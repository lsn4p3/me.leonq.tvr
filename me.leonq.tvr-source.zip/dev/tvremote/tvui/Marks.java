package dev.tvremote.tvui;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.text.style.ReplacementSpan;
import java.util.HashMap;
import java.util.Map;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;

/* loaded from: classes.dex */
public abstract class Marks {
    public static final Object ICONS;
    public static final String SET;
    public static final HashMap ids;

    /* loaded from: classes.dex */
    public final class IconSpan extends ReplacementSpan {
        public final Drawable d;

        public IconSpan(Drawable drawable) {
            this.d = drawable;
        }

        @Override // android.text.style.ReplacementSpan
        public final void draw(Canvas cv, CharSequence charSequence, int i, int i2, float f, int i3, int i4, int i5, Paint p) {
            Intrinsics.checkNotNullParameter(cv, "cv");
            Intrinsics.checkNotNullParameter(p, "p");
            int textSize = (int) (p.getTextSize() * 1.05f);
            float f2 = i4;
            float f3 = 2;
            int i6 = (int) ((p.getFontMetrics().descent / f3) + (p.getFontMetrics().ascent / f3) + f2);
            Drawable drawable = this.d;
            drawable.setBounds(0, 0, textSize, textSize);
            drawable.setTint(p.getColor());
            cv.save();
            cv.translate(f, i6 - (textSize / 2));
            drawable.draw(cv);
            cv.restore();
        }

        @Override // android.text.style.ReplacementSpan
        public final int getSize(Paint p, CharSequence charSequence, int i, int i2, Paint.FontMetricsInt fontMetricsInt) {
            Intrinsics.checkNotNullParameter(p, "p");
            if (fontMetricsInt != null) {
                Paint.FontMetricsInt fontMetricsInt2 = p.getFontMetricsInt();
                fontMetricsInt.ascent = fontMetricsInt2.ascent;
                fontMetricsInt.descent = fontMetricsInt2.descent;
                fontMetricsInt.top = fontMetricsInt2.top;
                fontMetricsInt.bottom = fontMetricsInt2.bottom;
                fontMetricsInt.leading = fontMetricsInt2.leading;
            }
            return (int) (p.getTextSize() * 1.05f);
        }
    }

    static {
        Map mapOf = MapsKt__MapsKt.mapOf(new Pair((char) 10003, "ic_check"), new Pair((char) 10004, "ic_check"), new Pair((char) 10007, "ic_close"), new Pair((char) 10005, "ic_close"), new Pair((char) 10006, "ic_close"), new Pair((char) 9888, "ic_alert"), new Pair((char) 9654, "ic_play"), new Pair((char) 9211, "ic_power"), new Pair((char) 9209, "ic_stop"), new Pair((char) 9208, "ic_pause"), new Pair((char) 9834, "ic_music"), new Pair((char) 8635, "ic_refresh"), new Pair((char) 8617, "ic_undo"), new Pair((char) 9733, "ic_star"), new Pair((char) 9734, "ic_star"), new Pair((char) 9881, "ic_settings"), new Pair((char) 11015, "ic_download"), new Pair((char) 9003, "ic_backspace"));
        ICONS = mapOf;
        SET = CollectionsKt.joinToString$default(mapOf.keySet(), "", null, null, null, 62);
        ids = new HashMap();
    }

    public static boolean isMark(String s, int i) {
        Intrinsics.checkNotNullParameter(s, "s");
        if (StringsKt.indexOf$default(SET, s.charAt(i), 6) >= 0) {
            int i2 = i + 1;
            if (i2 >= s.length() || s.charAt(i2) != 65039) {
                return true;
            }
            return false;
        }
        return false;
    }

    public static String plain(String s) {
        Intrinsics.checkNotNullParameter(s, "s");
        StringBuilder sb = new StringBuilder();
        int i = 0;
        int i2 = 0;
        while (i < s.length()) {
            char charAt = s.charAt(i);
            int i3 = i2 + 1;
            if (!isMark(s, i2)) {
                sb.append(charAt);
            }
            i++;
            i2 = i3;
        }
        return StringsKt__StringsJVMKt.replace$default(StringsKt.trim(sb.toString()).toString(), "  ", " ");
    }
}
