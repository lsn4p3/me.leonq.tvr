package dev.tvremote;

import dev.tvremote.core.Census$$ExternalSyntheticLambda4;
import java.security.Provider;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import kotlin.SynchronizedLazyImpl;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class ConscryptBackend {
    public final SynchronizedLazyImpl provider$delegate = new SynchronizedLazyImpl(new Census$$ExternalSyntheticLambda4(1));

    public final SSLContext context(KeyManager[] keyManagerArr, TrustManager[] trustManagerArr) {
        Object value = this.provider$delegate.getValue();
        Intrinsics.checkNotNullExpressionValue(value, "getValue(...)");
        SSLContext sSLContext = SSLContext.getInstance("TLSv1.3", (Provider) value);
        sSLContext.init(keyManagerArr, trustManagerArr, null);
        return sSLContext;
    }
}
