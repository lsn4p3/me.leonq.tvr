package dev.tvremote.core;

import kotlin.jvm.functions.Function0;

/* loaded from: classes.dex */
public final /* synthetic */ class Census$$ExternalSyntheticLambda7 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Function0 f$0;

    public /* synthetic */ Census$$ExternalSyntheticLambda7(Function0 function0, int i) {
        this.$r8$classId = i;
        this.f$0 = function0;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.$r8$classId) {
            case 0:
                try {
                    this.f$0.invoke();
                    return;
                } catch (Throwable unused) {
                    return;
                }
            default:
                try {
                    this.f$0.invoke();
                    return;
                } catch (InterruptedException unused2) {
                    return;
                }
        }
    }
}
