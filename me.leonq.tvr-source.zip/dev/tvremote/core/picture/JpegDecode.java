package dev.tvremote.core.picture;

import dev.tvremote.update.Ed25519;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;
import kotlin.Triple;
import kotlin.collections.EmptyList;
import kotlin.math.MathKt;

/* loaded from: classes.dex */
public abstract class JpegDecode {
    public static final float[][] COS;
    public static final int[] ZIGZAG = {0, 1, 8, 16, 9, 2, 3, 10, 17, 24, 32, 25, 18, 11, 4, 5, 12, 19, 26, 33, 40, 48, 41, 34, 27, 20, 13, 6, 7, 14, 21, 28, 35, 42, 49, 56, 57, 50, 43, 36, 29, 22, 15, 23, 30, 37, 44, 51, 58, 59, 52, 45, 38, 31, 39, 46, 53, 60, 61, 54, 47, 55, 62, 63};

    /* loaded from: classes.dex */
    public final class Comp {
        public int bw;
        public int dc;
        public final int h;
        public final int id;
        public byte[] plane = new byte[0];
        public int ta;
        public int td;
        public final int tq;
        public final int v;

        public Comp(int i, int i2, int i3, int i4) {
            this.id = i;
            this.h = i2;
            this.v = i3;
            this.tq = i4;
        }
    }

    /* loaded from: classes.dex */
    public final class Reader {
        public final Ed25519.Pt[] acT;
        public final byte[] b;
        public int bits;
        public Object comps;
        public final Ed25519.Pt[] dcT;
        public int h;
        public boolean hit;
        public int nbits;
        public int p;
        public final int[][] q;
        public int restart;
        public int w;

        public Reader(byte[] bArr) {
            this.b = bArr;
            int[][] iArr = new int[4];
            for (int i = 0; i < 4; i++) {
                int[] iArr2 = new int[64];
                for (int i2 = 0; i2 < 64; i2++) {
                    iArr2[i2] = 1;
                }
                iArr[i] = iArr2;
            }
            this.q = iArr;
            this.dcT = new Ed25519.Pt[4];
            this.acT = new Ed25519.Pt[4];
            this.comps = EmptyList.INSTANCE;
        }

        public static final int decode$sample(int i, int i2, int i3, int i4, Comp comp) {
            return comp.plane[((i3 * comp.h) / i4) + (comp.bw * 8 * ((i * comp.v) / i2))] & 255;
        }

        public final int bit() {
            int i;
            if (this.nbits < 1) {
                while (this.nbits <= 24) {
                    int i2 = 0;
                    if (!this.hit) {
                        int i3 = this.p;
                        byte[] bArr = this.b;
                        if (i3 < bArr.length) {
                            int u8 = u8();
                            if (u8 == 255) {
                                int i4 = this.p;
                                if (i4 < bArr.length) {
                                    i = bArr[i4] & 255;
                                } else {
                                    i = 217;
                                }
                                if (i == 0) {
                                    this.p = i4 + 1;
                                } else {
                                    this.hit = true;
                                    this.p = i4 - 1;
                                }
                            }
                            i2 = u8;
                        }
                    }
                    int i5 = this.bits;
                    int i6 = this.nbits;
                    this.bits = i5 | (i2 << (24 - i6));
                    this.nbits = i6 + 8;
                }
            }
            int i7 = this.bits;
            int i8 = i7 >>> 31;
            this.bits = i7 << 1;
            this.nbits--;
            return i8;
        }

        /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
        /* JADX WARN: Failed to find 'out' block for switch in B:30:0x0067. Please report as an issue. */
        /* JADX WARN: Removed duplicated region for block: B:247:0x03bc  */
        /* JADX WARN: Removed duplicated region for block: B:256:0x03e6 A[SYNTHETIC] */
        /* JADX WARN: Type inference failed for: r12v2, types: [java.util.List, java.lang.Object] */
        /* JADX WARN: Type inference failed for: r14v2, types: [java.util.List, java.lang.Object] */
        /* JADX WARN: Type inference failed for: r1v74, types: [java.lang.Object, java.lang.Iterable] */
        /* JADX WARN: Type inference failed for: r1v9, types: [java.util.List, java.lang.Object] */
        /* JADX WARN: Type inference failed for: r2v10, types: [java.util.Collection, java.lang.Object] */
        /* JADX WARN: Type inference failed for: r2v12, types: [java.lang.Object, java.lang.Iterable] */
        /* JADX WARN: Type inference failed for: r2v14, types: [java.lang.Object, java.lang.Iterable] */
        /* JADX WARN: Type inference failed for: r2v16, types: [java.util.List, java.lang.Object] */
        /* JADX WARN: Type inference failed for: r2v7, types: [java.util.List, java.lang.Object] */
        /* JADX WARN: Type inference failed for: r3v10, types: [java.lang.Object, java.lang.Iterable] */
        /* JADX WARN: Type inference failed for: r4v4, types: [java.util.List, java.lang.Object] */
        /* JADX WARN: Type inference failed for: r8v11, types: [java.util.List, java.lang.Object] */
        /* JADX WARN: Type inference failed for: r8v3, types: [java.util.List, java.lang.Object] */
        /* JADX WARN: Type inference failed for: r9v11, types: [java.util.List, java.lang.Object] */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final Triple run() {
            boolean z;
            int i;
            int i2;
            byte[] bArr;
            int i3;
            Iterator it;
            int i4;
            int i5;
            int i6;
            int i7;
            int i8;
            int i9;
            int i10;
            Object obj;
            int u16;
            int i11;
            int i12;
            Ed25519.Pt[] ptArr;
            byte[] bArr2 = this.b;
            int i13 = 4;
            if (bArr2.length >= 4 && u16() == 65496) {
                while (this.p + i13 <= bArr2.length && u8() == 255) {
                    int u8 = u8();
                    while (u8 == 255) {
                        u8 = u8();
                    }
                    if (u8 != 217) {
                        if (208 > u8 || u8 >= 217) {
                            if (u8 != 1 && u8 != 0) {
                                int u162 = (this.p + u16()) - 2;
                                Ed25519.Pt[] ptArr2 = this.acT;
                                Ed25519.Pt[] ptArr3 = this.dcT;
                                int[][] iArr = this.q;
                                if (u8 != 218) {
                                    if (u8 != 219) {
                                        if (u8 != 221) {
                                            switch (u8) {
                                                case 192:
                                                case 193:
                                                    if (u8() != 8) {
                                                        return null;
                                                    }
                                                    this.h = u16();
                                                    this.w = u16();
                                                    int u82 = u8();
                                                    int i14 = this.w;
                                                    if (i14 <= 0 || (i11 = this.h) <= 0 || i14 * i11 > 40000000) {
                                                        return null;
                                                    }
                                                    if (u82 != 1 && u82 != 3) {
                                                        return null;
                                                    }
                                                    ArrayList arrayList = new ArrayList(u82);
                                                    for (int i15 = 0; i15 < u82; i15++) {
                                                        int u83 = u8();
                                                        int u84 = u8();
                                                        arrayList.add(new Comp(u83, u84 >> 4, u84 & 15, u8() & 3));
                                                    }
                                                    this.comps = arrayList;
                                                    if (!arrayList.isEmpty()) {
                                                        Iterator it2 = arrayList.iterator();
                                                        while (it2.hasNext()) {
                                                            Comp comp = (Comp) it2.next();
                                                            int i16 = comp.h;
                                                            if (1 > i16 || i16 >= 5 || 1 > (i12 = comp.v) || i12 >= 5) {
                                                                return null;
                                                            }
                                                        }
                                                        break;
                                                    }
                                                    break;
                                                case 194:
                                                case 195:
                                                case 197:
                                                case 198:
                                                case 199:
                                                    return null;
                                                case 196:
                                                    while (this.p < u162) {
                                                        int u85 = u8();
                                                        int[] iArr2 = new int[17];
                                                        int i17 = 0;
                                                        for (int i18 = 1; i18 < 17; i18++) {
                                                            int u86 = u8();
                                                            iArr2[i18] = u86;
                                                            i17 += u86;
                                                        }
                                                        int[] iArr3 = new int[i17];
                                                        for (int i19 = 0; i19 < i17; i19++) {
                                                            iArr3[i19] = u8();
                                                        }
                                                        if ((u85 >> 4) == 0) {
                                                            ptArr = ptArr3;
                                                        } else {
                                                            ptArr = ptArr2;
                                                        }
                                                        ptArr[u85 & 3] = new Ed25519.Pt(iArr2, iArr3);
                                                    }
                                                    break;
                                                default:
                                                    switch (u8) {
                                                        case 201:
                                                        case 202:
                                                        case 203:
                                                            return null;
                                                        default:
                                                            switch (u8) {
                                                                case 205:
                                                                case 206:
                                                                case 207:
                                                                    return null;
                                                            }
                                                    }
                                            }
                                        } else {
                                            this.restart = u16();
                                        }
                                        this.p = u162;
                                        i13 = 4;
                                    }
                                    while (this.p < u162) {
                                        int u87 = u8();
                                        int i20 = u87 & 3;
                                        for (int i21 = 0; i21 < 64; i21++) {
                                            int[] iArr4 = iArr[i20];
                                            int i22 = JpegDecode.ZIGZAG[i21];
                                            if ((u87 >> 4) == 0) {
                                                u16 = u8();
                                            } else {
                                                u16 = u16();
                                            }
                                            iArr4[i22] = u16;
                                        }
                                    }
                                    this.p = u162;
                                    i13 = 4;
                                } else {
                                    if (this.comps.isEmpty() || u8() != this.comps.size()) {
                                        return null;
                                    }
                                    int size = this.comps.size();
                                    for (int i23 = 0; i23 < size; i23++) {
                                        int u88 = u8();
                                        int u89 = u8();
                                        Iterator it3 = this.comps.iterator();
                                        while (true) {
                                            if (it3.hasNext()) {
                                                obj = it3.next();
                                                if (((Comp) obj).id == u88) {
                                                }
                                            } else {
                                                obj = null;
                                            }
                                        }
                                        Comp comp2 = (Comp) obj;
                                        if (comp2 == null) {
                                            return null;
                                        }
                                        comp2.td = u89 >> 4;
                                        comp2.ta = u89 & 15;
                                    }
                                    this.p = u162;
                                    Iterator it4 = this.comps.iterator();
                                    if (it4.hasNext()) {
                                        int i24 = ((Comp) it4.next()).h;
                                        while (it4.hasNext()) {
                                            int i25 = ((Comp) it4.next()).h;
                                            if (i24 < i25) {
                                                i24 = i25;
                                            }
                                        }
                                        Iterator it5 = this.comps.iterator();
                                        if (it5.hasNext()) {
                                            int i26 = ((Comp) it5.next()).v;
                                            while (it5.hasNext()) {
                                                int i27 = ((Comp) it5.next()).v;
                                                if (i26 < i27) {
                                                    i26 = i27;
                                                }
                                            }
                                            if (this.comps.size() == 1) {
                                                z = true;
                                            } else {
                                                z = false;
                                            }
                                            int i28 = this.w;
                                            if (z) {
                                                i = (i28 + 7) / 8;
                                            } else {
                                                int i29 = i24 * 8;
                                                i = ((i28 + i29) - 1) / i29;
                                            }
                                            int i30 = this.h;
                                            if (z) {
                                                i2 = (i30 + 7) / 8;
                                            } else {
                                                int i31 = i26 * 8;
                                                i2 = ((i30 + i31) - 1) / i31;
                                            }
                                            for (Comp comp3 : this.comps) {
                                                if (z) {
                                                    i9 = i;
                                                } else {
                                                    i9 = comp3.h * i;
                                                }
                                                comp3.bw = i9;
                                                if (z) {
                                                    i10 = i2;
                                                } else {
                                                    i10 = comp3.v * i2;
                                                }
                                                comp3.plane = new byte[i9 * 8 * i10 * 8];
                                            }
                                            float[] fArr = new float[64];
                                            float[] fArr2 = new float[64];
                                            int i32 = this.restart;
                                            for (int i33 = 0; i33 < i2; i33++) {
                                                int i34 = 0;
                                                while (i34 < i) {
                                                    boolean z2 = z;
                                                    if (this.restart > 0 && i32 == 0) {
                                                        this.nbits = 0;
                                                        this.bits = 0;
                                                        if (this.hit) {
                                                            this.hit = false;
                                                            this.p += 2;
                                                            bArr = bArr2;
                                                        } else {
                                                            while (true) {
                                                                i7 = this.p;
                                                                int i35 = i7 + 1;
                                                                if (i35 < bArr2.length) {
                                                                    bArr = bArr2;
                                                                    if (bArr2[i7] != -1 || 208 > (i8 = bArr[i35] & 255) || i8 >= 216) {
                                                                        this.p = i35;
                                                                        bArr2 = bArr;
                                                                    }
                                                                } else {
                                                                    bArr = bArr2;
                                                                }
                                                            }
                                                            this.p = i7 + 2;
                                                        }
                                                        Iterator it6 = this.comps.iterator();
                                                        while (it6.hasNext()) {
                                                            ((Comp) it6.next()).dc = 0;
                                                        }
                                                        i32 = this.restart;
                                                    } else {
                                                        bArr = bArr2;
                                                    }
                                                    i32--;
                                                    Iterator it7 = this.comps.iterator();
                                                    while (it7.hasNext()) {
                                                        Comp comp4 = (Comp) it7.next();
                                                        if (z2) {
                                                            i3 = 1;
                                                        } else {
                                                            i3 = comp4.v;
                                                        }
                                                        if (z2) {
                                                            it = it7;
                                                            i4 = 1;
                                                        } else {
                                                            it = it7;
                                                            i4 = comp4.h;
                                                        }
                                                        float[] fArr3 = fArr2;
                                                        Ed25519.Pt pt = ptArr3[comp4.td];
                                                        if (pt == null) {
                                                            return null;
                                                        }
                                                        int i36 = i32;
                                                        Ed25519.Pt pt2 = ptArr2[comp4.ta];
                                                        if (pt2 == null) {
                                                            return null;
                                                        }
                                                        int i37 = i34;
                                                        int[] iArr5 = iArr[comp4.tq];
                                                        int i38 = 0;
                                                        while (i38 < i3) {
                                                            int i39 = i38;
                                                            int i40 = 0;
                                                            while (true) {
                                                                int i41 = i4;
                                                                if (i40 < i4) {
                                                                    int i42 = i40;
                                                                    int i43 = i;
                                                                    Arrays.fill(fArr, 0, 64, 0.0f);
                                                                    int sym = sym(pt);
                                                                    int i44 = comp4.dc;
                                                                    float[] fArr4 = fArr;
                                                                    int i45 = 0;
                                                                    for (int i46 = 0; i46 < sym; i46++) {
                                                                        i45 = (i45 << 1) | bit();
                                                                    }
                                                                    if (sym == 0) {
                                                                        i5 = 0;
                                                                    } else if (i45 < (1 << (sym - 1))) {
                                                                        i5 = (i45 - (1 << sym)) + 1;
                                                                    } else {
                                                                        i5 = i45;
                                                                    }
                                                                    comp4.dc = i5 + i44;
                                                                    fArr4[0] = r1 * iArr5[0];
                                                                    int i47 = 1;
                                                                    for (int i48 = 64; i47 < i48; i48 = 64) {
                                                                        int sym2 = sym(pt2);
                                                                        int i49 = sym2 >> 4;
                                                                        int i50 = sym2 & 15;
                                                                        if (i50 == 0) {
                                                                            if (i49 == 15) {
                                                                                i47 += 16;
                                                                            } else {
                                                                                i6 = 0;
                                                                                while (true) {
                                                                                    int i51 = 8;
                                                                                    if (i6 < 8) {
                                                                                        int i52 = 0;
                                                                                        while (i52 < i51) {
                                                                                            int i53 = 0;
                                                                                            float f = 0.0f;
                                                                                            while (i53 < i51) {
                                                                                                f = (JpegDecode.COS[i52][i53] * fArr4[(i6 * 8) + i53]) + f;
                                                                                                i53++;
                                                                                                i51 = 8;
                                                                                            }
                                                                                            fArr3[(i6 * 8) + i52] = f;
                                                                                            i52++;
                                                                                            i51 = 8;
                                                                                        }
                                                                                        i6++;
                                                                                    } else {
                                                                                        int i54 = 0;
                                                                                        while (i54 < i51) {
                                                                                            int i55 = 0;
                                                                                            while (i55 < i51) {
                                                                                                int i56 = 0;
                                                                                                float f2 = 0.0f;
                                                                                                while (i56 < i51) {
                                                                                                    f2 = (JpegDecode.COS[i55][i56] * fArr3[(i56 * 8) + i54]) + f2;
                                                                                                    i56++;
                                                                                                    i51 = 8;
                                                                                                }
                                                                                                fArr4[(i55 * 8) + i54] = f2;
                                                                                                i55++;
                                                                                                i51 = 8;
                                                                                            }
                                                                                            i54++;
                                                                                            i51 = 8;
                                                                                        }
                                                                                        int i57 = 8;
                                                                                        int i58 = ((i37 * i41) + i42) * 8;
                                                                                        int i59 = ((i33 * i3) + i39) * 8;
                                                                                        int i60 = comp4.bw * 8;
                                                                                        int i61 = 0;
                                                                                        while (i61 < i57) {
                                                                                            int i62 = i61;
                                                                                            int i63 = 0;
                                                                                            while (i63 < i57) {
                                                                                                comp4.plane[((i59 + i62) * i60) + i58 + i63] = (byte) MathKt.coerceIn((int) (fArr4[(i62 * 8) + i63] + 128.5f), 0, 255);
                                                                                                i63++;
                                                                                                comp4 = comp4;
                                                                                                i57 = 8;
                                                                                            }
                                                                                            i61 = i62 + 1;
                                                                                            i57 = 8;
                                                                                        }
                                                                                        i40 = i42 + 1;
                                                                                        i4 = i41;
                                                                                        i = i43;
                                                                                        fArr = fArr4;
                                                                                    }
                                                                                }
                                                                            }
                                                                        } else {
                                                                            int i64 = i47 + i49;
                                                                            if (i64 <= 63) {
                                                                                int i65 = JpegDecode.ZIGZAG[i64];
                                                                                int i66 = 0;
                                                                                for (int i67 = 0; i67 < i50; i67++) {
                                                                                    i66 = (i66 << 1) | bit();
                                                                                }
                                                                                if (i50 == 0) {
                                                                                    i66 = 0;
                                                                                } else if (i66 < (1 << (i50 - 1))) {
                                                                                    i66 = (i66 - (1 << i50)) + 1;
                                                                                }
                                                                                fArr4[i65] = i66 * iArr5[i65];
                                                                                i47 = i64 + 1;
                                                                            } else {
                                                                                i6 = 0;
                                                                                while (true) {
                                                                                    int i512 = 8;
                                                                                    if (i6 < 8) {
                                                                                    }
                                                                                    i6++;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                    i6 = 0;
                                                                    while (true) {
                                                                        int i5122 = 8;
                                                                        if (i6 < 8) {
                                                                        }
                                                                        i6++;
                                                                    }
                                                                }
                                                            }
                                                            i38 = i39 + 1;
                                                        }
                                                        it7 = it;
                                                        fArr2 = fArr3;
                                                        i32 = i36;
                                                        i34 = i37;
                                                    }
                                                    i34++;
                                                    z = z2;
                                                    bArr2 = bArr;
                                                }
                                            }
                                            boolean z3 = z;
                                            int i68 = this.w;
                                            int i69 = this.h;
                                            byte[] bArr3 = new byte[i68 * i69 * 3];
                                            for (int i70 = 0; i70 < i69; i70++) {
                                                int i71 = this.w;
                                                for (int i72 = 0; i72 < i71; i72++) {
                                                    int i73 = ((this.w * i70) + i72) * 3;
                                                    if (z3) {
                                                        byte decode$sample = (byte) decode$sample(i70, i26, i72, i24, (Comp) this.comps.get(0));
                                                        bArr3[i73] = decode$sample;
                                                        bArr3[i73 + 1] = decode$sample;
                                                        bArr3[i73 + 2] = decode$sample;
                                                    } else {
                                                        float decode$sample2 = decode$sample(i70, i26, i72, i24, (Comp) this.comps.get(0));
                                                        float decode$sample3 = decode$sample(i70, i26, i72, i24, (Comp) this.comps.get(1)) - 128.0f;
                                                        float decode$sample4 = decode$sample(i70, i26, i72, i24, (Comp) this.comps.get(2)) - 128.0f;
                                                        bArr3[i73] = (byte) MathKt.coerceIn((int) ((1.402f * decode$sample4) + decode$sample2 + 0.5f), 0, 255);
                                                        bArr3[i73 + 1] = (byte) MathKt.coerceIn((int) (((decode$sample2 - (0.344136f * decode$sample3)) - (decode$sample4 * 0.714136f)) + 0.5f), 0, 255);
                                                        bArr3[i73 + 2] = (byte) MathKt.coerceIn((int) ((decode$sample3 * 1.772f) + decode$sample2 + 0.5f), 0, 255);
                                                    }
                                                }
                                            }
                                            return new Triple(Integer.valueOf(this.w), Integer.valueOf(this.h), bArr3);
                                        }
                                        throw new NoSuchElementException();
                                    }
                                    throw new NoSuchElementException();
                                }
                            }
                        }
                    }
                }
            }
            return null;
        }

        public final int sym(Ed25519.Pt pt) {
            int i;
            int i2 = 0;
            for (int i3 = 1; i3 < 17; i3++) {
                i2 = (i2 << 1) | bit();
                int i4 = ((int[]) pt.z)[i3];
                if (i4 >= 0 && i2 <= i4 && i2 >= (i = ((int[]) pt.y)[i3])) {
                    return ((int[]) pt.x)[(((int[]) pt.t)[i3] + i2) - i];
                }
            }
            throw new IllegalStateException("code");
        }

        public final int u16() {
            return (u8() << 8) | u8();
        }

        public final int u8() {
            int i = this.p;
            this.p = i + 1;
            return this.b[i] & 255;
        }
    }

    static {
        float[][] fArr = new float[8];
        for (int i = 0; i < 8; i++) {
            float[] fArr2 = new float[8];
            for (int i2 = 0; i2 < 8; i2++) {
                double d = 1.0d;
                if (i2 == 0) {
                    d = 1.0d / Math.sqrt(2.0d);
                }
                fArr2[i2] = (float) (Math.cos(((((i * 2) + 1) * i2) * 3.141592653589793d) / 16) * d * 0.5d);
            }
            fArr[i] = fArr2;
        }
        COS = fArr;
    }
}
