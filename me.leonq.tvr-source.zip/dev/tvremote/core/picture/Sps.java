package dev.tvremote.core.picture;

import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.phone.ir.Ir$Signal;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.Set;
import kotlin.Pair;
import kotlin.collections.SetsKt;
import kotlin.jvm.internal.Intrinsics;
import org.conscrypt.PSKKeyManager;

/* loaded from: classes.dex */
public abstract class Sps {
    public static final Set HIGH = SetsKt.setOf((Object[]) new Integer[]{100, 110, 122, 244, 44, 83, 86, 118, 128, 138, 139, 134, 135});

    public static void hrd(Ir$Signal ir$Signal) {
        int ue = ir$Signal.ue();
        ir$Signal.u(8);
        int i = ue + 1;
        for (int i2 = 0; i2 < i; i2++) {
            ir$Signal.ue();
            ir$Signal.ue();
            ir$Signal.u(1);
        }
        ir$Signal.u(20);
    }

    public static Pair restrict(byte[] bArr) {
        boolean z;
        boolean z2;
        int i;
        int i2;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(bArr.length);
        int i3 = 0;
        for (byte b : bArr) {
            int i4 = 255 & b;
            if (i3 < 2 || i4 != 3) {
                byteArrayOutputStream.write(i4);
                if (i4 == 0) {
                    i3++;
                }
            }
            i3 = 0;
        }
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        Intrinsics.checkNotNullExpressionValue(byteArray, "toByteArray(...)");
        Ir$Signal ir$Signal = new Ir$Signal(byteArray);
        ir$Signal.hz = 8;
        int u = ir$Signal.u(8);
        ir$Signal.u(16);
        ir$Signal.ue();
        if (HIGH.contains(Integer.valueOf(u))) {
            int ue = ir$Signal.ue();
            if (ue == 3) {
                ir$Signal.u(1);
            }
            ir$Signal.ue();
            ir$Signal.ue();
            ir$Signal.u(1);
            if (ir$Signal.u(1) == 1) {
                if (ue == 3) {
                    i = 12;
                } else {
                    i = 8;
                }
                for (int i5 = 0; i5 < i; i5++) {
                    if (ir$Signal.u(1) == 1) {
                        if (i5 < 6) {
                            i2 = 16;
                        } else {
                            i2 = 64;
                        }
                        int i6 = 8;
                        int i7 = 8;
                        for (int i8 = 0; i8 < i2; i8++) {
                            if (i6 != 0) {
                                i6 = ((ir$Signal.se() + i7) + PSKKeyManager.MAX_KEY_LENGTH_BYTES) % PSKKeyManager.MAX_KEY_LENGTH_BYTES;
                            }
                            if (i6 != 0) {
                                i7 = i6;
                            }
                        }
                    }
                }
            }
        }
        ir$Signal.ue();
        int ue2 = ir$Signal.ue();
        if (ue2 != 0) {
            if (ue2 == 1) {
                ir$Signal.u(1);
                ir$Signal.se();
                ir$Signal.se();
                int ue3 = ir$Signal.ue();
                for (int i9 = 0; i9 < ue3; i9++) {
                    ir$Signal.se();
                }
            }
        } else {
            ir$Signal.ue();
        }
        int ue4 = ir$Signal.ue();
        ir$Signal.u(1);
        ir$Signal.ue();
        ir$Signal.ue();
        if (ir$Signal.u(1) == 0) {
            ir$Signal.u(1);
        }
        ir$Signal.u(1);
        if (ir$Signal.u(1) == 1) {
            for (int i10 = 0; i10 < 4; i10++) {
                ir$Signal.ue();
            }
        }
        String str = "profile " + u + " poc " + ue2 + " refs " + ue4;
        Out out = new Out(0);
        int i11 = ir$Signal.hz;
        if (ir$Signal.u(1) == 0) {
            ir$Signal.hz = 0;
            while (ir$Signal.hz < i11) {
                out.u(1, ir$Signal.u(1));
            }
            out.u(1, 1);
            for (int i12 = 0; i12 < 8; i12++) {
                out.u(1, 0);
            }
        } else {
            if (ir$Signal.u(1) == 1 && ir$Signal.u(8) == 255) {
                ir$Signal.u(32);
            }
            if (ir$Signal.u(1) == 1) {
                ir$Signal.u(1);
            }
            if (ir$Signal.u(1) == 1) {
                ir$Signal.u(4);
                if (ir$Signal.u(1) == 1) {
                    ir$Signal.u(24);
                }
            }
            if (ir$Signal.u(1) == 1) {
                ir$Signal.ue();
                ir$Signal.ue();
            }
            if (ir$Signal.u(1) == 1) {
                ir$Signal.u(32);
                ir$Signal.u(32);
                ir$Signal.u(1);
            }
            if (ir$Signal.u(1) == 1) {
                z = true;
            } else {
                z = false;
            }
            if (z) {
                hrd(ir$Signal);
            }
            if (ir$Signal.u(1) == 1) {
                z2 = true;
            } else {
                z2 = false;
            }
            if (z2) {
                hrd(ir$Signal);
            }
            if (z || z2) {
                ir$Signal.u(1);
            }
            ir$Signal.u(1);
            int i13 = ir$Signal.hz;
            if (ir$Signal.u(1) == 1) {
                return new Pair(null, Census$$ExternalSyntheticOutline0.m(str, ", restricted"));
            }
            ir$Signal.hz = 0;
            while (ir$Signal.hz < i13) {
                out.u(1, ir$Signal.u(1));
            }
        }
        out.u(1, 1);
        out.u(1, 1);
        out.ue(2);
        out.ue(1);
        out.ue(16);
        out.ue(16);
        out.ue(0);
        out.ue(Math.max(ue4, 1));
        out.u(1, 1);
        while (out.n != 0) {
            out.u(1, 0);
        }
        byte[] byteArray2 = ((ByteArrayOutputStream) out.o).toByteArray();
        Intrinsics.checkNotNullExpressionValue(byteArray2, "toByteArray(...)");
        ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream(byteArray2.length + 4);
        int i14 = 0;
        for (byte b2 : byteArray2) {
            int i15 = b2 & 255;
            if (i14 >= 2 && i15 <= 3) {
                byteArrayOutputStream2.write(3);
                i14 = 0;
            }
            byteArrayOutputStream2.write(i15);
            if (i15 == 0) {
                i14++;
            } else {
                i14 = 0;
            }
        }
        byte[] byteArray3 = byteArrayOutputStream2.toByteArray();
        Intrinsics.checkNotNullExpressionValue(byteArray3, "toByteArray(...)");
        return new Pair(byteArray3, str + ", restriction added");
    }

    /* loaded from: classes.dex */
    public final class Out {
        public int cur;
        public int n;
        public final Object o;

        public Out(int i) {
            switch (i) {
                case 1:
                    this.o = new ByteArrayOutputStream();
                    return;
                default:
                    this.o = new ByteArrayOutputStream();
                    return;
            }
        }

        public void put(int i, int i2) {
            while (true) {
                i2--;
                if (-1 < i2) {
                    int i3 = (this.cur << 1) | ((i >> i2) & 1);
                    this.cur = i3;
                    int i4 = this.n + 1;
                    this.n = i4;
                    if (i4 == 8) {
                        ByteArrayOutputStream byteArrayOutputStream = (ByteArrayOutputStream) this.o;
                        byteArrayOutputStream.write(i3);
                        if (this.cur == 255) {
                            byteArrayOutputStream.write(0);
                        }
                        this.cur = 0;
                        this.n = 0;
                    }
                } else {
                    return;
                }
            }
        }

        public void u(int i, int i2) {
            while (true) {
                i--;
                if (-1 < i) {
                    int i3 = (this.cur << 1) | ((i2 >> i) & 1);
                    this.cur = i3;
                    int i4 = this.n + 1;
                    this.n = i4;
                    if (i4 == 8) {
                        ((ByteArrayOutputStream) this.o).write(i3);
                        this.cur = 0;
                        this.n = 0;
                    }
                } else {
                    return;
                }
            }
        }

        public void ue(int i) {
            int i2 = i + 1;
            int numberOfLeadingZeros = Integer.numberOfLeadingZeros(i2);
            u(31 - numberOfLeadingZeros, 0);
            u(32 - numberOfLeadingZeros, i2);
        }

        public Out(ByteBuffer byteBuffer, int i, int i2) {
            this.cur = i;
            this.o = byteBuffer;
            this.n = i2;
        }
    }
}
