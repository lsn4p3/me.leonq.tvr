package dev.tvremote.core.picture;

import kotlin.math.MathKt;

/* loaded from: classes.dex */
public final class SoundQueue {
    public final int base;
    public long calm;
    public boolean cutting;
    public long gapMax;
    public long gapMs;
    public int gaps;
    public int heldFrames;
    public long lastAt;
    public long lastBehind;
    public long lastDrop;
    public boolean played;
    public long started;
    public int target;

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* loaded from: classes.dex */
    public final class Do {
        public static final /* synthetic */ Do[] $VALUES;
        public static final Do DROP;
        public static final Do HOLD;
        public static final Do PLAY;

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r3v0, types: [java.lang.Enum, dev.tvremote.core.picture.SoundQueue$Do] */
        /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Enum, dev.tvremote.core.picture.SoundQueue$Do] */
        /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Enum, dev.tvremote.core.picture.SoundQueue$Do] */
        static {
            ?? r3 = new Enum("PLAY", 0);
            PLAY = r3;
            ?? r4 = new Enum("HOLD", 1);
            HOLD = r4;
            ?? r5 = new Enum("DROP", 2);
            DROP = r5;
            $VALUES = new Do[]{r3, r4, r5};
        }

        public static Do valueOf(String str) {
            return (Do) Enum.valueOf(Do.class, str);
        }

        public static Do[] values() {
            return (Do[]) $VALUES.clone();
        }
    }

    public SoundQueue(int i, int i2) {
        this.base = i;
        this.target = MathKt.coerceIn(i2, i, 48000);
    }
}
