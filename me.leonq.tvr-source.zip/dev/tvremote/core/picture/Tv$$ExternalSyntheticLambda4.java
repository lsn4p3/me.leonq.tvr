package dev.tvremote.core.picture;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census;
import dev.tvremote.core.Census$$ExternalSyntheticLambda3;
import dev.tvremote.core.WireLog;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.AdbPrompt;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda5;
import dev.tvremote.phone.MainActivity$onCreate$2;
import dev.tvremote.tvapps.ApkCert$$ExternalSyntheticLambda0;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__MutableCollectionsJVMKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;

/* loaded from: classes.dex */
public final /* synthetic */ class Tv$$ExternalSyntheticLambda4 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Tv f$0;

    public /* synthetic */ Tv$$ExternalSyntheticLambda4(Tv tv, int i) {
        this.$r8$classId = i;
        this.f$0 = tv;
    }

    /* JADX WARN: Can't wrap try/catch for region: R(8:174|175|(3:180|(3:295|296|297)(7:184|(5:186|187|188|189|190)(1:293)|(2:192|(2:194|(2:252|(1:(6:261|262|263|264|265|203))(7:256|257|258|259|250|238|(0)(0)))(2:198|(2:204|205)))(4:269|270|271|(2:273|274)))(3:278|279|(8:281|282|(1:284)|285|286|201|202|203))|200|201|202|203)|176)|300|228|229|230|(5:233|234|(1:236)|238|(0)(0))(1:232)) */
    /* JADX WARN: Code restructure failed: missing block: B:237:0x0548, code lost:
    
        if (r3.stopped == false) goto L269;
     */
    /* JADX WARN: Removed duplicated region for block: B:210:0x04e6 A[Catch: all -> 0x03a6, TRY_ENTER, TryCatch #5 {all -> 0x03a6, blocks: (B:171:0x02dc, B:175:0x0342, B:176:0x0358, B:178:0x035c, B:180:0x0362, B:184:0x036c, B:186:0x0384, B:189:0x0393, B:205:0x03c2, B:208:0x04ad, B:242:0x04b1, B:244:0x04d0, B:245:0x04d3, B:247:0x04d7, B:210:0x04e6, B:212:0x04ea, B:214:0x04ee, B:217:0x050e, B:252:0x03e2, B:254:0x03e7, B:257:0x03f8, B:263:0x040c, B:271:0x043f, B:274:0x0446, B:278:0x044f, B:282:0x046c, B:284:0x0474, B:285:0x047b, B:296:0x0495, B:297:0x049c), top: B:170:0x02dc }] */
    /* JADX WARN: Removed duplicated region for block: B:223:0x054f  */
    /* JADX WARN: Removed duplicated region for block: B:224:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:232:0x0524 A[LOOP:4: B:160:0x02ab->B:232:0x0524, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:233:0x0541 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:236:0x0546  */
    /* JADX WARN: Removed duplicated region for block: B:241:0x04b1 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:40:0x007f A[Catch: all -> 0x0054, TRY_ENTER, TryCatch #14 {all -> 0x0054, blocks: (B:18:0x0030, B:20:0x0034, B:22:0x003c, B:24:0x0040, B:26:0x0044, B:28:0x0048, B:30:0x0057, B:32:0x0060, B:34:0x0064, B:36:0x0072, B:38:0x0078, B:40:0x007f, B:42:0x0083, B:44:0x0087, B:48:0x00a3, B:98:0x008f), top: B:17:0x0030 }] */
    /* JADX WARN: Removed duplicated region for block: B:99:0x007c A[SYNTHETIC] */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void run() {
        String str;
        String str2;
        String concat;
        String str3;
        boolean z;
        HttpURLConnection openSetup;
        HttpURLConnection httpURLConnection;
        HttpURLConnection httpURLConnection2;
        String str4;
        String str5;
        int responseCode;
        int read;
        DataInputStream dataInputStream;
        long j;
        byte[] byteArray;
        Object obj;
        Object obj2;
        Long l;
        long j2;
        long j3;
        long j4 = 0;
        boolean z2 = true;
        switch (this.$r8$classId) {
            case 0:
                long j5 = 0;
                Tv tv = this.f$0;
                String str6 = tv.relay;
                if (str6 != null && tv.screen != null && tv.audio == null) {
                    tv.status("connecting", tv.host);
                    int i = tv.quality;
                    int i2 = tv.fps;
                    if (i2 <= 0) {
                        str = "";
                    } else {
                        str = ApkSigner$$ExternalSyntheticOutline0.m("&fps=", i2);
                    }
                    int i3 = tv.bitRate;
                    if (i3 <= 0) {
                        str2 = "";
                    } else {
                        str2 = ApkSigner$$ExternalSyntheticOutline0.m("&rate=", i3);
                    }
                    if (!tv.encoder.equals("hw") && !tv.encoder.equals("sw")) {
                        concat = "";
                    } else {
                        concat = "&enc=".concat(tv.encoder);
                    }
                    if (!tv.hand) {
                        str3 = "";
                    } else {
                        str3 = "&hand=1";
                    }
                    String str7 = "/api/video?q=" + i + str + str2 + concat + str3;
                    long j6 = 0;
                    boolean z3 = false;
                    while (!tv.stopped) {
                        tv.rejoin = false;
                        try {
                            AdbPrompt adbPrompt = AdbPrompt.INSTANCE;
                            openSetup = AdbPrompt.openSetup(tv.host, str6, str7);
                            openSetup.setReadTimeout(20000);
                            tv.feedConn = openSetup;
                            if (!z3) {
                                Thread thread = new Thread(new Guard$$ExternalSyntheticLambda5(14, tv, openSetup), "tv-relay-first-frame");
                                thread.setDaemon(z2);
                                thread.start();
                            }
                            httpURLConnection = null;
                            try {
                                try {
                                    try {
                                        responseCode = openSetup.getResponseCode();
                                    } catch (Throwable th) {
                                        th = th;
                                        httpURLConnection2 = null;
                                    }
                                } catch (IOException e) {
                                    e = e;
                                }
                            } catch (Exception unused) {
                            }
                        } catch (Exception e2) {
                            tv.relayEnd(z3, e2.toString());
                        }
                        if (responseCode != 200) {
                            try {
                                try {
                                    WireLog wireLog = WireLog.all;
                                    wireLog.add("·", "picture " + tv.host + " TV Setup answered " + responseCode);
                                    if (responseCode == 401 || responseCode == 403) {
                                        tv.listener.onPassRefused();
                                    }
                                    tv.relayEnd(z3, "http " + responseCode);
                                    tv.feedConn = null;
                                    try {
                                        openSetup.disconnect();
                                    } catch (Exception unused2) {
                                    }
                                    z = z3;
                                } catch (Throwable th2) {
                                    th = th2;
                                    httpURLConnection2 = null;
                                    tv.feedConn = httpURLConnection2;
                                    try {
                                        openSetup.disconnect();
                                    } catch (Exception unused3) {
                                    }
                                    throw th;
                                }
                            } catch (IOException e3) {
                                e = e3;
                                str4 = str6;
                                str5 = str7;
                                if (!tv.noFrame) {
                                }
                            }
                            if (z) {
                                WireLog.all.add("·", "picture " + tv.host + " TV Setup's picture did not come: over ADB");
                            } else {
                                return;
                            }
                        } else {
                            DataInputStream dataInputStream2 = new DataInputStream(new BufferedInputStream(openSetup.getInputStream(), 65536));
                            long currentTimeMillis = System.currentTimeMillis();
                            long j7 = j5;
                            while (!tv.stopped && (read = dataInputStream2.read()) >= 0) {
                                int readInt = dataInputStream2.readInt();
                                if (readInt >= 0 && readInt <= 8388608) {
                                    byte[] bArr = new byte[readInt];
                                    dataInputStream2.readFully(bArr);
                                    j7 += readInt + 5;
                                    long currentTimeMillis2 = System.currentTimeMillis();
                                    long j8 = currentTimeMillis2 - currentTimeMillis;
                                    if (j8 >= 3000) {
                                        dataInputStream = dataInputStream2;
                                        str4 = str6;
                                        str5 = str7;
                                        try {
                                            tv.listener.onStatus("rate", String.valueOf(((j7 * 1000) / j8) / 1024));
                                            currentTimeMillis = currentTimeMillis2;
                                            j7 = j5;
                                        } catch (IOException e4) {
                                            e = e4;
                                            if (!tv.noFrame) {
                                            }
                                        }
                                    } else {
                                        dataInputStream = dataInputStream2;
                                        str4 = str6;
                                        str5 = str7;
                                    }
                                    if (read != 0) {
                                        if (read != 1) {
                                            if (read != 2 && read != 3) {
                                                if (read == 5) {
                                                    try {
                                                        WireLog.all.add("·", "picture " + tv.host + " fell behind, TV Setup caught up");
                                                    } catch (IOException e5) {
                                                        e = e5;
                                                        if (!tv.noFrame) {
                                                        }
                                                    }
                                                }
                                            } else {
                                                SurfaceScreen surfaceScreen = tv.screen;
                                                if (surfaceScreen != null && !surfaceScreen.feed(false, System.nanoTime() / 1000, bArr)) {
                                                    tv.relayEnd(true, "decoder");
                                                    tv.feedConn = null;
                                                    openSetup.disconnect();
                                                    z = true;
                                                    if (z) {
                                                    }
                                                } else if (!z3) {
                                                    try {
                                                        tv.relaying = true;
                                                        tv.framed = true;
                                                        MainActivity$onCreate$2 mainActivity$onCreate$2 = Census.store;
                                                        String host = tv.host;
                                                        Intrinsics.checkNotNullParameter(host, "host");
                                                        Census.later(new Census$$ExternalSyntheticLambda3(host, 1));
                                                        tv.status("live", "");
                                                        dataInputStream2 = dataInputStream;
                                                        str6 = str4;
                                                        str7 = str5;
                                                        z3 = true;
                                                        httpURLConnection = null;
                                                    } catch (IOException e6) {
                                                        e = e6;
                                                        z3 = true;
                                                        if (!tv.noFrame) {
                                                            WireLog.all.add("·", "picture " + tv.host + " TV Setup sent no picture in 8 s");
                                                            SurfaceScreen surfaceScreen2 = tv.screen;
                                                            if (surfaceScreen2 != null) {
                                                                surfaceScreen2.closeDec();
                                                            }
                                                            if (!tv.stopped) {
                                                                tv.status("error", "TV Setup sent no picture");
                                                            }
                                                            tv.feedConn = null;
                                                            openSetup.disconnect();
                                                            z = true;
                                                            if (z) {
                                                            }
                                                        } else {
                                                            if (!tv.rejoin && !tv.stopped) {
                                                                WireLog.all.add("·", "picture " + tv.host + " TV Setup's stream: " + e);
                                                                if (!z3) {
                                                                    tv.relaying = false;
                                                                    tv.feedConn = null;
                                                                    try {
                                                                        openSetup.disconnect();
                                                                    } catch (Exception unused4) {
                                                                    }
                                                                    z = false;
                                                                    if (z) {
                                                                    }
                                                                }
                                                            }
                                                            tv.feedConn = null;
                                                            openSetup.disconnect();
                                                            if (!tv.rejoin) {
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        } else {
                                            try {
                                                SurfaceScreen surfaceScreen3 = tv.screen;
                                                if (surfaceScreen3 != null) {
                                                    surfaceScreen3.feed(true, j5, bArr);
                                                }
                                            } catch (IOException e7) {
                                                e = e7;
                                                if (!tv.noFrame) {
                                                }
                                            }
                                        }
                                    } else {
                                        ByteBuffer wrap = ByteBuffer.wrap(bArr);
                                        int i4 = wrap.getInt();
                                        int i5 = wrap.getInt();
                                        long j9 = (i4 << 32) | i5;
                                        if (j9 != j6) {
                                            try {
                                                tv.width = i4;
                                                tv.height = i5;
                                                SurfaceScreen surfaceScreen4 = tv.screen;
                                                if (surfaceScreen4 != null) {
                                                    surfaceScreen4.start(i4, i5);
                                                }
                                                tv.listener.onVideoSize(i4, i5);
                                                j6 = j9;
                                                dataInputStream2 = dataInputStream;
                                                str6 = str4;
                                                str7 = str5;
                                                httpURLConnection = null;
                                                j5 = 0;
                                            } catch (IOException e8) {
                                                e = e8;
                                                j6 = j9;
                                                if (!tv.noFrame) {
                                                }
                                            }
                                        }
                                    }
                                    dataInputStream2 = dataInputStream;
                                    str6 = str4;
                                    str7 = str5;
                                    httpURLConnection = null;
                                    j5 = 0;
                                } else {
                                    throw new IOException("bad picture packet");
                                }
                            }
                            str4 = str6;
                            str5 = str7;
                            tv.feedConn = httpURLConnection;
                            openSetup.disconnect();
                            if (!tv.rejoin) {
                                str6 = str4;
                                str7 = str5;
                                z2 = true;
                                j5 = 0;
                            } else {
                                tv.relayEnd(z3, "");
                                if (!z3) {
                                    break;
                                }
                                z = true;
                                if (z) {
                                }
                            }
                        }
                    }
                    tv.relayEnd(z3, "");
                    if (!z3) {
                    }
                    z = true;
                    if (z) {
                    }
                }
                tv.session();
                if (tv.stalled && !tv.stopped) {
                    tv.stalled = false;
                    tv.io = Executors.newSingleThreadExecutor();
                    tv.session();
                    return;
                }
                return;
            case 1:
                Tv tv2 = this.f$0;
                try {
                    Adb adb = tv2.adb;
                    if (adb != null && tv2.quieted) {
                        PrivateListen privateListen = PrivateListen.INSTANCE;
                        Integer intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull(StringsKt.trim(adb.shell(8000L, "dumpsys audio 2>/dev/null | grep -c 'AudioPlaybackConfiguration.*state:started'")).toString());
                        if (intOrNull == null || intOrNull.intValue() <= 0) {
                            z2 = false;
                        }
                        if (z2) {
                            tv2.giveBackSound();
                            tv2.status("audio", "tvloud");
                        }
                    }
                } catch (Exception unused5) {
                } catch (Throwable th3) {
                    tv2.quietChecking = false;
                    throw th3;
                }
                tv2.quietChecking = false;
                return;
            case 2:
                Tv tv3 = this.f$0;
                tv3.getClass();
                ArrayList arrayList = new ArrayList();
                ArrayList arrayList2 = new ArrayList();
                long nanoTime = System.nanoTime();
                Long l2 = 0L;
                long j10 = 0;
                while (true) {
                    int i6 = 0;
                    while (tv3.mouseOn) {
                        synchronized (tv3.mouseLock) {
                            while (tv3.mouseOn && tv3.mouseOut.size() == 0 && tv3.accDx == 0 && tv3.accDy == 0 && tv3.accWheel == 0) {
                                try {
                                    tv3.mouseLock.wait(500L);
                                    j4 = j4;
                                } catch (Throwable th4) {
                                    throw th4;
                                }
                            }
                            j = j4;
                            if (tv3.mouseOn) {
                                while (tv3.mouseOn) {
                                    long currentTimeMillis3 = (8 + j10) - System.currentTimeMillis();
                                    if (currentTimeMillis3 > j) {
                                        tv3.mouseLock.wait(currentTimeMillis3);
                                    } else if (!tv3.mouseOn) {
                                        int i7 = tv3.accDx;
                                        if (i7 == 0 && tv3.accDy == 0 && tv3.accWheel == 0) {
                                            byteArray = tv3.mouseOut.toByteArray();
                                            Intrinsics.checkNotNullExpressionValue(byteArray, "toByteArray(...)");
                                            tv3.mouseOut.reset();
                                        }
                                        Tv.reportsFor(i7, tv3.accDy, tv3.accWheel, tv3.accBtn, tv3.mouseOut);
                                        tv3.accDx = 0;
                                        tv3.accDy = 0;
                                        tv3.accWheel = 0;
                                        byteArray = tv3.mouseOut.toByteArray();
                                        Intrinsics.checkNotNullExpressionValue(byteArray, "toByteArray(...)");
                                        tv3.mouseOut.reset();
                                    } else {
                                        return;
                                    }
                                }
                                if (!tv3.mouseOn) {
                                }
                            } else {
                                return;
                            }
                        }
                        if (byteArray.length == 0) {
                            j4 = j;
                        } else {
                            tv3.mouseHere();
                            long nanoTime2 = System.nanoTime();
                            if (j10 != j) {
                                arrayList2.add(Long.valueOf(System.currentTimeMillis() - j10));
                            }
                            long currentTimeMillis4 = System.currentTimeMillis();
                            i6 += byteArray.length / 9;
                            try {
                                Future send = tv3.send(byteArray);
                                if (send != null) {
                                    send.get(3L, TimeUnit.SECONDS);
                                }
                            } catch (Exception unused6) {
                            }
                            arrayList.add(Long.valueOf((System.nanoTime() - nanoTime2) / 1000000));
                            ApkCert$$ExternalSyntheticLambda0 apkCert$$ExternalSyntheticLambda0 = tv3.mouseStats;
                            if (apkCert$$ExternalSyntheticLambda0 != null && System.nanoTime() - nanoTime > 1000000000) {
                                CollectionsKt__MutableCollectionsJVMKt.sort(arrayList);
                                CollectionsKt__MutableCollectionsJVMKt.sort(arrayList2);
                                int size = arrayList.size();
                                Object obj3 = arrayList.get(arrayList.size() / 2);
                                Object obj4 = arrayList.get((arrayList.size() * 95) / 100);
                                Object last = CollectionsKt.last(arrayList);
                                int size2 = arrayList2.size() / 2;
                                if (size2 >= 0 && size2 < arrayList2.size()) {
                                    obj = arrayList2.get(size2);
                                } else {
                                    obj = l2;
                                }
                                int size3 = (arrayList2.size() * 95) / 100;
                                if (size3 >= 0 && size3 < arrayList2.size()) {
                                    obj2 = arrayList2.get(size3);
                                } else {
                                    obj2 = l2;
                                }
                                Long l3 = (Long) CollectionsKt.lastOrNull(arrayList2);
                                if (l3 != null) {
                                    long longValue = l3.longValue();
                                    l = l2;
                                    j2 = currentTimeMillis4;
                                    j3 = longValue;
                                } else {
                                    l = l2;
                                    j2 = currentTimeMillis4;
                                    j3 = j;
                                }
                                apkCert$$ExternalSyntheticLambda0.invoke("reports=" + i6 + " writes=" + size + " write_ms p50=" + obj3 + " p95=" + obj4 + " max=" + last + " gap_ms p50=" + obj + " p95=" + obj2 + " max=" + j3);
                                arrayList.clear();
                                arrayList2.clear();
                                nanoTime = System.nanoTime();
                                l2 = l;
                                j4 = j;
                                j10 = j2;
                                tv3 = tv3;
                            } else {
                                Tv tv4 = tv3;
                                Long l4 = l2;
                                if (apkCert$$ExternalSyntheticLambda0 == null && arrayList.size() > 2000) {
                                    arrayList.clear();
                                    arrayList2.clear();
                                }
                                l2 = l4;
                                j4 = j;
                                j10 = currentTimeMillis4;
                                tv3 = tv4;
                            }
                        }
                    }
                    return;
                }
            default:
                try {
                    this.f$0.resetVideo();
                    return;
                } catch (Exception unused7) {
                    return;
                }
        }
    }
}
