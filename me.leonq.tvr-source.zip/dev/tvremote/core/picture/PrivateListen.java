package dev.tvremote.core.picture;

import dev.tvremote.core.Fleet$$ExternalSyntheticLambda0;
import dev.tvremote.core.scenes.Scenes;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;

/* loaded from: classes.dex */
public final class PrivateListen {
    public static final PrivateListen INSTANCE = new Object();
    public static final AtomicInteger holders = new AtomicInteger();

    public static boolean engage(Fleet$$ExternalSyntheticLambda0 fleet$$ExternalSyntheticLambda0) {
        Integer left = left((String) fleet$$ExternalSyntheticLambda0.invoke("cat /data/local/tmp/tvr-listen-vol 2>/dev/null"));
        Integer level = level(fleet$$ExternalSyntheticLambda0);
        if (level != null) {
            int intValue = level.intValue();
            if (left != null) {
                intValue = left.intValue();
            }
            if (intValue == 0) {
                return true;
            }
            fleet$$ExternalSyntheticLambda0.invoke("echo " + intValue + " > /data/local/tmp/tvr-listen-vol");
            try {
                HashMap hashMap = Scenes.KEYS;
                Scenes.volume(fleet$$ExternalSyntheticLambda0, 0, 3);
                Integer level2 = level(fleet$$ExternalSyntheticLambda0);
                if (level2 != null) {
                    if (level2.intValue() == 0) {
                        holders.incrementAndGet();
                        return true;
                    }
                }
            } catch (Exception unused) {
            }
            try {
                HashMap hashMap2 = Scenes.KEYS;
                Scenes.volume(fleet$$ExternalSyntheticLambda0, intValue, 3);
            } catch (Exception unused2) {
            }
            fleet$$ExternalSyntheticLambda0.invoke("rm -f /data/local/tmp/tvr-listen-vol");
        }
        return false;
    }

    public static Integer left(String text) {
        int intValue;
        Intrinsics.checkNotNullParameter(text, "text");
        Integer intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull(StringsKt.trim(text).toString());
        if (intOrNull != null && (intValue = intOrNull.intValue()) >= 0 && intValue < 1001) {
            return intOrNull;
        }
        return null;
    }

    public static Integer level(Function1 function1) {
        String str;
        Pattern compile = Pattern.compile("volume is (\\d+)");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        CharSequence input = (CharSequence) function1.invoke("cmd media_session volume --stream 3 --get 2>&1");
        Intrinsics.checkNotNullParameter(input, "input");
        Matcher matcher = compile.matcher(input);
        Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
        MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, input);
        if (access$findNext != null && (str = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)) != null) {
            return StringsKt__StringNumberConversionsKt.toIntOrNull(str);
        }
        return null;
    }

    public static void putBack(Function1 function1, Integer num) {
        if (num == null) {
            return;
        }
        Integer level = level(function1);
        if (num.intValue() <= 0 || level == null || level.intValue() != 0) {
            num = null;
        }
        if (num != null) {
            HashMap hashMap = Scenes.KEYS;
            Scenes.volume(function1, num.intValue(), 3);
        }
        function1.invoke("rm -f /data/local/tmp/tvr-listen-vol");
    }

    public static void release$default(Fleet$$ExternalSyntheticLambda0 fleet$$ExternalSyntheticLambda0) {
        synchronized (INSTANCE) {
            AtomicInteger atomicInteger = holders;
            if (atomicInteger.get() > 0) {
                atomicInteger.decrementAndGet();
            }
        }
        putBack(fleet$$ExternalSyntheticLambda0, left((String) fleet$$ExternalSyntheticLambda0.invoke("cat /data/local/tmp/tvr-listen-vol 2>/dev/null")));
    }
}
