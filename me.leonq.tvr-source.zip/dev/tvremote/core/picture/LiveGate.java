package dev.tvremote.core.picture;

import kotlin.collections.ArrayDeque;

/* loaded from: classes.dex */
public final class LiveGate {
    public int catchUps;
    public int run;
    public boolean skipping;
    public final ArrayDeque inside = new ArrayDeque();
    public long askedAt = -2000;

    /* loaded from: classes.dex */
    public final class In {
        public final long at;
        public final long pts;

        public In(long j, long j2) {
            this.pts = j;
            this.at = j2;
        }
    }

    public final synchronized void fed(long j, long j2) {
        this.inside.addLast(new In(j, j2));
    }

    public final synchronized boolean lagged(long j) {
        boolean z;
        if (!this.inside.isEmpty()) {
            if (j - ((In) this.inside.first()).at >= 600) {
                z = true;
            }
        }
        z = false;
        return z;
    }

    public final synchronized boolean wantKey(long j) {
        boolean z;
        boolean z2;
        z = false;
        if (this.skipping) {
            if (j - this.askedAt < 2000) {
                z2 = false;
            } else {
                this.askedAt = j;
                z2 = true;
            }
            if (z2) {
                z = true;
            }
        }
        return z;
    }
}
