package dev.tvremote.core.picture;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.Writer;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class Trace {
    public static final Trace INSTANCE = new Object();
    public static final PrintWriter out;

    /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.Object, dev.tvremote.core.picture.Trace] */
    static {
        String str = System.getenv("TVR_TRACE");
        PrintWriter printWriter = null;
        if (str != null) {
            if (str.length() <= 0) {
                str = null;
            }
            if (str != null) {
                printWriter = new PrintWriter((Writer) new BufferedWriter(new FileWriter(new File(str), true)), true);
            }
        }
        out = printWriter;
    }

    public static boolean getOn() {
        if (out != null) {
            return true;
        }
        return false;
    }

    public final synchronized void log(String str, String fields) {
        Intrinsics.checkNotNullParameter(fields, "fields");
        PrintWriter printWriter = out;
        if (printWriter != null) {
            printWriter.println(System.currentTimeMillis() + " " + str + " " + fields);
        }
    }
}
