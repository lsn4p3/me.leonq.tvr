package dev.tvremote.core.picture;

import dev.tvremote.core.adb.Adb;
import java.io.IOException;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;

/* loaded from: classes.dex */
public final /* synthetic */ class Tv$$ExternalSyntheticLambda15 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Tv f$0;
    public final /* synthetic */ Adb.Stream f$1;

    public /* synthetic */ Tv$$ExternalSyntheticLambda15(Tv tv, Adb.Stream stream, int i) {
        this.$r8$classId = i;
        this.f$0 = tv;
        this.f$1 = stream;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.$r8$classId) {
            case 0:
                try {
                    this.f$0.deviceMessages(this.f$1);
                    return;
                } catch (IOException unused) {
                    return;
                }
            default:
                Tv tv = this.f$0;
                Adb.Stream stream = this.f$1;
                while (!tv.stopped) {
                    try {
                        byte[] bytes = "\n".getBytes(Charsets.UTF_8);
                        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                        stream.write(bytes);
                        Thread.sleep(8000L);
                    } catch (Exception unused2) {
                        return;
                    }
                }
                return;
        }
    }
}
