package dev.tvremote.core.picture;

import android.media.MediaCodec;
import android.media.MediaCrypto;
import android.media.MediaFormat;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.SystemClock;
import android.util.Log;
import android.view.Surface;
import dev.tvremote.core.Census;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.WireLog;
import dev.tvremote.core.ontv.Setup$$ExternalSyntheticLambda5;
import dev.tvremote.core.picture.LiveGate;
import dev.tvremote.phone.media.PlayingBar$$ExternalSyntheticLambda13;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.EmptyMap;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class SurfaceScreen {
    public volatile PlayingBar$$ExternalSyntheticLambda13 askKey;
    public volatile boolean away;
    public volatile boolean broken;
    public byte[] config;
    public final boolean debug;
    public volatile Census.Ok dec;
    public volatile boolean failed;
    public final LiveGate gate;
    public int h;
    public final String host;
    public int ins;
    public int mode;
    public volatile Setup$$ExternalSyntheticLambda5 onFail;
    public volatile int outs;
    public String spsSaid;
    public final LatencyStats stats;
    public final Surface surface;
    public final boolean verbose;
    public int w;

    /* JADX WARN: Type inference failed for: r3v2, types: [dev.tvremote.core.picture.LatencyStats, java.lang.Object] */
    public SurfaceScreen(Surface surface, String host) {
        Intrinsics.checkNotNullParameter(surface, "surface");
        Intrinsics.checkNotNullParameter(host, "host");
        this.surface = surface;
        this.host = host;
        this.gate = new LiveGate();
        ?? obj = new Object();
        obj.from = -1L;
        this.stats = obj;
        this.debug = Log.isLoggable("TvrPic", 3);
        this.verbose = Log.isLoggable("TvrPic", 2);
        this.spsSaid = "";
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v6, types: [android.media.MediaCodec$Callback, dev.tvremote.core.picture.SurfaceScreen$build$cb$1] */
    public final Census.Ok build(boolean z) {
        MediaCodec createDecoderByType;
        boolean z2;
        Map map;
        if (this.mode >= 2) {
            String[] strArr = {"c2.android.avc.decoder", "OMX.google.h264.decoder"};
            int i = 0;
            while (true) {
                if (i < 2) {
                    try {
                        createDecoderByType = MediaCodec.createByCodecName(strArr[i]);
                        Intrinsics.checkNotNullExpressionValue(createDecoderByType, "createByCodecName(...)");
                        break;
                    } catch (Exception unused) {
                        i++;
                    }
                } else {
                    createDecoderByType = MediaCodec.createDecoderByType("video/avc");
                    Intrinsics.checkNotNullExpressionValue(createDecoderByType, "createDecoderByType(...)");
                    break;
                }
            }
        } else {
            createDecoderByType = MediaCodec.createDecoderByType("video/avc");
            Intrinsics.checkNotNullExpressionValue(createDecoderByType, "createDecoderByType(...)");
        }
        HandlerThread handlerThread = new HandlerThread("tvr-decode");
        try {
            int i2 = Build.VERSION.SDK_INT;
            if (i2 >= 30 && createDecoderByType.getCodecInfo().getCapabilitiesForType("video/avc").isFeatureSupported("low-latency")) {
                z2 = true;
            } else {
                z2 = false;
            }
            if (this.mode > 0) {
                map = EmptyMap.INSTANCE;
            } else {
                LinkedHashMap linkedHashMap = new LinkedHashMap();
                if (i2 >= 30 && z2) {
                    linkedHashMap.put("low-latency", 1);
                }
                if (i2 >= 23) {
                    linkedHashMap.put("priority", 0);
                    linkedHashMap.put("operating-rate", 32767);
                }
                if (z) {
                    linkedHashMap.put("vendor.qti-ext-dec-picture-order.enable", 1);
                    linkedHashMap.put("vendor.qti-ext-dec-low-latency.enable", 1);
                    linkedHashMap.put("vendor.rtc-ext-dec-low-latency.enable", 1);
                }
                map = linkedHashMap;
            }
            MediaFormat createVideoFormat = MediaFormat.createVideoFormat("video/avc", this.w, this.h);
            Intrinsics.checkNotNullExpressionValue(createVideoFormat, "createVideoFormat(...)");
            createVideoFormat.setInteger("max-input-size", 2097152);
            for (Map.Entry entry : map.entrySet()) {
                createVideoFormat.setInteger((String) entry.getKey(), ((Number) entry.getValue()).intValue());
            }
            handlerThread.start();
            final Census.Ok ok = new Census.Ok(createDecoderByType, handlerThread);
            ?? r4 = new MediaCodec.Callback() { // from class: dev.tvremote.core.picture.SurfaceScreen$build$cb$1
                @Override // android.media.MediaCodec.Callback
                public final void onError(MediaCodec codec, MediaCodec.CodecException e) {
                    Intrinsics.checkNotNullParameter(codec, "codec");
                    Intrinsics.checkNotNullParameter(e, "e");
                    Log.w("TvrPic", "decoder error: " + e);
                    WireLog wireLog = WireLog.all;
                    WireLog.all.add("·", Census$$ExternalSyntheticOutline0.m("picture ", this.host, " decoder error ", e.getDiagnosticInfo()));
                    if (this.dec == Census.Ok.this) {
                        this.broken = true;
                    }
                }

                @Override // android.media.MediaCodec.Callback
                public final void onInputBufferAvailable(MediaCodec codec, int i3) {
                    Intrinsics.checkNotNullParameter(codec, "codec");
                    ((LinkedBlockingQueue) Census.Ok.this.optimize).add(Integer.valueOf(i3));
                }

                /* JADX WARN: Removed duplicated region for block: B:32:0x0092  */
                /* JADX WARN: Removed duplicated region for block: B:57:0x0093 A[Catch: all -> 0x0055, TryCatch #0 {all -> 0x0055, blocks: (B:9:0x0034, B:11:0x003c, B:13:0x004a, B:17:0x005e, B:19:0x0066, B:23:0x0079, B:27:0x0087, B:33:0x0096, B:57:0x0093, B:59:0x0076), top: B:8:0x0034 }] */
                @Override // android.media.MediaCodec.Callback
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                */
                public final void onOutputBufferAvailable(MediaCodec codec, int i3, MediaCodec.BufferInfo info) {
                    long j;
                    boolean z3;
                    String out;
                    String str;
                    Intrinsics.checkNotNullParameter(codec, "codec");
                    Intrinsics.checkNotNullParameter(info, "info");
                    SurfaceScreen surfaceScreen = this;
                    Census.Ok ok2 = Census.Ok.this;
                    int i4 = 0;
                    if (ok2 == surfaceScreen.dec && (info.flags & 4) == 0) {
                        surfaceScreen.outs++;
                        long elapsedRealtime = SystemClock.elapsedRealtime();
                        LiveGate liveGate = surfaceScreen.gate;
                        long j2 = info.presentationTimeUs;
                        synchronized (liveGate) {
                            long j3 = -1;
                            while (!liveGate.inside.isEmpty() && ((LiveGate.In) liveGate.inside.first()).pts <= j2) {
                                try {
                                    j3 = ((LiveGate.In) liveGate.inside.removeFirst()).at;
                                } catch (Throwable th) {
                                    throw th;
                                }
                            }
                            long j4 = 0;
                            if (j3 < 0 && !liveGate.inside.isEmpty()) {
                                j3 = ((LiveGate.In) liveGate.inside.removeFirst()).at;
                            }
                            if (j3 >= 0) {
                                j4 = elapsedRealtime - j3;
                            }
                            j = j4;
                            if (!liveGate.inside.isEmpty() && j >= 70 && liveGate.run < 3) {
                                z3 = false;
                                if (z3) {
                                    i4 = liveGate.run + 1;
                                }
                                liveGate.run = i4;
                            }
                            z3 = true;
                            if (z3) {
                            }
                            liveGate.run = i4;
                        }
                        try {
                            ((MediaCodec) ok2.adb).releaseOutputBuffer(i3, z3);
                            if (surfaceScreen.verbose) {
                                long j5 = info.presentationTimeUs;
                                if (z3) {
                                    str = "drawn";
                                } else {
                                    str = "skipped";
                                }
                                Log.v("TvrPic", "pts=" + j5 + " age=" + j + "ms " + str);
                            }
                            if (surfaceScreen.debug && (out = surfaceScreen.stats.out(j, z3, elapsedRealtime, surfaceScreen.gate.catchUps)) != null) {
                                Log.d("TvrPic", out);
                                return;
                            }
                            return;
                        } catch (IllegalStateException | Exception unused2) {
                            return;
                        }
                    }
                    ((MediaCodec) ok2.adb).releaseOutputBuffer(i3, false);
                }

                @Override // android.media.MediaCodec.Callback
                public final void onOutputFormatChanged(MediaCodec codec, MediaFormat format) {
                    Intrinsics.checkNotNullParameter(codec, "codec");
                    Intrinsics.checkNotNullParameter(format, "format");
                }
            };
            if (Build.VERSION.SDK_INT >= 23) {
                createDecoderByType.setCallback(r4, new Handler(handlerThread.getLooper()));
            } else {
                createDecoderByType.setCallback(r4);
            }
            createDecoderByType.configure(createVideoFormat, this.surface, (MediaCrypto) null, 0);
            createDecoderByType.start();
            if (this.debug) {
                Log.d("TvrPic", "decoder " + createDecoderByType.getName() + " lowLatencySupported=" + z2 + " keys=" + map);
            }
            return ok;
        } catch (Exception e) {
            try {
                createDecoderByType.release();
            } catch (Exception unused2) {
            }
            handlerThread.quitSafely();
            throw e;
        }
    }

    public final void catchUp(long j) {
        SurfaceScreen surfaceScreen;
        PlayingBar$$ExternalSyntheticLambda13 playingBar$$ExternalSyntheticLambda13;
        Integer num;
        if (this.debug) {
            Log.d("TvrPic", "catch up: decoder made again");
        }
        closeDec();
        boolean z = true;
        try {
            open();
            Census.Ok ok = this.dec;
            byte[] bArr = this.config;
            if (ok != null && bArr != null && (num = (Integer) ((LinkedBlockingQueue) ok.optimize).poll(1000L, TimeUnit.MILLISECONDS)) != null) {
                surfaceScreen = this;
                surfaceScreen.queue(ok, num.intValue(), bArr, 0L, true);
            } else {
                surfaceScreen = this;
            }
            LiveGate liveGate = surfaceScreen.gate;
            synchronized (liveGate) {
                liveGate.inside.clear();
                liveGate.run = 0;
                liveGate.skipping = true;
                liveGate.catchUps++;
                if (j - liveGate.askedAt < 2000) {
                    z = false;
                } else {
                    liveGate.askedAt = j;
                }
            }
            if (z && (playingBar$$ExternalSyntheticLambda13 = surfaceScreen.askKey) != null) {
                playingBar$$ExternalSyntheticLambda13.invoke();
            }
        } catch (Exception e) {
            Log.w("TvrPic", "decoder not made again: " + e);
            WireLog wireLog = WireLog.all;
            WireLog.all.add("·", "picture " + this.host + " decoder not made again: " + e);
            if (!this.failed) {
                this.failed = true;
                Setup$$ExternalSyntheticLambda5 setup$$ExternalSyntheticLambda5 = this.onFail;
                if (setup$$ExternalSyntheticLambda5 != null) {
                    setup$$ExternalSyntheticLambda5.invoke();
                }
            }
        }
    }

    public final synchronized void closeDec() {
        Census.Ok ok = this.dec;
        if (ok == null) {
            return;
        }
        this.dec = null;
        try {
            ((MediaCodec) ok.adb).stop();
        } catch (Exception unused) {
        }
        try {
            ((MediaCodec) ok.adb).release();
        } catch (Exception unused2) {
        }
        ((HandlerThread) ok.video).quitSafely();
    }

    /* JADX WARN: Removed duplicated region for block: B:41:0x0144  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean feed(boolean z, long j, byte[] bArr) {
        Pair pair;
        int length;
        Pair pair2;
        byte[] bArr2;
        boolean z2;
        PlayingBar$$ExternalSyntheticLambda13 playingBar$$ExternalSyntheticLambda13;
        int i;
        String str;
        byte[] bArr3 = bArr;
        if (z) {
            ArrayList arrayList = new ArrayList();
            int i2 = 0;
            while (true) {
                int i3 = i2 + 3;
                if (i3 > bArr3.length) {
                    break;
                }
                if (bArr3[i2] == 0 && bArr3[i2 + 1] == 0 && bArr3[i2 + 2] == 1) {
                    arrayList.add(Integer.valueOf(i3));
                    i2 = i3;
                } else {
                    i2++;
                }
            }
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(bArr3.length + 8);
            Iterator it = arrayList.iterator();
            String str2 = "";
            boolean z3 = false;
            int i4 = 0;
            int i5 = 0;
            while (it.hasNext()) {
                i4++;
                int intValue = ((Number) it.next()).intValue();
                if (i4 < arrayList.size()) {
                    length = ((Number) arrayList.get(i4)).intValue() - 3;
                } else {
                    length = bArr3.length;
                }
                if (i4 < arrayList.size() && length > intValue && bArr3[length - 1] == 0) {
                    length--;
                }
                if (intValue < bArr3.length && (bArr3[intValue] & 31) == 7) {
                    try {
                        Set set = Sps.HIGH;
                        pair2 = Sps.restrict(ArraysKt.copyOfRange(bArr3, intValue, length));
                    } catch (RuntimeException unused) {
                        pair2 = null;
                    }
                    if (pair2 == null || (str2 = (String) pair2.second) == null) {
                        str2 = "sps unread";
                    }
                    if (pair2 != null && (bArr2 = (byte[]) pair2.first) != null) {
                        byteArrayOutputStream.write(bArr3, i5, intValue - i5);
                        byteArrayOutputStream.write(bArr2);
                        i5 = length;
                        z3 = true;
                    }
                }
            }
            if (!z3) {
                pair = new Pair(bArr3, str2);
            } else {
                byteArrayOutputStream.write(bArr3, i5, bArr3.length - i5);
                pair = new Pair(byteArrayOutputStream.toByteArray(), str2);
            }
            bArr3 = (byte[]) pair.first;
            String str3 = (String) pair.second;
            if (!Intrinsics.areEqual(str3, this.spsSaid)) {
                this.spsSaid = str3;
                WireLog.all.add("·", Census$$ExternalSyntheticOutline0.m("picture ", this.host, " ", str3));
            }
        }
        byte[] d = bArr3;
        if (z) {
            this.config = d;
        }
        if (!this.away) {
            if (!this.failed) {
                long elapsedRealtime = SystemClock.elapsedRealtime();
                if (this.broken || (!z && this.gate.lagged(elapsedRealtime))) {
                    catchUp(elapsedRealtime);
                }
                LiveGate liveGate = this.gate;
                if (!z) {
                    Intrinsics.checkNotNullParameter(d, "d");
                    int i6 = 0;
                    while (true) {
                        int i7 = i6 + 3;
                        if (i7 < d.length) {
                            if (d[i6] == 0 && d[i6 + 1] == 0 && d[i6 + 2] == 1) {
                                int i8 = d[i7] & 31;
                                if (i8 == 1) {
                                    break;
                                }
                                if (i8 != 5) {
                                    i6 = i7;
                                } else {
                                    z2 = true;
                                    break;
                                }
                            } else {
                                i6++;
                            }
                        } else {
                            break;
                        }
                    }
                    synchronized (liveGate) {
                        if (!z) {
                            if (liveGate.skipping && !z2) {
                                if (this.gate.wantKey(elapsedRealtime) && (playingBar$$ExternalSyntheticLambda13 = this.askKey) != null) {
                                    playingBar$$ExternalSyntheticLambda13.invoke();
                                }
                            } else if (z2) {
                                liveGate.skipping = false;
                            }
                        }
                        Census.Ok ok = this.dec;
                        if (ok == null) {
                            return !this.failed;
                        }
                        long j2 = elapsedRealtime;
                        int i9 = -1;
                        while (i9 < 0) {
                            Integer num = (Integer) ((LinkedBlockingQueue) ok.optimize).poll(20L, TimeUnit.MILLISECONDS);
                            if (num != null) {
                                i9 = num.intValue();
                            } else {
                                i9 = -1;
                            }
                            if (i9 >= 0) {
                                break;
                            }
                            if (this.dec != ok) {
                                break;
                            }
                            j2 = SystemClock.elapsedRealtime();
                            if (!z && this.gate.lagged(j2)) {
                                catchUp(j2);
                                return true;
                            }
                            if (j2 - elapsedRealtime > 10000) {
                            }
                        }
                        if (queue(ok, i9, d, j, z) && !z) {
                            this.gate.fed(j, j2);
                            this.stats.fed();
                            int i10 = this.ins + 1;
                            this.ins = i10;
                            if (i10 >= 30 && this.outs == 0 && (i = this.mode) < 2) {
                                this.mode = i + 1;
                                this.ins = 0;
                                this.outs = 0;
                                WireLog wireLog = WireLog.all;
                                String str4 = this.host;
                                Census.Ok ok2 = this.dec;
                                if (ok2 != null) {
                                    str = ((MediaCodec) ok2.adb).getName();
                                } else {
                                    str = null;
                                }
                                wireLog.add("·", Census$$ExternalSyntheticOutline0.m("picture ", str4, " no frame out of ", str, ": trying a plainer decoder"));
                                catchUp(SystemClock.elapsedRealtime());
                            }
                        }
                    }
                }
                z2 = false;
                synchronized (liveGate) {
                }
            }
            return false;
        }
        return true;
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x0056  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0044 A[Catch: all -> 0x0011, TryCatch #0 {, blocks: (B:4:0x0007, B:6:0x000c, B:7:0x002c, B:9:0x0044, B:10:0x0058, B:18:0x0014, B:21:0x001a), top: B:3:0x0007, inners: #1 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final synchronized void open() {
        Census.Ok build;
        int i;
        String str;
        if (this.mode <= 0) {
            try {
                build = build(true);
            } catch (Exception e) {
                Log.w("TvrPic", "decoder without vendor keys: " + e);
            }
            this.dec = build;
            this.broken = false;
            WireLog wireLog = WireLog.all;
            WireLog wireLog2 = WireLog.all;
            String str2 = this.host;
            String name = ((MediaCodec) build.adb).getName();
            i = this.mode;
            if (i <= 0) {
                str = " (plain " + i + ")";
            } else {
                str = "";
            }
            wireLog2.add("·", "picture " + str2 + " decoder " + name + str);
        }
        build = build(false);
        this.dec = build;
        this.broken = false;
        WireLog wireLog3 = WireLog.all;
        WireLog wireLog22 = WireLog.all;
        String str22 = this.host;
        String name2 = ((MediaCodec) build.adb).getName();
        i = this.mode;
        if (i <= 0) {
        }
        wireLog22.add("·", "picture " + str22 + " decoder " + name2 + str);
    }

    public final boolean queue(Census.Ok ok, int i, byte[] bArr, long j, boolean z) {
        int i2;
        try {
            ByteBuffer inputBuffer = ((MediaCodec) ok.adb).getInputBuffer(i);
            Intrinsics.checkNotNull(inputBuffer);
            inputBuffer.clear();
            inputBuffer.put(bArr);
            MediaCodec mediaCodec = (MediaCodec) ok.adb;
            int length = bArr.length;
            if (z) {
                i2 = 2;
            } else {
                i2 = 0;
            }
            mediaCodec.queueInputBuffer(i, 0, length, j, i2);
            return true;
        } catch (RuntimeException e) {
            Log.w("TvrPic", "queue failed: " + e);
            this.broken = true;
            return false;
        }
    }

    public final void start(int i, int i2) {
        closeDec();
        this.w = i;
        this.h = i2;
        LiveGate liveGate = this.gate;
        synchronized (liveGate) {
            liveGate.inside.clear();
            liveGate.run = 0;
            liveGate.skipping = false;
        }
        this.ins = 0;
        this.outs = 0;
        this.failed = false;
        if (!this.away) {
            open();
        }
    }
}
