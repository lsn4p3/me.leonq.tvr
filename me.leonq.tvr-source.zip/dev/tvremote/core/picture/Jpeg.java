package dev.tvremote.core.picture;

import dev.tvremote.core.picture.JpegDecode;
import dev.tvremote.core.picture.Sps;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.zip.Inflater;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Charsets;
import org.conscrypt.PSKKeyManager;

/* loaded from: classes.dex */
public abstract class Jpeg {
    public static final Pair AC;
    public static final int[] AC_BITS;
    public static final int[] AC_VALS;
    public static final double[][] COS;
    public static final Pair DC;
    public static final int[] DC_VALS;
    public static final int[] ZIG = {0, 1, 8, 16, 9, 2, 3, 10, 17, 24, 32, 25, 18, 11, 4, 5, 12, 19, 26, 33, 40, 48, 41, 34, 27, 20, 13, 6, 7, 14, 21, 28, 35, 42, 49, 56, 57, 50, 43, 36, 29, 22, 15, 23, 30, 37, 44, 51, 58, 59, 52, 45, 38, 31, 39, 46, 53, 60, 61, 54, 47, 55, 62, 63};
    public static final int[] QBASE = {16, 11, 10, 16, 24, 40, 51, 61, 12, 12, 14, 19, 26, 58, 60, 55, 14, 13, 16, 24, 40, 57, 69, 56, 14, 17, 22, 29, 51, 87, 80, 62, 18, 22, 37, 56, 68, 109, 103, 77, 24, 35, 55, 64, 81, 104, 113, 92, 49, 64, 78, 87, 103, 121, 120, 101, 72, 92, 95, 98, 112, 100, 103, 99};
    public static final int[] DC_BITS = {0, 1, 5, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0};

    static {
        double d;
        int[] iArr = new int[12];
        for (int i = 0; i < 12; i++) {
            iArr[i] = i;
        }
        DC_VALS = iArr;
        AC_BITS = new int[]{0, 2, 1, 3, 3, 2, 4, 3, 5, 5, 4, 4, 0, 0, 1, 125};
        AC_VALS = new int[]{1, 2, 3, 0, 4, 17, 5, 18, 33, 49, 65, 6, 19, 81, 97, 7, 34, 113, 20, 50, 129, 145, 161, 8, 35, 66, 177, 193, 21, 82, 209, 240, 36, 51, 98, 114, 130, 9, 10, 22, 23, 24, 25, 26, 37, 38, 39, 40, 41, 42, 52, 53, 54, 55, 56, 57, 58, 67, 68, 69, 70, 71, 72, 73, 74, 83, 84, 85, 86, 87, 88, 89, 90, 99, 100, 101, 102, 103, 104, 105, 106, 115, 116, 117, 118, 119, 120, 121, 122, 131, 132, 133, 134, 135, 136, 137, 138, 146, 147, 148, 149, 150, 151, 152, 153, 154, 162, 163, 164, 165, 166, 167, 168, 169, 170, 178, 179, 180, 181, 182, 183, 184, 185, 186, 194, 195, 196, 197, 198, 199, 200, 201, 202, 210, 211, 212, 213, 214, 215, 216, 217, 218, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250};
        double[][] dArr = new double[8];
        for (int i2 = 0; i2 < 8; i2++) {
            double[] dArr2 = new double[8];
            for (int i3 = 0; i3 < 8; i3++) {
                if (i2 == 0) {
                    d = Math.sqrt(0.125d);
                } else {
                    d = 0.5d;
                }
                dArr2[i3] = Math.cos(((((i3 * 2) + 1) * i2) * 3.141592653589793d) / 16) * d;
            }
            dArr[i2] = dArr2;
        }
        COS = dArr;
        DC = codes(DC_BITS, DC_VALS);
        AC = codes(AC_BITS, AC_VALS);
    }

    public static Pair codes(int[] iArr, int[] iArr2) {
        int[] iArr3 = new int[PSKKeyManager.MAX_KEY_LENGTH_BYTES];
        int[] iArr4 = new int[PSKKeyManager.MAX_KEY_LENGTH_BYTES];
        int i = 0;
        int i2 = 0;
        for (int i3 = 1; i3 < 17; i3++) {
            int i4 = iArr[i3 - 1];
            for (int i5 = 0; i5 < i4; i5++) {
                iArr3[iArr2[i2]] = i;
                iArr4[iArr2[i2]] = i3;
                i++;
                i2++;
            }
            i <<= 1;
        }
        return new Pair(iArr3, iArr4);
    }

    public static byte[] encode(int i, int i2, int i3, byte[] bArr) {
        int i4;
        int[] iArr;
        double[][] dArr;
        Pair pair;
        int i5;
        int i6;
        double d;
        int i7 = i;
        byte[] rgb = bArr;
        Intrinsics.checkNotNullParameter(rgb, "rgb");
        if (i3 < 50) {
            i4 = 5000 / i3;
        } else {
            i4 = 200 - (i3 * 2);
        }
        int[] iArr2 = new int[64];
        int i8 = 0;
        for (int i9 = 0; i9 < 64; i9++) {
            iArr2[i9] = MathKt.coerceIn(((QBASE[i9] * i4) + 50) / 100, 1, 255);
        }
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byteArrayOutputStream.write(255);
        byteArrayOutputStream.write(216);
        byteArrayOutputStream.write(255);
        byteArrayOutputStream.write(219);
        encode$w16(byteArrayOutputStream, 67);
        byteArrayOutputStream.write(0);
        int i10 = 0;
        while (true) {
            iArr = ZIG;
            if (i10 >= 64) {
                break;
            }
            byteArrayOutputStream.write(iArr2[iArr[i10]]);
            i10++;
        }
        byteArrayOutputStream.write(255);
        byteArrayOutputStream.write(192);
        encode$w16(byteArrayOutputStream, 17);
        byteArrayOutputStream.write(8);
        encode$w16(byteArrayOutputStream, i2);
        encode$w16(byteArrayOutputStream, i7);
        int i11 = 3;
        byteArrayOutputStream.write(3);
        for (int i12 = 1; i12 < 4; i12++) {
            byteArrayOutputStream.write(i12);
            byteArrayOutputStream.write(17);
            byteArrayOutputStream.write(0);
        }
        byteArrayOutputStream.write(255);
        byteArrayOutputStream.write(196);
        encode$w16(byteArrayOutputStream, 31);
        byteArrayOutputStream.write(0);
        int[] iArr3 = DC_BITS;
        for (int i13 = 0; i13 < 16; i13++) {
            byteArrayOutputStream.write(iArr3[i13]);
        }
        int[] iArr4 = DC_VALS;
        for (int i14 = 0; i14 < 12; i14++) {
            byteArrayOutputStream.write(iArr4[i14]);
        }
        byteArrayOutputStream.write(255);
        byteArrayOutputStream.write(196);
        encode$w16(byteArrayOutputStream, 181);
        byteArrayOutputStream.write(16);
        int[] iArr5 = AC_BITS;
        for (int i15 = 0; i15 < 16; i15++) {
            byteArrayOutputStream.write(iArr5[i15]);
        }
        int[] iArr6 = AC_VALS;
        for (int i16 = 0; i16 < 162; i16++) {
            byteArrayOutputStream.write(iArr6[i16]);
        }
        byteArrayOutputStream.write(255);
        byteArrayOutputStream.write(218);
        encode$w16(byteArrayOutputStream, 12);
        byteArrayOutputStream.write(3);
        for (int i17 = 1; i17 < 4; i17++) {
            byteArrayOutputStream.write(i17);
            byteArrayOutputStream.write(0);
        }
        byteArrayOutputStream.write(0);
        byteArrayOutputStream.write(63);
        byteArrayOutputStream.write(0);
        Sps.Out out = new Sps.Out(1);
        int[] iArr7 = new int[3];
        double[] dArr2 = new double[64];
        double[] dArr3 = new double[64];
        int[] iArr8 = new int[64];
        int i18 = (i2 + 7) / 8;
        while (i8 < i18) {
            int i19 = (i7 + 7) / 8;
            int i20 = 0;
            while (i20 < i19) {
                int i21 = 0;
                while (i21 < i11) {
                    int i22 = 0;
                    while (true) {
                        if (i22 >= 8) {
                            break;
                        }
                        int i23 = i22;
                        int i24 = 0;
                        for (int i25 = 8; i24 < i25; i25 = 8) {
                            int i26 = i24;
                            int min = ((Math.min((i8 * 8) + i23, i2 - 1) * i) + Math.min((i20 * 8) + i24, i - 1)) * 3;
                            int i27 = rgb[min] & 255;
                            int i28 = i19;
                            int i29 = rgb[min + 1] & 255;
                            int i30 = bArr[min + 2] & 255;
                            int i31 = (i23 * 8) + i26;
                            if (i21 != 0) {
                                i6 = i31;
                                if (i21 != 1) {
                                    i5 = i21;
                                    d = ((i27 * 0.5d) - (i29 * 0.418688d)) - (i30 * 0.081312d);
                                } else {
                                    i5 = i21;
                                    d = ((i27 * (-0.168736d)) - (i29 * 0.331264d)) + (i30 * 0.5d);
                                }
                            } else {
                                i5 = i21;
                                i6 = i31;
                                d = ((i30 * 0.114d) + ((i29 * 0.587d) + (i27 * 0.299d))) - 128;
                            }
                            dArr2[i6] = d;
                            i24 = i26 + 1;
                            rgb = bArr;
                            i19 = i28;
                            i21 = i5;
                        }
                        i22 = i23 + 1;
                        rgb = bArr;
                    }
                    int i32 = i21;
                    int i33 = i19;
                    int i34 = 0;
                    while (true) {
                        dArr = COS;
                        int i35 = 8;
                        if (i34 >= 8) {
                            break;
                        }
                        int i36 = 0;
                        while (i36 < i35) {
                            int i37 = 0;
                            double d2 = 0.0d;
                            while (i37 < i35) {
                                d2 = (dArr2[(i34 * 8) + i37] * dArr[i36][i37]) + d2;
                                i37++;
                                i35 = 8;
                            }
                            dArr3[(i34 * 8) + i36] = d2;
                            i36++;
                            i35 = 8;
                        }
                        i34++;
                    }
                    for (int i38 = 0; i38 < 8; i38++) {
                        for (int i39 = 0; i39 < 8; i39++) {
                            double d3 = 0.0d;
                            for (int i40 = 0; i40 < 8; i40++) {
                                d3 = (dArr3[(i40 * 8) + i38] * dArr[i39][i40]) + d3;
                            }
                            dArr2[(i39 * 8) + i38] = d3;
                        }
                    }
                    int i41 = 0;
                    while (i41 < 64) {
                        iArr8[i41] = (int) Math.round(dArr2[iArr[i41]] / iArr2[r0]);
                        i41++;
                        dArr3 = dArr3;
                    }
                    double[] dArr4 = dArr3;
                    int i42 = iArr8[0];
                    int i43 = i42 - iArr7[i32];
                    iArr7[i32] = i42;
                    Pair size = size(i43);
                    int intValue = ((Number) size.first).intValue();
                    int intValue2 = ((Number) size.second).intValue();
                    Pair pair2 = DC;
                    out.put(((int[]) pair2.first)[intValue], ((int[]) pair2.second)[intValue]);
                    if (intValue > 0) {
                        out.put(intValue2, intValue);
                    }
                    int i44 = 0;
                    int i45 = 1;
                    while (true) {
                        pair = AC;
                        if (i45 >= 64) {
                            break;
                        }
                        if (iArr8[i45] == 0) {
                            i44++;
                        } else {
                            while (i44 > 15) {
                                out.put(((int[]) pair.first)[240], ((int[]) pair.second)[240]);
                                i44 -= 16;
                            }
                            Pair size2 = size(iArr8[i45]);
                            int intValue3 = ((Number) size2.first).intValue();
                            int intValue4 = ((Number) size2.second).intValue();
                            int i46 = (i44 << 4) | intValue3;
                            out.put(((int[]) pair.first)[i46], ((int[]) pair.second)[i46]);
                            out.put(intValue4, intValue3);
                            i44 = 0;
                        }
                        i45++;
                    }
                    if (i44 > 0) {
                        out.put(((int[]) pair.first)[0], ((int[]) pair.second)[0]);
                    }
                    i21 = i32 + 1;
                    rgb = bArr;
                    dArr3 = dArr4;
                    i19 = i33;
                    i11 = 3;
                }
                i20++;
                rgb = bArr;
                i11 = 3;
            }
            i8++;
            i7 = i;
            rgb = bArr;
            i11 = 3;
        }
        while (out.n != 0) {
            out.put(1, 1);
        }
        byteArrayOutputStream.write(((ByteArrayOutputStream) out.o).toByteArray());
        byteArrayOutputStream.write(255);
        byteArrayOutputStream.write(217);
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        Intrinsics.checkNotNullExpressionValue(byteArray, "toByteArray(...)");
        return byteArray;
    }

    public static final void encode$w16(ByteArrayOutputStream byteArrayOutputStream, int i) {
        byteArrayOutputStream.write(i >> 8);
        byteArrayOutputStream.write(i & 255);
    }

    public static Triple fit(int i, int i2, byte[] rgb, int i3, int i4) {
        int i5 = i;
        int i6 = i2;
        Intrinsics.checkNotNullParameter(rgb, "rgb");
        double d = i5;
        double d2 = i6;
        double min = Math.min(i3 / d, i4 / d2);
        if (min >= 1.0d) {
            return new Triple(Integer.valueOf(i5), Integer.valueOf(i6), rgb);
        }
        int max = Math.max(1, (int) (d * min));
        int max2 = Math.max(1, (int) (d2 * min));
        byte[] bArr = new byte[max * max2 * 3];
        int i7 = 0;
        while (i7 < max2) {
            long j = i6;
            long j2 = max2;
            int i8 = (int) ((i7 * j) / j2);
            int i9 = i7 + 1;
            int i10 = i7;
            int max3 = Math.max(i8 + 1, (int) ((i9 * j) / j2));
            int i11 = 0;
            while (i11 < max) {
                long j3 = i5;
                int i12 = max2;
                long j4 = max;
                int i13 = (int) ((i11 * j3) / j4);
                int i14 = i11 + 1;
                int max4 = Math.max(i13 + 1, (int) ((i14 * j3) / j4));
                int min2 = Math.min(max3, i6);
                int i15 = i8;
                int i16 = 0;
                int i17 = 0;
                int i18 = 0;
                int i19 = 0;
                while (i15 < min2) {
                    int min3 = Math.min(max4, i5);
                    for (int i20 = i13; i20 < min3; i20++) {
                        int i21 = ((i15 * i) + i20) * 3;
                        i16 += rgb[i21] & 255;
                        i18 += rgb[i21 + 1] & 255;
                        i19 += rgb[i21 + 2] & 255;
                        i17++;
                    }
                    i15++;
                    i5 = i;
                }
                int i22 = ((i10 * max) + i11) * 3;
                bArr[i22] = (byte) (i16 / i17);
                bArr[i22 + 1] = (byte) (i18 / i17);
                bArr[i22 + 2] = (byte) (i19 / i17);
                i5 = i;
                i6 = i2;
                max2 = i12;
                i11 = i14;
            }
            i5 = i;
            i6 = i2;
            i7 = i9;
        }
        return new Triple(Integer.valueOf(max), Integer.valueOf(max2), bArr);
    }

    /* JADX WARN: Code restructure failed: missing block: B:49:0x00ab, code lost:
    
        if (r11 <= 0) goto L30;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x00ad, code lost:
    
        if (r12 <= 0) goto L30;
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x00b8, code lost:
    
        if ((r11 * r12) <= 40000000) goto L45;
     */
    /* JADX WARN: Code restructure failed: missing block: B:53:0x00bb, code lost:
    
        if (r13 != 6) goto L47;
     */
    /* JADX WARN: Code restructure failed: missing block: B:54:0x00be, code lost:
    
        r2 = 3;
     */
    /* JADX WARN: Code restructure failed: missing block: B:55:0x00bf, code lost:
    
        r1 = new java.util.zip.Inflater();
        r1.setInput(r7.toByteArray());
        r0 = r11 * r2;
        r7 = new byte[(r11 * r12) * 3];
        r6 = new byte[r0];
        r5 = new byte[r0];
        r8 = 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:56:0x00db, code lost:
    
        if (r8 >= r12) goto L101;
     */
    /* JADX WARN: Code restructure failed: missing block: B:59:0x00de, code lost:
    
        r10 = new byte[1];
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x00e4, code lost:
    
        if (dev.tvremote.core.Fleet.fill(r1, r10, 1) == false) goto L55;
     */
    /* JADX WARN: Code restructure failed: missing block: B:62:0x00e8, code lost:
    
        r9 = r10[r17] & 255;
     */
    /* JADX WARN: Code restructure failed: missing block: B:63:0x00ec, code lost:
    
        if (r9 >= 0) goto L58;
     */
    /* JADX WARN: Code restructure failed: missing block: B:65:0x00f6, code lost:
    
        if (dev.tvremote.core.Fleet.fill(r1, r5, r0) != false) goto L61;
     */
    /* JADX WARN: Code restructure failed: missing block: B:66:0x00f9, code lost:
    
        dev.tvremote.core.Fleet.unfilter(r5, r9, r2, r6);
        r9 = (r8 * r11) * 3;
        r10 = 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:67:0x0101, code lost:
    
        if (r10 >= r11) goto L102;
     */
    /* JADX WARN: Code restructure failed: missing block: B:68:0x0103, code lost:
    
        r13 = r10 * r2;
        r7[r9] = r5[r13];
        r15 = r9 + 2;
        r7[r9 + 1] = r5[r13 + 1];
        r9 = r9 + 3;
        r7[r15] = r5[r13 + 2];
     */
    /* JADX WARN: Code restructure failed: missing block: B:69:0x011c, code lost:
    
        r10 = r10 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:71:0x0121, code lost:
    
        r8 = r8 + 1;
        r21 = r6;
        r6 = r5;
        r5 = r21;
     */
    /* JADX WARN: Code restructure failed: missing block: B:76:0x00eb, code lost:
    
        r9 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:79:0x011f, code lost:
    
        r0 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:80:0x012b, code lost:
    
        r1.end();
     */
    /* JADX WARN: Code restructure failed: missing block: B:81:0x012e, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:83:0x012f, code lost:
    
        r1.end();
        r0 = new kotlin.Triple(java.lang.Integer.valueOf(r11), java.lang.Integer.valueOf(r12), r7);
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:29:0x0142  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static byte[] fromPng(byte[] bArr) {
        byte[] bArr2;
        char c;
        Inflater inflater;
        int i = 4;
        ByteBuffer wrap = ByteBuffer.wrap(bArr);
        if (bArr.length < 33 || wrap.getLong(0) != -8552249625308161526L) {
            bArr2 = null;
        } else {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            int i2 = 8;
            int i3 = 0;
            int i4 = 0;
            byte b = 0;
            while (true) {
                int i5 = i2 + 12;
                if (i5 <= bArr.length) {
                    int i6 = wrap.getInt(i2);
                    c = 0;
                    bArr2 = null;
                    String str = new String(bArr, i2 + 4, 4, Charsets.ISO_8859_1);
                    if (i6 < 0 || i5 + i6 > bArr.length) {
                        break;
                    }
                    int hashCode = str.hashCode();
                    if (hashCode != 2242190) {
                        if (hashCode != 2243538) {
                            if (hashCode == 2246125 && str.equals("IHDR")) {
                                i3 = wrap.getInt(i2 + 8);
                                i4 = wrap.getInt(i5);
                                b = bArr[i2 + 17];
                                if (bArr[i2 + 16] != 8) {
                                    break;
                                }
                                if (bArr[i2 + 20] != 0) {
                                    break;
                                }
                                if (b != 2 && b != 6) {
                                    break;
                                }
                            }
                        } else if (str.equals("IEND")) {
                            break;
                        }
                    } else if (str.equals("IDAT")) {
                        byteArrayOutputStream.write(bArr, i2 + 8, i6);
                    }
                    i2 += i6 + 12;
                } else {
                    c = 0;
                    bArr2 = null;
                    break;
                }
            }
        }
        Triple triple = bArr2;
        if (triple != 0) {
            Triple fit = fit(((Number) triple.first).intValue(), ((Number) triple.second).intValue(), (byte[]) triple.third, 1280, 720);
            int intValue = ((Number) fit.first).intValue();
            int intValue2 = ((Number) fit.second).intValue();
            byte[] bArr3 = (byte[]) fit.third;
            int[] iArr = {82, 72, 62, 50, 40, 30, 22, 15};
            for (int i7 = 0; i7 < 8; i7++) {
                byte[] encode = encode(intValue, intValue2, iArr[i7], bArr3);
                if (encode.length <= 150000) {
                    return encode;
                }
            }
        }
        return bArr2;
        inflater.end();
        Triple triple2 = bArr2;
        if (triple2 != 0) {
        }
        return bArr2;
    }

    public static byte[] shrink(byte[] bArr) {
        Triple triple;
        Pair pair;
        int[] iArr = JpegDecode.ZIGZAG;
        try {
            triple = new JpegDecode.Reader(bArr).run();
        } catch (Exception unused) {
            triple = null;
        }
        if (triple == null) {
            if (bArr.length <= 350000) {
                int i = 2;
                while (i + 9 < bArr.length && (bArr[i] & 255) == 255) {
                    int i2 = bArr[i + 1] & 255;
                    if (192 <= i2 && i2 < 208 && i2 != 196 && i2 != 200 && i2 != 204) {
                        pair = new Pair(Integer.valueOf(((bArr[i + 7] & 255) << 8) | (bArr[i + 8] & 255)), Integer.valueOf((bArr[i + 6] & 255) | ((bArr[i + 5] & 255) << 8)));
                        break;
                    }
                    i += (((bArr[i + 2] & 255) << 8) | (255 & bArr[i + 3])) + 2;
                }
                pair = null;
                if (pair != null) {
                    if (((Number) pair.first).intValue() <= 1920 && ((Number) pair.second).intValue() <= 1920) {
                        return bArr;
                    }
                } else {
                    return bArr;
                }
            }
            return null;
        }
        int intValue = ((Number) triple.first).intValue();
        int intValue2 = ((Number) triple.second).intValue();
        byte[] bArr2 = (byte[]) triple.third;
        if (bArr.length <= 350000 && intValue <= 1920 && intValue2 <= 1920) {
            return bArr;
        }
        Triple fit = fit(intValue, intValue2, bArr2, 1920, 1920);
        int intValue3 = ((Number) fit.first).intValue();
        int intValue4 = ((Number) fit.second).intValue();
        byte[] bArr3 = (byte[]) fit.third;
        int[] iArr2 = {85, 78, 70, 62, 54, 46, 38, 30, 22, 15};
        for (int i3 = 0; i3 < 10; i3++) {
            byte[] encode = encode(intValue3, intValue4, iArr2[i3], bArr3);
            if (encode.length <= 350000) {
                return encode;
            }
        }
        return null;
    }

    public static Pair size(int i) {
        int i2 = 0;
        for (int abs = Math.abs(i); abs != 0; abs >>= 1) {
            i2++;
        }
        Integer valueOf = Integer.valueOf(i2);
        if (i < 0) {
            i = (i - 1) & ((1 << i2) - 1);
        }
        return new Pair(valueOf, Integer.valueOf(i));
    }
}
