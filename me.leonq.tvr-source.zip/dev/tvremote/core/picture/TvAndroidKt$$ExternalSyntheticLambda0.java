package dev.tvremote.core.picture;

import android.content.Context;
import android.os.Build;
import dev.tvremote.core.Scrub;
import dev.tvremote.core.SupportAndroid;
import dev.tvremote.core.WireLog;
import dev.tvremote.phone.manage.PhoneSupport;
import java.io.InputStream;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Charsets;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class TvAndroidKt$$ExternalSyntheticLambda0 implements Function0 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Context f$0;

    public /* synthetic */ TvAndroidKt$$ExternalSyntheticLambda0(Context context, int i) {
        this.$r8$classId = i;
        this.f$0 = context;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        switch (this.$r8$classId) {
            case 0:
                InputStream open = this.f$0.getAssets().open("scrcpy-server.jar");
                try {
                    Intrinsics.checkNotNull(open);
                    byte[] readBytes = MathKt.readBytes(open);
                    MathKt.closeFinally(open, null);
                    return readBytes;
                } finally {
                }
            default:
                Context applicationContext = this.f$0.getApplicationContext();
                Intrinsics.checkNotNullExpressionValue(applicationContext, "getApplicationContext(...)");
                Regex regex = Scrub.SECRET;
                StringBuilder sb = new StringBuilder();
                WireLog wireLog = WireLog.all;
                sb.append(WireLog.app);
                sb.append('\n');
                sb.append(Build.MANUFACTURER);
                sb.append(' ');
                sb.append(Build.MODEL);
                sb.append(" · Android ");
                sb.append(Build.VERSION.RELEASE);
                sb.append('\n');
                PhoneSupport phoneSupport = PhoneSupport.INSTANCE;
                sb.append(PhoneSupport.net(applicationContext));
                sb.append('\n');
                sb.append(PhoneSupport.tvs().toString(1));
                sb.append('\n');
                String s = SupportAndroid.logcat();
                Intrinsics.checkNotNullParameter(s, "s");
                while (true) {
                    String quote = JSONObject.quote(s);
                    Intrinsics.checkNotNullExpressionValue(quote, "quote(...)");
                    byte[] bytes = quote.getBytes(Charsets.UTF_8);
                    Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                    if (bytes.length > 12000) {
                        s = StringsKt.takeLast(s, (s.length() * 4) / 5);
                    } else {
                        sb.append(s);
                        sb.append('\n');
                        sb.append(StringsKt.takeLast(WireLog.all.report(null), 24000));
                        return Scrub.blank(sb.toString());
                    }
                }
        }
    }
}
