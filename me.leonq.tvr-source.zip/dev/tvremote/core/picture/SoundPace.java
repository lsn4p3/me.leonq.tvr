package dev.tvremote.core.picture;

import dev.tvremote.phone.media.TalkKt$$ExternalSyntheticLambda1;
import java.util.concurrent.ConcurrentHashMap;

/* loaded from: classes.dex */
public final class SoundPace {
    public static volatile TalkKt$$ExternalSyntheticLambda1 changed;
    public static volatile boolean even;
    public static final ConcurrentHashMap learned = new ConcurrentHashMap();
}
