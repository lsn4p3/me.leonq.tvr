package dev.tvremote.core.picture;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census;
import dev.tvremote.core.Census$$ExternalSyntheticLambda3;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Fleet$$ExternalSyntheticLambda0;
import dev.tvremote.core.SupportAndroid$store$1;
import dev.tvremote.core.WireLog;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.Adb$$ExternalSyntheticLambda0;
import dev.tvremote.core.adb.AdbLink$$ExternalSyntheticLambda2;
import dev.tvremote.core.adb.AdbPrompt;
import dev.tvremote.core.adb.TvShell;
import dev.tvremote.core.ontv.Bloat$$ExternalSyntheticLambda1;
import dev.tvremote.core.ontv.Games;
import dev.tvremote.core.remote.Lg$$ExternalSyntheticLambda2;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda5;
import dev.tvremote.phone.MainActivity$onCreate$2;
import dev.tvremote.tvapps.ApkCert$$ExternalSyntheticLambda0;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$ObjectRef;
import kotlin.math.MathKt;
import kotlin.sequences.GeneratorSequence;
import kotlin.sequences.SequencesKt;
import kotlin.text.Charsets;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class Tv {
    public static final int[] LEVELS;
    public static final byte[] MOUSE_DESC;
    public static final Set OPENERS;
    public static final byte[] PNG;
    public static final int[][] QUALITY;
    public static final ConcurrentHashMap encoderList;
    public static final ConcurrentHashMap softEncoder;
    public static final ConcurrentHashMap softName;
    public int accBtn;
    public int accDx;
    public int accDy;
    public int accWheel;
    public volatile Adb adb;
    public final String audio;
    public final int audioBitRate;
    public final boolean audioShare;
    public final SupportAndroid$store$1 audioSink;
    public final int bitRate;
    public volatile boolean capped;
    public volatile ArrayList capture;
    public volatile Tv carrier;
    public String clip;
    public int clipGot;
    public final Object clipLock;
    public volatile Adb.Stream control;
    public final File dir;
    public final String encoder;
    public volatile HttpURLConnection feedConn;
    public final int fps;
    public volatile boolean framed;
    public final boolean hand;
    public volatile int height;
    public JSONObject heldDown;
    public final String host;
    public volatile ExecutorService io;
    public final TvAndroidKt$$ExternalSyntheticLambda0 jar;
    public volatile Adb letGone;
    public final Listener listener;
    public final int maxSide;
    public volatile Adb.Stream mouseAt;
    public final Object mouseLock;
    public volatile boolean mouseOn;
    public final ByteArrayOutputStream mouseOut;
    public Thread mousePump;
    public volatile ApkCert$$ExternalSyntheticLambda0 mouseStats;
    public volatile boolean noFrame;
    public volatile long ownUse;
    public final AtomicReference pendingMove;
    public final int quality;
    public volatile boolean quietChecking;
    public final Object quietLock;
    public volatile boolean quieted;
    public volatile boolean rejoin;
    public volatile long rejoinedAt;
    public final String relay;
    public volatile boolean relaying;
    public final Object restLock;
    public volatile boolean resting;
    public final SurfaceScreen screen;
    public volatile int sdkSeen;
    public volatile Adb.Stream server;
    public volatile boolean stalled;
    public volatile boolean stopped;
    public final ScheduledExecutorService touchIo;
    public final Object touchLock;
    public volatile String video;
    public final boolean wake;
    public final boolean wantControl;
    public final boolean wantVideo;
    public volatile boolean wanted;
    public volatile int width;

    /* loaded from: classes.dex */
    public final class Facts {
        public final String ipAddr;
        public final boolean jarOk;
        public final Long memKb;
        public final String model;
        public final Integer quietMark;
        public final int sdk;

        public Facts(String model, int i, String ipAddr, boolean z, Long l, Integer num) {
            Intrinsics.checkNotNullParameter(model, "model");
            Intrinsics.checkNotNullParameter(ipAddr, "ipAddr");
            this.model = model;
            this.sdk = i;
            this.ipAddr = ipAddr;
            this.jarOk = z;
            this.memKb = l;
            this.quietMark = num;
        }
    }

    /* loaded from: classes.dex */
    public interface Listener {
        void onNetwork(String str, String str2, String str3);

        void onPass(String str);

        void onPassRefused();

        void onStatus(String str, String str2);

        void onVideoSize(int i, int i2);

        boolean wantsNetwork();

        boolean wantsPass();
    }

    static {
        int[] iArr = {5, 1, 9, 2, 161, 1, 9, 1, 161, 0, 5, 9, 25, 1, 41, 3, 21, 0, 37, 1, 149, 3, 117, 1, 129, 2, 149, 1, 117, 5, 129, 1, 5, 1, 9, 48, 9, 49, 9, 56, 21, 129, 37, 127, 117, 8, 149, 3, 129, 6, 192, 192};
        ArrayList arrayList = new ArrayList(52);
        for (int i = 0; i < 52; i++) {
            arrayList.add(Byte.valueOf((byte) iArr[i]));
        }
        MOUSE_DESC = CollectionsKt.toByteArray(arrayList);
        softEncoder = new ConcurrentHashMap();
        softName = new ConcurrentHashMap();
        encoderList = new ConcurrentHashMap();
        PNG = new byte[]{-119, 80, 78, 71, 13, 10, 26, 10};
        OPENERS = SetsKt.setOf((Object[]) new Integer[]{82, 176, 178, 172, 170, 190, 191, 195});
        QUALITY = new int[][]{new int[]{480, 300000, 15}, new int[]{720, 800000, 20}, new int[]{960, 2000000, 20}, new int[]{360, 200000, 15}, new int[]{240, 120000, 15}, new int[]{1280, 4000000, 30}};
        LEVELS = new int[]{4, 3, 0, 1, 2};
    }

    public Tv(File file, TvAndroidKt$$ExternalSyntheticLambda0 tvAndroidKt$$ExternalSyntheticLambda0, String host, SurfaceScreen surfaceScreen, int i, int i2, boolean z, Listener listener, String str, SupportAndroid$store$1 supportAndroid$store$1, boolean z2, boolean z3, int i3, int i4, int i5, String str2, boolean z4, String str3) {
        Intrinsics.checkNotNullParameter(host, "host");
        Intrinsics.checkNotNullParameter(listener, "listener");
        this.dir = file;
        this.jar = tvAndroidKt$$ExternalSyntheticLambda0;
        this.host = host;
        this.screen = surfaceScreen;
        this.quality = i;
        this.maxSide = i2;
        this.wake = z;
        this.listener = listener;
        this.audio = str;
        this.audioSink = supportAndroid$store$1;
        this.wantControl = z2;
        this.audioShare = z3;
        this.audioBitRate = i3;
        this.fps = i4;
        this.bitRate = i5;
        this.encoder = str2;
        this.hand = z4;
        this.relay = str3;
        this.io = Executors.newSingleThreadExecutor();
        this.quietLock = new Object();
        this.restLock = new Object();
        this.width = 960;
        this.height = 540;
        this.wantVideo = surfaceScreen != null;
        this.video = Fleet.videoOpts(i, i2, i5, false);
        Thread thread = new Thread(new Tv$$ExternalSyntheticLambda4(this, 0), "tv-session");
        thread.setDaemon(true);
        thread.start();
        this.touchIo = Executors.newSingleThreadScheduledExecutor();
        this.pendingMove = new AtomicReference(null);
        this.touchLock = new Object();
        this.mouseLock = new Object();
        this.mouseOut = new ByteArrayOutputStream();
        this.clipLock = new Object();
        this.clip = "";
    }

    public static String md5Of(byte[] bArr) {
        byte[] digest = MessageDigest.getInstance("MD5").digest(bArr);
        Intrinsics.checkNotNullExpressionValue(digest, "digest(...)");
        return ArraysKt.joinToString$default(digest, "", new Bloat$$ExternalSyntheticLambda1(21));
    }

    public static void reportsFor(int i, int i2, int i3, int i4, ByteArrayOutputStream byteArrayOutputStream) {
        int i5 = i;
        int i6 = i2;
        int i7 = i3;
        while (true) {
            int coerceIn = MathKt.coerceIn(i5, -127, 127);
            int coerceIn2 = MathKt.coerceIn(i6, -127, 127);
            int coerceIn3 = MathKt.coerceIn(i7, -127, 127);
            byteArrayOutputStream.write(new byte[]{13, 0, 1, 0, 4, (byte) i4, (byte) coerceIn, (byte) coerceIn2, (byte) coerceIn3});
            i5 -= coerceIn;
            i6 -= coerceIn2;
            i7 -= coerceIn3;
            if (i5 == 0 && i6 == 0 && i7 == 0) {
                return;
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:35:0x01a2  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x01ac A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final ArrayList session$startServer(Adb adb, Tv tv, String str, Ref$ObjectRef ref$ObjectRef, int i, boolean z) {
        String str2;
        String m;
        String str3;
        String str4;
        String str5;
        String sb;
        Object obj;
        String str6;
        byte[] bArr;
        Adb.Stream stream;
        int i2;
        long j;
        boolean z2;
        int i3;
        int i4;
        String str7;
        ArrayList arrayList = new ArrayList();
        int i5 = 1;
        String format = String.format("%08x", Arrays.copyOf(new Object[]{Integer.valueOf(new Random().nextInt(Integer.MAX_VALUE))}, 1));
        boolean z3 = tv.wantControl;
        if (tv.wantVideo) {
            String str8 = tv.video;
            int i6 = tv.quality;
            int i7 = tv.fps;
            if (str != null) {
                z2 = true;
            } else {
                z2 = false;
            }
            boolean z4 = tv.capped;
            if (i7 > 0) {
                i3 = MathKt.coerceIn(i7, 1, 60);
            } else {
                int[][] iArr = QUALITY;
                i3 = iArr[MathKt.coerceIn(i6, 0, iArr.length - 1)][2];
                if (z2) {
                    i4 = 10;
                } else if (z4) {
                    i4 = 20;
                }
                i3 = Math.min(i3, i4);
            }
            if (str == null || (str7 = " video_encoder=".concat(str)) == null) {
                str7 = "";
            }
            str2 = "video=true " + str8 + " max_fps=" + i3 + str7;
        } else {
            str2 = "video=false";
        }
        Object obj2 = ref$ObjectRef.element;
        if (obj2 == null) {
            str5 = " audio=false";
        } else {
            if (!obj2.equals("opus") && !Intrinsics.areEqual(ref$ObjectRef.element, "aac")) {
                m = "";
            } else {
                m = ApkSigner$$ExternalSyntheticOutline0.m(" audio_bit_rate=", tv.audioBitRate);
            }
            if (i >= 33) {
                str3 = " audio_source=playback";
            } else {
                str3 = "";
            }
            if (z) {
                str4 = " audio_dup=true";
            } else {
                str4 = "";
            }
            str5 = " audio=true audio_codec=" + obj2 + m + str3 + str4;
        }
        String str9 = "shell:CLASSPATH=/data/local/tmp/scrcpy-server.jar app_process / com.genymobile.scrcpy.Server 5.0.1 scid=" + format + " tunnel_forward=true cleanup=false control=" + z3 + " send_dummy_byte=true send_device_meta=false clipboard_autosync=false " + str2 + str5 + " & P=$!; while read -t 60 x; do :; done; kill $P";
        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
        Adb.Stream open = adb.open(10000L, str9);
        tv.server = open;
        Trace trace = Trace.INSTANCE;
        if (Trace.getOn()) {
            Trace.INSTANCE.log("s.launch", "");
        }
        Thread thread = new Thread(new Tv$$ExternalSyntheticLambda15(tv, open, i5), "scrcpy-heartbeat");
        thread.setDaemon(true);
        thread.start();
        StringBuilder sb2 = new StringBuilder();
        Thread thread2 = new Thread(new Guard$$ExternalSyntheticLambda5(9, open, sb2), "scrcpy-log");
        thread2.setDaemon(true);
        thread2.start();
        byte[] bArr2 = new byte[1];
        long nanoTime = System.nanoTime() + 20000000000L;
        Adb.Stream stream2 = null;
        int i8 = 0;
        while (System.nanoTime() < nanoTime && stream2 == null && !tv.stopped) {
            try {
                bArr = bArr2;
                i2 = i8;
                stream = stream2;
                stream2 = adb.open(10000L, "localabstract:scrcpy_" + format);
            } catch (IOException e) {
                e = e;
                bArr = bArr2;
                stream = stream2;
                i2 = i8;
            }
            try {
            } catch (IOException e2) {
                e = e2;
                if (adb.dead) {
                    throw e;
                }
                stream2 = stream;
                if (stream2 == null) {
                }
                i8 = i2 + 1;
                bArr2 = bArr;
            }
            if (stream2.read(4000L, bArr, 0, 1) != 1 || bArr[0] != 0) {
                stream2.close();
                stream2 = stream;
                if (stream2 == null) {
                    if (i2 < 60) {
                        j = 25;
                    } else {
                        j = 100;
                    }
                    Thread.sleep(j);
                }
                i8 = i2 + 1;
                bArr2 = bArr;
            } else {
                if (stream2 == null) {
                }
                i8 = i2 + 1;
                bArr2 = bArr;
            }
        }
        Adb.Stream stream3 = stream2;
        int i9 = i8;
        if (stream3 == null) {
            synchronized (sb2) {
                sb = sb2.toString();
                Intrinsics.checkNotNullExpressionValue(sb, "toString(...)");
            }
            List lines = StringsKt.lines(sb);
            ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(lines));
            Iterator it = lines.iterator();
            while (it.hasNext()) {
                arrayList2.add(StringsKt.trim((String) it.next()).toString());
            }
            ArrayList arrayList3 = new ArrayList();
            Iterator it2 = arrayList2.iterator();
            while (it2.hasNext()) {
                Object next = it2.next();
                if (((String) next).length() > 0) {
                    arrayList3.add(next);
                }
            }
            ListIterator listIterator = arrayList3.listIterator(arrayList3.size());
            while (listIterator.hasPrevious()) {
                Object previous = listIterator.previous();
                String str10 = (String) previous;
                if (StringsKt.contains(str10, "ERROR", false) || StringsKt.contains(str10, "Exception", false) || StringsKt.contains(str10, "Error:", false)) {
                    obj = previous;
                    break;
                }
            }
            obj = null;
            String str11 = (String) obj;
            if (str11 == null) {
                str11 = (String) CollectionsKt.lastOrNull(arrayList3);
            }
            if (str11 == null || (str6 = ": ".concat(StringsKt.take(str11, 200))) == null) {
                str6 = "";
            }
            throw new IOException("scrcpy-server did not start on the TV".concat(str6));
        }
        Trace trace2 = Trace.INSTANCE;
        if (Trace.getOn()) {
            trace2.log("s.listening", "tries=" + i9);
        }
        arrayList.add(stream3);
        boolean z5 = tv.wantVideo;
        if (ref$ObjectRef.element == null) {
            i5 = 0;
        }
        int i10 = (z5 ? 1 : 0) + i5 + (tv.wantControl ? 1 : 0);
        while (arrayList.size() < i10) {
            arrayList.add(adb.open(10000L, "localabstract:scrcpy_".concat(format)));
        }
        return arrayList;
    }

    public final boolean backWanted(Adb adb) {
        synchronized (this.restLock) {
            try {
                if (!this.resting) {
                    return false;
                }
                while (!this.wanted && !this.stopped) {
                    if (adb.dead) {
                        return false;
                    }
                    this.restLock.wait(5000L);
                }
                return !this.stopped;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void carry(Tv tv) {
        if (tv == null || tv.relaying) {
            tv = null;
        }
        this.carrier = tv;
        if (tv == null) {
            synchronized (this.restLock) {
                if (this.resting) {
                    this.wanted = true;
                    this.restLock.notifyAll();
                }
            }
            return;
        }
        if (this.wantControl && !this.wantVideo && this.audio == null) {
            this.ownUse = System.currentTimeMillis();
            Thread thread = new Thread(new Guard$$ExternalSyntheticLambda5(12, this, tv), "keys-rest");
            thread.setDaemon(true);
            thread.start();
        }
    }

    public final String clipboard() {
        int i;
        Tv tv = this.carrier;
        String str = null;
        if (tv != null) {
            if (tv.control == null || tv.stopped) {
                tv = null;
            }
            if (tv != null) {
                return tv.clipboard();
            }
        }
        synchronized (this.clipLock) {
            i = this.clipGot;
        }
        send(new byte[]{8, 0});
        long currentTimeMillis = System.currentTimeMillis() + 2500;
        synchronized (this.clipLock) {
            while (this.clipGot == i) {
                long currentTimeMillis2 = currentTimeMillis - System.currentTimeMillis();
                if (currentTimeMillis2 <= 0) {
                    if (!this.stopped && this.control != null) {
                        str = "";
                    }
                    return str;
                }
                this.clipLock.wait(currentTimeMillis2);
            }
            return this.clip;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:32:0x0070, code lost:
    
        r1.readAll(0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x0073, code lost:
    
        return;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void deviceMessages(Adb.Stream stream) {
        byte[] bArr = new byte[4];
        while (true) {
            Adb.Stream stream2 = stream;
            if (stream2.read(0L, bArr, 0, 1) < 0) {
                return;
            }
            byte b = bArr[0];
            if (b != 0) {
                if (b != 1) {
                    if (b != 2) {
                        stream2.readAll(0L);
                        return;
                    } else {
                        stream2.readFully(4, bArr);
                        int i = ByteBuffer.wrap(bArr).getShort(2) & 65535;
                        stream2.readFully(i, new byte[i]);
                    }
                } else {
                    stream2.readFully(8, new byte[8]);
                }
            } else {
                stream2.readFully(4, bArr);
                int i2 = ByteBuffer.wrap(bArr).getInt();
                if (i2 < 0 || i2 > 1048576) {
                    break;
                }
                byte[] bArr2 = new byte[i2];
                stream2.readFully(i2, bArr2);
                synchronized (this.clipLock) {
                    this.clip = new String(bArr2, Charsets.UTF_8);
                    this.clipGot++;
                    this.clipLock.notifyAll();
                }
            }
            stream = stream2;
        }
    }

    public final String encoders(Adb adb) {
        ConcurrentHashMap concurrentHashMap = encoderList;
        String str = this.host;
        String str2 = (String) concurrentHashMap.get(str);
        if (str2 != null) {
            return str2;
        }
        String replaceAll = Census$$ExternalSyntheticOutline0.m7m("[^A-Za-z0-9.-]", "compile(...)", str, "input", str).replaceAll("_");
        Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
        File file = new File(this.dir, "encoders-" + replaceAll + ".txt");
        try {
            if (file.isFile()) {
                String readText$default = MathKt.readText$default(file);
                concurrentHashMap.put(str, readText$default);
                return readText$default;
            }
        } catch (IOException unused) {
        }
        try {
            String shell = adb.shell(15000L, "CLASSPATH=/data/local/tmp/scrcpy-server.jar app_process / com.genymobile.scrcpy.Server 5.0.1 cleanup=false list_encoders=true 2>&1");
            if (StringsKt.contains(shell, "--video-codec=", false) || StringsKt.contains(shell, "--audio-codec=", false)) {
                concurrentHashMap.put(str, shell);
                try {
                    MathKt.writeText$default(file, shell);
                } catch (IOException unused2) {
                }
            }
            return shell;
        } catch (IOException e) {
            WireLog.all.add("·", Census$$ExternalSyntheticOutline0.m("picture ", str, " list_encoders failed: ", e.getMessage()));
            return null;
        }
    }

    public final void endCapture(ArrayList arrayList) {
        Adb adb = this.adb;
        if (adb != null) {
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                try {
                    ((Adb.Stream) it.next()).close();
                } catch (Exception unused) {
                }
            }
            try {
                ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                adb.shell(120000L, "for i in 1 2 3 4 5 6 7 8 9 10; do dumpsys audio | grep -qi remote_submix || break; sleep 0.5; done; pm path com.google.android.tv.remote.service >/dev/null 2>&1 && am startservice -n com.google.android.tv.remote.service/.RemoteService >/dev/null 2>&1; true");
            } catch (IOException unused2) {
            }
        }
    }

    public final void giveBackSound() {
        synchronized (this.quietLock) {
            if (!this.quieted) {
                return;
            }
            this.quieted = false;
            Adb adb = this.adb;
            if (adb == null) {
                return;
            }
            try {
                PrivateListen.release$default(new Fleet$$ExternalSyntheticLambda0(adb, 17));
            } catch (Exception unused) {
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r10v18 */
    /* JADX WARN: Type inference failed for: r10v2 */
    /* JADX WARN: Type inference failed for: r10v3, types: [boolean, int] */
    public final void hear(Adb.Stream stream, String str) {
        ?? r10;
        byte[] bArr;
        boolean z;
        long j;
        boolean z2;
        double d;
        String valueOf;
        Adb.Stream stream2 = stream;
        int i = 12;
        byte[] bArr2 = new byte[12];
        stream2.readFully(4, bArr2);
        int i2 = ByteBuffer.wrap(bArr2, 0, 4).getInt();
        if (i2 != 0 && i2 != 1) {
            long currentTimeMillis = System.currentTimeMillis();
            long j2 = 0;
            long j3 = 0;
            boolean z3 = false;
            boolean z4 = false;
            int i3 = 0;
            while (!this.stopped) {
                try {
                    stream2.readFully(i, bArr2);
                    ByteBuffer wrap = ByteBuffer.wrap(bArr2);
                    long j4 = wrap.getLong();
                    int i4 = wrap.getInt();
                    if (i4 >= 0 && i4 <= 1048576) {
                        byte[] bArr3 = new byte[i4];
                        stream2.readFully(i4, bArr3);
                        if ((j4 & 4611686018427387904L) != j2) {
                            r10 = 1;
                        } else {
                            r10 = 0;
                        }
                        Trace trace = Trace.INSTANCE;
                        if (Trace.getOn()) {
                            bArr = bArr2;
                            z = z3;
                            long j5 = (j4 & 4611686018427387903L) / 1000;
                            StringBuilder sb = new StringBuilder();
                            j = currentTimeMillis;
                            sb.append("pts=");
                            sb.append(j5);
                            sb.append(" cfg=");
                            sb.append((int) r10);
                            sb.append(" n=");
                            sb.append(i4);
                            trace.log("a.in", sb.toString());
                        } else {
                            bArr = bArr2;
                            z = z3;
                            j = currentTimeMillis;
                        }
                        SupportAndroid$store$1 supportAndroid$store$1 = this.audioSink;
                        if (supportAndroid$store$1 != 0) {
                            supportAndroid$store$1.audio(bArr3, r10);
                        }
                        if (r10 == 0 && !z4 && Intrinsics.areEqual(str, "raw")) {
                            int i5 = 0;
                            while (true) {
                                if (i5 < i4) {
                                    if (bArr3[i5] != 0) {
                                        z4 = true;
                                        break;
                                    }
                                    i5++;
                                } else {
                                    z4 = false;
                                    break;
                                }
                            }
                        }
                        Trace trace2 = Trace.INSTANCE;
                        if (Trace.getOn() && r10 == 0 && !z) {
                            Trace.INSTANCE.log("a.first", "");
                            z3 = true;
                        } else {
                            z3 = z;
                        }
                        j3 += i4 + 12;
                        currentTimeMillis = System.currentTimeMillis();
                        long j6 = currentTimeMillis - j;
                        if (j6 >= 3000) {
                            if (this.quieted) {
                                if (Intrinsics.areEqual(str, "raw")) {
                                    z2 = z3;
                                    d = 1000.0d;
                                } else {
                                    d = 1000.0d;
                                    z2 = z3;
                                    if (((j3 * 1000.0d) / j6) / 1024 >= 1.0d) {
                                        z4 = true;
                                    } else {
                                        z4 = false;
                                    }
                                }
                                if (z4) {
                                    i3 = 0;
                                } else {
                                    i3++;
                                }
                                if (i3 >= 3) {
                                    if (this.quieted && !this.quietChecking) {
                                        this.quietChecking = true;
                                        Thread thread = new Thread(new Tv$$ExternalSyntheticLambda4(this, 1), "tv-quiet-check");
                                        thread.setDaemon(true);
                                        thread.start();
                                    }
                                    i3 = 0;
                                }
                            } else {
                                z2 = z3;
                                d = 1000.0d;
                            }
                            Listener listener = this.listener;
                            double d2 = ((j3 * d) / j6) / 1024;
                            if (d2 < 10.0d) {
                                valueOf = String.format(Locale.US, "%.1f", Arrays.copyOf(new Object[]{Double.valueOf(d2)}, 1));
                            } else {
                                valueOf = String.valueOf((int) d2);
                            }
                            listener.onStatus("arate", valueOf);
                            z3 = z2;
                            bArr2 = bArr;
                            i = 12;
                            j2 = 0;
                            j3 = 0;
                            z4 = false;
                        } else {
                            currentTimeMillis = j;
                            bArr2 = bArr;
                            i = 12;
                            j2 = 0;
                        }
                        stream2 = stream;
                    } else {
                        throw new IOException("bad audio packet");
                    }
                } catch (Throwable th) {
                    SupportAndroid$store$1 supportAndroid$store$12 = this.audioSink;
                    if (supportAndroid$store$12 != null) {
                        ((AudioOut) supportAndroid$store$12.$p).release();
                    }
                    throw th;
                }
            }
            SupportAndroid$store$1 supportAndroid$store$13 = this.audioSink;
            if (supportAndroid$store$13 != null) {
                ((AudioOut) supportAndroid$store$13.$p).release();
                return;
            }
            return;
        }
        WireLog.all.add("·", "picture " + this.host + " sound capture refused (codec id " + i2 + ", Android sdk " + this.sdkSeen + ")");
        int i6 = this.sdkSeen;
        StringBuilder sb2 = new StringBuilder("refused:");
        sb2.append(i6);
        status("audio", sb2.toString());
    }

    public final void key(int i, int i2, int i3, int i4) {
        byte[] array = ByteBuffer.allocate(14).put((byte) 0).put((byte) i).putInt(i2).putInt(i3).putInt(i4).array();
        Intrinsics.checkNotNullExpressionValue(array, "array(...)");
        send(array);
    }

    public final void letGo() {
        Adb adb = this.adb;
        if (adb == null) {
            return;
        }
        synchronized (this) {
            if (this.letGone == adb) {
                return;
            }
            this.letGone = adb;
            adb.close();
        }
    }

    public final void mouseHere() {
        Adb.Stream stream;
        Tv tv = this.carrier;
        if (tv != null && tv.control != null && !tv.stopped) {
            stream = tv.control;
        } else {
            stream = this.control;
        }
        if (stream == null || stream == this.mouseAt) {
            return;
        }
        this.mouseAt = stream;
        byte[] bytes = "TV Remote Air Mouse".getBytes(Charsets.UTF_8);
        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        int length = bytes.length + 10;
        byte[] bArr = MOUSE_DESC;
        byte[] array = ByteBuffer.allocate(length + bArr.length).put((byte) 12).putShort((short) 1).putShort((short) 6353).putShort((short) 20034).put((byte) bytes.length).put(bytes).putShort((short) bArr.length).put(bArr).array();
        Intrinsics.checkNotNullExpressionValue(array, "array(...)");
        send(array);
    }

    public final void mouseMove(int i, int i2, int i3, int i4) {
        if (!this.mouseOn) {
            return;
        }
        synchronized (this.mouseLock) {
            try {
                int i5 = this.accBtn;
                if (i3 != i5) {
                    int i6 = this.accDx;
                    if (i6 == 0) {
                        if (this.accDy == 0) {
                            if (this.accWheel != 0) {
                            }
                            reportsFor(0, 0, 0, i3, this.mouseOut);
                            this.accBtn = i3;
                        }
                    }
                    reportsFor(i6, this.accDy, this.accWheel, i5, this.mouseOut);
                    this.accDx = 0;
                    this.accDy = 0;
                    this.accWheel = 0;
                    reportsFor(0, 0, 0, i3, this.mouseOut);
                    this.accBtn = i3;
                }
                this.accDx += i;
                this.accDy += i2;
                this.accWheel += i4;
                if (this.mouseOut.size() > 3600) {
                    this.mouseOut.reset();
                }
                if (this.mousePump == null) {
                    Thread thread = new Thread(new Tv$$ExternalSyntheticLambda4(this, 2), "tv-mouse");
                    thread.setDaemon(true);
                    thread.start();
                    this.mousePump = thread;
                }
                this.mouseLock.notifyAll();
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r6v2 */
    /* JADX WARN: Type inference failed for: r6v3, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r6v7 */
    public final void play(Adb.Stream stream) {
        ?? r6;
        long j;
        long j2;
        int i;
        Adb.Stream stream2 = stream;
        int i2 = 12;
        byte[] bArr = new byte[12];
        stream2.readFully(4, bArr);
        long currentTimeMillis = System.currentTimeMillis();
        long j3 = 0;
        long j4 = 0;
        boolean z = true;
        while (!this.stopped) {
            stream2.readFully(i2, bArr);
            ByteBuffer wrap = ByteBuffer.wrap(bArr);
            long j5 = wrap.getLong();
            int i3 = wrap.getInt();
            if (j5 < j3) {
                this.width = (int) (j5 & 4294967295L);
                this.height = i3;
                SurfaceScreen surfaceScreen = this.screen;
                if (surfaceScreen != null) {
                    surfaceScreen.start(this.width, this.height);
                }
                this.listener.onVideoSize(this.width, this.height);
            } else if (i3 >= 0 && i3 <= 8388608) {
                byte[] bArr2 = new byte[i3];
                stream2.readFully(i3, bArr2);
                long j6 = j3;
                long j7 = j4 + i3 + 12;
                long currentTimeMillis2 = System.currentTimeMillis();
                long j8 = currentTimeMillis2 - currentTimeMillis;
                if (j8 >= 3000) {
                    this.listener.onStatus("rate", String.valueOf(((j7 * 1000) / j8) / 1024));
                    j7 = j6;
                    currentTimeMillis = currentTimeMillis2;
                }
                if ((4611686018427387904L & j5) != j6) {
                    r6 = 1;
                } else {
                    r6 = 0;
                }
                Trace trace = Trace.INSTANCE;
                if (Trace.getOn()) {
                    j = j7;
                    long j9 = (j5 & 2305843009213693951L) / 1000;
                    if ((j5 & 2305843009213693952L) != j6) {
                        i = 1;
                    } else {
                        i = 0;
                    }
                    trace.log("v.in", "pts=" + j9 + " cfg=" + ((int) r6) + " key=" + i + " n=" + i3);
                } else {
                    j = j7;
                }
                SurfaceScreen surfaceScreen2 = this.screen;
                if (surfaceScreen2 != 0) {
                    if (r6 != 0) {
                        j2 = j6;
                    } else {
                        j2 = j5 & 2305843009213693951L;
                    }
                    if (surfaceScreen2.feed(r6, j2, bArr2)) {
                        if (z && r6 == 0) {
                            this.framed = true;
                            MainActivity$onCreate$2 mainActivity$onCreate$2 = Census.store;
                            String host = this.host;
                            Intrinsics.checkNotNullParameter(host, "host");
                            Census.later(new Census$$ExternalSyntheticLambda3(host, 1));
                            if (Trace.getOn()) {
                                Trace.INSTANCE.log("v.first", "");
                            }
                            status("live", "");
                            stream2 = stream;
                            j3 = j6;
                            j4 = j;
                            i2 = 12;
                            z = false;
                        }
                    } else {
                        return;
                    }
                }
                stream2 = stream;
                j3 = j6;
                j4 = j;
                i2 = 12;
            } else {
                throw new IOException("bad video packet");
            }
        }
    }

    public final void postTouch(JSONObject jSONObject) {
        String str = this.relay;
        if (str != null) {
            boolean areEqual = Intrinsics.areEqual(jSONObject.optString("a"), "move");
            AtomicReference atomicReference = this.pendingMove;
            if (areEqual) {
                if (atomicReference.getAndSet(jSONObject) != null) {
                    return;
                }
            } else {
                atomicReference.set(null);
            }
            try {
                this.touchIo.execute(new Lg$$ExternalSyntheticLambda2(jSONObject, this, str, 5));
            } catch (RuntimeException unused) {
            }
        }
    }

    public final void press(int i) {
        key(0, i, 0, 0);
        key(1, i, 0, 0);
    }

    public final void pushServer(Adb adb, boolean z) {
        if (!z) {
            byte[] bArr = (byte[]) this.jar.invoke();
            String md5Of = md5Of(bArr);
            ConcurrentHashMap concurrentHashMap = Adb.ASKING;
            adb.put("/data/local/tmp/scrcpy-server.jar", bArr, false);
            for (int i = 0; i < 20; i++) {
                String obj = StringsKt.trim(adb.shell(120000L, "md5sum /data/local/tmp/scrcpy-server.jar 2>/dev/null || wc -c < /data/local/tmp/scrcpy-server.jar")).toString();
                if (!StringsKt__StringsJVMKt.startsWith(obj, false, md5Of) && !obj.equals(String.valueOf(bArr.length))) {
                    try {
                        Thread.sleep(150L);
                    } catch (InterruptedException unused) {
                    }
                } else {
                    return;
                }
            }
            throw new IOException("could not copy scrcpy-server to the TV");
        }
    }

    public final boolean ready() {
        if ((this.relaying || this.control != null || this.resting) && !this.stopped) {
            return true;
        }
        return false;
    }

    public final void relayEnd(boolean z, String str) {
        this.relaying = false;
        if (z) {
            SurfaceScreen surfaceScreen = this.screen;
            if (surfaceScreen != null) {
                surfaceScreen.closeDec();
            }
            if (!this.stopped) {
                status("closed", str);
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:24:0x008f, code lost:
    
        r9 = r4.group(1);
        kotlin.jvm.internal.Intrinsics.checkNotNull(r9);
        r1 = java.util.Locale.ROOT;
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, "ROOT");
        r9 = r9.toUpperCase(r1);
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r9, "toUpperCase(...)");
        r8.listener.onNetwork(r9, r6, r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00ab, code lost:
    
        return;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void reportNetwork(String str) {
        boolean z;
        Matcher m7m = Census$$ExternalSyntheticOutline0.m7m("inet (100\\.(?:6[4-9]|[7-9]\\d|1[01]\\d|12[0-7])\\.[0-9.]+)/", "compile(...)", str, "input", str);
        Intrinsics.checkNotNullExpressionValue(m7m, "matcher(...)");
        MatcherMatchResult access$findNext = MathKt.access$findNext(m7m, 0, str);
        if (access$findNext == null || (r0 = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)) == null) {
            String str2 = "";
        }
        String[] array = Pattern.compile("(?m)^\\d+: ").split(str);
        Intrinsics.checkNotNullParameter(array, "array");
        int i = 0;
        while (true) {
            if (i < array.length) {
                z = true;
            } else {
                z = false;
            }
            if (z) {
                int i2 = i + 1;
                try {
                    String str3 = array[i];
                    Matcher matcher = Pattern.compile("inet ([0-9.]+)/").matcher(str3);
                    Matcher matcher2 = Pattern.compile("link/ether ([0-9a-f:]{17})").matcher(str3);
                    if (matcher.find() && matcher2.find()) {
                        String group = matcher.group(1);
                        Intrinsics.checkNotNull(group);
                        if (StringsKt__StringsJVMKt.startsWith(group, false, "192.168.") || StringsKt__StringsJVMKt.startsWith(group, false, "10.")) {
                            break;
                        }
                        Pattern compile = Pattern.compile("172\\.(1[6-9]|2\\d|3[01])\\..*");
                        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                        if (compile.matcher(group).matches()) {
                            break;
                        }
                    }
                    i = i2;
                } catch (ArrayIndexOutOfBoundsException e) {
                    throw new NoSuchElementException(e.getMessage());
                }
            } else {
                return;
            }
        }
    }

    public final void resetVideo() {
        if (this.relaying) {
            long nanoTime = System.nanoTime();
            if (nanoTime - this.rejoinedAt >= 5000000000L) {
                this.rejoinedAt = nanoTime;
                WireLog.all.add("·", "picture " + this.host + " joining TV Setup's picture again for a key frame");
                this.rejoin = true;
                HttpURLConnection httpURLConnection = this.feedConn;
                if (httpURLConnection != null) {
                    httpURLConnection.disconnect();
                    return;
                }
                return;
            }
            return;
        }
        if (!this.framed) {
            return;
        }
        send(new byte[]{17});
    }

    public final void rest() {
        if (this.wantControl && !this.wantVideo && this.audio == null && !this.stopped) {
            synchronized (this.restLock) {
                if (this.resting) {
                    return;
                }
                Adb.Stream stream = this.control;
                if (stream == null) {
                    return;
                }
                this.resting = true;
                this.wanted = false;
                this.control = null;
                try {
                    stream.close();
                } catch (Exception unused) {
                }
                try {
                    Adb.Stream stream2 = this.server;
                    if (stream2 != null) {
                        stream2.close();
                    }
                } catch (Exception unused2) {
                }
            }
        }
    }

    public final String search(String query) {
        Intrinsics.checkNotNullParameter(query, "query");
        Adb adb = this.adb;
        if (adb != null) {
            try {
                TvShell tvShell = TvShell.INSTANCE;
                String obj = StringsKt.trim(adb.shell(120000L, TvShell.search(query))).toString();
                if (!Intrinsics.areEqual(obj, "yt")) {
                    if (Intrinsics.areEqual(obj, "gs")) {
                    }
                }
                return obj;
            } catch (Exception unused) {
                return null;
            }
        }
        return null;
    }

    public final Future send(byte[] bArr) {
        Tv tv = this.carrier;
        if (tv != null && tv.control != null && !tv.stopped) {
            return tv.send(bArr);
        }
        if (this.resting) {
            synchronized (this.restLock) {
                if (this.resting) {
                    this.wanted = true;
                    this.restLock.notifyAll();
                }
            }
        } else if (this.control == null) {
            return null;
        }
        if (!this.io.isShutdown()) {
            this.ownUse = System.currentTimeMillis();
            try {
                return this.io.submit(new Guard$$ExternalSyntheticLambda5(11, this, bArr));
            } catch (RuntimeException unused) {
                return null;
            }
        }
        return null;
    }

    /* JADX WARN: Code restructure failed: missing block: B:196:0x03e1, code lost:
    
        if (r0 == null) goto L214;
     */
    /* JADX WARN: Code restructure failed: missing block: B:197:0x03e3, code lost:
    
        r0.close();
     */
    /* JADX WARN: Code restructure failed: missing block: B:271:0x044a, code lost:
    
        if (r0 == null) goto L214;
     */
    /* JADX WARN: Removed duplicated region for block: B:142:0x0284 A[Catch: all -> 0x001e, TryCatch #11 {all -> 0x001e, blocks: (B:3:0x000e, B:5:0x0016, B:6:0x0021, B:34:0x008a, B:36:0x0090, B:37:0x0097, B:39:0x00a9, B:40:0x00ae, B:42:0x00bc, B:44:0x00c2, B:47:0x00cb, B:49:0x00ce, B:51:0x00d2, B:53:0x00d6, B:55:0x00da, B:58:0x0106, B:64:0x0117, B:66:0x00e3, B:69:0x00f0, B:72:0x00f9, B:75:0x0104, B:76:0x0102, B:77:0x00f7, B:78:0x00ee, B:79:0x0148, B:81:0x0150, B:82:0x0155, B:233:0x015d, B:235:0x0165, B:84:0x016a, B:86:0x0177, B:87:0x017c, B:89:0x018f, B:95:0x019c, B:99:0x01a4, B:100:0x01ab, B:103:0x01b1, B:105:0x01be, B:108:0x01c3, B:109:0x01ca, B:110:0x01cb, B:112:0x01d5, B:114:0x01d9, B:117:0x01f5, B:120:0x01fe, B:123:0x0207, B:126:0x0211, B:128:0x021b, B:129:0x023a, B:131:0x0240, B:133:0x0244, B:136:0x0258, B:138:0x025a, B:142:0x0284, B:143:0x02a1, B:147:0x02b4, B:148:0x02c8, B:150:0x02cc, B:151:0x02d8, B:153:0x02dc, B:154:0x02eb, B:156:0x02ef, B:157:0x02f7, B:159:0x02fd, B:163:0x0305, B:165:0x031a, B:168:0x0326, B:170:0x033b, B:171:0x034e, B:172:0x0396, B:174:0x039a, B:176:0x039e, B:201:0x0354, B:203:0x035b, B:204:0x0360, B:206:0x0366, B:207:0x0371, B:210:0x037e, B:214:0x0381, B:215:0x0382, B:220:0x0385, B:224:0x0260, B:227:0x026b, B:229:0x0273, B:230:0x0278, B:209:0x0372), top: B:2:0x000e, outer: #8, inners: #0 }] */
    /* JADX WARN: Removed duplicated region for block: B:150:0x02cc A[Catch: all -> 0x001e, TryCatch #11 {all -> 0x001e, blocks: (B:3:0x000e, B:5:0x0016, B:6:0x0021, B:34:0x008a, B:36:0x0090, B:37:0x0097, B:39:0x00a9, B:40:0x00ae, B:42:0x00bc, B:44:0x00c2, B:47:0x00cb, B:49:0x00ce, B:51:0x00d2, B:53:0x00d6, B:55:0x00da, B:58:0x0106, B:64:0x0117, B:66:0x00e3, B:69:0x00f0, B:72:0x00f9, B:75:0x0104, B:76:0x0102, B:77:0x00f7, B:78:0x00ee, B:79:0x0148, B:81:0x0150, B:82:0x0155, B:233:0x015d, B:235:0x0165, B:84:0x016a, B:86:0x0177, B:87:0x017c, B:89:0x018f, B:95:0x019c, B:99:0x01a4, B:100:0x01ab, B:103:0x01b1, B:105:0x01be, B:108:0x01c3, B:109:0x01ca, B:110:0x01cb, B:112:0x01d5, B:114:0x01d9, B:117:0x01f5, B:120:0x01fe, B:123:0x0207, B:126:0x0211, B:128:0x021b, B:129:0x023a, B:131:0x0240, B:133:0x0244, B:136:0x0258, B:138:0x025a, B:142:0x0284, B:143:0x02a1, B:147:0x02b4, B:148:0x02c8, B:150:0x02cc, B:151:0x02d8, B:153:0x02dc, B:154:0x02eb, B:156:0x02ef, B:157:0x02f7, B:159:0x02fd, B:163:0x0305, B:165:0x031a, B:168:0x0326, B:170:0x033b, B:171:0x034e, B:172:0x0396, B:174:0x039a, B:176:0x039e, B:201:0x0354, B:203:0x035b, B:204:0x0360, B:206:0x0366, B:207:0x0371, B:210:0x037e, B:214:0x0381, B:215:0x0382, B:220:0x0385, B:224:0x0260, B:227:0x026b, B:229:0x0273, B:230:0x0278, B:209:0x0372), top: B:2:0x000e, outer: #8, inners: #0 }] */
    /* JADX WARN: Removed duplicated region for block: B:153:0x02dc A[Catch: all -> 0x001e, TryCatch #11 {all -> 0x001e, blocks: (B:3:0x000e, B:5:0x0016, B:6:0x0021, B:34:0x008a, B:36:0x0090, B:37:0x0097, B:39:0x00a9, B:40:0x00ae, B:42:0x00bc, B:44:0x00c2, B:47:0x00cb, B:49:0x00ce, B:51:0x00d2, B:53:0x00d6, B:55:0x00da, B:58:0x0106, B:64:0x0117, B:66:0x00e3, B:69:0x00f0, B:72:0x00f9, B:75:0x0104, B:76:0x0102, B:77:0x00f7, B:78:0x00ee, B:79:0x0148, B:81:0x0150, B:82:0x0155, B:233:0x015d, B:235:0x0165, B:84:0x016a, B:86:0x0177, B:87:0x017c, B:89:0x018f, B:95:0x019c, B:99:0x01a4, B:100:0x01ab, B:103:0x01b1, B:105:0x01be, B:108:0x01c3, B:109:0x01ca, B:110:0x01cb, B:112:0x01d5, B:114:0x01d9, B:117:0x01f5, B:120:0x01fe, B:123:0x0207, B:126:0x0211, B:128:0x021b, B:129:0x023a, B:131:0x0240, B:133:0x0244, B:136:0x0258, B:138:0x025a, B:142:0x0284, B:143:0x02a1, B:147:0x02b4, B:148:0x02c8, B:150:0x02cc, B:151:0x02d8, B:153:0x02dc, B:154:0x02eb, B:156:0x02ef, B:157:0x02f7, B:159:0x02fd, B:163:0x0305, B:165:0x031a, B:168:0x0326, B:170:0x033b, B:171:0x034e, B:172:0x0396, B:174:0x039a, B:176:0x039e, B:201:0x0354, B:203:0x035b, B:204:0x0360, B:206:0x0366, B:207:0x0371, B:210:0x037e, B:214:0x0381, B:215:0x0382, B:220:0x0385, B:224:0x0260, B:227:0x026b, B:229:0x0273, B:230:0x0278, B:209:0x0372), top: B:2:0x000e, outer: #8, inners: #0 }] */
    /* JADX WARN: Removed duplicated region for block: B:156:0x02ef A[Catch: all -> 0x001e, TryCatch #11 {all -> 0x001e, blocks: (B:3:0x000e, B:5:0x0016, B:6:0x0021, B:34:0x008a, B:36:0x0090, B:37:0x0097, B:39:0x00a9, B:40:0x00ae, B:42:0x00bc, B:44:0x00c2, B:47:0x00cb, B:49:0x00ce, B:51:0x00d2, B:53:0x00d6, B:55:0x00da, B:58:0x0106, B:64:0x0117, B:66:0x00e3, B:69:0x00f0, B:72:0x00f9, B:75:0x0104, B:76:0x0102, B:77:0x00f7, B:78:0x00ee, B:79:0x0148, B:81:0x0150, B:82:0x0155, B:233:0x015d, B:235:0x0165, B:84:0x016a, B:86:0x0177, B:87:0x017c, B:89:0x018f, B:95:0x019c, B:99:0x01a4, B:100:0x01ab, B:103:0x01b1, B:105:0x01be, B:108:0x01c3, B:109:0x01ca, B:110:0x01cb, B:112:0x01d5, B:114:0x01d9, B:117:0x01f5, B:120:0x01fe, B:123:0x0207, B:126:0x0211, B:128:0x021b, B:129:0x023a, B:131:0x0240, B:133:0x0244, B:136:0x0258, B:138:0x025a, B:142:0x0284, B:143:0x02a1, B:147:0x02b4, B:148:0x02c8, B:150:0x02cc, B:151:0x02d8, B:153:0x02dc, B:154:0x02eb, B:156:0x02ef, B:157:0x02f7, B:159:0x02fd, B:163:0x0305, B:165:0x031a, B:168:0x0326, B:170:0x033b, B:171:0x034e, B:172:0x0396, B:174:0x039a, B:176:0x039e, B:201:0x0354, B:203:0x035b, B:204:0x0360, B:206:0x0366, B:207:0x0371, B:210:0x037e, B:214:0x0381, B:215:0x0382, B:220:0x0385, B:224:0x0260, B:227:0x026b, B:229:0x0273, B:230:0x0278, B:209:0x0372), top: B:2:0x000e, outer: #8, inners: #0 }] */
    /* JADX WARN: Removed duplicated region for block: B:159:0x02fd A[Catch: all -> 0x001e, TryCatch #11 {all -> 0x001e, blocks: (B:3:0x000e, B:5:0x0016, B:6:0x0021, B:34:0x008a, B:36:0x0090, B:37:0x0097, B:39:0x00a9, B:40:0x00ae, B:42:0x00bc, B:44:0x00c2, B:47:0x00cb, B:49:0x00ce, B:51:0x00d2, B:53:0x00d6, B:55:0x00da, B:58:0x0106, B:64:0x0117, B:66:0x00e3, B:69:0x00f0, B:72:0x00f9, B:75:0x0104, B:76:0x0102, B:77:0x00f7, B:78:0x00ee, B:79:0x0148, B:81:0x0150, B:82:0x0155, B:233:0x015d, B:235:0x0165, B:84:0x016a, B:86:0x0177, B:87:0x017c, B:89:0x018f, B:95:0x019c, B:99:0x01a4, B:100:0x01ab, B:103:0x01b1, B:105:0x01be, B:108:0x01c3, B:109:0x01ca, B:110:0x01cb, B:112:0x01d5, B:114:0x01d9, B:117:0x01f5, B:120:0x01fe, B:123:0x0207, B:126:0x0211, B:128:0x021b, B:129:0x023a, B:131:0x0240, B:133:0x0244, B:136:0x0258, B:138:0x025a, B:142:0x0284, B:143:0x02a1, B:147:0x02b4, B:148:0x02c8, B:150:0x02cc, B:151:0x02d8, B:153:0x02dc, B:154:0x02eb, B:156:0x02ef, B:157:0x02f7, B:159:0x02fd, B:163:0x0305, B:165:0x031a, B:168:0x0326, B:170:0x033b, B:171:0x034e, B:172:0x0396, B:174:0x039a, B:176:0x039e, B:201:0x0354, B:203:0x035b, B:204:0x0360, B:206:0x0366, B:207:0x0371, B:210:0x037e, B:214:0x0381, B:215:0x0382, B:220:0x0385, B:224:0x0260, B:227:0x026b, B:229:0x0273, B:230:0x0278, B:209:0x0372), top: B:2:0x000e, outer: #8, inners: #0 }] */
    /* JADX WARN: Removed duplicated region for block: B:165:0x031a A[Catch: all -> 0x001e, TryCatch #11 {all -> 0x001e, blocks: (B:3:0x000e, B:5:0x0016, B:6:0x0021, B:34:0x008a, B:36:0x0090, B:37:0x0097, B:39:0x00a9, B:40:0x00ae, B:42:0x00bc, B:44:0x00c2, B:47:0x00cb, B:49:0x00ce, B:51:0x00d2, B:53:0x00d6, B:55:0x00da, B:58:0x0106, B:64:0x0117, B:66:0x00e3, B:69:0x00f0, B:72:0x00f9, B:75:0x0104, B:76:0x0102, B:77:0x00f7, B:78:0x00ee, B:79:0x0148, B:81:0x0150, B:82:0x0155, B:233:0x015d, B:235:0x0165, B:84:0x016a, B:86:0x0177, B:87:0x017c, B:89:0x018f, B:95:0x019c, B:99:0x01a4, B:100:0x01ab, B:103:0x01b1, B:105:0x01be, B:108:0x01c3, B:109:0x01ca, B:110:0x01cb, B:112:0x01d5, B:114:0x01d9, B:117:0x01f5, B:120:0x01fe, B:123:0x0207, B:126:0x0211, B:128:0x021b, B:129:0x023a, B:131:0x0240, B:133:0x0244, B:136:0x0258, B:138:0x025a, B:142:0x0284, B:143:0x02a1, B:147:0x02b4, B:148:0x02c8, B:150:0x02cc, B:151:0x02d8, B:153:0x02dc, B:154:0x02eb, B:156:0x02ef, B:157:0x02f7, B:159:0x02fd, B:163:0x0305, B:165:0x031a, B:168:0x0326, B:170:0x033b, B:171:0x034e, B:172:0x0396, B:174:0x039a, B:176:0x039e, B:201:0x0354, B:203:0x035b, B:204:0x0360, B:206:0x0366, B:207:0x0371, B:210:0x037e, B:214:0x0381, B:215:0x0382, B:220:0x0385, B:224:0x0260, B:227:0x026b, B:229:0x0273, B:230:0x0278, B:209:0x0372), top: B:2:0x000e, outer: #8, inners: #0 }] */
    /* JADX WARN: Removed duplicated region for block: B:179:0x03af  */
    /* JADX WARN: Removed duplicated region for block: B:182:0x03b6  */
    /* JADX WARN: Removed duplicated region for block: B:186:0x03ce  */
    /* JADX WARN: Removed duplicated region for block: B:200:0x0352  */
    /* JADX WARN: Removed duplicated region for block: B:221:0x02f6  */
    /* JADX WARN: Removed duplicated region for block: B:222:0x02ea  */
    /* JADX WARN: Removed duplicated region for block: B:223:0x02d6  */
    /* JADX WARN: Type inference failed for: r5v18, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void session() {
        Adb.Stream stream;
        boolean z;
        String str;
        Adb.Stream stream2;
        int i;
        Adb.Stream stream3;
        Adb.Stream stream4;
        SurfaceScreen surfaceScreen;
        Iterator it;
        SupportAndroid$store$1 supportAndroid$store$1;
        String str2;
        Long l;
        boolean z2;
        ArrayList arrayList = new ArrayList();
        try {
            try {
                Trace trace = Trace.INSTANCE;
                if (Trace.getOn()) {
                    trace.log("s.begin", this.host);
                }
                status("connecting", this.host);
                Adb adb = new Adb(this.dir);
                this.adb = adb;
                Adb connectOrShare$default = Adb.connectOrShare$default(adb, this.host, new AdbLink$$ExternalSyntheticLambda2(2, this));
                this.adb = connectOrShare$default;
                if (this.stopped) {
                    this.control = null;
                    this.resting = false;
                    SurfaceScreen surfaceScreen2 = this.screen;
                    if (surfaceScreen2 != null) {
                        surfaceScreen2.closeDec();
                    }
                    if (this.capture != null) {
                        endCapture(arrayList);
                    }
                    this.capture = null;
                    giveBackSound();
                    Iterator it2 = arrayList.iterator();
                    Intrinsics.checkNotNullExpressionValue(it2, "iterator(...)");
                    while (it2.hasNext()) {
                        Object next = it2.next();
                        Intrinsics.checkNotNullExpressionValue(next, "next(...)");
                        try {
                            ((Adb.Stream) next).close();
                        } catch (Exception unused) {
                        }
                    }
                    try {
                        Adb.Stream stream5 = this.server;
                        if (stream5 != null) {
                            stream5.close();
                        }
                    } catch (Exception unused2) {
                    }
                    letGo();
                    this.io.shutdownNow();
                    return;
                }
                if (Trace.getOn()) {
                    trace.log("s.adb", this.host);
                }
                Facts startFacts = startFacts(connectOrShare$default, (byte[]) this.jar.invoke());
                if (Trace.getOn()) {
                    Trace.INSTANCE.log("s.facts", "");
                }
                status("starting", startFacts.model);
                Fleet$$ExternalSyntheticLambda0 fleet$$ExternalSyntheticLambda0 = new Fleet$$ExternalSyntheticLambda0(connectOrShare$default, 16);
                try {
                    PrivateListen privateListen = PrivateListen.INSTANCE;
                    Integer num = startFacts.quietMark;
                    if (num != null && PrivateListen.holders.get() <= 0) {
                        PrivateListen.putBack(fleet$$ExternalSyntheticLambda0, num);
                    }
                } catch (Exception unused3) {
                }
                if (!this.hand && this.wantVideo && (l = startFacts.memKb) != null) {
                    long j = 1;
                    long j2 = 1572863;
                    if (j < 1572863) {
                        long j3 = 1572863 % 1;
                        if (j3 < 0) {
                            j3++;
                        }
                        long j4 = j % 1;
                        if (j4 < 0) {
                            j4++;
                        }
                        long j5 = (j3 - j4) % 1;
                        if (j5 < 0) {
                            j5++;
                        }
                        j2 = 1572863 - j5;
                    }
                    long longValue = l.longValue();
                    if (j <= longValue && longValue <= j2) {
                        z2 = true;
                    } else {
                        z2 = false;
                    }
                    if (z2) {
                        this.capped = true;
                        this.video = Fleet.videoOpts(this.quality, this.maxSide, this.bitRate, true);
                        Long l2 = startFacts.memKb;
                        Intrinsics.checkNotNull(l2);
                        status("lowram", (l2.longValue() / 1024) + " MB");
                    }
                }
                if (this.listener.wantsNetwork()) {
                    reportNetwork(startFacts.ipAddr);
                }
                if (this.listener.wantsPass()) {
                    try {
                        AdbPrompt adbPrompt = AdbPrompt.INSTANCE;
                        String str3 = AdbPrompt.token(connectOrShare$default);
                        if (str3 != null) {
                            this.listener.onPass(str3);
                        }
                    } catch (IOException unused4) {
                    }
                }
                pushServer(connectOrShare$default, startFacts.jarOk);
                Trace trace2 = Trace.INSTANCE;
                if (Trace.getOn()) {
                    Trace.INSTANCE.log("s.pushed", "");
                }
                ?? obj = new Object();
                obj.element = this.audio;
                int i2 = startFacts.sdk;
                this.sdkSeen = i2;
                Object obj2 = obj.element;
                if (obj2 != null && this.audioShare && i2 >= 33) {
                    z = true;
                } else {
                    z = false;
                }
                if (obj2 != null && this.audioShare && !z && i2 >= 30) {
                    status("audio", "noshare");
                }
                if (obj.element != null && i2 < 30) {
                    status("audio", "unsupported");
                    obj.element = null;
                    if (!this.wantVideo && !this.wantControl) {
                        throw new IOException("this TV cannot send its sound (Android 11 or newer is needed)");
                    }
                }
                if (Intrinsics.areEqual(obj.element, "opus") && this.audioSink != null) {
                    String str4 = (String) obj.element;
                    String encoders = encoders(connectOrShare$default);
                    this.audioSink.getClass();
                    this.audioSink.getClass();
                    if (Intrinsics.areEqual(str4, "opus") && encoders != null && StringsKt.contains(encoders, "--audio-codec=", false) && !StringsKt.contains(encoders, "--audio-codec=opus", false) && StringsKt.contains(encoders, "--audio-codec=aac", false)) {
                        str4 = "aac";
                    }
                    obj.element = str4;
                    if (!Intrinsics.areEqual(str4, "opus")) {
                        WireLog.all.add("·", "picture " + this.host + " no Opus encoder on the TV: sound as " + obj.element);
                    }
                }
                String str5 = (String) obj.element;
                if (str5 != null && (supportAndroid$store$1 = this.audioSink) != null) {
                    AudioOut audioOut = (AudioOut) supportAndroid$store$1.$p;
                    audioOut.getClass();
                    if (str5.equals("aac")) {
                        str2 = "audio/mp4a-latm";
                    } else {
                        str2 = "audio/opus";
                    }
                    audioOut.mime = str2;
                }
                if (this.wantVideo) {
                    String str6 = this.encoder;
                    if (!str6.equals("hw")) {
                        if (str6.equals("sw")) {
                            str = softFor(connectOrShare$default);
                        } else {
                            str = (String) softEncoder.get(this.host);
                        }
                        if (str != null) {
                            WireLog.all.add("·", "picture " + this.host + " encoder " + str);
                        }
                        boolean z3 = z;
                        arrayList.addAll(session$startServer(connectOrShare$default, this, str, obj, i2, z3));
                        if (obj.element != null && !z3 && i2 >= 33) {
                            Thread thread = new Thread(new Guard$$ExternalSyntheticLambda5(8, this, fleet$$ExternalSyntheticLambda0), "tv-quiet");
                            thread.setDaemon(true);
                            thread.start();
                        }
                        if (!this.wantVideo) {
                            stream2 = (Adb.Stream) arrayList.get(0);
                            i = 1;
                        } else {
                            stream2 = null;
                            i = 0;
                        }
                        if (obj.element == null) {
                            stream3 = (Adb.Stream) arrayList.get(i);
                            i++;
                        } else {
                            stream3 = null;
                        }
                        if (!this.wantControl) {
                            stream4 = (Adb.Stream) arrayList.get(i);
                        } else {
                            stream4 = null;
                        }
                        this.control = stream4;
                        if (obj.element != null) {
                            this.capture = arrayList;
                        }
                        if (stream3 != null && (stream2 != null || stream4 != null)) {
                            Thread thread2 = new Thread(new Lg$$ExternalSyntheticLambda2(this, stream3, obj, 3), "scrcpy-audio");
                            thread2.setDaemon(true);
                            thread2.start();
                        }
                        if (stream2 == null) {
                            if (this.encoder.equals("auto") && str == null) {
                                Thread thread3 = new Thread(new Lg$$ExternalSyntheticLambda2(this, connectOrShare$default, stream2, 4), "scrcpy-first-frame");
                                thread3.setDaemon(true);
                                thread3.start();
                            }
                            if (stream4 != null) {
                                Thread thread4 = new Thread(new Tv$$ExternalSyntheticLambda15(this, stream4, 0), "scrcpy-ctl");
                                thread4.setDaemon(true);
                                thread4.start();
                            }
                            play(stream2);
                        } else if (stream4 != null) {
                            status("live", "");
                            Object obj3 = stream4;
                            while (true) {
                                try {
                                    deviceMessages((Adb.Stream) obj3);
                                } catch (IOException unused5) {
                                }
                                if (!backWanted(connectOrShare$default)) {
                                    break;
                                }
                                Object obj4 = session$startServer(connectOrShare$default, this, str, obj, i2, z3).get(0);
                                synchronized (this.restLock) {
                                    this.control = (Adb.Stream) obj4;
                                    this.resting = false;
                                    this.restLock.notifyAll();
                                }
                                obj3 = obj4;
                            }
                        } else if (stream3 != null) {
                            status("live", "");
                            Object obj5 = obj.element;
                            Intrinsics.checkNotNull(obj5);
                            hear(stream3, (String) obj5);
                        }
                        if (!this.stopped && !this.stalled) {
                            status("closed", "");
                        }
                        this.control = null;
                        this.resting = false;
                        surfaceScreen = this.screen;
                        if (surfaceScreen != null) {
                            surfaceScreen.closeDec();
                        }
                        if (this.capture != null) {
                            endCapture(arrayList);
                        }
                        this.capture = null;
                        giveBackSound();
                        it = arrayList.iterator();
                        Intrinsics.checkNotNullExpressionValue(it, "iterator(...)");
                        while (it.hasNext()) {
                            Object next2 = it.next();
                            Intrinsics.checkNotNullExpressionValue(next2, "next(...)");
                            try {
                                ((Adb.Stream) next2).close();
                            } catch (Exception unused6) {
                            }
                        }
                        stream = this.server;
                    }
                }
                str = null;
                if (str != null) {
                }
                boolean z32 = z;
                arrayList.addAll(session$startServer(connectOrShare$default, this, str, obj, i2, z32));
                if (obj.element != null) {
                    Thread thread5 = new Thread(new Guard$$ExternalSyntheticLambda5(8, this, fleet$$ExternalSyntheticLambda0), "tv-quiet");
                    thread5.setDaemon(true);
                    thread5.start();
                }
                if (!this.wantVideo) {
                }
                if (obj.element == null) {
                }
                if (!this.wantControl) {
                }
                this.control = stream4;
                if (obj.element != null) {
                }
                if (stream3 != null) {
                    Thread thread22 = new Thread(new Lg$$ExternalSyntheticLambda2(this, stream3, obj, 3), "scrcpy-audio");
                    thread22.setDaemon(true);
                    thread22.start();
                }
                if (stream2 == null) {
                }
                if (!this.stopped) {
                    status("closed", "");
                }
                this.control = null;
                this.resting = false;
                surfaceScreen = this.screen;
                if (surfaceScreen != null) {
                }
                if (this.capture != null) {
                }
                this.capture = null;
                giveBackSound();
                it = arrayList.iterator();
                Intrinsics.checkNotNullExpressionValue(it, "iterator(...)");
                while (it.hasNext()) {
                }
                stream = this.server;
            } catch (Exception unused7) {
                letGo();
                this.io.shutdownNow();
            }
        } catch (Throwable th) {
            try {
                if (!this.stopped && !this.stalled) {
                    String message = th.getMessage();
                    if (message == null) {
                        message = th.getClass().getSimpleName();
                    }
                    status("error", message);
                }
                this.control = null;
                this.resting = false;
                SurfaceScreen surfaceScreen3 = this.screen;
                if (surfaceScreen3 != null) {
                    surfaceScreen3.closeDec();
                }
                if (this.capture != null) {
                    endCapture(arrayList);
                }
                this.capture = null;
                giveBackSound();
                Iterator it3 = arrayList.iterator();
                Intrinsics.checkNotNullExpressionValue(it3, "iterator(...)");
                while (it3.hasNext()) {
                    Object next3 = it3.next();
                    Intrinsics.checkNotNullExpressionValue(next3, "next(...)");
                    try {
                        ((Adb.Stream) next3).close();
                    } catch (Exception unused8) {
                    }
                }
                stream = this.server;
            } catch (Throwable th2) {
                this.control = null;
                this.resting = false;
                SurfaceScreen surfaceScreen4 = this.screen;
                if (surfaceScreen4 != null) {
                    surfaceScreen4.closeDec();
                }
                if (this.capture != null) {
                    endCapture(arrayList);
                }
                this.capture = null;
                giveBackSound();
                Iterator it4 = arrayList.iterator();
                Intrinsics.checkNotNullExpressionValue(it4, "iterator(...)");
                while (it4.hasNext()) {
                    Object next4 = it4.next();
                    Intrinsics.checkNotNullExpressionValue(next4, "next(...)");
                    try {
                        ((Adb.Stream) next4).close();
                    } catch (Exception unused9) {
                    }
                }
                try {
                    Adb.Stream stream6 = this.server;
                    if (stream6 != null) {
                        stream6.close();
                    }
                } catch (Exception unused10) {
                }
                letGo();
                this.io.shutdownNow();
                throw th2;
            }
        }
    }

    public final void setClipboard(boolean z, String t) {
        Intrinsics.checkNotNullParameter(t, "t");
        byte[] bytes = t.getBytes(Charsets.UTF_8);
        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        byte[] array = ByteBuffer.allocate(bytes.length + 14).put((byte) 9).putLong(0L).put(z ? (byte) 1 : (byte) 0).putInt(bytes.length).put(bytes).array();
        Intrinsics.checkNotNullExpressionValue(array, "array(...)");
        send(array);
    }

    public final String shell(String cmd) {
        Intrinsics.checkNotNullParameter(cmd, "cmd");
        Adb adb = this.adb;
        if (adb != null) {
            ConcurrentHashMap concurrentHashMap = Adb.ASKING;
            String shell = adb.shell(120000L, cmd);
            if (shell != null) {
                return shell;
            }
            return "";
        }
        return "";
    }

    public final String softFor(Adb adb) {
        Object obj;
        Object obj2;
        String str;
        ConcurrentHashMap concurrentHashMap = softName;
        String str2 = this.host;
        String str3 = (String) concurrentHashMap.get(str2);
        if (str3 != null) {
            return str3;
        }
        String encoders = encoders(adb);
        if (encoders == null) {
            return null;
        }
        List list = SequencesKt.toList(new GeneratorSequence(Regex.findAll$default(new Regex("--video-codec=h264 --video-encoder=(\\S+)(?:\\s+\\((\\w+)\\))?"), encoders), new Bloat$$ExternalSyntheticLambda1(22), 2));
        Iterator it = list.iterator();
        while (true) {
            if (it.hasNext()) {
                obj = it.next();
                if (Intrinsics.areEqual(((Pair) obj).second, "sw")) {
                    break;
                }
            } else {
                obj = null;
                break;
            }
        }
        Pair pair = (Pair) obj;
        if (pair == null || (str = (String) pair.first) == null) {
            Iterator it2 = list.iterator();
            while (true) {
                if (it2.hasNext()) {
                    obj2 = it2.next();
                    Pair pair2 = (Pair) obj2;
                    if (((CharSequence) pair2.second).length() == 0 || Intrinsics.areEqual(pair2.second, "hybrid")) {
                        String str4 = (String) pair2.first;
                        if (StringsKt__StringsJVMKt.startsWith(str4, false, "OMX.google.") || StringsKt__StringsJVMKt.startsWith(str4, false, "c2.android.")) {
                            break;
                        }
                    }
                } else {
                    obj2 = null;
                    break;
                }
            }
            Pair pair3 = (Pair) obj2;
            if (pair3 != null) {
                str = (String) pair3.first;
            } else {
                str = null;
            }
        }
        if (str == null) {
            WireLog.all.add("·", "picture " + str2 + " no software encoder");
            return null;
        }
        concurrentHashMap.put(str2, str);
        return str;
    }

    /* JADX WARN: Code restructure failed: missing block: B:20:0x0086, code lost:
    
        if (r3.length() == 32) goto L26;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Facts startFacts(Adb adb, byte[] bArr) {
        String str;
        String str2;
        Object obj;
        String str3;
        boolean areEqual;
        Object obj2;
        Object obj3;
        int i;
        Object obj4;
        Object obj5;
        String obj6;
        Object obj7 = "";
        if (!this.wake) {
            str = "";
        } else {
            str = "input keyevent KEYCODE_WAKEUP; ";
        }
        if (!this.listener.wantsNetwork()) {
            str2 = "";
        } else {
            str2 = "; ip addr show";
        }
        String m = Census$$ExternalSyntheticOutline0.m(str, "getprop ro.product.model; echo '#tvr-sep#'; getprop ro.build.version.sdk; echo '#tvr-sep#'; if [ -f /data/local/tmp/scrcpy-server.jar ]; then wc -c < /data/local/tmp/scrcpy-server.jar; md5sum /data/local/tmp/scrcpy-server.jar 2>/dev/null; else echo 0; fi; echo '#tvr-sep#'; grep MemTotal /proc/meminfo; echo '#tvr-sep#'; cat /data/local/tmp/tvr-listen-vol 2>/dev/null; echo '#tvr-sep#'", str2);
        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
        List split$default = StringsKt.split$default(adb.shell(120000L, m), new String[]{"#tvr-sep#"}, 6, 2);
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(split$default));
        Iterator it = split$default.iterator();
        while (it.hasNext()) {
            arrayList.add(StringsKt.trim((String) it.next()).toString());
        }
        if (2 >= arrayList.size()) {
            obj = "";
        } else {
            obj = arrayList.get(2);
        }
        List lines = StringsKt.lines((CharSequence) obj);
        String str4 = (String) CollectionsKt.getOrNull(1, lines);
        String str5 = null;
        if (str4 != null && (obj6 = StringsKt.trim(str4).toString()) != null) {
            str3 = StringsKt.substringBefore(obj6, ' ', obj6);
        }
        str3 = null;
        if (str3 != null) {
            areEqual = str3.equalsIgnoreCase(md5Of(bArr));
        } else {
            String str6 = (String) CollectionsKt.firstOrNull(lines);
            if (str6 != null) {
                str5 = StringsKt.trim(str6).toString();
            }
            areEqual = Intrinsics.areEqual(str5, String.valueOf(bArr.length));
        }
        boolean z = areEqual;
        if (arrayList.size() <= 0) {
            obj2 = "";
        } else {
            obj2 = arrayList.get(0);
        }
        String str7 = (String) obj2;
        if (1 >= arrayList.size()) {
            obj3 = "";
        } else {
            obj3 = arrayList.get(1);
        }
        Integer intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull((String) obj3);
        if (intOrNull != null) {
            i = intOrNull.intValue();
        } else {
            i = 0;
        }
        if (5 >= arrayList.size()) {
            obj4 = "";
        } else {
            obj4 = arrayList.get(5);
        }
        String str8 = (String) obj4;
        if (3 >= arrayList.size()) {
            obj5 = "";
        } else {
            obj5 = arrayList.get(3);
        }
        Long kb = Games.kb((String) obj5, "MemTotal");
        PrivateListen privateListen = PrivateListen.INSTANCE;
        if (4 < arrayList.size()) {
            obj7 = arrayList.get(4);
        }
        return new Facts(str7, i, str8, z, kb, PrivateListen.left((String) obj7));
    }

    public final void status(String str, String str2) {
        WireLog.all.add("·", "picture " + this.host + " " + str + " " + str2);
        this.listener.onStatus(str, str2);
    }

    public final void stop() {
        this.stopped = true;
        this.touchIo.shutdown();
        HttpURLConnection httpURLConnection = this.feedConn;
        if (httpURLConnection != null) {
            Thread thread = new Thread(new Adb$$ExternalSyntheticLambda0(2, httpURLConnection), "tv-relay-stop");
            thread.setDaemon(true);
            thread.start();
        }
        synchronized (this.restLock) {
            this.restLock.notifyAll();
        }
        ArrayList arrayList = this.capture;
        if (arrayList == null) {
            letGo();
            return;
        }
        Thread thread2 = new Thread(new Guard$$ExternalSyntheticLambda5(10, arrayList, this), "scrcpy-stop");
        thread2.setDaemon(true);
        thread2.start();
    }

    public final void text(String t) {
        Intrinsics.checkNotNullParameter(t, "t");
        byte[] bytes = t.getBytes(Charsets.UTF_8);
        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        if (bytes.length == t.length()) {
            byte[] array = ByteBuffer.allocate(bytes.length + 5).put((byte) 1).putInt(bytes.length).put(bytes).array();
            Intrinsics.checkNotNullExpressionValue(array, "array(...)");
            send(array);
        } else {
            setClipboard(false, t);
            key(0, 113, 0, 12288);
            key(0, 50, 0, 12288);
            key(1, 50, 0, 12288);
            key(1, 113, 0, 0);
        }
    }
}
