package dev.tvremote.core.picture;

/* loaded from: classes.dex */
public final class LatencyStats {
    public int fed;
    public long from;
    public long max;
    public int shown;
    public int skipped;
    public long sum;

    public final synchronized void fed() {
        this.fed++;
    }

    public final synchronized String out(long j, boolean z, long j2, int i) {
        long j3;
        try {
            if (this.from < 0) {
                this.from = j2;
            }
            if (z) {
                this.shown++;
            } else {
                this.skipped++;
            }
            long j4 = this.sum + j;
            this.sum = j4;
            if (j > this.max) {
                this.max = j;
            }
            if (j2 - this.from < 1000) {
                return null;
            }
            int i2 = this.shown;
            int i3 = this.skipped;
            int i4 = i2 + i3;
            int i5 = this.fed;
            if (i4 > 0) {
                j3 = j4 / i4;
            } else {
                j3 = 0;
            }
            String str = "in=" + i5 + " out=" + i4 + " drawn=" + i2 + " skipped=" + i3 + " age avg=" + j3 + "ms max=" + this.max + "ms catchUps=" + i;
            this.from = j2;
            this.fed = 0;
            this.shown = 0;
            this.skipped = 0;
            this.sum = 0L;
            this.max = 0L;
            return str;
        } catch (Throwable th) {
            throw th;
        }
    }
}
