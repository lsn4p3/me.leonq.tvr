package dev.tvremote.core.picture;

import android.media.AudioTimestamp;
import android.media.AudioTrack;
import android.media.MediaCodec;
import android.media.audiofx.LoudnessEnhancer;
import dev.tvremote.core.Fleet;
import java.util.ArrayList;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class AudioOut {
    public final int base;
    public MediaCodec codec;
    public int drops;
    public int dry;
    public final ArrayList held;
    public final String host;
    public LoudnessEnhancer loud;
    public float loudAt;
    public volatile String mime;
    public SoundQueue q;
    public int room;
    public final AudioTimestamp stamp;
    public long told;
    public AudioTrack track;
    public long written;

    public AudioOut(boolean z, String host) {
        int i;
        Intrinsics.checkNotNullParameter(host, "host");
        this.host = host;
        boolean z2 = SoundPace.even;
        if (SoundPace.even) {
            i = 24000;
        } else if (z) {
            i = 19200;
        } else {
            i = 7200;
        }
        this.base = i;
        this.q = new SoundQueue(i, getFirst());
        this.held = new ArrayList();
        this.stamp = new AudioTimestamp();
        this.loudAt = 1.0f;
        this.mime = "audio/opus";
    }

    public final void boost(AudioTrack audioTrack) {
        boolean z;
        float f = Fleet.times;
        this.loudAt = f;
        try {
            audioTrack.setVolume(Math.min(1.0f, f));
        } catch (Exception unused) {
        }
        try {
            if (this.loudAt > 1.0f || this.loud != null) {
                LoudnessEnhancer loudnessEnhancer = this.loud;
                if (loudnessEnhancer == null) {
                    loudnessEnhancer = new LoudnessEnhancer(audioTrack.getAudioSessionId());
                    this.loud = loudnessEnhancer;
                }
                float f2 = this.loudAt;
                if (f2 > 1.0f) {
                    loudnessEnhancer.setTargetGain((int) (2000 * Math.log10(f2)));
                }
                if (this.loudAt > 1.0f) {
                    z = true;
                } else {
                    z = false;
                }
                loudnessEnhancer.setEnabled(z);
            }
        } catch (Exception unused2) {
        }
    }

    public final int getFirst() {
        int i;
        boolean z = SoundPace.even;
        Integer num = (Integer) SoundPace.learned.get(this.host);
        if (num != null) {
            i = num.intValue();
        } else {
            i = 0;
        }
        return Math.max(this.base, Math.min(28800, (i * 48000) / 1000));
    }

    public final void release() {
        MediaCodec mediaCodec = this.codec;
        if (mediaCodec != null) {
            try {
                mediaCodec.stop();
            } catch (Exception unused) {
            }
            try {
                mediaCodec.release();
            } catch (Exception unused2) {
            }
        }
        this.codec = null;
        LoudnessEnhancer loudnessEnhancer = this.loud;
        if (loudnessEnhancer != null) {
            try {
                loudnessEnhancer.release();
            } catch (Exception unused3) {
            }
        }
        this.loud = null;
        this.loudAt = 1.0f;
        AudioTrack audioTrack = this.track;
        if (audioTrack != null) {
            try {
                audioTrack.stop();
            } catch (Exception unused4) {
            }
            try {
                audioTrack.release();
            } catch (Exception unused5) {
            }
        }
        this.track = null;
    }
}
