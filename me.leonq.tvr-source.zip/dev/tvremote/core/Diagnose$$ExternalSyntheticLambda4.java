package dev.tvremote.core;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.concurrent.Callable;
import java.util.regex.Pattern;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final /* synthetic */ class Diagnose$$ExternalSyntheticLambda4 implements Callable {
    @Override // java.util.concurrent.Callable
    public final Object call() {
        boolean z;
        Function0 function0 = Lan.wifi;
        if (Lan.wifi.invoke() == null) {
            try {
                Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
                Intrinsics.checkNotNullExpressionValue(networkInterfaces, "getNetworkInterfaces(...)");
                ArrayList<NetworkInterface> list = Collections.list(networkInterfaces);
                Intrinsics.checkNotNullExpressionValue(list, "list(...)");
                if (!list.isEmpty()) {
                    loop0: for (NetworkInterface networkInterface : list) {
                        if (networkInterface.isUp()) {
                            Pattern compile = Pattern.compile("^(tun|tap|utun|ppp|wg|ipsec)", 66);
                            Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                            String name = networkInterface.getName();
                            Intrinsics.checkNotNullExpressionValue(name, "getName(...)");
                            if (compile.matcher(name).find()) {
                                Enumeration<InetAddress> inetAddresses = networkInterface.getInetAddresses();
                                Intrinsics.checkNotNullExpressionValue(inetAddresses, "getInetAddresses(...)");
                                ArrayList<InetAddress> list2 = Collections.list(inetAddresses);
                                Intrinsics.checkNotNullExpressionValue(list2, "list(...)");
                                if (!list2.isEmpty()) {
                                    for (InetAddress inetAddress : list2) {
                                        if (!(inetAddress instanceof Inet4Address) || Diagnose.tailnet(inetAddress) || ((Inet4Address) inetAddress).isLinkLocalAddress()) {
                                        }
                                    }
                                }
                            } else {
                                continue;
                            }
                        }
                    }
                }
            } catch (Exception unused) {
            }
            z = false;
            return Boolean.valueOf(z);
        }
        z = true;
        return Boolean.valueOf(z);
    }
}
