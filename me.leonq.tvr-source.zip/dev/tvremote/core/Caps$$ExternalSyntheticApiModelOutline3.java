package dev.tvremote.core;

/* loaded from: classes.dex */
public abstract /* synthetic */ class Caps$$ExternalSyntheticApiModelOutline3 {
}
