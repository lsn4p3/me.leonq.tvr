package dev.tvremote.core;

import android.app.ActivityManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.InstallSourceInfo;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.util.Log;
import android.view.Surface;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RemoteViews;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import com.android.apksig.internal.apk.ApkSigningBlockUtils;
import com.android.apksig.internal.apk.ContentDigestAlgorithm;
import com.android.apksig.internal.apk.SignatureAlgorithm;
import com.android.apksig.internal.asn1.Asn1TagClass;
import com.android.apksig.internal.asn1.Asn1Type;
import com.android.apksig.internal.util.FileChannelDataSource;
import dev.tvremote.core.Diagnose;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.Adb$$ExternalSyntheticLambda5;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.adb.AdbTls;
import dev.tvremote.core.adb.Pkg;
import dev.tvremote.core.manage.Procs$Keep;
import dev.tvremote.core.ontv.Bloat$$ExternalSyntheticLambda1;
import dev.tvremote.core.ontv.Games;
import dev.tvremote.core.ontv.Home;
import dev.tvremote.core.ontv.Home$$ExternalSyntheticLambda6;
import dev.tvremote.core.ontv.LauncherSwap;
import dev.tvremote.core.ontv.RemoteLabels;
import dev.tvremote.core.ontv.Rescue;
import dev.tvremote.core.ontv.Setup;
import dev.tvremote.core.ontv.Setup$$ExternalSyntheticLambda5;
import dev.tvremote.core.picture.SurfaceScreen;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.picture.TvAndroidKt$$ExternalSyntheticLambda0;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.core.remote.Vidaa$$ExternalSyntheticLambda3;
import dev.tvremote.core.scenes.RemoteSpec$Entry;
import dev.tvremote.core.web.Cancel;
import dev.tvremote.core.web.HttpServer;
import dev.tvremote.core.web.Qr;
import dev.tvremote.guard.Guard$$ExternalSyntheticApiModelOutline0;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda5;
import dev.tvremote.home.HomeQr$$ExternalSyntheticLambda0;
import dev.tvremote.phone.ListenService;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda30;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda9;
import dev.tvremote.phone.MainActivity$onCreate$2;
import dev.tvremote.phone.RemoteWidget;
import dev.tvremote.phone.WorkService;
import dev.tvremote.phone.ir.Ir$Signal;
import dev.tvremote.phone.ir.IrRemoteKt$$ExternalSyntheticLambda49;
import dev.tvremote.phone.manage.Managing;
import dev.tvremote.phone.manage.PhoneSupport;
import dev.tvremote.phone.manage.UpdaterKt;
import dev.tvremote.phone.manage.UpdaterKt$$ExternalSyntheticLambda6;
import dev.tvremote.phone.media.MediaKt$$ExternalSyntheticLambda1;
import dev.tvremote.phone.media.MediaKt$$ExternalSyntheticLambda10;
import dev.tvremote.phone.media.MediaKt$$ExternalSyntheticLambda2;
import dev.tvremote.phone.media.MediaKt$$ExternalSyntheticLambda4;
import dev.tvremote.phone.media.MediaKt$castFile$tick$1;
import dev.tvremote.phone.media.PlayingBar$$ExternalSyntheticLambda13;
import dev.tvremote.phone.media.Talk$$ExternalSyntheticLambda5;
import dev.tvremote.phone.media.TalkKt$$ExternalSyntheticLambda1;
import dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda69;
import dev.tvremote.phone.picker.PickerScreenKt;
import dev.tvremote.phone.remote.TypingKt;
import dev.tvremote.phone.ui.IconButton;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.phone.ui.UiKt;
import dev.tvremote.phone.ui.UiKt$$ExternalSyntheticLambda4;
import dev.tvremote.tvapps.ApkCert$$ExternalSyntheticLambda0;
import dev.tvremote.update.Release;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.CRC32;
import java.util.zip.Deflater;
import java.util.zip.Inflater;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyList;
import kotlin.collections.EmptyMap;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$IntRef;
import kotlin.jvm.internal.Ref$LongRef;
import kotlin.jvm.internal.Ref$ObjectRef;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgression;
import kotlin.ranges.IntProgressionIterator;
import kotlin.ranges.IntRange;
import kotlin.sequences.ConstrainedOnceSequence;
import kotlin.sequences.Sequence;
import kotlin.sequences.SequencesKt;
import kotlin.text.Charsets;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.Regex$$ExternalSyntheticLambda0;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.conscrypt.PSKKeyManager;
import org.conscrypt.R;
import org.conscrypt.metrics.ConscryptStatsLog;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public abstract class Fleet {
    public static volatile float times = 1.0f;

    /* loaded from: classes.dex */
    public final class Info {
        public final String android;
        public final List apps;
        public final long diskFree;
        public final long diskTotal;
        public final String model;
        public final long ram;
        public final int sdk;
        public final String setup;

        public Info(String model, String android, int i, long j, long j2, long j3, List list, String str) {
            Intrinsics.checkNotNullParameter(model, "model");
            Intrinsics.checkNotNullParameter(android, "android");
            this.model = model;
            this.android = android;
            this.sdk = i;
            this.diskTotal = j;
            this.diskFree = j2;
            this.ram = j3;
            this.apps = list;
            this.setup = str;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof Info)) {
                return false;
            }
            Info info = (Info) obj;
            return Intrinsics.areEqual(this.model, info.model) && Intrinsics.areEqual(this.android, info.android) && this.sdk == info.sdk && this.diskTotal == info.diskTotal && this.diskFree == info.diskFree && this.ram == info.ram && Intrinsics.areEqual(this.apps, info.apps) && Intrinsics.areEqual(this.setup, info.setup);
        }

        public final int hashCode() {
            int hashCode = (((this.android.hashCode() + (this.model.hashCode() * 31)) * 31) + this.sdk) * 31;
            long j = this.diskTotal;
            int i = (hashCode + ((int) (j ^ (j >>> 32)))) * 31;
            long j2 = this.diskFree;
            int i2 = (i + ((int) (j2 ^ (j2 >>> 32)))) * 31;
            long j3 = this.ram;
            return this.setup.hashCode() + ((this.apps.hashCode() + ((i2 + ((int) (j3 ^ (j3 >>> 32)))) * 31)) * 31);
        }

        public final String toString() {
            StringBuilder sb = new StringBuilder("Info(model=");
            sb.append(this.model);
            sb.append(", android=");
            sb.append(this.android);
            sb.append(", sdk=");
            sb.append(this.sdk);
            sb.append(", diskTotal=");
            sb.append(this.diskTotal);
            sb.append(", diskFree=");
            sb.append(this.diskFree);
            sb.append(", ram=");
            sb.append(this.ram);
            sb.append(", apps=");
            sb.append(this.apps);
            sb.append(", setup=");
            return Census$$ExternalSyntheticOutline0.m(sb, this.setup, ")");
        }
    }

    public static final String T(String id, Pair... args) {
        Intrinsics.checkNotNullParameter(id, "id");
        Intrinsics.checkNotNullParameter(args, "args");
        ConcurrentHashMap concurrentHashMap = Words.books;
        Pair[] args2 = (Pair[]) Arrays.copyOf(args, args.length);
        Intrinsics.checkNotNullParameter(args2, "args");
        return Words.get(Words.lang, id, (Pair[]) Arrays.copyOf(args2, args2.length));
    }

    public static Tv Tv$default(MainActivity ctx, String host, Surface surface, int i, int i2, boolean z, Tv.Listener listener, boolean z2, int i3, int i4, int i5, String str, boolean z3, String str2, int i6) {
        String str3 = (i6 & PSKKeyManager.MAX_KEY_LENGTH_BYTES) != 0 ? null : "opus";
        boolean z4 = (i6 & 1024) != 0;
        boolean z5 = (i6 & 2048) != 0 ? false : z2;
        int i7 = (i6 & 4096) != 0 ? 64000 : i3;
        int i8 = (i6 & 8192) != 0 ? 0 : i4;
        int i9 = (i6 & 16384) != 0 ? 0 : i5;
        String str4 = (32768 & i6) != 0 ? "auto" : str;
        boolean z6 = (65536 & i6) != 0 ? false : z3;
        String str5 = (i6 & 262144) != 0 ? null : str2;
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Intrinsics.checkNotNullParameter(host, "host");
        Intrinsics.checkNotNullParameter(listener, "listener");
        Context applicationContext = ctx.getApplicationContext();
        SupportAndroid$store$1 supportAndroid$store$1 = Intrinsics.areEqual(str3, "opus") ? new SupportAndroid$store$1(host) : null;
        SurfaceScreen surfaceScreen = surface != null ? new SurfaceScreen(surface, host) : null;
        File filesDir = applicationContext.getFilesDir();
        Intrinsics.checkNotNullExpressionValue(filesDir, "getFilesDir(...)");
        Tv tv = new Tv(filesDir, new TvAndroidKt$$ExternalSyntheticLambda0(applicationContext, 0), host, surfaceScreen, i, i2, z, listener, str3, supportAndroid$store$1, z4, z5, i7, i8, i9, str4, z6, str5);
        if (surfaceScreen != null) {
            surfaceScreen.onFail = new Setup$$ExternalSyntheticLambda5(3, listener);
        }
        if (surfaceScreen != null) {
            surfaceScreen.askKey = new PlayingBar$$ExternalSyntheticLambda13(tv, 1);
        }
        return tv;
    }

    public static String activeApp$shared_release(String str) {
        String str2;
        Triple triple = (Triple) CollectionsKt.firstOrNull(parseApps$shared_release(str));
        if (triple != null) {
            if (!Intrinsics.areEqual(triple.second, "appl")) {
                triple = null;
            }
            if (triple != null && (str2 = (String) triple.first) != null) {
                return str2;
            }
            return "";
        }
        return "";
    }

    public static Bitmap apply(Bitmap bitmap, int i) {
        Matrix matrix = new Matrix();
        switch (i) {
            case 2:
                matrix.setScale(-1.0f, 1.0f);
                break;
            case 3:
                matrix.setRotate(180.0f);
                break;
            case 4:
                matrix.setRotate(180.0f);
                matrix.postScale(-1.0f, 1.0f);
                break;
            case 5:
                matrix.setRotate(90.0f);
                matrix.postScale(-1.0f, 1.0f);
                break;
            case 6:
                matrix.setRotate(90.0f);
                break;
            case 7:
                matrix.setRotate(-90.0f);
                matrix.postScale(-1.0f, 1.0f);
                break;
            case 8:
                matrix.setRotate(-90.0f);
                break;
            default:
                return bitmap;
        }
        try {
            try {
                Bitmap createBitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
                Intrinsics.checkNotNull(createBitmap);
                if (createBitmap != bitmap) {
                    bitmap.recycle();
                }
                return createBitmap;
            } catch (OutOfMemoryError unused) {
                return bitmap;
            }
        } catch (OutOfMemoryError unused2) {
        }
    }

    public static final void askLink(MainActivity mainActivity, String url, Function0 function0) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Intrinsics.checkNotNullParameter(url, "url");
        Tv tv = mainActivity.tv;
        if (mainActivity.basic == null && tv != null && tv.ready()) {
            Managing managing$android_release = mainActivity.getManaging$android_release();
            String str = mainActivity.host;
            if (str == null) {
                return;
            }
            Managing.open$default(managing$android_release, str, null, ApkSigner$$ExternalSyntheticOutline0.m("fromRemote(() => homePin(", JSONObject.quote(url), "))"), 2);
            return;
        }
        function0.invoke();
    }

    public static final void askText(MainActivity mainActivity, String title, String hint, String ok, String value, Function1 function1) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Intrinsics.checkNotNullParameter(title, "title");
        Intrinsics.checkNotNullParameter(hint, "hint");
        Intrinsics.checkNotNullParameter(ok, "ok");
        Intrinsics.checkNotNullParameter(value, "value");
        EditText input = UiKt.input(mainActivity, hint);
        if (value.length() > 0) {
            input.setText(value);
            input.selectAll();
        }
        FrameLayout inDialog = UiKt.inDialog(mainActivity, input);
        Popup.Builder builder = new Popup.Builder(mainActivity);
        builder.title = title;
        builder.view = inDialog;
        builder.setPositiveButton(ok, new MediaKt$$ExternalSyntheticLambda10(0, input, function1));
        builder.setNegativeButton(T("common.cancel", new Pair[0]), null);
        builder.show();
        input.postDelayed(new Guard$$ExternalSyntheticLambda5(23, input, mainActivity), 150L);
    }

    public static void assertByteOrderLittleEndian(ByteBuffer byteBuffer) {
        if (byteBuffer.order() == ByteOrder.LITTLE_ENDIAN) {
        } else {
            throw new IllegalArgumentException("ByteBuffer byte order must be little endian");
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:168:0x03fc, code lost:
    
        if (r10 == r2[r2.length - 1]) goto L123;
     */
    /* JADX WARN: Type inference failed for: r1v37, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final ScrollView buildAbout(MainActivity mainActivity) {
        int[] iArr;
        Bitmap bitmap;
        Object obj;
        boolean[][] zArr;
        int i;
        int[] iArr2;
        int i2;
        boolean z;
        boolean z2;
        boolean z3;
        boolean z4;
        boolean z5;
        boolean z6;
        int i3;
        int i4;
        LinearLayout col = UiKt.col(mainActivity);
        float f = 16;
        col.setPadding(UiKt.dp(mainActivity, f), UiKt.dp(mainActivity, 20), UiKt.dp(mainActivity, f), UiKt.dp(mainActivity, 24));
        TextView label = UiKt.label(mainActivity, T("about.about", new Pair[0]), 24, UiKt.TEXT);
        Typeface typeface = Typeface.DEFAULT_BOLD;
        label.setTypeface(typeface);
        LinearLayout linearLayout = new LinearLayout(mainActivity);
        linearLayout.setGravity(16);
        linearLayout.addView(label, new LinearLayout.LayoutParams(0, -2, 1.0f));
        IconButton icon = UiKt.icon(mainActivity, "@check", T("drawing.done", new Pair[0]), UiKt.ACCENT);
        icon.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(mainActivity, 12));
        linearLayout.addView(icon, new LinearLayout.LayoutParams(UiKt.dp(mainActivity, 52), UiKt.dp(mainActivity, 44)));
        col.addView(linearLayout);
        ImageView imageView = new ImageView(mainActivity);
        imageView.setImageResource(R.drawable.icon);
        float f2 = 84;
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(UiKt.dp(mainActivity, f2), UiKt.dp(mainActivity, f2));
        layoutParams.gravity = 1;
        layoutParams.topMargin = UiKt.dp(mainActivity, 22);
        col.addView(imageView, layoutParams);
        TextView label2 = UiKt.label(mainActivity, ApkSigner$$ExternalSyntheticOutline0.m("TV Remote ", UpdaterKt.versionLine(mainActivity)), 20, UiKt.TEXT);
        label2.setTypeface(typeface);
        label2.setGravity(17);
        col.addView(label2, UiKt.gap(mainActivity, 10));
        byte[] bytes = "https://tvremote.pages.dev/dl/tv-remote.apk".getBytes(Charsets.UTF_8);
        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        Iterator it = new IntProgression(1, 10, 1).iterator();
        while (true) {
            IntProgressionIterator intProgressionIterator = (IntProgressionIterator) it;
            boolean z7 = intProgressionIterator.hasNext;
            iArr = Qr.DATA;
            bitmap = null;
            if (z7) {
                obj = intProgressionIterator.next();
                int intValue = ((Number) obj).intValue();
                if (intValue < 10) {
                    i4 = 8;
                } else {
                    i4 = 16;
                }
                if ((((bytes.length * 8) + (i4 + 4)) + 7) / 8 <= iArr[intValue - 1]) {
                    break;
                }
            } else {
                obj = null;
                break;
            }
        }
        Integer num = (Integer) obj;
        if (num != null) {
            int intValue2 = num.intValue();
            int i5 = intValue2 - 1;
            int i6 = iArr[i5];
            ArrayList arrayList = new ArrayList();
            Qr.modules$put(arrayList, 4, 4);
            int length = bytes.length;
            if (intValue2 < 10) {
                i = 8;
            } else {
                i = 16;
            }
            Qr.modules$put(arrayList, length, i);
            for (byte b : bytes) {
                Qr.modules$put(arrayList, b & 255, 8);
            }
            int i7 = i6 * 8;
            Qr.modules$put(arrayList, 0, Math.min(4, i7 - arrayList.size()));
            while (arrayList.size() % 8 != 0) {
                arrayList.add(Boolean.FALSE);
            }
            loop3: while (true) {
                int i8 = 236;
                while (arrayList.size() < i7) {
                    Qr.modules$put(arrayList, i8, 8);
                    if (i8 == 236) {
                        i8 = 17;
                    }
                }
            }
            int[] iArr3 = new int[i6];
            for (int i9 = 0; i9 < i6; i9++) {
                Iterator it2 = MathKt.until(0, 8).iterator();
                int i10 = 0;
                while (((IntProgressionIterator) it2).hasNext) {
                    i10 = (i10 << 1) | (((Boolean) arrayList.get((i9 * 8) + ((IntProgressionIterator) it2).nextInt())).booleanValue() ? 1 : 0);
                }
                iArr3[i9] = i10;
            }
            int i11 = Qr.BLOCKS[i5];
            int i12 = i6 / i11;
            ArrayList arrayList2 = new ArrayList();
            ArrayList arrayList3 = new ArrayList();
            int i13 = 0;
            int i14 = 0;
            while (true) {
                iArr2 = Qr.EC;
                if (i14 >= i11) {
                    break;
                }
                if (i14 >= i11 - (i6 % i11)) {
                    i3 = 1;
                } else {
                    i3 = 0;
                }
                int i15 = i3 + i12 + i13;
                MathKt.copyOfRangeToIndexCheck(i15, i6);
                int[] copyOfRange = Arrays.copyOfRange(iArr3, i13, i15);
                Intrinsics.checkNotNullExpressionValue(copyOfRange, "copyOfRange(...)");
                arrayList2.add(copyOfRange);
                int i16 = iArr2[i5];
                char c = 0;
                int[] iArr4 = new int[i16];
                int i17 = i16 - 1;
                iArr4[i17] = 1;
                int[] iArr5 = iArr3;
                int i18 = 0;
                int i19 = 1;
                while (i18 < i16) {
                    int i20 = i18;
                    int i21 = 0;
                    while (i21 < i16) {
                        int i22 = i21;
                        int remainder$mul = Qr.remainder$mul(iArr4[i22], i19);
                        iArr4[i22] = remainder$mul;
                        i21 = i22 + 1;
                        if (i21 < i16) {
                            iArr4[i22] = remainder$mul ^ iArr4[i21];
                        }
                    }
                    i19 = Qr.remainder$mul(i19, 2);
                    i18 = i20 + 1;
                }
                int[] iArr6 = new int[i16];
                int length2 = copyOfRange.length;
                int i23 = i11;
                int i24 = 0;
                while (i24 < length2) {
                    int i25 = length2;
                    int i26 = copyOfRange[i24] ^ iArr6[c];
                    int i27 = i24;
                    int[] iArr7 = iArr4;
                    System.arraycopy(iArr6, 1, iArr6, 0, i17);
                    iArr6[i17] = 0;
                    for (int i28 = 0; i28 < i16; i28++) {
                        iArr6[i28] = iArr6[i28] ^ Qr.remainder$mul(iArr7[i28], i26);
                    }
                    i24 = i27 + 1;
                    iArr4 = iArr7;
                    length2 = i25;
                    c = 0;
                }
                arrayList3.add(iArr6);
                i14++;
                iArr3 = iArr5;
                i13 = i15;
                i11 = i23;
            }
            ArrayList arrayList4 = new ArrayList();
            if (i12 >= 0) {
                int i29 = 0;
                while (true) {
                    Iterator it3 = arrayList2.iterator();
                    Intrinsics.checkNotNullExpressionValue(it3, "iterator(...)");
                    while (it3.hasNext()) {
                        Object next = it3.next();
                        Intrinsics.checkNotNullExpressionValue(next, "next(...)");
                        int[] iArr8 = (int[]) next;
                        if (i29 < iArr8.length) {
                            arrayList4.add(Integer.valueOf(iArr8[i29]));
                        }
                    }
                    if (i29 == i12) {
                        break;
                    }
                    i29++;
                }
            }
            int i30 = iArr2[i5];
            for (int i31 = 0; i31 < i30; i31++) {
                Iterator it4 = arrayList3.iterator();
                Intrinsics.checkNotNullExpressionValue(it4, "iterator(...)");
                while (it4.hasNext()) {
                    Object next2 = it4.next();
                    Intrinsics.checkNotNullExpressionValue(next2, "next(...)");
                    arrayList4.add(Integer.valueOf(((int[]) next2)[i31]));
                }
            }
            int[] intArray = CollectionsKt.toIntArray(arrayList4);
            int i32 = intValue2 * 4;
            int i33 = i32 + 17;
            boolean[][] zArr2 = new boolean[i33];
            for (int i34 = 0; i34 < i33; i34++) {
                zArr2[i34] = new boolean[i33];
            }
            boolean[][] zArr3 = new boolean[i33];
            for (int i35 = 0; i35 < i33; i35++) {
                zArr3[i35] = new boolean[i33];
            }
            int i36 = 0;
            while (i36 < i33) {
                int i37 = i36 % 2;
                if (i37 == 0) {
                    z5 = true;
                } else {
                    z5 = false;
                }
                boolean[][] zArr4 = zArr2;
                boolean[][] zArr5 = zArr3;
                int i38 = i36;
                int i39 = i33;
                Qr.modules$set(i39, zArr4, zArr5, 6, i38, z5);
                if (i37 == 0) {
                    z6 = true;
                } else {
                    z6 = false;
                }
                Qr.modules$set(i39, zArr4, zArr5, i38, 6, z6);
                i36 = i38 + 1;
                i33 = i39;
                zArr2 = zArr4;
                zArr3 = zArr5;
            }
            boolean[][] zArr6 = zArr2;
            boolean[][] zArr7 = zArr3;
            int i40 = i33;
            int i41 = i32 + 13;
            for (Pair pair : ArraysKt.asList(new Pair[]{new Pair(3, 3), new Pair(Integer.valueOf(i41), 3), new Pair(3, Integer.valueOf(i41))})) {
                int intValue3 = ((Number) pair.first).intValue();
                int intValue4 = ((Number) pair.second).intValue();
                int i42 = -4;
                while (true) {
                    if (i42 < 5) {
                        int i43 = -4;
                        for (int i44 = 5; i43 < i44; i44 = 5) {
                            int max = Math.max(Math.abs(i43), Math.abs(i42));
                            int i45 = intValue3 + i43;
                            int i46 = intValue4 + i42;
                            if (max != 2 && max != 4) {
                                z4 = true;
                            } else {
                                z4 = false;
                            }
                            Qr.modules$set(i40, zArr6, zArr7, i45, i46, z4);
                            i43++;
                        }
                        i42++;
                    }
                }
            }
            int[] iArr9 = Qr.ALIGN[i5];
            for (int i47 : iArr9) {
                int length3 = iArr9.length;
                for (int i48 = 0; i48 < length3; i48++) {
                    int i49 = iArr9[i48];
                    int i50 = 6;
                    if (i49 != 6 || i47 != 6) {
                        if (i49 == 6) {
                            if (iArr9.length != 0) {
                                if (i47 != iArr9[iArr9.length - 1]) {
                                    i50 = 6;
                                }
                            } else {
                                throw new NoSuchElementException("Array is empty.");
                            }
                        }
                        if (i47 == i50) {
                            if (iArr9.length == 0) {
                                throw new NoSuchElementException("Array is empty.");
                            }
                        }
                        int i51 = -2;
                        while (true) {
                            if (i51 >= 3) {
                                break;
                            }
                            int i52 = -2;
                            for (int i53 = 3; i52 < i53; i53 = 3) {
                                int i54 = i49 + i52;
                                int i55 = i47 + i51;
                                if (Math.max(Math.abs(i52), Math.abs(i51)) != 1) {
                                    z3 = true;
                                } else {
                                    z3 = false;
                                }
                                Qr.modules$set(i40, zArr6, zArr7, i54, i55, z3);
                                i52++;
                            }
                            i51++;
                        }
                    }
                }
            }
            int i56 = 8;
            for (int i57 = 0; i57 < 10; i57++) {
                i56 = ((i56 >>> 9) * 1335) ^ (i56 << 1);
            }
            int i58 = (i56 | 8192) ^ 21522;
            int i59 = 0;
            while (i59 < 6) {
                int i60 = i59;
                Qr.modules$set(i40, zArr6, zArr7, 8, i60, Qr.modules$bit(i58, i59));
                i59 = i60 + 1;
            }
            Qr.modules$set(i40, zArr6, zArr7, 8, 7, Qr.modules$bit(i58, 6));
            Qr.modules$set(i40, zArr6, zArr7, 8, 8, Qr.modules$bit(i58, 7));
            Qr.modules$set(i40, zArr6, zArr7, 7, 8, Qr.modules$bit(i58, 8));
            for (int i61 = 9; i61 < 15; i61++) {
                Qr.modules$set(i40, zArr6, zArr7, 14 - i61, 8, Qr.modules$bit(i58, i61));
            }
            int i62 = 1;
            for (int i63 = 0; i63 < 8; i63++) {
                Qr.modules$set(i40, zArr6, zArr7, (i32 + 16) - i63, 8, Qr.modules$bit(i58, i63));
            }
            for (int i64 = 8; i64 < 15; i64++) {
                Qr.modules$set(i40, zArr6, zArr7, 8, i32 + 2 + i64, Qr.modules$bit(i58, i64));
            }
            Qr.modules$set(i40, zArr6, zArr7, 8, i32 + 9, true);
            if (intValue2 >= 7) {
                int i65 = intValue2;
                for (int i66 = 0; i66 < 12; i66++) {
                    i65 = ((i65 >>> 11) * 7973) ^ (i65 << 1);
                }
                int i67 = (intValue2 << 12) | i65;
                for (int i68 = 0; i68 < 18; i68++) {
                    if (((i67 >>> i68) & 1) == 1) {
                        z2 = true;
                    } else {
                        z2 = false;
                    }
                    int i69 = (i68 % 3) + i32 + 6;
                    int i70 = i68 / 3;
                    Qr.modules$set(i40, zArr6, zArr7, i69, i70, z2);
                    Qr.modules$set(i40, zArr6, zArr7, i70, i69, z2);
                }
            }
            int i71 = i32 + 16;
            int i72 = i71;
            int i73 = 0;
            while (i72 >= i62) {
                if (i72 == 6) {
                    i72 = 5;
                }
                for (int i74 = 0; i74 < i40; i74 += i62) {
                    int i75 = 0;
                    while (i75 < 2) {
                        int i76 = i72 - i75;
                        if (((i72 + 1) & 2) == 0) {
                            i2 = i71 - i74;
                        } else {
                            i2 = i74;
                        }
                        if (!zArr7[i2][i76] && i73 < intArray.length * 8) {
                            boolean[] zArr8 = zArr6[i2];
                            i62 = 1;
                            if (((intArray[i73 >>> 3] >>> (7 - (i73 & 7))) & 1) == 1) {
                                z = true;
                            } else {
                                z = false;
                            }
                            zArr8[i76] = z;
                            i73++;
                        } else {
                            i62 = 1;
                        }
                        i75 += i62;
                    }
                }
                i72 -= 2;
                i62 = 1;
            }
            for (int i77 = 0; i77 < i40; i77++) {
                for (int i78 = 0; i78 < i40; i78++) {
                    if (!zArr7[i77][i78] && (i78 + i77) % 2 == 0) {
                        zArr6[i77][i78] = !r3[i78];
                    }
                }
            }
            zArr = zArr6;
        } else {
            zArr = null;
        }
        if (zArr != null) {
            int length4 = 8 + zArr.length;
            int i79 = length4 * 6;
            int i80 = i79 * length4 * 6;
            int[] iArr10 = new int[i80];
            for (int i81 = 0; i81 < i80; i81++) {
                iArr10[i81] = -1;
            }
            int length5 = zArr.length;
            for (int i82 = 0; i82 < length5; i82++) {
                int length6 = zArr.length;
                for (int i83 = 0; i83 < length6; i83++) {
                    if (zArr[i82][i83]) {
                        for (int i84 = 0; i84 < 6; i84++) {
                            for (int i85 = 0; i85 < 6; i85++) {
                                iArr10[((i83 + 4) * 6) + ((((i82 + 4) * 6) + i84) * length4 * 6) + i85] = -16777216;
                            }
                        }
                    }
                }
            }
            bitmap = Bitmap.createBitmap(iArr10, i79, i79, Bitmap.Config.ARGB_8888);
        }
        Bitmap bitmap2 = bitmap;
        if (bitmap2 != null) {
            ImageView imageView2 = new ImageView(mainActivity);
            imageView2.setImageBitmap(bitmap2);
            imageView2.setContentDescription(T("info_screens.qr_code_to_download", new Pair[0]));
            float f3 = 170;
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(UiKt.dp(mainActivity, f3), UiKt.dp(mainActivity, f3));
            layoutParams2.gravity = 1;
            layoutParams2.topMargin = UiKt.dp(mainActivity, 14);
            col.addView(imageView2, layoutParams2);
            View button = UiKt.button(mainActivity, T("info_screens.share_the_download_link", new Pair[0]), UiKt.BTN);
            button.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(mainActivity, 13));
            LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, UiKt.dp(mainActivity, 48));
            layoutParams3.topMargin = UiKt.dp(mainActivity, 12);
            col.addView(button, layoutParams3);
        }
        col.addView(UiKt.head(mainActivity, T("info_screens.author", new Pair[0])), UiKt.gap(mainActivity, 22));
        col.addView(UiKt.row(mainActivity, "@user|Hoang Tran\n@HoangTran0410", new TalkKt$$ExternalSyntheticLambda1(mainActivity, 12)));
        col.addView(UiKt.head(mainActivity, T("info_screens.website", new Pair[0])), UiKt.gap(mainActivity, 18));
        col.addView(UiKt.row(mainActivity, "@globe|tvremote.pages.dev", new TalkKt$$ExternalSyntheticLambda1(mainActivity, 13)));
        col.addView(UiKt.row(mainActivity, ApkSigner$$ExternalSyntheticOutline0.m("@info|", T("info_screens.guide_link", new Pair[0])), new TalkKt$$ExternalSyntheticLambda1(mainActivity, 14)));
        col.addView(UiKt.row(mainActivity, ApkSigner$$ExternalSyntheticOutline0.m("@package|", T("about.releases", new Pair[0])), new TalkKt$$ExternalSyntheticLambda1(mainActivity, 15)));
        col.addView(UiKt.row(mainActivity, ApkSigner$$ExternalSyntheticOutline0.m("@clipboard|", T("info_screens.send_the_log", new Pair[0])), new TalkKt$$ExternalSyntheticLambda1(mainActivity, 16)));
        ?? obj2 = new Object();
        View row = UiKt.row(mainActivity, "", new UpdaterKt$$ExternalSyntheticLambda6(5, mainActivity, obj2));
        obj2.element = row;
        col.addView(row);
        col.addView(UiKt.note(mainActivity, T("support.app_sub", new Pair[0])));
        buildAbout$supMark(obj2, PhoneSupport.INSTANCE.relay(mainActivity).state());
        col.addView(UiKt.head(mainActivity, T("info_screens.credits", new Pair[0])), UiKt.gap(mainActivity, 18));
        col.addView(UiKt.row(mainActivity, "scrcpy · Apache-2.0", new TalkKt$$ExternalSyntheticLambda1(mainActivity, 17)));
        ScrollView scrollView = new ScrollView(mainActivity);
        scrollView.setBackgroundColor(UiKt.BG);
        scrollView.setClickable(true);
        scrollView.addView(col);
        scrollView.setVisibility(8);
        return scrollView;
    }

    public static final void buildAbout$supMark(Ref$ObjectRef ref$ObjectRef, JSONObject jSONObject) {
        String T;
        Object obj = ref$ObjectRef.element;
        if (obj != null) {
            Button button = (Button) obj;
            if (jSONObject.optBoolean("open")) {
                T = T("support.stop_sub", new Pair("code", jSONObject.optString("code")), new Pair("min", Long.valueOf(jSONObject.optLong("min"))));
            } else {
                T = T("support.app_open", new Pair("min", 30));
            }
            UiKt.setLabel(button, "@eye|" + T);
            return;
        }
        Intrinsics.throwUninitializedPropertyAccessException("sup");
        throw null;
    }

    /* JADX WARN: Type inference failed for: r7v0, types: [java.lang.Object, kotlin.jvm.internal.Ref$LongRef] */
    /* JADX WARN: Type inference failed for: r8v0, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    public static final void castFile(MainActivity mainActivity, Uri uri) {
        Uri uri2;
        String string;
        int i = 1;
        String str = mainActivity.host;
        if (str != null && mainActivity.basic == null) {
            ?? obj = new Object();
            obj.element = "shared";
            ?? obj2 = new Object();
            obj2.element = -1L;
            try {
                Cursor query = mainActivity.getContentResolver().query(uri, null, null, null, null);
                if (query != null) {
                    try {
                        if (query.moveToFirst()) {
                            int columnIndex = query.getColumnIndex("_display_name");
                            if (columnIndex >= 0 && (string = query.getString(columnIndex)) != null) {
                                obj.element = string;
                            }
                            int columnIndex2 = query.getColumnIndex("_size");
                            if (columnIndex2 >= 0 && !query.isNull(columnIndex2)) {
                                obj2.element = query.getLong(columnIndex2);
                            }
                        }
                        query.close();
                    } finally {
                    }
                }
            } catch (Exception unused) {
            }
            if (!StringsKt.contains$default((CharSequence) obj.element, '.')) {
                uri2 = uri;
                String extensionFromMimeType = MimeTypeMap.getSingleton().getExtensionFromMimeType(mainActivity.getContentResolver().getType(uri2));
                if (extensionFromMimeType != null) {
                    obj.element = obj.element + "." + extensionFromMimeType;
                }
            } else {
                uri2 = uri;
            }
            Cancel cancel = new Cancel();
            JSONObject jSONObject = new JSONObject();
            String T = T("media.sending_to_the_tv", new Pair("name", obj.element));
            Popup.Builder builder = new Popup.Builder(mainActivity);
            builder.message = Census$$ExternalSyntheticOutline0.m(T, "...");
            builder.cancelable = false;
            builder.setNegativeButton(T("page.stop", new Pair[0]), new Talk$$ExternalSyntheticLambda5(i, cancel));
            Popup show = builder.show();
            mainActivity.ui.post(new MediaKt$castFile$tick$1(show, mainActivity, jSONObject, T));
            new Thread(new MediaKt$$ExternalSyntheticLambda1(mainActivity, str, uri2, (Ref$LongRef) obj2, (Ref$ObjectRef) obj, jSONObject, cancel, show)).start();
            return;
        }
        say(mainActivity, T("media.playing_a_file_on", new Pair[0]), true);
    }

    public static HttpServer.Response census(HttpServer.Request request) {
        String str;
        if (request.method.equals("POST")) {
            JSONObject json = request.json(65536);
            if (json.has("on")) {
                MainActivity$onCreate$2 mainActivity$onCreate$2 = Census.store;
                boolean optBoolean = json.optBoolean("on");
                MainActivity$onCreate$2 mainActivity$onCreate$22 = Census.store;
                if (mainActivity$onCreate$22 != null) {
                    if (optBoolean) {
                        str = "1";
                    } else {
                        str = "0";
                    }
                    mainActivity$onCreate$22.put("census.on", str);
                }
            } else {
                throw new IllegalArgumentException("on missing");
            }
        }
        JSONObject put = new JSONObject().put("on", Census.getEnabled());
        Intrinsics.checkNotNullExpressionValue(put, "put(...)");
        HttpServer.Response response = new HttpServer.Response();
        response.status = 200;
        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = HttpServer.trusted;
        response.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put);
        return response;
    }

    public static byte[] certificate(PrivateKey privateKey, byte[] bArr, String str) {
        byte[] der = der(48, hex("06092A864886F70D01010B"), hex("0500"));
        byte[] hex = hex("0603550403");
        Charset charset = Charsets.UTF_8;
        byte[] bytes = str.getBytes(charset);
        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        byte[] der2 = der(48, der(49, der(48, hex, der(12, bytes))));
        byte[] bytes2 = "240101000000Z".getBytes(charset);
        Intrinsics.checkNotNullExpressionValue(bytes2, "getBytes(...)");
        byte[] der3 = der(23, bytes2);
        byte[] bytes3 = "491231235959Z".getBytes(charset);
        Intrinsics.checkNotNullExpressionValue(bytes3, "getBytes(...)");
        byte[] der4 = der(48, der3, der(23, bytes3));
        byte[] der5 = der(48, der(160, hex("020102")), der(2, new BigInteger(63, new SecureRandom()).add(BigInteger.ONE).toByteArray()), der, der2, der4, der2, bArr);
        Signature signature = Signature.getInstance("SHA256withRSA");
        signature.initSign(privateKey);
        signature.update(der5);
        return der(48, der5, der, der(3, new byte[]{0}, signature.sign()));
    }

    public static void chunk(ByteArrayOutputStream byteArrayOutputStream, String str, byte[] bArr) {
        byteArrayOutputStream.write(ByteBuffer.allocate(4).putInt(bArr.length).array());
        byte[] bytes = str.getBytes(Charsets.ISO_8859_1);
        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        byteArrayOutputStream.write(bytes);
        byteArrayOutputStream.write(bArr);
        ByteBuffer allocate = ByteBuffer.allocate(4);
        CRC32 crc32 = new CRC32();
        crc32.update(bytes);
        crc32.update(bArr);
        byteArrayOutputStream.write(allocate.putInt((int) crc32.getValue()).array());
    }

    public static int code(char c) {
        if ('a' <= c && c < '{') {
            return c - 'D';
        }
        if ('0' <= c && c < ':') {
            return c - ')';
        }
        if (c == ' ') {
            return 62;
        }
        if (c == '.') {
            return 56;
        }
        if (c == '/') {
            return 76;
        }
        if (c == '-') {
            return 69;
        }
        if (c == ',') {
            return 55;
        }
        if (c == '=') {
            return 70;
        }
        if (c == ';') {
            return 74;
        }
        if (c == '\'') {
            return 75;
        }
        if (c == '@') {
            return 77;
        }
        if (c == '+') {
            return 81;
        }
        if (c == '#') {
            return 18;
        }
        if (c == '*') {
            return 17;
        }
        if (c == '[') {
            return 71;
        }
        if (c == ']') {
            return 72;
        }
        if (c == '\\') {
            return 73;
        }
        if (c == '`') {
            return 68;
        }
        return 0;
    }

    public static final void confirmShare(MainActivity mainActivity, String str, Function0 function0) {
        Popup.Builder builder = new Popup.Builder(mainActivity);
        builder.title = T("media.send_to_the_tv", new Pair[0]);
        String str2 = mainActivity.host;
        if (str2 == null) {
            str2 = "";
        }
        builder.message = Census$$ExternalSyntheticOutline0.m(str, "\n→ ", mainActivity.title$android_release(str2));
        builder.setPositiveButton(T("notify.send", new Pair[0]), new UiKt$$ExternalSyntheticLambda4(function0, 1));
        builder.setNegativeButton(T("common.cancel", new Pair[0]), null);
        builder.show();
    }

    public static HttpServer.Response crash(HttpServer.Request request) {
        if (!request.method.equals("POST")) {
            JSONObject m9m = Census$$ExternalSyntheticOutline0.m9m("error", "post", "put(...)");
            HttpServer.Response response = new HttpServer.Response();
            response.status = 405;
            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = HttpServer.trusted;
            response.body = Census$$ExternalSyntheticOutline0.m("toString(...)", m9m);
            return response;
        }
        JSONObject json = request.json(65536);
        MainActivity$onCreate$2 mainActivity$onCreate$2 = Census.store;
        String optString = json.optString("kind", "Error");
        Intrinsics.checkNotNullExpressionValue(optString, "optString(...)");
        String take = StringsKt.take(optString, 120);
        String optString2 = json.optString("msg");
        Intrinsics.checkNotNullExpressionValue(optString2, "optString(...)");
        String take2 = StringsKt.take(optString2, 600);
        String optString3 = json.optString("stack");
        Intrinsics.checkNotNullExpressionValue(optString3, "optString(...)");
        JSONObject put = new JSONObject().put("sent", Census.crashNow("page", take, take2, StringsKt.take(optString3, 16384)));
        Intrinsics.checkNotNullExpressionValue(put, "put(...)");
        HttpServer.Response response2 = new HttpServer.Response();
        response2.status = 200;
        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda02 = HttpServer.trusted;
        response2.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put);
        return response2;
    }

    public static byte[] der(int i, byte[]... bArr) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        for (byte[] bArr2 : bArr) {
            byteArrayOutputStream.write(bArr2);
        }
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
        byteArrayOutputStream2.write(i);
        if (byteArray.length < 128) {
            byteArrayOutputStream2.write(byteArray.length);
        } else {
            byte[] byteArray2 = BigInteger.valueOf(byteArray.length).toByteArray();
            Intrinsics.checkNotNullExpressionValue(byteArray2, "toByteArray(...)");
            ArrayList arrayList = new ArrayList();
            boolean z = false;
            for (byte b : byteArray2) {
                if (z) {
                    arrayList.add(Byte.valueOf(b));
                } else if (b != 0) {
                    arrayList.add(Byte.valueOf(b));
                    z = true;
                }
            }
            byteArrayOutputStream2.write(arrayList.size() | 128);
            byteArrayOutputStream2.write(CollectionsKt.toByteArray(arrayList));
        }
        byteArrayOutputStream2.write(byteArray);
        byte[] byteArray3 = byteArrayOutputStream2.toByteArray();
        Intrinsics.checkNotNullExpressionValue(byteArray3, "toByteArray(...)");
        return byteArray3;
    }

    public static HttpServer.Response diagnose(HttpServer.Request request, AdbLink adbLink) {
        String lang;
        String obj = StringsKt.trim(request.q("ip")).toString();
        if (obj.length() == 0 && (adbLink == null || (obj = adbLink.host) == null)) {
            obj = "";
        }
        String str = obj;
        if (str.length() != 0 && str.length() <= 80) {
            Pattern compile = Pattern.compile("[0-9A-Za-z.:\\[\\]-]+");
            Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
            if (compile.matcher(str).matches()) {
                String q = request.q("lang");
                if (q.length() <= 0) {
                    q = null;
                }
                if (q != null) {
                    lang = Words.pick(q);
                } else {
                    lang = request.getLang();
                }
                String str2 = lang;
                Regex regex = Diagnose.OTHER_BRANDS;
                Diagnose.Real real = new Diagnose.Real(adbLink, 2);
                List list = Remote.Kind.ALL;
                JSONObject json = Diagnose.json(Diagnose.run(real, str, Remote.Kind.of(request.q("kind")), StringsKt.take(request.q("name"), 80), StringsKt.take(request.q("err"), 2000), str2), str2);
                HttpServer.Response response = new HttpServer.Response();
                response.status = 200;
                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = HttpServer.trusted;
                response.body = Census$$ExternalSyntheticOutline0.m("toString(...)", json);
                return response;
            }
        }
        JSONObject m9m = Census$$ExternalSyntheticOutline0.m9m("error", "ip", "put(...)");
        HttpServer.Response response2 = new HttpServer.Response();
        response2.status = 400;
        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda02 = HttpServer.trusted;
        response2.body = Census$$ExternalSyntheticOutline0.m("toString(...)", m9m);
        return response2;
    }

    public static void distance(ArrayList arrayList, long j, int i, int i2, int i3) {
        int i4;
        for (int i5 = 0; i5 < 32; i5++) {
            arrayList.add(Integer.valueOf(i));
            if (((j >> i5) & 1) == 1) {
                i4 = i3;
            } else {
                i4 = i2;
            }
            arrayList.add(Integer.valueOf(i4));
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x0216 A[Catch: Exception -> 0x022a, TryCatch #0 {Exception -> 0x022a, blocks: (B:3:0x000c, B:5:0x002d, B:6:0x0048, B:8:0x004e, B:14:0x0069, B:16:0x006f, B:19:0x0091, B:21:0x0216, B:24:0x021e, B:31:0x0076, B:32:0x007a, B:34:0x0080, B:42:0x009c, B:43:0x00c5, B:45:0x00ca, B:48:0x00d4, B:49:0x00dd, B:52:0x0164, B:53:0x00e7, B:56:0x00f1, B:59:0x011b, B:63:0x012c, B:67:0x0135, B:68:0x0148, B:71:0x0152, B:72:0x015a, B:75:0x016c, B:77:0x0174, B:78:0x018d, B:81:0x0196, B:82:0x01db, B:85:0x01e4, B:86:0x01ed, B:89:0x01f6, B:90:0x01fd, B:92:0x0207), top: B:2:0x000c }] */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0229 A[RETURN] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static Ir$Signal encode(boolean z, String code) {
        List split;
        Ir$Signal necFrame;
        int i;
        Intrinsics.checkNotNullParameter(code, "code");
        try {
            split = new Regex("\\s+").split(StringsKt.trim(code).toString(), 0);
        } catch (Exception unused) {
        }
        if (Intrinsics.areEqual((String) split.get(0), "RAW")) {
            int parseInt = Integer.parseInt((String) split.get(1));
            List drop = CollectionsKt.drop(2, split);
            ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(drop));
            Iterator it = drop.iterator();
            while (it.hasNext()) {
                arrayList.add(Integer.valueOf(Integer.parseInt((String) it.next())));
            }
            if (30000 <= parseInt && parseInt < 60001 && arrayList.size() >= 2) {
                if (!arrayList.isEmpty()) {
                    Iterator it2 = arrayList.iterator();
                    while (it2.hasNext()) {
                        int intValue = ((Number) it2.next()).intValue();
                        if (50 <= intValue && intValue < 60001) {
                        }
                    }
                }
                necFrame = new Ir$Signal(parseInt, CollectionsKt.toIntArray(arrayList));
                if (necFrame != null && ((int[]) necFrame.pattern).length != 0) {
                    if (necFrame.getMicros() > 2000000) {
                        return necFrame;
                    }
                }
                return null;
            }
            necFrame = null;
            if (necFrame != null) {
                if (necFrame.getMicros() > 2000000) {
                }
            }
            return null;
        }
        String str = (String) split.get(1);
        MathKt.checkRadix(16);
        long parseLong = Long.parseLong(str, 16);
        String str2 = (String) split.get(2);
        MathKt.checkRadix(16);
        long parseLong2 = Long.parseLong(str2, 16);
        String str3 = (String) split.get(0);
        int i2 = 38000;
        switch (str3.hashCode()) {
            case -1996073675:
                if (str3.equals("NECext")) {
                    necFrame = necFrame((((int) parseLong) & 65535) | ((((int) parseLong2) & 65535) << 16));
                    break;
                }
                necFrame = null;
                break;
            case -1848821909:
                if (str3.equals("SIRC15")) {
                    necFrame = sirc(8, (int) parseLong, (int) parseLong2);
                    break;
                } else {
                    necFrame = null;
                    break;
                }
            case -1848821883:
                if (str3.equals("SIRC20")) {
                    necFrame = sirc(13, (int) parseLong, (int) parseLong2);
                    break;
                } else {
                    necFrame = null;
                    break;
                }
            case -1083519047:
                if (str3.equals("Samsung32")) {
                    int i3 = (int) parseLong2;
                    int i4 = ((int) parseLong) & 255;
                    int i5 = i4 | (i4 << 8) | ((i3 & 255) << 16) | (((~i3) & 255) << 24);
                    ArrayList arrayListOf = CollectionsKt__CollectionsKt.arrayListOf(4500, 4500);
                    distance(arrayListOf, i5 & 4294967295L, 550, 550, 1650);
                    arrayListOf.add(550);
                    necFrame = new Ir$Signal(i2, CollectionsKt.toIntArray(arrayListOf));
                    break;
                } else {
                    necFrame = null;
                    break;
                }
            case 77164:
                if (str3.equals("NEC")) {
                    int i6 = (int) parseLong;
                    int i7 = (int) parseLong2;
                    necFrame = necFrame((((~i6) & 255) << 8) | (i6 & 255) | ((i7 & 255) << 16) | (((~i7) & 255) << 24));
                    break;
                }
                necFrame = null;
                break;
            case 80932:
                if (!str3.equals("RC5")) {
                    necFrame = null;
                    break;
                }
                necFrame = rc5((int) parseLong, (int) parseLong2, z);
                break;
            case 80933:
                if (str3.equals("RC6")) {
                    necFrame = rc6((int) parseLong, (int) parseLong2, z);
                    break;
                } else {
                    necFrame = null;
                    break;
                }
            case 80944:
                if (str3.equals("RCA")) {
                    int i8 = ((int) parseLong) & 15;
                    int i9 = ((int) parseLong2) & 255;
                    int i10 = (((~i8) & 15) << 8) | (i8 << 20) | (i9 << 12) | ((~i9) & 255);
                    ArrayList arrayListOf2 = CollectionsKt__CollectionsKt.arrayListOf(4000, 4000);
                    for (int i11 = 23; -1 < i11; i11--) {
                        arrayListOf2.add(500);
                        if (((i10 >> i11) & 1) == 1) {
                            i = 2000;
                        } else {
                            i = 1000;
                        }
                        arrayListOf2.add(Integer.valueOf(i));
                    }
                    arrayListOf2.add(500);
                    necFrame = new Ir$Signal(i2, CollectionsKt.toIntArray(arrayListOf2));
                    break;
                } else {
                    necFrame = null;
                    break;
                }
            case 2508980:
                if (!str3.equals("RC5X")) {
                    necFrame = null;
                    break;
                }
                necFrame = rc5((int) parseLong, (int) parseLong2, z);
                break;
            case 2545415:
                if (str3.equals("SIRC")) {
                    necFrame = sirc(5, (int) parseLong, (int) parseLong2);
                    break;
                } else {
                    necFrame = null;
                    break;
                }
            default:
                necFrame = null;
                break;
        }
        if (necFrame != null) {
        }
        return null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x01c2  */
    /* JADX WARN: Removed duplicated region for block: B:15:0x01c5 A[SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r4v1, types: [kotlin.collections.EmptyList] */
    /* JADX WARN: Type inference failed for: r4v2 */
    /* JADX WARN: Type inference failed for: r4v8, types: [java.util.ArrayList] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static ArrayList entries(JSONArray jSONArray) {
        String str;
        String str2;
        Iterator it;
        ?? r4;
        String str3;
        Map map;
        RemoteSpec$Entry remoteSpec$Entry;
        JSONObject jSONObject;
        String str4;
        int i = 0;
        IntRange until = MathKt.until(0, jSONArray.length());
        ArrayList arrayList = new ArrayList();
        Iterator it2 = until.iterator();
        while (((IntProgressionIterator) it2).hasNext) {
            JSONObject jSONObject2 = jSONArray.getJSONObject(((IntProgressionIterator) it2).nextInt());
            Intrinsics.checkNotNullExpressionValue(jSONObject2, "getJSONObject(...)");
            JSONArray optJSONArray = jSONObject2.optJSONArray("cores");
            if (optJSONArray != null) {
                Iterable until2 = MathKt.until(i, optJSONArray.length());
                if (!(until2 instanceof Collection) || !((Collection) until2).isEmpty()) {
                    Iterator it3 = until2.iterator();
                    while (((IntProgressionIterator) it3).hasNext) {
                        if (Intrinsics.areEqual(optJSONArray.getString(((IntProgressionIterator) it3).nextInt()), "phone")) {
                        }
                    }
                }
                it = it2;
                remoteSpec$Entry = null;
                if (remoteSpec$Entry == null) {
                    arrayList.add(remoteSpec$Entry);
                }
                it2 = it;
                i = 0;
            }
            JSONObject optJSONObject = jSONObject2.optJSONObject("phone");
            if (optJSONObject == null) {
                optJSONObject = new JSONObject();
            }
            String string = jSONObject2.getString("id");
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            String optString = jSONObject2.optString("icon");
            Intrinsics.checkNotNullExpressionValue(optString, "optString(...)");
            String optString2 = optJSONObject.optString("t", jSONObject2.optString("t"));
            Intrinsics.checkNotNullExpressionValue(optString2, "entry$text(...)");
            String optString3 = optJSONObject.optString("sub", jSONObject2.optString("sub"));
            Intrinsics.checkNotNullExpressionValue(optString3, "entry$text(...)");
            String optString4 = jSONObject2.optString("key");
            if (optString4.length() == 0) {
                optString4 = null;
            }
            String optString5 = jSONObject2.optString("do");
            if (optString5.length() == 0) {
                optString5 = null;
            }
            String optString6 = jSONObject2.optString("arg");
            if (optString6.length() == 0) {
                optString6 = null;
            }
            String optString7 = jSONObject2.optString("when");
            if (optString7.length() == 0) {
                optString7 = null;
            }
            String optString8 = jSONObject2.optString("expand");
            if (optString8.length() == 0) {
                str = null;
            } else {
                str = optString8;
            }
            String optString9 = jSONObject2.optString("style");
            if (optString9.length() == 0) {
                str2 = null;
            } else {
                str2 = optString9;
            }
            JSONArray optJSONArray2 = jSONObject2.optJSONArray("needs");
            it = it2;
            if (optJSONArray2 != null) {
                IntRange until3 = MathKt.until(0, optJSONArray2.length());
                r4 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until3));
                Iterator it4 = until3.iterator();
                while (((IntProgressionIterator) it4).hasNext) {
                    r4.add(optJSONArray2.getString(((IntProgressionIterator) it4).nextInt()));
                }
            } else {
                r4 = EmptyList.INSTANCE;
            }
            List list = r4;
            String optString10 = jSONObject2.optString("tint");
            Intrinsics.checkNotNullExpressionValue(optString10, "optString(...)");
            JSONObject optJSONObject2 = jSONObject2.optJSONObject("kinds");
            if (optJSONObject2 != null) {
                Iterator<String> keys = optJSONObject2.keys();
                Intrinsics.checkNotNullExpressionValue(keys, "keys(...)");
                Sequence asSequence = SequencesKt.asSequence(keys);
                map = new LinkedHashMap();
                Iterator it5 = ((ConstrainedOnceSequence) asSequence).iterator();
                while (it5.hasNext()) {
                    Object next = it5.next();
                    String str5 = optString10;
                    JSONObject jSONObject3 = optJSONObject2.getJSONObject((String) next);
                    String optString11 = jSONObject3.optString("t");
                    if (optString11.length() == 0) {
                        jSONObject = optJSONObject2;
                        str4 = null;
                    } else {
                        jSONObject = optJSONObject2;
                        str4 = optString11;
                    }
                    String optString12 = jSONObject3.optString("icon");
                    if (optString12.length() == 0) {
                        optString12 = null;
                    }
                    map.put(next, new Pair(str4, optString12));
                    optString10 = str5;
                    it5 = it5;
                    optJSONObject2 = jSONObject;
                }
                str3 = optString10;
            } else {
                str3 = optString10;
                map = EmptyMap.INSTANCE;
            }
            remoteSpec$Entry = new RemoteSpec$Entry(string, optString, optString2, optString3, optString4, optString5, optString6, optString7, str, str2, list, str3, map);
            if (remoteSpec$Entry == null) {
            }
            it2 = it;
            i = 0;
        }
        return arrayList;
    }

    public static String field$shared_release(String str, String str2) {
        String str3;
        String obj;
        String pattern = Census$$ExternalSyntheticOutline0.m("<", str2, ">([^<]*)</", str2, ">");
        Intrinsics.checkNotNullParameter(pattern, "pattern");
        Pattern compile = Pattern.compile(pattern);
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        Matcher matcher = compile.matcher(str);
        Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
        MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, str);
        if (access$findNext != null && (str3 = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)) != null && (obj = StringsKt.trim(str3).toString()) != null) {
            return unescape(obj);
        }
        return "";
    }

    public static boolean fill(Inflater inflater, byte[] bArr, int i) {
        int i2 = 0;
        while (i2 < i) {
            int inflate = inflater.inflate(bArr, i2, i - i2);
            if (inflate == 0 && (inflater.finished() || inflater.needsInput())) {
                return false;
            }
            i2 += inflate;
        }
        return true;
    }

    public static com.android.apksig.internal.util.Pair findZipEndOfCentralDirectoryRecord(FileChannelDataSource fileChannelDataSource, int i) {
        int i2;
        if (i >= 0 && i <= 65535) {
            long size = fileChannelDataSource.size();
            if (size >= 22) {
                int min = ((int) Math.min(i, size - 22)) + 22;
                long j = size - min;
                ByteBuffer byteBuffer = fileChannelDataSource.getByteBuffer(min, j);
                byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
                assertByteOrderLittleEndian(byteBuffer);
                int capacity = byteBuffer.capacity();
                if (capacity >= 22) {
                    int i3 = capacity - 22;
                    int min2 = Math.min(i3, 65535);
                    for (int i4 = 0; i4 <= min2; i4++) {
                        i2 = i3 - i4;
                        if (byteBuffer.getInt(i2) == 101010256 && (byteBuffer.getShort(i2 + 20) & 65535) == i4) {
                            break;
                        }
                    }
                }
                i2 = -1;
                if (i2 == -1) {
                    return null;
                }
                byteBuffer.position(i2);
                ByteBuffer slice = byteBuffer.slice();
                slice.order(ByteOrder.LITTLE_ENDIAN);
                return new com.android.apksig.internal.util.Pair(slice, Long.valueOf(j + i2));
            }
            return null;
        }
        throw new IllegalArgumentException(ApkSigner$$ExternalSyntheticOutline0.m("maxCommentSize: ", i));
    }

    public static byte[] frame$shared_release(InputStream inputStream) {
        int i = 0;
        int i2 = 0;
        int i3 = 0;
        do {
            int read = inputStream.read();
            if (read >= 0) {
                i2 |= (read & 127) << i3;
                if ((read & 128) != 0) {
                    i3 += 7;
                } else {
                    if (i2 <= 1048576) {
                        byte[] bArr = new byte[i2];
                        while (i < i2) {
                            int read2 = inputStream.read(bArr, i, i2 - i);
                            if (read2 < 0) {
                                return null;
                            }
                            i += read2;
                        }
                        return bArr;
                    }
                    throw new IOException("bad message");
                }
            } else {
                return null;
            }
        } while (i3 <= 21);
        throw new IOException("bad message");
    }

    public static byte[] generateSignerBlock(ApkSigningBlockUtils.SignerConfig signerConfig, Map map, boolean z) {
        byte[] bArr;
        if (!signerConfig.certificates.isEmpty()) {
            byte[] encodePublicKey = ApkSigningBlockUtils.encodePublicKey(((X509Certificate) signerConfig.certificates.get(0)).getPublicKey());
            try {
                ArrayList encodeCertificates = ApkSigningBlockUtils.encodeCertificates(signerConfig.certificates);
                ArrayList arrayList = new ArrayList(signerConfig.signatureAlgorithms.size());
                for (SignatureAlgorithm signatureAlgorithm : signerConfig.signatureAlgorithms) {
                    ContentDigestAlgorithm contentDigestAlgorithm = signatureAlgorithm.mContentDigestAlgorithm;
                    byte[] bArr2 = (byte[]) map.get(contentDigestAlgorithm);
                    if (bArr2 != null) {
                        arrayList.add(new com.android.apksig.internal.util.Pair(Integer.valueOf(signatureAlgorithm.mId), bArr2));
                    } else {
                        throw new RuntimeException(contentDigestAlgorithm + " content digest for " + signatureAlgorithm + " not computed");
                    }
                }
                if (z) {
                    ByteBuffer allocate = ByteBuffer.allocate(12);
                    allocate.order(ByteOrder.LITTLE_ENDIAN);
                    allocate.putInt(8);
                    allocate.putInt(-1091571699);
                    allocate.putInt(3);
                    bArr = allocate.array();
                } else {
                    bArr = new byte[0];
                }
                byte[] encodeAsSequenceOfLengthPrefixedElements = ApkSigningBlockUtils.encodeAsSequenceOfLengthPrefixedElements(new byte[][]{ApkSigningBlockUtils.encodeAsSequenceOfLengthPrefixedPairsOfIntAndLengthPrefixedBytes(arrayList), ApkSigningBlockUtils.encodeAsSequenceOfLengthPrefixedElements(encodeCertificates), bArr, new byte[0]});
                new ArrayList();
                return ApkSigningBlockUtils.encodeAsSequenceOfLengthPrefixedElements(new byte[][]{encodeAsSequenceOfLengthPrefixedElements, ApkSigningBlockUtils.encodeAsSequenceOfLengthPrefixedPairsOfIntAndLengthPrefixedBytes(ApkSigningBlockUtils.generateSignaturesOverData(signerConfig, encodeAsSequenceOfLengthPrefixedElements)), encodePublicKey});
            } catch (CertificateEncodingException e) {
                throw new SignatureException("Failed to encode certificates", e);
            }
        }
        throw new SignatureException("No certificates configured for signer");
    }

    public static int getTagClass(Asn1TagClass asn1TagClass) {
        int ordinal = asn1TagClass.ordinal();
        if (ordinal != 0) {
            int i = 1;
            if (ordinal != 1) {
                i = 2;
                if (ordinal != 2) {
                    if (ordinal == 3) {
                        return 3;
                    }
                    throw new IllegalArgumentException("Unsupported tag class: " + asn1TagClass);
                }
            }
            return i;
        }
        return 0;
    }

    public static int getTagNumber(Asn1Type asn1Type) {
        switch (asn1Type.ordinal()) {
            case 2:
                return 2;
            case 3:
                return 6;
            case 4:
                return 4;
            case 5:
            case 6:
                return 16;
            case 7:
                return 17;
            case 8:
                return 3;
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                return 23;
            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                return 24;
            case 11:
                return 1;
            default:
                throw new IllegalArgumentException("Unsupported data type: " + asn1Type);
        }
    }

    public static Ir$Signal halves(ArrayList arrayList, int i) {
        ArrayList arrayList2 = new ArrayList();
        Iterator it = arrayList.iterator();
        Boolean bool = null;
        while (it.hasNext()) {
            Pair pair = (Pair) it.next();
            Boolean bool2 = (Boolean) pair.first;
            boolean booleanValue = bool2.booleanValue();
            int intValue = ((Number) pair.second).intValue();
            if (bool != null || booleanValue) {
                if (bool2.equals(bool)) {
                    arrayList2.set(arrayList2.size() - 1, Integer.valueOf((intValue * i) + ((Number) arrayList2.get(arrayList2.size() - 1)).intValue()));
                } else {
                    arrayList2.add(Integer.valueOf(intValue * i));
                }
                bool = bool2;
            }
        }
        return new Ir$Signal(36000, CollectionsKt.toIntArray(arrayList2));
    }

    public static byte[] hex(String str) {
        int length = str.length() / 2;
        byte[] bArr = new byte[length];
        for (int i = 0; i < length; i++) {
            int i2 = i * 2;
            String substring = str.substring(i2, i2 + 2);
            Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
            MathKt.checkRadix(16);
            bArr[i] = (byte) Integer.parseInt(substring, 16);
        }
        return bArr;
    }

    public static Info info(Adb adb) {
        boolean z;
        int i;
        String str;
        long j;
        long j2;
        String str2;
        String str3;
        String str4;
        String str5;
        String out = adb.shell(15000L, "getprop ro.product.manufacturer; getprop ro.product.model; getprop ro.build.version.release; getprop ro.build.version.sdk; printf '\\043~\\043\\n'; df -k /data | tail -1; printf '\\043~\\043\\n'; grep MemTotal /proc/meminfo; printf '\\043~\\043\\n'; pm list packages -3; printf '\\043~\\043\\n'; dumpsys package dev.tvremote.setup | grep -m1 versionName");
        Intrinsics.checkNotNullParameter(out, "out");
        List split$default = StringsKt.split$default(StringsKt__StringsJVMKt.replace$default(out, "\r", ""), new String[]{"#~#\n"}, 0, 6);
        ArrayList arrayList = new ArrayList(5);
        for (int i2 = 0; i2 < 5; i2++) {
            arrayList.add("");
        }
        ArrayList plus = CollectionsKt.plus(split$default, (Iterable) arrayList);
        List split$default2 = StringsKt.split$default((CharSequence) plus.get(0), new String[]{"\n"}, 0, 6);
        ArrayList arrayList2 = new ArrayList(4);
        for (int i3 = 0; i3 < 4; i3++) {
            arrayList2.add("");
        }
        ArrayList plus2 = CollectionsKt.plus(split$default2, (Iterable) arrayList2);
        List split = new Regex("\\s+").split(StringsKt.trim((String) plus.get(1)).toString(), 0);
        if (split.size() >= 4) {
            CharSequence charSequence = (CharSequence) split.get(1);
            int i4 = 0;
            while (true) {
                if (i4 < charSequence.length()) {
                    if (!Character.isDigit(charSequence.charAt(i4))) {
                        break;
                    }
                    i4++;
                } else {
                    CharSequence charSequence2 = (CharSequence) split.get(3);
                    int i5 = 0;
                    while (true) {
                        if (i5 < charSequence2.length()) {
                            if (!Character.isDigit(charSequence2.charAt(i5))) {
                                break;
                            }
                            i5++;
                        } else if (((CharSequence) split.get(1)).length() > 0 && ((CharSequence) split.get(3)).length() > 0) {
                            z = true;
                        }
                    }
                }
            }
        }
        z = false;
        String obj = StringsKt.trim(StringsKt.trim((String) plus2.get(0)).toString() + " " + StringsKt.trim((String) plus2.get(1)).toString()).toString();
        String obj2 = StringsKt.trim((String) plus2.get(2)).toString();
        Integer intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull(StringsKt.trim((String) plus2.get(3)).toString());
        if (intOrNull != null) {
            i = intOrNull.intValue();
        } else {
            i = 0;
        }
        long j3 = 0;
        if (z) {
            str = "\n";
            j = Long.parseLong((String) split.get(1)) * 1024;
        } else {
            str = "\n";
            j = 0;
        }
        if (z) {
            j2 = Long.parseLong((String) split.get(3)) * 1024;
        } else {
            j2 = 0;
        }
        Pattern compile = Pattern.compile("MemTotal:\\s+(\\d+)");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        CharSequence input = (CharSequence) plus.get(2);
        Intrinsics.checkNotNullParameter(input, "input");
        Matcher matcher = compile.matcher(input);
        Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
        MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, input);
        if (access$findNext == null || (str5 = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)) == null) {
            str2 = "input";
        } else {
            str2 = "input";
            j3 = Long.parseLong(str5) * 1024;
        }
        List split$default3 = StringsKt.split$default((CharSequence) plus.get(3), new String[]{str}, 0, 6);
        ArrayList arrayList3 = new ArrayList();
        for (Object obj3 : split$default3) {
            if (StringsKt__StringsJVMKt.startsWith((String) obj3, false, "package:")) {
                arrayList3.add(obj3);
            }
        }
        ArrayList arrayList4 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList3));
        Iterator it = arrayList3.iterator();
        while (it.hasNext()) {
            String substring = ((String) it.next()).substring(8);
            Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
            arrayList4.add(StringsKt.trim(substring).toString());
        }
        List sorted = CollectionsKt.sorted(arrayList4);
        Pattern compile2 = Pattern.compile("versionName=(\\S+)");
        Intrinsics.checkNotNullExpressionValue(compile2, "compile(...)");
        CharSequence charSequence3 = (CharSequence) plus.get(4);
        Intrinsics.checkNotNullParameter(charSequence3, str2);
        Matcher matcher2 = compile2.matcher(charSequence3);
        Intrinsics.checkNotNullExpressionValue(matcher2, "matcher(...)");
        MatcherMatchResult access$findNext2 = MathKt.access$findNext(matcher2, 0, charSequence3);
        if (access$findNext2 == null || (str4 = (String) ((MatcherMatchResult$groupValues$1) access$findNext2.getGroupValues()).get(1)) == null) {
            str3 = "";
        } else {
            str3 = str4;
        }
        return new Info(obj, obj2, i, j, j2, j3, sorted, str3);
    }

    public static void install(Context context, Release release) {
        if (release != null) {
            String str = release.version;
            File file = new File(context.getCacheDir(), ApkSigner$$ExternalSyntheticOutline0.m("quiet-", str, ".apk"));
            if (file.exists() && why(context).length() == 0) {
                ActivityManager.RunningAppProcessInfo runningAppProcessInfo = new ActivityManager.RunningAppProcessInfo();
                ActivityManager.getMyMemoryState(runningAppProcessInfo);
                int i = runningAppProcessInfo.importance;
                if (i <= 230) {
                    Log.i("QuietUpdate", "busy: " + i);
                    return;
                } else {
                    Log.i("QuietUpdate", "installing ".concat(str));
                    new Thread(new Guard$$ExternalSyntheticLambda5(20, context, file), "quiet-update").start();
                    return;
                }
            }
            Log.i("QuietUpdate", "nothing to install");
        }
    }

    public static final boolean irScan$answered(IrRemoteKt$$ExternalSyntheticLambda49 irRemoteKt$$ExternalSyntheticLambda49, Regex$$ExternalSyntheticLambda0 regex$$ExternalSyntheticLambda0, Census$$ExternalSyntheticLambda4 census$$ExternalSyntheticLambda4, String str) {
        long j = 1000000;
        long nanoTime = System.nanoTime() / j;
        irRemoteKt$$ExternalSyntheticLambda49.invoke(str);
        long j2 = 700 + nanoTime;
        while (System.nanoTime() / j < j2) {
            if (((Number) regex$$ExternalSyntheticLambda0.invoke()).longValue() <= nanoTime) {
                if (!((Boolean) census$$ExternalSyntheticLambda4.invoke()).booleanValue()) {
                    Thread.sleep(40L);
                } else {
                    return false;
                }
            } else {
                return true;
            }
        }
        if (((Number) regex$$ExternalSyntheticLambda0.invoke()).longValue() > nanoTime) {
            return true;
        }
        return false;
    }

    public static Object irScan$default(ArrayList arrayList, ApkCert$$ExternalSyntheticLambda0 apkCert$$ExternalSyntheticLambda0, IrRemoteKt$$ExternalSyntheticLambda49 irRemoteKt$$ExternalSyntheticLambda49, Regex$$ExternalSyntheticLambda0 regex$$ExternalSyntheticLambda0, Census$$ExternalSyntheticLambda4 census$$ExternalSyntheticLambda4, Adb$$ExternalSyntheticLambda5 adb$$ExternalSyntheticLambda5) {
        Iterator it = arrayList.iterator();
        int i = 0;
        while (it.hasNext()) {
            int i2 = i + 1;
            Object next = it.next();
            if (!((Boolean) census$$ExternalSyntheticLambda4.invoke()).booleanValue()) {
                adb$$ExternalSyntheticLambda5.invoke(Integer.valueOf(i));
                if (irScan$answered(irRemoteKt$$ExternalSyntheticLambda49, regex$$ExternalSyntheticLambda0, census$$ExternalSyntheticLambda4, (String) apkCert$$ExternalSyntheticLambda0.invoke(next))) {
                    Thread.sleep(300L);
                    if (irScan$answered(irRemoteKt$$ExternalSyntheticLambda49, regex$$ExternalSyntheticLambda0, census$$ExternalSyntheticLambda4, (String) apkCert$$ExternalSyntheticLambda0.invoke(next))) {
                        return next;
                    }
                }
                i = i2;
            } else {
                return null;
            }
        }
        return null;
    }

    public static final String[] jsplit(String str, int i, String str2) {
        Intrinsics.checkNotNullParameter(str, "<this>");
        String[] split = Pattern.compile(str2).split(str, i);
        Intrinsics.checkNotNullExpressionValue(split, "split(...)");
        return split;
    }

    public static Procs$Keep keepNow$shared_release(String out) {
        Object obj;
        Object obj2;
        String str;
        Intrinsics.checkNotNullParameter(out, "out");
        List split$default = StringsKt.split$default(out, new String[]{"\n"}, 0, 6);
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(split$default));
        Iterator it = split$default.iterator();
        while (it.hasNext()) {
            arrayList.add(StringsKt.trim((String) it.next()).toString());
        }
        Object obj3 = "";
        if (2 >= arrayList.size()) {
            obj = "";
        } else {
            obj = arrayList.get(2);
        }
        List split$default2 = StringsKt.split$default((CharSequence) obj, new char[]{':'});
        ArrayList arrayList2 = new ArrayList();
        for (Object obj4 : split$default2) {
            if (StringsKt.contains$default((String) obj4, '/')) {
                arrayList2.add(obj4);
            }
        }
        ArrayList arrayList3 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList2));
        Iterator it2 = arrayList2.iterator();
        while (it2.hasNext()) {
            String str2 = (String) it2.next();
            arrayList3.add(StringsKt.substringBefore(str2, '/', str2));
        }
        Set set = CollectionsKt.toSet(arrayList3);
        List<String> drop = CollectionsKt.drop(3, arrayList);
        ArrayList arrayList4 = new ArrayList();
        for (String str3 : drop) {
            if (StringsKt__StringsJVMKt.startsWith(str3, false, "package:")) {
                str = str3.substring(8);
                Intrinsics.checkNotNullExpressionValue(str, "substring(...)");
            } else if (StringsKt.contains$default(str3, '/')) {
                str = StringsKt.substringBefore(str3, '/', str3);
            } else {
                str = null;
            }
            if (str != null) {
                arrayList4.add(str);
            }
        }
        if (arrayList.size() <= 0) {
            obj2 = "";
        } else {
            obj2 = arrayList.get(0);
        }
        String str4 = (String) obj2;
        String substringBefore = StringsKt.substringBefore(str4, '/', str4);
        if (1 < arrayList.size()) {
            obj3 = arrayList.get(1);
        }
        String str5 = (String) obj3;
        return new Procs$Keep(substringBefore, StringsKt.substringBefore(str5, '/', str5), CollectionsKt.toSet(arrayList4), set);
    }

    public static String keepWhy$shared_release(String str, Procs$Keep procs$Keep) {
        if (!StringsKt__StringsJVMKt.startsWith(str, false, "dev.tvremote.setup") && !str.equals("com.tailscale.ipn")) {
            if (str.equals(procs$Keep.home)) {
                return "home";
            }
            if (str.equals(procs$Keep.keyboard)) {
                return "keyboard";
            }
            if (procs$Keep.a11y.contains(str)) {
                return "a11y";
            }
            if (!Setup.PROTECTED.matches(str) && procs$Keep.people.contains(str)) {
                return null;
            }
            return "system";
        }
        return "us";
    }

    public static final void listenService(MainActivity mainActivity, boolean z) {
        int checkSelfPermission;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Intent intent = new Intent(mainActivity, (Class<?>) ListenService.class);
        if (z && Build.VERSION.SDK_INT >= 33) {
            checkSelfPermission = mainActivity.checkSelfPermission("android.permission.POST_NOTIFICATIONS");
            if (checkSelfPermission != 0) {
                mainActivity.requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 7);
            }
        }
        try {
            if (!z) {
                WorkService.Companion companion = ListenService.Companion;
                WorkService.Companion.stop(mainActivity);
                return;
            }
            synchronized (ListenService.Companion) {
                ListenService.stopAsked = false;
            }
            if (Build.VERSION.SDK_INT >= 26) {
                Guard$$ExternalSyntheticApiModelOutline0.m(mainActivity, intent);
            } else {
                mainActivity.startService(intent);
            }
        } catch (Exception unused) {
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:18:0x001a A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:22:0x000d A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0027  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static JSONObject meta(RemoteLabels remoteLabels, String str) {
        String label;
        JSONObject put;
        String str2 = null;
        if (remoteLabels != null) {
            try {
                label = remoteLabels.label(str);
            } catch (Exception unused) {
            }
            boolean z = false;
            if (remoteLabels != null) {
                try {
                    remoteLabels.names();
                    if (remoteLabels.ok) {
                        z = true;
                    }
                } catch (Exception unused2) {
                }
            }
            if (remoteLabels != null) {
                try {
                    str2 = remoteLabels.stamp(str);
                } catch (Exception unused3) {
                }
            }
            JSONObject jSONObject = new JSONObject();
            if (label == null) {
                label = StringsKt.substringAfterLast(str, '.', str);
            }
            put = jSONObject.put("label", label).put("icon", z).put("banner", z);
            if (str2 != null && str2.length() != 0) {
                put.put("iv", str2);
            }
            Intrinsics.checkNotNullExpressionValue(put, "also(...)");
            return put;
        }
        label = null;
        boolean z2 = false;
        if (remoteLabels != null) {
        }
        if (remoteLabels != null) {
        }
        JSONObject jSONObject2 = new JSONObject();
        if (label == null) {
        }
        put = jSONObject2.put("label", label).put("icon", z2).put("banner", z2);
        if (str2 != null) {
            put.put("iv", str2);
        }
        Intrinsics.checkNotNullExpressionValue(put, "also(...)");
        return put;
    }

    public static Ir$Signal necFrame(int i) {
        ArrayList arrayListOf = CollectionsKt__CollectionsKt.arrayListOf(9000, 4500);
        distance(arrayListOf, 4294967295L & i, 560, 560, 1690);
        arrayListOf.add(560);
        return new Ir$Signal(38000, CollectionsKt.toIntArray(arrayListOf));
    }

    public static final void openLink(MainActivity mainActivity, String link) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Intrinsics.checkNotNullParameter(link, "link");
        Remote remote = mainActivity.basic;
        Tv tv = mainActivity.tv;
        if (remote != null) {
            remote.launch(link);
        } else if (tv != null && tv.ready()) {
            new Thread(new MainActivity$$ExternalSyntheticLambda9(link, mainActivity, tv, 5)).start();
        }
    }

    public static void paint(Context context, AppWidgetManager appWidgetManager, int[] iArr) {
        Object obj;
        int i;
        if (iArr.length == 0) {
            return;
        }
        UiKt.loadLang(context);
        RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.widget);
        AdbHelpKt$$ExternalSyntheticLambda69 adbHelpKt$$ExternalSyntheticLambda69 = new AdbHelpKt$$ExternalSyntheticLambda69(context, remoteViews, new Object(), 1);
        adbHelpKt$$ExternalSyntheticLambda69.invoke(Integer.valueOf(R.id.w_power), new HomeQr$$ExternalSyntheticLambda0(23));
        adbHelpKt$$ExternalSyntheticLambda69.invoke(Integer.valueOf(R.id.w_mute), new HomeQr$$ExternalSyntheticLambda0(24));
        adbHelpKt$$ExternalSyntheticLambda69.invoke(Integer.valueOf(R.id.w_down), new HomeQr$$ExternalSyntheticLambda0(25));
        adbHelpKt$$ExternalSyntheticLambda69.invoke(Integer.valueOf(R.id.w_up), new HomeQr$$ExternalSyntheticLambda0(26));
        remoteViews.setOnClickPendingIntent(R.id.w_title, PendingIntent.getActivity(context, 99, new Intent(context, (Class<?>) MainActivity.class), 67108864));
        SharedPreferences sharedPreferences = context.getSharedPreferences("tvs", 0);
        MathKt.reachAroundVpn(context);
        String str = "";
        String string = sharedPreferences.getString("ips", "");
        if (string == null) {
            string = "";
        }
        Iterator it = StringsKt.split$default(string, new String[]{","}, 0, 6).iterator();
        while (true) {
            if (it.hasNext()) {
                obj = it.next();
                if (((String) obj).length() > 0) {
                    break;
                }
            } else {
                obj = null;
                break;
            }
        }
        String str2 = (String) obj;
        if (str2 != null) {
            String string2 = sharedPreferences.getString("name:".concat(str2), "");
            if (string2 != null) {
                str = string2;
            }
            if (str.length() == 0) {
                str = str2;
            }
        }
        if (str.length() == 0) {
            str = "TV Remote";
        }
        remoteViews.setTextViewText(R.id.w_title, str);
        ArrayList list = MathKt.list(context);
        int[] iArr2 = RemoteWidget.SCENES;
        int i2 = 0;
        int i3 = 0;
        while (true) {
            i = 8;
            if (i2 >= 3) {
                break;
            }
            int i4 = iArr2[i2];
            int i5 = i3 + 1;
            JSONObject jSONObject = (JSONObject) CollectionsKt.getOrNull(i3, list);
            if (jSONObject != null) {
                i = 0;
            }
            remoteViews.setViewVisibility(i4, i);
            if (jSONObject != null) {
                remoteViews.setTextViewText(i4, StringsKt.trim(jSONObject.optString("icon") + " " + jSONObject.optString("name")).toString());
                adbHelpKt$$ExternalSyntheticLambda69.invoke(Integer.valueOf(i4), new Home$$ExternalSyntheticLambda6(jSONObject, 6));
            }
            i2++;
            i3 = i5;
        }
        if (list.isEmpty()) {
            i = 0;
        }
        remoteViews.setViewVisibility(R.id.w_hint, i);
        remoteViews.setTextViewText(R.id.w_hint, T("remote_widget.make_scenes_in_the", new Pair[0]));
        appWidgetManager.updateAppWidget(iArr, remoteViews);
    }

    public static AdbTls.Wireless parse(String str) {
        int i;
        int i2;
        List lines = StringsKt.lines(str);
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(lines));
        Iterator it = lines.iterator();
        while (it.hasNext()) {
            arrayList.add(StringsKt.trim((String) it.next()).toString());
        }
        if (!Intrinsics.areEqual(CollectionsKt.firstOrNull(arrayList), "ARGS")) {
            return null;
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator it2 = arrayList.iterator();
        while (true) {
            i = 0;
            if (!it2.hasNext()) {
                break;
            }
            Object next = it2.next();
            String str2 = (String) next;
            if (StringsKt__StringsJVMKt.startsWith(str2, false, "app_process") && StringsKt.contains(str2, "com.genymobile.scrcpy.Server", false)) {
                arrayList2.add(next);
            }
        }
        if (arrayList2.isEmpty()) {
            i2 = 0;
        } else {
            Iterator it3 = arrayList2.iterator();
            i2 = 0;
            while (it3.hasNext()) {
                if (StringsKt.contains((String) it3.next(), " video=true", false) && (i2 = i2 + 1) < 0) {
                    CollectionsKt__CollectionsKt.throwCountOverflow();
                    throw null;
                }
            }
        }
        if (!arrayList2.isEmpty()) {
            Iterator it4 = arrayList2.iterator();
            int i3 = 0;
            while (it4.hasNext()) {
                if (StringsKt.contains((String) it4.next(), " audio=true", false) && (i3 = i3 + 1) < 0) {
                    CollectionsKt__CollectionsKt.throwCountOverflow();
                    throw null;
                }
            }
            i = i3;
        }
        return new AdbTls.Wireless(i2, i);
    }

    public static List parseApps$shared_release(String str) {
        return SequencesKt.toList(SequencesKt.mapNotNull(Regex.findAll$default(new Regex("<app\\s+([^>]*)>([^<]*)</app>"), str), new Bloat$$ExternalSyntheticLambda1(27)));
    }

    public static final void pickFile(MainActivity mainActivity, String[] strArr) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        try {
            mainActivity.startActivityForResult(new Intent("android.intent.action.GET_CONTENT").setType("*/*").putExtra("android.intent.extra.MIME_TYPES", strArr).addCategory("android.intent.category.OPENABLE"), mainActivity.PICK_CAST);
        } catch (Exception unused) {
            say(mainActivity, T("media.this_phone_has_no", new Pair[0]), true);
        }
    }

    public static void putUnsignedInt16(ByteBuffer byteBuffer, int i) {
        if (i >= 0 && i <= 65535) {
            byteBuffer.putShort((short) i);
            return;
        }
        throw new IllegalArgumentException(ApkSigner$$ExternalSyntheticOutline0.m("uint16 value of out range: ", i));
    }

    public static void putUnsignedInt32(ByteBuffer byteBuffer, long j) {
        if (j >= 0 && j <= 4294967295L) {
            byteBuffer.putInt((int) j);
            return;
        }
        throw new IllegalArgumentException(ApkSigner$$ExternalSyntheticOutline0.m(j, "uint32 value of out range: "));
    }

    public static Ir$Signal rc5(int i, int i2, boolean z) {
        boolean z2;
        boolean z3;
        boolean z4;
        ArrayList arrayList = new ArrayList();
        arrayList.add(Boolean.TRUE);
        if ((i2 & 64) == 0) {
            z2 = true;
        } else {
            z2 = false;
        }
        arrayList.add(Boolean.valueOf(z2));
        arrayList.add(Boolean.valueOf(z));
        for (int i3 = 4; -1 < i3; i3--) {
            if (((i >> i3) & 1) == 1) {
                z4 = true;
            } else {
                z4 = false;
            }
            arrayList.add(Boolean.valueOf(z4));
        }
        for (int i4 = 5; -1 < i4; i4--) {
            if (((i2 >> i4) & 1) == 1) {
                z3 = true;
            } else {
                z3 = false;
            }
            arrayList.add(Boolean.valueOf(z3));
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator it = arrayList.iterator();
        Intrinsics.checkNotNullExpressionValue(it, "iterator(...)");
        while (it.hasNext()) {
            Object next = it.next();
            Intrinsics.checkNotNullExpressionValue(next, "next(...)");
            arrayList2.add(new Pair(Boolean.valueOf(!r7.booleanValue()), 1));
            arrayList2.add(new Pair((Boolean) next, 1));
        }
        return halves(arrayList2, 889);
    }

    public static Ir$Signal rc6(int i, int i2, boolean z) {
        boolean z2;
        boolean z3;
        ArrayList arrayList = new ArrayList();
        arrayList.add(new Pair(Boolean.TRUE, 6));
        arrayList.add(new Pair(Boolean.FALSE, 2));
        rc6$at(arrayList, true, 1);
        for (int i3 = 0; i3 < 3; i3++) {
            rc6$at(arrayList, false, 1);
        }
        rc6$at(arrayList, z, 2);
        for (int i4 = 7; -1 < i4; i4--) {
            if (((i >> i4) & 1) == 1) {
                z3 = true;
            } else {
                z3 = false;
            }
            rc6$at(arrayList, z3, 1);
        }
        for (int i5 = 7; -1 < i5; i5--) {
            if (((i2 >> i5) & 1) == 1) {
                z2 = true;
            } else {
                z2 = false;
            }
            rc6$at(arrayList, z2, 1);
        }
        return halves(arrayList, 444);
    }

    public static final void rc6$at(ArrayList arrayList, boolean z, int i) {
        arrayList.add(new Pair(Boolean.valueOf(z), Integer.valueOf(i)));
        arrayList.add(new Pair(Boolean.valueOf(!z), Integer.valueOf(i)));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v0, types: [kotlin.jvm.internal.Ref$IntRef, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r4v7, types: [byte[]] */
    public static HashMap read(byte[] bArr) {
        long valueOf;
        HashMap hashMap = new HashMap();
        ?? obj = new Object();
        while (obj.element < bArr.length) {
            int read$num = (int) read$num(obj, bArr);
            int i = read$num & 7;
            if (i != 0) {
                if (i != 1) {
                    if (i != 2) {
                        if (i == 5) {
                            int i2 = obj.element + 4;
                            obj.element = i2;
                            if (i2 <= bArr.length) {
                                valueOf = 0L;
                            } else {
                                throw new IOException("bad message");
                            }
                        } else {
                            throw new IOException("bad message");
                        }
                    } else {
                        long read$num2 = read$num(obj, bArr);
                        if (read$num2 >= 0) {
                            int length = bArr.length;
                            int i3 = obj.element;
                            if (read$num2 <= length - i3) {
                                int i4 = (int) read$num2;
                                ?? copyOfRange = ArraysKt.copyOfRange(bArr, i3, i3 + i4);
                                obj.element += i4;
                                valueOf = copyOfRange;
                            }
                        }
                        throw new IOException("bad message");
                    }
                } else {
                    int i5 = obj.element + 8;
                    obj.element = i5;
                    if (i5 <= bArr.length) {
                        valueOf = 0L;
                    } else {
                        throw new IOException("bad message");
                    }
                }
            } else {
                valueOf = Long.valueOf(read$num(obj, bArr));
            }
            Integer valueOf2 = Integer.valueOf(read$num >>> 3);
            Object obj2 = hashMap.get(valueOf2);
            if (obj2 == null) {
                obj2 = new ArrayList();
                hashMap.put(valueOf2, obj2);
            }
            ((List) obj2).add(valueOf);
        }
        return hashMap;
    }

    public static final long read$num(Ref$IntRef ref$IntRef, byte[] bArr) {
        long j = 0;
        int i = 0;
        while (true) {
            int i2 = ref$IntRef.element;
            if (i2 >= bArr.length || i > 63) {
                break;
            }
            ref$IntRef.element = i2 + 1;
            j |= (r3 & Byte.MAX_VALUE) << i;
            if ((bArr[i2] & 128) == 0) {
                return j;
            }
            i += 7;
        }
        throw new IOException("bad message");
    }

    public static final void say(MainActivity mainActivity, String text, boolean z) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Intrinsics.checkNotNullParameter(text, "text");
        if (mainActivity.host == null) {
            PickerScreenKt.message(mainActivity, text, z);
        } else {
            Toast.makeText(mainActivity, text, z ? 1 : 0).show();
        }
    }

    public static byte[] screen(Adb adb) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byte[] bArr = new byte[65536];
        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
        Adb.Stream open = adb.open(10000L, "exec:screencap -p");
        do {
            try {
                int read = open.read(15000L, bArr, 0, 65536);
                if (read > 0) {
                    byteArrayOutputStream.write(bArr, 0, read);
                } else {
                    open.close();
                    if (byteArrayOutputStream.size() > 8) {
                        return byteArrayOutputStream.toByteArray();
                    }
                    return null;
                }
            } finally {
            }
        } while (byteArrayOutputStream.size() <= 12582912);
        throw new IOException("picture too big");
    }

    public static byte[] screencap(Adb a) {
        Intrinsics.checkNotNullParameter(a, "a");
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byte[] bArr = new byte[65536];
        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
        Adb.Stream open = a.open(10000L, "exec:screencap -p");
        while (true) {
            try {
                int read = open.read(15000L, bArr, 0, 65536);
                if (read <= 0) {
                    break;
                }
                byteArrayOutputStream.write(bArr, 0, read);
            } catch (Throwable th) {
                try {
                    throw th;
                } catch (Throwable th2) {
                    MathKt.closeFinally(open, th);
                    throw th2;
                }
            }
        }
        open.close();
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        Intrinsics.checkNotNullExpressionValue(byteArray, "toByteArray(...)");
        int length = (byteArray.length - Tv.PNG.length) - 1;
        if (length >= 0) {
            int i = 0;
            loop1: while (true) {
                byte[] bArr2 = Tv.PNG;
                Intrinsics.checkNotNullParameter(bArr2, "<this>");
                Iterable intProgression = new IntProgression(0, bArr2.length - 1, 1);
                if (!(intProgression instanceof Collection) || !((Collection) intProgression).isEmpty()) {
                    Iterator it = intProgression.iterator();
                    while (((IntProgressionIterator) it).hasNext) {
                        int nextInt = ((IntProgressionIterator) it).nextInt();
                        if (byteArray[i + nextInt] != Tv.PNG[nextInt]) {
                            if (i != length) {
                                i++;
                            } else {
                                return null;
                            }
                        }
                    }
                    break loop1;
                }
                break;
            }
            if (i == 0) {
                return byteArray;
            }
            return ArraysKt.copyOfRange(byteArray, i, byteArray.length);
        }
        return null;
    }

    /* JADX WARN: Code restructure failed: missing block: B:22:0x005f, code lost:
    
        if (kotlin.text.StringsKt__StringsJVMKt.startsWith(r0, false, r1) == true) goto L45;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void sendShared(int i, MainActivity mainActivity) {
        String str;
        Intent intent = mainActivity.shared;
        if (intent != null) {
            String str2 = null;
            if (!mainActivity.live$android_release()) {
                if (mainActivity.host == null) {
                    PickerScreenKt.message(mainActivity, T("media.choose_a_tv_to", new Pair[0]), false);
                }
                if (i < 90) {
                    mainActivity.ui.postDelayed(new MediaKt$$ExternalSyntheticLambda2(mainActivity, i, 0), 1000L);
                    return;
                } else {
                    mainActivity.shared = null;
                    return;
                }
            }
            mainActivity.shared = null;
            Uri uri = (Uri) intent.getParcelableExtra("android.intent.extra.STREAM");
            if (uri != null) {
                if (Intrinsics.areEqual(uri.getScheme(), "content")) {
                    String authority = uri.getAuthority();
                    if (authority != null) {
                        String packageName = mainActivity.getPackageName();
                        Intrinsics.checkNotNullExpressionValue(packageName, "getPackageName(...)");
                    }
                    try {
                        Cursor query = mainActivity.getContentResolver().query(uri, new String[]{"_display_name"}, null, null, null);
                        if (query != null) {
                            try {
                                if (query.moveToFirst()) {
                                    str = query.getString(0);
                                } else {
                                    str = null;
                                }
                                query.close();
                                str2 = str;
                            } finally {
                            }
                        }
                    } catch (Exception unused) {
                    }
                    if (str2 == null) {
                        str2 = T("media.a_file", new Pair[0]);
                    }
                    confirmShare(mainActivity, str2, new Regex$$ExternalSyntheticLambda0(13, mainActivity, uri));
                    return;
                }
                say(mainActivity, T("media.this_file_cannot_be", new Pair[0]), true);
                return;
            }
            Pattern compile = Pattern.compile("(?i)https?://\\S+");
            Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
            String stringExtra = intent.getStringExtra("android.intent.extra.TEXT");
            if (stringExtra == null) {
                stringExtra = "";
            }
            Matcher matcher = compile.matcher(stringExtra);
            Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
            MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, stringExtra);
            if (access$findNext != null) {
                str2 = access$findNext.getValue();
            }
            if (str2 == null) {
                say(mainActivity, T("media.what_was_shared_has", new Pair[0]), true);
                return;
            }
            String youtubeUrl = Home.youtubeUrl(str2);
            if (youtubeUrl == null) {
                youtubeUrl = str2;
            }
            askLink(mainActivity, youtubeUrl, new MediaKt$$ExternalSyntheticLambda4(mainActivity, str2, 0));
        }
    }

    public static final void setTalkMode(MainActivity mainActivity, String m) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Intrinsics.checkNotNullParameter(m, "m");
        mainActivity.getPrefs$android_release().edit().putString("talkMode", m).apply();
    }

    public static void setUnsignedInt16(ByteBuffer byteBuffer, int i, int i2) {
        if (i2 >= 0 && i2 <= 65535) {
            byteBuffer.putShort(i, (short) i2);
            return;
        }
        throw new IllegalArgumentException(ApkSigner$$ExternalSyntheticOutline0.m("uint16 value of out range: ", i2));
    }

    public static void setUnsignedInt32(int i, long j, ByteBuffer byteBuffer) {
        if (j >= 0 && j <= 4294967295L) {
            byteBuffer.putInt(i, (int) j);
            return;
        }
        throw new IllegalArgumentException(ApkSigner$$ExternalSyntheticOutline0.m(j, "uint32 value of out range: "));
    }

    public static Ir$Signal sirc(int i, int i2, int i3) {
        int i4;
        long j = ((i2 & ((1 << i) - 1)) << 7) | (i3 & 127);
        ArrayList arrayList = new ArrayList();
        arrayList.add(2400);
        arrayList.add(600);
        int i5 = i + 7;
        for (int i6 = 0; i6 < i5; i6++) {
            if (((j >> i6) & 1) == 1) {
                i4 = 1200;
            } else {
                i4 = 600;
            }
            arrayList.add(Integer.valueOf(i4));
            arrayList.add(600);
        }
        Iterator it = arrayList.iterator();
        int i7 = 0;
        while (it.hasNext()) {
            i7 += ((Number) it.next()).intValue();
        }
        ArrayList arrayList2 = new ArrayList();
        for (int i8 = 0; i8 < 3; i8++) {
            arrayList2.addAll(arrayList);
            if (i8 < 2) {
                arrayList2.set(arrayList2.size() - 1, Integer.valueOf((45000 - i7) + ((Number) arrayList2.get(arrayList2.size() - 1)).intValue()));
            }
        }
        return new Ir$Signal(40000, CollectionsKt.toIntArray(arrayList2));
    }

    public static byte[] small(byte[] bArr) {
        char c;
        int i;
        int i2 = 4;
        ByteBuffer wrap = ByteBuffer.wrap(bArr);
        if (bArr.length < 33 || wrap.getLong(0) != -8552249625308161526L) {
            return null;
        }
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        int i3 = 8;
        int i4 = 0;
        int i5 = 0;
        byte b = 0;
        while (true) {
            int i6 = i3 + 12;
            c = 0;
            if (i6 > bArr.length) {
                break;
            }
            int i7 = wrap.getInt(i3);
            String str = new String(bArr, i3 + 4, 4, Charsets.ISO_8859_1);
            if (i7 < 0 || i6 + i7 > bArr.length) {
                return null;
            }
            int hashCode = str.hashCode();
            if (hashCode != 2242190) {
                if (hashCode != 2243538) {
                    if (hashCode == 2246125 && str.equals("IHDR")) {
                        i4 = wrap.getInt(i3 + 8);
                        i5 = wrap.getInt(i6);
                        b = bArr[i3 + 17];
                        if (bArr[i3 + 16] != 8 || bArr[i3 + 20] != 0) {
                            return null;
                        }
                        if (b != 2 && b != 6) {
                            return null;
                        }
                    }
                } else if (str.equals("IEND")) {
                    break;
                }
            } else if (str.equals("IDAT")) {
                byteArrayOutputStream.write(bArr, i3 + 8, i7);
            }
            i3 += i7 + 12;
        }
        if (i4 <= 0 || i5 <= 0) {
            return null;
        }
        if (b != 6) {
            i2 = 3;
        }
        int max = Math.max(1, (i4 + 239) / 240);
        int i8 = i4 / max;
        int i9 = i5 / max;
        if (i8 <= 0 || i9 <= 0) {
            return null;
        }
        Inflater inflater = new Inflater();
        inflater.setInput(byteArrayOutputStream.toByteArray());
        int i10 = i4 * i2;
        int i11 = i8 * 3;
        int[] iArr = new int[i11];
        ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
        byte[] bArr2 = new byte[i11 + 1];
        byte[] bArr3 = new byte[i10];
        byte[] bArr4 = new byte[i10];
        int i12 = 0;
        while (i12 < i5) {
            int i13 = i12;
            int i14 = i5;
            try {
                byte[] bArr5 = new byte[1];
                if (fill(inflater, bArr5, 1)) {
                    i = bArr5[c] & 255;
                } else {
                    i = -1;
                }
                if (i < 0) {
                    inflater.end();
                    return null;
                }
                if (!fill(inflater, bArr4, i10)) {
                    inflater.end();
                    return null;
                }
                unfilter(bArr4, i, i2, bArr3);
                if (i13 / max < i9) {
                    int i15 = i8 * max;
                    int i16 = 0;
                    while (i16 < i15) {
                        int i17 = (i16 / max) * 3;
                        int i18 = i16 * i2;
                        int i19 = i15;
                        iArr[i17] = iArr[i17] + (bArr4[i18] & 255);
                        int i20 = i17 + 1;
                        iArr[i20] = iArr[i20] + (bArr4[i18 + 1] & 255);
                        int i21 = i17 + 2;
                        iArr[i21] = iArr[i21] + (bArr4[i18 + 2] & 255);
                        i16++;
                        i15 = i19;
                    }
                    if (i13 % max == max - 1) {
                        int i22 = 0;
                        while (i22 < i11) {
                            int i23 = i22 + 1;
                            bArr2[i23] = (byte) (iArr[i22] / (max * max));
                            i22 = i23;
                        }
                        byteArrayOutputStream2.write(bArr2);
                        Arrays.fill(iArr, 0, i11, 0);
                    }
                }
                i12 = i13 + 1;
                byte[] bArr6 = bArr3;
                bArr3 = bArr4;
                bArr4 = bArr6;
                i5 = i14;
                c = 0;
            } catch (Exception unused) {
                inflater.end();
                return null;
            } catch (Throwable th) {
                inflater.end();
                throw th;
            }
        }
        inflater.end();
        byte[] byteArray = byteArrayOutputStream2.toByteArray();
        Intrinsics.checkNotNullExpressionValue(byteArray, "toByteArray(...)");
        Deflater deflater = new Deflater(6);
        deflater.setInput(byteArray);
        deflater.finish();
        ByteArrayOutputStream byteArrayOutputStream3 = new ByteArrayOutputStream();
        byte[] bArr7 = new byte[8192];
        while (!deflater.finished()) {
            byteArrayOutputStream3.write(bArr7, 0, deflater.deflate(bArr7));
        }
        deflater.end();
        ByteArrayOutputStream byteArrayOutputStream4 = new ByteArrayOutputStream();
        byteArrayOutputStream4.write(new byte[]{-119, 80, 78, 71, 13, 10, 26, 10});
        byte[] array = ByteBuffer.allocate(13).putInt(i8).putInt(i9).put((byte) 8).put((byte) 2).put((byte) 0).put((byte) 0).put((byte) 0).array();
        Intrinsics.checkNotNullExpressionValue(array, "array(...)");
        chunk(byteArrayOutputStream4, "IHDR", array);
        byte[] byteArray2 = byteArrayOutputStream3.toByteArray();
        Intrinsics.checkNotNullExpressionValue(byteArray2, "toByteArray(...)");
        chunk(byteArrayOutputStream4, "IDAT", byteArray2);
        chunk(byteArrayOutputStream4, "IEND", new byte[0]);
        byte[] byteArray3 = byteArrayOutputStream4.toByteArray();
        Intrinsics.checkNotNullExpressionValue(byteArray3, "toByteArray(...)");
        return byteArray3;
    }

    public static JSONObject snapshot(JSONObject jSONObject) {
        String jSONObject2;
        for (int i = 0; i < 20; i++) {
            try {
                jSONObject2 = jSONObject.toString();
            } catch (ConcurrentModificationException unused) {
            }
            if (jSONObject2 != null) {
                return new JSONObject(jSONObject2);
            }
            continue;
            Thread.sleep(5L);
        }
        JSONObject put = new JSONObject().put("id", jSONObject.optString("id")).put("status", "running").put("pct", 0).put("msg", "");
        Intrinsics.checkNotNullExpressionValue(put, "put(...)");
        return put;
    }

    public static final void soundChanged(MainActivity mainActivity) {
        if (mainActivity.listen) {
            mainActivity.listenShare = mainActivity.getPrefs$android_release().getBoolean("listenShare", false);
            stopSound(mainActivity);
            TypingKt.layoutRemote(mainActivity);
            startSound(mainActivity);
            return;
        }
        TypingKt.layoutRemote(mainActivity);
    }

    /* JADX WARN: Type inference failed for: r15v0, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef, java.io.Serializable] */
    public static final void startSound(MainActivity mainActivity) {
        int i;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        String str = mainActivity.host;
        if (str != null && mainActivity.listen && mainActivity.sound == null && mainActivity.basic == null) {
            String str2 = mainActivity.entry;
            if (str2 == null) {
                str2 = str;
            }
            if (TypingKt.kindOf(mainActivity, str2).equals("android")) {
                ?? obj = new Object();
                Diagnose.Real real = new Diagnose.Real(mainActivity, (Serializable) obj);
                boolean z = mainActivity.listenShare;
                if (mainActivity.getPrefs$android_release().getBoolean("listenHq", false)) {
                    i = 160000;
                } else {
                    i = 64000;
                }
                Tv Tv$default = Tv$default(mainActivity, str, null, 0, 0, false, real, z, i, 0, 0, null, false, null, 516736);
                obj.element = Tv$default;
                mainActivity.sound = Tv$default;
            }
        }
    }

    public static final void stopListen(MainActivity mainActivity, String str) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        if (mainActivity.listen) {
            mainActivity.listen = false;
            listenService(mainActivity, false);
            stopSound(mainActivity);
            TypingKt.layoutRemote(mainActivity);
            if (str != null) {
                Toast.makeText(mainActivity, str, 1).show();
            }
        }
    }

    public static final void stopSound(MainActivity mainActivity) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Tv tv = mainActivity.sound;
        if (tv != null) {
            tv.stop();
        }
        mainActivity.sound = null;
    }

    public static String tagClassAndNumberToString(int i, int i2) {
        String str;
        String tagClassToString = tagClassToString(i);
        if (i2 != 16) {
            if (i2 != 17) {
                if (i2 != 23) {
                    if (i2 != 24) {
                        switch (i2) {
                            case 1:
                                str = "BOOLEAN";
                                break;
                            case 2:
                                str = "INTEGER";
                                break;
                            case 3:
                                str = "BIT STRING";
                                break;
                            case 4:
                                str = "OCTET STRING";
                                break;
                            case 5:
                                str = "NULL";
                                break;
                            case 6:
                                str = "OBJECT IDENTIFIER";
                                break;
                            default:
                                str = "0x" + Integer.toHexString(i2);
                                break;
                        }
                    } else {
                        str = "GENERALIZED TIME";
                    }
                } else {
                    str = "UTC TIME";
                }
            } else {
                str = "SET";
            }
        } else {
            str = "SEQUENCE";
        }
        if (tagClassToString.isEmpty()) {
            return str;
        }
        return Census$$ExternalSyntheticOutline0.m(tagClassToString, " ", str);
    }

    public static String tagClassToString(int i) {
        if (i != 0) {
            if (i != 1) {
                if (i != 2) {
                    if (i == 3) {
                        return "PRIVATE";
                    }
                    throw new IllegalArgumentException(ApkSigner$$ExternalSyntheticOutline0.m("Unsupported type class: ", i));
                }
                return "";
            }
            return "APPLICATION";
        }
        return "UNIVERSAL";
    }

    public static final boolean takeShare(MainActivity mainActivity, Intent intent) {
        if (intent == null || !"android.intent.action.SEND".equals(intent.getAction())) {
            return false;
        }
        mainActivity.shared = intent;
        mainActivity.setIntent(new Intent(mainActivity, (Class<?>) MainActivity.class));
        sendShared(0, mainActivity);
        return true;
    }

    public static final void toggleListen(MainActivity mainActivity) {
        String T;
        if (mainActivity.needsAdb$android_release()) {
            return;
        }
        if (mainActivity.listen) {
            stopListen(mainActivity, null);
            return;
        }
        mainActivity.listen = true;
        mainActivity.listenShare = mainActivity.getPrefs$android_release().getBoolean("listenShare", false);
        mainActivity.listenTvLoud = false;
        mainActivity.soundTries = 0;
        stopSound(mainActivity);
        TypingKt.layoutRemote(mainActivity);
        startSound(mainActivity);
        listenService(mainActivity, true);
        if (mainActivity.listenShare) {
            T = T("listen.opening_the_tvs_sound", new Pair[0]);
        } else {
            T = T("listen.opening_the_tvs_sound_2", new Pair[0]);
        }
        Toast.makeText(mainActivity, T, 0).show();
    }

    public static void type(Remote remote, int i, String str) {
        for (int i2 = 0; i2 < i; i2++) {
            remote.key(67, 3);
        }
        if (str.length() > 0) {
            remote.text(str);
        }
    }

    public static String unescape(String str) {
        return StringsKt__StringsJVMKt.replace$default(StringsKt__StringsJVMKt.replace$default(StringsKt__StringsJVMKt.replace$default(StringsKt__StringsJVMKt.replace$default(StringsKt__StringsJVMKt.replace$default(str, "&lt;", "<"), "&gt;", ">"), "&quot;", "\""), "&apos;", "'"), "&amp;", "&");
    }

    public static void unfilter(byte[] bArr, int i, int i2, byte[] bArr2) {
        int i3;
        int i4;
        int length = bArr.length;
        for (int i5 = 0; i5 < length; i5++) {
            if (i5 >= i2) {
                i3 = bArr[i5 - i2] & 255;
            } else {
                i3 = 0;
            }
            int i6 = bArr2[i5] & 255;
            if (i5 >= i2) {
                i4 = bArr2[i5 - i2] & 255;
            } else {
                i4 = 0;
            }
            if (i != 1) {
                if (i != 2) {
                    if (i != 3) {
                        if (i != 4) {
                            i3 = 0;
                        } else {
                            int i7 = (i3 + i6) - i4;
                            int abs = Math.abs(i7 - i3);
                            int abs2 = Math.abs(i7 - i6);
                            int abs3 = Math.abs(i7 - i4);
                            if (abs > abs2 || abs > abs3) {
                                if (abs2 > abs3) {
                                    i3 = i4;
                                }
                            }
                        }
                    } else {
                        i3 = (i3 + i6) / 2;
                    }
                }
                i3 = i6;
            }
            bArr[i5] = (byte) (bArr[i5] + i3);
        }
    }

    public static void uninstall(Adb adb, String pkg) {
        String str;
        Intrinsics.checkNotNullParameter(pkg, "pkg");
        if (!Pkg.RE.matches(pkg)) {
            str = "bad package name";
        } else {
            String[] strArr = Setup.GOOGLE;
            if (Rescue.mustKeep(pkg)) {
                str = "protected: the TV needs this app";
            } else {
                str = null;
            }
        }
        if (str == null) {
            Regex regex = LauncherSwap.PKG;
            ConcurrentHashMap concurrentHashMap = Adb.ASKING;
            if (!StringsKt__StringsJVMKt.startsWith(Games.last(adb.shell(120000L, "p=$(cmd role get-role-holders android.app.role.HOME 2>/dev/null); c=$([ -n \"$p\" ] && cmd package query-activities --brief -a android.intent.action.MAIN -c android.intent.category.HOME 2>/dev/null | grep -m1 \"^ *$p/\"); if [ -n \"$c\" ]; then echo $c; else cmd package resolve-activity --brief -c android.intent.category.HOME -a android.intent.action.MAIN; fi")), false, pkg.concat("/"))) {
                String[] strArr2 = Setup.GOOGLE;
                if (!Rescue.inUse(pkg, new Fleet$$ExternalSyntheticLambda0(adb, 0))) {
                    String obj = StringsKt.trim(adb.shell(120000L, ApkSigner$$ExternalSyntheticOutline0.m("pm uninstall ", pkg, " 2>&1"))).toString();
                    if (!StringsKt.contains(obj, "Success", false)) {
                        if (obj.length() == 0) {
                            obj = "uninstall failed";
                        }
                        throw new IOException(obj);
                    }
                    return;
                }
                throw new IOException("protected: the TV needs this app");
            }
            throw new IOException("protected: the TV needs this app");
        }
        throw new IOException(str);
    }

    public static void varint(ByteArrayOutputStream o, long j) {
        Intrinsics.checkNotNullParameter(o, "o");
        while (((-128) & j) != 0) {
            o.write((int) ((127 & j) | 128));
            j >>>= 7;
        }
        o.write((int) j);
    }

    public static String videoOpts(int i, int i2, int i3, boolean z) {
        int i4;
        int[][] iArr = Tv.QUALITY;
        int[] iArr2 = iArr[MathKt.coerceIn(i, 0, iArr.length - 1)];
        int min = Math.min(iArr2[0], i2);
        if (i3 > 0) {
            i4 = MathKt.coerceIn(i3, 100000, 20000000);
        } else {
            i4 = iArr2[1];
        }
        if (z) {
            min = Math.min(min, 720);
            if (i3 <= 0) {
                i4 = Math.min(i4, 1000000);
            }
        }
        return Census$$ExternalSyntheticOutline0.m("video_bit_rate=", i4, " max_size=", Math.max(160, (min / 32) * 32));
    }

    public static final void warmAppNames(MainActivity mainActivity, Census$$ExternalSyntheticLambda6 census$$ExternalSyntheticLambda6) {
        String str = mainActivity.host;
        Tv tv = mainActivity.tv;
        if ((!Intrinsics.areEqual(mainActivity.appNamesFor, str) || System.currentTimeMillis() - mainActivity.voicePinsAt >= 300000) && str != null && tv != null && tv.ready()) {
            new Thread(new Vidaa$$ExternalSyntheticLambda3(mainActivity, str, tv, census$$ExternalSyntheticLambda6, 4)).start();
        } else if (census$$ExternalSyntheticLambda6 != null) {
            census$$ExternalSyntheticLambda6.invoke();
        }
    }

    public static final void web(MainActivity mainActivity, String str) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        try {
            mainActivity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
        } catch (Exception unused) {
            PickerScreenKt.message(mainActivity, str, false);
        }
    }

    public static String why(Context context) {
        String str;
        InstallSourceInfo installSourceInfo;
        if (Build.VERSION.SDK_INT < 31) {
            return "android";
        }
        if (!Guard$$ExternalSyntheticApiModelOutline0.m(context.getPackageManager())) {
            return "not allowed";
        }
        if (!context.getSharedPreferences("quiet_update", 0).getBoolean("asks", false)) {
            try {
                installSourceInfo = context.getPackageManager().getInstallSourceInfo(context.getPackageName());
                str = installSourceInfo.getInstallingPackageName();
            } catch (Exception unused) {
                str = null;
            }
            if (Intrinsics.areEqual(str, context.getPackageName())) {
                return "";
            }
            return ApkSigner$$ExternalSyntheticOutline0.m("installed by ", str);
        }
        return "asks";
    }
}
