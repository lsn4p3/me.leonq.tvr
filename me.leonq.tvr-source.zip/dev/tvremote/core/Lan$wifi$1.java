package dev.tvremote.core;

import kotlin.jvm.functions.Function0;

/* loaded from: classes.dex */
public final class Lan$wifi$1 implements Function0 {
    public static final Lan$wifi$1 INSTANCE = new Object();

    @Override // kotlin.jvm.functions.Function0
    public final /* bridge */ /* synthetic */ Object invoke() {
        return null;
    }
}
