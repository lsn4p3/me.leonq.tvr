package dev.tvremote.core;

import android.content.Context;
import android.content.SharedPreferences;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Diagnose;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.adb.AdbTls;
import dev.tvremote.core.adb.Mdns;
import dev.tvremote.core.manage.HomeApi$$ExternalSyntheticLambda1;
import dev.tvremote.core.manage.Jobs$$ExternalSyntheticLambda0;
import dev.tvremote.core.ontv.Bloat$$ExternalSyntheticLambda1;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.remote.Atv;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.core.remote.RemoteSteps;
import dev.tvremote.core.remote.Ssdp;
import dev.tvremote.core.remote.Vidaa;
import dev.tvremote.core.remote.Vidaa$$ExternalSyntheticLambda3;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.scenes.Headless$Keys;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.net.ConnectException;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyMap;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$ObjectRef;
import kotlin.math.MathKt;
import kotlin.text.Regex;
import kotlin.text.RegexOption;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.conscrypt.PSKKeyManager;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public abstract class Diagnose {
    public static final Regex ISP;
    public static final Regex NOT_LAN;
    public static final Regex OTHER_BRANDS;
    public static volatile Function1 bindUdp;

    /* loaded from: classes.dex */
    public final class Check {
        public final String id;
        public final String note;
        public final Boolean ok;

        public Check(String str, Boolean bool, String note) {
            Intrinsics.checkNotNullParameter(note, "note");
            this.id = str;
            this.ok = bool;
            this.note = note;
        }
    }

    /* loaded from: classes.dex */
    public final class Found {
        public final String ip;
        public final String name;

        public Found(String str, String name) {
            Intrinsics.checkNotNullParameter(name, "name");
            this.ip = str;
            this.name = name;
        }
    }

    /* loaded from: classes.dex */
    public final class Local {
        public final InetAddress ip;
        public final int prefix;

        public Local(InetAddress inetAddress, int i) {
            this.ip = inetAddress;
            this.prefix = i;
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* loaded from: classes.dex */
    public final class Net {
        public static final /* synthetic */ Net[] $VALUES;
        public static final Net NA;
        public static final Net NONE;
        public static final Net OK;
        public static final Net OTHER;
        public static final Net TAILSCALE_OFF;

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r5v0, types: [dev.tvremote.core.Diagnose$Net, java.lang.Enum] */
        /* JADX WARN: Type inference failed for: r6v1, types: [dev.tvremote.core.Diagnose$Net, java.lang.Enum] */
        /* JADX WARN: Type inference failed for: r7v1, types: [dev.tvremote.core.Diagnose$Net, java.lang.Enum] */
        /* JADX WARN: Type inference failed for: r8v1, types: [dev.tvremote.core.Diagnose$Net, java.lang.Enum] */
        /* JADX WARN: Type inference failed for: r9v1, types: [dev.tvremote.core.Diagnose$Net, java.lang.Enum] */
        static {
            ?? r5 = new Enum("OK", 0);
            OK = r5;
            ?? r6 = new Enum("NONE", 1);
            NONE = r6;
            ?? r7 = new Enum("OTHER", 2);
            OTHER = r7;
            ?? r8 = new Enum("TAILSCALE_OFF", 3);
            TAILSCALE_OFF = r8;
            ?? r9 = new Enum("NA", 4);
            NA = r9;
            $VALUES = new Net[]{r5, r6, r7, r8, r9};
        }

        public static Net valueOf(String str) {
            return (Net) Enum.valueOf(Net.class, str);
        }

        public static Net[] values() {
            return (Net[]) $VALUES.clone();
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* loaded from: classes.dex */
    public final class Port {
        public static final /* synthetic */ Port[] $VALUES;
        public static final Port OPEN;
        public static final Port REFUSED;
        public static final Port SILENT;

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r3v0, types: [java.lang.Enum, dev.tvremote.core.Diagnose$Port] */
        /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Enum, dev.tvremote.core.Diagnose$Port] */
        /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Enum, dev.tvremote.core.Diagnose$Port] */
        static {
            ?? r3 = new Enum("OPEN", 0);
            OPEN = r3;
            ?? r4 = new Enum("REFUSED", 1);
            REFUSED = r4;
            ?? r5 = new Enum("SILENT", 2);
            SILENT = r5;
            $VALUES = new Port[]{r3, r4, r5};
        }

        public static Port valueOf(String str) {
            return (Port) Enum.valueOf(Port.class, str);
        }

        public static Port[] values() {
            return (Port[]) $VALUES.clone();
        }
    }

    /* loaded from: classes.dex */
    public final class Real implements Tv.Listener {
        public Object bindUdp;
        public Object link;

        public /* synthetic */ Real(Object obj, Serializable serializable) {
            this.link = obj;
            this.bindUdp = serializable;
        }

        public File file(String str) {
            String replaceAll = Census$$ExternalSyntheticOutline0.m7m("[^\\w.-]", "compile(...)", str, "input", str).replaceAll("_");
            Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
            return new File((File) this.link, ((String) this.bindUdp) + "-" + replaceAll);
        }

        public Found find(String str, String str2, String not) {
            ArrayList arrayList;
            Found found;
            Intrinsics.checkNotNullParameter(not, "not");
            String lowerCase = StringsKt.trim(str2).toString().toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
            Object obj = null;
            if (lowerCase.length() == 0) {
                return null;
            }
            boolean equals = str.equals("android");
            Function1 function1 = (Function1) this.bindUdp;
            if (equals) {
                ArrayList find$default = Mdns.find$default(1800, "_androidtvremote2._tcp", function1);
                ArrayList arrayList2 = new ArrayList();
                Iterator it = find$default.iterator();
                while (it.hasNext()) {
                    Object next = it.next();
                    if (!((Mdns.Service) next).ip.equals(not)) {
                        arrayList2.add(next);
                    }
                }
                ExecutorService newFixedThreadPool = Executors.newFixedThreadPool(Math.max(1, arrayList2.size()), new Diagnose$$ExternalSyntheticLambda1(1));
                try {
                    ArrayList arrayList3 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList2));
                    Iterator it2 = arrayList2.iterator();
                    while (it2.hasNext()) {
                        arrayList3.add(newFixedThreadPool.submit(new Diagnose$$ExternalSyntheticLambda3((Mdns.Service) it2.next())));
                    }
                    arrayList = new ArrayList();
                    Iterator it3 = arrayList3.iterator();
                    while (it3.hasNext()) {
                        try {
                            found = (Found) ((Future) it3.next()).get(1500L, TimeUnit.MILLISECONDS);
                        } catch (Exception unused) {
                            found = null;
                        }
                        if (found != null) {
                            arrayList.add(found);
                        }
                    }
                    newFixedThreadPool.shutdownNow();
                } catch (Throwable th) {
                    newFixedThreadPool.shutdownNow();
                    throw th;
                }
            } else {
                List list = Ssdp.SEARCH;
                List find = Ssdp.find(1800, function1, new Bloat$$ExternalSyntheticLambda1(28));
                ArrayList arrayList4 = new ArrayList();
                for (Object obj2 : find) {
                    Ssdp.Found found2 = (Ssdp.Found) obj2;
                    if (found2.kind.equals(str) && !found2.ip.equals(not)) {
                        arrayList4.add(obj2);
                    }
                }
                arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList4));
                Iterator it4 = arrayList4.iterator();
                while (it4.hasNext()) {
                    Ssdp.Found found3 = (Ssdp.Found) it4.next();
                    arrayList.add(new Found(found3.ip, found3.name));
                }
            }
            ArrayList arrayList5 = new ArrayList();
            for (Object obj3 : arrayList) {
                String lowerCase2 = StringsKt.trim(((Found) obj3).name).toString().toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
                if (lowerCase2.equals(lowerCase)) {
                    arrayList5.add(obj3);
                }
            }
            if (arrayList5.size() == 1) {
                obj = arrayList5.get(0);
            }
            return (Found) obj;
        }

        public String get(String host) {
            Intrinsics.checkNotNullParameter(host, "host");
            try {
                return StringsKt.trim(MathKt.readText$default(file(host))).toString();
            } catch (IOException unused) {
                return "";
            }
        }

        @Override // dev.tvremote.core.picture.Tv.Listener
        public void onStatus(String str, String detail) {
            Intrinsics.checkNotNullParameter(detail, "detail");
            MainActivity mainActivity = (MainActivity) this.link;
            mainActivity.ui.post(new Vidaa$$ExternalSyntheticLambda3(mainActivity, (Ref$ObjectRef) this.bindUdp, str, detail));
        }

        public void put(String host, String value) {
            Intrinsics.checkNotNullParameter(host, "host");
            Intrinsics.checkNotNullParameter(value, "value");
            try {
                ((File) this.link).mkdirs();
                File file = file(host);
                MathKt.writeText$default(file, value);
                file.setReadable(false, false);
                file.setReadable(true, true);
            } catch (IOException e) {
                WireLog.all.add("·", ((String) this.bindUdp) + " key for " + host + " not saved: " + e);
            }
        }

        /* JADX WARN: Type inference failed for: r3v42, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
        /* JADX WARN: Type inference failed for: r5v9, types: [kotlin.jvm.internal.Ref$BooleanRef, java.lang.Object] */
        /* JADX WARN: Type inference failed for: r7v3, types: [kotlin.jvm.internal.Ref$BooleanRef, java.lang.Object] */
        public String run(Function2 function2) {
            Object obj;
            Object obj2;
            String str;
            Object obj3;
            Object obj4;
            String str2;
            String str3;
            String str4;
            boolean z;
            Object obj5;
            String str5;
            String T;
            String str6;
            String str7 = "";
            String string = ((SharedPreferences) this.bindUdp).getString("ips", "");
            if (string == null) {
                string = "";
            }
            Iterator it = StringsKt.split$default(string, new String[]{","}, 0, 6).iterator();
            while (true) {
                obj = null;
                if (it.hasNext()) {
                    obj2 = it.next();
                    if (((String) obj2).length() > 0) {
                        break;
                    }
                } else {
                    obj2 = null;
                    break;
                }
            }
            String str8 = (String) obj2;
            if (str8 == null) {
                return Fleet.T("headless.no_tv_yet_open", new Pair[0]);
            }
            String string2 = ((SharedPreferences) this.bindUdp).getString("name:".concat(str8), "");
            if (string2 == null) {
                string2 = "";
            }
            if (string2.length() == 0) {
                str = str8;
            } else {
                str = string2;
            }
            String string3 = ((SharedPreferences) this.bindUdp).getString("ts:".concat(str8), "");
            if (string3 == null) {
                string3 = "";
            }
            String string4 = ((SharedPreferences) this.bindUdp).getString("lan:".concat(str8), "");
            if (string4 == null) {
                string4 = "";
            }
            List asList = ArraysKt.asList(new String[]{str8, string3, string4});
            ArrayList arrayList = new ArrayList();
            for (Object obj6 : asList) {
                if (((String) obj6).length() > 0) {
                    arrayList.add(obj6);
                }
            }
            List distinct = CollectionsKt.distinct(arrayList);
            List list = Remote.Kind.ALL;
            String string5 = ((SharedPreferences) this.bindUdp).getString("kind:".concat(str8), "");
            if (string5 != null) {
                str7 = string5;
            }
            String of = Remote.Kind.of(str7);
            if (!of.equals("android")) {
                Iterator it2 = distinct.iterator();
                loop2: while (true) {
                    if (!it2.hasNext()) {
                        break;
                    }
                    Object next = it2.next();
                    String str9 = (String) next;
                    List ports = Remote.Kind.ports(of);
                    if (!ports.isEmpty()) {
                        Iterator it3 = ports.iterator();
                        while (it3.hasNext()) {
                            if (MathKt.open(str9, ((Number) it3.next()).intValue(), 1500, null)) {
                                obj = next;
                                break loop2;
                            }
                        }
                    }
                }
                String str10 = (String) obj;
                if (str10 == null) {
                    return Fleet.T("headless.cannot_reach_the_tv", new Pair("name", str));
                }
                File filesDir = ((Context) this.link).getFilesDir();
                Intrinsics.checkNotNullExpressionValue(filesDir, "getFilesDir(...)");
                Remote of2 = Vidaa.Companion.of(filesDir, of, str10);
                try {
                    try {
                        try {
                            of2.connect(new Census$$ExternalSyntheticLambda4(4));
                            for (int i = 0; i < 20 && !of2.ready(); i++) {
                                Thread.sleep(100L);
                            }
                            String str11 = (String) function2.invoke(new RemoteSteps(of2, new Census$$ExternalSyntheticLambda4(4)), Boolean.FALSE);
                            Thread.sleep(400L);
                            if (str11 == null) {
                                str6 = "✓ " + str;
                            } else {
                                str6 = str + ": " + str11;
                            }
                            of2.close();
                            return str6;
                        } catch (Exception e) {
                            String message = e.getMessage();
                            if (message == null) {
                                message = e.getClass().getSimpleName();
                            }
                            T = str + ": " + message;
                            of2.close();
                            return T;
                        }
                    } catch (Remote.Refused unused) {
                        T = Fleet.T("headless.the_tv_said_no", new Pair("name", str));
                        of2.close();
                        return T;
                    }
                } finally {
                    of2.close();
                }
            }
            Iterator it4 = distinct.iterator();
            while (true) {
                if (it4.hasNext()) {
                    obj3 = it4.next();
                    if (MathKt.open((String) obj3, 5555, 2000, null)) {
                        break;
                    }
                } else {
                    obj3 = null;
                    break;
                }
            }
            String str12 = (String) obj3;
            if (str12 == null) {
                obj4 = "name";
                str2 = "headless.cannot_reach_the_tv";
                str3 = "✓ ";
                str4 = "getFilesDir(...)";
                z = false;
            } else {
                File filesDir2 = ((Context) this.link).getFilesDir();
                Intrinsics.checkNotNullExpressionValue(filesDir2, "getFilesDir(...)");
                AdbLink adbLink = new AdbLink(filesDir2, str12);
                ?? obj7 = new Object();
                ?? obj8 = new Object();
                str2 = "headless.cannot_reach_the_tv";
                ?? obj9 = new Object();
                obj4 = "name";
                str3 = "✓ ";
                str4 = "getFilesDir(...)";
                Thread thread = new Thread(new Jobs$$ExternalSyntheticLambda0(obj7, adbLink, obj9, function2, obj8, 6));
                thread.start();
                thread.join(15000L);
                if (obj9.element && !obj8.element) {
                    thread.join(120000L);
                }
                if (!obj8.element && adbLink.waiting) {
                    adbLink.close();
                    return Fleet.T("headless.the_tv_is_asking", new Pair(obj4, str));
                }
                adbLink.close();
                if (!obj8.element) {
                    return Fleet.T("headless.the_tv_did_not", new Pair(obj4, str));
                }
                String str13 = (String) obj7.element;
                if (str13 == null) {
                    return str3.concat(str);
                }
                z = false;
                if (!StringsKt__StringsJVMKt.startsWith(str13, false, "adb:")) {
                    return Census$$ExternalSyntheticOutline0.m(str, ": ", str13);
                }
            }
            if (((SharedPreferences) this.bindUdp).getBoolean("atv:".concat(str8), z)) {
                Iterator it5 = distinct.iterator();
                while (true) {
                    if (it5.hasNext()) {
                        obj5 = it5.next();
                        if (MathKt.open((String) obj5, 6466, 1500, null)) {
                            break;
                        }
                    } else {
                        obj5 = null;
                        break;
                    }
                }
                String str14 = (String) obj5;
                if (str14 != null) {
                    File filesDir3 = ((Context) this.link).getFilesDir();
                    Intrinsics.checkNotNullExpressionValue(filesDir3, str4);
                    Atv atv = new Atv(filesDir3, str14);
                    try {
                        try {
                            atv.connect(new Census$$ExternalSyntheticLambda4(4));
                            for (int i2 = 0; i2 < 20 && !atv.ready(); i2++) {
                                Thread.sleep(100L);
                            }
                            String str15 = (String) function2.invoke(new Headless$Keys(atv), Boolean.FALSE);
                            Thread.sleep(400L);
                            if (str15 == null) {
                                str5 = str3 + str;
                            } else {
                                str5 = str + ": " + str15;
                            }
                            atv.close();
                            return str5;
                        } catch (Exception e2) {
                            String message2 = e2.getMessage();
                            if (message2 == null) {
                                message2 = e2.getClass().getSimpleName();
                            }
                            String str16 = str + ": " + message2;
                            atv.close();
                            return str16;
                        }
                    } finally {
                        atv.close();
                    }
                }
            }
            return Fleet.T(str2, new Pair(obj4, str));
        }

        public String scene(String id) {
            Intrinsics.checkNotNullParameter(id, "id");
            JSONObject find = MathKt.find((Context) this.link, id);
            if (find == null) {
                return Fleet.T("headless.this_scene_is_gone", new Pair[0]);
            }
            String run = run(new HomeApi$$ExternalSyntheticLambda1(4, find));
            if (StringsKt__StringsJVMKt.startsWith(run, false, "✓")) {
                return ApkSigner$$ExternalSyntheticOutline0.m("✓ ", find.optString("name"));
            }
            return run;
        }

        @Override // dev.tvremote.core.picture.Tv.Listener
        public boolean wantsNetwork() {
            return true;
        }

        @Override // dev.tvremote.core.picture.Tv.Listener
        public boolean wantsPass() {
            return false;
        }

        public Real(AdbLink adbLink, int i) {
            adbLink = (i & 1) != 0 ? null : adbLink;
            Regex regex = Diagnose.OTHER_BRANDS;
            Function1 bindUdp = Diagnose.bindUdp;
            Intrinsics.checkNotNullParameter(bindUdp, "bindUdp");
            this.link = adbLink;
            this.bindUdp = bindUdp;
        }

        @Override // dev.tvremote.core.picture.Tv.Listener
        public void onPassRefused() {
        }

        @Override // dev.tvremote.core.picture.Tv.Listener
        public void onPass(String str) {
        }

        @Override // dev.tvremote.core.picture.Tv.Listener
        public void onVideoSize(int i, int i2) {
        }

        @Override // dev.tvremote.core.picture.Tv.Listener
        public void onNetwork(String str, String str2, String str3) {
        }
    }

    /* loaded from: classes.dex */
    public final class Result {
        public final String brand;
        public final List checks;
        public final String code;
        public final Found found;
        public final String ip;
        public final String kind;
        public final long ms;

        public Result(String str, String ip, String str2, Found found, List list, long j, String brand) {
            Intrinsics.checkNotNullParameter(ip, "ip");
            Intrinsics.checkNotNullParameter(brand, "brand");
            this.code = str;
            this.ip = ip;
            this.kind = str2;
            this.found = found;
            this.checks = list;
            this.ms = j;
            this.brand = brand;
        }
    }

    static {
        CollectionsKt__CollectionsKt.listOf((Object[]) new String[]{"setup_off", "clock", "no_wifi", "other_net", "tailscale", "allow", "wireless", "adb_off", "remote_off", "up", "closed", "moved", "vpn", "off"});
        RegexOption regexOption = RegexOption.IGNORE_CASE;
        OTHER_BRANDS = new Regex("sony|bravia|xiaomi|\\bmi\\b|hisense|philips|nvidia|shield|chromecast|fire ?tv|xgimi|epson|oneplus|benq|chiq|\\brca\\b|sanyo|toshiba|insignia|thomson|skyworth", regexOption);
        ISP = new Regex("fpt|viettel", regexOption);
        bindUdp = new Lan$$ExternalSyntheticLambda0(1);
        NOT_LAN = new Regex("^(lo|tun|tap|utun|ppp|wg|tailscale|rmnet|ccmni|pdp|dummy|docker|veth|br-|virbr|vmnet|vboxnet|awdl|llw|ap\\d|p2p)", regexOption);
    }

    public static ArrayList checks(Facts facts, String str, String str2) {
        Boolean bool;
        String checks$t$2;
        String checks$t$22;
        boolean z;
        ArrayList arrayList = new ArrayList();
        Net net = facts.net;
        int ordinal = net.ordinal();
        Boolean bool2 = null;
        if (ordinal != 0) {
            if (ordinal != 4) {
                bool = Boolean.FALSE;
            } else {
                bool = null;
            }
        } else {
            bool = Boolean.TRUE;
        }
        int ordinal2 = net.ordinal();
        if (ordinal2 != 0) {
            if (ordinal2 != 1) {
                if (ordinal2 != 2) {
                    if (ordinal2 != 3) {
                        if (ordinal2 == 4) {
                            checks$t$2 = checks$t$2(str2, "diagnose_kt.device_s_network_nothing", new Pair[0]);
                        } else {
                            throw new RuntimeException();
                        }
                    } else {
                        checks$t$2 = checks$t$2(str2, "diagnose_kt.tailscale_off", new Pair[0]);
                    }
                } else {
                    checks$t$2 = checks$t$2(str2, "diagnose_kt.device_another_network_than_2", new Pair[0]);
                }
            } else {
                checks$t$2 = checks$t$2(str2, "diagnose_kt.device_has_no_wi", new Pair[0]);
            }
        } else {
            checks$t$2 = checks$t$2(str2, "diagnose_kt.device_tv_s_network", new Pair[0]);
        }
        arrayList.add(new Check("net", bool, checks$t$2));
        List sorted = CollectionsKt.sorted(facts.getOpen());
        Boolean valueOf = Boolean.valueOf(facts.getAlive());
        boolean isEmpty = sorted.isEmpty();
        String str3 = facts.ip;
        if (!isEmpty) {
            checks$t$22 = checks$t$2(str2, "diagnose_kt.tv_answers_port", new Pair("open", CollectionsKt.joinToString$default(sorted, ", ", null, null, null, 62)));
        } else if (facts.getAlive()) {
            checks$t$22 = checks$t$2(str2, "diagnose_kt.tv_network_but_its", new Pair[0]);
        } else {
            checks$t$22 = checks$t$2(str2, "diagnose_kt.nothing_answers_at", new Pair("ip", str3));
        }
        arrayList.add(new Check("tv", valueOf, checks$t$22));
        if (facts.wireless) {
            arrayList.add(new Check("wireless", Boolean.TRUE, checks$t$2(str2, "diagnose_kt.wireless_found", new Pair[0])));
        }
        if (facts.vpn) {
            Function0 function0 = Lan.wifi;
            if (Lan.home(str3) != null && sorted.isEmpty()) {
                z = false;
            } else {
                z = true;
            }
            arrayList.add(new Check("vpn", Boolean.valueOf(z), checks$t$2(str2, "diagnose_kt.vpn", new Pair[0])));
        }
        List asList = ArraysKt.asList(new String[]{"ready", "unauthorized", "waiting", "offline"});
        String str4 = facts.adb;
        if (asList.contains(str4)) {
            arrayList.add(new Check("adb", Boolean.valueOf(Intrinsics.areEqual(str4, "ready")), checks$t$2(str2, "diagnose_kt.app_s_adb", new Pair("adb", str4))));
        }
        if (facts.tls) {
            if (str.equals("clock")) {
                bool2 = Boolean.FALSE;
            }
            arrayList.add(new Check("clock", bool2, checks$t$2(str2, "diagnose_kt.secure_connection_error_date", new Pair[0])));
        }
        return arrayList;
    }

    public static final String checks$t$2(String str, String str2, Pair... pairArr) {
        ConcurrentHashMap concurrentHashMap = Words.books;
        return Words.get(str, str2, (Pair[]) Arrays.copyOf(pairArr, pairArr.length));
    }

    public static String decide(Facts facts) {
        Set open = facts.getOpen();
        boolean areEqual = Intrinsics.areEqual(facts.kind, "android");
        if (facts.tls && !open.isEmpty()) {
            return "clock";
        }
        boolean isEmpty = open.isEmpty();
        boolean z = true;
        boolean z2 = facts.wireless;
        if (isEmpty) {
            int ordinal = facts.net.ordinal();
            if (ordinal != 1) {
                if (ordinal != 2) {
                    if (ordinal != 3) {
                        if (!z2 || !areEqual) {
                            if (facts.getAlive()) {
                                return "closed";
                            }
                            if (facts.moved != null) {
                                return "moved";
                            }
                            if (facts.vpn) {
                                Function0 function0 = Lan.wifi;
                                if (Lan.home(facts.ip) != null) {
                                    return "vpn";
                                }
                                return "off";
                            }
                            return "off";
                        }
                        return "wireless";
                    }
                    return "tailscale";
                }
                return "other_net";
            }
            return "no_wifi";
        }
        if (areEqual) {
            boolean contains = open.contains(5555);
            if (!open.contains(6466) && !open.contains(6467)) {
                z = false;
            }
            if (contains) {
                String str = facts.adb;
                if (Intrinsics.areEqual(str, "unauthorized") || Intrinsics.areEqual(str, "waiting")) {
                    return "allow";
                }
            }
            if (!contains && z2) {
                return "wireless";
            }
            if (!contains && (z || open.contains(8765))) {
                return "adb_off";
            }
            if (contains && !z) {
                return "remote_off";
            }
            return "up";
        }
        return "up";
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0090, code lost:
    
        if (r2.equals("vpn") == false) goto L33;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x00cf, code lost:
    
        r1 = kotlin.collections.ArraysKt.asList(new java.lang.String[]{"retry", "scan"});
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x0099, code lost:
    
        if (r2.equals("off") == false) goto L33;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00c8, code lost:
    
        if (r2.equals("closed") == false) goto L33;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static JSONObject json(Result result, String str) {
        List listOf;
        Object obj;
        EmptyMap emptyMap = EmptyMap.INSTANCE;
        Net net = Net.NA;
        String str2 = result.kind;
        Facts facts = new Facts(str2, result.ip, emptyMap, net, false, null, false, result.found, false, result.brand, PSKKeyManager.MAX_KEY_LENGTH_BYTES);
        String str3 = result.code;
        Pair say = say(facts, str3, str);
        JSONObject put = Census$$ExternalSyntheticOutline0.m10m("code", str3, "title", (String) say.first).put("fix", (String) say.second).put("ip", result.ip).put("kind", str2).put("ms", result.ms);
        switch (str3.hashCode()) {
            case -1357520532:
                break;
            case -1150095921:
                if (str3.equals("adb_off")) {
                    listOf = ArraysKt.asList(new String[]{"adbhelp", "retry"});
                    break;
                }
                listOf = MathKt.listOf("retry");
                break;
            case -1000044642:
                if (str3.equals("wireless")) {
                    listOf = ArraysKt.asList(new String[]{"wireless", "retry"});
                    break;
                }
                listOf = MathKt.listOf("retry");
                break;
            case 109935:
                break;
            case 116980:
                break;
            case 94755854:
                if (str3.equals("clock")) {
                    listOf = MathKt.listOf("retry");
                    break;
                }
                listOf = MathKt.listOf("retry");
                break;
            case 104087219:
                if (str3.equals("moved")) {
                    listOf = ArraysKt.asList(new String[]{"use", "retry"});
                    break;
                }
                listOf = MathKt.listOf("retry");
                break;
            case 1558548653:
                if (str3.equals("setup_off")) {
                    listOf = MathKt.listOf("fixsetup");
                    break;
                }
                listOf = MathKt.listOf("retry");
                break;
            default:
                listOf = MathKt.listOf("retry");
                break;
        }
        JSONObject put2 = put.put("actions", new JSONArray((Collection) listOf));
        Found found = result.found;
        if (found == null || (obj = new JSONObject().put("ip", found.ip).put("name", found.name)) == null) {
            obj = JSONObject.NULL;
        }
        JSONObject put3 = put2.put("found", obj);
        List<Check> list = result.checks;
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(list));
        for (Check check : list) {
            JSONObject put4 = new JSONObject().put("id", check.id);
            Object obj2 = check.ok;
            if (obj2 == null) {
                obj2 = JSONObject.NULL;
            }
            arrayList.add(put4.put("ok", obj2).put("note", check.note));
        }
        JSONObject put5 = put3.put("checks", new JSONArray((Collection) arrayList));
        Intrinsics.checkNotNullExpressionValue(put5, "put(...)");
        return put5;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Type inference failed for: r3v5, types: [java.util.Map, java.lang.Object] */
    public static Result run(final Real real, final String ip, String str, String str2, String err, String lang) {
        List asList;
        ExecutorService executorService;
        Found found;
        Found found2;
        Intrinsics.checkNotNullParameter(ip, "ip");
        Intrinsics.checkNotNullParameter(err, "err");
        Intrinsics.checkNotNullParameter(lang, "lang");
        long currentTimeMillis = System.currentTimeMillis();
        switch (str.hashCode()) {
            case -861391249:
                if (str.equals("android")) {
                    asList = ArraysKt.asList(new Integer[]{5555, 6466, 6467, 8765});
                    break;
                }
                asList = ArraysKt.asList(new Integer[]{5555, 6466, 6467, 8765});
                break;
            case 3451:
                if (str.equals("lg")) {
                    asList = ArraysKt.asList(new Integer[]{3000, 3001});
                    break;
                }
                asList = ArraysKt.asList(new Integer[]{5555, 6466, 6467, 8765});
                break;
            case 3506279:
                if (str.equals("roku")) {
                    asList = MathKt.listOf(8060);
                    break;
                }
                asList = ArraysKt.asList(new Integer[]{5555, 6466, 6467, 8765});
                break;
            case 112202737:
                if (str.equals("vidaa")) {
                    asList = MathKt.listOf(36669);
                    break;
                }
                asList = ArraysKt.asList(new Integer[]{5555, 6466, 6467, 8765});
                break;
            case 1864941562:
                if (str.equals("samsung")) {
                    asList = ArraysKt.asList(new Integer[]{8001, 8002});
                    break;
                }
                asList = ArraysKt.asList(new Integer[]{5555, 6466, 6467, 8765});
                break;
            default:
                asList = ArraysKt.asList(new Integer[]{5555, 6466, 6467, 8765});
                break;
        }
        ExecutorService newFixedThreadPool = Executors.newFixedThreadPool(asList.size() + 4, new Diagnose$$ExternalSyntheticLambda1(0));
        try {
            int mapCapacity = MapsKt__MapsKt.mapCapacity(CollectionsKt__IterablesKt.collectionSizeOrDefault(asList));
            if (mapCapacity < 16) {
                mapCapacity = 16;
            }
            LinkedHashMap linkedHashMap = new LinkedHashMap(mapCapacity);
            for (Object obj : asList) {
                final int intValue = ((Number) obj).intValue();
                linkedHashMap.put(obj, newFixedThreadPool.submit(new Callable(real, ip, intValue) { // from class: dev.tvremote.core.Diagnose$$ExternalSyntheticLambda2
                    public final /* synthetic */ String f$1;
                    public final /* synthetic */ int f$2;

                    {
                        this.f$1 = ip;
                        this.f$2 = intValue;
                    }

                    @Override // java.util.concurrent.Callable
                    public final Object call() {
                        Throwable cause;
                        String message;
                        Diagnose.Port port = Diagnose.Port.SILENT;
                        int i = this.f$2;
                        String host = this.f$1;
                        Intrinsics.checkNotNullParameter(host, "host");
                        try {
                            Lan.connect(host, i, 1400, new Lan$$ExternalSyntheticLambda0(0)).close();
                            return Diagnose.Port.OPEN;
                        } catch (ConnectException e) {
                            String message2 = e.getMessage();
                            if ((message2 != null && StringsKt.contains(message2, "refused", true)) || ((cause = e.getCause()) != null && (message = cause.getMessage()) != null && StringsKt.contains(message, "refused", true))) {
                                return Diagnose.Port.REFUSED;
                            }
                            return port;
                        } catch (Exception unused) {
                            return port;
                        }
                    }
                }));
            }
            Future submit = newFixedThreadPool.submit(new Diagnose$$ExternalSyntheticLambda3(real, ip));
            Future submit2 = newFixedThreadPool.submit((Callable) new Object());
            Future submit3 = newFixedThreadPool.submit(new Callable() { // from class: dev.tvremote.core.Diagnose$$ExternalSyntheticLambda5
                @Override // java.util.concurrent.Callable
                public final Object call() {
                    Diagnose.Real real2 = Diagnose.Real.this;
                    String host = ip;
                    Intrinsics.checkNotNullParameter(host, "host");
                    AdbLink adbLink = (AdbLink) real2.link;
                    if (adbLink != null) {
                        if (!Intrinsics.areEqual(adbLink.host, host)) {
                            adbLink = null;
                        }
                        if (adbLink != null) {
                            if (adbLink.waiting) {
                                return "waiting";
                            }
                            return adbLink.state();
                        }
                    }
                    return null;
                }
            });
            final boolean equals = str.equals("android");
            Future submit4 = newFixedThreadPool.submit(new Callable() { // from class: dev.tvremote.core.Diagnose$$ExternalSyntheticLambda6
                @Override // java.util.concurrent.Callable
                public final Object call() {
                    boolean z;
                    if (equals) {
                        Diagnose.Real real2 = real;
                        String host = ip;
                        Intrinsics.checkNotNullParameter(host, "host");
                        AdbTls adbTls = AdbTls.INSTANCE;
                        if (AdbTls.available() && AdbTls.wireless$default(8, host, (Function1) real2.bindUdp).getAny()) {
                            z = true;
                            return Boolean.valueOf(z);
                        }
                    }
                    z = false;
                    return Boolean.valueOf(z);
                }
            });
            Future submit5 = newFixedThreadPool.submit(new Callable(equals, real, ip) { // from class: dev.tvremote.core.Diagnose$$ExternalSyntheticLambda7
                public final /* synthetic */ boolean f$0;
                public final /* synthetic */ String f$2;

                {
                    this.f$2 = ip;
                }

                @Override // java.util.concurrent.Callable
                public final Object call() {
                    if (this.f$0) {
                        String host = this.f$2;
                        Intrinsics.checkNotNullParameter(host, "host");
                        return Ssdp.castName$default(host);
                    }
                    return "";
                }
            });
            LinkedHashMap linkedHashMap2 = new LinkedHashMap(MapsKt__MapsKt.mapCapacity(linkedHashMap.size()));
            Iterator it = linkedHashMap.entrySet().iterator();
            while (it.hasNext()) {
                Object next = it.next();
                Iterator it2 = it;
                Object key = ((Map.Entry) next).getKey();
                Object value = ((Map.Entry) next).getValue();
                Intrinsics.checkNotNullExpressionValue(value, "<get-value>(...)");
                linkedHashMap2.put(key, (Port) run$get((Future) value, Port.SILENT));
                it = it2;
            }
            Intrinsics.checkNotNull(submit);
            Object run$get = run$get(submit, Net.NA);
            Intrinsics.checkNotNullExpressionValue(run$get, "run$get(...)");
            Net net = (Net) run$get;
            Intrinsics.checkNotNull(submit2);
            Boolean bool = Boolean.FALSE;
            Object run$get2 = run$get(submit2, bool);
            Intrinsics.checkNotNullExpressionValue(run$get2, "run$get(...)");
            boolean booleanValue = ((Boolean) run$get2).booleanValue();
            Intrinsics.checkNotNull(submit3);
            String str3 = (String) run$get(submit3, null);
            Pattern compile = Pattern.compile("SSLHandshake|CertPathValidator|Chain validation|CERTIFICATE_VERIFY|not yet valid|expired", 66);
            Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
            boolean find = compile.matcher(err).find();
            Intrinsics.checkNotNull(submit4);
            Object run$get3 = run$get(submit4, bool);
            Intrinsics.checkNotNullExpressionValue(run$get3, "run$get(...)");
            boolean booleanValue2 = ((Boolean) run$get3).booleanValue();
            Intrinsics.checkNotNull(submit5);
            try {
                executorService = newFixedThreadPool;
                try {
                    Facts facts = new Facts(str, ip, linkedHashMap2, net, booleanValue, str3, find, null, booleanValue2, StringsKt.trim(str2 + " " + run$get(submit5, "")).toString(), 128);
                    String decide = decide(facts);
                    if (!decide.equals("off")) {
                        if (decide.equals("vpn")) {
                        }
                        found2 = null;
                        ArrayList checks = checks(facts, decide, lang);
                        long currentTimeMillis2 = System.currentTimeMillis() - currentTimeMillis;
                        String str4 = facts.brand;
                        String str5 = decide;
                        Result result = new Result(str5, ip, str, found2, checks, currentTimeMillis2, str4);
                        WireLog.all.add("·", "diagnose " + ip + " " + str + " -> " + ((Object) str5) + " (" + currentTimeMillis2 + " ms)");
                        executorService.shutdownNow();
                        return result;
                    }
                    if (!StringsKt.isBlank(str2)) {
                        try {
                            found = real.find(str, str2, ip);
                        } catch (Exception unused) {
                            found = null;
                        }
                        if (found != null) {
                            Facts facts2 = new Facts(str, ip, facts.ports, facts.net, facts.vpn, facts.adb, facts.tls, found, facts.wireless, facts.brand);
                            decide = decide(facts2);
                            facts = facts2;
                        }
                        found2 = found;
                        ArrayList checks2 = checks(facts, decide, lang);
                        long currentTimeMillis22 = System.currentTimeMillis() - currentTimeMillis;
                        String str42 = facts.brand;
                        String str52 = decide;
                        Result result2 = new Result(str52, ip, str, found2, checks2, currentTimeMillis22, str42);
                        WireLog.all.add("·", "diagnose " + ip + " " + str + " -> " + ((Object) str52) + " (" + currentTimeMillis22 + " ms)");
                        executorService.shutdownNow();
                        return result2;
                    }
                    found2 = null;
                    ArrayList checks22 = checks(facts, decide, lang);
                    long currentTimeMillis222 = System.currentTimeMillis() - currentTimeMillis;
                    String str422 = facts.brand;
                    String str522 = decide;
                    Result result22 = new Result(str522, ip, str, found2, checks22, currentTimeMillis222, str422);
                    WireLog.all.add("·", "diagnose " + ip + " " + str + " -> " + ((Object) str522) + " (" + currentTimeMillis222 + " ms)");
                    executorService.shutdownNow();
                    return result22;
                } catch (Throwable th) {
                    th = th;
                    executorService.shutdownNow();
                    throw th;
                }
            } catch (Throwable th2) {
                th = th2;
                executorService = newFixedThreadPool;
            }
        } catch (Throwable th3) {
            th = th3;
            executorService = newFixedThreadPool;
        }
    }

    public static final Object run$get(Future future, Object obj) {
        try {
            return future.get(2100L, TimeUnit.MILLISECONDS);
        } catch (Exception unused) {
            return obj;
        }
    }

    public static Pair say(Facts facts, String str, String lang) {
        String str2;
        Intrinsics.checkNotNullParameter(lang, "lang");
        int hashCode = str.hashCode();
        String str3 = facts.ip;
        switch (hashCode) {
            case -1945546770:
                if (str.equals("other_net")) {
                    return new Pair(say$t(lang, "diagnose_kt.device_another_network_than", new Pair[0]), say$t(lang, "diagnose_kt.tv_at_join_tv", new Pair("ip", str3)));
                }
                break;
            case -1357520532:
                if (str.equals("closed")) {
                    return new Pair(say$t(lang, "diagnose_kt.tv_network_but_not", new Pair[0]), say$t(lang, "diagnose_kt.usually_tv_dozing_press", new Pair[0]));
                }
                break;
            case -1150095921:
                if (str.equals("adb_off")) {
                    return new Pair(say$t(lang, "diagnose_kt.adb_debugging_off_tv", new Pair[0]), Census$$ExternalSyntheticOutline0.m(say$t(lang, "diagnose_kt.keys_still_work_picture", new Pair[0]), tclHint(facts, lang)));
                }
                break;
            case -1000044642:
                if (str.equals("wireless")) {
                    return new Pair(say$t(lang, "diagnose_kt.wireless_only", new Pair[0]), Census$$ExternalSyntheticOutline0.m(say$t(lang, "diagnose_kt.wireless_pair", new Pair[0]), tclHint(facts, lang)));
                }
                break;
            case -57604358:
                if (str.equals("tailscale")) {
                    return new Pair(say$t(lang, "diagnose_kt.tailscale_off_device", new Pair[0]), say$t(lang, "diagnose_kt.tv_at_tailscale_address", new Pair("ip", str3)));
                }
                break;
            case 3739:
                if (str.equals("up")) {
                    return new Pair(say$t(lang, "diagnose_kt.tv_answering", new Pair[0]), say$t(lang, "diagnose_kt.error_was_momentary_try", new Pair[0]));
                }
                break;
            case 116980:
                if (str.equals("vpn")) {
                    return new Pair(say$t(lang, "diagnose_kt.vpn_way", new Pair[0]), say$t(lang, "diagnose_kt.tv_at_home_out", new Pair[0]));
                }
                break;
            case 92906313:
                if (str.equals("allow")) {
                    return new Pair(say$t(lang, "setup.tv_waiting_allow", new Pair[0]), say$t(lang, "diagnose_kt.look_at_tv_tick", new Pair[0]));
                }
                break;
            case 94755854:
                if (str.equals("clock")) {
                    return new Pair(say$t(lang, "diagnose_kt.tv_s_date_time", new Pair[0]), say$t(lang, "diagnose_kt.tv_answers_but_secure", new Pair[0]));
                }
                break;
            case 104087219:
                if (str.equals("moved")) {
                    String say$t = say$t(lang, "diagnosing.the_tv_has_a", new Pair[0]);
                    String str4 = null;
                    Found found = facts.moved;
                    if (found != null) {
                        str2 = found.name;
                    } else {
                        str2 = null;
                    }
                    Pair pair = new Pair("name", str2);
                    if (found != null) {
                        str4 = found.ip;
                    }
                    return new Pair(say$t, say$t(lang, "diagnose_kt.found_at_was_use", pair, new Pair("ip", str4), new Pair("was", str3)));
                }
                break;
            case 1041646070:
                if (str.equals("remote_off")) {
                    return new Pair(say$t(lang, "diagnose_kt.tv_s_remote_service", new Pair[0]), say$t(lang, "diagnose_kt.adb_answers_so_keys", new Pair[0]));
                }
                break;
            case 1558548653:
                if (str.equals("setup_off")) {
                    return new Pair(say$t(lang, "diagnose_kt.setup_off_title", new Pair[0]), say$t(lang, "diagnose_kt.setup_off_fix", new Pair[0]));
                }
                break;
            case 2110376659:
                if (str.equals("no_wifi")) {
                    return new Pair(say$t(lang, "diagnose_kt.device_not_wi_fi", new Pair[0]), say$t(lang, "diagnose_kt.turn_wi_fi_join", new Pair[0]));
                }
                break;
        }
        return new Pair(say$t(lang, "diagnose_kt.tv_not_answering", new Pair[0]), say$t(lang, "diagnose_kt.tv_may_be_off", new Pair[0]));
    }

    public static final String say$t(String str, String str2, Pair... pairArr) {
        ConcurrentHashMap concurrentHashMap = Words.books;
        return Words.get(str, str2, (Pair[]) Arrays.copyOf(pairArr, pairArr.length));
    }

    public static Result setup(String out, String ip, String lang) {
        Intrinsics.checkNotNullParameter(out, "out");
        Intrinsics.checkNotNullParameter(ip, "ip");
        Intrinsics.checkNotNullParameter(lang, "lang");
        List lines = StringsKt.lines(StringsKt.trim(out).toString());
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(lines));
        Iterator it = lines.iterator();
        while (it.hasNext()) {
            arrayList.add(StringsKt.trim((String) it.next()).toString());
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator it2 = arrayList.iterator();
        while (it2.hasNext()) {
            Object next = it2.next();
            if (((String) next).length() > 0) {
                arrayList2.add(next);
            }
        }
        if (arrayList2.size() >= 2 && StringsKt.contains((CharSequence) arrayList2.get(0), "amazon", true) && Intrinsics.areEqual(CollectionsKt.last(arrayList2), "0")) {
            return new Result("setup_off", ip, "android", null, MathKt.listOf(new Check("setup", Boolean.FALSE, Words.get(lang, "diagnose_kt.setup_off_note", new Pair[0]))), 0L, "");
        }
        return null;
    }

    public static boolean tailnet(InetAddress inetAddress) {
        Function0 function0 = Lan.wifi;
        InetAddress byName = InetAddress.getByName("100.64.0.0");
        Intrinsics.checkNotNullExpressionValue(byName, "getByName(...)");
        return Lan.inSubnet(inetAddress, byName, 10);
    }

    public static String tclHint(Facts facts, String str) {
        Regex regex = ISP;
        String str2 = facts.brand;
        if (regex.containsMatchIn(str2)) {
            return ApkSigner$$ExternalSyntheticOutline0.m("\n", Words.get(str, "diagnose_kt.isp_locked", new Pair[0]));
        }
        if (!StringsKt.isBlank(str2) && !StringsKt.contains(str2, "tcl", true) && OTHER_BRANDS.containsMatchIn(str2)) {
            return "";
        }
        return ApkSigner$$ExternalSyntheticOutline0.m("\n", Words.get(str, "setup.tcl_hidden_adb", new Pair[0]));
    }

    /* loaded from: classes.dex */
    public final class Facts {
        public final String adb;
        public final String brand;
        public final String ip;
        public final String kind;
        public final Found moved;
        public final Net net;
        public final Object ports;
        public final boolean tls;
        public final boolean vpn;
        public final boolean wireless;

        public Facts(String str, String ip, Map ports, Net net, boolean z, String str2, boolean z2, Found found, boolean z3, String brand) {
            Intrinsics.checkNotNullParameter(ip, "ip");
            Intrinsics.checkNotNullParameter(ports, "ports");
            Intrinsics.checkNotNullParameter(net, "net");
            Intrinsics.checkNotNullParameter(brand, "brand");
            this.kind = str;
            this.ip = ip;
            this.ports = ports;
            this.net = net;
            this.vpn = z;
            this.adb = str2;
            this.tls = z2;
            this.moved = found;
            this.wireless = z3;
            this.brand = brand;
        }

        /* JADX WARN: Type inference failed for: r0v0, types: [java.util.Map, java.lang.Object] */
        public final boolean getAlive() {
            boolean z;
            Collection values = this.ports.values();
            if (values != null) {
                z = true;
            } else {
                z = false;
            }
            if (!z || !values.isEmpty()) {
                Iterator it = values.iterator();
                while (it.hasNext()) {
                    if (((Port) it.next()) != Port.SILENT) {
                        return true;
                    }
                }
            }
            return false;
        }

        /* JADX WARN: Type inference failed for: r1v0, types: [java.util.Map, java.lang.Object] */
        public final Set getOpen() {
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            for (Map.Entry entry : this.ports.entrySet()) {
                if (((Port) entry.getValue()) == Port.OPEN) {
                    linkedHashMap.put(entry.getKey(), entry.getValue());
                }
            }
            return linkedHashMap.keySet();
        }

        /* JADX WARN: Illegal instructions before constructor call */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public /* synthetic */ Facts(String str, String str2, Map map, Net net, boolean z, String str3, boolean z2, Found found, boolean z3, String str4, int i) {
            this(str, str2, map, net, z, str3, z2, found, r12, r13);
            String str5;
            boolean z4;
            z2 = (i & 64) != 0 ? false : z2;
            found = (i & 128) != 0 ? null : found;
            if ((i & PSKKeyManager.MAX_KEY_LENGTH_BYTES) != 0) {
                str5 = str4;
                z4 = false;
            } else {
                str5 = str4;
                z4 = z3;
            }
        }
    }
}
