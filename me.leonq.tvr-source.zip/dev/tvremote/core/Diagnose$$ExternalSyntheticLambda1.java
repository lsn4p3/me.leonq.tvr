package dev.tvremote.core;

import java.util.concurrent.ThreadFactory;
import org.conscrypt.metrics.ConscryptStatsLog;

/* loaded from: classes.dex */
public final /* synthetic */ class Diagnose$$ExternalSyntheticLambda1 implements ThreadFactory {
    public final /* synthetic */ int $r8$classId;

    @Override // java.util.concurrent.ThreadFactory
    public final Thread newThread(Runnable runnable) {
        switch (this.$r8$classId) {
            case 0:
                Thread thread = new Thread(runnable, "diagnose");
                thread.setDaemon(true);
                return thread;
            case 1:
                Thread thread2 = new Thread(runnable, "diagnose");
                thread2.setDaemon(true);
                return thread2;
            case 2:
                Thread thread3 = new Thread(runnable, "fleet-status");
                thread3.setDaemon(true);
                return thread3;
            case 3:
                Thread thread4 = new Thread(runnable, "lg-out");
                thread4.setDaemon(true);
                return thread4;
            case 4:
                Thread thread5 = new Thread(runnable, "roku-out");
                thread5.setDaemon(true);
                return thread5;
            case 5:
                Thread thread6 = new Thread(runnable, "samsung-out");
                thread6.setDaemon(true);
                return thread6;
            case 6:
                Thread thread7 = new Thread(runnable, "vidaa-out");
                thread7.setDaemon(true);
                return thread7;
            case 7:
                Thread thread8 = new Thread(runnable, "http-stall");
                thread8.setDaemon(true);
                return thread8;
            case 8:
                Thread thread9 = new Thread(runnable, "ir");
                thread9.setDaemon(true);
                return thread9;
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                Thread thread10 = new Thread(runnable, "tv-status");
                thread10.setDaemon(true);
                return thread10;
            default:
                Thread thread11 = new Thread(runnable, "tv-status-sweep");
                thread11.setDaemon(true);
                return thread11;
        }
    }
}
