package dev.tvremote.core;

import dev.tvremote.core.adb.Adb;
import java.net.Socket;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.conscrypt.FileClientSessionCache;
import org.conscrypt.metrics.ConscryptStatsLog;

/* loaded from: classes.dex */
public final /* synthetic */ class Fleet$$ExternalSyntheticLambda0 implements Function1 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Adb f$0;

    public /* synthetic */ Fleet$$ExternalSyntheticLambda0(Adb adb, int i) {
        this.$r8$classId = i;
        this.f$0 = adb;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        Adb adb = this.f$0;
        switch (this.$r8$classId) {
            case 0:
                String it = (String) obj;
                Intrinsics.checkNotNullParameter(it, "it");
                ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                return adb.shell(120000L, it);
            case 1:
                Socket it2 = (Socket) obj;
                Intrinsics.checkNotNullParameter(it2, "it");
                adb.sock = it2;
                return Unit.INSTANCE;
            case 2:
                String it3 = (String) obj;
                Intrinsics.checkNotNullParameter(it3, "it");
                ConcurrentHashMap concurrentHashMap2 = Adb.ASKING;
                return adb.shell(120000L, it3);
            case 3:
                String it4 = (String) obj;
                Intrinsics.checkNotNullParameter(it4, "it");
                ConcurrentHashMap concurrentHashMap3 = Adb.ASKING;
                return adb.shell(120000L, it4);
            case 4:
                String it5 = (String) obj;
                Intrinsics.checkNotNullParameter(it5, "it");
                return adb.shell(600000L, it5);
            case 5:
                String it6 = (String) obj;
                Intrinsics.checkNotNullParameter(it6, "it");
                return adb.shell(600000L, it6);
            case 6:
                String it7 = (String) obj;
                Intrinsics.checkNotNullParameter(it7, "it");
                ConcurrentHashMap concurrentHashMap4 = Adb.ASKING;
                return adb.shell(120000L, it7);
            case 7:
                String it8 = (String) obj;
                Intrinsics.checkNotNullParameter(it8, "it");
                ConcurrentHashMap concurrentHashMap5 = Adb.ASKING;
                return adb.shell(120000L, it8);
            case 8:
                String it9 = (String) obj;
                Intrinsics.checkNotNullParameter(it9, "it");
                ConcurrentHashMap concurrentHashMap6 = Adb.ASKING;
                return adb.shell(120000L, it9);
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                String it10 = (String) obj;
                Intrinsics.checkNotNullParameter(it10, "it");
                ConcurrentHashMap concurrentHashMap7 = Adb.ASKING;
                return adb.shell(120000L, it10);
            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                String it11 = (String) obj;
                Intrinsics.checkNotNullParameter(it11, "it");
                ConcurrentHashMap concurrentHashMap8 = Adb.ASKING;
                return adb.shell(120000L, it11);
            case 11:
                String it12 = (String) obj;
                Intrinsics.checkNotNullParameter(it12, "it");
                ConcurrentHashMap concurrentHashMap9 = Adb.ASKING;
                return adb.shell(120000L, it12);
            case FileClientSessionCache.MAX_SIZE /* 12 */:
                String it13 = (String) obj;
                Intrinsics.checkNotNullParameter(it13, "it");
                ConcurrentHashMap concurrentHashMap10 = Adb.ASKING;
                return adb.shell(120000L, it13);
            case 13:
                String it14 = (String) obj;
                Intrinsics.checkNotNullParameter(it14, "it");
                ConcurrentHashMap concurrentHashMap11 = Adb.ASKING;
                return adb.shell(120000L, it14);
            case 14:
                String it15 = (String) obj;
                Intrinsics.checkNotNullParameter(it15, "it");
                ConcurrentHashMap concurrentHashMap12 = Adb.ASKING;
                return adb.shell(120000L, it15);
            case 15:
                String it16 = (String) obj;
                Intrinsics.checkNotNullParameter(it16, "it");
                ConcurrentHashMap concurrentHashMap13 = Adb.ASKING;
                return adb.shell(120000L, it16);
            case 16:
                String c = (String) obj;
                Intrinsics.checkNotNullParameter(c, "c");
                return adb.shell(8000L, c);
            case 17:
                String c2 = (String) obj;
                Intrinsics.checkNotNullParameter(c2, "c");
                return adb.shell(8000L, c2);
            case 18:
                String it17 = (String) obj;
                Intrinsics.checkNotNullParameter(it17, "it");
                ConcurrentHashMap concurrentHashMap14 = Adb.ASKING;
                return adb.shell(120000L, it17);
            default:
                String it18 = (String) obj;
                Intrinsics.checkNotNullParameter(it18, "it");
                ConcurrentHashMap concurrentHashMap15 = Adb.ASKING;
                return adb.shell(120000L, it18);
        }
    }
}
