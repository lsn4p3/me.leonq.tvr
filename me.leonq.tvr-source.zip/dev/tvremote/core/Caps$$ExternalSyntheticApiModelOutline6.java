package dev.tvremote.core;

import android.content.ComponentName;
import android.content.Context;
import android.media.ExifInterface;
import android.service.quicksettings.TileService;
import java.io.InputStream;
import java.util.OptionalInt;
import javax.net.ssl.SNIHostName;
import javax.net.ssl.X509ExtendedTrustManager;
import javax.net.ssl.X509TrustManager;

/* loaded from: classes.dex */
public abstract /* synthetic */ class Caps$$ExternalSyntheticApiModelOutline6 {
    public static /* synthetic */ ExifInterface m(InputStream inputStream) {
        return new ExifInterface(inputStream);
    }

    public static /* bridge */ /* synthetic */ OptionalInt m() {
        return OptionalInt.empty();
    }

    public static /* bridge */ /* synthetic */ OptionalInt m(int i) {
        return OptionalInt.of(i);
    }

    public static /* synthetic */ SNIHostName m(String str) {
        return new SNIHostName(str);
    }

    public static /* bridge */ /* synthetic */ X509ExtendedTrustManager m(X509TrustManager x509TrustManager) {
        return (X509ExtendedTrustManager) x509TrustManager;
    }

    public static /* bridge */ /* synthetic */ void m(Context context, ComponentName componentName) {
        TileService.requestListeningState(context, componentName);
    }

    /* renamed from: m, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ boolean m4m(X509TrustManager x509TrustManager) {
        return x509TrustManager instanceof X509ExtendedTrustManager;
    }
}
