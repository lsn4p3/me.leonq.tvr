package dev.tvremote.core;

import dev.tvremote.core.remote.Vidaa;
import dev.tvremote.core.remote.Vidaa$device$$inlined$sortedBy$1;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.CollectionsKt__MutableCollectionsJVMKt;
import kotlin.collections.EmptyList;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.sequences.Sequence;
import kotlin.sequences.SequencesKt;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class Census$post$1 extends FunctionReferenceImpl implements Function2 {
    public final /* synthetic */ int $r8$classId;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ Census$post$1(int i, Object obj, Class cls, String str, String str2, int i2) {
        super(i, obj, cls, str, str2);
        this.$r8$classId = i2;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(Object obj, Object obj2) {
        Boolean bool;
        String str;
        String str2;
        Object obj3;
        List<String> list;
        boolean z = true;
        String str3 = null;
        boolean z2 = false;
        switch (this.$r8$classId) {
            case 0:
                String p0 = (String) obj;
                String p1 = (String) obj2;
                Intrinsics.checkNotNullParameter(p0, "p0");
                Intrinsics.checkNotNullParameter(p1, "p1");
                ((Report) this.receiver).getClass();
                try {
                    URLConnection openConnection = new URL(p0).openConnection();
                    Intrinsics.checkNotNull(openConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
                    HttpURLConnection httpURLConnection = (HttpURLConnection) openConnection;
                    try {
                        httpURLConnection.setConnectTimeout(4000);
                        httpURLConnection.setReadTimeout(4000);
                        httpURLConnection.setRequestMethod("POST");
                        httpURLConnection.setDoOutput(true);
                        httpURLConnection.setRequestProperty("Content-Type", "application/json");
                        OutputStream outputStream = httpURLConnection.getOutputStream();
                        try {
                            byte[] bytes = p1.getBytes(Charsets.UTF_8);
                            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                            outputStream.write(bytes);
                            MathKt.closeFinally(outputStream, null);
                            int responseCode = httpURLConnection.getResponseCode();
                            if (200 > responseCode || responseCode >= 300) {
                                z = false;
                            }
                            z2 = z;
                        } finally {
                        }
                    } finally {
                        httpURLConnection.disconnect();
                    }
                } catch (Exception unused) {
                }
                return Boolean.valueOf(z2);
            default:
                String p02 = (String) obj;
                byte[] p12 = (byte[]) obj2;
                Intrinsics.checkNotNullParameter(p02, "p0");
                Intrinsics.checkNotNullParameter(p12, "p1");
                Vidaa vidaa = (Vidaa) this.receiver;
                vidaa.getClass();
                String str4 = new String(p12, Charsets.UTF_8);
                Vidaa.Companion companion = Vidaa.Companion;
                JSONObject access$json = Vidaa.Companion.access$json(str4);
                if (!StringsKt__StringsJVMKt.endsWith(p02, false, "/ui_service/state") && !StringsKt__StringsJVMKt.endsWith(p02, false, "/ui_service/data/gettvstate") && !StringsKt__StringsJVMKt.endsWith(p02, false, "/ui_service/data/state")) {
                    if (!StringsKt__StringsJVMKt.endsWith(p02, false, "/volumechange") && !StringsKt__StringsJVMKt.endsWith(p02, false, "/ui_service/volume") && !StringsKt__StringsJVMKt.endsWith(p02, false, "/platform_service/data/getvolume")) {
                        if (StringsKt__StringsJVMKt.endsWith(p02, false, "/actions/tvsleep")) {
                            vidaa.isOn = Boolean.FALSE;
                        } else if (StringsKt__StringsJVMKt.endsWith(p02, false, "/ui_service/data/sourcelist")) {
                            vidaa.sources = Vidaa.Companion.access$list(str4, "sourcelist");
                        } else if (StringsKt__StringsJVMKt.endsWith(p02, false, "/ui_service/data/applist")) {
                            vidaa.apps = Vidaa.Companion.access$list(str4, "applist");
                        } else if ((StringsKt__StringsJVMKt.endsWith(p02, false, "/platform_service/data/getdeviceinfo") || StringsKt__StringsJVMKt.endsWith(p02, false, "/platform_service/data/gettvinfo")) && access$json != null) {
                            List list2 = Vidaa.NAME_FIELDS;
                            ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(list2));
                            Iterator it = list2.iterator();
                            while (it.hasNext()) {
                                arrayList.add(access$json.optString((String) it.next()));
                            }
                            Iterator it2 = CollectionsKt.plus(CollectionsKt.plus(arrayList, access$json.optString("model_name")), access$json.optString("model")).iterator();
                            while (true) {
                                if (it2.hasNext()) {
                                    obj3 = it2.next();
                                    String str5 = (String) obj3;
                                    Intrinsics.checkNotNull(str5);
                                    if (!StringsKt.isBlank(str5)) {
                                    }
                                } else {
                                    obj3 = null;
                                }
                            }
                            String str6 = (String) obj3;
                            if (str6 != null) {
                                vidaa.model = StringsKt.trim(str6).toString();
                            }
                            String optString = access$json.optString("brand");
                            if (optString.length() == 0) {
                                optString = access$json.optString("manufacturer");
                            }
                            Intrinsics.checkNotNull(optString);
                            if (StringsKt.isBlank(optString)) {
                                optString = null;
                            }
                            if (optString != null) {
                                vidaa.vendor = StringsKt.trim(optString).toString();
                            }
                            String optString2 = access$json.optString("firmware_version");
                            if (optString2.length() == 0) {
                                optString2 = access$json.optString("sw_version");
                            }
                            Intrinsics.checkNotNull(optString2);
                            if (!StringsKt.isBlank(optString2)) {
                                str3 = optString2;
                            }
                            if (str3 != null) {
                                vidaa.version = StringsKt.trim(str3).toString();
                            }
                            LinkedHashSet linkedHashSet = new LinkedHashSet();
                            Iterator<String> keys = access$json.keys();
                            Intrinsics.checkNotNullExpressionValue(keys, "keys(...)");
                            Sequence asSequence = SequencesKt.asSequence(keys);
                            Vidaa$device$$inlined$sortedBy$1 vidaa$device$$inlined$sortedBy$1 = new Vidaa$device$$inlined$sortedBy$1(null == true ? 1 : 0);
                            ArrayList mutableList = SequencesKt.toMutableList(asSequence);
                            CollectionsKt__MutableCollectionsJVMKt.sortWith(mutableList, vidaa$device$$inlined$sortedBy$1);
                            Iterator it3 = mutableList.iterator();
                            if (!it3.hasNext()) {
                                list = EmptyList.INSTANCE;
                            } else {
                                Object next = it3.next();
                                if (!it3.hasNext()) {
                                    list = MathKt.listOf(next);
                                } else {
                                    ArrayList arrayList2 = new ArrayList();
                                    arrayList2.add(next);
                                    while (it3.hasNext()) {
                                        arrayList2.add(it3.next());
                                    }
                                    list = arrayList2;
                                }
                            }
                            for (String str7 : list) {
                                Intrinsics.checkNotNull(str7);
                                Locale locale = Locale.ROOT;
                                String lowerCase = str7.toLowerCase(locale);
                                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                                if (!StringsKt.contains(lowerCase, "mac", false)) {
                                    Set set = Vidaa.IFACES;
                                    String lowerCase2 = str7.toLowerCase(locale);
                                    Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
                                    if (set.contains(lowerCase2)) {
                                    }
                                }
                                String optString3 = access$json.optString(str7);
                                Intrinsics.checkNotNullExpressionValue(optString3, "optString(...)");
                                String normMac$shared_release = Vidaa.Companion.normMac$shared_release(optString3);
                                if (normMac$shared_release != null) {
                                    linkedHashSet.add(normMac$shared_release);
                                }
                            }
                            if (!linkedHashSet.isEmpty()) {
                                LinkedHashSet linkedHashSet2 = new LinkedHashSet();
                                linkedHashSet2.addAll(vidaa.macs);
                                linkedHashSet2.addAll(linkedHashSet);
                                vidaa.macs = CollectionsKt.toList(linkedHashSet2);
                                if (vidaa.mac.length() == 0) {
                                    vidaa.mac = (String) CollectionsKt.first(vidaa.macs);
                                }
                                vidaa.remember(vidaa.mac, "mac");
                                vidaa.remember(new JSONArray((Collection) vidaa.macs), "macs");
                            }
                        }
                    } else if (access$json != null) {
                        Triple triple = vidaa.volume;
                        if (triple == null) {
                            triple = new Triple(0, 100, Boolean.FALSE);
                        }
                        Object opt = access$json.opt("volume_type");
                        if (opt != null) {
                            str2 = opt.toString();
                        } else {
                            str2 = null;
                        }
                        String optString4 = access$json.optString("volume_value");
                        if (optString4.length() == 0) {
                            optString4 = access$json.optString("volume");
                        }
                        Intrinsics.checkNotNullExpressionValue(optString4, "ifEmpty(...)");
                        Integer intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull(optString4);
                        if (Intrinsics.areEqual(str2, "2")) {
                            if (intOrNull == null || intOrNull.intValue() != 1) {
                                z = false;
                            }
                            triple = Triple.copy$default(triple, null, Boolean.valueOf(z), 3);
                        } else if (intOrNull != null && (str2 == null || str2.equals("0") || str2.equals("1"))) {
                            triple = Triple.copy$default(triple, intOrNull, null, 6);
                        }
                        vidaa.volume = triple;
                    }
                } else if (access$json != null) {
                    String optString5 = access$json.optString("statetype");
                    Intrinsics.checkNotNullExpressionValue(optString5, "optString(...)");
                    String lowerCase3 = optString5.toLowerCase(Locale.ROOT);
                    Intrinsics.checkNotNullExpressionValue(lowerCase3, "toLowerCase(...)");
                    if (!StringsKt.contains(lowerCase3, "off", false) && !lowerCase3.equals("fake_sleep_0")) {
                        if (lowerCase3.length() > 0) {
                            bool = Boolean.TRUE;
                        } else {
                            bool = vidaa.isOn;
                        }
                    } else {
                        bool = Boolean.FALSE;
                    }
                    vidaa.isOn = bool;
                    if (lowerCase3.equals("app")) {
                        str = access$json.optString("name");
                        if (str.length() == 0) {
                            str = access$json.optString("appId");
                        }
                        Intrinsics.checkNotNullExpressionValue(str, "ifEmpty(...)");
                    } else {
                        str = "";
                    }
                    vidaa.app = str;
                }
                Iterator it4 = vidaa.waits.iterator();
                Intrinsics.checkNotNullExpressionValue(it4, "iterator(...)");
                while (it4.hasNext()) {
                    Pair pair = (Pair) it4.next();
                    if (((Boolean) ((Function1) pair.first).invoke(p02)).booleanValue()) {
                        ((ArrayBlockingQueue) pair.second).offer(new Pair(p02, str4));
                    }
                }
                return Unit.INSTANCE;
        }
    }
}
