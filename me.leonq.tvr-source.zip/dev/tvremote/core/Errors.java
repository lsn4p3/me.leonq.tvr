package dev.tvremote.core;

import dev.tvremote.core.ontv.SetupNeed;
import dev.tvremote.core.web.Cancelled;
import dev.tvremote.core.web.NoRoom;
import dev.tvremote.core.web.Qr;
import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.sequences.SequencesKt;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;

/* loaded from: classes.dex */
public abstract class Errors {
    public static final Object ANDROID = MapsKt__MapsKt.mapOf(new Pair(21, "5.0"), new Pair(22, "5.1"), new Pair(23, "6"), new Pair(24, "7"), new Pair(25, "7.1"), new Pair(26, "8"), new Pair(27, "8.1"), new Pair(28, "9"), new Pair(29, "10"), new Pair(30, "11"), new Pair(31, "12"), new Pair(32, "12L"), new Pair(33, "13"), new Pair(34, "14"), new Pair(35, "15"), new Pair(36, "16"));

    public static boolean fromInternet(IOException iOException) {
        Iterator it = SequencesKt.generateSequence(iOException, new Lan$$ExternalSyntheticLambda0(5)).iterator();
        while (it.hasNext()) {
            StackTraceElement[] stackTrace = ((Throwable) it.next()).getStackTrace();
            Intrinsics.checkNotNullExpressionValue(stackTrace, "getStackTrace(...)");
            for (StackTraceElement stackTraceElement : stackTrace) {
                String className = stackTraceElement.getClassName();
                Intrinsics.checkNotNull(className);
                if (StringsKt__StringsJVMKt.startsWith(className, false, "sun.net.www.") || StringsKt__StringsJVMKt.startsWith(className, false, "com.android.okhttp.") || StringsKt__StringsJVMKt.startsWith(className, false, "dev.tvremote.update.") || StringsKt__StringsJVMKt.startsWith(className, false, "java.net.HttpURLConnection") || StringsKt__StringsJVMKt.startsWith(className, false, "javax.net.ssl.HttpsURLConnection")) {
                    return true;
                }
            }
        }
        return false;
    }

    /* JADX WARN: Type inference failed for: r3v3, types: [java.util.Map, java.lang.Object] */
    public static String say(String lang, Throwable e) {
        NoRoom noRoom;
        int i = 4;
        Intrinsics.checkNotNullParameter(e, "e");
        Intrinsics.checkNotNullParameter(lang, "lang");
        String joinToString$default = SequencesKt.joinToString$default(SequencesKt.generateSequence(e, new Lan$$ExternalSyntheticLambda0(2)), " ", new Lan$$ExternalSyntheticLambda0(3), 30);
        WireLog.all.add("·", "error " + joinToString$default);
        String say = SetupNeed.say(lang, e);
        if (say != null) {
            return say;
        }
        if (StringsKt.contains(joinToString$default, "stopped", false)) {
            Iterator it = SequencesKt.generateSequence(e, new Lan$$ExternalSyntheticLambda0(i)).iterator();
            while (it.hasNext()) {
                if (((Throwable) it.next()) instanceof Cancelled) {
                    return say$t(lang, "errors.stopped", new Pair[0]);
                }
            }
        }
        MatcherMatchResult find = NoRoom.CODE.find(joinToString$default, 0);
        if (find != null) {
            MatcherMatchResult$groupValues$1 matcherMatchResult$groupValues$1 = (MatcherMatchResult$groupValues$1) find.getGroupValues();
            noRoom = new NoRoom(Long.parseLong((String) matcherMatchResult$groupValues$1.get(1)), Long.parseLong((String) matcherMatchResult$groupValues$1.get(2)), Long.parseLong((String) matcherMatchResult$groupValues$1.get(3)), Intrinsics.areEqual(matcherMatchResult$groupValues$1.get(4), "1"));
        } else {
            noRoom = null;
        }
        if (noRoom != null) {
            String size = Qr.size(noRoom.free);
            String size2 = Qr.size(noRoom.size);
            String size3 = Qr.size(noRoom.need);
            if (noRoom.apk) {
                Pair[] pairArr = {new Pair("left", size), new Pair("big", size2), new Pair("least", size3)};
                ConcurrentHashMap concurrentHashMap = Words.books;
                return Words.get(lang, "transfer.no_room_apk", (Pair[]) Arrays.copyOf(pairArr, 3));
            }
            Pair[] pairArr2 = {new Pair("left", size), new Pair("big", size2), new Pair("least", size3)};
            ConcurrentHashMap concurrentHashMap2 = Words.books;
            return Words.get(lang, "transfer.no_room_file", (Pair[]) Arrays.copyOf(pairArr2, 3));
        }
        if (!StringsKt.contains(joinToString$default, "update file does not match its signed checksum", false) && !StringsKt.contains(joinToString$default, "update list not signed by this project", false)) {
            if (StringsKt.contains(joinToString$default, "launcher:play", false)) {
                return say$t(lang, "errors.launcher_play", new Pair[0]);
            }
            if (StringsKt.contains(joinToString$default, "launcher:home", false)) {
                return say$t(lang, "core.fr_launcher_home", new Pair[0]);
            }
            if (StringsKt.contains(joinToString$default, "launcher list not signed by this project", false)) {
                return say$t(lang, "errors.launcher_list_bad", new Pair[0]);
            }
            if (StringsKt.contains(joinToString$default, "launcher file does not match its signed checksum", false)) {
                return say$t(lang, "errors.launcher_file_bad", new Pair[0]);
            }
            if (StringsKt.contains(joinToString$default, "adb pair: wrong code", false)) {
                return say$t(lang, "errors.pairing_code_wrong_has", new Pair[0]);
            }
            if (StringsKt.contains(joinToString$default, "adb pair: not a pairing port", false)) {
                return say$t(lang, "errors.not_pairing_port_use", new Pair[0]);
            }
            if (StringsKt.contains(joinToString$default, "adb tls: this device is not paired", false)) {
                return say$t(lang, "errors.tv_not_paired_with", new Pair[0]);
            }
            if (StringsKt.contains(joinToString$default, "adb tls: this app cannot pair", false)) {
                return say$t(lang, "errors.app_cannot_pair_through", new Pair[0]);
            }
            Pattern compile = Pattern.compile("SSLHandshake|CertPathValidator|Chain validation|CERTIFICATE_VERIFY|not yet valid|expired", 66);
            Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
            if (compile.matcher(joinToString$default).find()) {
                return say$t(lang, "errors.could_not_open_secure", new Pair[0]);
            }
            if (StringsKt.contains(joinToString$default, "the home network is out of reach under the VPN", false)) {
                return say$t(lang, "errors.vpn_so_tv_at", new Pair[0]);
            }
            if (!StringsKt.contains(joinToString$default, "the TV's allow question was not answered", false) && !StringsKt.contains(joinToString$default, "the TV is asking to allow USB debugging", false)) {
                if (StringsKt.contains(joinToString$default, "adb still connecting", false)) {
                    return say$t(lang, "errors.still_connecting_tv_over", new Pair[0]);
                }
                if (StringsKt.contains(joinToString$default, "UnknownHost", false)) {
                    return say$t(lang, "errors.tv_cannot_reach_internet", new Pair[0]);
                }
                Pattern compile2 = Pattern.compile("SocketTimeout|timed out|ConnectException|Connection reset", 66);
                Intrinsics.checkNotNullExpressionValue(compile2, "compile(...)");
                if (compile2.matcher(joinToString$default).find()) {
                    return say$t(lang, "errors.network_slow_dropped_try", new Pair[0]);
                }
                if (!StringsKt.contains(joinToString$default, "stopped answering", false) && !StringsKt.contains(joinToString$default, "stopped taking data", false)) {
                    if (StringsKt.contains(joinToString$default, "copy to the TV incomplete", false)) {
                        return say$t(lang, "errors.file_did_not_reach", new Pair[0]);
                    }
                    if (StringsKt.contains(joinToString$default, "no sign-in link", false)) {
                        return say$t(lang, "errors.could_not_read_sign", new Pair[0]);
                    }
                    if (StringsKt.contains(joinToString$default, "no app that can open", false)) {
                        return say$t(lang, "errors.tv_has_no_app", new Pair[0]);
                    }
                    if (StringsKt.contains(joinToString$default, "home:pin_old", false)) {
                        return say$t(lang, "errors.pin_old", new Pair[0]);
                    }
                    if (StringsKt.contains(joinToString$default, "pin_bad_link", false)) {
                        return say$t(lang, "errors.pin_bad_link", new Pair[0]);
                    }
                    if (StringsKt.contains(joinToString$default, "pin_no_app", false)) {
                        return say$t(lang, "errors.pin_no_app", new Pair[0]);
                    }
                    if (StringsKt.contains(joinToString$default, "pin_failed", false)) {
                        return say$t(lang, "errors.pin_failed", new Pair[0]);
                    }
                    if (StringsKt.contains(joinToString$default, "home:missing", false)) {
                        return say$t(lang, "core.fr_home_missing", new Pair[0]);
                    }
                    Pattern compile3 = Pattern.compile("INSUFFICIENT_STORAGE|No space", 66);
                    Intrinsics.checkNotNullExpressionValue(compile3, "compile(...)");
                    if (compile3.matcher(joinToString$default).find()) {
                        return say$t(lang, "errors.tv_out_storage", new Pair[0]);
                    }
                    Pattern compile4 = Pattern.compile("apk needs sdk (\\d+), the tv has sdk (\\d+)");
                    Intrinsics.checkNotNullExpressionValue(compile4, "compile(...)");
                    if (compile4.matcher(joinToString$default).find()) {
                        MatcherMatchResult access$findNext = MathKt.access$findNext(Census$$ExternalSyntheticOutline0.m6m("apk needs sdk (\\d+), the tv has sdk (\\d+)", "compile(...)", joinToString$default, "matcher(...)"), 0, joinToString$default);
                        Intrinsics.checkNotNull(access$findNext);
                        MatcherMatchResult$groupValues$1 matcherMatchResult$groupValues$12 = (MatcherMatchResult$groupValues$1) access$findNext.getGroupValues();
                        String str = (String) matcherMatchResult$groupValues$12.get(1);
                        ?? r3 = ANDROID;
                        String str2 = (String) r3.get(StringsKt__StringNumberConversionsKt.toIntOrNull(str));
                        if (str2 == null) {
                            str2 = "SDK ".concat(str);
                        }
                        Pair pair = new Pair("need", str2);
                        String str3 = (String) matcherMatchResult$groupValues$12.get(2);
                        String str4 = (String) r3.get(StringsKt__StringNumberConversionsKt.toIntOrNull(str3));
                        if (str4 == null) {
                            str4 = "SDK ".concat(str3);
                        }
                        return say$t(lang, "errors.apk_needs_android_newer", pair, new Pair("have", str4));
                    }
                    Pattern compile5 = Pattern.compile("apk is built for (\\S+), the tv runs (\\S+)");
                    Intrinsics.checkNotNullExpressionValue(compile5, "compile(...)");
                    if (compile5.matcher(joinToString$default).find()) {
                        MatcherMatchResult access$findNext2 = MathKt.access$findNext(Census$$ExternalSyntheticOutline0.m6m("apk is built for (\\S+), the tv runs (\\S+)", "compile(...)", joinToString$default, "matcher(...)"), 0, joinToString$default);
                        Intrinsics.checkNotNull(access$findNext2);
                        MatcherMatchResult$groupValues$1 matcherMatchResult$groupValues$13 = (MatcherMatchResult$groupValues$1) access$findNext2.getGroupValues();
                        return say$t(lang, "errors.apk_built_chips_tv", new Pair("apk", matcherMatchResult$groupValues$13.get(1)), new Pair("tv", matcherMatchResult$groupValues$13.get(2)));
                    }
                    if (!StringsKt.contains(joinToString$default, "install blocked by this TV's firmware", false) && !StringsKt.contains(joinToString$default, "disabled from pm", false)) {
                        if (StringsKt.contains(joinToString$default, "removed by the TV right after install", false)) {
                            return say$t(lang, "errors.tv_said_installed_app", new Pair[0]);
                        }
                        if (StringsKt.contains(joinToString$default, "cannot copy: split", false)) {
                            return say$t(lang, "errors.copy_split", new Pair[0]);
                        }
                        if (StringsKt.contains(joinToString$default, "cannot copy: manifest", false)) {
                            return say$t(lang, "errors.copy_odd", new Pair[0]);
                        }
                        if (MathKt.access$findNext(Census$$ExternalSyntheticOutline0.m6m("copy closed: (\\S+)", "compile(...)", joinToString$default, "matcher(...)"), 0, joinToString$default) != null) {
                            MatcherMatchResult access$findNext3 = MathKt.access$findNext(Census$$ExternalSyntheticOutline0.m6m("copy closed: (\\S+)", "compile(...)", joinToString$default, "matcher(...)"), 0, joinToString$default);
                            Intrinsics.checkNotNull(access$findNext3);
                            return say$t(lang, "errors.copy_closed", new Pair("pkg", ((MatcherMatchResult$groupValues$1) access$findNext3.getGroupValues()).get(1)));
                        }
                        Pattern compile6 = Pattern.compile("INSTALL_FAILED_CONFLICTING_PROVIDER|INSTALL_FAILED_DUPLICATE_PERMISSION");
                        Intrinsics.checkNotNullExpressionValue(compile6, "compile(...)");
                        if (compile6.matcher(joinToString$default).find()) {
                            return say$t(lang, "errors.copy_conflict", new Pair[0]);
                        }
                        if (MathKt.access$findNext(Census$$ExternalSyntheticOutline0.m6m("builtin app: (\\S+)", "compile(...)", joinToString$default, "matcher(...)"), 0, joinToString$default) != null) {
                            MatcherMatchResult access$findNext4 = MathKt.access$findNext(Census$$ExternalSyntheticOutline0.m6m("builtin app: (\\S+)", "compile(...)", joinToString$default, "matcher(...)"), 0, joinToString$default);
                            Intrinsics.checkNotNull(access$findNext4);
                            return say$t(lang, "errors.builtin_app", new Pair("pkg", ((MatcherMatchResult$groupValues$1) access$findNext4.getGroupValues()).get(1)));
                        }
                        Pattern compile7 = Pattern.compile("INSTALL_FAILED_UPDATE_INCOMPATIBLE|signatures do not match", 66);
                        Intrinsics.checkNotNullExpressionValue(compile7, "compile(...)");
                        if (compile7.matcher(joinToString$default).find()) {
                            return say$t(lang, "errors.tv_has_app_from", new Pair[0]);
                        }
                        if (StringsKt.contains(joinToString$default, "INSTALL_FAILED_VERSION_DOWNGRADE", false)) {
                            return say$t(lang, "errors.tv_has_newer_version", new Pair[0]);
                        }
                        if (StringsKt.contains(joinToString$default, "bundle:missing", false)) {
                            return say$t(lang, "core.fr_bundle_missing", new Pair[0]);
                        }
                        if (StringsKt.contains(joinToString$default, "bundle:locked", false)) {
                            return say$t(lang, "core.fr_bundle_locked", new Pair[0]);
                        }
                        if (StringsKt.contains(joinToString$default, "INSTALL_FAILED_MISSING_SPLIT", false)) {
                            return say$t(lang, "core.fr_missing_split", new Pair[0]);
                        }
                        if (StringsKt.contains(joinToString$default, "not an APK file", false)) {
                            return say$t(lang, "errors.file_not_apk", new Pair[0]);
                        }
                        if (StringsKt.contains(joinToString$default, "roku: control by mobile apps is off", false)) {
                            return say$t(lang, "errors.roku_blocks_control_from", new Pair[0]);
                        }
                        if (StringsKt.contains(joinToString$default, "vidaa: the certificate from Hisense's app is needed", false)) {
                            return say$t(lang, "errors.hisense_tv_needs_certificate", new Pair[0]);
                        }
                        if (StringsKt.contains(joinToString$default, "protected: the TV needs this app", false)) {
                            return say$t(lang, "errors.tv_needs_app_cannot", new Pair[0]);
                        }
                        if (StringsKt.contains(joinToString$default, "factory app: not opened", false)) {
                            return say$t(lang, "errors.factory_app", new Pair[0]);
                        }
                        String message = e.getMessage();
                        if (message == null) {
                            return e.getClass().getSimpleName();
                        }
                        return message;
                    }
                    return say$t(lang, "errors.install_blocked", new Pair[0]);
                }
                return say$t(lang, "errors.tv_stopped_answering_midway", new Pair[0]);
            }
            return say$t(lang, "errors.tv_asks_allow_usb", new Pair[0]);
        }
        return say$t(lang, "errors.downloaded_update_does_not", new Pair[0]);
    }

    public static final String say$t(String str, String str2, Pair... pairArr) {
        ConcurrentHashMap concurrentHashMap = Words.books;
        return Words.get(str, str2, (Pair[]) Arrays.copyOf(pairArr, pairArr.length));
    }
}
