package dev.tvremote.core;

import android.os.Process;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Iterator;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Charsets;
import kotlin.text.Regex;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public abstract class SupportAndroid {
    public static final Regex SECRET = new Regex("(?i)^(?:.*[_-])?(token|tokens|pass|password|pin|code|secret|totp|hash|h|salt|key|cookie|chats|history|paired|recovery|backup|note)$");
    public static final Regex TOKEN = new Regex("[0-9a-fA-F]{32,}");

    public static Object clean(Object obj) {
        if (obj instanceof JSONObject) {
            JSONObject jSONObject = new JSONObject();
            JSONObject jSONObject2 = (JSONObject) obj;
            Iterator<String> keys = jSONObject2.keys();
            Intrinsics.checkNotNullExpressionValue(keys, "keys(...)");
            while (keys.hasNext()) {
                String next = keys.next();
                Intrinsics.checkNotNull(next);
                Object obj2 = "…";
                if (!SECRET.matches(next)) {
                    Object clean = clean(jSONObject2.opt(next));
                    if (clean instanceof String) {
                        clean = TOKEN.replace((CharSequence) clean, "…");
                    }
                    obj2 = clean;
                }
                jSONObject.put(next, obj2);
            }
            return jSONObject;
        }
        if (obj instanceof JSONArray) {
            JSONArray jSONArray = new JSONArray();
            JSONArray jSONArray2 = (JSONArray) obj;
            int length = jSONArray2.length();
            for (int i = 0; i < length; i++) {
                jSONArray.put(clean(jSONArray2.opt(i)));
            }
            return jSONArray;
        }
        return obj;
    }

    public static String logcat() {
        try {
            Process start = new ProcessBuilder("logcat", "-d", "-t", "3000", "-v", "time", "--pid=" + Process.myPid()).redirectErrorStream(true).start();
            InputStream inputStream = start.getInputStream();
            Intrinsics.checkNotNullExpressionValue(inputStream, "getInputStream(...)");
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, Charsets.UTF_8), 8192);
            try {
                String readText = MathKt.readText(bufferedReader);
                bufferedReader.close();
                start.waitFor();
                return "[logcat]\n" + Scrub.blank(readText);
            } finally {
            }
        } catch (Exception e) {
            return "[logcat] " + e + "\n";
        }
    }
}
