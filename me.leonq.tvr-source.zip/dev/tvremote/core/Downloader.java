package dev.tvremote.core;

import dev.tvremote.core.ontv.Launchers;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda3;
import dev.tvremote.update.SignedList;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.sequences.SequencesKt;
import kotlin.text.Charsets;
import org.json.JSONObject;

/* loaded from: classes.dex */
public abstract class Downloader {
    public static volatile long asked;
    public static final List bases = ArraysKt.asList(new String[]{"https://tvremote.pages.dev/data/", "https://raw.githubusercontent.com/HoangTran0410/tv-remote/main/docs/data/"});
    public static volatile File dir;

    public static LinkedHashMap accept(String str, byte[] bArr) {
        List list = Launchers.KEYS;
        List list2 = SignedList.KEYS;
        if (SignedList.verify(bArr, str, CollectionsKt.plus(Launchers.KEYS, (Iterable) Launchers.testKeys))) {
            return parse(new String(bArr, Charsets.UTF_8));
        }
        return null;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0032, code lost:
    
        if (r4 < 86400000) goto L15;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static LinkedHashMap codes() {
        File file = dir;
        if (file != null) {
            long currentTimeMillis = System.currentTimeMillis();
            File file2 = new File(file, "downloader.json");
            if (currentTimeMillis - asked >= 60000) {
                if (file2.isFile()) {
                    long lastModified = currentTimeMillis - file2.lastModified();
                    if (0 <= lastModified) {
                    }
                }
                asked = currentTimeMillis;
                Thread thread = new Thread(new Guard$$ExternalSyntheticLambda3(1));
                thread.setDaemon(true);
                thread.start();
            }
        }
        File file3 = dir;
        LinkedHashMap linkedHashMap = null;
        if (file3 != null) {
            File file4 = new File(file3, "downloader.json");
            File file5 = new File(file3, "downloader.json.sig");
            try {
                if (file4.isFile() && file5.isFile()) {
                    linkedHashMap = accept(MathKt.readText$default(file5), MathKt.readBytes(file4));
                }
            } catch (IOException unused) {
            }
        }
        if (linkedHashMap == null) {
            LinkedHashMap parse = parse("{\"v\":1,\"setup\":\"2397346\",\"remote\":\"2973135\",\"home\":\"4356026\",\"channels\":\"8135635\",\"games\":\"2294968\",\"tvapps\":\"1082201\"}");
            Intrinsics.checkNotNull(parse);
            return parse;
        }
        return linkedHashMap;
    }

    public static JSONObject json() {
        JSONObject jSONObject = new JSONObject();
        for (Map.Entry entry : codes().entrySet()) {
            jSONObject.put((String) entry.getKey(), (String) entry.getValue());
        }
        return jSONObject;
    }

    public static LinkedHashMap parse(String str) {
        try {
            JSONObject jSONObject = new JSONObject(str);
            if (jSONObject.optInt("v") == 1) {
                LinkedHashMap linkedHashMap = new LinkedHashMap();
                Iterator<String> keys = jSONObject.keys();
                Intrinsics.checkNotNullExpressionValue(keys, "keys(...)");
                for (String str2 : SequencesKt.toList(SequencesKt.asSequence(keys))) {
                    if (!Intrinsics.areEqual(str2, "v") && !jSONObject.isNull(str2)) {
                        String optString = jSONObject.optString(str2);
                        Intrinsics.checkNotNull(optString);
                        Pattern compile = Pattern.compile("\\d{4,9}");
                        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                        if (compile.matcher(optString).matches()) {
                            linkedHashMap.put(str2, optString);
                        } else {
                            return null;
                        }
                    }
                }
                return linkedHashMap;
            }
            return null;
        } catch (Exception unused) {
            return null;
        }
    }
}
