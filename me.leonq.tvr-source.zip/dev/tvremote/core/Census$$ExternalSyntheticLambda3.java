package dev.tvremote.core;

import dev.tvremote.core.Census;
import java.util.HashMap;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;

/* loaded from: classes.dex */
public final /* synthetic */ class Census$$ExternalSyntheticLambda3 implements Function0 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ String f$0;

    public /* synthetic */ Census$$ExternalSyntheticLambda3(String str, int i) {
        this.$r8$classId = i;
        this.f$0 = str;
    }

    private final Object invoke$dev$tvremote$core$Census$$ExternalSyntheticLambda3() {
        Census.State state;
        String str = this.f$0;
        if (Census.live()) {
            HashMap hashMap = Census.tvs;
            synchronized (hashMap) {
                state = (Census.State) hashMap.get(str);
            }
            if (state != null) {
                state.optimize = Boolean.TRUE;
                Census.send(str);
            }
        }
        return Unit.INSTANCE;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        Census.State state;
        switch (this.$r8$classId) {
            case 0:
                return invoke$dev$tvremote$core$Census$$ExternalSyntheticLambda3();
            default:
                String str = this.f$0;
                if (Census.live()) {
                    HashMap hashMap = Census.tvs;
                    synchronized (hashMap) {
                        state = (Census.State) hashMap.get(str);
                    }
                    if (state != null) {
                        state.video = Boolean.TRUE;
                        Census.send(str);
                    }
                }
                return Unit.INSTANCE;
        }
    }
}
