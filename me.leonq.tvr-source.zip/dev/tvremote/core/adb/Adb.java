package dev.tvremote.core.adb;

import dev.tvremote.core.B64;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet$$ExternalSyntheticLambda0;
import dev.tvremote.core.Lan;
import dev.tvremote.core.Lan$$ExternalSyntheticLambda0;
import dev.tvremote.core.WireLog;
import dev.tvremote.core.Words$$ExternalSyntheticLambda1;
import dev.tvremote.core.adb.AdbTls;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.math.BigInteger;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import javax.crypto.Cipher;
import javax.net.ssl.SSLSocket;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class Adb implements Closeable {
    public static final byte[] BANNER;
    public static final boolean BURST;
    public static final byte[] EMPTY;
    public static final byte[] EOF;
    public static final byte[] SHA1_PREFIX;
    public static final Object poke = null;
    public volatile String at;
    public volatile boolean dead;
    public volatile boolean delayed;
    public final File dir;
    public volatile long heard;
    public DataInputStream input;
    public final KeyPair key;
    public int maxData;
    public int nextId;
    public OutputStream output;
    public Socket sock;
    public final ConcurrentHashMap streams;
    public final AtomicInteger users;
    public static final ConcurrentHashMap ASKING = new ConcurrentHashMap();
    public static final ConcurrentHashMap PLAIN_ASKED = new ConcurrentHashMap();
    public static final ConcurrentHashMap ASKED = new ConcurrentHashMap();
    public static final ConcurrentHashMap LIVE = new ConcurrentHashMap();
    public static final HashSet ONE = new HashSet();
    public static final Object KEY_LOCK = new Object();

    /* loaded from: classes.dex */
    public final class Msg {
        public final int arg0;
        public final int arg1;
        public final int cmd;
        public final byte[] data;

        public Msg(int i, int i2, int i3, byte[] bArr) {
            this.cmd = i;
            this.arg0 = i2;
            this.arg1 = i3;
            this.data = bArr;
        }
    }

    /* renamed from: $r8$lambda$8yQ-NsDKOE_HPXJvvGWBjdTbzG0 */
    public static void m11$r8$lambda$8yQNsDKOE_HPXJvvGWBjdTbzG0(Adb adb) {
        int i;
        int i2;
        int i3;
        adb.getClass();
        while (true) {
            try {
                Msg read = adb.read();
                adb.heard = System.nanoTime();
                Stream stream = (Stream) adb.streams.get(Integer.valueOf(read.arg1));
                int i4 = 0;
                if (stream == null) {
                    if (read.cmd == 1497451343 && (i = read.arg0) != 0) {
                        try {
                            adb.send(1163086915, read.arg1, i, new byte[0]);
                        } catch (IOException unused) {
                        }
                    }
                } else {
                    int i5 = read.cmd;
                    if (i5 != 1163086915) {
                        if (i5 != 1163154007) {
                            if (i5 == 1497451343) {
                                if (stream.remote == 0) {
                                    stream.remote = read.arg0;
                                    if (stream.delayed) {
                                        Semaphore semaphore = stream.credit;
                                        byte[] bArr = read.data;
                                        if (bArr.length == 4 && (i2 = ByteBuffer.wrap(bArr).order(ByteOrder.LITTLE_ENDIAN).getInt()) >= 0) {
                                            i4 = i2;
                                        }
                                        semaphore.release(i4);
                                    }
                                    stream.opened.release();
                                } else if (stream.delayed) {
                                    Semaphore semaphore2 = stream.credit;
                                    byte[] bArr2 = read.data;
                                    if (bArr2.length == 4 && (i3 = ByteBuffer.wrap(bArr2).order(ByteOrder.LITTLE_ENDIAN).getInt()) >= 0) {
                                        i4 = i3;
                                    }
                                    semaphore2.release(i4);
                                } else {
                                    stream.acked.release();
                                }
                            }
                        } else {
                            stream.incoming.add(read.data);
                        }
                    } else {
                        stream.end$shared_release();
                    }
                }
            } catch (IOException e) {
                if (!adb.dead) {
                    WireLog.all.add("·", "adb connection lost: " + e);
                }
                adb.dead = true;
                LIVE.remove(adb.at, adb);
                Iterator it = new ArrayList(adb.streams.values()).iterator();
                Intrinsics.checkNotNullExpressionValue(it, "iterator(...)");
                while (it.hasNext()) {
                    ((Stream) it.next()).end$shared_release();
                }
                return;
            }
        }
    }

    static {
        String str;
        boolean areEqual = Intrinsics.areEqual(System.getenv("TVR_ADB_BURST"), "0");
        BURST = !areEqual;
        if (!areEqual) {
            str = "host::features=delayed_ack";
        } else {
            str = "host::\u0000";
        }
        byte[] bytes = str.getBytes(Charsets.UTF_8);
        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        BANNER = bytes;
        EMPTY = new byte[0];
        EOF = new byte[0];
        SHA1_PREFIX = new byte[]{48, 33, 48, 9, 6, 5, 43, 14, 3, 2, 26, 5, 0, 4, 20};
    }

    public Adb(File dir) {
        KeyPair generateKeyPair;
        Intrinsics.checkNotNullParameter(dir, "dir");
        this.dir = dir;
        this.streams = new ConcurrentHashMap();
        this.nextId = 1;
        this.maxData = 4096;
        this.heard = System.nanoTime();
        this.users = new AtomicInteger(1);
        this.at = "";
        synchronized (KEY_LOCK) {
            FileChannel channel = new RandomAccessFile(new File(dir, "adbkey.lock"), "rw").getChannel();
            try {
                FileLock lock = channel.lock();
                try {
                    File file = new File(dir, "adbkey.pk8");
                    File file2 = new File(dir, "adbkey.x509");
                    KeyFactory keyFactory = KeyFactory.getInstance("RSA");
                    if (file.exists() && file2.exists()) {
                        generateKeyPair = new KeyPair(keyFactory.generatePublic(new X509EncodedKeySpec(MathKt.readBytes(file2))), keyFactory.generatePrivate(new PKCS8EncodedKeySpec(MathKt.readBytes(file))));
                    } else {
                        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
                        keyPairGenerator.initialize(2048);
                        generateKeyPair = keyPairGenerator.generateKeyPair();
                        byte[] encoded = generateKeyPair.getPrivate().getEncoded();
                        Intrinsics.checkNotNullExpressionValue(encoded, "getEncoded(...)");
                        MathKt.writeBytes(file, encoded);
                        byte[] encoded2 = generateKeyPair.getPublic().getEncoded();
                        Intrinsics.checkNotNullExpressionValue(encoded2, "getEncoded(...)");
                        MathKt.writeBytes(file2, encoded2);
                    }
                    if (lock != null) {
                        lock.close();
                    }
                    channel.close();
                } finally {
                }
            } finally {
            }
        }
        this.key = generateKeyPair;
    }

    /* JADX WARN: Code restructure failed: missing block: B:25:0x005a, code lost:
    
        if (r0 != null) goto L111;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x005e, code lost:
    
        if (r0.dead != false) goto L170;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0060, code lost:
    
        r3 = r0.users.get();
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0066, code lost:
    
        if (r3 > 0) goto L116;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0071, code lost:
    
        if (r0.users.compareAndSet(r3, r3 + 1) == false) goto L171;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x0075, code lost:
    
        if (r0 == null) goto L158;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x0077, code lost:
    
        r9.close();
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x007a, code lost:
    
        return r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0074, code lost:
    
        r0 = null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x0096, code lost:
    
        if (r0 == null) goto L139;
     */
    /* JADX WARN: Code restructure failed: missing block: B:51:0x009a, code lost:
    
        if (r0.dead != false) goto L173;
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x009c, code lost:
    
        r3 = r0.users.get();
     */
    /* JADX WARN: Code restructure failed: missing block: B:53:0x00a2, code lost:
    
        if (r3 > 0) goto L136;
     */
    /* JADX WARN: Code restructure failed: missing block: B:55:0x00ad, code lost:
    
        if (r0.users.compareAndSet(r3, r3 + 1) == false) goto L175;
     */
    /* JADX WARN: Code restructure failed: missing block: B:57:0x00af, code lost:
    
        r2 = r0;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static Adb connectOrShare$default(Adb adb, String host, AdbLink$$ExternalSyntheticLambda2 adbLink$$ExternalSyntheticLambda2) {
        boolean contains;
        Intrinsics.checkNotNullParameter(host, "host");
        File file = new File(adb.dir, "adb-one-client.txt");
        HashSet hashSet = ONE;
        synchronized (hashSet) {
            try {
                if (hashSet.isEmpty() && file.exists()) {
                    ArrayList readLines$default = MathKt.readLines$default(file);
                    ArrayList arrayList = new ArrayList();
                    Iterator it = readLines$default.iterator();
                    while (it.hasNext()) {
                        Object next = it.next();
                        if (!StringsKt.isBlank((String) next)) {
                            arrayList.add(next);
                        }
                    }
                    hashSet.addAll(arrayList);
                }
                contains = ONE.contains(host);
            } catch (Throwable th) {
                throw th;
            }
        }
        Adb adb2 = null;
        if (contains) {
            Adb adb3 = (Adb) LIVE.get(host);
        }
        try {
            adb.connectTo(host, adbLink$$ExternalSyntheticLambda2);
            return adb;
        } catch (Exception e) {
            if (!Intrinsics.areEqual(e.getMessage(), "the TV's allow question was not answered")) {
                Adb adb4 = (Adb) LIVE.get(host);
            }
            if (adb2 != null) {
                adb.close();
                WireLog.all.add("·", "adb " + host + " takes one client at a time (" + e + "): sharing the open connection");
                HashSet hashSet2 = ONE;
                synchronized (hashSet2) {
                    if (hashSet2.add(host)) {
                        try {
                            MathKt.writeText$default(file, CollectionsKt.joinToString$default(hashSet2, "\n", null, null, null, 62) + "\n");
                        } catch (IOException unused) {
                        }
                    }
                    return adb2;
                }
            }
            throw e;
        }
    }

    public final boolean alive(long j) {
        try {
            Stream open = open(j, "shell:echo");
            try {
                open.readAll(j);
                open.close();
                return !this.dead;
            } finally {
            }
        } catch (IOException unused) {
            return false;
        }
    }

    public final boolean askOnce(String str, AdbLink$$ExternalSyntheticLambda2 adbLink$$ExternalSyntheticLambda2) {
        String m = Census$$ExternalSyntheticOutline0.m(str, ":5555");
        long currentTimeMillis = System.currentTimeMillis() + 180000;
        while (ASKING.putIfAbsent(m, this) != null) {
            adbLink$$ExternalSyntheticLambda2.waitingForUser();
            try {
                Socket socket = this.sock;
                if (socket != null) {
                    socket.close();
                }
            } catch (IOException unused) {
            }
            while (ASKING.get(m) != null && !this.dead && System.currentTimeMillis() < currentTimeMillis) {
                Thread.sleep(400L);
            }
            if (!this.dead) {
                if (System.currentTimeMillis() < currentTimeMillis) {
                    dial(str, 5555);
                    if (authenticate() == null) {
                        return true;
                    }
                } else {
                    throw new IOException("the TV's allow question was not answered");
                }
            } else {
                throw new IOException("closed");
            }
        }
        return false;
    }

    public final byte[] authenticate() {
        send(1314410051, 16777216, 262144, BANNER);
        boolean z = false;
        while (true) {
            Msg read = read();
            int i = read.cmd;
            if (i == 1314410051) {
                connected(read);
                return null;
            }
            if (i == 1213486401 && read.arg0 == 1) {
                byte[] bArr = read.data;
                if (z) {
                    return bArr;
                }
                if (bArr.length <= 200) {
                    Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
                    cipher.init(1, this.key.getPrivate());
                    cipher.update(SHA1_PREFIX);
                    byte[] doFinal = cipher.doFinal(bArr);
                    Intrinsics.checkNotNullExpressionValue(doFinal, "doFinal(...)");
                    send(1213486401, 2, 0, doFinal);
                    z = true;
                } else {
                    throw new IOException("bad adb token");
                }
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:27:0x0085 A[Catch: IOException -> 0x0080, TRY_LEAVE, TryCatch #4 {IOException -> 0x0080, blocks: (B:25:0x0073, B:77:0x007c, B:27:0x0085, B:71:0x00f0), top: B:24:0x0073 }] */
    /* JADX WARN: Removed duplicated region for block: B:76:0x007c A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void awaitApproval(String str) {
        Socket socket;
        boolean z;
        Socket socket2 = this.sock;
        Intrinsics.checkNotNull(socket2);
        DataInputStream dataInputStream = this.input;
        if (dataInputStream != null) {
            long currentTimeMillis = System.currentTimeMillis() + 180000;
            long j = 1000000;
            long nanoTime = System.nanoTime() / j;
            long j2 = 0;
            boolean z2 = true;
            int i = 1;
            while (System.currentTimeMillis() < currentTimeMillis) {
                if (!this.dead) {
                    if (z2) {
                        this.sock = socket2;
                        this.input = dataInputStream;
                        this.output = socket2.getOutputStream();
                        try {
                            socket2.setSoTimeout(3000);
                            while (true) {
                                Msg read = read();
                                socket = socket2;
                                if (read.cmd == 1314410051) {
                                    try {
                                        connected(read);
                                        return;
                                    } catch (SocketTimeoutException unused) {
                                    } catch (IOException unused2) {
                                        j2 = (System.nanoTime() / j) + 6000;
                                        z2 = false;
                                        dial(str, 5555);
                                        if (authenticate() != null) {
                                        }
                                    }
                                } else {
                                    socket2 = socket;
                                }
                            }
                        } catch (SocketTimeoutException unused3) {
                            socket = socket2;
                        } catch (IOException unused4) {
                            socket = socket2;
                        }
                    } else {
                        socket = socket2;
                        Thread.sleep(2000L);
                    }
                    try {
                        dial(str, 5555);
                    } catch (IOException unused5) {
                        socket2 = socket;
                    }
                    if (authenticate() != null) {
                        socket.close();
                        return;
                    }
                    long nanoTime2 = System.nanoTime() / j;
                    if (z2 && nanoTime2 - nanoTime > 20000) {
                        z = true;
                    } else {
                        z = false;
                    }
                    if ((!z2 && i < 4 && nanoTime2 > j2) || (z && i < 12)) {
                        try {
                            byte[] bytes = (publicKey$shared_release() + "\u0000").getBytes(Charsets.UTF_8);
                            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                            send(1213486401, 3, 0, bytes);
                            socket.close();
                            socket2 = this.sock;
                            Intrinsics.checkNotNull(socket2);
                            try {
                                DataInputStream dataInputStream2 = this.input;
                                if (dataInputStream2 != null) {
                                    i++;
                                    dataInputStream = dataInputStream2;
                                    nanoTime = nanoTime2;
                                    z2 = true;
                                } else {
                                    Intrinsics.throwUninitializedPropertyAccessException("input");
                                    throw null;
                                    break;
                                }
                            } catch (IOException unused6) {
                                nanoTime = nanoTime2;
                                Socket socket3 = this.sock;
                                if (socket3 != null && socket3 != socket2) {
                                    try {
                                        socket3.close();
                                    } catch (IOException unused7) {
                                    }
                                }
                            }
                        } catch (IOException unused8) {
                            socket2 = socket;
                        }
                    } else {
                        Socket socket4 = this.sock;
                        Intrinsics.checkNotNull(socket4);
                        socket4.close();
                        socket2 = socket;
                    }
                } else {
                    socket2.close();
                    throw new IOException("closed");
                }
            }
            socket2.close();
            throw new IOException("the TV's allow question was not answered");
        }
        Intrinsics.throwUninitializedPropertyAccessException("input");
        throw null;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        if (this.users.decrementAndGet() <= 0) {
            kill();
        }
    }

    public final void connect(String host, AdbLink$$ExternalSyntheticLambda2 adbLink$$ExternalSyntheticLambda2) {
        Intrinsics.checkNotNullParameter(host, "host");
        dial(host, 5555);
        if (authenticate() != null) {
            try {
                if (!askOnce(host, adbLink$$ExternalSyntheticLambda2)) {
                    ASKED.put(host, Long.valueOf(System.currentTimeMillis()));
                    byte[] bytes = (publicKey$shared_release() + "\u0000").getBytes(Charsets.UTF_8);
                    Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                    send(1213486401, 3, 0, bytes);
                    adbLink$$ExternalSyntheticLambda2.waitingForUser();
                    awaitApproval(host);
                }
            } finally {
                ASKING.remove(host.concat(":5555"), this);
            }
        }
        Socket socket = this.sock;
        Intrinsics.checkNotNull(socket);
        socket.setSoTimeout(0);
        Socket socket2 = this.sock;
        Intrinsics.checkNotNull(socket2);
        socket2.setKeepAlive(true);
        Thread thread = new Thread(new Adb$$ExternalSyntheticLambda4(this, 1), "adb-reader");
        thread.setDaemon(true);
        thread.start();
        this.at = host;
        LIVE.put(host, this);
        Long l = (Long) ASKED.remove(host);
        if (l != null && System.currentTimeMillis() - l.longValue() < 600000) {
            Thread thread2 = new Thread(new Adb$$ExternalSyntheticLambda4(this, 2), "adb-after-question");
            thread2.setDaemon(true);
            thread2.start();
        }
    }

    public final void connectTls(String host, int i) {
        Msg read;
        int i2 = 1;
        Intrinsics.checkNotNullParameter(host, "host");
        dial(host, i);
        send(1314410051, 16777217, 262144, BANNER);
        Msg read2 = read();
        if (read2.cmd == 1397511251) {
            send(1397511251, read2.arg0, 0, EMPTY);
            AdbTls adbTls = AdbTls.INSTANCE;
            Socket socket = this.sock;
            Intrinsics.checkNotNull(socket);
            Socket createSocket = AdbTls.context(this).getSocketFactory().createSocket(socket, host, i, true);
            Intrinsics.checkNotNull(createSocket, "null cannot be cast to non-null type javax.net.ssl.SSLSocket");
            SSLSocket sSLSocket = (SSLSocket) createSocket;
            sSLSocket.setEnabledProtocols(new String[]{"TLSv1.3"});
            sSLSocket.setSoTimeout(15000);
            sSLSocket.startHandshake();
            this.sock = sSLSocket;
            this.input = new DataInputStream(sSLSocket.getInputStream());
            this.output = sSLSocket.getOutputStream();
            try {
                read = read();
            } catch (SocketTimeoutException unused) {
                send(1314410051, 16777217, 262144, BANNER);
                read = read();
            }
            read2 = read;
        }
        int i3 = read2.cmd;
        if (i3 != 1213486401) {
            if (i3 == 1314410051) {
                connected(read2);
                Socket socket2 = this.sock;
                Intrinsics.checkNotNull(socket2);
                socket2.setSoTimeout(0);
                Socket socket3 = this.sock;
                Intrinsics.checkNotNull(socket3);
                socket3.setKeepAlive(true);
                Thread thread = new Thread(new Adb$$ExternalSyntheticLambda4(this, i2), "adb-reader");
                thread.setDaemon(true);
                thread.start();
                this.at = host;
                LIVE.put(host, this);
                return;
            }
            throw new IOException("adb tls: unexpected answer");
        }
        throw new IOException("adb tls: this device is not paired");
    }

    /* JADX WARN: Removed duplicated region for block: B:122:0x01e3  */
    /* JADX WARN: Removed duplicated region for block: B:123:0x01e4  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void connectTo(String host, AdbLink$$ExternalSyntheticLambda2 adbLink$$ExternalSyntheticLambda2) {
        int i;
        int discoverConnect$default;
        long j;
        String obj;
        int i2 = 0;
        Intrinsics.checkNotNullParameter(host, "host");
        AdbTls adbTls = AdbTls.INSTANCE;
        File dir = this.dir;
        synchronized (adbTls) {
            Intrinsics.checkNotNullParameter(dir, "dir");
            try {
                i = new JSONObject(MathKt.readText$default(new File(dir, "adbtls.json"))).optInt(host, 0);
            } catch (Exception unused) {
                i = 0;
            }
        }
        if (i > 0) {
            long currentTimeMillis = System.currentTimeMillis();
            AdbTls adbTls2 = AdbTls.INSTANCE;
            if (!AdbTls.same(host, "127.0.0.1")) {
                ConcurrentHashMap concurrentHashMap = PLAIN_ASKED;
                Long l = (Long) concurrentHashMap.get(host);
                if (l != null) {
                    j = l.longValue();
                } else {
                    j = 0;
                }
                if (currentTimeMillis - j >= 600000 && !AdbTls.plainOpen(host)) {
                    try {
                        Adb adb = new Adb(this.dir);
                        try {
                            adb.connectTls(host, i);
                            if (!StringsKt.contains(adb.shell(10000L, "pm path dev.tvremote.setup 2>/dev/null"), "package:", false)) {
                                adb.close();
                            } else {
                                concurrentHashMap.put(host, Long.valueOf(currentTimeMillis));
                                try {
                                    Stream open = adb.open(10000L, "tcpip:5555");
                                    try {
                                        obj = open.readAll(3000L);
                                        open.close();
                                    } catch (Throwable th) {
                                        try {
                                            throw th;
                                        } catch (Throwable th2) {
                                            MathKt.closeFinally(open, th);
                                            throw th2;
                                        }
                                    }
                                } catch (IOException e) {
                                    obj = e.toString();
                                }
                                WireLog.all.add("·", "adb " + host + " tcpip:5555 for TV Setup: " + StringsKt.take(StringsKt.trim(obj).toString(), 120));
                                adb.close();
                                Thread.sleep(3000L);
                                Thread thread = new Thread(new Adb$$ExternalSyntheticLambda4(this, i2), "adb-after-tcpip");
                                thread.setDaemon(true);
                                thread.start();
                            }
                        } catch (Throwable th3) {
                            try {
                                throw th3;
                            } catch (Throwable th4) {
                                MathKt.closeFinally(adb, th3);
                                throw th4;
                            }
                        }
                    } catch (Exception unused2) {
                    }
                }
            }
        }
        IOException iOException = null;
        if (i > 0) {
            Exception exc = null;
            while (i2 < 2) {
                if (i2 == 0) {
                    discoverConnect$default = i;
                } else {
                    discoverConnect$default = AdbTls.discoverConnect$default(host);
                }
                if (discoverConnect$default > 0 && (i2 != 1 || discoverConnect$default != i)) {
                    try {
                        connectTls(host, discoverConnect$default);
                        if (discoverConnect$default != i) {
                            AdbTls.INSTANCE.save(this.dir, host, discoverConnect$default);
                            return;
                        }
                        return;
                    } catch (Exception e2) {
                        if (exc == null) {
                            exc = e2;
                        }
                        WireLog.all.add("·", "adb " + host + " tls port " + discoverConnect$default + ": " + e2);
                        try {
                            Socket socket = this.sock;
                            if (socket != null) {
                                socket.close();
                            }
                        } catch (IOException unused3) {
                        }
                    }
                }
                i2++;
            }
            AdbTls adbTls3 = AdbTls.INSTANCE;
            if (!AdbTls.plainOpen(host)) {
                if (exc != null) {
                    throw exc;
                }
                throw new IOException("adb tls: no port");
            }
        }
        try {
            connect(host, adbLink$$ExternalSyntheticLambda2);
        } catch (IOException e3) {
            AdbTls adbTls4 = AdbTls.INSTANCE;
            if (AdbTls.available() && !AdbTls.plainOpen(host)) {
                AdbTls.Wireless wireless$default = AdbTls.wireless$default(14, host, null);
                if (wireless$default.getAny()) {
                    WireLog wireLog = WireLog.all;
                    StringBuilder sb = new StringBuilder("adb ");
                    sb.append(host);
                    sb.append(": wireless debugging only (connect ");
                    int i3 = wireless$default.connect;
                    sb.append(i3);
                    sb.append(", pairing ");
                    sb.append(wireless$default.pairing);
                    sb.append(")");
                    wireLog.add("·", sb.toString());
                    if (i3 > 0) {
                        try {
                            connectTls(host, i3);
                            adbTls4.save(this.dir, host, i3);
                        } catch (Exception e4) {
                            WireLog.all.add("·", "adb " + host + " tls port " + i3 + ": " + e4);
                            try {
                                Socket socket2 = this.sock;
                                if (socket2 != null) {
                                    socket2.close();
                                }
                            } catch (IOException unused4) {
                            }
                            iOException = new IOException("adb tls: this device is not paired");
                            if (iOException == null) {
                            }
                        }
                    }
                    iOException = new IOException("adb tls: this device is not paired");
                }
            }
            if (iOException == null) {
                throw iOException;
            }
            throw e3;
        }
    }

    public final void connected(Msg msg) {
        boolean z = true;
        this.maxData = MathKt.coerceIn(msg.arg1, 4096, 262144);
        String substringAfter = StringsKt.substringAfter(new String(msg.data, Charsets.UTF_8), "features=", "");
        String trimEnd = StringsKt.trimEnd(StringsKt.substringBefore(substringAfter, ';', substringAfter), 0);
        if (!BURST || !StringsKt.split$default(trimEnd, new char[]{','}).contains("delayed_ack")) {
            z = false;
        }
        this.delayed = z;
    }

    public final void dial(String str, int i) {
        Function0 function0 = Lan.wifi;
        Socket connect = Lan.connect(str, i, 6000, new Fleet$$ExternalSyntheticLambda0(this, 1));
        connect.setTcpNoDelay(true);
        connect.setSoTimeout(15000);
        this.input = new DataInputStream(connect.getInputStream());
        this.output = connect.getOutputStream();
    }

    public final Stream exec(String cmd) {
        Intrinsics.checkNotNullParameter(cmd, "cmd");
        return open(10000L, "exec:".concat(cmd));
    }

    public final String fingerprint() {
        int[] iArr = B64.INDEX;
        String publicKey$shared_release = publicKey$shared_release();
        byte[] digest = MessageDigest.getInstance("MD5").digest(B64.decode(StringsKt.substringBefore(publicKey$shared_release, ' ', publicKey$shared_release)));
        Intrinsics.checkNotNullExpressionValue(digest, "digest(...)");
        return ArraysKt.joinToString$default(digest, ":", new Lan$$ExternalSyntheticLambda0(20));
    }

    public final void kill() {
        this.dead = true;
        LIVE.remove(this.at, this);
        Socket socket = this.sock;
        if (socket != null) {
            if (!Intrinsics.areEqual(Thread.currentThread().getName(), "main")) {
                try {
                    socket.close();
                } catch (IOException unused) {
                }
            } else {
                Thread thread = new Thread(new Adb$$ExternalSyntheticLambda0(0, socket), "adb-close");
                thread.setDaemon(true);
                thread.start();
            }
        }
    }

    public final Stream open(long j, String service) {
        Stream stream;
        int i;
        int i2;
        Intrinsics.checkNotNullParameter(service, "service");
        if (!this.dead) {
            synchronized (this) {
                i = this.nextId;
                this.nextId = i + 1;
                stream = new Stream(i);
            }
            this.streams.put(Integer.valueOf(i), stream);
            try {
                if (stream.delayed) {
                    i2 = 1048576;
                } else {
                    i2 = 0;
                }
                byte[] bytes = service.concat("\u0000").getBytes(Charsets.UTF_8);
                Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                send(1313165391, i, i2, bytes);
                try {
                    long nanoTime = System.nanoTime();
                    while (!stream.opened.tryAcquire(1000L, TimeUnit.MILLISECONDS)) {
                        long nanoTime2 = System.nanoTime();
                        long j2 = 1000000;
                        if ((nanoTime2 - this.heard) / j2 >= j && (nanoTime2 - nanoTime) / j2 >= j) {
                            stream.end$shared_release();
                            kill();
                            throw new IOException("no answer from the TV");
                        }
                        if ((nanoTime2 - nanoTime) / j2 >= Math.max(j, 60000L)) {
                            stream.end$shared_release();
                            throw new IOException("the TV is busy");
                        }
                    }
                    if (stream.remote != 0) {
                        return stream;
                    }
                    throw new IOException("refused: ".concat(service));
                } catch (InterruptedException unused) {
                    throw new IOException("interrupted");
                }
            } catch (IOException e) {
                this.streams.remove(Integer.valueOf(stream.local));
                throw e;
            }
        }
        throw new IOException("adb connection lost");
    }

    public final String publicKey$shared_release() {
        PublicKey publicKey = this.key.getPublic();
        Intrinsics.checkNotNull(publicKey, "null cannot be cast to non-null type java.security.interfaces.RSAPublicKey");
        RSAPublicKey rSAPublicKey = (RSAPublicKey) publicKey;
        BigInteger modulus = rSAPublicKey.getModulus();
        BigInteger bigInteger = BigInteger.ONE;
        BigInteger shiftLeft = bigInteger.shiftLeft(32);
        BigInteger shiftLeft2 = bigInteger.shiftLeft(2048);
        ByteBuffer order = ByteBuffer.allocate(524).order(ByteOrder.LITTLE_ENDIAN);
        order.putInt(64).putInt(modulus.mod(shiftLeft).modInverse(shiftLeft).negate().mod(shiftLeft).intValue());
        for (int i = 0; i < 64; i++) {
            order.putInt(modulus.shiftRight(i * 32).intValue());
        }
        BigInteger mod = shiftLeft2.multiply(shiftLeft2).mod(modulus);
        Intrinsics.checkNotNullExpressionValue(mod, "mod(...)");
        for (int i2 = 0; i2 < 64; i2++) {
            order.putInt(mod.shiftRight(i2 * 32).intValue());
        }
        order.putInt(rSAPublicKey.getPublicExponent().intValue());
        int[] iArr = B64.INDEX;
        byte[] array = order.array();
        Intrinsics.checkNotNullExpressionValue(array, "array(...)");
        return B64.encode(array).concat(" tvremote@phone");
    }

    /* JADX WARN: Removed duplicated region for block: B:38:0x014c A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean put(String path, long j, boolean z, String str, Function1 function1) {
        boolean z2;
        Intrinsics.checkNotNullParameter(path, "path");
        String concat = path.concat(".part");
        Stream writeTo = writeTo(concat);
        boolean z3 = false;
        try {
            function1.invoke(writeTo);
            String str2 = "";
            String str3 = "";
            int i = 0;
            while (true) {
                if (i >= 40) {
                    z2 = false;
                    break;
                }
                String obj = StringsKt.trim(shell(120000L, "stat -c %s " + Mdns.q(concat) + " 2>/dev/null")).toString();
                if (Intrinsics.areEqual(obj, String.valueOf(j))) {
                    z2 = true;
                    break;
                }
                i = Intrinsics.areEqual(obj, str3) ? i + 1 : 0;
                try {
                    Thread.sleep(200L);
                    str3 = obj;
                } catch (InterruptedException unused) {
                    throw new IOException("interrupted");
                }
            }
            if (z2 && str != null) {
                try {
                    String obj2 = StringsKt.trim(shell(120000L, "(md5sum " + Mdns.q(concat) + " || toybox md5sum " + Mdns.q(concat) + ") 2>/dev/null")).toString();
                    String substringBefore = StringsKt.substringBefore(obj2, ' ', obj2);
                    Locale locale = Locale.ROOT;
                    String lowerCase = substringBefore.toLowerCase(locale);
                    Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                    if (lowerCase.length() == 32) {
                        String lowerCase2 = str.toLowerCase(locale);
                        Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
                        if (!lowerCase.equals(lowerCase2)) {
                            z2 = false;
                        }
                    }
                } catch (Throwable th) {
                    th = th;
                    z3 = z2;
                    writeTo.close();
                    if (!z3) {
                        try {
                            shell(120000L, "rm -f " + Mdns.q(concat));
                        } catch (IOException unused2) {
                        }
                    }
                    throw th;
                }
            }
            if (z2) {
                String q = Mdns.q(concat);
                String q2 = Mdns.q(path);
                if (z) {
                    str2 = " && chmod a+r " + Mdns.q(path);
                }
                z2 = StringsKt__StringsJVMKt.endsWith(StringsKt.trim(shell(120000L, "mv -f " + q + " " + q2 + str2 + " && echo ok")).toString(), false, "ok");
            }
            writeTo.close();
            if (!z2) {
                try {
                    shell(120000L, "rm -f " + Mdns.q(concat));
                } catch (IOException unused3) {
                }
            }
            return z2;
        } catch (Throwable th2) {
            th = th2;
            writeTo.close();
            if (!z3) {
            }
            throw th;
        }
    }

    public final Msg read() {
        byte[] bArr = new byte[24];
        DataInputStream dataInputStream = this.input;
        if (dataInputStream != null) {
            dataInputStream.readFully(bArr);
            ByteBuffer order = ByteBuffer.wrap(bArr).order(ByteOrder.LITTLE_ENDIAN);
            int i = order.getInt();
            int i2 = order.getInt();
            int i3 = order.getInt();
            int i4 = order.getInt();
            if (i4 >= 0 && i4 <= 1048576) {
                byte[] bArr2 = new byte[i4];
                DataInputStream dataInputStream2 = this.input;
                if (dataInputStream2 != null) {
                    dataInputStream2.readFully(bArr2);
                    return new Msg(i, i2, i3, bArr2);
                }
                Intrinsics.throwUninitializedPropertyAccessException("input");
                throw null;
            }
            throw new IOException("bad adb packet");
        }
        Intrinsics.throwUninitializedPropertyAccessException("input");
        throw null;
    }

    public final synchronized void send(int i, int i2, int i3, byte[] bArr) {
        try {
            int i4 = 0;
            for (byte b : bArr) {
                i4 += b & 255;
            }
            ByteBuffer order = ByteBuffer.allocate(bArr.length + 24).order(ByteOrder.LITTLE_ENDIAN);
            order.putInt(i).putInt(i2).putInt(i3).putInt(bArr.length).putInt(i4).putInt(~i).put(bArr);
            OutputStream outputStream = this.output;
            if (outputStream != null) {
                outputStream.write(order.array());
                OutputStream outputStream2 = this.output;
                if (outputStream2 != null) {
                    outputStream2.flush();
                } else {
                    Intrinsics.throwUninitializedPropertyAccessException("output");
                    throw null;
                }
            } else {
                throw new IOException("not connected");
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    public final String shell(long j, String cmd) {
        Intrinsics.checkNotNullParameter(cmd, "cmd");
        Stream open = open(10000L, "shell:".concat(cmd));
        try {
            String readAll = open.readAll(j);
            open.close();
            return readAll;
        } finally {
        }
    }

    public final Stream writeTo(String path) {
        Intrinsics.checkNotNullParameter(path, "path");
        Stream exec = exec("cat > " + Mdns.q(path));
        exec.pace = new Adb$$ExternalSyntheticLambda5(exec, this, path, 0);
        return exec;
    }

    /* loaded from: classes.dex */
    public final class Stream implements Closeable {
        public volatile boolean closed;
        public final boolean delayed;
        public final int local;
        public Adb$$ExternalSyntheticLambda5 pace;
        public int pos;
        public volatile int remote;
        public long sent;
        public final LinkedBlockingQueue incoming = new LinkedBlockingQueue();
        public final Semaphore opened = new Semaphore(0);
        public final Semaphore acked = new Semaphore(0);
        public final Semaphore credit = new Semaphore(0);
        public byte[] cur = Adb.EMPTY;
        public long paced = 2097152;

        public Stream(int i) {
            this.local = i;
            this.delayed = Adb.this.delayed;
        }

        @Override // java.io.Closeable, java.lang.AutoCloseable
        public final void close() {
            if (!this.closed) {
                end$shared_release();
                try {
                    Adb.this.send(1163086915, this.local, this.remote, Adb.EMPTY);
                } catch (IOException unused) {
                }
            }
        }

        public final void end$shared_release() {
            this.closed = true;
            Adb.this.streams.remove(Integer.valueOf(this.local));
            this.incoming.add(Adb.EOF);
            this.opened.release();
        }

        public final int read(long j, byte[] bArr, int i, int i2) {
            Object take;
            byte[] bArr2;
            int i3 = this.pos;
            byte[] bArr3 = this.cur;
            if (i3 == bArr3.length) {
                byte[] bArr4 = Adb.EOF;
                if (bArr3 != bArr4) {
                    try {
                        if (j > 0) {
                            take = this.incoming.poll(j, TimeUnit.MILLISECONDS);
                        } else {
                            take = this.incoming.take();
                        }
                        byte[] bArr5 = (byte[]) take;
                        if (bArr5 == null) {
                            return 0;
                        }
                        this.cur = bArr5;
                        this.pos = 0;
                        if (bArr5 == bArr4) {
                            return -1;
                        }
                        if (!this.closed) {
                            Adb adb = Adb.this;
                            int length = bArr5.length;
                            adb.getClass();
                            int i4 = this.local;
                            int i5 = this.remote;
                            if (this.delayed) {
                                bArr2 = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(length).array();
                            } else {
                                bArr2 = Adb.EMPTY;
                            }
                            Intrinsics.checkNotNull(bArr2);
                            adb.send(1497451343, i4, i5, bArr2);
                        }
                    } catch (InterruptedException unused) {
                        throw new IOException("interrupted");
                    }
                } else {
                    return -1;
                }
            }
            int min = Math.min(i2, this.cur.length - this.pos);
            System.arraycopy(this.cur, this.pos, bArr, i, min);
            this.pos += min;
            return min;
        }

        public final String readAll(long j) {
            long j2;
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            byte[] bArr = new byte[8192];
            while (true) {
                if (j > 0) {
                    j2 = j;
                } else {
                    j2 = 0;
                }
                int read = read(j2, bArr, 0, 8192);
                if (read >= 0) {
                    if (read != 0) {
                        byteArrayOutputStream.write(bArr, 0, read);
                    } else {
                        Adb.this.kill();
                        throw new IOException("the TV stopped answering");
                    }
                } else {
                    String byteArrayOutputStream2 = byteArrayOutputStream.toString("UTF-8");
                    Intrinsics.checkNotNullExpressionValue(byteArrayOutputStream2, "toString(...)");
                    return StringsKt.trim(StringsKt__StringsJVMKt.replace$default(byteArrayOutputStream2, "\r\n", "\n")).toString();
                }
            }
        }

        public final void readFully(int i, byte[] bArr) {
            int i2 = i;
            int i3 = 0;
            while (i2 > 0) {
                byte[] bArr2 = bArr;
                int read = read(0L, bArr2, i3, i2);
                if (read >= 0) {
                    i3 += read;
                    i2 -= read;
                    bArr = bArr2;
                } else {
                    throw new EOFException("stream closed");
                }
            }
        }

        public final synchronized void write(int i, byte[] data) {
            try {
                Intrinsics.checkNotNullParameter(data, "data");
                int i2 = 0;
                while (i > 0) {
                    if (!this.closed) {
                        int min = Math.min(i, Adb.this.maxData);
                        if (this.delayed) {
                            int i3 = 0;
                            while (!this.credit.tryAcquire(min, 1L, TimeUnit.SECONDS)) {
                                try {
                                    if (this.closed) {
                                        throw new IOException("stream closed");
                                    }
                                    i3++;
                                    if (i3 >= 30) {
                                        Adb.this.kill();
                                        throw new IOException("the TV stopped taking data");
                                    }
                                } catch (InterruptedException unused) {
                                    throw new IOException("interrupted");
                                }
                            }
                        }
                        int i4 = i2 + min;
                        Adb.this.send(1163154007, this.local, this.remote, ArraysKt.copyOfRange(data, i2, i4));
                        if (!this.delayed) {
                            int i5 = 0;
                            while (!this.acked.tryAcquire(1L, TimeUnit.SECONDS)) {
                                try {
                                    if (this.closed) {
                                        throw new IOException("stream closed");
                                    }
                                    i5++;
                                    if (i5 >= 30) {
                                        Adb.this.kill();
                                        throw new IOException("the TV stopped taking data");
                                    }
                                } catch (InterruptedException unused2) {
                                    throw new IOException("interrupted");
                                }
                            }
                        }
                        i -= min;
                        long j = this.sent + min;
                        this.sent = j;
                        if (j >= this.paced) {
                            this.paced = 2097152 + j;
                            Adb$$ExternalSyntheticLambda5 adb$$ExternalSyntheticLambda5 = this.pace;
                            if (adb$$ExternalSyntheticLambda5 != null) {
                                adb$$ExternalSyntheticLambda5.invoke(Long.valueOf(j));
                            }
                        }
                        i2 = i4;
                    } else {
                        throw new IOException("stream closed");
                    }
                }
            } finally {
            }
        }

        public final void write(byte[] data) {
            Intrinsics.checkNotNullParameter(data, "data");
            write(data.length, data);
        }
    }

    public final boolean put(String path, byte[] data, boolean z) {
        Intrinsics.checkNotNullParameter(path, "path");
        Intrinsics.checkNotNullParameter(data, "data");
        long length = data.length;
        byte[] digest = MessageDigest.getInstance("MD5").digest(data);
        Intrinsics.checkNotNullExpressionValue(digest, "digest(...)");
        return put(path, length, z, ArraysKt.joinToString$default(digest, "", new Lan$$ExternalSyntheticLambda0(21)), new Words$$ExternalSyntheticLambda1(1, data));
    }
}
