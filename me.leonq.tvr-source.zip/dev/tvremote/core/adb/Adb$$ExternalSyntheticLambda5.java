package dev.tvremote.core.adb;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Words$$ExternalSyntheticLambda1;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.manage.LauncherApi;
import dev.tvremote.core.manage.Manage$$ExternalSyntheticLambda27;
import dev.tvremote.core.manage.TvAppsApi$$ExternalSyntheticLambda1;
import dev.tvremote.core.ontv.Checkout;
import dev.tvremote.core.ontv.LauncherInstall;
import dev.tvremote.core.ontv.LauncherSwap;
import dev.tvremote.core.ontv.Launchers;
import dev.tvremote.core.ontv.SetupNeed;
import dev.tvremote.core.remote.Lg;
import dev.tvremote.core.remote.Lg$$ExternalSyntheticLambda2;
import dev.tvremote.core.remote.Vidaa$$ExternalSyntheticLambda18;
import dev.tvremote.core.web.Cancel;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda10;
import dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda69;
import dev.tvremote.phone.picker.ManyTvsKt;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.phone.ui.UiKt;
import dev.tvremote.phone.ui.UiKt$$ExternalSyntheticLambda8;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$IntRef;
import kotlin.jvm.internal.Ref$ObjectRef;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class Adb$$ExternalSyntheticLambda5 implements Function1 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;
    public final /* synthetic */ Object f$1;
    public final /* synthetic */ Object f$2;

    public /* synthetic */ Adb$$ExternalSyntheticLambda5(LauncherApi launcherApi, String str, Launchers.Entry entry) {
        this.$r8$classId = 1;
        this.f$0 = launcherApi;
        this.f$2 = str;
        this.f$1 = entry;
    }

    /* JADX WARN: Code restructure failed: missing block: B:74:0x022b, code lost:
    
        r1 = "rolledback:".concat(r13);
     */
    /* JADX WARN: Removed duplicated region for block: B:39:0x01f4  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x0264  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x0280  */
    /* JADX WARN: Removed duplicated region for block: B:67:0x0266  */
    /* JADX WARN: Removed duplicated region for block: B:86:0x01f0 A[SYNTHETIC] */
    @Override // kotlin.jvm.functions.Function1
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object invoke(Object obj) {
        long j;
        Cancel cancel;
        LauncherSwap launcherSwap;
        LauncherSwap.Rec state;
        String str;
        int tvNow;
        Cancel cancel2;
        String str2;
        String str3;
        boolean z = false;
        switch (this.$r8$classId) {
            case 0:
                Adb.Stream stream = (Adb.Stream) this.f$0;
                Adb adb = (Adb) this.f$1;
                String str4 = (String) this.f$2;
                long longValue = ((Long) obj).longValue();
                long j2 = -1;
                int i = 0;
                while (!stream.closed) {
                    ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                    Long longOrNull = StringsKt__StringNumberConversionsKt.toLongOrNull(StringsKt.trim(adb.shell(120000L, ApkSigner$$ExternalSyntheticOutline0.m("stat -c %s ", Mdns.q(str4), " 2>/dev/null"))).toString());
                    if (longOrNull != null) {
                        j = longOrNull.longValue();
                    } else {
                        j = 0;
                    }
                    if (j < longValue - 8388608) {
                        if (j == j2) {
                            i++;
                        } else {
                            i = 0;
                        }
                        if (i < 150) {
                            try {
                                Thread.sleep(200L);
                                j2 = j;
                            } catch (InterruptedException unused) {
                                throw new IOException("interrupted");
                            }
                        } else {
                            stream.close();
                            throw new IOException("the TV stopped taking data");
                        }
                    } else {
                        return Unit.INSTANCE;
                    }
                }
                throw new IOException("stream closed");
            case 1:
                LauncherApi launcherApi = (LauncherApi) this.f$0;
                String str5 = (String) this.f$2;
                Launchers.Entry entry = (Launchers.Entry) this.f$1;
                JSONObject j3 = (JSONObject) obj;
                Intrinsics.checkNotNullParameter(j3, "j");
                Adb adb2 = launcherApi.link.get();
                File file = launcherApi.dir;
                if (file != null) {
                    LauncherInstall launcherInstall = new LauncherInstall(adb2, file, Launchers.fetch$default(), str5);
                    Cancel cancel3 = (Cancel) launcherApi.cancel.invoke();
                    if (launcherInstall.run(entry, 30, new Manage$$ExternalSyntheticLambda27(j3, 1), new TvAppsApi$$ExternalSyntheticLambda1(cancel3, 4)).equals("pending")) {
                        j3.put("step", "confirm").put("pct", 95);
                        LauncherSwap.Rec state2 = launcherInstall.swap.state();
                        if (state2 != null) {
                            if (!state2.state.equals("pending")) {
                                state2 = null;
                            }
                            if (state2 != null) {
                                Words$$ExternalSyntheticLambda1 words$$ExternalSyntheticLambda1 = launcherInstall.sh;
                                if (SetupNeed.ok(SetupNeed.have(words$$ExternalSyntheticLambda1), "launcher")) {
                                    ConcurrentHashMap concurrentHashMap2 = Adb.ASKING;
                                    String q = Mdns.q(entry.name);
                                    StringBuilder sb = new StringBuilder("am start -n dev.tvremote.setup/.LauncherConfirmActivity --es pkg ");
                                    sb.append(entry.pkg);
                                    sb.append(" --es name ");
                                    sb.append(q);
                                    sb.append(" --el until ");
                                    cancel = cancel3;
                                    sb.append(state2.until);
                                    sb.append(" 2>&1");
                                    StringsKt.contains((String) words$$ExternalSyntheticLambda1.invoke(sb.toString()), "Error", false);
                                    while (true) {
                                        launcherSwap = launcherInstall.swap;
                                        state = launcherSwap.state();
                                        if (state != null) {
                                            str = "rolledback:gone";
                                        } else {
                                            String str6 = state.state;
                                            int hashCode = str6.hashCode();
                                            String str7 = state.why;
                                            if (hashCode != -682587753) {
                                                if (hashCode != -393668413) {
                                                    if (hashCode == 3288286 && str6.equals("kept")) {
                                                        str = "kept";
                                                    }
                                                } else if (str6.equals("rolledback")) {
                                                    str = "rolledback:".concat(str7);
                                                }
                                            } else if (!str6.equals("pending")) {
                                                break;
                                            } else {
                                                tvNow = (int) (state.until - launcherSwap.tvNow());
                                                if (tvNow >= -5) {
                                                    cancel2 = cancel;
                                                    if (cancel == null || !cancel2.stopped) {
                                                        j3.put("confirm", Math.max(0, tvNow));
                                                        Thread.sleep(1000L);
                                                        cancel = cancel2;
                                                    }
                                                } else {
                                                    cancel2 = cancel;
                                                }
                                            }
                                        }
                                    }
                                    if (cancel2 != null && cancel2.stopped) {
                                        z = true;
                                    }
                                    str2 = "timeout";
                                    if (z) {
                                        str3 = "timeout";
                                    } else {
                                        str3 = "user";
                                    }
                                    launcherSwap.rollback(str3, null);
                                    if (cancel2 != null && cancel2.stopped) {
                                        str2 = "user";
                                    }
                                    str = "rolledback:".concat(str2);
                                    j3.remove("confirm");
                                    if (!Intrinsics.areEqual(str, "kept")) {
                                        throw new IOException(ApkSigner$$ExternalSyntheticOutline0.m("launcher:", str));
                                    }
                                }
                            }
                        }
                        cancel = cancel3;
                        while (true) {
                            launcherSwap = launcherInstall.swap;
                            state = launcherSwap.state();
                            if (state != null) {
                            }
                            j3.put("confirm", Math.max(0, tvNow));
                            Thread.sleep(1000L);
                            cancel = cancel2;
                        }
                        if (cancel2 != null) {
                            z = true;
                        }
                        str2 = "timeout";
                        if (z) {
                        }
                        launcherSwap.rollback(str3, null);
                        if (cancel2 != null) {
                            str2 = "user";
                        }
                        str = "rolledback:".concat(str2);
                        j3.remove("confirm");
                        if (!Intrinsics.areEqual(str, "kept")) {
                        }
                    }
                    return "kept";
                }
                throw new IOException("no folder for the download");
            case 2:
                Lg lg = (Lg) this.f$0;
                Ref$ObjectRef ref$ObjectRef = (Ref$ObjectRef) this.f$1;
                CountDownLatch countDownLatch = (CountDownLatch) this.f$2;
                JSONObject m = (JSONObject) obj;
                Intrinsics.checkNotNullParameter(m, "m");
                if (Intrinsics.areEqual(m.optString("type"), "response")) {
                    lg.asking = true;
                } else {
                    ref$ObjectRef.element = m;
                    countDownLatch.countDown();
                }
                return Unit.INSTANCE;
            case 3:
                ((MainActivity$$ExternalSyntheticLambda10) this.f$0).invoke(new Vidaa$$ExternalSyntheticLambda18(((Integer) obj).intValue(), (MainActivity) this.f$1, (ArrayList) this.f$2));
                return Unit.INSTANCE;
            case 4:
                String id = (String) obj;
                Intrinsics.checkNotNullParameter(id, "id");
                return Boolean.valueOf(((MainActivity) this.f$0).ui.post(new Lg$$ExternalSyntheticLambda2((Popup) this.f$1, (Ref$IntRef) this.f$2, id, 16)));
            case 5:
                List ips = (List) obj;
                Intrinsics.checkNotNullParameter(ips, "ips");
                Launchers.Entry entry2 = (Launchers.Entry) this.f$1;
                String str8 = entry2.name;
                MainActivity mainActivity = (MainActivity) this.f$0;
                ManyTvsKt.fleetRun$default(mainActivity, str8, ips, new AdbHelpKt$$ExternalSyntheticLambda69(mainActivity, (Launchers.Gallery) this.f$2, entry2), 8);
                return Unit.INSTANCE;
            default:
                List chosen = (List) obj;
                Intrinsics.checkNotNullParameter(chosen, "chosen");
                List asList = ArraysKt.asList(new Integer[]{10, 25, 40, 60});
                String T = Fleet.T("fleet.co_volume", new Pair[0]);
                int indexOf = asList.indexOf(Integer.valueOf(((Checkout.Config) this.f$1).volume));
                ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(asList));
                Iterator it = asList.iterator();
                while (true) {
                    boolean hasNext = it.hasNext();
                    MainActivity mainActivity2 = (MainActivity) this.f$0;
                    if (hasNext) {
                        int intValue = ((Number) it.next()).intValue();
                        arrayList.add(new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@vol_up|", intValue, "%"), "", new UiKt$$ExternalSyntheticLambda8(mainActivity2, (List) this.f$2, chosen, intValue)));
                    } else {
                        UiKt.menu(mainActivity2, T, indexOf, arrayList);
                        return Unit.INSTANCE;
                    }
                }
        }
    }

    public /* synthetic */ Adb$$ExternalSyntheticLambda5(Object obj, Object obj2, Object obj3, int i) {
        this.$r8$classId = i;
        this.f$0 = obj;
        this.f$1 = obj2;
        this.f$2 = obj3;
    }
}
