package dev.tvremote.core.adb;

/* loaded from: classes.dex */
public final /* synthetic */ class AdbLink$$ExternalSyntheticLambda1 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ AdbLink f$0;

    public /* synthetic */ AdbLink$$ExternalSyntheticLambda1(AdbLink adbLink, int i) {
        this.$r8$classId = i;
        this.f$0 = adbLink;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.$r8$classId) {
            case 0:
                AdbLink adbLink = this.f$0;
                try {
                    adbLink.get();
                } catch (Exception unused) {
                } catch (Throwable th) {
                    adbLink.spawning.set(false);
                    throw th;
                }
                adbLink.spawning.set(false);
                return;
            default:
                this.f$0.close();
                return;
        }
    }
}
