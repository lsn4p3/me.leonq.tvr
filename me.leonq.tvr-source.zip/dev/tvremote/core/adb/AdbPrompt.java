package dev.tvremote.core.adb;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticLambda4;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Lan;
import dev.tvremote.core.Lan$$ExternalSyntheticLambda0;
import dev.tvremote.core.WireLog;
import dev.tvremote.core.ontv.Setup$$ExternalSyntheticLambda5;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import kotlin.collections.ArraysKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.sequences.GeneratorSequence;
import kotlin.sequences.GeneratorSequence$iterator$1;
import kotlin.sequences.SequencesKt;
import kotlin.text.Charsets;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;

/* loaded from: classes.dex */
public final class AdbPrompt {
    public static final AdbPrompt INSTANCE = new Object();
    public static final Regex FP = new Regex("(?:[0-9A-F]{2}:){15}[0-9A-F]{2}");
    public static final ConcurrentHashMap pinned = new ConcurrentHashMap();
    public static volatile int plainPort = 8765;

    /* loaded from: classes.dex */
    public final class Node {
        public final boolean checked;
        public final String cls;
        public final boolean focused;
        public final String id;
        public final int x;
        public final int y;

        public Node(String str, String str2, boolean z, boolean z2, int i, int i2) {
            this.id = str;
            this.cls = str2;
            this.checked = z;
            this.focused = z2;
            this.x = i;
            this.y = i2;
        }

        public final boolean getChecked() {
            return this.checked;
        }
    }

    /* loaded from: classes.dex */
    public final class Pin implements X509TrustManager {
        public final String fingerprint;

        public Pin(String str) {
            this.fingerprint = str;
        }

        @Override // javax.net.ssl.X509TrustManager
        public final void checkClientTrusted(X509Certificate[] chain, String authType) {
            Intrinsics.checkNotNullParameter(chain, "chain");
            Intrinsics.checkNotNullParameter(authType, "authType");
            throw new CertificateException("no clients");
        }

        @Override // javax.net.ssl.X509TrustManager
        public final void checkServerTrusted(X509Certificate[] chain, String authType) {
            Intrinsics.checkNotNullParameter(chain, "chain");
            Intrinsics.checkNotNullParameter(authType, "authType");
            byte[] encoded = chain[0].getEncoded();
            Intrinsics.checkNotNullExpressionValue(encoded, "getEncoded(...)");
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(encoded);
            Intrinsics.checkNotNullExpressionValue(digest, "digest(...)");
            String joinToString$default = ArraysKt.joinToString$default(digest, "", new Lan$$ExternalSyntheticLambda0(17));
            Charset charset = Charsets.UTF_8;
            byte[] bytes = joinToString$default.getBytes(charset);
            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
            byte[] bytes2 = this.fingerprint.getBytes(charset);
            Intrinsics.checkNotNullExpressionValue(bytes2, "getBytes(...)");
            if (MessageDigest.isEqual(bytes, bytes2)) {
            } else {
                throw new CertificateException("not the TV's certificate");
            }
        }

        @Override // javax.net.ssl.X509TrustManager
        public final X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[0];
        }
    }

    /* loaded from: classes.dex */
    public final class Seen {
        public final String fingerprint;
        public final ArrayList nodes;

        public Seen(String str, ArrayList arrayList) {
            this.fingerprint = str;
            this.nodes = arrayList;
        }

        public final Node getAlways() {
            Object obj;
            Iterator it = this.nodes.iterator();
            while (true) {
                if (it.hasNext()) {
                    obj = it.next();
                    Node node = (Node) obj;
                    if (StringsKt__StringsJVMKt.endsWith(node.id, false, "alwaysUse") || StringsKt__StringsJVMKt.endsWith(node.cls, false, "CheckBox")) {
                        break;
                    }
                } else {
                    obj = null;
                    break;
                }
            }
            return (Node) obj;
        }

        public final Node getCancel() {
            Object obj;
            Iterator it = this.nodes.iterator();
            while (true) {
                if (it.hasNext()) {
                    obj = it.next();
                    if (((Node) obj).id.equals("android:id/button2")) {
                        break;
                    }
                } else {
                    obj = null;
                    break;
                }
            }
            return (Node) obj;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:54:0x0072, code lost:
    
        return "other:".concat(r8);
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static String allow$shared_release$default(AdbPrompt adbPrompt, AdbPrompt$deny$1 adbPrompt$deny$1, String fingerprint, long j, boolean z, boolean z2, Setup$$ExternalSyntheticLambda5 setup$$ExternalSyntheticLambda5, int i) {
        if ((i & 16) != 0) {
            z2 = true;
        }
        AdbPrompt$allow$2 adbPrompt$allow$2 = AdbPrompt$allow$2.INSTANCE;
        Function0 function0 = setup$$ExternalSyntheticLambda5;
        if ((i & 64) != 0) {
            function0 = new Census$$ExternalSyntheticLambda4(5);
        }
        adbPrompt.getClass();
        Intrinsics.checkNotNullParameter(fingerprint, "fingerprint");
        String upperCase = fingerprint.toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        long currentTimeMillis = System.currentTimeMillis() + j;
        int i2 = 0;
        while (true) {
            Seen read$shared_release = read$shared_release(adbPrompt$deny$1);
            if (read$shared_release != null) {
                String str = read$shared_release.fingerprint;
                if (str.equals(upperCase)) {
                    Node always = read$shared_release.getAlways();
                    Boolean valueOf = always != null ? Boolean.valueOf(always.checked) : null;
                    if (valueOf != null && !valueOf.equals(Boolean.valueOf(z2))) {
                        press(adbPrompt$deny$1, read$shared_release, new Lan$$ExternalSyntheticLambda0(24), adbPrompt$allow$2);
                    }
                    Seen read$shared_release2 = read$shared_release(adbPrompt$deny$1);
                    if (read$shared_release2 != null && read$shared_release2.fingerprint.equals(upperCase)) {
                        Node always2 = read$shared_release2.getAlways();
                        Boolean valueOf2 = always2 != null ? Boolean.valueOf(always2.checked) : null;
                        if (valueOf2 == null || valueOf2.equals(Boolean.valueOf(z2))) {
                            press(adbPrompt$deny$1, read$shared_release2, new Lan$$ExternalSyntheticLambda0(25), adbPrompt$allow$2);
                            adbPrompt$allow$2.invoke(900L);
                            Seen read$shared_release3 = read$shared_release(adbPrompt$deny$1);
                            if (read$shared_release3 != null && read$shared_release3.fingerprint.equals(upperCase)) {
                                return "failed";
                            }
                            return "allowed";
                        }
                        return "failed";
                    }
                } else {
                    if (!z || i2 >= 6) {
                        break;
                    }
                    press(adbPrompt$deny$1, read$shared_release, new Lan$$ExternalSyntheticLambda0(23), adbPrompt$allow$2);
                    i2++;
                    function0.invoke();
                    adbPrompt$allow$2.invoke(1200L);
                }
            } else {
                if (System.currentTimeMillis() > currentTimeMillis) {
                    return "none";
                }
                adbPrompt$allow$2.invoke(800L);
            }
        }
    }

    public static boolean deny(Adb adb, String str) {
        AdbPrompt$deny$1 adbPrompt$deny$1 = new AdbPrompt$deny$1(adb, 0);
        Seen read$shared_release = read$shared_release(adbPrompt$deny$1);
        if (read$shared_release != null) {
            String upperCase = str.toUpperCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
            if (!read$shared_release.fingerprint.equals(upperCase)) {
                return false;
            }
            press(adbPrompt$deny$1, read$shared_release, new Lan$$ExternalSyntheticLambda0(26), AdbPrompt$press$1.INSTANCE);
            return true;
        }
        return false;
    }

    public static void leftovers(Adb adb, String fingerprint) {
        Node node;
        Intrinsics.checkNotNullParameter(adb, "adb");
        Intrinsics.checkNotNullParameter(fingerprint, "fingerprint");
        AdbPrompt$deny$1 adbPrompt$deny$1 = new AdbPrompt$deny$1(adb, 3);
        AdbPrompt$leftovers$1 adbPrompt$leftovers$1 = AdbPrompt$leftovers$1.INSTANCE;
        int i = 0;
        int i2 = 0;
        while (i < 2 && i2 < 15) {
            Seen read$shared_release = read$shared_release(adbPrompt$deny$1);
            if (read$shared_release != null) {
                node = read$shared_release.getCancel();
            } else {
                node = null;
            }
            if (read$shared_release != null && node != null) {
                String upperCase = fingerprint.toUpperCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
                if (read$shared_release.fingerprint.equals(upperCase)) {
                    adbPrompt$deny$1.shell(120000L, "input tap " + node.x + " " + node.y);
                    i2++;
                    adbPrompt$leftovers$1.invoke(1500L);
                    i = 0;
                }
            }
            i++;
            adbPrompt$leftovers$1.invoke(2500L);
        }
        if (i2 > 0) {
            WireLog.all.add("·", "closed " + i2 + " leftover copies of our own question");
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.lang.Object, javax.net.ssl.HostnameVerifier] */
    public static HttpURLConnection openSetup(String host, String pass, String path) {
        URL url;
        String str;
        Intrinsics.checkNotNullParameter(host, "host");
        Intrinsics.checkNotNullParameter(pass, "pass");
        Intrinsics.checkNotNullParameter(path, "path");
        String substringBefore = StringsKt.substringBefore(pass, ':', pass);
        String substringAfter = StringsKt.substringAfter(pass, ':', "");
        Function0 function0 = Lan.wifi;
        if (substringAfter.length() == 0) {
            url = new URL("http://" + host + ":" + plainPort + path);
        } else {
            url = new URL(Census$$ExternalSyntheticOutline0.m("https://", host, ":8766", path));
        }
        HttpURLConnection httpURLConnection = (HttpURLConnection) Lan.open(url);
        if (httpURLConnection instanceof HttpsURLConnection) {
            HttpsURLConnection httpsURLConnection = (HttpsURLConnection) httpURLConnection;
            ConcurrentHashMap concurrentHashMap = pinned;
            Object obj = concurrentHashMap.get(substringAfter);
            if (obj == null) {
                SSLContext sSLContext = SSLContext.getInstance("TLS");
                sSLContext.init(null, new TrustManager[]{new Pin(substringAfter)}, null);
                obj = sSLContext.getSocketFactory();
                Object putIfAbsent = concurrentHashMap.putIfAbsent(substringAfter, obj);
                if (putIfAbsent != null) {
                    obj = putIfAbsent;
                }
            }
            httpsURLConnection.setSSLSocketFactory((SSLSocketFactory) obj);
            httpsURLConnection.setHostnameVerifier(new Object());
        }
        httpURLConnection.setConnectTimeout(4000);
        if (substringAfter.length() == 0) {
            str = "tvr=";
        } else {
            str = "tvrs=";
        }
        httpURLConnection.setRequestProperty("Cookie", str.concat(substringBefore));
        return httpURLConnection;
    }

    public static void press(AdbPrompt$deny$1 adbPrompt$deny$1, Seen seen, Function1 function1, Function1 function12) {
        Node node;
        Node node2;
        Object obj;
        Node node3 = (Node) function1.invoke(seen);
        if (node3 != null) {
            adbPrompt$deny$1.shell(120000L, "input tap " + node3.x + " " + node3.y);
            function12.invoke(500L);
            Seen read$shared_release = read$shared_release(adbPrompt$deny$1);
            if (read$shared_release != null) {
                String str = seen.fingerprint;
                if (read$shared_release.fingerprint.equals(str) && (node = (Node) function1.invoke(read$shared_release)) != null && node.checked == node3.checked) {
                    for (int i = 0; i < 8 && (node2 = (Node) function1.invoke(read$shared_release)) != null; i++) {
                        Iterator it = read$shared_release.nodes.iterator();
                        while (true) {
                            if (it.hasNext()) {
                                obj = it.next();
                                if (((Node) obj).focused) {
                                    break;
                                }
                            } else {
                                obj = null;
                                break;
                            }
                        }
                        Node node4 = (Node) obj;
                        int i2 = node2.y;
                        int i3 = node2.x;
                        if (node4 != null && node4.x == i3 && node4.y == i2) {
                            adbPrompt$deny$1.shell(120000L, "input keyevent 23");
                            return;
                        }
                        int i4 = 20;
                        if (node4 != null) {
                            int i5 = node4.y;
                            if (i2 <= i5 + 10) {
                                i4 = i2 < i5 + (-10) ? 19 : i3 > node4.x ? 22 : 21;
                            }
                        }
                        adbPrompt$deny$1.shell(120000L, "input keyevent " + i4);
                        read$shared_release = read$shared_release(adbPrompt$deny$1);
                        if (read$shared_release == null || !read$shared_release.fingerprint.equals(str)) {
                            return;
                        }
                    }
                    return;
                }
                return;
            }
            return;
        }
        throw new IOException("the question on the TV looks different than expected");
    }

    public static Seen read(Adb adb) {
        return read$shared_release(new AdbPrompt$deny$1(adb, 4));
    }

    public static Seen read$shared_release(AdbPrompt$deny$1 adbPrompt$deny$1) {
        String str;
        String str2;
        if (StringsKt.contains(adbPrompt$deny$1.shell(15000L, "dumpsys window | grep -E 'mCurrentFocus|mFocusedWindow'"), "UsbDebuggingActivity", false)) {
            for (int i = 0; i < 3; i++) {
                String shell = adbPrompt$deny$1.shell(30000L, "uiautomator dump /data/local/tmp/tvr-ui.xml >/dev/null 2>&1; cat /data/local/tmp/tvr-ui.xml; rm -f /data/local/tmp/tvr-ui.xml");
                ArrayList arrayList = new ArrayList();
                GeneratorSequence$iterator$1 generatorSequence$iterator$1 = new GeneratorSequence$iterator$1(Regex.findAll$default(new Regex("<node ([^>]*)"), shell));
                String str3 = "";
                while (generatorSequence$iterator$1.hasNext()) {
                    GeneratorSequence findAll$default = Regex.findAll$default(new Regex("([\\w-]+)=\"([^\"]*)\""), (CharSequence) ((MatcherMatchResult$groupValues$1) ((MatcherMatchResult) generatorSequence$iterator$1.next()).getGroupValues()).get(1));
                    LinkedHashMap linkedHashMap = new LinkedHashMap();
                    GeneratorSequence$iterator$1 generatorSequence$iterator$12 = new GeneratorSequence$iterator$1(findAll$default);
                    while (generatorSequence$iterator$12.hasNext()) {
                        MatcherMatchResult matcherMatchResult = (MatcherMatchResult) generatorSequence$iterator$12.next();
                        linkedHashMap.put(((MatcherMatchResult$groupValues$1) matcherMatchResult.getGroupValues()).get(1), ((MatcherMatchResult$groupValues$1) matcherMatchResult.getGroupValues()).get(2));
                    }
                    String str4 = (String) linkedHashMap.get("text");
                    if (str4 == null) {
                        str4 = "";
                    }
                    MatcherMatchResult find = FP.find(str4, 0);
                    if (find != null) {
                        str3 = find.getValue();
                    }
                    Regex regex = new Regex("\\d+");
                    String str5 = (String) linkedHashMap.get("bounds");
                    if (str5 == null) {
                        str5 = "";
                    }
                    List list = SequencesKt.toList(new GeneratorSequence(Regex.findAll$default(regex, str5), new Lan$$ExternalSyntheticLambda0(22), 2));
                    if (list.size() == 4) {
                        String str6 = (String) linkedHashMap.get("resource-id");
                        if (str6 == null) {
                            str = "";
                        } else {
                            str = str6;
                        }
                        String str7 = (String) linkedHashMap.get("class");
                        if (str7 == null) {
                            str2 = "";
                        } else {
                            str2 = str7;
                        }
                        arrayList.add(new Node(str, str2, Intrinsics.areEqual(linkedHashMap.get("checked"), "true"), Intrinsics.areEqual(linkedHashMap.get("focused"), "true"), (((Number) list.get(2)).intValue() + ((Number) list.get(0)).intValue()) / 2, (((Number) list.get(3)).intValue() + ((Number) list.get(1)).intValue()) / 2));
                    }
                }
                if (str3.length() > 0) {
                    return new Seen(str3, arrayList);
                }
                Thread.sleep(600L);
            }
            return null;
        }
        return null;
    }

    public static String token(Adb adb) {
        String str;
        String str2;
        String str3;
        Pattern compile = Pattern.compile("[a-z]+");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        if (compile.matcher("phone").matches()) {
            str = " --es app ".concat("phone");
        } else {
            str = "";
        }
        String m = ApkSigner$$ExternalSyntheticOutline0.m("am broadcast -n dev.tvremote.setup/.TrustReceiver", str);
        String shell = adb.shell(15000L, m + " --es want fp 2>&1");
        Matcher m7m = Census$$ExternalSyntheticOutline0.m7m("data=\"([0-9a-f]{64})\"", "compile(...)", shell, "input", shell);
        Intrinsics.checkNotNullExpressionValue(m7m, "matcher(...)");
        MatcherMatchResult access$findNext = MathKt.access$findNext(m7m, 0, shell);
        if (access$findNext != null) {
            str2 = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1);
        } else {
            str2 = null;
        }
        if (str2 == null) {
            MatcherMatchResult access$findNext2 = MathKt.access$findNext(Census$$ExternalSyntheticOutline0.m6m("data=\"([0-9a-f]{48})\"", "compile(...)", shell, "matcher(...)"), 0, shell);
            if (access$findNext2 != null) {
                return (String) ((MatcherMatchResult$groupValues$1) access$findNext2.getGroupValues()).get(1);
            }
        } else {
            Pattern compile2 = Pattern.compile("data=\"([0-9a-f]{48})\"");
            Intrinsics.checkNotNullExpressionValue(compile2, "compile(...)");
            String input = adb.shell(15000L, m + " --es tls 1 2>&1");
            Intrinsics.checkNotNullParameter(input, "input");
            Matcher matcher = compile2.matcher(input);
            Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
            MatcherMatchResult access$findNext3 = MathKt.access$findNext(matcher, 0, input);
            if (access$findNext3 != null && (str3 = (String) ((MatcherMatchResult$groupValues$1) access$findNext3.getGroupValues()).get(1)) != null) {
                return Census$$ExternalSyntheticOutline0.m(str3, ":", str2);
            }
        }
        return null;
    }

    public final String allow(Adb adb, String str, long j, boolean z, boolean z2) {
        return allow$shared_release$default(this, new AdbPrompt$deny$1(adb, 1), str, j, z, z2, null, 96);
    }

    public final void helpSetup(Adb adb) {
        Intrinsics.checkNotNullParameter(adb, "adb");
        String shell = adb.shell(15000L, "am broadcast -n dev.tvremote.setup/.TrustReceiver --es want adbkey 2>&1");
        Matcher m7m = Census$$ExternalSyntheticOutline0.m7m("data=\"([0-9A-F]{2}(?::[0-9A-F]{2}){15}) (hold|ask)\"", "compile(...)", shell, "input", shell);
        Intrinsics.checkNotNullExpressionValue(m7m, "matcher(...)");
        MatcherMatchResult access$findNext = MathKt.access$findNext(m7m, 0, shell);
        if (access$findNext != null) {
            String str = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1);
            if (Intrinsics.areEqual(str, adb.fingerprint())) {
                return;
            }
            Setup$$ExternalSyntheticLambda5 setup$$ExternalSyntheticLambda5 = new Setup$$ExternalSyntheticLambda5(1, adb);
            WireLog.all.add("·", "adb answering TV Setup's question: " + allow$shared_release$default(this, new AdbPrompt$deny$1(adb, 2), str, 40000L, true, false, setup$$ExternalSyntheticLambda5, 48));
        }
    }
}
