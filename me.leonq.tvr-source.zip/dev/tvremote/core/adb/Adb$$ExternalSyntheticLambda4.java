package dev.tvremote.core.adb;

/* loaded from: classes.dex */
public final /* synthetic */ class Adb$$ExternalSyntheticLambda4 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Adb f$0;

    public /* synthetic */ Adb$$ExternalSyntheticLambda4(Adb adb, int i) {
        this.$r8$classId = i;
        this.f$0 = adb;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.$r8$classId) {
            case 0:
                Adb adb = this.f$0;
                Thread.sleep(4000L);
                try {
                    if (!adb.dead) {
                        AdbPrompt.INSTANCE.helpSetup(adb);
                        return;
                    }
                    return;
                } catch (Exception unused) {
                    return;
                }
            case 1:
                Adb.m11$r8$lambda$8yQNsDKOE_HPXJvvGWBjdTbzG0(this.f$0);
                return;
            case 2:
                Adb adb2 = this.f$0;
                try {
                    AdbPrompt adbPrompt = AdbPrompt.INSTANCE;
                    AdbPrompt.leftovers(adb2, adb2.fingerprint());
                } catch (Exception unused2) {
                }
                try {
                    AdbPrompt.INSTANCE.helpSetup(adb2);
                    return;
                } catch (Exception unused3) {
                    return;
                }
            default:
                this.f$0.alive(2500L);
                return;
        }
    }
}
