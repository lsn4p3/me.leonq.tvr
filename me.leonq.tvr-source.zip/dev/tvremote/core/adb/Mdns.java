package dev.tvremote.core.adb;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.adb.Spake2;
import dev.tvremote.phone.ui.DlApp;
import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.net.DatagramPacket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.MulticastSocket;
import java.net.NetworkInterface;
import java.net.SocketAddress;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.collections.EmptyList;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;

/* loaded from: classes.dex */
public final class Mdns {

    /* loaded from: classes.dex */
    public final class Record {
        public final String ip;
        public final String name;
        public final int port;
        public final String target;
        public final int type;

        public Record(String name, int i, String target, int i2, String ip, int i3) {
            target = (i3 & 4) != 0 ? "" : target;
            i2 = (i3 & 8) != 0 ? 0 : i2;
            ip = (i3 & 16) != 0 ? "" : ip;
            Intrinsics.checkNotNullParameter(name, "name");
            Intrinsics.checkNotNullParameter(target, "target");
            Intrinsics.checkNotNullParameter(ip, "ip");
            this.name = name;
            this.type = i;
            this.target = target;
            this.port = i2;
            this.ip = ip;
        }
    }

    /* loaded from: classes.dex */
    public final class Service {
        public final String ip;
        public final String name;
        public final int port;

        public Service(String str, int i, String str2) {
            this.name = str;
            this.ip = str2;
            this.port = i;
        }
    }

    public static final Spake2.Pt access$decode(byte[] bArr) {
        boolean z;
        BigInteger bigInteger = Spake2.P;
        if (bArr.length == 32) {
            if ((bArr[31] & 128) != 0) {
                z = true;
            } else {
                z = false;
            }
            byte[] copyOf = Arrays.copyOf(bArr, bArr.length);
            Intrinsics.checkNotNullExpressionValue(copyOf, "copyOf(...)");
            copyOf[31] = (byte) (copyOf[31] & Byte.MAX_VALUE);
            BigInteger bigInteger2 = new BigInteger(1, ArraysKt.reversedArray(copyOf));
            BigInteger bigInteger3 = Spake2.P;
            if (bigInteger2.compareTo(bigInteger3) < 0) {
                BigInteger mod = bigInteger2.multiply(bigInteger2).mod(bigInteger3);
                Intrinsics.checkNotNull(mod);
                BigInteger ONE = BigInteger.ONE;
                Intrinsics.checkNotNullExpressionValue(ONE, "ONE");
                BigInteger subtract = mod.subtract(ONE);
                Intrinsics.checkNotNullExpressionValue(subtract, "subtract(...)");
                BigInteger mod2 = Spake2.D.multiply(mod).add(ONE).mod(bigInteger3);
                BigInteger valueOf = BigInteger.valueOf(2L);
                Intrinsics.checkNotNullExpressionValue(valueOf, "valueOf(...)");
                BigInteger subtract2 = bigInteger3.subtract(valueOf);
                Intrinsics.checkNotNullExpressionValue(subtract2, "subtract(...)");
                BigInteger mod3 = subtract.multiply(mod2.modPow(subtract2, bigInteger3)).mod(bigInteger3);
                BigInteger valueOf2 = BigInteger.valueOf(3L);
                Intrinsics.checkNotNullExpressionValue(valueOf2, "valueOf(...)");
                BigInteger add = bigInteger3.add(valueOf2);
                Intrinsics.checkNotNullExpressionValue(add, "add(...)");
                BigInteger modPow = mod3.modPow(add.shiftRight(3), bigInteger3);
                if (mod2.multiply(modPow).multiply(modPow).subtract(subtract).mod(bigInteger3).signum() != 0) {
                    modPow = modPow.multiply(Spake2.SQRT_M1).mod(bigInteger3);
                    if (mod2.multiply(modPow).multiply(modPow).subtract(subtract).mod(bigInteger3).signum() != 0) {
                        return null;
                    }
                }
                if (modPow.testBit(0) != z) {
                    modPow = modPow.negate().mod(bigInteger3);
                }
                Intrinsics.checkNotNull(modPow);
                BigInteger mod4 = modPow.multiply(bigInteger2).mod(bigInteger3);
                Intrinsics.checkNotNullExpressionValue(mod4, "mod(...)");
                return new Spake2.Pt(modPow, bigInteger2, ONE, mod4);
            }
            return null;
        }
        return null;
    }

    public static final byte[] access$encode(Spake2.Pt pt) {
        BigInteger bigInteger = Spake2.P;
        BigInteger bigInteger2 = pt.z;
        BigInteger bigInteger3 = Spake2.P;
        BigInteger modInverse = bigInteger2.modInverse(bigInteger3);
        BigInteger mod = pt.x.multiply(modInverse).mod(bigInteger3);
        BigInteger mod2 = pt.y.multiply(modInverse).mod(bigInteger3);
        Intrinsics.checkNotNull(mod2);
        return encodeY(mod2, mod.testBit(0));
    }

    public static final byte[] access$hex(String str) {
        BigInteger bigInteger = Spake2.P;
        int length = str.length() / 2;
        byte[] bArr = new byte[length];
        for (int i = 0; i < length; i++) {
            int i2 = i * 2;
            String substring = str.substring(i2, i2 + 2);
            Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
            MathKt.checkRadix(16);
            bArr[i] = (byte) Integer.parseInt(substring, 16);
        }
        return bArr;
    }

    public static final Spake2.Pt access$mul(Spake2.Pt pt, BigInteger bigInteger) {
        BigInteger bigInteger2 = Spake2.P;
        Spake2.Pt pt2 = Spake2.ZERO;
        int bitLength = bigInteger.bitLength();
        for (int i = 0; i < bitLength; i++) {
            if (bigInteger.testBit(i)) {
                pt2 = add(pt2, pt);
            }
            pt = add(pt, pt);
        }
        return pt2;
    }

    public static Spake2.Pt add(Spake2.Pt pt, Spake2.Pt pt2) {
        BigInteger bigInteger = pt.y;
        BigInteger bigInteger2 = pt.x;
        BigInteger subtract = bigInteger.subtract(bigInteger2);
        Intrinsics.checkNotNullExpressionValue(subtract, "subtract(...)");
        BigInteger bigInteger3 = pt2.y;
        BigInteger bigInteger4 = pt2.x;
        BigInteger subtract2 = bigInteger3.subtract(bigInteger4);
        Intrinsics.checkNotNullExpressionValue(subtract2, "subtract(...)");
        BigInteger multiply = subtract.multiply(subtract2);
        BigInteger bigInteger5 = Spake2.P;
        BigInteger mod = multiply.mod(bigInteger5);
        BigInteger add = pt.y.add(bigInteger2);
        Intrinsics.checkNotNullExpressionValue(add, "add(...)");
        BigInteger add2 = pt2.y.add(bigInteger4);
        Intrinsics.checkNotNullExpressionValue(add2, "add(...)");
        BigInteger mod2 = add.multiply(add2).mod(bigInteger5);
        BigInteger mod3 = pt.t.multiply(Spake2.D2).multiply(pt2.t).mod(bigInteger5);
        BigInteger mod4 = pt.z.shiftLeft(1).multiply(pt2.z).mod(bigInteger5);
        Intrinsics.checkNotNull(mod2);
        Intrinsics.checkNotNull(mod);
        BigInteger subtract3 = mod2.subtract(mod);
        Intrinsics.checkNotNullExpressionValue(subtract3, "subtract(...)");
        Intrinsics.checkNotNull(mod4);
        Intrinsics.checkNotNull(mod3);
        BigInteger subtract4 = mod4.subtract(mod3);
        Intrinsics.checkNotNullExpressionValue(subtract4, "subtract(...)");
        BigInteger add3 = mod4.add(mod3);
        Intrinsics.checkNotNullExpressionValue(add3, "add(...)");
        BigInteger add4 = mod2.add(mod);
        Intrinsics.checkNotNullExpressionValue(add4, "add(...)");
        BigInteger mod5 = subtract3.multiply(subtract4).mod(bigInteger5);
        Intrinsics.checkNotNullExpressionValue(mod5, "mod(...)");
        BigInteger mod6 = add3.multiply(add4).mod(bigInteger5);
        Intrinsics.checkNotNullExpressionValue(mod6, "mod(...)");
        BigInteger mod7 = subtract4.multiply(add3).mod(bigInteger5);
        Intrinsics.checkNotNullExpressionValue(mod7, "mod(...)");
        BigInteger mod8 = subtract3.multiply(add4).mod(bigInteger5);
        Intrinsics.checkNotNullExpressionValue(mod8, "mod(...)");
        return new Spake2.Pt(mod5, mod6, mod7, mod8);
    }

    public static byte[] encodeY(BigInteger bigInteger, boolean z) {
        byte[] bArr = new byte[32];
        byte[] byteArray = bigInteger.toByteArray();
        Intrinsics.checkNotNullExpressionValue(byteArray, "toByteArray(...)");
        byte[] reversedArray = ArraysKt.reversedArray(byteArray);
        int min = Math.min(32, reversedArray.length);
        for (int i = 0; i < min; i++) {
            bArr[i] = reversedArray[i];
        }
        if (z) {
            bArr[31] = (byte) (bArr[31] | 128);
        }
        return bArr;
    }

    public static ArrayList find$default(int i, String str, Function1 bind) {
        long j;
        String type = str;
        String str2 = ".local";
        Intrinsics.checkNotNullParameter(type, "type");
        Intrinsics.checkNotNullParameter(bind, "bind");
        DlApp dlApp = new DlApp(type);
        HashSet hashSet = new HashSet();
        try {
            MulticastSocket multicastSocket = new MulticastSocket((SocketAddress) null);
            try {
                multicastSocket.setReuseAddress(false);
                multicastSocket.bind(new InetSocketAddress(0));
                bind.invoke(multicastSocket);
                multicastSocket.setSoTimeout(250);
                multicastSocket.setTimeToLive(255);
                InetAddress byName = InetAddress.getByName("224.0.0.251");
                List interfaces = interfaces();
                find$lambda$7$ask(interfaces, multicastSocket, byName, type.concat(".local"), 12);
                long currentTimeMillis = System.currentTimeMillis();
                long j2 = i + currentTimeMillis;
                long j3 = 700;
                long j4 = currentTimeMillis + j3;
                int i2 = 9000;
                byte[] bArr = new byte[9000];
                while (System.currentTimeMillis() < j2) {
                    DatagramPacket datagramPacket = new DatagramPacket(bArr, i2);
                    try {
                        multicastSocket.receive(datagramPacket);
                    } catch (SocketTimeoutException unused) {
                    }
                    if (datagramPacket.getLength() > 0 && datagramPacket.getAddress() != null) {
                        byte[] data = datagramPacket.getData();
                        j = j4;
                        Intrinsics.checkNotNullExpressionValue(data, "getData(...)");
                        ArrayList parse = parse(datagramPacket.getLength(), data);
                        String hostAddress = datagramPacket.getAddress().getHostAddress();
                        if (hostAddress == null) {
                            hostAddress = "";
                        }
                        dlApp.add(hostAddress, parse);
                        i2 = 9000;
                    } else {
                        j = j4;
                    }
                    datagramPacket.setLength(i2);
                    for (Iterator it = dlApp.found().iterator(); it.hasNext(); it = it) {
                        Service service = (Service) it.next();
                        hashSet.add(service.name + "@" + service.ip + ":" + service.port);
                    }
                    if (System.currentTimeMillis() >= j) {
                        j4 = j + j3;
                        find$lambda$7$ask(interfaces, multicastSocket, byName, type + str2, 12);
                        LinkedHashSet linkedHashSet = (LinkedHashSet) dlApp.pkg;
                        ArrayList arrayList = new ArrayList();
                        for (Object obj : linkedHashSet) {
                            String str3 = str2;
                            HashSet hashSet2 = hashSet;
                            if (((HashMap) dlApp.title).get((String) obj) == null) {
                                arrayList.add(obj);
                            }
                            str2 = str3;
                            hashSet = hashSet2;
                        }
                        String str4 = str2;
                        HashSet hashSet3 = hashSet;
                        Iterator it2 = arrayList.iterator();
                        while (it2.hasNext()) {
                            find$lambda$7$ask(interfaces, multicastSocket, byName, (String) it2.next(), 33);
                        }
                        Iterator it3 = dlApp.hosts().iterator();
                        while (it3.hasNext()) {
                            find$lambda$7$ask(interfaces, multicastSocket, byName, (String) it3.next(), 1);
                        }
                        type = str;
                        str2 = str4;
                        hashSet = hashSet3;
                    } else {
                        type = str;
                        j4 = j;
                    }
                    i2 = 9000;
                }
                multicastSocket.close();
            } finally {
            }
        } catch (Exception unused2) {
        }
        return dlApp.found();
    }

    public static final void find$lambda$7$ask(List list, MulticastSocket multicastSocket, InetAddress inetAddress, String name, int i) {
        int i2 = 0;
        Intrinsics.checkNotNullParameter(name, "name");
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byteArrayOutputStream.write(new byte[]{0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0});
        List split$default = StringsKt.split$default(name, new char[]{'.'});
        ArrayList arrayList = new ArrayList();
        for (Object obj : split$default) {
            if (((String) obj).length() > 0) {
                arrayList.add(obj);
            }
        }
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            byte[] bytes = ((String) it.next()).getBytes(Charsets.UTF_8);
            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
            byteArrayOutputStream.write(bytes.length);
            byteArrayOutputStream.write(bytes);
        }
        byteArrayOutputStream.write(0);
        byteArrayOutputStream.write(0);
        byteArrayOutputStream.write(i & 255);
        byteArrayOutputStream.write(128);
        byteArrayOutputStream.write(1);
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        Intrinsics.checkNotNullExpressionValue(byteArray, "toByteArray(...)");
        if (!list.isEmpty()) {
            Iterator it2 = list.iterator();
            while (it2.hasNext()) {
                try {
                    multicastSocket.setNetworkInterface((NetworkInterface) it2.next());
                    multicastSocket.send(new DatagramPacket(byteArray, byteArray.length, inetAddress, 5353));
                    i2++;
                } catch (Exception unused) {
                }
                if (i2 < 0) {
                    CollectionsKt__CollectionsKt.throwCountOverflow();
                    throw null;
                }
            }
        }
        if (i2 == 0) {
            try {
                multicastSocket.send(new DatagramPacket(byteArray, byteArray.length, inetAddress, 5353));
            } catch (Exception unused2) {
            }
        }
    }

    public static List interfaces() {
        try {
            Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
            Intrinsics.checkNotNullExpressionValue(networkInterfaces, "getNetworkInterfaces(...)");
            ArrayList list = Collections.list(networkInterfaces);
            Intrinsics.checkNotNullExpressionValue(list, "list(...)");
            ArrayList arrayList = new ArrayList();
            for (Object obj : list) {
                NetworkInterface networkInterface = (NetworkInterface) obj;
                try {
                    if (networkInterface.isUp() && !networkInterface.isLoopback() && networkInterface.supportsMulticast()) {
                        Enumeration<InetAddress> inetAddresses = networkInterface.getInetAddresses();
                        Intrinsics.checkNotNullExpressionValue(inetAddresses, "getInetAddresses(...)");
                        ArrayList list2 = Collections.list(inetAddresses);
                        Intrinsics.checkNotNullExpressionValue(list2, "list(...)");
                        if (!list2.isEmpty()) {
                            Iterator it = list2.iterator();
                            while (true) {
                                if (!it.hasNext()) {
                                    break;
                                }
                                if (((InetAddress) it.next()) instanceof Inet4Address) {
                                    arrayList.add(obj);
                                    break;
                                }
                            }
                        }
                    }
                } catch (Exception unused) {
                }
            }
            return arrayList;
        } catch (Exception unused2) {
            return EmptyList.INSTANCE;
        }
    }

    public static ArrayList parse(int i, byte[] bArr) {
        int i2;
        ArrayList arrayList = new ArrayList();
        if (i >= 12) {
            try {
                int parse$u16 = parse$u16(4, bArr);
                int i3 = 12;
                for (int i4 = 0; i4 < parse$u16; i4++) {
                    while (true) {
                        byte b = bArr[i3];
                        int i5 = b & 255;
                        if (i5 == 0) {
                            i2 = i3 + 1;
                            break;
                        }
                        if ((b & 192) == 192) {
                            i2 = i3 + 2;
                            break;
                        }
                        i3 += i5 + 1;
                    }
                    i3 = i2 + 4;
                }
                int parse$u162 = parse$u16(6, bArr) + parse$u16(8, bArr) + parse$u16(10, bArr);
                for (int i6 = 0; i6 < parse$u162; i6++) {
                    Pair readName = readName(bArr, i3, i);
                    String str = (String) readName.first;
                    int intValue = ((Number) readName.second).intValue();
                    int parse$u163 = parse$u16(intValue, bArr);
                    int parse$u164 = parse$u16(intValue + 8, bArr);
                    int i7 = intValue + 10;
                    int i8 = i7 + parse$u164;
                    if (i8 > i) {
                        break;
                    }
                    if (parse$u163 != 1) {
                        if (parse$u163 != 12) {
                            if (parse$u163 != 33) {
                                i3 = i8;
                            } else {
                                String str2 = (String) readName(bArr, intValue + 16, i).first;
                                int parse$u165 = parse$u16(intValue + 14, bArr);
                                i3 = i8;
                                arrayList.add(new Record(str, 33, str2, parse$u165, null, 16));
                            }
                        } else {
                            i3 = i8;
                            arrayList.add(new Record(str, 12, (String) readName(bArr, i7, i).first, 0, null, 24));
                        }
                    } else {
                        i3 = i8;
                        if (parse$u164 == 4) {
                            arrayList.add(new Record(str, 1, null, 0, CollectionsKt.joinToString$default(MathKt.until(0, 4), ".", null, null, new Mdns$$ExternalSyntheticLambda0(bArr, i7, 0), 30), 12));
                        }
                    }
                }
            } catch (IndexOutOfBoundsException unused) {
            }
        }
        return arrayList;
    }

    public static final int parse$u16(int i, byte[] bArr) {
        return (bArr[i + 1] & 255) | ((bArr[i] & 255) << 8);
    }

    public static String q(String s) {
        Intrinsics.checkNotNullParameter(s, "s");
        return ApkSigner$$ExternalSyntheticOutline0.m("'", StringsKt__StringsJVMKt.replace$default(s, "'", "'\\''"), "'");
    }

    public static Pair readName(byte[] bArr, int i, int i2) {
        StringBuilder sb = new StringBuilder();
        int i3 = -1;
        int i4 = 0;
        while (true) {
            int i5 = bArr[i];
            int i6 = i5 & 255;
            if (i6 == 0) {
                if (i3 < 0) {
                    i3 = i + 1;
                }
                String sb2 = sb.toString();
                Intrinsics.checkNotNullExpressionValue(sb2, "toString(...)");
                return new Pair(sb2, Integer.valueOf(i3));
            }
            if ((i5 & 192) == 192) {
                if (i3 < 0) {
                    i3 = i + 2;
                }
                i = (bArr[i + 1] & 255) | ((i5 & 63) << 8);
                i4++;
                if (i4 > 20 || i >= i2) {
                    break;
                }
            } else {
                if (sb.length() > 0) {
                    sb.append('.');
                }
                sb.append(new String(bArr, i + 1, i6, Charsets.UTF_8));
                i += i6 + 1;
            }
        }
        throw new IndexOutOfBoundsException("bad name");
    }
}
