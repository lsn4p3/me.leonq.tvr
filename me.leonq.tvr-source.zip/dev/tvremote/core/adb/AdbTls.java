package dev.tvremote.core.adb;

import dev.tvremote.ConscryptBackend;
import dev.tvremote.core.Census$$ExternalSyntheticLambda4;
import dev.tvremote.core.Diagnose;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Lan;
import dev.tvremote.core.Lan$$ExternalSyntheticLambda0;
import dev.tvremote.core.WireLog;
import dev.tvremote.core.adb.Mdns;
import dev.tvremote.core.remote.Lg$$ExternalSyntheticLambda2;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda5;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.security.GeneralSecurityException;
import java.security.KeyPair;
import java.security.Principal;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509KeyManager;
import javax.net.ssl.X509TrustManager;
import kotlin.Pair;
import kotlin.SynchronizedLazyImpl;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__MutableCollectionsKt;
import kotlin.collections.EmptyList;
import kotlin.collections.EmptySet;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Charsets;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import org.conscrypt.Conscrypt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class AdbTls {
    public static final byte[] CLIENT_NAME;
    public static final AdbTls INSTANCE = new Object();
    public static final byte[] SERVER_NAME;
    public static final SynchronizedLazyImpl backend$delegate;

    /* loaded from: classes.dex */
    public final class OurKeys implements X509KeyManager {
        public final X509Certificate[] chain;
        public final PrivateKey key;

        public OurKeys(PrivateKey privateKey, X509Certificate[] x509CertificateArr) {
            this.key = privateKey;
            this.chain = x509CertificateArr;
        }

        @Override // javax.net.ssl.X509KeyManager
        public final String chooseClientAlias(String[] strArr, Principal[] principalArr, Socket socket) {
            return "adb";
        }

        @Override // javax.net.ssl.X509KeyManager
        public final String chooseServerAlias(String str, Principal[] principalArr, Socket socket) {
            return null;
        }

        @Override // javax.net.ssl.X509KeyManager
        public final X509Certificate[] getCertificateChain(String str) {
            return this.chain;
        }

        @Override // javax.net.ssl.X509KeyManager
        public final String[] getClientAliases(String str, Principal[] principalArr) {
            return new String[]{"adb"};
        }

        @Override // javax.net.ssl.X509KeyManager
        public final PrivateKey getPrivateKey(String str) {
            return this.key;
        }

        @Override // javax.net.ssl.X509KeyManager
        public final String[] getServerAliases(String str, Principal[] principalArr) {
            return null;
        }
    }

    /* loaded from: classes.dex */
    public final class TrustAll implements X509TrustManager {
        @Override // javax.net.ssl.X509TrustManager
        public final void checkClientTrusted(X509Certificate[] x509CertificateArr, String str) {
        }

        @Override // javax.net.ssl.X509TrustManager
        public final void checkServerTrusted(X509Certificate[] x509CertificateArr, String str) {
        }

        @Override // javax.net.ssl.X509TrustManager
        public final X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[0];
        }
    }

    /* loaded from: classes.dex */
    public final class Wireless {
        public final int connect;
        public final int pairing;

        public /* synthetic */ Wireless(int i, int i2) {
            this.connect = i;
            this.pairing = i2;
        }

        public boolean getAny() {
            if (this.connect <= 0 && this.pairing <= 0) {
                return false;
            }
            return true;
        }
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [dev.tvremote.core.adb.AdbTls, java.lang.Object] */
    static {
        Charset charset = Charsets.UTF_8;
        byte[] bytes = "adb pair client\u0000".getBytes(charset);
        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        CLIENT_NAME = bytes;
        byte[] bytes2 = "adb pair server\u0000".getBytes(charset);
        Intrinsics.checkNotNullExpressionValue(bytes2, "getBytes(...)");
        SERVER_NAME = bytes2;
        backend$delegate = new SynchronizedLazyImpl(new Census$$ExternalSyntheticLambda4(6));
    }

    public static boolean available() {
        SynchronizedLazyImpl synchronizedLazyImpl = backend$delegate;
        if (((ConscryptBackend) synchronizedLazyImpl.getValue()) != null) {
            try {
                ConscryptBackend conscryptBackend = (ConscryptBackend) synchronizedLazyImpl.getValue();
                Intrinsics.checkNotNull(conscryptBackend);
                conscryptBackend.context(new KeyManager[0], new TrustManager[0]);
                return true;
            } catch (Throwable unused) {
            }
        }
        return false;
    }

    public static String cleanCode(String str) {
        if (str != null) {
            StringBuilder sb = new StringBuilder();
            int length = str.length();
            for (int i = 0; i < length; i++) {
                char charAt = str.charAt(i);
                if (Character.isDigit(charAt)) {
                    sb.append(charAt);
                }
            }
            String sb2 = sb.toString();
            if (sb2 != null && sb2.length() == 6) {
                return sb2;
            }
            return null;
        }
        return null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static SSLContext context(Adb adb) {
        ConscryptBackend conscryptBackend = (ConscryptBackend) backend$delegate.getValue();
        if (conscryptBackend != null) {
            CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
            byte[] encoded = adb.key.getPublic().getEncoded();
            Intrinsics.checkNotNullExpressionValue(encoded, "getEncoded(...)");
            KeyPair keyPair = adb.key;
            PrivateKey privateKey = keyPair.getPrivate();
            Intrinsics.checkNotNullExpressionValue(privateKey, "getPrivate(...)");
            Certificate generateCertificate = certificateFactory.generateCertificate(new ByteArrayInputStream(Fleet.certificate(privateKey, encoded, "adb")));
            Intrinsics.checkNotNull(generateCertificate, "null cannot be cast to non-null type java.security.cert.X509Certificate");
            PrivateKey privateKey2 = keyPair.getPrivate();
            Intrinsics.checkNotNullExpressionValue(privateKey2, "getPrivate(...)");
            return conscryptBackend.context(new KeyManager[]{new OurKeys(privateKey2, new X509Certificate[]{(X509Certificate) generateCertificate})}, new TrustManager[]{new Object()});
        }
        throw new IOException("adb tls: this app cannot pair (no TLS 1.3)");
    }

    /* JADX WARN: Type inference failed for: r1v1, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    public static Pair discover$default() {
        Lan$$ExternalSyntheticLambda0 lan$$ExternalSyntheticLambda0 = new Lan$$ExternalSyntheticLambda0(27);
        ?? obj = new Object();
        obj.element = EmptyList.INSTANCE;
        Thread thread = new Thread(new Guard$$ExternalSyntheticLambda5(5, (Object) obj, lan$$ExternalSyntheticLambda0));
        thread.setDaemon(true);
        thread.start();
        ArrayList find$default = Mdns.find$default(2500, "_adb-tls-connect._tcp", lan$$ExternalSyntheticLambda0);
        thread.join(2500 + 1000);
        return new Pair(obj.element, find$default);
    }

    public static int discoverConnect$default(String host) {
        Object obj;
        Lan$$ExternalSyntheticLambda0 lan$$ExternalSyntheticLambda0 = new Lan$$ExternalSyntheticLambda0(28);
        Intrinsics.checkNotNullParameter(host, "host");
        Iterator it = Mdns.find$default(3000, "_adb-tls-connect._tcp", lan$$ExternalSyntheticLambda0).iterator();
        while (true) {
            if (it.hasNext()) {
                obj = it.next();
                if (same(host, ((Mdns.Service) obj).ip)) {
                    break;
                }
            } else {
                obj = null;
                break;
            }
        }
        Mdns.Service service = (Mdns.Service) obj;
        if (service != null) {
            return service.port;
        }
        return 0;
    }

    public static byte[] gcm(byte[] bArr, int i, byte[] bArr2) {
        byte[] array = ByteBuffer.allocate(12).order(ByteOrder.LITTLE_ENDIAN).putLong(0L).array();
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(i, new SecretKeySpec(bArr, "AES"), new GCMParameterSpec(128, array));
        byte[] doFinal = cipher.doFinal(bArr2);
        Intrinsics.checkNotNullExpressionValue(doFinal, "doFinal(...)");
        return doFinal;
    }

    public static byte[] hkdf(byte[] bArr, byte[] bArr2) {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(new byte[32], "HmacSHA256"));
        byte[] doFinal = mac.doFinal(bArr);
        Mac mac2 = Mac.getInstance("HmacSHA256");
        mac2.init(new SecretKeySpec(doFinal, "HmacSHA256"));
        byte[] doFinal2 = mac2.doFinal(ArraysKt.plus(bArr2, new byte[]{1}));
        Intrinsics.checkNotNullExpressionValue(doFinal2, "doFinal(...)");
        byte[] copyOf = Arrays.copyOf(doFinal2, 16);
        Intrinsics.checkNotNullExpressionValue(copyOf, "copyOf(...)");
        return copyOf;
    }

    public static byte[] packet(int i, byte[] bArr) {
        byte[] array = ByteBuffer.allocate(bArr.length + 6).order(ByteOrder.BIG_ENDIAN).put((byte) 1).put((byte) i).putInt(bArr.length).put(bArr).array();
        Intrinsics.checkNotNullExpressionValue(array, "array(...)");
        return array;
    }

    public static void pair(Adb adb, String host, int i, String str) {
        Intrinsics.checkNotNullParameter(host, "host");
        if (((ConscryptBackend) backend$delegate.getValue()) != null) {
            Socket connect = Lan.connect(host, i, 6000, new Lan$$ExternalSyntheticLambda0(0));
            try {
                connect.setTcpNoDelay(true);
                connect.setSoTimeout(15000);
                Socket createSocket = context(adb).getSocketFactory().createSocket(connect, host, i, true);
                Intrinsics.checkNotNull(createSocket, "null cannot be cast to non-null type javax.net.ssl.SSLSocket");
                SSLSocket sSLSocket = (SSLSocket) createSocket;
                sSLSocket.setEnabledProtocols(new String[]{"TLSv1.3"});
                try {
                    sSLSocket.startHandshake();
                    byte[] exportKeyingMaterial = Conscrypt.exportKeyingMaterial(sSLSocket, "adb-label\u0000", (byte[]) null, 64);
                    Intrinsics.checkNotNullExpressionValue(exportKeyingMaterial, "exportKeyingMaterial(...)");
                    OutputStream outputStream = sSLSocket.getOutputStream();
                    DataInputStream dataInputStream = new DataInputStream(sSLSocket.getInputStream());
                    Spake2 spake2 = new Spake2(CLIENT_NAME, SERVER_NAME);
                    Charset charset = Charsets.UTF_8;
                    byte[] bytes = str.getBytes(charset);
                    Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                    outputStream.write(packet(0, spake2.generate(ArraysKt.plus(bytes, exportKeyingMaterial))));
                    outputStream.flush();
                    byte[] process = spake2.process(readPacket(dataInputStream, 0));
                    byte[] bytes2 = "adb pairing_auth aes-128-gcm key".getBytes(charset);
                    Intrinsics.checkNotNullExpressionValue(bytes2, "getBytes(...)");
                    byte[] hkdf = hkdf(process, bytes2);
                    byte[] bArr = new byte[8192];
                    byte[] bytes3 = (adb.publicKey$shared_release() + "\u0000").getBytes(charset);
                    Intrinsics.checkNotNullExpressionValue(bytes3, "getBytes(...)");
                    System.arraycopy(bytes3, 0, bArr, 1, bytes3.length);
                    outputStream.write(packet(1, gcm(hkdf, 1, bArr)));
                    outputStream.flush();
                    try {
                        gcm(hkdf, 2, readPacket(dataInputStream, 1));
                        WireLog.all.add("·", "adb pair " + host + ":" + i + " paired");
                        try {
                            connect.close();
                            return;
                        } catch (IOException unused) {
                            return;
                        }
                    } catch (SocketTimeoutException e) {
                        throw e;
                    } catch (IOException unused2) {
                        throw new IOException("adb pair: wrong code");
                    } catch (GeneralSecurityException unused3) {
                        throw new IOException("adb pair: wrong code");
                    }
                } catch (Exception e2) {
                    throw new IOException("adb pair: not a pairing port (" + e2 + ")");
                }
            } catch (Throwable th) {
                try {
                    connect.close();
                } catch (IOException unused4) {
                }
                throw th;
            }
        }
        throw new IOException("adb tls: this app cannot pair (no TLS 1.3)");
    }

    public static boolean plainOpen(String host) {
        Intrinsics.checkNotNullParameter(host, "host");
        try {
            Lan.connect(host, 5555, 1500, new Lan$$ExternalSyntheticLambda0(0)).close();
            return true;
        } catch (Exception unused) {
            return false;
        }
    }

    public static byte[] readPacket(DataInputStream dataInputStream, int i) {
        byte[] bArr = new byte[6];
        dataInputStream.readFully(bArr);
        ByteBuffer order = ByteBuffer.wrap(bArr).order(ByteOrder.BIG_ENDIAN);
        byte b = order.get();
        byte b2 = order.get();
        int i2 = order.getInt();
        if (b == 1 && b2 == i && i2 >= 0 && i2 <= 16384) {
            byte[] bArr2 = new byte[i2];
            dataInputStream.readFully(bArr2);
            return bArr2;
        }
        throw new IOException("adb pair: bad packet");
    }

    public static boolean same(String host, String str) {
        Set set;
        String str2;
        Intrinsics.checkNotNullParameter(host, "host");
        if (!str.equals(host)) {
            if (host.equals("127.0.0.1") || host.equals("localhost") || host.equals("::1")) {
                try {
                    Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
                    Intrinsics.checkNotNullExpressionValue(networkInterfaces, "getNetworkInterfaces(...)");
                    ArrayList list = Collections.list(networkInterfaces);
                    Intrinsics.checkNotNullExpressionValue(list, "list(...)");
                    ArrayList arrayList = new ArrayList();
                    Iterator it = list.iterator();
                    while (it.hasNext()) {
                        Enumeration<InetAddress> inetAddresses = ((NetworkInterface) it.next()).getInetAddresses();
                        Intrinsics.checkNotNullExpressionValue(inetAddresses, "getInetAddresses(...)");
                        ArrayList list2 = Collections.list(inetAddresses);
                        Intrinsics.checkNotNullExpressionValue(list2, "list(...)");
                        CollectionsKt__MutableCollectionsKt.addAll(list2, arrayList);
                    }
                    ArrayList arrayList2 = new ArrayList();
                    Iterator it2 = arrayList.iterator();
                    while (it2.hasNext()) {
                        String hostAddress = ((InetAddress) it2.next()).getHostAddress();
                        if (hostAddress != null) {
                            str2 = StringsKt.substringBefore(hostAddress, '%', hostAddress);
                        } else {
                            str2 = null;
                        }
                        if (str2 != null) {
                            arrayList2.add(str2);
                        }
                    }
                    set = CollectionsKt.toSet(arrayList2);
                } catch (Exception unused) {
                    set = EmptySet.INSTANCE;
                }
                if (set.contains(str)) {
                }
            }
            return false;
        }
        return true;
    }

    /* JADX WARN: Type inference failed for: r7v2, types: [kotlin.jvm.internal.Ref$IntRef, java.lang.Object] */
    public static Wireless wireless$default(int i, String host, Function1 bind) {
        int i2;
        Object obj;
        int i3;
        if ((i & 2) != 0) {
            i2 = 1800;
        } else {
            i2 = 1500;
        }
        if ((i & 4) != 0) {
            Regex regex = Diagnose.OTHER_BRANDS;
            bind = Diagnose.bindUdp;
        }
        Mdns$$ExternalSyntheticLambda0 mdns$$ExternalSyntheticLambda0 = new Mdns$$ExternalSyntheticLambda0(i2, bind);
        Intrinsics.checkNotNullParameter(host, "host");
        Intrinsics.checkNotNullParameter(bind, "bind");
        ?? obj2 = new Object();
        Thread thread = new Thread(new Lg$$ExternalSyntheticLambda2(obj2, mdns$$ExternalSyntheticLambda0, host, 2));
        thread.setDaemon(true);
        thread.start();
        Iterator it = ((Iterable) mdns$$ExternalSyntheticLambda0.invoke("_adb-tls-connect._tcp")).iterator();
        while (true) {
            if (it.hasNext()) {
                obj = it.next();
                if (same(host, ((Mdns.Service) obj).ip)) {
                    break;
                }
            } else {
                obj = null;
                break;
            }
        }
        Mdns.Service service = (Mdns.Service) obj;
        if (service != null) {
            i3 = service.port;
        } else {
            i3 = 0;
        }
        thread.join(i2 + 1000);
        return new Wireless(i3, obj2.element);
    }

    public final synchronized void save(File dir, String host, int i) {
        JSONObject jSONObject;
        Intrinsics.checkNotNullParameter(dir, "dir");
        Intrinsics.checkNotNullParameter(host, "host");
        try {
            jSONObject = new JSONObject(MathKt.readText$default(new File(dir, "adbtls.json")));
        } catch (Exception unused) {
            jSONObject = new JSONObject();
        }
        if (i > 0) {
            jSONObject.put(host, i);
        } else {
            jSONObject.remove(host);
        }
        File file = new File(dir, "adbtls.json");
        String jSONObject2 = jSONObject.toString();
        Intrinsics.checkNotNullExpressionValue(jSONObject2, "toString(...)");
        MathKt.writeText$default(file, jSONObject2);
    }
}
