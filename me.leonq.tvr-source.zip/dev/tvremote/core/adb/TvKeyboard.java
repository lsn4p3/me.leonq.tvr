package dev.tvremote.core.adb;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$IntRef;
import kotlin.math.MathKt;
import kotlin.ranges.IntRange;
import kotlin.sequences.SequencesKt;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;

/* loaded from: classes.dex */
public abstract class TvKeyboard {
    public static final Regex SHOWN = new Regex("\\bmInputShown=true\\b");
    public static final Regex FIELD = new Regex("\\binputType=0x([0-9a-fA-F]+)\\b.*\\bfieldId=");

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* loaded from: classes.dex */
    public final class Do {
        public static final /* synthetic */ Do[] $VALUES;
        public static final Do CLOSE;
        public static final Do NONE;
        public static final Do OPEN;

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r3v0, types: [dev.tvremote.core.adb.TvKeyboard$Do, java.lang.Enum] */
        /* JADX WARN: Type inference failed for: r4v1, types: [dev.tvremote.core.adb.TvKeyboard$Do, java.lang.Enum] */
        /* JADX WARN: Type inference failed for: r5v1, types: [dev.tvremote.core.adb.TvKeyboard$Do, java.lang.Enum] */
        static {
            ?? r3 = new Enum("NONE", 0);
            NONE = r3;
            ?? r4 = new Enum("OPEN", 1);
            OPEN = r4;
            ?? r5 = new Enum("CLOSE", 2);
            CLOSE = r5;
            $VALUES = new Do[]{r3, r4, r5};
        }

        public static Do valueOf(String str) {
            return (Do) Enum.valueOf(Do.class, str);
        }

        public static Do[] values() {
            return (Do[]) $VALUES.clone();
        }
    }

    /* loaded from: classes.dex */
    public final class Follow {
        public boolean closed;
        public boolean opened;
        public boolean typed;
        public boolean was;
    }

    /* loaded from: classes.dex */
    public final class Reader {
        public int asks;
        public boolean proto = true;

        /* JADX WARN: Removed duplicated region for block: B:59:0x00da  */
        /* JADX WARN: Removed duplicated region for block: B:61:0x00df  */
        /* JADX WARN: Removed duplicated region for block: B:69:0x00e4  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final boolean ask(Function1 function1) {
            MatcherMatchResult matcherMatchResult;
            String str;
            Long longOrNull;
            Boolean bool;
            IntRange intRange;
            Object obj;
            long j;
            boolean z;
            IntRange intRange2;
            if (!this.proto) {
                int i = this.asks + 1;
                this.asks = i;
                if (i % 60 == 0) {
                    this.proto = true;
                }
            }
            if (this.proto) {
                String hex = (String) function1.invoke("dumpsys input_method --proto 2>/dev/null | od -An -tx1 -v");
                Regex regex = TvKeyboard.SHOWN;
                Intrinsics.checkNotNullParameter(hex, "hex");
                List split = new Regex("\\s+").split(hex, 0);
                ArrayList arrayList = new ArrayList();
                for (Object obj2 : split) {
                    if (((String) obj2).length() > 0) {
                        arrayList.add(obj2);
                    }
                }
                ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList));
                Iterator it = arrayList.iterator();
                while (true) {
                    bool = null;
                    bool = null;
                    Long l = null;
                    bool = null;
                    if (it.hasNext()) {
                        Integer intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull((String) it.next(), 16);
                        if (intOrNull == null) {
                            break;
                        }
                        arrayList2.add(intOrNull);
                    } else {
                        HashMap fields = TvKeyboard.fields(arrayList2, 0, arrayList2.size());
                        if (fields != null) {
                            Object obj3 = fields.get(3);
                            if (obj3 != null) {
                                if (obj3 instanceof IntRange) {
                                    intRange2 = (IntRange) obj3;
                                } else {
                                    intRange2 = null;
                                }
                                if (intRange2 != null) {
                                    HashMap fields2 = TvKeyboard.fields(arrayList2, intRange2.first, intRange2.last + 1);
                                    if (fields2 != null) {
                                        fields = fields2;
                                    }
                                }
                            }
                            if (fields.get(1) instanceof IntRange) {
                                Object obj4 = fields.get(7);
                                if (obj4 instanceof IntRange) {
                                    intRange = (IntRange) obj4;
                                } else {
                                    intRange = null;
                                }
                                if (intRange != null) {
                                    HashMap fields3 = TvKeyboard.fields(arrayList2, intRange.first, intRange.last + 1);
                                    if (fields3 != null) {
                                        obj = fields3.get(1);
                                        if (obj instanceof Long) {
                                            l = (Long) obj;
                                        }
                                        if (l == null) {
                                            j = l.longValue();
                                        } else {
                                            j = 0;
                                        }
                                        if (Intrinsics.areEqual(fields.get(12), 1L) && j == 0) {
                                            z = false;
                                        } else {
                                            z = true;
                                        }
                                        bool = Boolean.valueOf(z);
                                    }
                                }
                                obj = null;
                                if (obj instanceof Long) {
                                }
                                if (l == null) {
                                }
                                if (Intrinsics.areEqual(fields.get(12), 1L)) {
                                }
                                z = true;
                                bool = Boolean.valueOf(z);
                            }
                        }
                    }
                }
                if (bool != null) {
                    return bool.booleanValue();
                }
                if (!StringsKt.isBlank(hex)) {
                    this.proto = false;
                } else {
                    throw new IOException("no answer");
                }
            }
            Regex regex2 = TvKeyboard.SHOWN;
            String dump = (String) function1.invoke("dumpsys input_method | grep -E 'mInputShown=|inputType=.*fieldId='");
            Intrinsics.checkNotNullParameter(dump, "dump");
            if (TvKeyboard.SHOWN.containsMatchIn(dump) || ((matcherMatchResult = (MatcherMatchResult) SequencesKt.lastOrNull(Regex.findAll$default(TvKeyboard.FIELD, dump))) != null && (str = (String) ((MatcherMatchResult$groupValues$1) matcherMatchResult.getGroupValues()).get(1)) != null && (longOrNull = StringsKt__StringNumberConversionsKt.toLongOrNull(str, 16)) != null && longOrNull.longValue() != 0)) {
                return true;
            }
            return false;
        }
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [kotlin.jvm.internal.Ref$IntRef, java.lang.Object] */
    public static HashMap fields(ArrayList arrayList, int i, int i2) {
        HashMap hashMap = new HashMap();
        ?? obj = new Object();
        obj.element = i;
        while (true) {
            int i3 = obj.element;
            if (i3 < i2) {
                Long fields$varint = fields$varint(obj, i2, arrayList);
                if (fields$varint != null) {
                    long longValue = fields$varint.longValue();
                    int i4 = (int) (longValue >>> 3);
                    int i5 = (int) (longValue & 7);
                    if (i5 != 0) {
                        if (i5 != 1) {
                            if (i5 != 2) {
                                if (i5 == 5) {
                                    obj.element += 4;
                                } else {
                                    return null;
                                }
                            } else {
                                Long fields$varint2 = fields$varint(obj, i2, arrayList);
                                if (fields$varint2 != null) {
                                    long longValue2 = fields$varint2.longValue();
                                    if (longValue2 >= 0 && obj.element + longValue2 <= i2) {
                                        Integer valueOf = Integer.valueOf(i4);
                                        int i6 = obj.element;
                                        int i7 = (int) longValue2;
                                        hashMap.put(valueOf, MathKt.until(i6, i6 + i7));
                                        obj.element += i7;
                                    } else {
                                        return null;
                                    }
                                } else {
                                    return null;
                                }
                            }
                        } else {
                            obj.element += 8;
                        }
                    } else {
                        Integer valueOf2 = Integer.valueOf(i4);
                        Long fields$varint3 = fields$varint(obj, i2, arrayList);
                        if (fields$varint3 != null) {
                            hashMap.put(valueOf2, fields$varint3);
                        } else {
                            return null;
                        }
                    }
                } else {
                    return null;
                }
            } else {
                if (i3 == i2) {
                    return hashMap;
                }
                return null;
            }
        }
    }

    public static final Long fields$varint(Ref$IntRef ref$IntRef, int i, ArrayList arrayList) {
        long j = 0;
        int i2 = 0;
        while (true) {
            int i3 = ref$IntRef.element;
            if (i3 < i && i2 < 64) {
                ref$IntRef.element = i3 + 1;
                j |= (r3 & 127) << i2;
                if (((Number) arrayList.get(i3)).intValue() < 128) {
                    return Long.valueOf(j);
                }
                i2 += 7;
            } else {
                return null;
            }
        }
    }
}
