package dev.tvremote.core.adb;

import dev.tvremote.core.Fleet;
import dev.tvremote.core.WireLog;
import dev.tvremote.core.manage.Manage;
import dev.tvremote.core.ontv.LauncherInstall;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.web.Cancel;
import dev.tvremote.phone.picker.Part;
import java.io.FileInputStream;
import kotlin.Pair;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$ObjectRef;

/* loaded from: classes.dex */
public final /* synthetic */ class AdbLink$$ExternalSyntheticLambda2 implements Function3, LauncherInstall.Progress {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;

    public /* synthetic */ AdbLink$$ExternalSyntheticLambda2(int i, Object obj) {
        this.$r8$classId = i;
        this.f$0 = obj;
    }

    @Override // dev.tvremote.core.ontv.LauncherInstall.Progress
    public void at(String str, int i) {
        String T;
        if (str.equals("download")) {
            T = Fleet.T("fleet.step_ldownload", new Pair[0]) + " " + i + "%";
        } else if (str.equals("install")) {
            T = Fleet.T("fleet.step_linstall", new Pair[0]);
        } else {
            T = Fleet.T("fleet.step_lswap", new Pair[0]);
        }
        ((Part) this.f$0).setStep(T);
    }

    @Override // kotlin.jvm.functions.Function3
    public Object invoke(Object obj, Object obj2, Object obj3) {
        switch (this.$r8$classId) {
            case 1:
                return ((Manage) this.f$0).install((FileInputStream) obj, ((Long) obj2).longValue(), null, (Cancel) obj3);
            default:
                byte[] bArr = (byte[]) obj;
                Intrinsics.checkNotNullParameter((String) obj3, "<unused var>");
                ((Ref$ObjectRef) this.f$0).element = (String) obj2;
                return bArr;
        }
    }

    public void waitingForUser() {
        switch (this.$r8$classId) {
            case 0:
                AdbLink adbLink = (AdbLink) this.f$0;
                adbLink.waiting = true;
                WireLog.all.add("·", "adb " + adbLink.host + " asking on the TV");
                return;
            default:
                ((Tv) this.f$0).status("allow", "");
                return;
        }
    }
}
