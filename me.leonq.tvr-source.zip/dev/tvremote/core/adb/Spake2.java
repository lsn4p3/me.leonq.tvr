package dev.tvremote.core.adb;

import dev.tvremote.core.Census$$ExternalSyntheticLambda4;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.SecureRandom;
import kotlin.SynchronizedLazyImpl;
import kotlin.collections.ArraysKt;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class Spake2 {
    public static final SynchronizedLazyImpl BASE$delegate;
    public static final BigInteger D;
    public static final BigInteger D2;
    public static final BigInteger L;
    public static final SynchronizedLazyImpl M$delegate;
    public static final SynchronizedLazyImpl N$delegate;
    public static final BigInteger P;
    public static final BigInteger SQRT_M1;
    public static final Pt ZERO;
    public byte[] myMsg;
    public final byte[] myName;
    public byte[] passwordHash;
    public BigInteger passwordScalar;
    public final BigInteger secret;
    public final byte[] theirName;

    /* loaded from: classes.dex */
    public final class Pt {
        public final BigInteger t;
        public final BigInteger x;
        public final BigInteger y;
        public final BigInteger z;

        public Pt(BigInteger bigInteger, BigInteger bigInteger2, BigInteger bigInteger3, BigInteger bigInteger4) {
            this.x = bigInteger;
            this.y = bigInteger2;
            this.z = bigInteger3;
            this.t = bigInteger4;
        }
    }

    static {
        BigInteger bigInteger = BigInteger.ONE;
        BigInteger shiftLeft = bigInteger.shiftLeft(255);
        Intrinsics.checkNotNullExpressionValue(shiftLeft, "shiftLeft(...)");
        BigInteger valueOf = BigInteger.valueOf(19L);
        Intrinsics.checkNotNullExpressionValue(valueOf, "valueOf(...)");
        BigInteger subtract = shiftLeft.subtract(valueOf);
        Intrinsics.checkNotNullExpressionValue(subtract, "subtract(...)");
        P = subtract;
        BigInteger shiftLeft2 = bigInteger.shiftLeft(252);
        Intrinsics.checkNotNullExpressionValue(shiftLeft2, "shiftLeft(...)");
        BigInteger add = shiftLeft2.add(new BigInteger("27742317777372353535851937790883648493"));
        Intrinsics.checkNotNullExpressionValue(add, "add(...)");
        L = add;
        BigInteger mod = BigInteger.valueOf(-121665L).multiply(BigInteger.valueOf(121666L).modInverse(subtract)).mod(subtract);
        D = mod;
        D2 = mod.shiftLeft(1).mod(subtract);
        BigInteger valueOf2 = BigInteger.valueOf(2L);
        BigInteger subtract2 = subtract.subtract(bigInteger);
        Intrinsics.checkNotNullExpressionValue(subtract2, "subtract(...)");
        SQRT_M1 = valueOf2.modPow(subtract2.shiftRight(2), subtract);
        M$delegate = new SynchronizedLazyImpl(new Census$$ExternalSyntheticLambda4(8));
        N$delegate = new SynchronizedLazyImpl(new Census$$ExternalSyntheticLambda4(9));
        BASE$delegate = new SynchronizedLazyImpl(new Census$$ExternalSyntheticLambda4(10));
        BigInteger ZERO2 = BigInteger.ZERO;
        Intrinsics.checkNotNullExpressionValue(ZERO2, "ZERO");
        ZERO = new Pt(ZERO2, bigInteger, bigInteger, ZERO2);
    }

    public Spake2(byte[] myName, byte[] theirName) {
        Intrinsics.checkNotNullParameter(myName, "myName");
        Intrinsics.checkNotNullParameter(theirName, "theirName");
        this.myName = myName;
        this.theirName = theirName;
        byte[] bArr = new byte[64];
        new SecureRandom().nextBytes(bArr);
        BigInteger shiftLeft = new BigInteger(1, ArraysKt.reversedArray(bArr)).mod(L).shiftLeft(3);
        Intrinsics.checkNotNullExpressionValue(shiftLeft, "let(...)");
        this.secret = shiftLeft;
    }

    public static final void process$part(MessageDigest messageDigest, byte[] bArr) {
        byte[] bArr2 = new byte[8];
        for (int i = 0; i < 8; i++) {
            bArr2[i] = (byte) (bArr.length >> (i * 8));
        }
        messageDigest.update(bArr2);
        messageDigest.update(bArr);
    }

    public final byte[] generate(byte[] bArr) {
        if (this.myMsg == null) {
            byte[] digest = MessageDigest.getInstance("SHA-512").digest(bArr);
            this.passwordHash = digest;
            Intrinsics.checkNotNull(digest);
            BigInteger mod = new BigInteger(1, ArraysKt.reversedArray(digest)).mod(L);
            this.passwordScalar = mod;
            Pt pt = (Pt) M$delegate.getValue();
            Intrinsics.checkNotNull(mod);
            byte[] access$encode = Mdns.access$encode(Mdns.add(Mdns.access$mul((Pt) BASE$delegate.getValue(), this.secret), Mdns.access$mul(pt, mod)));
            this.myMsg = access$encode;
            return access$encode;
        }
        throw new IllegalStateException("already generated");
    }

    public final byte[] process(byte[] bArr) {
        byte[] bArr2 = this.myMsg;
        if (bArr2 != null) {
            if (bArr.length == 32) {
                Pt access$decode = Mdns.access$decode(bArr);
                if (access$decode != null) {
                    Pt pt = (Pt) N$delegate.getValue();
                    BigInteger bigInteger = this.passwordScalar;
                    Intrinsics.checkNotNull(bigInteger);
                    Pt access$mul = Mdns.access$mul(pt, bigInteger);
                    BigInteger negate = access$mul.x.negate();
                    BigInteger bigInteger2 = P;
                    BigInteger mod = negate.mod(bigInteger2);
                    Intrinsics.checkNotNullExpressionValue(mod, "mod(...)");
                    BigInteger mod2 = access$mul.t.negate().mod(bigInteger2);
                    Intrinsics.checkNotNullExpressionValue(mod2, "mod(...)");
                    byte[] access$encode = Mdns.access$encode(Mdns.access$mul(Mdns.add(access$decode, new Pt(mod, access$mul.y, access$mul.z, mod2)), this.secret));
                    MessageDigest messageDigest = MessageDigest.getInstance("SHA-512");
                    process$part(messageDigest, this.myName);
                    process$part(messageDigest, this.theirName);
                    process$part(messageDigest, bArr2);
                    process$part(messageDigest, bArr);
                    process$part(messageDigest, access$encode);
                    byte[] bArr3 = this.passwordHash;
                    Intrinsics.checkNotNull(bArr3);
                    process$part(messageDigest, bArr3);
                    byte[] digest = messageDigest.digest();
                    Intrinsics.checkNotNullExpressionValue(digest, "digest(...)");
                    return digest;
                }
                throw new IllegalArgumentException("bad pairing message");
            }
            throw new IllegalArgumentException("bad pairing message");
        }
        throw new IllegalStateException("generate first");
    }
}
