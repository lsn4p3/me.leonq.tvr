package dev.tvremote.core.adb;

import dev.tvremote.core.Census;
import dev.tvremote.core.Fleet$$ExternalSyntheticLambda0;
import dev.tvremote.core.WireLog;
import dev.tvremote.phone.MainActivity$onCreate$2;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class AdbLink {
    public volatile Adb adb;
    public volatile long dialStart;
    public volatile Adb dialing;
    public volatile boolean failed;
    public volatile int gen;
    public final String host;
    public final File keyDir;
    public volatile long lastTry;
    public final ReentrantLock lock;
    public final AtomicBoolean spawning;
    public volatile boolean waiting;

    public AdbLink(File keyDir, String host) {
        Intrinsics.checkNotNullParameter(keyDir, "keyDir");
        Intrinsics.checkNotNullParameter(host, "host");
        this.keyDir = keyDir;
        this.host = host;
        this.spawning = new AtomicBoolean();
        this.lock = new ReentrantLock();
    }

    public final void close() {
        Adb adb = this.dialing;
        Adb adb2 = this.adb;
        this.adb = null;
        this.waiting = false;
        if (adb != null) {
            try {
                adb.close();
            } catch (Exception unused) {
            }
        }
        if (adb2 != null) {
            try {
                adb2.close();
            } catch (Exception unused2) {
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final Adb get() {
        boolean z = false;
        Object[] objArr = 0;
        Adb adb = this.adb;
        if (adb != null && !adb.dead) {
            return adb;
        }
        if (!this.lock.tryLock()) {
            long nanoTime = System.nanoTime() + 20000000000L;
            while (!this.waiting) {
                if (!this.lock.tryLock(200L, TimeUnit.MILLISECONDS)) {
                    if (System.nanoTime() > nanoTime) {
                        throw new IOException("adb still connecting");
                    }
                }
            }
            throw new IOException("the TV is asking to allow USB debugging");
        }
        try {
            Adb adb2 = this.adb;
            if (adb2 != null && !adb2.dead) {
                return adb2;
            }
            Adb adb3 = new Adb(this.keyDir);
            int i = this.gen;
            this.dialStart = System.nanoTime();
            this.dialing = adb3;
            try {
                try {
                    Adb connectOrShare$default = Adb.connectOrShare$default(adb3, this.host, new AdbLink$$ExternalSyntheticLambda2(objArr == true ? 1 : 0, this));
                    WireLog.all.add("·", "adb " + this.host + " connected");
                    this.waiting = false;
                    this.failed = false;
                    this.adb = connectOrShare$default;
                    MainActivity$onCreate$2 mainActivity$onCreate$2 = Census.store;
                    Census.connected(this.host, new Fleet$$ExternalSyntheticLambda0(connectOrShare$default, 2));
                    return connectOrShare$default;
                } finally {
                    this.dialing = null;
                    this.waiting = false;
                    if (i == this.gen) {
                        this.lastTry = System.currentTimeMillis();
                    }
                }
            } catch (IOException e) {
                WireLog.all.add("·", "adb " + this.host + " " + e);
                if (i == this.gen) {
                    this.failed = true;
                }
                try {
                    adb3.close();
                } catch (Exception unused) {
                }
                throw e;
            } catch (Exception e2) {
                WireLog.all.add("·", "adb " + this.host + " " + e2);
                if (i == this.gen) {
                    this.failed = true;
                }
                try {
                    adb3.close();
                } catch (Exception unused2) {
                }
                String message = e2.getMessage();
                if (message == null) {
                    message = e2.getClass().getSimpleName();
                }
                throw new IOException(message);
            }
        } finally {
            this.lock.unlock();
        }
    }

    public final String state() {
        Adb adb = this.adb;
        if (adb != null && !adb.dead) {
            return "ready";
        }
        Adb adb2 = this.dialing;
        if (adb2 != null && !this.waiting && (System.nanoTime() - this.dialStart) / 1000000 > 25000) {
            this.failed = true;
            try {
                adb2.close();
                return "closed";
            } catch (Exception unused) {
            }
        } else {
            if (adb2 == null && ((!this.failed || System.currentTimeMillis() - this.lastTry > 10000) && this.spawning.compareAndSet(false, true))) {
                Thread thread = new Thread(new AdbLink$$ExternalSyntheticLambda1(this, 0), "adb-link");
                thread.setDaemon(true);
                thread.start();
            }
            if (this.waiting) {
                return "unauthorized";
            }
            if (!this.failed || adb2 != null || this.spawning.get()) {
                return "unknown";
            }
        }
        return "closed";
    }

    public final boolean waitingForUser() {
        return this.waiting;
    }
}
