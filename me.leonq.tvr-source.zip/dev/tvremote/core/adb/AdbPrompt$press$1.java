package dev.tvremote.core.adb;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.FunctionReferenceImpl;

/* loaded from: classes.dex */
public final /* synthetic */ class AdbPrompt$press$1 extends FunctionReferenceImpl implements Function1 {
    public static final AdbPrompt$press$1 INSTANCE = new FunctionReferenceImpl(1, Thread.class, "sleep", "sleep(J)V");

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        Thread.sleep(((Number) obj).longValue());
        return Unit.INSTANCE;
    }
}
