package dev.tvremote.core.adb;

import dev.tvremote.core.Fleet$$ExternalSyntheticLambda0;
import dev.tvremote.core.WireLog;
import dev.tvremote.core.manage.TvAppsApi$$ExternalSyntheticLambda1;
import java.util.ArrayList;
import java.util.Iterator;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.RegexOption;
import kotlin.text.StringsKt;

/* loaded from: classes.dex */
public abstract class PmInstall {
    public static final Regex REFUSED = new Regex("disabled from pm|install apk has be disabled", RegexOption.IGNORE_CASE);
    public static final Regex ID = new Regex("\\[(\\d+)]");

    /* loaded from: classes.dex */
    public final class Part {
        public final String name;
        public final long size;
        public final String src;

        public Part(long j, String src, String name) {
            Intrinsics.checkNotNullParameter(src, "src");
            Intrinsics.checkNotNullParameter(name, "name");
            this.src = src;
            this.size = j;
            this.name = name;
        }
    }

    public static String bundle(Fleet$$ExternalSyntheticLambda0 fleet$$ExternalSyntheticLambda0, ArrayList arrayList, TvAppsApi$$ExternalSyntheticLambda1 tvAppsApi$$ExternalSyntheticLambda1) {
        String str;
        Iterator it = arrayList.iterator();
        long j = 0;
        while (it.hasNext()) {
            j += ((Part) it.next()).size;
        }
        String str2 = (String) fleet$$ExternalSyntheticLambda0.invoke("pm install-create -r -S " + j + " 2>&1");
        MatcherMatchResult find = ID.find(str2, 0);
        if (find != null && (str = (String) ((MatcherMatchResult$groupValues$1) find.getGroupValues()).get(1)) != null) {
            try {
                Iterator it2 = arrayList.iterator();
                while (it2.hasNext()) {
                    Part part = (Part) it2.next();
                    tvAppsApi$$ExternalSyntheticLambda1.invoke();
                    String str3 = (String) fleet$$ExternalSyntheticLambda0.invoke(part.src + " | pm install-write -S " + part.size + " " + str + " " + part.name + " - 2>&1");
                    if (!StringsKt.contains(str3, "Success", false)) {
                        if (StringsKt.isBlank(str3)) {
                            str3 = "install-write gave no answer";
                        }
                        try {
                            fleet$$ExternalSyntheticLambda0.invoke("pm install-abandon " + str + " 2>&1");
                        } catch (Exception unused) {
                        }
                        return str3;
                    }
                }
                tvAppsApi$$ExternalSyntheticLambda1.invoke();
                return (String) fleet$$ExternalSyntheticLambda0.invoke("pm install-commit " + str + " 2>&1");
            } catch (Throwable th) {
                try {
                    fleet$$ExternalSyntheticLambda0.invoke("pm install-abandon " + str + " 2>&1");
                } catch (Exception unused2) {
                }
                throw th;
            }
        }
        if (StringsKt.isBlank(str2)) {
            return "install-create gave no session";
        }
        return str2;
    }

    public static String fallback(String out, Function1 function1, String quoted, long j, Function0 function0) {
        String str;
        Intrinsics.checkNotNullParameter(out, "out");
        Intrinsics.checkNotNullParameter(quoted, "quoted");
        if (!StringsKt.contains(out, "Success", false) && REFUSED.containsMatchIn(out)) {
            WireLog.all.add("·", "pm install refused by the firmware: trying a session");
            String str2 = "pm install-abandon ";
            String str3 = (String) function1.invoke("pm install-create -r -S " + j + " 2>&1");
            MatcherMatchResult find = ID.find(str3, 0);
            if (find != null && (str = (String) ((MatcherMatchResult$groupValues$1) find.getGroupValues()).get(1)) != null) {
                try {
                    function0.invoke();
                    String str4 = (String) function1.invoke("cat " + quoted + " | pm install-write -S " + j + " " + str + " base.apk - 2>&1");
                    if (!StringsKt.contains(str4, "Success", false)) {
                        if (StringsKt.isBlank(str4)) {
                            str4 = "install-write gave no answer";
                        }
                        str3 = str4;
                        try {
                            str2 = "pm install-abandon " + str + " 2>&1";
                            function1.invoke(str2);
                        } catch (Exception unused) {
                        }
                    } else {
                        function0.invoke();
                        str3 = (String) function1.invoke("pm install-commit " + str + " 2>&1");
                    }
                } catch (Throwable th) {
                    try {
                        function1.invoke(str2 + str + " 2>&1");
                    } catch (Exception unused2) {
                    }
                    throw th;
                }
            } else if (StringsKt.isBlank(str3)) {
                str3 = "install-create gave no session";
            }
            if (!StringsKt.contains(str3, "Success", false)) {
                String str5 = (String) CollectionsKt.lastOrNull(StringsKt.lines(StringsKt.trim(str3).toString()));
                if (str5 == null) {
                    str5 = "";
                }
                return "install blocked by this TV's firmware: ".concat(str5);
            }
            return str3;
        }
        return out;
    }
}
