package dev.tvremote.core.adb;

import kotlin.text.Regex;

/* loaded from: classes.dex */
public abstract class Pkg {
    public static final Regex RE = new Regex("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z_][A-Za-z0-9_]*)+");
}
