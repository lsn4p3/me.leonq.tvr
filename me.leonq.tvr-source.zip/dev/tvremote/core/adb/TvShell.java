package dev.tvremote.core.adb;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import java.net.URLEncoder;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;

/* loaded from: classes.dex */
public final class TvShell {
    public static final TvShell INSTANCE = new Object();
    public static final Regex PKG = Pkg.RE;
    public static final Regex COMP = new Regex("[A-Za-z][A-Za-z0-9_.]*/[A-Za-z0-9_.$]+");
    public static final Regex HOST = new Regex("(?=.{4,253}$)[a-z0-9]([a-z0-9-]*[a-z0-9])?(\\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+");
    public static final Regex SINCE = new Regex("[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}\\.[0-9]{3}");
    public static final Regex NUM = new Regex("-?[0-9]{1,10}");
    public static final Regex PERM = new Regex("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+");
    public static final Regex SETTING_ACTION = new Regex("^(?:android\\.settings\\.[A-Z_]+|com\\.google\\.android\\.intent\\.action\\.CONNECT_INPUT)$");
    public static final Regex SET_LOCKED = new Regex("(?i).*(adb|develop|debug|provision|setup|verif|install|package|vpn|dns|proxy|wifi|airplane|bluetooth|mobile|tether|captive|ntp|lock|password|policy|service|input_method|accessibility_enabled|touch_exploration|location|android_id|_uri|component|hidden_api|database|locale|density|volume|boot|hdr|formats|user|fac|zram|usb_mass|netstats|standby|safe_volume|shop|tuner|tcl|miracast|always_on_vpn|maintenance|earc_status).*");
    public static final Object ON_ONLY = MapsKt__MapsKt.mapOf(new Pair("adb_enabled", "1"), new Pair("adb_wifi_enabled", "1"));
    public static final Object VOLUME = MapsKt__MapsKt.mapOf(new Pair("volume_system", 1), new Pair("volume_music", 3));
    public static final Regex SET_NAME = new Regex("[A-Za-z][A-Za-z0-9_.]{0,80}");
    public static final Regex SET_VALUE = new Regex("[A-Za-z0-9 ._:+-]{0,100}");

    /* JADX WARN: Type inference failed for: r0v0, types: [java.util.Map, java.lang.Object] */
    public static Map getVOLUME() {
        return VOLUME;
    }

    /* renamed from: int, reason: not valid java name */
    public static long m12int(String str, long j, long j2, Long l) {
        if (NUM.matches(str)) {
            long parseLong = Long.parseLong(str);
            if ((l == null || parseLong != l.longValue()) && (j > parseLong || parseLong > j2)) {
                throw new IllegalArgumentException("out of range");
            }
            return parseLong;
        }
        throw new IllegalArgumentException("bad number");
    }

    public static String log(String str, String str2) {
        String str3;
        pkg(str);
        if (str2.length() > 0 && !SINCE.matches(str2)) {
            throw new IllegalArgumentException("bad time");
        }
        if (str2.length() > 0) {
            str3 = ApkSigner$$ExternalSyntheticOutline0.m("-T '", str2, "'");
        } else {
            str3 = "-t 300";
        }
        return Census$$ExternalSyntheticOutline0.m("p=$(pidof ", str, "); echo pid $p; [ -n \"$p\" ] && logcat -d -v threadtime --pid=${p%% *} ", str3, " | tail -n 500");
    }

    public static void pkg(String str) {
        if (PKG.matches(str)) {
        } else {
            throw new IllegalArgumentException("bad package name");
        }
    }

    public static String search(String q) {
        Intrinsics.checkNotNullParameter(q, "q");
        String take = StringsKt.take(StringsKt.trim(q).toString(), 300);
        if (take.length() > 0) {
            ConcurrentHashMap concurrentHashMap = Adb.ASKING;
            return "q='cmd package query-activities --brief -a android.intent.action.VIEW -c android.intent.category.BROWSABLE -d'; u=$($q " + Mdns.q(youtube("x")) + " 2>/dev/null | grep /); b=$($q " + Mdns.q("https://example.com/results?search_query=x") + " 2>/dev/null | grep /); y=; for a in $u; do case \"$b\" in *\"$a\"*) ;; *) y=${a%%/*}; break;; esac; done; [ -z \"$u\" ] && pm list packages -e 2>/dev/null | grep -qx package:com.google.android.youtube.tv && y=com.google.android.youtube.tv; if [ -n \"$y\" ]; then am start -a android.intent.action.VIEW -d " + Mdns.q(youtube(take)) + " -p $y 2>&1 | grep -q Error || echo yt; else am start -a android.search.action.GLOBAL_SEARCH --es query " + Mdns.q(take) + " 2>&1 | grep -q Error || echo gs; fi";
        }
        throw new IllegalArgumentException("empty query");
    }

    public static String searchIn(String pkg, String str, String q) {
        String m;
        Intrinsics.checkNotNullParameter(pkg, "pkg");
        Intrinsics.checkNotNullParameter(q, "q");
        pkg(pkg);
        String take = StringsKt.take(StringsKt.trim(q).toString(), 300);
        if (take.length() > 0) {
            if (str != null && (!StringsKt__StringsJVMKt.startsWith(str, false, "https://") || str.length() >= 1000)) {
                throw new IllegalArgumentException("bad link");
            }
            ConcurrentHashMap concurrentHashMap = Adb.ASKING;
            String q2 = Mdns.q(pkg);
            String str2 = "";
            if (str == null) {
                m = "";
            } else {
                m = ApkSigner$$ExternalSyntheticOutline0.m("g=$(cmd package query-activities --brief -a android.intent.action.VIEW -d 'https://example.com/results?search_query=x' 2>/dev/null); for a in $(cmd package query-activities --brief -a android.intent.action.VIEW -d ", Mdns.q(str), " 2>/dev/null | grep /); do case \"$g\" in *\"$a\"*) ;; *) t=\"-p ${a%%/*}\"; break;; esac; done; ");
            }
            if (str != null) {
                str2 = ApkSigner$$ExternalSyntheticOutline0.m("am start -a android.intent.action.VIEW -d ", Mdns.q(str), " $t 2>&1 | grep -q Error || r=url; ");
            }
            return "p=" + q2 + "; r=none; t=; if pm list packages -e $p 2>/dev/null | grep -qx \"package:$p\"; then t=\"-p $p\"; else " + m + " fi; " + str2 + "if [ $r = none ] && cmd package query-activities --brief -a android.intent.action.SEARCH 2>/dev/null | grep -q \"^ *$p/\"; then am start -a android.intent.action.SEARCH -p $p --es query " + Mdns.q(take) + " 2>&1 | grep -q Error || r=search; fi; echo $r";
        }
        throw new IllegalArgumentException("empty query");
    }

    public static String setting(List list) {
        if (!list.isEmpty()) {
            if (!list.isEmpty()) {
                Iterator it = list.iterator();
                while (it.hasNext()) {
                    if (SETTING_ACTION.matches((String) it.next())) {
                    }
                }
            }
            return ApkSigner$$ExternalSyntheticOutline0.m("for a in ", CollectionsKt.joinToString$default(list, " ", null, null, null, 62), "; do o=$(am start -a $a 2>&1); case \"$o\" in *Error*|*xception*) ;; *) echo ok; exit 0;; esac; done; am start -a android.settings.SETTINGS >/dev/null 2>&1; echo fallback");
        }
        throw new IllegalArgumentException("not a settings page");
    }

    public static String youtube(String q) {
        Intrinsics.checkNotNullParameter(q, "q");
        return ApkSigner$$ExternalSyntheticOutline0.m("https://www.youtube.com/results?search_query=", URLEncoder.encode(StringsKt.trim(q).toString(), "UTF-8"));
    }

    public final String tvset(String str, String str2) {
        String obj = StringsKt.trim(str2).toString();
        switch (str.hashCode()) {
            case 99625:
                if (str.equals("dns")) {
                    if (obj.length() == 0) {
                        return "settings put global private_dns_mode opportunistic; settings delete global private_dns_specifier >/dev/null 2>&1; settings delete global tvr_dns_off >/dev/null 2>&1; echo ok";
                    }
                    Locale ROOT = Locale.ROOT;
                    Intrinsics.checkNotNullExpressionValue(ROOT, "ROOT");
                    String lowerCase = obj.toLowerCase(ROOT);
                    Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                    if (HOST.matches(lowerCase)) {
                        return ApkSigner$$ExternalSyntheticOutline0.m("trap '' HUP PIPE; m=$(settings get global private_dns_mode); h=$(settings get global private_dns_specifier); settings put global private_dns_specifier ", lowerCase, "; settings put global private_dns_mode hostname; e=$(($(date +%s)+30)); while [ $(date +%s) -lt $e ]; do sleep 2; { r=t$RANDOM$RANDOM; timeout 5 ping -c 1 -W 3 $r.1.2.3.4.sslip.io 2>&1 | grep -q '^PING ' || timeout 5 ping -c 1 -W 3 $r.1.2.3.4.nip.io 2>&1 | grep -q '^PING '; } && { settings delete global tvr_dns_off >/dev/null 2>&1; echo ok; exit; }; done; if [ \"$h\" = null ]; then settings delete global private_dns_specifier >/dev/null 2>&1; else settings put global private_dns_specifier \"$h\"; fi; [ \"$m\" = null ] && m=opportunistic; settings put global private_dns_mode $m; echo failed");
                    }
                    throw new IllegalArgumentException("bad DNS name");
                }
                break;
            case 3208415:
                if (str.equals("home")) {
                    if (COMP.matches(obj)) {
                        return Census$$ExternalSyntheticOutline0.m("cmd package query-activities --brief -a android.intent.action.MAIN -c android.intent.category.HOME | grep -qF '", obj, "' || { echo 'not a home screen'; exit; }; cmd package set-home-activity '", obj, "' >/dev/null 2>&1; echo home $({ p=$(cmd role get-role-holders android.app.role.HOME 2>/dev/null); c=$([ -n \"$p\" ] && cmd package query-activities --brief -a android.intent.action.MAIN -c android.intent.category.HOME 2>/dev/null | grep -m1 \"^ *$p/\"); if [ -n \"$c\" ]; then echo $c; else cmd package resolve-activity --brief -c android.intent.category.HOME -a android.intent.action.MAIN; fi; } | tail -n 1)");
                    }
                    throw new IllegalArgumentException("bad home screen");
                }
                break;
            case 109211285:
                if (str.equals("saver")) {
                    if (Intrinsics.areEqual(obj, "off")) {
                        return "settings put secure screensaver_enabled 0; echo ok";
                    }
                    return "settings put secure screensaver_enabled 1; settings put system screen_off_timeout " + m12int(obj, 60000L, 86400000L, null) + "; echo ok";
                }
                break;
            case 109522647:
                if (str.equals("sleep")) {
                    return "settings put secure sleep_timeout " + m12int(obj, 60000L, 86400000L, -1L) + "; echo ok";
                }
                break;
            case 1552717032:
                if (str.equals("density")) {
                    if (Intrinsics.areEqual(obj, "reset")) {
                        return "wm density reset; echo ok";
                    }
                    return "wm density " + m12int(obj, 100L, 800L, null) + "; echo ok";
                }
                break;
        }
        throw new IllegalArgumentException("unknown setting");
    }

    /* JADX WARN: Type inference failed for: r1v6, types: [java.util.Map, java.lang.Object] */
    public static String setting(String str, String str2, String str3) {
        if (SetsKt.setOf((Object[]) new String[]{"global", "secure", "system"}).contains(str)) {
            if (SET_NAME.matches(str2)) {
                String str4 = (String) ON_ONLY.get(str2);
                if (str4 != null) {
                    if (!str.equals("global") || !str3.equals(str4)) {
                        throw new IllegalArgumentException("locked");
                    }
                } else if (SET_LOCKED.matches(str2)) {
                    throw new IllegalArgumentException("locked");
                }
                if (!SET_VALUE.matches(str3)) {
                    throw new IllegalArgumentException("bad value");
                }
                if (str4 != null) {
                    return "settings put global " + str2 + " '" + str3 + "'; sleep 1; [ \"$(settings get global " + str2 + ")\" = '" + str3 + "' ] && echo ok || echo 'turned itself back off'";
                }
                StringBuilder sb = new StringBuilder("settings put ");
                sb.append(str);
                sb.append(" ");
                sb.append(str2);
                sb.append(" '");
                return Census$$ExternalSyntheticOutline0.m(sb, str3, "'; echo ok");
            }
            throw new IllegalArgumentException("bad name");
        }
        throw new IllegalArgumentException("bad table");
    }
}
