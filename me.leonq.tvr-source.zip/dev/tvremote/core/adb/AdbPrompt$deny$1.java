package dev.tvremote.core.adb;

import kotlin.Function;
import kotlin.jvm.internal.FunctionAdapter;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final /* synthetic */ class AdbPrompt$deny$1 implements FunctionAdapter {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Adb $tmp0;

    public /* synthetic */ AdbPrompt$deny$1(Adb adb, int i) {
        this.$r8$classId = i;
        this.$tmp0 = adb;
    }

    public final boolean equals(Object obj) {
        switch (this.$r8$classId) {
            case 0:
                if ((obj instanceof AdbPrompt$deny$1) && (obj instanceof FunctionAdapter)) {
                    return getFunctionDelegate().equals(((FunctionAdapter) obj).getFunctionDelegate());
                }
                return false;
            case 1:
                if ((obj instanceof AdbPrompt$deny$1) && (obj instanceof FunctionAdapter)) {
                    return getFunctionDelegate().equals(((FunctionAdapter) obj).getFunctionDelegate());
                }
                return false;
            case 2:
                if ((obj instanceof AdbPrompt$deny$1) && (obj instanceof FunctionAdapter)) {
                    return getFunctionDelegate().equals(((FunctionAdapter) obj).getFunctionDelegate());
                }
                return false;
            case 3:
                if ((obj instanceof AdbPrompt$deny$1) && (obj instanceof FunctionAdapter)) {
                    return getFunctionDelegate().equals(((FunctionAdapter) obj).getFunctionDelegate());
                }
                return false;
            default:
                if ((obj instanceof AdbPrompt$deny$1) && (obj instanceof FunctionAdapter)) {
                    return getFunctionDelegate().equals(((FunctionAdapter) obj).getFunctionDelegate());
                }
                return false;
        }
    }

    @Override // kotlin.jvm.internal.FunctionAdapter
    public final Function getFunctionDelegate() {
        switch (this.$r8$classId) {
            case 0:
                return new FunctionReferenceImpl(2, this.$tmp0, Adb.class, "shell", "shell(Ljava/lang/String;J)Ljava/lang/String;");
            case 1:
                return new FunctionReferenceImpl(2, this.$tmp0, Adb.class, "shell", "shell(Ljava/lang/String;J)Ljava/lang/String;");
            case 2:
                return new FunctionReferenceImpl(2, this.$tmp0, Adb.class, "shell", "shell(Ljava/lang/String;J)Ljava/lang/String;");
            case 3:
                return new FunctionReferenceImpl(2, this.$tmp0, Adb.class, "shell", "shell(Ljava/lang/String;J)Ljava/lang/String;");
            default:
                return new FunctionReferenceImpl(2, this.$tmp0, Adb.class, "shell", "shell(Ljava/lang/String;J)Ljava/lang/String;");
        }
    }

    public final int hashCode() {
        switch (this.$r8$classId) {
            case 0:
                return getFunctionDelegate().hashCode();
            case 1:
                return getFunctionDelegate().hashCode();
            case 2:
                return getFunctionDelegate().hashCode();
            case 3:
                return getFunctionDelegate().hashCode();
            default:
                return getFunctionDelegate().hashCode();
        }
    }

    public final String shell(long j, String p0) {
        switch (this.$r8$classId) {
            case 0:
                Intrinsics.checkNotNullParameter(p0, "p0");
                return this.$tmp0.shell(j, p0);
            case 1:
                Intrinsics.checkNotNullParameter(p0, "p0");
                return this.$tmp0.shell(j, p0);
            case 2:
                Intrinsics.checkNotNullParameter(p0, "p0");
                return this.$tmp0.shell(j, p0);
            case 3:
                Intrinsics.checkNotNullParameter(p0, "p0");
                return this.$tmp0.shell(j, p0);
            default:
                Intrinsics.checkNotNullParameter(p0, "p0");
                return this.$tmp0.shell(j, p0);
        }
    }
}
