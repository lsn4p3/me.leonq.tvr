package dev.tvremote.core.adb;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

/* loaded from: classes.dex */
public final /* synthetic */ class AdbPrompt$$ExternalSyntheticLambda1 implements HostnameVerifier {
    @Override // javax.net.ssl.HostnameVerifier
    public final boolean verify(String str, SSLSession sSLSession) {
        AdbPrompt adbPrompt = AdbPrompt.INSTANCE;
        return true;
    }
}
