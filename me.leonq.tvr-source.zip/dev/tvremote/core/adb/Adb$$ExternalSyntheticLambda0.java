package dev.tvremote.core.adb;

import android.app.Activity;
import android.app.Dialog;
import android.media.ToneGenerator;
import android.widget.Button;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.ontv.RemoteLabels;
import dev.tvremote.core.remote.Lg;
import dev.tvremote.phone.ir.IrEvents;
import dev.tvremote.phone.ir.IrHear;
import dev.tvremote.phone.media.NowApp;
import dev.tvremote.phone.media.PlayingBar;
import dev.tvremote.phone.ui.IconBesideText;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.tvapps.AppList;
import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.net.ssl.SSLSocket;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import org.conscrypt.FileClientSessionCache;
import org.conscrypt.metrics.ConscryptStatsLog;
import org.conscrypt.metrics.StatsLogImpl;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class Adb$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;

    public /* synthetic */ Adb$$ExternalSyntheticLambda0(int i, Object obj) {
        this.$r8$classId = i;
        this.f$0 = obj;
    }

    @Override // java.lang.Runnable
    public final void run() {
        String str;
        JSONObject optJSONObject;
        String str2;
        String optString;
        String optString2;
        JSONObject optJSONObject2;
        JSONObject request$default;
        int read;
        Long l;
        long j;
        String str3;
        final int i = 1;
        final int i2 = 0;
        switch (this.$r8$classId) {
            case 0:
                try {
                    ((Socket) this.f$0).close();
                    return;
                } catch (IOException unused) {
                    return;
                }
            case 1:
                RemoteLabels remoteLabels = (RemoteLabels) this.f$0;
                synchronized (remoteLabels.running) {
                    if (remoteLabels.stamps == null) {
                        remoteLabels.ask();
                    }
                }
                return;
            case 2:
                try {
                    ((HttpURLConnection) this.f$0).disconnect();
                    return;
                } catch (Exception unused2) {
                    return;
                }
            case 3:
                SSLSocket sSLSocket = (SSLSocket) this.f$0;
                if (sSLSocket != null) {
                    try {
                        sSLSocket.close();
                        return;
                    } catch (Exception unused3) {
                        return;
                    }
                }
                return;
            case 4:
                final Lg lg = (Lg) this.f$0;
                if (lg.model.length() == 0 && (request$default = Lg.request$default(lg, "ssap://system/getSystemInfo", null, 0L, 6)) != null) {
                    String optString3 = request$default.optString("modelName");
                    Intrinsics.checkNotNullExpressionValue(optString3, "optString(...)");
                    lg.model = optString3;
                }
                JSONObject request$default2 = Lg.request$default(lg, "ssap://com.webos.service.update/getCurrentSWInformation", null, 0L, 6);
                if (request$default2 != null) {
                    String optString4 = request$default2.optString("product_name");
                    List asList = ArraysKt.asList(new String[]{request$default2.optString("major_ver"), request$default2.optString("minor_ver")});
                    ArrayList arrayList = new ArrayList();
                    for (Object obj : asList) {
                        String str4 = (String) obj;
                        Intrinsics.checkNotNull(str4);
                        if (str4.length() > 0) {
                            arrayList.add(obj);
                        }
                    }
                    List asList2 = ArraysKt.asList(new String[]{optString4, CollectionsKt.joinToString$default(arrayList, ".", null, null, null, 62)});
                    ArrayList arrayList2 = new ArrayList();
                    for (Object obj2 : asList2) {
                        String str5 = (String) obj2;
                        Intrinsics.checkNotNull(str5);
                        if (str5.length() > 0) {
                            arrayList2.add(obj2);
                        }
                    }
                    lg.version = CollectionsKt.joinToString$default(arrayList2, " ", null, null, null, 62);
                    if (lg.model.length() == 0) {
                        String optString5 = request$default2.optString("model_name");
                        Intrinsics.checkNotNullExpressionValue(optString5, "optString(...)");
                        lg.model = optString5;
                    }
                }
                JSONObject request$default3 = Lg.request$default(lg, "ssap://com.webos.service.connectionmanager/getinfo", null, 0L, 6);
                JSONObject request$default4 = Lg.request$default(lg, "ssap://com.webos.service.connectionmanager/getstatus", null, 0L, 6);
                if (request$default3 != null) {
                    if (request$default4 != null && (optJSONObject2 = request$default4.optJSONObject("wired")) != null) {
                        str = optJSONObject2.optString("state");
                    } else {
                        str = null;
                    }
                    if (Intrinsics.areEqual(str, "connected")) {
                        optJSONObject = request$default3.optJSONObject("wiredInfo");
                    } else {
                        optJSONObject = request$default3.optJSONObject("wifiInfo");
                    }
                    if (optJSONObject != null && (optString2 = optJSONObject.optString("macAddress")) != null) {
                        str2 = optString2.toUpperCase(Locale.ROOT);
                        Intrinsics.checkNotNullExpressionValue(str2, "toUpperCase(...)");
                    } else {
                        JSONObject optJSONObject3 = request$default3.optJSONObject("wiredInfo");
                        if (optJSONObject3 != null && (optString = optJSONObject3.optString("macAddress")) != null) {
                            str2 = optString.toUpperCase(Locale.ROOT);
                            Intrinsics.checkNotNullExpressionValue(str2, "toUpperCase(...)");
                        } else {
                            str2 = "";
                        }
                    }
                    lg.mac = str2;
                }
                lg.subscribe("ssap://audio/getVolume", new Function1() { // from class: dev.tvremote.core.remote.Lg$$ExternalSyntheticLambda10
                    /* JADX WARN: Removed duplicated region for block: B:43:0x00dd  */
                    @Override // kotlin.jvm.functions.Function1
                    /*
                        Code decompiled incorrectly, please refer to instructions dump.
                    */
                    public final Object invoke(Object obj3) {
                        int optInt;
                        boolean optBoolean;
                        String optString6;
                        boolean z;
                        boolean z2;
                        switch (i2) {
                            case 0:
                                Lg lg2 = lg;
                                JSONObject p = (JSONObject) obj3;
                                Intrinsics.checkNotNullParameter(p, "p");
                                JSONObject optJSONObject4 = p.optJSONObject("volumeStatus");
                                Integer num = null;
                                if (optJSONObject4 != null) {
                                    int optInt2 = optJSONObject4.optInt("volume", -1);
                                    Integer valueOf = Integer.valueOf(optInt2);
                                    if (optInt2 < 0) {
                                        valueOf = null;
                                    }
                                    if (valueOf != null) {
                                        optInt = valueOf.intValue();
                                        if (optJSONObject4 == null && optJSONObject4.has("muteStatus")) {
                                            optBoolean = optJSONObject4.optBoolean("muteStatus");
                                        } else {
                                            optBoolean = p.optBoolean("muted", p.optBoolean("mute"));
                                        }
                                        if (optJSONObject4 != null || (optString6 = optJSONObject4.optString("soundOutput")) == null) {
                                            optString6 = p.optString("scenario");
                                        }
                                        Intrinsics.checkNotNull(optString6);
                                        z = false;
                                        if (optString6.length() > 0 && !StringsKt.contains(optString6, "tv_speaker", false) && !StringsKt.contains(optString6, "tv_external_speaker", false)) {
                                            z = true;
                                        }
                                        lg2.external = z;
                                        if (optInt >= 0) {
                                            Integer valueOf2 = Integer.valueOf(optInt);
                                            int i3 = 100;
                                            if (optJSONObject4 != null) {
                                                int optInt3 = optJSONObject4.optInt("maxVolume", 100);
                                                Integer valueOf3 = Integer.valueOf(optInt3);
                                                if (optInt3 > 0) {
                                                    num = valueOf3;
                                                }
                                                if (num != null) {
                                                    i3 = num.intValue();
                                                }
                                            }
                                            lg2.volume = new Triple(valueOf2, Integer.valueOf(i3), Boolean.valueOf(optBoolean));
                                        }
                                        return Unit.INSTANCE;
                                    }
                                }
                                optInt = p.optInt("volume", -1);
                                if (optJSONObject4 == null) {
                                }
                                optBoolean = p.optBoolean("muted", p.optBoolean("mute"));
                                if (optJSONObject4 != null) {
                                }
                                optString6 = p.optString("scenario");
                                Intrinsics.checkNotNull(optString6);
                                z = false;
                                if (optString6.length() > 0) {
                                    z = true;
                                }
                                lg2.external = z;
                                if (optInt >= 0) {
                                }
                                return Unit.INSTANCE;
                            case 1:
                                Lg lg3 = lg;
                                JSONObject p2 = (JSONObject) obj3;
                                Intrinsics.checkNotNullParameter(p2, "p");
                                String optString7 = p2.optString("appId");
                                Intrinsics.checkNotNullExpressionValue(optString7, "optString(...)");
                                lg3.app = optString7;
                                if (lg3.powerUnknown) {
                                    if (lg3.app.length() > 0 || !Intrinsics.areEqual(lg3.isOn, Boolean.FALSE)) {
                                        z2 = true;
                                    } else {
                                        z2 = false;
                                    }
                                    lg3.isOn = Boolean.valueOf(z2);
                                }
                                return Unit.INSTANCE;
                            default:
                                Lg lg4 = lg;
                                JSONObject p3 = (JSONObject) obj3;
                                Intrinsics.checkNotNullParameter(p3, "p");
                                String optString8 = p3.optString("state");
                                Intrinsics.checkNotNull(optString8);
                                if (optString8.length() > 0) {
                                    lg4.isOn = Boolean.valueOf(!Lg.OFF.contains(optString8));
                                }
                                return Unit.INSTANCE;
                        }
                    }
                });
                lg.subscribe("ssap://com.webos.applicationManager/getForegroundAppInfo", new Function1() { // from class: dev.tvremote.core.remote.Lg$$ExternalSyntheticLambda10
                    /* JADX WARN: Removed duplicated region for block: B:43:0x00dd  */
                    @Override // kotlin.jvm.functions.Function1
                    /*
                        Code decompiled incorrectly, please refer to instructions dump.
                    */
                    public final Object invoke(Object obj3) {
                        int optInt;
                        boolean optBoolean;
                        String optString6;
                        boolean z;
                        boolean z2;
                        switch (i) {
                            case 0:
                                Lg lg2 = lg;
                                JSONObject p = (JSONObject) obj3;
                                Intrinsics.checkNotNullParameter(p, "p");
                                JSONObject optJSONObject4 = p.optJSONObject("volumeStatus");
                                Integer num = null;
                                if (optJSONObject4 != null) {
                                    int optInt2 = optJSONObject4.optInt("volume", -1);
                                    Integer valueOf = Integer.valueOf(optInt2);
                                    if (optInt2 < 0) {
                                        valueOf = null;
                                    }
                                    if (valueOf != null) {
                                        optInt = valueOf.intValue();
                                        if (optJSONObject4 == null && optJSONObject4.has("muteStatus")) {
                                            optBoolean = optJSONObject4.optBoolean("muteStatus");
                                        } else {
                                            optBoolean = p.optBoolean("muted", p.optBoolean("mute"));
                                        }
                                        if (optJSONObject4 != null || (optString6 = optJSONObject4.optString("soundOutput")) == null) {
                                            optString6 = p.optString("scenario");
                                        }
                                        Intrinsics.checkNotNull(optString6);
                                        z = false;
                                        if (optString6.length() > 0 && !StringsKt.contains(optString6, "tv_speaker", false) && !StringsKt.contains(optString6, "tv_external_speaker", false)) {
                                            z = true;
                                        }
                                        lg2.external = z;
                                        if (optInt >= 0) {
                                            Integer valueOf2 = Integer.valueOf(optInt);
                                            int i3 = 100;
                                            if (optJSONObject4 != null) {
                                                int optInt3 = optJSONObject4.optInt("maxVolume", 100);
                                                Integer valueOf3 = Integer.valueOf(optInt3);
                                                if (optInt3 > 0) {
                                                    num = valueOf3;
                                                }
                                                if (num != null) {
                                                    i3 = num.intValue();
                                                }
                                            }
                                            lg2.volume = new Triple(valueOf2, Integer.valueOf(i3), Boolean.valueOf(optBoolean));
                                        }
                                        return Unit.INSTANCE;
                                    }
                                }
                                optInt = p.optInt("volume", -1);
                                if (optJSONObject4 == null) {
                                }
                                optBoolean = p.optBoolean("muted", p.optBoolean("mute"));
                                if (optJSONObject4 != null) {
                                }
                                optString6 = p.optString("scenario");
                                Intrinsics.checkNotNull(optString6);
                                z = false;
                                if (optString6.length() > 0) {
                                    z = true;
                                }
                                lg2.external = z;
                                if (optInt >= 0) {
                                }
                                return Unit.INSTANCE;
                            case 1:
                                Lg lg3 = lg;
                                JSONObject p2 = (JSONObject) obj3;
                                Intrinsics.checkNotNullParameter(p2, "p");
                                String optString7 = p2.optString("appId");
                                Intrinsics.checkNotNullExpressionValue(optString7, "optString(...)");
                                lg3.app = optString7;
                                if (lg3.powerUnknown) {
                                    if (lg3.app.length() > 0 || !Intrinsics.areEqual(lg3.isOn, Boolean.FALSE)) {
                                        z2 = true;
                                    } else {
                                        z2 = false;
                                    }
                                    lg3.isOn = Boolean.valueOf(z2);
                                }
                                return Unit.INSTANCE;
                            default:
                                Lg lg4 = lg;
                                JSONObject p3 = (JSONObject) obj3;
                                Intrinsics.checkNotNullParameter(p3, "p");
                                String optString8 = p3.optString("state");
                                Intrinsics.checkNotNull(optString8);
                                if (optString8.length() > 0) {
                                    lg4.isOn = Boolean.valueOf(!Lg.OFF.contains(optString8));
                                }
                                return Unit.INSTANCE;
                        }
                    }
                });
                final int i3 = 2;
                if (!lg.subscribe("ssap://com.webos.service.tvpower/power/getPowerState", new Function1() { // from class: dev.tvremote.core.remote.Lg$$ExternalSyntheticLambda10
                    /* JADX WARN: Removed duplicated region for block: B:43:0x00dd  */
                    @Override // kotlin.jvm.functions.Function1
                    /*
                        Code decompiled incorrectly, please refer to instructions dump.
                    */
                    public final Object invoke(Object obj3) {
                        int optInt;
                        boolean optBoolean;
                        String optString6;
                        boolean z;
                        boolean z2;
                        switch (i3) {
                            case 0:
                                Lg lg2 = lg;
                                JSONObject p = (JSONObject) obj3;
                                Intrinsics.checkNotNullParameter(p, "p");
                                JSONObject optJSONObject4 = p.optJSONObject("volumeStatus");
                                Integer num = null;
                                if (optJSONObject4 != null) {
                                    int optInt2 = optJSONObject4.optInt("volume", -1);
                                    Integer valueOf = Integer.valueOf(optInt2);
                                    if (optInt2 < 0) {
                                        valueOf = null;
                                    }
                                    if (valueOf != null) {
                                        optInt = valueOf.intValue();
                                        if (optJSONObject4 == null && optJSONObject4.has("muteStatus")) {
                                            optBoolean = optJSONObject4.optBoolean("muteStatus");
                                        } else {
                                            optBoolean = p.optBoolean("muted", p.optBoolean("mute"));
                                        }
                                        if (optJSONObject4 != null || (optString6 = optJSONObject4.optString("soundOutput")) == null) {
                                            optString6 = p.optString("scenario");
                                        }
                                        Intrinsics.checkNotNull(optString6);
                                        z = false;
                                        if (optString6.length() > 0 && !StringsKt.contains(optString6, "tv_speaker", false) && !StringsKt.contains(optString6, "tv_external_speaker", false)) {
                                            z = true;
                                        }
                                        lg2.external = z;
                                        if (optInt >= 0) {
                                            Integer valueOf2 = Integer.valueOf(optInt);
                                            int i32 = 100;
                                            if (optJSONObject4 != null) {
                                                int optInt3 = optJSONObject4.optInt("maxVolume", 100);
                                                Integer valueOf3 = Integer.valueOf(optInt3);
                                                if (optInt3 > 0) {
                                                    num = valueOf3;
                                                }
                                                if (num != null) {
                                                    i32 = num.intValue();
                                                }
                                            }
                                            lg2.volume = new Triple(valueOf2, Integer.valueOf(i32), Boolean.valueOf(optBoolean));
                                        }
                                        return Unit.INSTANCE;
                                    }
                                }
                                optInt = p.optInt("volume", -1);
                                if (optJSONObject4 == null) {
                                }
                                optBoolean = p.optBoolean("muted", p.optBoolean("mute"));
                                if (optJSONObject4 != null) {
                                }
                                optString6 = p.optString("scenario");
                                Intrinsics.checkNotNull(optString6);
                                z = false;
                                if (optString6.length() > 0) {
                                    z = true;
                                }
                                lg2.external = z;
                                if (optInt >= 0) {
                                }
                                return Unit.INSTANCE;
                            case 1:
                                Lg lg3 = lg;
                                JSONObject p2 = (JSONObject) obj3;
                                Intrinsics.checkNotNullParameter(p2, "p");
                                String optString7 = p2.optString("appId");
                                Intrinsics.checkNotNullExpressionValue(optString7, "optString(...)");
                                lg3.app = optString7;
                                if (lg3.powerUnknown) {
                                    if (lg3.app.length() > 0 || !Intrinsics.areEqual(lg3.isOn, Boolean.FALSE)) {
                                        z2 = true;
                                    } else {
                                        z2 = false;
                                    }
                                    lg3.isOn = Boolean.valueOf(z2);
                                }
                                return Unit.INSTANCE;
                            default:
                                Lg lg4 = lg;
                                JSONObject p3 = (JSONObject) obj3;
                                Intrinsics.checkNotNullParameter(p3, "p");
                                String optString8 = p3.optString("state");
                                Intrinsics.checkNotNull(optString8);
                                if (optString8.length() > 0) {
                                    lg4.isOn = Boolean.valueOf(!Lg.OFF.contains(optString8));
                                }
                                return Unit.INSTANCE;
                        }
                    }
                })) {
                    lg.powerUnknown = true;
                    if (lg.isOn == null) {
                        lg.isOn = Boolean.TRUE;
                    }
                }
                if (lg.isOn == null) {
                    lg.isOn = Boolean.TRUE;
                    return;
                }
                return;
            case 5:
                new Dialog((Activity) this.f$0).show();
                return;
            case 6:
                IrHear irHear = (IrHear) this.f$0;
                IrEvents.Reader reader = new IrEvents.Reader();
                byte[] bArr = new byte[4096];
                StringBuilder sb = new StringBuilder();
                while (!irHear.closed && (read = irHear.s.read(500L, bArr, 0, 4096)) >= 0) {
                    try {
                        for (int i4 = 0; i4 < read; i4++) {
                            char c = (char) bArr[i4];
                            if (c != '\n') {
                                sb.append(c);
                            } else {
                                String sb2 = sb.toString();
                                Intrinsics.checkNotNullExpressionValue(sb2, "toString(...)");
                                if (reader.key(sb2)) {
                                    if (reader.mapped) {
                                        irHear.lastKey = System.nanoTime() / 1000000;
                                    } else {
                                        MatcherMatchResult find = IrEvents.SCAN.find(sb2, 0);
                                        if (find != null && (str3 = (String) ((MatcherMatchResult$groupValues$1) find.getGroupValues()).get(1)) != null) {
                                            l = StringsKt__StringNumberConversionsKt.toLongOrNull(str3, 16);
                                        } else {
                                            l = null;
                                        }
                                        if (l != null) {
                                            j = l.longValue();
                                        } else {
                                            j = -1;
                                        }
                                        irHear.scanValue = j;
                                        irHear.lastScan = System.nanoTime() / 1000000;
                                    }
                                }
                                sb.setLength(0);
                            }
                        }
                    } catch (Exception unused4) {
                        return;
                    }
                }
                return;
            case 7:
                ((NowApp) this.f$0).tick.run();
                return;
            case 8:
                ((PlayingBar) this.f$0).tick.run();
                return;
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                ((ToneGenerator) this.f$0).release();
                return;
            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                Popup popup = (Popup) this.f$0;
                if (popup.isShowing()) {
                    popup.setMessage(Fleet.T("setup.direct_body", new Pair[0]));
                    return;
                }
                return;
            case 11:
                IconBesideText.place((Button) this.f$0);
                return;
            case FileClientSessionCache.MAX_SIZE /* 12 */:
                File file = (File) this.f$0;
                AtomicBoolean atomicBoolean = AppList.asking;
                try {
                    List list = AppList.bases;
                    AppList.ask(file);
                } catch (IOException unused5) {
                } catch (Throwable th) {
                    atomicBoolean.set(false);
                    throw th;
                }
                atomicBoolean.set(false);
                return;
            default:
                StatsLogImpl.$r8$lambda$OQuWYm__zPPq9kShEglo_NxnAbU((StatsLogImpl) this.f$0);
                return;
        }
    }
}
