package dev.tvremote.core.adb;

import dev.tvremote.core.Fleet;
import dev.tvremote.phone.MainActivity;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class Mdns$$ExternalSyntheticLambda0 implements Function1 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;
    public final /* synthetic */ int f$1;

    public /* synthetic */ Mdns$$ExternalSyntheticLambda0(int i, Function1 function1) {
        this.$r8$classId = 1;
        this.f$1 = i;
        this.f$0 = function1;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        String T;
        int i = this.f$1;
        Object obj2 = this.f$0;
        switch (this.$r8$classId) {
            case 0:
                return String.valueOf(((byte[]) obj2)[((Integer) obj).intValue() + i] & 255);
            case 1:
                String it = (String) obj;
                Intrinsics.checkNotNullParameter(it, "it");
                return Mdns.find$default(i, it, (Function1) obj2);
            default:
                JSONObject r = (JSONObject) obj;
                Intrinsics.checkNotNullParameter(r, "r");
                MainActivity mainActivity = (MainActivity) obj2;
                if (!MathKt.needsSetup(mainActivity, r)) {
                    if (i > 0) {
                        T = Fleet.T("automation.the_tv_turns_off", new Pair("time", MathKt.hm(r.optLong("sleep_at"), r.optLong("now"))));
                    } else {
                        T = Fleet.T("auto.sleep_cancelled", new Pair[0]);
                    }
                    MathKt.toast(mainActivity, T);
                }
                return Unit.INSTANCE;
        }
    }

    public /* synthetic */ Mdns$$ExternalSyntheticLambda0(Object obj, int i, int i2) {
        this.$r8$classId = i2;
        this.f$0 = obj;
        this.f$1 = i;
    }
}
