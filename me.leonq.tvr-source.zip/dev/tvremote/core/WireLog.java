package dev.tvremote.core;

import dev.tvremote.core.remote.Remote;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;

/* loaded from: classes.dex */
public final class WireLog {
    public static final WireLog all = new WireLog();
    public static volatile String app = "TV Remote";
    public int repeats;
    public final ArrayDeque lines = new ArrayDeque();
    public final SimpleDateFormat clock = new SimpleDateFormat("HH:mm:ss.SSS", Locale.ROOT);
    public String last = "";

    public final void add(String str, String text) {
        Intrinsics.checkNotNullParameter(text, "text");
        String replace$default = StringsKt__StringsJVMKt.replace$default(Scrub.blank(text), "\n", "\\n");
        if (replace$default.length() > 600) {
            replace$default = StringsKt.take(replace$default, 600) + " …(" + replace$default.length() + ")";
        }
        String m = Census$$ExternalSyntheticOutline0.m(str, " ", replace$default);
        String format = this.clock.format(new Date());
        synchronized (this.lines) {
            if (Intrinsics.areEqual(m, this.last)) {
                this.repeats++;
                this.lines.removeLast();
                this.lines.addLast(format + " " + m + " (×" + (this.repeats + 1) + ")");
                return;
            }
            this.last = m;
            this.repeats = 0;
            this.lines.addLast(format + " " + m);
            while (this.lines.size() > 500) {
                this.lines.removeFirst();
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:14:0x004d, code lost:
    
        if (r9 == null) goto L11;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final String report(Remote remote) {
        String str;
        String m;
        String joinToString$default;
        if (remote != null) {
            List list = Remote.Kind.ALL;
            List asList = ArraysKt.asList(new String[]{"TV ".concat(Remote.Kind.name(remote.getKind())), remote.getModel(), remote.getVersion()});
            ArrayList arrayList = new ArrayList();
            for (Object obj : asList) {
                if (((String) obj).length() > 0) {
                    arrayList.add(obj);
                }
            }
            str = CollectionsKt.joinToString$default(arrayList, " · ", null, null, null, 62);
        }
        str = "";
        if (StringsKt.contains(app, "Android", false)) {
            m = "";
        } else {
            m = Census$$ExternalSyntheticOutline0.m(System.getProperty("os.name"), " ", System.getProperty("os.version"));
        }
        List asList2 = ArraysKt.asList(new String[]{app, m, str});
        ArrayList arrayList2 = new ArrayList();
        for (Object obj2 : asList2) {
            if (((String) obj2).length() > 0) {
                arrayList2.add(obj2);
            }
        }
        String joinToString$default2 = CollectionsKt.joinToString$default(arrayList2, "\n", null, null, null, 62);
        synchronized (this.lines) {
            joinToString$default = CollectionsKt.joinToString$default(this.lines, "\n", null, null, null, 62);
        }
        if (joinToString$default.length() == 0) {
            joinToString$default = "(empty)";
        }
        return joinToString$default2 + "\n\n" + ((Object) joinToString$default);
    }
}
