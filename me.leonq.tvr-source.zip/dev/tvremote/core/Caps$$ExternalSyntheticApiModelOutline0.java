package dev.tvremote.core;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.drawable.Icon;
import org.conscrypt.R;

/* loaded from: classes.dex */
public abstract /* synthetic */ class Caps$$ExternalSyntheticApiModelOutline0 {
    public static /* synthetic */ Notification.Action.Builder m(Icon icon, String str, PendingIntent pendingIntent) {
        return new Notification.Action.Builder(icon, str, pendingIntent);
    }

    public static /* bridge */ /* synthetic */ Icon m(Context context) {
        return Icon.createWithResource(context, R.drawable.icon);
    }

    public static /* bridge */ /* synthetic */ Object m(Context context, Class cls) {
        return context.getSystemService(cls);
    }
}
