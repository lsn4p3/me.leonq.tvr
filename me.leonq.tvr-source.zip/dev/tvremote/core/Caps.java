package dev.tvremote.core;

import android.content.Context;
import android.content.pm.FeatureInfo;
import android.hardware.display.DisplayManager;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.os.Build;
import android.os.Looper;
import android.view.Display;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Locale;
import org.conscrypt.metrics.ConscryptStatsLog;

/* loaded from: classes.dex */
public final class Caps {
    /* JADX WARN: Removed duplicated region for block: B:26:0x0079  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x007c A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static void audio(Context context, StringBuilder sb) {
        AudioDeviceInfo[] devices;
        int type;
        String str;
        int[] encodings;
        String str2;
        devices = ((AudioManager) context.getSystemService("audio")).getDevices(2);
        for (AudioDeviceInfo audioDeviceInfo : devices) {
            type = audioDeviceInfo.getType();
            if (type != 2) {
                if (type != 6) {
                    if (type != 29) {
                        switch (type) {
                            case 8:
                                str = "bluetooth";
                                break;
                            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                                str = "hdmi";
                                break;
                            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                                str = "arc";
                                break;
                        }
                    } else {
                        str = "earc";
                    }
                } else {
                    str = "optical";
                }
            } else {
                str = "speaker";
            }
            LinkedHashSet linkedHashSet = new LinkedHashSet();
            encodings = audioDeviceInfo.getEncodings();
            for (int i : encodings) {
                if (i != 2) {
                    if (i != 13) {
                        if (i != 14) {
                            if (i != 18) {
                                if (i != 19) {
                                    switch (i) {
                                        case 4:
                                            break;
                                        case 5:
                                            str2 = "ac3";
                                            break;
                                        case 6:
                                            str2 = "eac3";
                                            break;
                                        case 7:
                                            str2 = "dts";
                                            break;
                                        case 8:
                                            str2 = "dtshd";
                                            break;
                                        default:
                                            str2 = null;
                                            break;
                                    }
                                } else {
                                    str2 = "ac4";
                                }
                            } else {
                                str2 = "eac3joc";
                            }
                        } else {
                            str2 = "truehd";
                        }
                    } else {
                        str2 = "iec61937";
                    }
                    if (str2 == null) {
                        linkedHashSet.add(str2);
                    }
                }
                str2 = "pcm";
                if (str2 == null) {
                }
            }
            sb.append("audio ");
            sb.append(str);
            Iterator it = linkedHashSet.iterator();
            while (it.hasNext()) {
                String str3 = (String) it.next();
                sb.append(' ');
                sb.append(str3);
            }
            sb.append('\n');
        }
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x004d, code lost:
    
        if (r10 != false) goto L22;
     */
    /* JADX WARN: Code restructure failed: missing block: B:58:0x0186, code lost:
    
        if (r19 == false) goto L87;
     */
    /* JADX WARN: Code restructure failed: missing block: B:59:0x0188, code lost:
    
        r2 = r8.isSoftwareOnly();
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x018c, code lost:
    
        if (r2 == false) goto L87;
     */
    /* JADX WARN: Code restructure failed: missing block: B:61:0x018e, code lost:
    
        r4.add("soft");
     */
    /* JADX WARN: Code restructure failed: missing block: B:62:0x0193, code lost:
    
        if (r15 == null) goto L91;
     */
    /* JADX WARN: Code restructure failed: missing block: B:64:0x019b, code lost:
    
        if (r15.isFeatureSupported("secure-playback") == false) goto L91;
     */
    /* JADX WARN: Code restructure failed: missing block: B:65:0x019d, code lost:
    
        r4.add("secure");
     */
    /* JADX WARN: Code restructure failed: missing block: B:66:0x01a2, code lost:
    
        if (r15 == null) goto L95;
     */
    /* JADX WARN: Code restructure failed: missing block: B:68:0x01aa, code lost:
    
        if (r15.isFeatureSupported("tunneled-playback") == false) goto L95;
     */
    /* JADX WARN: Code restructure failed: missing block: B:69:0x01ac, code lost:
    
        r4.add("tunnel");
     */
    /* JADX WARN: Code restructure failed: missing block: B:70:0x01b1, code lost:
    
        r25.append("codec ");
     */
    /* JADX WARN: Code restructure failed: missing block: B:71:0x01ba, code lost:
    
        if (r8.isEncoder() == false) goto L98;
     */
    /* JADX WARN: Code restructure failed: missing block: B:72:0x01bc, code lost:
    
        r2 = "enc";
     */
    /* JADX WARN: Code restructure failed: missing block: B:73:0x01c1, code lost:
    
        r25.append(r2);
     */
    /* JADX WARN: Code restructure failed: missing block: B:74:0x01c4, code lost:
    
        if (r9 == false) goto L102;
     */
    /* JADX WARN: Code restructure failed: missing block: B:75:0x01c6, code lost:
    
        r2 = " hw ";
     */
    /* JADX WARN: Code restructure failed: missing block: B:76:0x01cb, code lost:
    
        r25.append(r2);
        r25.append(r8.getName());
        r25.append(' ');
        r25.append(r13);
        r25.append(' ');
        r25.append(r1);
        r25.append(' ');
     */
    /* JADX WARN: Code restructure failed: missing block: B:77:0x01ea, code lost:
    
        if (r4.isEmpty() == false) goto L106;
     */
    /* JADX WARN: Code restructure failed: missing block: B:79:0x021b, code lost:
    
        r25.append(r16);
        r25.append('\n');
        r12 = r12 + 1;
        r2 = r19;
        r3 = r20;
        r6 = r24;
     */
    /* JADX WARN: Code restructure failed: missing block: B:80:0x01ef, code lost:
    
        r1 = new java.lang.StringBuilder();
        r2 = r4.iterator();
     */
    /* JADX WARN: Code restructure failed: missing block: B:82:0x01fc, code lost:
    
        if (r2.hasNext() == false) goto L123;
     */
    /* JADX WARN: Code restructure failed: missing block: B:83:0x01fe, code lost:
    
        r3 = (java.lang.String) r2.next();
     */
    /* JADX WARN: Code restructure failed: missing block: B:84:0x0208, code lost:
    
        if (r1.length() <= 0) goto L112;
     */
    /* JADX WARN: Code restructure failed: missing block: B:85:0x020a, code lost:
    
        r4 = ",";
     */
    /* JADX WARN: Code restructure failed: missing block: B:87:0x020f, code lost:
    
        r1.append(r4);
        r1.append(r3);
     */
    /* JADX WARN: Code restructure failed: missing block: B:88:0x020d, code lost:
    
        r4 = "";
     */
    /* JADX WARN: Code restructure failed: missing block: B:91:0x0216, code lost:
    
        r16 = r1.toString();
     */
    /* JADX WARN: Code restructure failed: missing block: B:92:0x01c9, code lost:
    
        r2 = " sw ";
     */
    /* JADX WARN: Code restructure failed: missing block: B:93:0x01bf, code lost:
    
        r2 = "dec";
     */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0063  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static void codecs(StringBuilder sb) {
        boolean z;
        boolean z2;
        MediaCodecInfo.CodecCapabilities codecCapabilities;
        String str;
        boolean z3;
        MediaCodecInfo[] mediaCodecInfoArr;
        int i;
        boolean isAlias;
        if (Build.VERSION.SDK_INT >= 29) {
            z = true;
        } else {
            z = false;
        }
        MediaCodecInfo[] codecInfos = new MediaCodecList(1).getCodecInfos();
        int length = codecInfos.length;
        int i2 = 0;
        while (i2 < length) {
            MediaCodecInfo mediaCodecInfo = codecInfos[i2];
            String lowerCase = mediaCodecInfo.getName().toLowerCase(Locale.ROOT);
            if (z) {
                z2 = mediaCodecInfo.isHardwareAccelerated();
            } else if (!lowerCase.startsWith("omx.google.") && !lowerCase.startsWith("c2.android.") && !lowerCase.contains(".sw.")) {
                z2 = true;
            } else {
                z2 = false;
            }
            if (z) {
                isAlias = mediaCodecInfo.isAlias();
            }
            String[] supportedTypes = mediaCodecInfo.getSupportedTypes();
            int length2 = supportedTypes.length;
            int i3 = 0;
            while (i3 < length2) {
                String str2 = supportedTypes[i3];
                MediaCodecInfo.VideoCapabilities videoCapabilities = null;
                try {
                    codecCapabilities = mediaCodecInfo.getCapabilitiesForType(str2);
                } catch (Exception unused) {
                    codecCapabilities = null;
                }
                if (codecCapabilities != null) {
                    videoCapabilities = codecCapabilities.getVideoCapabilities();
                }
                String str3 = "-";
                if (videoCapabilities == null) {
                    str = "-";
                } else {
                    str = videoCapabilities.getSupportedWidths().getUpper() + "x" + videoCapabilities.getSupportedHeights().getUpper();
                }
                ArrayList arrayList = new ArrayList();
                HashSet hashSet = new HashSet();
                if (codecCapabilities != null) {
                    MediaCodecInfo.CodecProfileLevel[] codecProfileLevelArr = codecCapabilities.profileLevels;
                    z3 = z;
                    if (codecProfileLevelArr != null) {
                        mediaCodecInfoArr = codecInfos;
                        int i4 = 0;
                        for (int length3 = codecProfileLevelArr.length; i4 < length3; length3 = length3) {
                            hashSet.add(Integer.valueOf(codecProfileLevelArr[i4].profile));
                            i4++;
                        }
                    } else {
                        mediaCodecInfoArr = codecInfos;
                    }
                } else {
                    z3 = z;
                    mediaCodecInfoArr = codecInfos;
                }
                String lowerCase2 = str2.toLowerCase(Locale.ROOT);
                lowerCase2.getClass();
                char c = 65535;
                switch (lowerCase2.hashCode()) {
                    case -1662735862:
                        i = length;
                        if (lowerCase2.equals("video/av01")) {
                            c = 0;
                            break;
                        }
                        break;
                    case -1662541442:
                        i = length;
                        if (lowerCase2.equals("video/hevc")) {
                            c = 1;
                            break;
                        }
                        break;
                    case 1599127257:
                        i = length;
                        if (lowerCase2.equals("video/x-vnd.on2.vp9")) {
                            c = 2;
                            break;
                        }
                        break;
                    default:
                        i = length;
                        break;
                }
                switch (c) {
                    case 0:
                        if (hashSet.contains(2) || hashSet.contains(4096) || hashSet.contains(8192)) {
                            arrayList.add("10bit");
                            break;
                        }
                        break;
                    case 1:
                        if (hashSet.contains(2)) {
                            arrayList.add("10bit");
                        }
                        if (hashSet.contains(4096)) {
                            arrayList.add("hdr10");
                        }
                        if (hashSet.contains(8192)) {
                            arrayList.add("hdr10+");
                            break;
                        }
                        break;
                    case 2:
                        if (hashSet.contains(4)) {
                            arrayList.add("10bit");
                        }
                        if (hashSet.contains(4096)) {
                            arrayList.add("hdr10");
                            break;
                        }
                        break;
                }
                while (i3 < length2) {
                }
            }
            i2++;
            z = z;
            codecInfos = codecInfos;
            length = length;
        }
    }

    public static void display(Context context, StringBuilder sb) {
        Display.HdrCapabilities hdrCapabilities;
        int[] iArr;
        Display.Mode[] supportedModes;
        int physicalWidth;
        int physicalHeight;
        float refreshRate;
        Display display = ((DisplayManager) context.getSystemService("display")).getDisplay(0);
        if (display != null) {
            hdrCapabilities = display.getHdrCapabilities();
            if (hdrCapabilities != null) {
                iArr = hdrCapabilities.getSupportedHdrTypes();
            } else {
                iArr = new int[0];
            }
            sb.append("hdr");
            for (int i : iArr) {
                if (i != 1) {
                    if (i != 2) {
                        if (i != 3) {
                            if (i == 4) {
                                sb.append(" hdr10+");
                            }
                        } else {
                            sb.append(" hlg");
                        }
                    } else {
                        sb.append(" hdr10");
                    }
                } else {
                    sb.append(" dv");
                }
            }
            sb.append('\n');
            supportedModes = display.getSupportedModes();
            for (Display.Mode mode : supportedModes) {
                sb.append("mode ");
                physicalWidth = mode.getPhysicalWidth();
                sb.append(physicalWidth);
                sb.append('x');
                physicalHeight = mode.getPhysicalHeight();
                sb.append(physicalHeight);
                sb.append('@');
                refreshRate = mode.getRefreshRate();
                sb.append(Math.round(refreshRate * 100.0f) / 100.0d);
                sb.append('\n');
            }
        }
    }

    public static void main(String[] strArr) {
        Looper.prepareMainLooper();
        Class<?> cls = Class.forName("android.app.ActivityThread");
        Context context = (Context) cls.getMethod("getSystemContext", new Class[0]).invoke(cls.getMethod("systemMain", new Class[0]).invoke(null, new Object[0]), new Object[0]);
        PrintStream printStream = System.out;
        StringBuilder sb = new StringBuilder("sdk ");
        sb.append(Build.VERSION.SDK_INT);
        sb.append(' ');
        sb.append(Build.VERSION.RELEASE);
        sb.append('\n');
        try {
            codecs(sb);
        } catch (Throwable unused) {
        }
        try {
            display(context, sb);
        } catch (Throwable unused2) {
        }
        try {
            audio(context, sb);
        } catch (Throwable unused3) {
        }
        try {
            for (FeatureInfo featureInfo : context.getPackageManager().getSystemAvailableFeatures()) {
                if (featureInfo.name != null) {
                    sb.append("feature ");
                    sb.append(featureInfo.name);
                    sb.append('\n');
                }
            }
        } catch (Throwable unused4) {
        }
        printStream.print(sb.toString());
        System.out.flush();
        System.exit(0);
    }
}
