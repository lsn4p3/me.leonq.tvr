package dev.tvremote.core;

import java.util.ArrayList;
import java.util.Set;
import kotlin.collections.CollectionsKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class SameTv$Tv {
    public final String host;
    public final String lan;
    public final String mac;
    public final String ts;

    public SameTv$Tv(String host, String str, String str2, String str3) {
        Intrinsics.checkNotNullParameter(host, "host");
        this.host = host;
        this.lan = str;
        this.ts = str2;
        this.mac = str3;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof SameTv$Tv)) {
            return false;
        }
        SameTv$Tv sameTv$Tv = (SameTv$Tv) obj;
        return Intrinsics.areEqual(this.host, sameTv$Tv.host) && Intrinsics.areEqual(this.lan, sameTv$Tv.lan) && Intrinsics.areEqual(this.ts, sameTv$Tv.ts) && Intrinsics.areEqual(this.mac, sameTv$Tv.mac);
    }

    public final Set getAddresses() {
        Set of = SetsKt.setOf((Object[]) new String[]{this.host, this.lan, this.ts});
        ArrayList arrayList = new ArrayList();
        for (Object obj : of) {
            if (((String) obj).length() > 0) {
                arrayList.add(obj);
            }
        }
        return CollectionsKt.toSet(arrayList);
    }

    public final int hashCode() {
        return this.mac.hashCode() + ((this.ts.hashCode() + ((this.lan.hashCode() + (this.host.hashCode() * 31)) * 31)) * 31);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("Tv(host=");
        sb.append(this.host);
        sb.append(", lan=");
        sb.append(this.lan);
        sb.append(", ts=");
        sb.append(this.ts);
        sb.append(", mac=");
        return Census$$ExternalSyntheticOutline0.m(sb, this.mac, ")");
    }
}
