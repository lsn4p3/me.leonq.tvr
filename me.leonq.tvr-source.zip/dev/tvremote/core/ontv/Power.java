package dev.tvremote.core.ontv;

import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.sequences.GeneratorSequence$iterator$1;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;

/* loaded from: classes.dex */
public abstract class Power {
    public static final String CMD;
    public static final List DEEP;

    static {
        List asList = ArraysKt.asList(new String[]{"secure sleep_timeout", "secure attentive_timeout", "system screen_off_timeout", "global stay_on_while_plugged_in", "global hdmi_control_auto_device_off_enabled", "global wifi_sleep_policy", "global boot_count", "secure always_on_vpn_app"});
        List listOf = MathKt.listOf(new Pair("persist.tcl.totalstrtimes", "TCL"));
        DEEP = listOf;
        CMD = Census$$ExternalSyntheticOutline0.m("cat /proc/uptime; echo \"now=$(date +%s)\"; dumpsys alarm 2>/dev/null | grep -m2 'Runtime uptime'; printf '\\043~\\043\\n'; p=$(dumpsys power 2>/dev/null); echo \"$p\" | grep -F -e mWakefulness= -e mLastWake -e mLastSleep -e mLastGlobalWake -e mLastGlobalSleep -e mIsEnabled= -e 'Low Power Standby' -e mLowPowerStandby; echo \"$p\" | sed -n '/^Wake Locks: size/,/^$/p'; printf '\\043~\\043\\n'; for k in ", CollectionsKt.joinToString$default(asList, " ", null, null, new Bloat$$ExternalSyntheticLambda1(10), 30), "; do echo \"$k=$(settings get $k)\"; done; for p in sys.boot.reason ", CollectionsKt.joinToString$default(listOf, " ", null, null, new Bloat$$ExternalSyntheticLambda1(11), 30), "; do echo \"$p=$(getprop $p)\"; done; printf '\\043~\\043\\n'; pm path com.tailscale.ipn 2>/dev/null | head -1; echo \"ts=$(pidof com.tailscale.ipn)\"; echo \"setup=$(pidof dev.tvremote.setup)\"; ip -o -4 addr show 2>/dev/null | grep -E '(tailscale|tun)[0-9]*[[:space:]]+inet 100\\.'; printf '\\043~\\043\\n'; logcat -d -v epoch 2>/dev/null | grep -F -e 'has died' -e tguard-kill -e lowmemorykiller -e lmkd | grep -E 'com.tailscale.ipn|dev.tvremote.setup' | tail -n 40; logcat -d -b events -v epoch 2>/dev/null | grep -E 'am_kill' | grep -E 'com.tailscale.ipn|dev.tvremote.setup' | tail -n 40; printf '\\043~\\043\\n'; tail -n 3000 /sdcard/Android/data/dev.tvremote.setup/files/stats/power.jsonl 2>/dev/null");
    }

    public static Long duration$shared_release(String str) {
        long j;
        GeneratorSequence$iterator$1 generatorSequence$iterator$1 = new GeneratorSequence$iterator$1(Regex.findAll$default(new Regex("(\\d+)(ms|d|h|m|s)"), str));
        boolean z = false;
        long j2 = 0;
        while (generatorSequence$iterator$1.hasNext()) {
            MatcherMatchResult matcherMatchResult = (MatcherMatchResult) generatorSequence$iterator$1.next();
            long parseLong = Long.parseLong((String) ((MatcherMatchResult$groupValues$1) matcherMatchResult.getGroupValues()).get(1));
            String str2 = (String) ((MatcherMatchResult$groupValues$1) matcherMatchResult.getGroupValues()).get(2);
            int hashCode = str2.hashCode();
            if (hashCode != 100) {
                if (hashCode != 104) {
                    if (hashCode != 109) {
                        if (hashCode == 115 && str2.equals("s")) {
                            j = 1000;
                        }
                        j = 1;
                    } else {
                        if (str2.equals("m")) {
                            j = 60000;
                        }
                        j = 1;
                    }
                } else {
                    if (str2.equals("h")) {
                        j = 3600000;
                    }
                    j = 1;
                }
            } else {
                if (str2.equals("d")) {
                    j = 86400000;
                }
                j = 1;
            }
            Long.signum(parseLong);
            j2 += parseLong * j;
            z = true;
        }
        if (z) {
            return Long.valueOf(j2);
        }
        return null;
    }

    public static String find(String pattern, String input) {
        Intrinsics.checkNotNullParameter(pattern, "pattern");
        Pattern compile = Pattern.compile(pattern, 8);
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        Intrinsics.checkNotNullParameter(input, "input");
        Matcher matcher = compile.matcher(input);
        Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
        MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, input);
        if (access$findNext != null) {
            return (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1);
        }
        return null;
    }
}
