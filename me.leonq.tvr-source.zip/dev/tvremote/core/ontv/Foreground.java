package dev.tvremote.core.ontv;

import dev.tvremote.guard.Guard$$ExternalSyntheticLambda5;
import dev.tvremote.phone.media.TalkKt$$ExternalSyntheticLambda2;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.text.Regex;

/* loaded from: classes.dex */
public final class Foreground {
    public static final Regex PKG = new Regex("u\\d+ ([\\w.]+)/");
    public volatile long at;
    public volatile String pkg = "";
    public final AtomicBoolean busy = new AtomicBoolean();

    public final String get(TalkKt$$ExternalSyntheticLambda2 talkKt$$ExternalSyntheticLambda2) {
        if (talkKt$$ExternalSyntheticLambda2 == null) {
            this.at = 0L;
            return "";
        }
        if (System.currentTimeMillis() - this.at > 3000 && this.busy.compareAndSet(false, true)) {
            Thread thread = new Thread(new Guard$$ExternalSyntheticLambda5(6, this, talkKt$$ExternalSyntheticLambda2), "foreground");
            thread.setDaemon(true);
            thread.start();
        }
        return this.pkg;
    }
}
