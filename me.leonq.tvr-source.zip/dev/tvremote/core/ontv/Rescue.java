package dev.tvremote.core.ontv;

import com.android.apksig.ApkSigner;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Diagnose;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.Pkg;
import dev.tvremote.core.manage.TvAppsApi$$ExternalSyntheticLambda1;
import dev.tvremote.core.ontv.Axml;
import dev.tvremote.core.ontv.Bloat;
import dev.tvremote.phone.MainActivity$onCreate$2;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyList;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Charsets;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class Rescue {
    public static final Rescue INSTANCE = new Object();

    public static final String access$last(String str) {
        List list;
        String[] strArr = Setup.GOOGLE;
        List split$default = StringsKt.split$default(str, new String[]{"\n"}, 0, 6);
        if (!split$default.isEmpty()) {
            ListIterator listIterator = split$default.listIterator(split$default.size());
            while (listIterator.hasPrevious()) {
                if (((String) listIterator.previous()).length() != 0) {
                    list = CollectionsKt.take(split$default, listIterator.nextIndex() + 1);
                    break;
                }
            }
        }
        list = EmptyList.INSTANCE;
        String str2 = (String) CollectionsKt.lastOrNull(list);
        if (str2 == null) {
            return "";
        }
        return str2;
    }

    public static boolean blocked(File file, String str) {
        if (file != null && str.length() > 0) {
            try {
                File file2 = new File(file, "play-protect-blocked.txt");
                if (!file2.isFile()) {
                    file2 = null;
                }
                if (file2 != null) {
                    if (MathKt.readLines$default(file2).contains(str)) {
                        return true;
                    }
                    return false;
                }
                return false;
            } catch (IOException unused) {
                return false;
            }
        }
        return false;
    }

    public static void check(File file, String str, String str2) {
        if (str2 == null) {
            if (blocked(file, str)) {
                throw new IOException("launcher:install:INSTALL_FAILED_VERIFICATION_FAILURE");
            }
            return;
        }
        if (StringsKt.contains(str2, "INSTALL_FAILED_VERIFICATION_FAILURE", false) && file != null && str.length() > 0 && !blocked(file, str)) {
            try {
                File file2 = new File(file, "play-protect-blocked.txt");
                String text = str.concat("\n");
                Charset charset = Charsets.UTF_8;
                Intrinsics.checkNotNullParameter(text, "text");
                Intrinsics.checkNotNullParameter(charset, "charset");
                FileOutputStream fileOutputStream = new FileOutputStream(file2, true);
                try {
                    MathKt.writeTextImpl(fileOutputStream, text, charset);
                    fileOutputStream.close();
                } finally {
                }
            } catch (IOException unused) {
            }
        }
    }

    public static boolean inUse(String p, Function1 sh) {
        int i;
        Intrinsics.checkNotNullParameter(sh, "sh");
        Intrinsics.checkNotNullParameter(p, "p");
        String out = (String) sh.invoke("dumpsys package " + p + " 2>/dev/null | grep -cE 'android.permission.TV_INPUT_HARDWARE| pkgFlags=.*PERSISTENT'; dumpsys wifi 2>/dev/null | grep -cE 'cname=" + p + "([ ,]|$)'; cmd package query-activities --brief -a android.settings.SETTINGS 2>/dev/null | grep -c '^ *" + p + "/'; cmd package query-activities --brief -a android.intent.action.VIEW -t vnd.android.cursor.item/channel 2>/dev/null | grep -c '^ *" + p + "/'");
        Intrinsics.checkNotNullParameter(out, "out");
        List lines = StringsKt.lines(out);
        if (!lines.isEmpty()) {
            Iterator it = lines.iterator();
            while (it.hasNext()) {
                Integer intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull(StringsKt.trim((String) it.next()).toString());
                if (intOrNull != null) {
                    i = intOrNull.intValue();
                } else {
                    i = 0;
                }
                if (i > 0) {
                    return true;
                }
            }
        }
        return false;
    }

    /* JADX WARN: Type inference failed for: r8v3, types: [java.io.OutputStream, java.io.Closeable, java.io.FilterOutputStream, dev.tvremote.core.ontv.AppCopy$CountingOut] */
    public static String make(File file, File file2, File file3, TvAppsApi$$ExternalSyntheticLambda1 tvAppsApi$$ExternalSyntheticLambda1) {
        byte[] bArr;
        String str;
        String str2;
        Enumeration<? extends ZipEntry> enumeration;
        int i;
        String str3 = "not an APK file";
        String str4 = "AndroidManifest.xml";
        try {
            ZipFile zipFile = new ZipFile(file);
            try {
                ZipEntry entry = zipFile.getEntry("AndroidManifest.xml");
                if (entry != null) {
                    try {
                        Set set = Axml.CLASS_ELEMENTS;
                        InputStream inputStream = zipFile.getInputStream(entry);
                        try {
                            Intrinsics.checkNotNull(inputStream);
                            byte[] readBytes = MathKt.readBytes(inputStream);
                            inputStream.close();
                            Diagnose.Real clone = Axml.clone(readBytes);
                            String str5 = (String) clone.bindUdp;
                            File file4 = new File(file2.getPath() + ".unsigned");
                            try {
                                try {
                                    ?? filterOutputStream = new FilterOutputStream(new BufferedOutputStream(new FileOutputStream(file4), 8192));
                                    try {
                                        ZipOutputStream zipOutputStream = new ZipOutputStream(filterOutputStream);
                                        Enumeration<? extends ZipEntry> entries = zipFile.entries();
                                        Intrinsics.checkNotNullExpressionValue(entries, "entries(...)");
                                        while (entries.hasMoreElements()) {
                                            ZipEntry nextElement = entries.nextElement();
                                            tvAppsApi$$ExternalSyntheticLambda1.invoke();
                                            String name = nextElement.getName();
                                            Intrinsics.checkNotNull(name);
                                            if (StringsKt__StringsJVMKt.startsWith(name, false, "META-INF/")) {
                                                Pattern compile = Pattern.compile(".*\\.(SF|RSA|DSA|EC)|.*/MANIFEST\\.MF", 66);
                                                Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                                                if (compile.matcher(name).matches()) {
                                                    continue;
                                                }
                                            }
                                            ZipEntry zipEntry = new ZipEntry(name);
                                            if (name.equals(str4)) {
                                                bArr = (byte[]) clone.link;
                                            } else {
                                                bArr = null;
                                            }
                                            if (nextElement.getMethod() == 0) {
                                                if (bArr == null) {
                                                    inputStream = zipFile.getInputStream(nextElement);
                                                    try {
                                                        Intrinsics.checkNotNull(inputStream);
                                                        bArr = MathKt.readBytes(inputStream);
                                                        inputStream.close();
                                                    } finally {
                                                    }
                                                }
                                                zipEntry.setMethod(0);
                                                str = str3;
                                                zipEntry.setSize(bArr.length);
                                                zipEntry.setCompressedSize(bArr.length);
                                                CRC32 crc32 = new CRC32();
                                                crc32.update(bArr);
                                                zipEntry.setCrc(crc32.getValue());
                                                if (StringsKt__StringsJVMKt.endsWith(name, false, ".so")) {
                                                    i = 4096;
                                                } else {
                                                    i = 4;
                                                }
                                                long j = i;
                                                enumeration = entries;
                                                long j2 = filterOutputStream.count + 30;
                                                Intrinsics.checkNotNullExpressionValue(name.getBytes(Charsets.UTF_8), "getBytes(...)");
                                                str2 = str4;
                                                int length = (int) ((j - (((j2 + r1.length) + 4) % j)) % j);
                                                byte[] bArr2 = new byte[length + 4];
                                                bArr2[0] = 53;
                                                bArr2[1] = -39;
                                                bArr2[2] = (byte) (length & 255);
                                                bArr2[3] = (byte) (length >> 8);
                                                zipEntry.setExtra(bArr2);
                                                zipOutputStream.putNextEntry(zipEntry);
                                                zipOutputStream.write(bArr);
                                            } else {
                                                str = str3;
                                                str2 = str4;
                                                enumeration = entries;
                                                zipEntry.setMethod(8);
                                                zipOutputStream.putNextEntry(zipEntry);
                                                if (bArr != null) {
                                                    zipOutputStream.write(bArr);
                                                } else if (!nextElement.isDirectory()) {
                                                    inputStream = zipFile.getInputStream(nextElement);
                                                    try {
                                                        Intrinsics.checkNotNull(inputStream);
                                                        MathKt.copyTo(inputStream, zipOutputStream, 8192);
                                                        inputStream.close();
                                                    } finally {
                                                        try {
                                                            throw th;
                                                        } finally {
                                                        }
                                                    }
                                                }
                                            }
                                            zipOutputStream.closeEntry();
                                            str4 = str2;
                                            str3 = str;
                                            entries = enumeration;
                                        }
                                        String str6 = str3;
                                        zipOutputStream.finish();
                                        filterOutputStream.close();
                                        tvAppsApi$$ExternalSyntheticLambda1.invoke();
                                        Pair signer = INSTANCE.signer(file3);
                                        List listOf = MathKt.listOf(new ApkSigner.SignerConfig(new ApkSigner.SignerConfig.Builder((PrivateKey) signer.first, MathKt.listOf((X509Certificate) signer.second))));
                                        if (!listOf.isEmpty()) {
                                            listOf.size();
                                            new ApkSigner(new ArrayList(listOf), 21, false, file4, file2).sign();
                                            file4.delete();
                                            if (Pkg.RE.matches(str5)) {
                                                zipFile.close();
                                                return str5;
                                            }
                                            throw new IOException(str6);
                                        }
                                        throw new IllegalArgumentException("At least one signer config must be provided");
                                    } finally {
                                    }
                                } catch (Throwable th) {
                                    file4.delete();
                                    throw th;
                                }
                            } catch (IOException e) {
                                throw e;
                            } catch (Exception e2) {
                                throw new IOException("cannot copy: manifest: " + e2.getMessage());
                            }
                        } finally {
                        }
                    } catch (Axml.Unusual e3) {
                        throw new IOException("cannot copy: manifest: " + e3.getMessage());
                    }
                } else {
                    throw new IOException("cannot copy: split");
                }
            } finally {
            }
        } catch (Exception unused) {
            throw new IOException("not an APK file");
        }
    }

    public static boolean mustKeep(String p) {
        Intrinsics.checkNotNullParameter(p, "p");
        if (!Setup.PROTECTED.matches(p) && !Bloat.KEEP.matches(p)) {
            Bloat.Extra extra = Bloat.extra;
            if (extra != null) {
                ArrayList arrayList = extra.keep;
                if (!arrayList.isEmpty()) {
                    Iterator it = arrayList.iterator();
                    while (it.hasNext()) {
                        if (((Regex) it.next()).matches(p)) {
                            return true;
                        }
                    }
                    return false;
                }
                return false;
            }
            return false;
        }
        return true;
    }

    public static void report(String kind, String about, String pkg, Map map) {
        Object obj;
        String str;
        Object obj2;
        Intrinsics.checkNotNullParameter(kind, "kind");
        Intrinsics.checkNotNullParameter(about, "about");
        Intrinsics.checkNotNullParameter(pkg, "pkg");
        if (!Census.getEnabled()) {
            return;
        }
        List split$default = StringsKt.split$default(about, new String[]{"\n"}, 0, 6);
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(split$default));
        Iterator it = split$default.iterator();
        while (it.hasNext()) {
            arrayList.add(StringsKt.trim((String) it.next()).toString());
        }
        String joinToString$default = CollectionsKt.joinToString$default(CollectionsKt.take(arrayList, 3), " / ", null, null, null, 62);
        if (3 < arrayList.size()) {
            obj = arrayList.get(3);
        } else {
            obj = "?";
        }
        String str2 = "";
        if (pkg.length() <= 0) {
            str = "";
        } else {
            str = ApkSigner$$ExternalSyntheticOutline0.m("pkg: ", pkg, "\n");
        }
        String joinToString$default2 = CollectionsKt.joinToString$default(map.entrySet(), "\n", null, null, new Bloat$$ExternalSyntheticLambda1(18), 30);
        StringBuilder sb = new StringBuilder("tv: ");
        sb.append(joinToString$default);
        sb.append(", Android ");
        sb.append(obj);
        sb.append("\n");
        String m = Census$$ExternalSyntheticOutline0.m(sb, str, joinToString$default2);
        MainActivity$onCreate$2 mainActivity$onCreate$2 = Census.store;
        if (1 >= arrayList.size()) {
            obj2 = "";
        } else {
            obj2 = arrayList.get(1);
        }
        String str3 = "Optimize " + kind + " " + obj2;
        if (pkg.length() > 0) {
            str2 = ": ".concat(pkg);
        }
        Census.crash(str3, ApkSigner$$ExternalSyntheticOutline0.m("Optimize TV ", kind, str2), m, null);
    }

    public static String restoreName(String str) {
        Pattern compile = Pattern.compile("[^A-Za-z0-9_.-]+");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        String replaceAll = compile.matcher(str).replaceAll("-");
        Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
        String trim = StringsKt.trim(replaceAll, '-');
        if (trim.length() == 0) {
            trim = "tv";
        }
        return "tv-restore-" + ((Object) trim) + ".sh";
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x0050  */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0066  */
    /* JADX WARN: Removed duplicated region for block: B:17:0x0074  */
    /* JADX WARN: Removed duplicated region for block: B:20:0x007f  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0076  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static JSONObject run$default(Function1 function1) {
        boolean z;
        String str;
        Regex regex = Foreground.PKG;
        String m13parse = Games.m13parse((String) function1.invoke("dumpsys activity activities | grep -m1 -E 'mResumedActivity|topResumedActivity'"));
        String homeOpens = new LauncherSwap(function1).homeOpens();
        String substringBefore = StringsKt.substringBefore(homeOpens, '/', homeOpens);
        String obj = StringsKt.trim((String) function1.invoke("settings get secure default_input_method")).toString();
        String substringBefore2 = StringsKt.substringBefore(obj, '/', obj);
        if (m13parse.length() > 0 && !m13parse.equals(substringBefore) && !m13parse.equals(substringBefore2)) {
            String[] strArr = Setup.GOOGLE;
            if (!mustKeep(m13parse)) {
                z = true;
                if (z) {
                    function1.invoke("am force-stop ".concat(m13parse));
                }
                function1.invoke("input keyevent 3");
                if (substringBefore.equals("dev.tvremote.home")) {
                    function1.invoke("am start -n dev.tvremote.home/.HomeActivity >/dev/null 2>&1");
                }
                JSONObject jSONObject = new JSONObject();
                if (z) {
                    str = "";
                } else {
                    str = m13parse;
                }
                JSONObject put = jSONObject.put("stopped", str);
                if (z) {
                    m13parse = "";
                }
                JSONObject put2 = put.put("kept", m13parse);
                Intrinsics.checkNotNullExpressionValue(put2, "put(...)");
                return put2;
            }
        }
        z = false;
        if (z) {
        }
        function1.invoke("input keyevent 3");
        if (substringBefore.equals("dev.tvremote.home")) {
        }
        JSONObject jSONObject2 = new JSONObject();
        if (z) {
        }
        JSONObject put3 = jSONObject2.put("stopped", str);
        if (z) {
        }
        JSONObject put22 = put3.put("kept", m13parse);
        Intrinsics.checkNotNullExpressionValue(put22, "put(...)");
        return put22;
    }

    public synchronized String install(Adb a, byte[] bytes) {
        String str;
        try {
            Intrinsics.checkNotNullParameter(a, "a");
            Intrinsics.checkNotNullParameter(bytes, "bytes");
            CRC32 crc32 = new CRC32();
            crc32.update(bytes);
            long value = crc32.getValue();
            MathKt.checkRadix(16);
            String l = Long.toString(value, 16);
            Intrinsics.checkNotNullExpressionValue(l, "toString(...)");
            str = "/data/local/tmp/tvr-helper-" + l + ".jar";
            String str2 = "[ -f " + str + " ] && echo y";
            ConcurrentHashMap concurrentHashMap = Adb.ASKING;
            if (!Intrinsics.areEqual(StringsKt.trim(a.shell(120000L, str2)).toString(), "y")) {
                a.shell(120000L, "find /data/local/tmp -maxdepth 1 \\( -name 'tvr-meta*.apk' -o -name 'tvr-helper-*.jar' \\) -mtime +3 -delete 2>/dev/null; rm -f /data/local/tmp/tvr-meta.apk");
                a.put(str + ".part", bytes, false);
                String valueOf = String.valueOf(bytes.length);
                for (int i = 0; i < 40; i++) {
                    if (Intrinsics.areEqual(StringsKt.trim(a.shell(120000L, "wc -c < " + str + ".part")).toString(), valueOf)) {
                        break;
                    }
                    Thread.sleep(150L);
                }
                a.shell(120000L, "mv " + str + ".part " + str);
            }
        } catch (Throwable th) {
            throw th;
        }
        return str;
    }

    public synchronized Pair signer(File file) {
        FileInputStream fileInputStream;
        try {
            if (file == null) {
                file = new File(System.getProperty("java.io.tmpdir"), "tvr-appcopy");
            }
            File file2 = new File(file, "appcopy.key");
            File parentFile = file2.getParentFile();
            if (parentFile != null) {
                parentFile.mkdirs();
            }
            File file3 = new File(file2.getParentFile(), "appcopy.crt");
            CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
            if (file2.isFile() && file3.isFile()) {
                try {
                    PrivateKey generatePrivate = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(MathKt.readBytes(file2)));
                    fileInputStream = new FileInputStream(file3);
                    try {
                        Certificate generateCertificate = certificateFactory.generateCertificate(fileInputStream);
                        Intrinsics.checkNotNull(generateCertificate, "null cannot be cast to non-null type java.security.cert.X509Certificate");
                        X509Certificate x509Certificate = (X509Certificate) generateCertificate;
                        fileInputStream.close();
                        return new Pair(generatePrivate, x509Certificate);
                    } finally {
                    }
                } catch (Exception unused) {
                }
            }
            KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
            keyPairGenerator.initialize(2048);
            KeyPair generateKeyPair = keyPairGenerator.generateKeyPair();
            byte[] encoded = generateKeyPair.getPublic().getEncoded();
            Intrinsics.checkNotNullExpressionValue(encoded, "getEncoded(...)");
            PrivateKey privateKey = generateKeyPair.getPrivate();
            Intrinsics.checkNotNullExpressionValue(privateKey, "getPrivate(...)");
            byte[] certificate = Fleet.certificate(privateKey, encoded, "TV Remote app copy");
            byte[] encoded2 = generateKeyPair.getPrivate().getEncoded();
            Intrinsics.checkNotNullExpressionValue(encoded2, "getEncoded(...)");
            MathKt.writeBytes(file2, encoded2);
            MathKt.writeBytes(file3, certificate);
            file2.setReadable(false, false);
            file2.setReadable(true, true);
            PrivateKey privateKey2 = generateKeyPair.getPrivate();
            fileInputStream = new FileInputStream(file3);
            try {
                Certificate generateCertificate2 = certificateFactory.generateCertificate(fileInputStream);
                Intrinsics.checkNotNull(generateCertificate2, "null cannot be cast to non-null type java.security.cert.X509Certificate");
                X509Certificate x509Certificate2 = (X509Certificate) generateCertificate2;
                fileInputStream.close();
                return new Pair(privateKey2, x509Certificate2);
            } finally {
            }
        } catch (Throwable th) {
            throw th;
        }
    }
}
