package dev.tvremote.core.ontv;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.B64;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet$$ExternalSyntheticLambda0;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.Mdns;
import dev.tvremote.core.manage.HomeApi$$ExternalSyntheticLambda16;
import dev.tvremote.core.manage.HomeApi$$ExternalSyntheticLambda4;
import dev.tvremote.core.scenes.Voice;
import dev.tvremote.home.HomeConfig;
import dev.tvremote.home.LinkUrl;
import dev.tvremote.home.Target;
import dev.tvremote.phone.media.TalkKt$$ExternalSyntheticLambda2;
import dev.tvremote.update.Release;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyList;
import kotlin.collections.EmptyMap;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgressionIterator;
import kotlin.ranges.IntRange;
import kotlin.sequences.FilteringSequence;
import kotlin.sequences.FilteringSequence$iterator$1;
import kotlin.sequences.SequencesKt;
import kotlin.text.Charsets;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public abstract class Home {
    public static volatile Triple checked;
    public static volatile boolean unasked;
    public static final Regex PIN_KEY = new Regex("^pin:[A-Za-z][\\w.]*/[\\w.:@+=,~-]{1,200}$");
    public static final Regex YT_HOST = new Regex("^(www\\.|m\\.|music\\.)?(youtube\\.com|youtu\\.be)$");
    public static final Regex PKG = new Regex("^[A-Za-z][\\w.]{0,150}$");
    public static final Regex NOT_YT = new Regex("frameworkpackagestubs|downloader|\\.browser|chrome|firefox|puffin|silk|opera|tvbro|webview");

    public static JSONObject appPic(Adb adb, String str, byte[] bArr) {
        if (Target.kind(str) != null && !HomeConfig.isLive(str) && !HomeConfig.isFolder(str)) {
            if (bArr.length >= 4 && bArr.length <= 300000 && bArr[0] == -1 && bArr[1] == -40) {
                Fleet$$ExternalSyntheticLambda0 fleet$$ExternalSyntheticLambda0 = new Fleet$$ExternalSyntheticLambda0(adb, 6);
                JSONObject call = call("", fleet$$ExternalSyntheticLambda0, null);
                if (call.optBoolean("installed")) {
                    JSONObject optJSONObject = call.optJSONObject("config");
                    if (optJSONObject == null) {
                        optJSONObject = new JSONObject();
                    }
                    if (optJSONObject.has("pics")) {
                        JSONObject optJSONObject2 = optJSONObject.optJSONObject("pics");
                        if (optJSONObject2 == null) {
                            optJSONObject2 = new JSONObject();
                        }
                        if (!optJSONObject2.has(str) && optJSONObject2.length() >= 40) {
                            throw new IOException("home:pic_full");
                        }
                        String format = String.format("%08x", Arrays.copyOf(new Object[]{Integer.valueOf(new SecureRandom().nextInt())}, 1));
                        String str2 = StringsKt.substringBeforeLast("/sdcard/Android/data/dev.tvremote.home/files/wall.jpg", '/', "/sdcard/Android/data/dev.tvremote.home/files/wall.jpg") + "/pics/" + format + ".jpg";
                        fleet$$ExternalSyntheticLambda0.invoke("mkdir -p ".concat(StringsKt.substringBeforeLast(str2, '/', str2)));
                        if (adb.put(str2, bArr, true)) {
                            return call("", fleet$$ExternalSyntheticLambda0, new JSONObject().put("pics", new JSONObject(optJSONObject2.toString()).put(str, format)));
                        }
                        throw new IOException("home:photo");
                    }
                    throw new IOException("home:pic_old");
                }
                throw new IOException("home:missing");
            }
            throw new IllegalArgumentException("pic image");
        }
        throw new IllegalArgumentException("pic target");
    }

    public static JSONObject call(String extra, Function1 function1, JSONObject jSONObject) {
        String concat;
        String str;
        Intrinsics.checkNotNullParameter(extra, "extra");
        String str2 = "";
        if (jSONObject == null) {
            concat = "";
        } else {
            int[] iArr = B64.INDEX;
            JSONObject forward = HomeConfig.forward(jSONObject);
            JSONObject jSONObject2 = new JSONObject();
            Iterator<String> keys = jSONObject.keys();
            Intrinsics.checkNotNullExpressionValue(keys, "keys(...)");
            while (keys.hasNext()) {
                String next = keys.next();
                if (forward.has(next)) {
                    jSONObject2.put(next, forward.get(next));
                }
            }
            String jSONObject3 = jSONObject2.toString();
            Intrinsics.checkNotNullExpressionValue(jSONObject3, "toString(...)");
            byte[] bytes = jSONObject3.getBytes(Charsets.UTF_8);
            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
            concat = " --es set ".concat(B64.encode(bytes));
        }
        String m = ApkSigner$$ExternalSyntheticOutline0.m(" ", extra, concat);
        if (jSONObject == null || !jSONObject.optBoolean("dream")) {
            str = "";
        } else {
            str = "pm grant dev.tvremote.home android.permission.WRITE_SECURE_SETTINGS 2>&1; ";
        }
        if (jSONObject != null) {
            str2 = "pm grant dev.tvremote.home android.permission.ACCESS_FINE_LOCATION >/dev/null 2>&1; pm grant dev.tvremote.home android.permission.BLUETOOTH_CONNECT >/dev/null 2>&1; pm grant dev.tvremote.home android.permission.READ_TV_LISTINGS >/dev/null 2>&1; pm grant dev.tvremote.home android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1; ";
        }
        String str3 = (String) function1.invoke(str + str2 + "am broadcast --include-stopped-packages -n dev.tvremote.home/.HomeReceiver" + m + " 2>&1; echo '#~#'; p=$(cmd role get-role-holders android.app.role.HOME 2>/dev/null); c=$([ -n \"$p\" ] && cmd package query-activities --brief -a android.intent.action.MAIN -c android.intent.category.HOME 2>/dev/null | grep -m1 \"^ *$p/\"); if [ -n \"$c\" ]; then echo $c; else cmd package resolve-activity --brief -c android.intent.category.HOME -a android.intent.action.MAIN; fi");
        Matcher m7m = Census$$ExternalSyntheticOutline0.m7m("data=\"([A-Za-z0-9+/=]+)\"", "compile(...)", str3, "input", str3);
        Intrinsics.checkNotNullExpressionValue(m7m, "matcher(...)");
        MatcherMatchResult access$findNext = MathKt.access$findNext(m7m, 0, str3);
        if (access$findNext == null) {
            JSONObject put = new JSONObject().put("installed", false);
            Intrinsics.checkNotNullExpressionValue(put, "put(...)");
            return put;
        }
        int[] iArr2 = B64.INDEX;
        JSONObject jSONObject4 = new JSONObject(new String(B64.decode((String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)), Charsets.UTF_8));
        if (!jSONObject4.has("error")) {
            jSONObject4.put("installed", true).put("home", StringsKt.contains(StringsKt.substringAfter(str3, "#~#", str3), "dev.tvremote.home/", false));
            String optString = jSONObject4.optString("version");
            Intrinsics.checkNotNullExpressionValue(optString, "optString(...)");
            Release latest = latest(optString);
            if (latest != null) {
                jSONObject4.put("latest", latest.version);
            }
            if (unasked) {
                jSONObject4.put("offline", true);
            }
            return jSONObject4;
        }
        throw new IOException(jSONObject4.optString("error"));
    }

    public static Release latest(String str) {
        unasked = false;
        Triple triple = checked;
        if (triple != null) {
            long longValue = ((Number) triple.first).longValue();
            String str2 = (String) triple.second;
            Release release = (Release) triple.third;
            if (Intrinsics.areEqual(str2, str) && System.currentTimeMillis() - longValue < 21600000) {
                return release;
            }
        }
        try {
            List list = Release.KEYS;
            Release newer = MathKt.newer(str, "home", "tv-home.apk");
            checked = new Triple(Long.valueOf(System.currentTimeMillis()), str, newer);
            return newer;
        } catch (Exception unused) {
            unasked = true;
            return null;
        }
    }

    public static String mediaPath(String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        if (HomeConfig.isPhoto(id)) {
            return HomeConfig.photoPath(id);
        }
        if (HomeConfig.isVideo(id)) {
            return StringsKt.substringBeforeLast("/sdcard/Android/data/dev.tvremote.home/files/videos/in", '/', "/sdcard/Android/data/dev.tvremote.home/files/videos/in") + "/" + StringsKt.removePrefix(id, "vid:") + ".mp4";
        }
        return null;
    }

    public static Map names(JSONObject jSONObject) {
        JSONObject optJSONObject;
        if (jSONObject != null && (optJSONObject = jSONObject.optJSONObject("names")) != null) {
            Iterator<String> keys = optJSONObject.keys();
            Intrinsics.checkNotNullExpressionValue(keys, "keys(...)");
            FilteringSequence mapNotNull = SequencesKt.mapNotNull(SequencesKt.asSequence(keys), new Home$$ExternalSyntheticLambda6(optJSONObject, 0));
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            FilteringSequence$iterator$1 filteringSequence$iterator$1 = new FilteringSequence$iterator$1(mapNotNull);
            while (filteringSequence$iterator$1.hasNext()) {
                Pair pair = (Pair) filteringSequence$iterator$1.next();
                linkedHashMap.put(pair.first, pair.second);
            }
            int size = linkedHashMap.size();
            if (size != 0) {
                if (size == 1) {
                    Map.Entry entry = (Map.Entry) linkedHashMap.entrySet().iterator().next();
                    Map singletonMap = Collections.singletonMap(entry.getKey(), entry.getValue());
                    Intrinsics.checkNotNullExpressionValue(singletonMap, "with(...)");
                    return singletonMap;
                }
                return linkedHashMap;
            }
            return EmptyMap.INSTANCE;
        }
        return EmptyMap.INSTANCE;
    }

    public static void openPin(String str, Function1 function1) {
        if (PIN_KEY.matches(str)) {
            ConcurrentHashMap concurrentHashMap = Adb.ASKING;
            if (!StringsKt.contains((String) function1.invoke("am start -n dev.tvremote.home/.OpenActivity --es t " + Mdns.q(str) + " 2>&1"), "Error", false)) {
                return;
            } else {
                throw new IOException("home:missing");
            }
        }
        throw new IOException("pin_bad_link");
    }

    public static JSONObject ownConfig(Function1 function1) {
        Pattern compile = Pattern.compile("data=\"([A-Za-z0-9+/=]+)\"");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        CharSequence input = (CharSequence) function1.invoke("am broadcast --include-stopped-packages -n dev.tvremote.home/.HomeReceiver 2>&1");
        Intrinsics.checkNotNullParameter(input, "input");
        Matcher matcher = compile.matcher(input);
        Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
        MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, input);
        if (access$findNext == null) {
            return null;
        }
        int[] iArr = B64.INDEX;
        JSONObject optJSONObject = new JSONObject(new String(B64.decode((String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)), Charsets.UTF_8)).optJSONObject("config");
        if (optJSONObject == null) {
            return new JSONObject();
        }
        return optJSONObject;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [kotlin.collections.EmptyList] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v9, types: [java.util.ArrayList] */
    public static List ownPins(TalkKt$$ExternalSyntheticLambda2 talkKt$$ExternalSyntheticLambda2) {
        JSONArray optJSONArray;
        Pattern compile = Pattern.compile("data=\"([A-Za-z0-9+/=]+)\"");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        CharSequence charSequence = (CharSequence) talkKt$$ExternalSyntheticLambda2.invoke("am broadcast --include-stopped-packages -n dev.tvremote.home/.HomeReceiver 2>&1");
        Matcher matcher = compile.matcher(charSequence);
        Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
        MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, charSequence);
        ?? r0 = EmptyList.INSTANCE;
        if (access$findNext != null) {
            int[] iArr = B64.INDEX;
            JSONObject optJSONObject = new JSONObject(new String(B64.decode((String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)), Charsets.UTF_8)).optJSONObject("config");
            if (optJSONObject != null && (optJSONArray = optJSONObject.optJSONArray("pinned")) != null) {
                IntRange until = MathKt.until(0, optJSONArray.length());
                ArrayList arrayList = new ArrayList();
                Iterator it = until.iterator();
                while (((IntProgressionIterator) it).hasNext) {
                    JSONObject optJSONObject2 = optJSONArray.optJSONObject(((IntProgressionIterator) it).nextInt());
                    if (optJSONObject2 != null) {
                        arrayList.add(optJSONObject2);
                    }
                }
                ArrayList arrayList2 = new ArrayList();
                Iterator it2 = arrayList.iterator();
                while (it2.hasNext()) {
                    Object next = it2.next();
                    JSONObject jSONObject = (JSONObject) next;
                    String optString = jSONObject.optString("key");
                    Intrinsics.checkNotNullExpressionValue(optString, "optString(...)");
                    if (StringsKt__StringsJVMKt.startsWith(optString, false, "pin:")) {
                        String optString2 = jSONObject.optString("title");
                        Intrinsics.checkNotNullExpressionValue(optString2, "optString(...)");
                        if (!StringsKt.isBlank(optString2)) {
                            arrayList2.add(next);
                        }
                    }
                }
                r0 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList2));
                Iterator it3 = arrayList2.iterator();
                while (it3.hasNext()) {
                    JSONObject jSONObject2 = (JSONObject) it3.next();
                    String string = jSONObject2.getString("key");
                    Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                    String string2 = jSONObject2.getString("title");
                    Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
                    String optString3 = jSONObject2.optString("app");
                    Intrinsics.checkNotNullExpressionValue(optString3, "optString(...)");
                    String optString4 = jSONObject2.optString("link");
                    if (StringsKt.isBlank(optString4)) {
                        optString4 = null;
                    }
                    r0.add(new Voice.PinRef(string, string2, optString3, optString4));
                }
            }
        }
        return r0;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r7v3, types: [kotlin.collections.EmptyList] */
    /* JADX WARN: Type inference failed for: r7v4, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r7v5, types: [java.util.ArrayList] */
    public static JSONObject photo(Adb adb, byte[] bArr) {
        ArrayList arrayList;
        Object obj;
        Collection plus;
        Fleet$$ExternalSyntheticLambda0 fleet$$ExternalSyntheticLambda0 = new Fleet$$ExternalSyntheticLambda0(adb, 7);
        JSONObject call = call("", fleet$$ExternalSyntheticLambda0, null);
        if (call.optBoolean("installed")) {
            JSONObject optJSONObject = call.optJSONObject("config");
            if (optJSONObject == null) {
                optJSONObject = new JSONObject();
            }
            if (!optJSONObject.optBoolean("wrotate")) {
                if (adb.put("/sdcard/Android/data/dev.tvremote.home/files/wall.jpg", bArr, true)) {
                    return call("", fleet$$ExternalSyntheticLambda0, Census$$ExternalSyntheticOutline0.m8m("wall", "photo").put("photo", System.currentTimeMillis()));
                }
                throw new IOException("home:photo");
            }
            JSONArray optJSONArray = call.optJSONArray("photos");
            ?? r7 = EmptyList.INSTANCE;
            if (optJSONArray != null) {
                IntRange until = MathKt.until(0, optJSONArray.length());
                arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until));
                Iterator it = until.iterator();
                while (((IntProgressionIterator) it).hasNext) {
                    arrayList.add(optJSONArray.getJSONObject(((IntProgressionIterator) it).nextInt()).optString("id"));
                }
            } else {
                arrayList = r7;
            }
            Iterator it2 = HomeConfig.PHOTOS.iterator();
            while (true) {
                if (it2.hasNext()) {
                    Object next = it2.next();
                    if (!arrayList.contains((String) next)) {
                        obj = next;
                        break;
                    }
                } else {
                    obj = null;
                    break;
                }
            }
            String str = (String) obj;
            if (str != null) {
                if (adb.put(HomeConfig.photoPath(str), bArr, true)) {
                    JSONArray optJSONArray2 = optJSONObject.optJSONArray("walls");
                    if (optJSONArray2 != null) {
                        int length = optJSONArray2.length();
                        r7 = new ArrayList(length);
                        for (int i = 0; i < length; i++) {
                            r7.add(optJSONArray2.getString(i));
                        }
                    }
                    if (Intrinsics.areEqual(optJSONObject.optString("wevery", "off"), "off")) {
                        plus = MathKt.listOf(str);
                    } else {
                        plus = CollectionsKt.plus((List) r7, str);
                    }
                    return call("", fleet$$ExternalSyntheticLambda0, new JSONObject().put("walls", new JSONArray(plus)).put("wall", str).put("photo", System.currentTimeMillis()));
                }
                throw new IOException("home:photo");
            }
            throw new IOException("home:photos_full");
        }
        throw new IOException("home:missing");
    }

    public static JSONObject pin(HomeApi$$ExternalSyntheticLambda4 homeApi$$ExternalSyntheticLambda4, JSONObject jSONObject) {
        JSONObject optJSONObject;
        JSONObject optJSONObject2;
        Set set = LinkUrl.BANNED;
        String clean = LinkUrl.clean(jSONObject.optString("url"));
        if (clean != null) {
            JSONObject m8m = Census$$ExternalSyntheticOutline0.m8m("url", clean);
            String optString = jSONObject.optString("pkg");
            Intrinsics.checkNotNull(optString);
            if (PKG.matches(optString)) {
                m8m.put("pkg", optString);
            }
            String optString2 = jSONObject.optString("name");
            Intrinsics.checkNotNullExpressionValue(optString2, "optString(...)");
            String take = StringsKt.take(StringsKt.trim(optString2).toString(), 120);
            if (take.length() > 0) {
                m8m.put("name", take);
            }
            String optString3 = jSONObject.optString("img");
            Intrinsics.checkNotNull(optString3);
            if (StringsKt__StringsJVMKt.startsWith(optString3, false, "https://") && optString3.length() < 400) {
                m8m.put("img", optString3);
            }
            int[] iArr = B64.INDEX;
            String jSONObject2 = m8m.toString();
            Intrinsics.checkNotNullExpressionValue(jSONObject2, "toString(...)");
            byte[] bytes = jSONObject2.getBytes(Charsets.UTF_8);
            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
            JSONObject call = call("--es pin ".concat(B64.encode(bytes)), homeApi$$ExternalSyntheticLambda4, null);
            if (call.optBoolean("installed")) {
                if (!call.optBoolean("pinOk") && ((optJSONObject2 = call.optJSONObject("config")) == null || !optJSONObject2.optBoolean("pinOk"))) {
                    throw new IOException("home:pin_old");
                }
                if (youtubeUrl(clean) == null && !call.optBoolean("linkOk") && ((optJSONObject = call.optJSONObject("config")) == null || !optJSONObject.optBoolean("linkOk"))) {
                    throw new IOException("home:pin_old");
                }
                return call;
            }
            throw new IOException("home:missing");
        }
        throw new IOException("pin_bad_link");
    }

    public static List queryPackages$shared_release(String str) {
        List lines = StringsKt.lines(str);
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(lines));
        Iterator it = lines.iterator();
        while (it.hasNext()) {
            arrayList.add(StringsKt.trim((String) it.next()).toString());
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator it2 = arrayList.iterator();
        while (it2.hasNext()) {
            Object next = it2.next();
            String input = (String) next;
            Pattern compile = Pattern.compile("^[A-Za-z][\\w.]*/\\S+$");
            Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
            Intrinsics.checkNotNullParameter(input, "input");
            if (compile.matcher(input).matches()) {
                arrayList2.add(next);
            }
        }
        ArrayList arrayList3 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList2));
        Iterator it3 = arrayList2.iterator();
        while (it3.hasNext()) {
            String str2 = (String) it3.next();
            arrayList3.add(StringsKt.substringBefore(str2, '/', str2));
        }
        return CollectionsKt.distinct(arrayList3);
    }

    public static JSONObject video(Adb adb, String str, long j, HomeApi$$ExternalSyntheticLambda16 homeApi$$ExternalSyntheticLambda16) {
        String lowerCase = StringsKt.substringAfterLast(str, '.', "").toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        if (HomeConfig.VIDEO_EXT.contains(lowerCase)) {
            if (j > 0 && j <= 209715200) {
                Fleet$$ExternalSyntheticLambda0 fleet$$ExternalSyntheticLambda0 = new Fleet$$ExternalSyntheticLambda0(adb, 9);
                JSONObject call = call("", fleet$$ExternalSyntheticLambda0, null);
                if (call.optBoolean("installed")) {
                    if (call.optJSONObject("video") != null) {
                        JSONObject optJSONObject = call.optJSONObject("video");
                        Intrinsics.checkNotNull(optJSONObject);
                        if (optJSONObject.optLong("free") >= (2 * j) + 104857600) {
                            long currentTimeMillis = System.currentTimeMillis();
                            MathKt.checkRadix(36);
                            String l = Long.toString(currentTimeMillis, 36);
                            Intrinsics.checkNotNullExpressionValue(l, "toString(...)");
                            String m = Census$$ExternalSyntheticOutline0.m("in", l, ".", lowerCase);
                            fleet$$ExternalSyntheticLambda0.invoke("mkdir -p /sdcard/Android/data/dev.tvremote.home/files/videos/in");
                            if (adb.put("/sdcard/Android/data/dev.tvremote.home/files/videos/in/" + m, j, true, null, homeApi$$ExternalSyntheticLambda16)) {
                                int[] iArr = B64.INDEX;
                                byte[] bytes = str.getBytes(Charsets.UTF_8);
                                Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                                return call(Census$$ExternalSyntheticOutline0.m("--es addvideo ", m, " --es vname ", B64.encode(bytes)), fleet$$ExternalSyntheticLambda0, null);
                            }
                            throw new IOException("home:video");
                        }
                        throw new IOException("home:video_space");
                    }
                    throw new IOException("home:video_old");
                }
                throw new IOException("home:missing");
            }
            throw new IllegalArgumentException("video size");
        }
        throw new IllegalArgumentException("video type");
    }

    public static String youtubeUrl(String str) {
        if (str == null) {
            str = "";
        }
        String input = StringsKt.trim(str).toString();
        Pattern compile = Pattern.compile("^https://([^/?#:@]+)(/\\S*)?$", 66);
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        Intrinsics.checkNotNullParameter(input, "input");
        Matcher matcher = compile.matcher(input);
        Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
        MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, input);
        if (access$findNext != null) {
            String lowerCase = ((String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)).toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
            if (YT_HOST.matches(lowerCase)) {
                return input;
            }
            return null;
        }
        return null;
    }
}
