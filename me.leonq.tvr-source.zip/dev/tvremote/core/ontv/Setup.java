package dev.tvremote.core.ontv;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticLambda4;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet$$ExternalSyntheticLambda0;
import dev.tvremote.core.Words;
import dev.tvremote.core.Words$$ExternalSyntheticLambda1;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.adb.PmInstall;
import dev.tvremote.core.manage.SetupApi$$ExternalSyntheticLambda0;
import dev.tvremote.core.ontv.Bloat;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyList;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class Setup {
    public String about;
    public final Adb adb0;
    public final File dir;
    public final Setup$$ExternalSyntheticLambda5 fresh;
    public final String lang;
    public String opened;
    public final Bloat$$ExternalSyntheticLambda1 pause;
    public String refused;
    public final Function1 sh;
    public String via;
    public static final String[] GOOGLE = {"com.google.android.play.games", "com.google.android.videos", "com.google.android.youtube.tvmusic"};
    public static final String[] SONY = {"com.sony.dtv.b2b.vendorprotocol", "com.sony.dtv.b2b.rs232csupport", "com.sony.dtv.b2b.hotelmode", "com.sony.dtv.b2b.prosettings", "com.sony.dtv.b2b.importexport", "com.sony.dtv.b2b.noderuntime.normal", "com.sony.dtv.b2b.noderuntime.privilege", "com.sony.dtv.b2b.webappruntimedrm", "com.sony.dtv.demomode", "com.sony.dtv.demosupport", "com.sony.dtv.multiscreendemo", "com.sony.dtv.sonyselect", "tv.samba.ssm"};
    public static final String[] LAUNCHER = {"com.google.android.tvrecommendations", "com.google.android.tvlauncher", "com.google.android.apps.tv.launcherx", "com.google.android.leanbacklauncher", "com.mitv.tvhome"};
    public static final String[] WIZARD = {"com.google.android.tungsten.setupwraith"};
    public static final Object NAMES = MapsKt__MapsKt.mapOf(new Pair("com.google.android.play.games", "Google Play Games"), new Pair("com.google.android.videos", "Google Play Movies & TV"), new Pair("com.google.android.youtube.tvmusic", "YouTube Music"), new Pair("com.sony.dtv.b2b.vendorprotocol", "Sony B2B vendor protocol"), new Pair("com.sony.dtv.b2b.rs232csupport", "Sony B2B RS-232C"), new Pair("com.sony.dtv.b2b.hotelmode", "Sony Hotel mode"), new Pair("com.sony.dtv.b2b.prosettings", "Sony Pro settings"), new Pair("com.sony.dtv.b2b.importexport", "Sony B2B import/export"), new Pair("com.sony.dtv.b2b.noderuntime.normal", "Sony B2B runtime"), new Pair("com.sony.dtv.b2b.noderuntime.privilege", "Sony B2B runtime (privileged)"), new Pair("com.sony.dtv.b2b.webappruntimedrm", "Sony B2B web app DRM"), new Pair("com.sony.dtv.demomode", "Sony Demo mode"), new Pair("com.sony.dtv.demosupport", "Sony Demo support"), new Pair("com.sony.dtv.multiscreendemo", "Sony Multi-screen demo"), new Pair("com.sony.dtv.sonyselect", "Sony Select"), new Pair("tv.samba.ssm", "Samba TV"));
    public static final Regex PROTECTED = new Regex("android|android\\.ext\\.(services|shared)|com\\.android\\.(systemui|settings|tv\\.settings|shell|phone|bluetooth|providers\\..*|packageinstaller|permissioncontroller|inputmethod.*|networkstack.*|vending|ext\\.services|ext\\.shared|modulemetadata|provision|tv\\.provision|managedprovisioning|inputdevices|location\\.fused|externalstorage|keychain|se)|com\\.dolby\\.android\\.audio\\.service|com\\.google\\.android\\.(gms|gsf|packageinstaller|permissioncontroller|tvlauncher|tvrecommendations|leanbacklauncher.*|inputmethod.*|tv\\.remote\\.service|katniss|apps\\.tv\\.launcherx|tungsten\\.setupwraith|leanback\\.ime|onetimeinitializer|partnersetup|ext\\.services|ext\\.shared|modulemetadata|overlay\\.modules.*)|dev\\.tvremote\\.setup(\\.keys)?|com\\.tailscale\\.ipn");
    public static final Regex PERMS_FIXED = new Regex("android|com\\.android\\.(?!inputmethod).*|com\\.google\\.android\\.(gms|gsf|packageinstaller|permissioncontroller|ext\\..*|modulemetadata)|dev\\.tvremote\\..*|com\\.tailscale\\.ipn");
    public static final Regex SAFE = new Regex("[A-Za-z][\\w]*(\\.[\\w]+)+(/[\\w.$]+)?");
    public static final Regex DEAD = new Regex("Failure calling service|Can't find service|DeadObjectException|DeadSystemException");

    /* loaded from: classes.dex */
    public final class Choice {
        public final boolean anim;
        public final ArrayList disable;
        public final boolean home;

        public Choice(boolean z, boolean z2, ArrayList arrayList) {
            this.anim = z;
            this.home = z2;
            this.disable = arrayList;
        }
    }

    /* loaded from: classes.dex */
    public interface Log {
    }

    /* loaded from: classes.dex */
    public final class Stopped extends IOException {
        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public Stopped(String msg, String str) {
            super(msg);
            Intrinsics.checkNotNullParameter(msg, "msg");
        }
    }

    public Setup(Adb adb, File file, String lang, Function1 function1, Setup$$ExternalSyntheticLambda5 setup$$ExternalSyntheticLambda5, Log log) {
        Intrinsics.checkNotNullParameter(lang, "lang");
        this.adb0 = adb;
        this.dir = file;
        this.lang = lang;
        this.sh = function1;
        this.fresh = setup$$ExternalSyntheticLambda5;
        this.pause = new Bloat$$ExternalSyntheticLambda1(16);
        this.about = "";
        this.refused = "";
        this.via = "";
        this.opened = "";
    }

    public static final String keyboard$whole(String str) {
        String substringBefore = StringsKt.substringBefore(str, '/', str);
        String substringAfter = StringsKt.substringAfter(str, '/', str);
        if (StringsKt__StringsJVMKt.startsWith(substringAfter, false, ".")) {
            substringAfter = StringsKt.substringBefore(str, '/', str).concat(substringAfter);
        }
        return substringBefore + "/" + ((Object) substringAfter);
    }

    /* JADX WARN: Type inference failed for: r8v4, types: [java.util.Map, java.lang.Object] */
    public static final JSONObject plan$item(SetupApi$$ExternalSyntheticLambda0 setupApi$$ExternalSyntheticLambda0, String str) {
        String str2;
        JSONObject m8m = Census$$ExternalSyntheticOutline0.m8m("pkg", str);
        String str3 = (String) Bloat.suggest().get(str);
        if (str3 == null && (str3 = (String) setupApi$$ExternalSyntheticLambda0.invoke(str)) == null && (str3 = (String) NAMES.get(str)) == null) {
            List split$default = StringsKt.split$default(str, new char[]{'.'});
            if (((String) CollectionsKt.last(split$default)).length() <= 3 && split$default.size() > 1) {
                str2 = CollectionsKt.joinToString$default(CollectionsKt.takeLast(2, split$default), ".", null, null, null, 62);
            } else {
                str2 = (String) CollectionsKt.last(split$default);
            }
            str3 = str2;
        }
        return m8m.put("label", str3);
    }

    public static ArrayList suggested() {
        String[] strArr = GOOGLE;
        String[] strArr2 = SONY;
        Object[] copyOf = Arrays.copyOf(strArr, 16);
        System.arraycopy(strArr2, 0, copyOf, 3, 13);
        Intrinsics.checkNotNull(copyOf);
        ArrayList arrayList = new ArrayList();
        for (Object obj : copyOf) {
            String p = (String) obj;
            LinkedHashMap linkedHashMap = Bloat.SUGGEST;
            Intrinsics.checkNotNullParameter(p, "p");
            Bloat.Extra extra = Bloat.extra;
            if (extra == null || !extra.drop.contains(p)) {
                arrayList.add(obj);
            }
        }
        return CollectionsKt.plus((List) arrayList, (Iterable) Bloat.suggest().keySet());
    }

    public final String copyAndInstall(File file) {
        Function1 function1;
        try {
            Adb adb = getAdb();
            Intrinsics.checkNotNull(adb);
            long length = file.length();
            Words$$ExternalSyntheticLambda1 words$$ExternalSyntheticLambda1 = new Words$$ExternalSyntheticLambda1(6, file);
            ConcurrentHashMap concurrentHashMap = Adb.ASKING;
            adb.put("/data/local/tmp/tvr-setup.apk", length, false, null, words$$ExternalSyntheticLambda1);
            String str = "";
            int i = 0;
            while (true) {
                function1 = this.sh;
                if (i >= 30) {
                    break;
                }
                String obj = StringsKt.trim((String) function1.invoke("stat -c %s /data/local/tmp/tvr-setup.apk 2>/dev/null")).toString();
                if (Intrinsics.areEqual(obj, String.valueOf(file.length()))) {
                    str = obj;
                    break;
                }
                if (Intrinsics.areEqual(obj, str)) {
                    i++;
                } else {
                    i = 0;
                }
                Thread.sleep(500L);
                str = obj;
            }
            if (Intrinsics.areEqual(str, String.valueOf(file.length()))) {
                try {
                    return pmInstall(file.length(), "/data/local/tmp/tvr-setup.apk");
                } finally {
                    function1.invoke("rm -f /data/local/tmp/tvr-setup.apk");
                }
            }
            function1.invoke("rm -f /data/local/tmp/tvr-setup.apk");
            throw new IOException("copy to the TV incomplete (" + str + " of " + file.length() + " bytes)");
        } finally {
        }
    }

    public final File download(String url, String str, String str2, Axml$$ExternalSyntheticLambda2 axml$$ExternalSyntheticLambda2) {
        Intrinsics.checkNotNullParameter(url, "url");
        File file = this.dir;
        if (file == null) {
            file = new File(System.getProperty("java.io.tmpdir"));
        }
        File file2 = new File(file, str);
        URLConnection openConnection = new URL(url).openConnection();
        Intrinsics.checkNotNull(openConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
        HttpURLConnection httpURLConnection = (HttpURLConnection) openConnection;
        httpURLConnection.setConnectTimeout(20000);
        httpURLConnection.setReadTimeout(60000);
        httpURLConnection.setInstanceFollowRedirects(true);
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        try {
            long contentLength = httpURLConnection.getContentLength();
            InputStream inputStream = httpURLConnection.getInputStream();
            try {
                FileOutputStream fileOutputStream = new FileOutputStream(file2);
                try {
                    byte[] bArr = new byte[65536];
                    long j = 0;
                    while (true) {
                        int read = inputStream.read(bArr);
                        if (read <= 0) {
                            break;
                        }
                        fileOutputStream.write(bArr, 0, read);
                        messageDigest.update(bArr, 0, read);
                        j += read;
                        if (axml$$ExternalSyntheticLambda2 != null && contentLength > 0) {
                            axml$$ExternalSyntheticLambda2.invoke(Integer.valueOf((int) ((100 * j) / contentLength)));
                        }
                    }
                    fileOutputStream.close();
                    inputStream.close();
                    httpURLConnection.disconnect();
                    byte[] digest = messageDigest.digest();
                    Intrinsics.checkNotNullExpressionValue(digest, "digest(...)");
                    String joinToString$default = ArraysKt.joinToString$default(digest, "", new Bloat$$ExternalSyntheticLambda1(17));
                    if (str2 != null && !Intrinsics.areEqual(joinToString$default, str2)) {
                        file2.delete();
                        throw new IOException(t("optimize.checksum_mismatch_not_installing", new Pair[0]));
                    }
                    return file2;
                } finally {
                }
            } finally {
            }
        } catch (Throwable th) {
            httpURLConnection.disconnect();
            throw th;
        }
    }

    public final Adb getAdb() {
        Setup$$ExternalSyntheticLambda5 setup$$ExternalSyntheticLambda5 = this.fresh;
        if (setup$$ExternalSyntheticLambda5 != null) {
            return ((AdbLink) setup$$ExternalSyntheticLambda5.f$0).get();
        }
        return this.adb0;
    }

    public final Set handlers() {
        List split$default = StringsKt.split$default((CharSequence) this.sh.invoke("cmd package query-activities --brief -a android.intent.action.VIEW -t vnd.android.cursor.item/channel 2>/dev/null; cmd package query-activities --brief -a android.settings.SETTINGS 2>/dev/null"), new String[]{"\n"}, 0, 6);
        ArrayList arrayList = new ArrayList();
        for (Object obj : split$default) {
            if (StringsKt.contains$default((String) obj, '/')) {
                arrayList.add(obj);
            }
        }
        ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList));
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            String obj2 = StringsKt.trim((String) it.next()).toString();
            arrayList2.add(StringsKt.substringBefore(obj2, '/', obj2));
        }
        return CollectionsKt.toSet(arrayList2);
    }

    public final boolean has(String str) {
        return StringsKt.contains((CharSequence) this.sh.invoke("pm path ".concat(str)), "package:", false);
    }

    public final String homeNow() {
        String access$last = Rescue.access$last((String) this.sh.invoke("p=$(cmd role get-role-holders android.app.role.HOME 2>/dev/null); c=$([ -n \"$p\" ] && cmd package query-activities --brief -a android.intent.action.MAIN -c android.intent.category.HOME 2>/dev/null | grep -m1 \"^ *$p/\"); if [ -n \"$c\" ]; then echo $c; else cmd package resolve-activity --brief -c android.intent.category.HOME -a android.intent.action.MAIN; fi"));
        return StringsKt.substringBefore(access$last, '/', access$last);
    }

    public final String install(File file) {
        String absolutePath = file.getAbsolutePath();
        Intrinsics.checkNotNullExpressionValue(absolutePath, "getAbsolutePath(...)");
        String m = ApkSigner$$ExternalSyntheticOutline0.m("'", StringsKt__StringsJVMKt.replace$default(absolutePath, "'", "'\\''"), "'");
        if (Intrinsics.areEqual(StringsKt.trim((String) this.sh.invoke(ApkSigner$$ExternalSyntheticOutline0.m("stat -c %s ", m, " 2>/dev/null"))).toString(), String.valueOf(file.length()))) {
            return pmInstall(file.length(), m);
        }
        try {
            return copyAndInstall(file);
        } catch (IOException unused) {
            return copyAndInstall(file);
        }
    }

    public final Set off() {
        List split$default = StringsKt.split$default((CharSequence) this.sh.invoke("pm list packages -d 2>/dev/null"), new String[]{"\n"}, 0, 6);
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(split$default));
        Iterator it = split$default.iterator();
        while (it.hasNext()) {
            arrayList.add(StringsKt.trim(StringsKt.removePrefix((String) it.next(), "package:")).toString());
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator it2 = arrayList.iterator();
        while (it2.hasNext()) {
            Object next = it2.next();
            if (((String) next).length() > 0) {
                arrayList2.add(next);
            }
        }
        return CollectionsKt.toSet(arrayList2);
    }

    public final boolean optimized() {
        Set off = off();
        List undoable = undoable();
        if (undoable.isEmpty()) {
            return false;
        }
        Iterator it = undoable.iterator();
        while (it.hasNext()) {
            if (off.contains((String) it.next())) {
                return true;
            }
        }
        return false;
    }

    public final String pmInstall(long j, String str) {
        Adb adb = getAdb();
        Intrinsics.checkNotNull(adb);
        return PmInstall.fallback(adb.shell(600000L, "cat " + str + " | pm install -r -S " + j + " 2>&1"), new Words$$ExternalSyntheticLambda1(7, this), str, j, new Census$$ExternalSyntheticLambda4(7));
    }

    public final String systemPid() {
        String input;
        Pattern compile;
        try {
            input = StringsKt.trim((String) this.sh.invoke("pidof system_server")).toString();
            compile = Pattern.compile("\\d+");
            Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
            Intrinsics.checkNotNullParameter(input, "input");
        } catch (IOException unused) {
        }
        if (!compile.matcher(input).matches()) {
            return null;
        }
        return input;
    }

    public final String t(String str, Pair... pairArr) {
        ConcurrentHashMap concurrentHashMap = Words.books;
        return Words.get(this.lang, str, (Pair[]) Arrays.copyOf(pairArr, pairArr.length));
    }

    public final String turnOff(String str) {
        String m = Census$$ExternalSyntheticOutline0.m("grep -qx '", str, "' /data/local/tmp/tvr-disabled.txt 2>/dev/null || echo '", str, "' >> /data/local/tmp/tvr-disabled.txt");
        Function1 function1 = this.sh;
        function1.invoke(m);
        String str2 = (String) function1.invoke("pm disable-user --user 0 ".concat(str));
        if (!DEAD.containsMatchIn(str2)) {
            function1.invoke("am force-stop ".concat(str));
        }
        return str2;
    }

    public final void tvOnly() {
        if (!Intrinsics.areEqual(StringsKt.trim((String) this.sh.invoke("pm has-feature android.software.leanback")).toString(), "false")) {
        } else {
            throw new IOException(t("optimize.device_not_tv_optimize", new Pair[0]));
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:29:0x0093  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final List undoable() {
        Iterable take;
        List split$default = StringsKt.split$default((CharSequence) this.sh.invoke("cat /data/local/tmp/tvr-disabled.txt 2>/dev/null"), new String[]{"\n"}, 0, 6);
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(split$default));
        Iterator it = split$default.iterator();
        while (it.hasNext()) {
            arrayList.add(StringsKt.trim((String) it.next()).toString());
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator it2 = arrayList.iterator();
        while (it2.hasNext()) {
            Object next = it2.next();
            if (((String) next).length() > 0) {
                arrayList2.add(next);
            }
        }
        boolean isEmpty = arrayList2.isEmpty();
        String[] strArr = LAUNCHER;
        if (!isEmpty) {
            Iterator it3 = arrayList2.iterator();
            while (it3.hasNext()) {
                if (ArraysKt.contains((String) it3.next(), strArr)) {
                    break;
                }
            }
        }
        if (!has("com.google.android.apps.tv.launcherx")) {
            take = ArraysKt.take(strArr, 2);
            ArrayList arrayList3 = new ArrayList();
            for (int i = 0; i < 5; i++) {
                String str = strArr[i];
                if (arrayList2.contains(str)) {
                    arrayList3.add(str);
                }
            }
            return CollectionsKt.distinct(CollectionsKt.plus((List) CollectionsKt.plus((List) CollectionsKt.plus((List) CollectionsKt.plus((List) arrayList3, take), (Object[]) GOOGLE), (Object[]) SONY), (Iterable) arrayList2));
        }
        take = EmptyList.INSTANCE;
        ArrayList arrayList32 = new ArrayList();
        while (i < 5) {
        }
        return CollectionsKt.distinct(CollectionsKt.plus((List) CollectionsKt.plus((List) CollectionsKt.plus((List) CollectionsKt.plus((List) arrayList32, take), (Object[]) GOOGLE), (Object[]) SONY), (Iterable) arrayList2));
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public Setup(Adb adb, File file, String lang, Log log) {
        this(adb, file, lang, new Fleet$$ExternalSyntheticLambda0(adb, 13), null, log);
        Intrinsics.checkNotNullParameter(adb, "adb");
        Intrinsics.checkNotNullParameter(lang, "lang");
    }
}
