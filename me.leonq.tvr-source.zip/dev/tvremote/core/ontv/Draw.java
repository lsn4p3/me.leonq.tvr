package dev.tvremote.core.ontv;

import dev.tvremote.core.B64;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.ontv.SetupNeed;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Collection;
import java.util.Iterator;
import java.util.regex.Matcher;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgressionIterator;
import kotlin.text.Charsets;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class Draw {
    public final Function0 adb;
    public Adb from;
    public volatile boolean pics;
    public Adb.Stream stream;

    public Draw(Function0 function0) {
        this.adb = function0;
    }

    public final synchronized void close() {
        try {
            Adb.Stream stream = this.stream;
            if (stream != null) {
                stream.close();
            }
        } catch (Exception unused) {
        }
        this.stream = null;
    }

    public final boolean getPics() {
        return this.pics;
    }

    public final Adb.Stream open() {
        Adb adb = (Adb) this.adb.invoke();
        Adb.Stream stream = this.stream;
        if (stream != null && this.from == adb && !adb.dead) {
            return stream;
        }
        close();
        String shell = adb.shell(20000L, "appops set dev.tvremote.setup SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1; am broadcast --include-stopped-packages -n dev.tvremote.setup/.DrawReceiver 2>&1");
        Matcher m7m = Census$$ExternalSyntheticOutline0.m7m("data=\"([A-Za-z0-9+/=]+)\"", "compile(...)", shell, "input", shell);
        Intrinsics.checkNotNullExpressionValue(m7m, "matcher(...)");
        MatcherMatchResult access$findNext = MathKt.access$findNext(m7m, 0, shell);
        if (access$findNext != null) {
            int[] iArr = B64.INDEX;
            byte[] decode = B64.decode((String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1));
            Charset charset = Charsets.UTF_8;
            JSONObject jSONObject = new JSONObject(new String(decode, charset));
            if (jSONObject.optBoolean("overlay")) {
                this.pics = jSONObject.optBoolean("pic");
                Adb.Stream open = adb.open(10000L, "tcp:" + jSONObject.getInt("port"));
                byte[] bytes = (jSONObject.getString("token") + "\n").getBytes(charset);
                Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                open.write(bytes);
                this.stream = open;
                this.from = adb;
                return open;
            }
            throw new IOException("draw:nooverlay");
        }
        Regex regex = SetupUpdate.VERSION;
        throw new SetupNeed.Missing("draw", SetupUpdate.installed(adb));
    }

    public final synchronized void send(JSONArray jSONArray) {
        boolean z;
        Adb.Stream open;
        try {
            StringBuilder sb = new StringBuilder();
            int length = jSONArray.length();
            for (int i = 0; i < length; i++) {
                sb.append(jSONArray.getJSONObject(i).toString());
                sb.append('\n');
            }
            String sb2 = sb.toString();
            Intrinsics.checkNotNullExpressionValue(sb2, "toString(...)");
            byte[] bytes = sb2.getBytes(Charsets.UTF_8);
            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
            Iterable until = MathKt.until(0, jSONArray.length());
            if (!(until instanceof Collection) || !((Collection) until).isEmpty()) {
                Iterator it = until.iterator();
                while (((IntProgressionIterator) it).hasNext) {
                    if (Intrinsics.areEqual(jSONArray.getJSONObject(((IntProgressionIterator) it).nextInt()).optString("o"), "i")) {
                        z = true;
                        break;
                    }
                }
            }
            z = false;
            if (jSONArray.length() == 0) {
                close();
            }
            for (int i2 = 0; i2 < 2; i2++) {
                try {
                    open = open();
                    if (z && !this.pics) {
                        Regex regex = SetupUpdate.VERSION;
                        throw new SetupNeed.Missing("pic", SetupUpdate.installed((Adb) this.adb.invoke()));
                        break;
                    }
                } catch (IOException e) {
                    if (i2 != 1 && !(e instanceof SetupNeed.Missing)) {
                        close();
                    } else {
                        throw e;
                    }
                }
                try {
                    if (bytes.length != 0) {
                        open.write(bytes);
                    }
                    return;
                } catch (IOException e2) {
                    close();
                    if (i2 == 1) {
                        throw e2;
                    }
                }
            }
        } catch (Throwable th) {
            throw th;
        }
    }
}
