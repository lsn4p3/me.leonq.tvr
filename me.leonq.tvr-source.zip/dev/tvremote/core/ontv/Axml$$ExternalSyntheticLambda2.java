package dev.tvremote.core.ontv;

import android.graphics.Typeface;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.Adb$$ExternalSyntheticLambda5;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.adb.Mdns;
import dev.tvremote.core.manage.HomeApi;
import dev.tvremote.core.manage.InstallApi;
import dev.tvremote.core.manage.Manage$$ExternalSyntheticLambda27;
import dev.tvremote.core.manage.SetupApi;
import dev.tvremote.core.manage.TvAppsApi;
import dev.tvremote.core.manage.TvAppsApi$$ExternalSyntheticLambda1;
import dev.tvremote.core.manage.TvCopy;
import dev.tvremote.core.ontv.Launchers;
import dev.tvremote.core.remote.Lg$$ExternalSyntheticLambda5;
import dev.tvremote.core.remote.Vidaa$$ExternalSyntheticLambda6;
import dev.tvremote.core.web.Cancel;
import dev.tvremote.core.web.Cancelled;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda30;
import dev.tvremote.phone.ir.IrProfile;
import dev.tvremote.phone.ir.IrRemoteKt;
import dev.tvremote.phone.manage.UpdaterKt$$ExternalSyntheticLambda3;
import dev.tvremote.phone.picker.ManyTvsKt;
import dev.tvremote.phone.remote.TypingKt;
import dev.tvremote.phone.ui.IconButton;
import dev.tvremote.phone.ui.UiKt;
import dev.tvremote.tvapps.AppList;
import dev.tvremote.update.Release;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.NoRouteToHostException;
import java.net.URL;
import java.net.URLConnection;
import java.net.UnknownHostException;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$IntRef;
import kotlin.math.MathKt;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import org.conscrypt.metrics.ConscryptStatsLog;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class Axml$$ExternalSyntheticLambda2 implements Function1 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;
    public final /* synthetic */ Object f$1;

    public /* synthetic */ Axml$$ExternalSyntheticLambda2(int i, Object obj, Object obj2) {
        this.$r8$classId = i;
        this.f$0 = obj;
        this.f$1 = obj2;
    }

    /* JADX WARN: Code restructure failed: missing block: B:291:0x090f, code lost:
    
        continue;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v66, types: [android.widget.LinearLayout, java.lang.Object, android.view.ViewGroup] */
    /* JADX WARN: Type inference failed for: r2v0, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v20 */
    /* JADX WARN: Type inference failed for: r2v21, types: [long] */
    /* JADX WARN: Type inference failed for: r2v5, types: [kotlin.jvm.internal.Ref$BooleanRef, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r30v0, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r30v1 */
    /* JADX WARN: Type inference failed for: r30v10, types: [java.net.HttpURLConnection] */
    /* JADX WARN: Type inference failed for: r30v12 */
    /* JADX WARN: Type inference failed for: r30v13 */
    /* JADX WARN: Type inference failed for: r30v14 */
    /* JADX WARN: Type inference failed for: r30v2, types: [java.net.HttpURLConnection] */
    /* JADX WARN: Type inference failed for: r30v3 */
    /* JADX WARN: Type inference failed for: r30v4 */
    /* JADX WARN: Type inference failed for: r30v6 */
    /* JADX WARN: Type inference failed for: r30v7 */
    /* JADX WARN: Type inference failed for: r30v8 */
    /* JADX WARN: Type inference failed for: r30v9 */
    /* JADX WARN: Type inference failed for: r5v15, types: [java.util.List, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r5v5, types: [dev.tvremote.core.adb.Adb] */
    /* JADX WARN: Unreachable blocks removed: 1, instructions: 1 */
    @Override // kotlin.jvm.functions.Function1
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object invoke(Object obj) {
        JSONObject put;
        String str;
        DigestInputStream digestInputStream;
        Throwable th;
        TvCopy tvCopy;
        MessageDigest messageDigest;
        long j;
        String T;
        String T2;
        int i;
        Iterator it;
        View view;
        boolean z;
        boolean z2;
        boolean z3;
        String str2;
        ?? r2 = "msg";
        int i2 = 5;
        int i3 = 4;
        int i4 = 3;
        int i5 = 2;
        switch (this.$r8$classId) {
            case 0:
                String it2 = (String) obj;
                Intrinsics.checkNotNullParameter(it2, "it");
                String clone$own = Axml.clone$own((String) this.f$0, (String) this.f$1, it2);
                if (clone$own != null) {
                    return clone$own;
                }
                return it2;
            case 1:
                HomeApi homeApi = (HomeApi) this.f$0;
                Function2 function2 = (Function2) this.f$1;
                JSONObject j2 = (JSONObject) obj;
                Intrinsics.checkNotNullParameter(j2, "j");
                Cancel cancel = (Cancel) homeApi.getCurrent().get();
                j2.put("msg", "download");
                ?? obj2 = new Object();
                JSONObject jSONObject = (JSONObject) function2.invoke(new Vidaa$$ExternalSyntheticLambda6((Object) obj2, cancel, j2, 1), new Axml$$ExternalSyntheticLambda2(2, cancel, j2));
                if (!obj2.element && cancel != null && cancel.stopped) {
                    throw new Cancelled();
                }
                j2.put("state", jSONObject);
                return "";
            case 2:
                int intValue = ((Integer) obj).intValue();
                Cancel cancel2 = (Cancel) this.f$0;
                if (cancel2 != null) {
                    cancel2.check();
                }
                ((JSONObject) this.f$1).put("pct", (intValue * 9) / 10);
                return Unit.INSTANCE;
            case 3:
                JSONObject j3 = (JSONObject) obj;
                Intrinsics.checkNotNullParameter(j3, "j");
                j3.put("pct", 50);
                ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                String str3 = (String) this.f$0;
                String m = ApkSigner$$ExternalSyntheticOutline0.m("stat -c %s ", Mdns.q(str3), " 2>/dev/null");
                InstallApi installApi = (InstallApi) this.f$1;
                Long longOrNull = StringsKt__StringNumberConversionsKt.toLongOrNull(StringsKt.trim(installApi.sh(m)).toString());
                if (longOrNull != null) {
                    installApi.copy.ensureRoom(longOrNull.longValue(), "/data", 1);
                }
                return installApi.pmInstall(str3);
            case 4:
                Release release = (Release) this.f$0;
                SetupApi setupApi = (SetupApi) this.f$1;
                JSONObject j4 = (JSONObject) obj;
                Intrinsics.checkNotNullParameter(j4, "j");
                try {
                    put = j4.put("msg", "download");
                    str = release.version;
                } catch (Exception e) {
                    e = e;
                    r2 = 120000;
                }
                try {
                    put.put("version", str);
                    URLConnection openConnection = new URL(release.url).openConnection();
                    Intrinsics.checkNotNull(openConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
                    HttpURLConnection httpURLConnection = (HttpURLConnection) openConnection;
                    httpURLConnection.setConnectTimeout(15000);
                    httpURLConnection.setReadTimeout(30000);
                    httpURLConnection.setRequestProperty("User-Agent", "tv-remote");
                    try {
                    } catch (Throwable th2) {
                        th = th2;
                        obj = httpURLConnection;
                    }
                    try {
                        if (httpURLConnection.getResponseCode() == 200) {
                            MessageDigest messageDigest2 = MessageDigest.getInstance("SHA-256");
                            DigestInputStream digestInputStream2 = new DigestInputStream(httpURLConnection.getInputStream(), messageDigest2);
                            try {
                                TvCopy tvCopy2 = setupApi.copy;
                                AdbLink adbLink = setupApi.link;
                                if (httpURLConnection.getContentLength() >= 0) {
                                    HttpURLConnection httpURLConnection2 = httpURLConnection;
                                    try {
                                        tvCopy = tvCopy2;
                                        messageDigest = messageDigest2;
                                        j = httpURLConnection2.getContentLength();
                                        obj = httpURLConnection2;
                                    } catch (Throwable th3) {
                                        th = th3;
                                        digestInputStream = digestInputStream2;
                                        obj = httpURLConnection2;
                                        try {
                                            throw th;
                                        } catch (Throwable th4) {
                                            MathKt.closeFinally(digestInputStream, th);
                                            throw th4;
                                        }
                                    }
                                } else {
                                    obj = httpURLConnection;
                                    tvCopy = tvCopy2;
                                    messageDigest = messageDigest2;
                                    j = -1;
                                }
                                try {
                                    int i6 = TvCopy.$r8$clinit;
                                    digestInputStream = digestInputStream2;
                                    try {
                                        tvCopy.push(digestInputStream, j, "/data/local/tmp/tvr-update/new.apk", j4, 1);
                                        try {
                                            digestInputStream.close();
                                            try {
                                                Intrinsics.checkNotNull(messageDigest);
                                                release.check(messageDigest);
                                                obj.disconnect();
                                                Regex regex = SetupUpdate.VERSION;
                                                Adb adb = adbLink.get();
                                                if (SetupUpdate.VERSION.matches(str)) {
                                                    try {
                                                        SetupUpdate.launch(adb, str);
                                                        j4.put("msg", "installing").put("pct", 92);
                                                        long j5 = 1000000;
                                                        long nanoTime = System.nanoTime() / j5;
                                                        while ((System.nanoTime() / j5) - nanoTime < 300000) {
                                                            Thread.sleep(2000L);
                                                            try {
                                                                Regex regex2 = SetupUpdate.VERSION;
                                                                JSONObject state = SetupUpdate.state(adbLink.get());
                                                                if (!Intrinsics.areEqual(state.optString("version"), str)) {
                                                                    if ((System.nanoTime() / j5) - nanoTime > 30000) {
                                                                        throw new IOException("the update did not start on the TV");
                                                                    }
                                                                } else {
                                                                    String optString = state.optString("state");
                                                                    if (optString != null) {
                                                                        switch (optString.hashCode()) {
                                                                            case -1380616235:
                                                                                if (optString.equals("broken")) {
                                                                                    throw new IOException("setup:broken ".concat(str));
                                                                                }
                                                                                break;
                                                                            case -1281977283:
                                                                                if (optString.equals("failed")) {
                                                                                    String optString2 = state.optString("detail");
                                                                                    if (optString2.length() == 0) {
                                                                                        optString2 = "install failed";
                                                                                    }
                                                                                    throw new IOException(optString2);
                                                                                }
                                                                                break;
                                                                            case -393668413:
                                                                                if (optString.equals("rolledback")) {
                                                                                    throw new IOException(Census$$ExternalSyntheticOutline0.m("setup:rolledback ", str, " ", state.optString("from")));
                                                                                }
                                                                                break;
                                                                            case 3548:
                                                                                if (optString.equals("ok")) {
                                                                                    return "updated ".concat(str);
                                                                                }
                                                                                break;
                                                                            case 1536898522:
                                                                                if (optString.equals("checking")) {
                                                                                    j4.put("msg", "checking").put("pct", 96);
                                                                                    break;
                                                                                } else {
                                                                                    break;
                                                                                }
                                                                        }
                                                                    } else {
                                                                        continue;
                                                                    }
                                                                }
                                                            } catch (IOException unused) {
                                                            }
                                                        }
                                                        throw new IOException("setup:slow");
                                                    } catch (Exception e2) {
                                                        ConcurrentHashMap concurrentHashMap2 = Adb.ASKING;
                                                        adb.shell(120000L, "rmdir /data/local/tmp/tvr-update/lock 2>/dev/null");
                                                        throw e2;
                                                    }
                                                }
                                                throw new IllegalArgumentException("bad version");
                                            } catch (IOException e3) {
                                                setupApi.sh("rm -f /data/local/tmp/tvr-update/new.apk");
                                                throw e3;
                                            }
                                        } catch (Throwable th5) {
                                            th = th5;
                                            obj.disconnect();
                                            throw th;
                                        }
                                    } catch (Throwable th6) {
                                        th = th6;
                                        th = th;
                                        obj = obj;
                                        throw th;
                                    }
                                } catch (Throwable th7) {
                                    th = th7;
                                    digestInputStream = digestInputStream2;
                                }
                            } catch (Throwable th8) {
                                th = th8;
                                obj = httpURLConnection;
                                digestInputStream = digestInputStream2;
                            }
                        } else {
                            throw new IOException("HTTP " + httpURLConnection.getResponseCode());
                        }
                    } catch (Throwable th9) {
                        th = th9;
                        obj.disconnect();
                        throw th;
                    }
                } catch (Exception e4) {
                    e = e4;
                    try {
                        Regex regex3 = SetupUpdate.VERSION;
                        ?? r5 = setupApi.link.get();
                        ConcurrentHashMap concurrentHashMap3 = Adb.ASKING;
                        r5.shell(r2, "rmdir /data/local/tmp/tvr-update/lock 2>/dev/null");
                    } catch (Exception unused2) {
                    }
                    throw e;
                }
                break;
            case 5:
                JSONObject j6 = (JSONObject) obj;
                Intrinsics.checkNotNullParameter(j6, "j");
                TvAppsApi tvAppsApi = (TvAppsApi) this.f$0;
                File file = tvAppsApi.dir;
                if (file != null) {
                    Cancel cancel3 = (Cancel) tvAppsApi.cancel.invoke();
                    j6.put("step", "download").put("pct", 0);
                    List list = AppList.bases;
                    try {
                        File file2 = AppList.get((AppList.App) this.f$1, tvAppsApi.tv().token, file, new Home$$ExternalSyntheticLambda6(j6, 1), new TvAppsApi$$ExternalSyntheticLambda1(cancel3, 0));
                        try {
                            j6.put("step", "install");
                            FileInputStream fileInputStream = new FileInputStream(file2);
                            try {
                                String str4 = (String) tvAppsApi.install.invoke(fileInputStream, Long.valueOf(file2.length()), cancel3);
                                fileInputStream.close();
                                return str4;
                            } finally {
                            }
                        } finally {
                            file2.delete();
                        }
                    } catch (ConnectException e5) {
                        throw new IOException("apps:offline", e5);
                    } catch (NoRouteToHostException e6) {
                        throw new IOException("apps:offline", e6);
                    } catch (UnknownHostException e7) {
                        throw new IOException("apps:offline", e7);
                    }
                } else {
                    throw new IOException("no folder for the download");
                }
            case 6:
                int intValue2 = ((Integer) obj).intValue();
                int i7 = intValue2 / 5;
                Ref$IntRef ref$IntRef = (Ref$IntRef) this.f$0;
                if (i7 != ref$IntRef.element) {
                    ref$IntRef.element = i7;
                    ((Manage$$ExternalSyntheticLambda27) this.f$1).at("download", ((intValue2 * 55) / 100) + 5);
                }
                return Unit.INSTANCE;
            case 7:
                ?? irPage = (LinearLayout) obj;
                Intrinsics.checkNotNullParameter(irPage, "$this$irPage");
                MainActivity mainActivity = (MainActivity) this.f$0;
                LinearLayout linearLayout = new LinearLayout(mainActivity);
                IrProfile irProfile = (IrProfile) this.f$1;
                if (irProfile == null || (T = IrRemoteKt.getTitle(irProfile)) == null) {
                    T = Fleet.T("ir.choose_brand", new Pair[0]);
                }
                Button button = UiKt.button(mainActivity, ApkSigner$$ExternalSyntheticOutline0.m("@tv|", T), UiKt.BTN);
                button.setMaxLines(1);
                button.setEllipsize(TextUtils.TruncateAt.END);
                button.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(mainActivity, i4));
                float f = 48;
                linearLayout.addView(button, new LinearLayout.LayoutParams(0, UiKt.dp(mainActivity, f), 1.0f));
                Button button2 = UiKt.button(mainActivity, ApkSigner$$ExternalSyntheticOutline0.m("@search|", Fleet.T("ir.find", new Pair[0])), UiKt.SOFT);
                UiKt.setInk(button2, UiKt.ACCENT_TEXT);
                button2.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(mainActivity, i3));
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, UiKt.dp(mainActivity, f));
                float f2 = 8;
                layoutParams.leftMargin = UiKt.dp(mainActivity, f2);
                linearLayout.addView(button2, layoutParams);
                irPage.addView(linearLayout, UiKt.gap(mainActivity, 14));
                if (irProfile == null) {
                    T2 = Fleet.T("ir.pick_first", new Pair[0]);
                } else {
                    T2 = Fleet.T("ir.aim", new Pair[0]);
                }
                irPage.addView(UiKt.note(mainActivity, T2));
                if (irProfile != null) {
                    irPage.addView(IrRemoteKt.irRow(mainActivity, irProfile, 52, new Triple("POWER", "@power", Fleet.T("remote.power", new Pair[0])), new Triple("INPUT", "@input", Fleet.T("rkey.input", new Pair[0])), new Triple("MUTE", "@mute", Fleet.T("rkey.mute", new Pair[0]))), UiKt.gap(mainActivity, 16));
                    FrameLayout frameLayout = new FrameLayout(mainActivity);
                    frameLayout.setBackground(UiKt.oval(mainActivity, UiKt.CARD));
                    List<Triple> asList = ArraysKt.asList(new Triple[]{new Triple("UP", "@up", 49), new Triple("DOWN", "@down", 81), new Triple("LEFT", "@left", 8388627), new Triple("RIGHT", "@right", 8388629)});
                    Map mapOf = MapsKt__MapsKt.mapOf(new Pair("UP", Fleet.T("remote.up", new Pair[0])), new Pair("DOWN", Fleet.T("remote.down", new Pair[0])), new Pair("LEFT", Fleet.T("remote.left", new Pair[0])), new Pair("RIGHT", Fleet.T("remote.right", new Pair[0])));
                    for (Triple triple : asList) {
                        String str5 = (String) triple.first;
                        String str6 = (String) triple.second;
                        int intValue3 = ((Number) triple.third).intValue();
                        IconButton icon = UiKt.icon(mainActivity, str6, (String) MapsKt__MapsKt.getValue(mapOf, str5), 0);
                        icon.setIcon(str6, UiKt.MUTED);
                        icon.setSize(26.0f);
                        icon.setBackground(UiKt.oval(mainActivity, 0));
                        IrRemoteKt.irBind(mainActivity, icon, irProfile, str5, UiKt.oval(mainActivity, UiKt.HELD));
                        float f3 = 72;
                        FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(UiKt.dp(mainActivity, f3), UiKt.dp(mainActivity, f3), intValue3);
                        float f4 = 4;
                        layoutParams2.setMargins(UiKt.dp(mainActivity, f4), UiKt.dp(mainActivity, f4), UiKt.dp(mainActivity, f4), UiKt.dp(mainActivity, f4));
                        frameLayout.addView(icon, layoutParams2);
                        mapOf = mapOf;
                    }
                    Button button3 = UiKt.button(mainActivity, "OK", UiKt.ACCENT);
                    button3.setTypeface(Typeface.DEFAULT_BOLD);
                    button3.setTextSize(18.0f);
                    button3.setPadding(0, 0, 0, 0);
                    button3.setBackground(UiKt.oval(mainActivity, UiKt.ACCENT));
                    button3.setElevation(UiKt.dp(mainActivity, 6));
                    IrRemoteKt.irBind(mainActivity, button3, irProfile, "OK", UiKt.oval(mainActivity, UiKt.HELD));
                    float f5 = 84;
                    frameLayout.addView(button3, new FrameLayout.LayoutParams(UiKt.dp(mainActivity, f5), UiKt.dp(mainActivity, f5), 17));
                    LinearLayout linearLayout2 = new LinearLayout(mainActivity);
                    linearLayout2.setGravity(17);
                    float f6 = 216;
                    linearLayout2.addView(frameLayout, new LinearLayout.LayoutParams(UiKt.dp(mainActivity, f6), UiKt.dp(mainActivity, f6)));
                    irPage.addView(linearLayout2, UiKt.gap(mainActivity, 14));
                    irPage.addView(IrRemoteKt.irRow(mainActivity, irProfile, 52, new Triple("BACK", "@back", Fleet.T("rkey.back", new Pair[0])), new Triple("HOME", "@home", Fleet.T("rkey.home", new Pair[0])), new Triple("MENU", "@menu", Fleet.T("rkey.menu", new Pair[0]))), UiKt.gap(mainActivity, 14));
                    LinearLayout linearLayout3 = new LinearLayout(mainActivity);
                    LinearLayout irPill = IrRemoteKt.irPill(mainActivity, irProfile, Fleet.T("remote.ch_2", new Pair[0]), new Triple("CH_UP", "@up", Fleet.T("remote.ch", new Pair[0])), new Triple("CH_DOWN", "@down", Fleet.T("remote.ch_3", new Pair[0])));
                    float f7 = 124;
                    LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(0, UiKt.dp(mainActivity, f7), 1.0f);
                    layoutParams3.rightMargin = UiKt.dp(mainActivity, f2);
                    linearLayout3.addView(irPill, layoutParams3);
                    LinearLayout irPill2 = IrRemoteKt.irPill(mainActivity, irProfile, "VOL", new Triple("VOL_UP", "@plus", Fleet.T("remote.volume_up", new Pair[0])), new Triple("VOL_DOWN", "@minus", Fleet.T("remote.volume_down", new Pair[0])));
                    LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(0, UiKt.dp(mainActivity, f7), 1.0f);
                    layoutParams4.leftMargin = UiKt.dp(mainActivity, f2);
                    linearLayout3.addView(irPill2, layoutParams4);
                    irPage.addView(linearLayout3, UiKt.gap(mainActivity, 14));
                    LinkedHashMap linkedHashMap = irProfile.keys;
                    Set keySet = linkedHashMap.keySet();
                    if (keySet == null || !keySet.isEmpty()) {
                        Iterator it3 = keySet.iterator();
                        while (true) {
                            if (it3.hasNext()) {
                                String str7 = (String) it3.next();
                                if (str7.compareTo("0") >= 0 && str7.compareTo("9") <= 0) {
                                    Iterator it4 = ArraysKt.asList(new String[]{"123", "456", "789", " 0 "}).iterator();
                                    while (it4.hasNext()) {
                                        String str8 = (String) it4.next();
                                        LinearLayout linearLayout4 = new LinearLayout(mainActivity);
                                        int i8 = 0;
                                        int i9 = 0;
                                        while (i8 < str8.length()) {
                                            char charAt = str8.charAt(i8);
                                            int i10 = i9 + 1;
                                            if (charAt == ' ') {
                                                view = new View(mainActivity);
                                                it = it4;
                                            } else {
                                                Button button4 = UiKt.button(mainActivity, String.valueOf(charAt), UiKt.BTN);
                                                button4.setTextSize(18.0f);
                                                it = it4;
                                                IrRemoteKt.irBind(mainActivity, button4, irProfile, String.valueOf(charAt), UiKt.box(mainActivity, UiKt.HELD, 14));
                                                view = button4;
                                            }
                                            if (i9 > 0) {
                                                z = true;
                                            } else {
                                                z = false;
                                            }
                                            linearLayout4.addView(view, UiKt.cell(48, mainActivity, z));
                                            i8++;
                                            i9 = i10;
                                            it4 = it;
                                        }
                                        Iterator it5 = it4;
                                        if (str8.equals("123")) {
                                            i = 14;
                                        } else {
                                            i = 6;
                                        }
                                        irPage.addView(linearLayout4, UiKt.gap(mainActivity, i));
                                        it4 = it5;
                                    }
                                }
                            }
                        }
                    }
                    for (List list2 : ArraysKt.asList(new List[]{ArraysKt.asList(new Triple[]{new Triple("REWIND", "@rewind", Fleet.T("rkey.rewind", new Pair[0])), new Triple("PLAY_PAUSE", "@play_pause", Fleet.T("rkey.playpause", new Pair[0])), new Triple("FFWD", "@ffwd", Fleet.T("rkey.forward", new Pair[0])), new Triple("STOP", "@stop", Fleet.T("rkey.stop", new Pair[0]))}), ArraysKt.asList(new Triple[]{new Triple("SETTINGS", "@gear", Fleet.T("rkey.settings", new Pair[0])), new Triple("INFO", "@info", Fleet.T("rkey.info", new Pair[0])), new Triple("GUIDE", "@guide", Fleet.T("rkey.guide", new Pair[0])), new Triple("SUBTITLE", "@subtitle", Fleet.T("rkey.subtitles", new Pair[0]))})})) {
                        if (list2 == null || !list2.isEmpty()) {
                            Iterator it6 = list2.iterator();
                            while (it6.hasNext()) {
                                if (linkedHashMap.containsKey(((Triple) it6.next()).first)) {
                                    Triple[] tripleArr = (Triple[]) list2.toArray(new Triple[0]);
                                    irPage.addView(IrRemoteKt.irRow(mainActivity, irProfile, 48, (Triple[]) Arrays.copyOf(tripleArr, tripleArr.length)), UiKt.gap(mainActivity, 14));
                                }
                            }
                        }
                    }
                    List asList2 = ArraysKt.asList(new Pair[]{new Pair("RED", -1750963), new Pair("GREEN", -13589396), new Pair("YELLOW", -665334), new Pair("BLUE", -12688419)});
                    ArrayList arrayList = new ArrayList();
                    for (Object obj3 : asList2) {
                        if (linkedHashMap.containsKey(((Pair) obj3).first)) {
                            arrayList.add(obj3);
                        }
                    }
                    if (!arrayList.isEmpty()) {
                        LinearLayout linearLayout5 = new LinearLayout(mainActivity);
                        Iterator it7 = arrayList.iterator();
                        int i11 = 0;
                        while (it7.hasNext()) {
                            Object next = it7.next();
                            int i12 = i11 + 1;
                            if (i11 >= 0) {
                                Pair pair = (Pair) next;
                                String str9 = (String) pair.first;
                                Button button5 = UiKt.button(mainActivity, " ", ((Number) pair.second).intValue());
                                String lowerCase = str9.toLowerCase(Locale.ROOT);
                                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                                button5.setContentDescription(Fleet.T("rkey.".concat(lowerCase), new Pair[0]));
                                IrRemoteKt.irBind(mainActivity, button5, irProfile, str9, UiKt.box(mainActivity, UiKt.HELD, 16));
                                if (i11 > 0) {
                                    z3 = true;
                                } else {
                                    z3 = false;
                                }
                                linearLayout5.addView(button5, UiKt.cell(34, mainActivity, z3));
                                i11 = i12;
                            } else {
                                CollectionsKt__CollectionsKt.throwIndexOverflow();
                                throw null;
                            }
                        }
                        irPage.addView(linearLayout5, UiKt.gap(mainActivity, 14));
                    }
                    List asList3 = ArraysKt.asList(new Pair[]{new Pair("NETFLIX", Fleet.T("rkey.netflix", new Pair[0])), new Pair("YOUTUBE", Fleet.T("rkey.youtube", new Pair[0])), new Pair("PRIME", Fleet.T("rkey.prime", new Pair[0]))});
                    ArrayList arrayList2 = new ArrayList();
                    for (Object obj4 : asList3) {
                        if (linkedHashMap.containsKey(((Pair) obj4).first)) {
                            arrayList2.add(obj4);
                        }
                    }
                    if (!arrayList2.isEmpty()) {
                        LinearLayout linearLayout6 = new LinearLayout(mainActivity);
                        Iterator it8 = arrayList2.iterator();
                        int i13 = 0;
                        while (it8.hasNext()) {
                            Object next2 = it8.next();
                            int i14 = i13 + 1;
                            if (i13 >= 0) {
                                Pair pair2 = (Pair) next2;
                                String str10 = (String) pair2.first;
                                Button button6 = UiKt.button(mainActivity, (String) pair2.second, UiKt.BTN);
                                button6.setTextSize(14.0f);
                                float f8 = 4;
                                button6.setPadding(UiKt.dp(mainActivity, f8), 0, UiKt.dp(mainActivity, f8), 0);
                                IrRemoteKt.irBind(mainActivity, button6, irProfile, str10, UiKt.box(mainActivity, UiKt.HELD, 14));
                                if (i13 > 0) {
                                    z2 = true;
                                } else {
                                    z2 = false;
                                }
                                linearLayout6.addView(button6, UiKt.cell(44, mainActivity, z2));
                                i13 = i14;
                            } else {
                                CollectionsKt__CollectionsKt.throwIndexOverflow();
                                throw null;
                            }
                        }
                        irPage.addView(linearLayout6, UiKt.gap(mainActivity, 14));
                    }
                }
                return Unit.INSTANCE;
            case 8:
                int intValue4 = ((Integer) obj).intValue();
                MainActivity mainActivity2 = (MainActivity) this.f$0;
                mainActivity2.ui.post(new Lg$$ExternalSyntheticLambda5(mainActivity2, (Release) this.f$1, intValue4, i4));
                return Unit.INSTANCE;
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                return Boolean.valueOf(((MainActivity) this.f$0).ui.post(new UpdaterKt$$ExternalSyntheticLambda3((Button) this.f$1, ((Boolean) obj).booleanValue(), i5)));
            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                Launchers.Entry e8 = (Launchers.Entry) obj;
                Intrinsics.checkNotNullParameter(e8, "e");
                if (e8.kind.equals("play")) {
                    str2 = "fleet.launcher_ask_play";
                } else {
                    str2 = "fleet.launcher_ask";
                }
                String T3 = Fleet.T(str2, new Pair("name", e8.name));
                MainActivity mainActivity3 = (MainActivity) this.f$0;
                ManyTvsKt.fleetPick(mainActivity3, T3, new Adb$$ExternalSyntheticLambda5(mainActivity3, e8, (Launchers.Gallery) this.f$1, i2));
                return Unit.INSTANCE;
            default:
                float floatValue = ((Float) obj).floatValue();
                MainActivity mainActivity4 = (MainActivity) this.f$0;
                mainActivity4.getPrefs$android_release().edit().putFloat("listenGain", floatValue).apply();
                ((TextView) this.f$1).setText(TypingKt.gainWords(floatValue));
                TypingKt.layoutRemote(mainActivity4);
                return Unit.INSTANCE;
        }
    }

    public /* synthetic */ Axml$$ExternalSyntheticLambda2(InstallApi installApi, String str) {
        this.$r8$classId = 3;
        this.f$1 = installApi;
        this.f$0 = str;
    }
}
