package dev.tvremote.core.ontv;

import dev.tvremote.core.manage.SetupApi$$ExternalSyntheticLambda0;
import java.util.Comparator;
import java.util.Locale;
import java.util.Map;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;

/* loaded from: classes.dex */
public final class Setup$plan$$inlined$sortedBy$1 implements Comparator {
    public final /* synthetic */ Object $label$inlined;
    public final /* synthetic */ int $r8$classId;

    public /* synthetic */ Setup$plan$$inlined$sortedBy$1(int i, Object obj) {
        this.$r8$classId = i;
        this.$label$inlined = obj;
    }

    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        switch (this.$r8$classId) {
            case 0:
                String str = (String) obj;
                SetupApi$$ExternalSyntheticLambda0 setupApi$$ExternalSyntheticLambda0 = (SetupApi$$ExternalSyntheticLambda0) this.$label$inlined;
                String str2 = (String) setupApi$$ExternalSyntheticLambda0.invoke(str);
                if (str2 != null) {
                    str = str2;
                }
                Locale locale = Locale.ROOT;
                String lowerCase = str.toLowerCase(locale);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                String str3 = (String) obj2;
                String str4 = (String) setupApi$$ExternalSyntheticLambda0.invoke(str3);
                if (str4 != null) {
                    str3 = str4;
                }
                String lowerCase2 = str3.toLowerCase(locale);
                Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
                return MathKt.compareValues(lowerCase, lowerCase2);
            case 1:
                Object obj3 = this.$label$inlined;
                return MathKt.compareValues(Integer.valueOf(!Intrinsics.areEqual((String) obj, obj3) ? 1 : 0), Integer.valueOf(!Intrinsics.areEqual((String) obj2, obj3) ? 1 : 0));
            default:
                Object obj4 = ((Pair) ((Map.Entry) obj).getValue()).first;
                String str5 = (String) this.$label$inlined;
                return MathKt.compareValues(Boolean.valueOf(!Intrinsics.areEqual(obj4, str5)), Boolean.valueOf(!Intrinsics.areEqual(((Pair) ((Map.Entry) obj2).getValue()).first, str5)));
        }
    }
}
