package dev.tvremote.core.ontv;

import dev.tvremote.core.Fleet$$ExternalSyntheticLambda0;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.update.Release;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.StringsKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class OwnApp {
    public final String afterInstall;
    public final String apk;
    public final String none;
    public final String pkg;
    public volatile Seen seen;
    public final String versionKey;

    /* loaded from: classes.dex */
    public final class Seen {
        public final long at;
        public final boolean ok;
        public final Release release;
        public final String version;

        public Seen(long j, String str, Release release, boolean z) {
            this.at = j;
            this.version = str;
            this.release = release;
            this.ok = z;
        }
    }

    public OwnApp(String str, String str2, String str3, String str4, String str5) {
        this.pkg = str;
        this.apk = str2;
        this.versionKey = str3;
        this.none = str4;
        this.afterInstall = str5;
    }

    public final JSONObject install(Adb adb, File file, String lang, Function0 go, Function1 function1) {
        Release release;
        File file2;
        Home$$ExternalSyntheticLambda3 home$$ExternalSyntheticLambda3;
        Seen seen;
        Intrinsics.checkNotNullParameter(adb, "adb");
        Intrinsics.checkNotNullParameter(lang, "lang");
        Intrinsics.checkNotNullParameter(go, "go");
        Fleet$$ExternalSyntheticLambda0 fleet$$ExternalSyntheticLambda0 = new Fleet$$ExternalSyntheticLambda0(adb, 11);
        this.seen = null;
        JSONObject state = state(fleet$$ExternalSyntheticLambda0);
        if (state.has("latest") && (seen = this.seen) != null) {
            release = seen.release;
        } else {
            release = null;
        }
        if (release == null) {
            if (state.optBoolean("installed")) {
                return state;
            }
            throw new IOException(this.none);
        }
        if (file == null) {
            file2 = new File(System.getProperty("java.io.tmpdir"));
        } else {
            file2 = file;
        }
        File file3 = new File(file2, StringsKt.removeSuffix(this.apk, ".apk") + "-" + release.version + ".apk");
        Rescue.check(file, release.sha256, null);
        if (function1 != null) {
            try {
                home$$ExternalSyntheticLambda3 = new Home$$ExternalSyntheticLambda3(1, function1);
            } catch (Throwable th) {
                file3.delete();
                throw th;
            }
        } else {
            home$$ExternalSyntheticLambda3 = null;
        }
        release.download(file3, home$$ExternalSyntheticLambda3);
        if (!((Boolean) go.invoke()).booleanValue()) {
            file3.delete();
            return state;
        }
        String install = new Setup(adb, file, lang, new Bloat$$ExternalSyntheticLambda0(3)).install(file3);
        Rescue.check(file, release.sha256, install);
        if (!StringsKt.contains(install, "Success", false)) {
            String str = (String) CollectionsKt.lastOrNull(StringsKt.lines(StringsKt.trim(install).toString()));
            if (str == null) {
                str = "";
            }
            throw new IOException("launcher:install:".concat(StringsKt.take(str, 200)));
        }
        if (this.afterInstall.length() > 0) {
            fleet$$ExternalSyntheticLambda0.invoke(this.afterInstall);
        }
        file3.delete();
        try {
            adb.shell(120000L, "cmd package compile -m speed -f " + this.pkg + " >/dev/null 2>&1");
        } catch (IOException unused) {
        }
        this.seen = null;
        return state(fleet$$ExternalSyntheticLambda0);
    }

    public final Seen look(String str) {
        String str2;
        Seen seen;
        long currentTimeMillis;
        long j;
        Seen seen2 = this.seen;
        if (seen2 != null && seen2.version.equals(str)) {
            long currentTimeMillis2 = System.currentTimeMillis() - seen2.at;
            if (seen2.ok) {
                j = 21600000;
            } else {
                j = 60000;
            }
            if (currentTimeMillis2 < j) {
                return seen2;
            }
        }
        try {
            currentTimeMillis = System.currentTimeMillis();
            List list = Release.KEYS;
        } catch (Exception unused) {
            str2 = str;
        }
        try {
            seen = new Seen(currentTimeMillis, str, MathKt.newer(str, this.versionKey, this.apk), true);
        } catch (Exception unused2) {
            str2 = str;
            seen = new Seen(System.currentTimeMillis(), str2, null, false);
            this.seen = seen;
            return seen;
        }
        this.seen = seen;
        return seen;
    }

    public final JSONObject state(Function1 function1) {
        String str;
        String str2;
        Pattern compile = Pattern.compile("versionName=(\\S+)");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        CharSequence input = (CharSequence) function1.invoke("dumpsys package " + this.pkg + " | grep -m1 versionName");
        Intrinsics.checkNotNullParameter(input, "input");
        Matcher matcher = compile.matcher(input);
        Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
        boolean z = false;
        MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, input);
        if (access$findNext != null) {
            str = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1);
        } else {
            str = null;
        }
        JSONObject jSONObject = new JSONObject();
        if (str != null) {
            z = true;
        }
        JSONObject put = jSONObject.put("installed", z);
        if (str != null) {
            put.put("version", str);
        }
        if (str == null) {
            str2 = "0";
        } else {
            str2 = str;
        }
        Seen look = look(str2);
        Release release = look.release;
        if (release != null) {
            put.put("latest", release.version);
        }
        boolean z2 = look.ok;
        if (str == null && z2 && release == null) {
            put.put("soon", true);
        }
        if (!z2) {
            put.put("offline", true);
        }
        Intrinsics.checkNotNull(put);
        return put;
    }
}
