package dev.tvremote.core.ontv;

import java.io.IOException;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class ThemeShare$Fail extends IOException {
    public final String code;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ThemeShare$Fail(String str, String msg) {
        super(msg);
        Intrinsics.checkNotNullParameter(msg, "msg");
        this.code = str;
    }
}
