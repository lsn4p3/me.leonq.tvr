package dev.tvremote.core.ontv;

import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Lan$$ExternalSyntheticLambda0;
import dev.tvremote.core.manage.AppsApi;
import dev.tvremote.core.remote.Inputs$parseUnsafe$Raw;
import dev.tvremote.core.remote.Roku;
import dev.tvremote.core.remote.Ssdp;
import java.net.URLEncoder;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Matcher;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.sequences.GeneratorSequence;
import kotlin.sequences.GeneratorSequence$iterator$1;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.conscrypt.FileClientSessionCache;
import org.conscrypt.metrics.ConscryptStatsLog;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class Bloat$$ExternalSyntheticLambda1 implements Function1 {
    public final /* synthetic */ int $r8$classId;

    public /* synthetic */ Bloat$$ExternalSyntheticLambda1(int i) {
        this.$r8$classId = i;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.Long, java.lang.Number] */
    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object it) {
        JSONObject jSONObject;
        String obj;
        ?? longOrNull;
        String str;
        String str2;
        String str3 = null;
        boolean z = false;
        int i = 1;
        switch (this.$r8$classId) {
            case 0:
                String str4 = (String) it;
                Intrinsics.checkNotNull(str4);
                return Boolean.valueOf(Bloat.PKG.matches(str4));
            case 1:
                Intrinsics.checkNotNullParameter(it, "it");
                if (it instanceof JSONObject) {
                    jSONObject = (JSONObject) it;
                } else {
                    jSONObject = null;
                }
                if (jSONObject != null) {
                    str3 = jSONObject.optString("id");
                }
                return Boolean.valueOf(!Intrinsics.areEqual(str3, "a11y"));
            case 2:
                JSONObject o = (JSONObject) it;
                Intrinsics.checkNotNullParameter(o, "o");
                AppsApi.privacyA11yOff$lambda$49$drop("tags", new Lan$$ExternalSyntheticLambda0(29), o);
                AppsApi.privacyA11yOff$lambda$49$drop("ev", new Bloat$$ExternalSyntheticLambda1(i), o);
                return Unit.INSTANCE;
            case 3:
                String it2 = (String) it;
                Intrinsics.checkNotNullParameter(it2, "it");
                String encode = URLEncoder.encode(it2, "UTF-8");
                Intrinsics.checkNotNullExpressionValue(encode, "encode(...)");
                return StringsKt__StringsJVMKt.replace$default(encode, "+", "%20");
            case 4:
                MatcherMatchResult it3 = (MatcherMatchResult) it;
                Intrinsics.checkNotNullParameter(it3, "it");
                return "\\".concat(it3.getValue());
            case 5:
                Byte b = (Byte) it;
                b.byteValue();
                return String.format("%02X", Arrays.copyOf(new Object[]{b}, 1));
            case 6:
                MatcherMatchResult tag = (MatcherMatchResult) it;
                Intrinsics.checkNotNullParameter(tag, "tag");
                GeneratorSequence findAll$default = Regex.findAll$default(AdbAccess.ATTR, tag.getValue());
                LinkedHashMap linkedHashMap = new LinkedHashMap();
                GeneratorSequence$iterator$1 generatorSequence$iterator$1 = new GeneratorSequence$iterator$1(findAll$default);
                while (generatorSequence$iterator$1.hasNext()) {
                    MatcherMatchResult matcherMatchResult = (MatcherMatchResult) generatorSequence$iterator$1.next();
                    linkedHashMap.put(((MatcherMatchResult$groupValues$1) matcherMatchResult.getGroupValues()).get(1), StringsKt__StringsJVMKt.replace$default(StringsKt__StringsJVMKt.replace$default(StringsKt__StringsJVMKt.replace$default(StringsKt__StringsJVMKt.replace$default(StringsKt__StringsJVMKt.replace$default((String) ((MatcherMatchResult$groupValues$1) matcherMatchResult.getGroupValues()).get(2), "&lt;", "<"), "&gt;", ">"), "&quot;", "\""), "&apos;", "'"), "&amp;", "&"));
                }
                String str5 = (String) linkedHashMap.get("key");
                if (str5 == null || (obj = StringsKt.trim(str5).toString()) == null) {
                    return null;
                }
                String str6 = (String) linkedHashMap.get("lastConnection");
                if (str6 != null && (longOrNull = StringsKt__StringNumberConversionsKt.toLongOrNull(str6)) != 0 && longOrNull.longValue() > 0) {
                    str3 = longOrNull;
                }
                return new Pair(obj, str3);
            case 7:
                Byte b2 = (Byte) it;
                b2.byteValue();
                return String.format("%02x", Arrays.copyOf(new Object[]{b2}, 1));
            case 8:
                Intrinsics.checkNotNullParameter((String) it, "it");
                return Unit.INSTANCE;
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                Byte b3 = (Byte) it;
                b3.byteValue();
                return String.format("%02x", Arrays.copyOf(new Object[]{b3}, 1));
            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                String it4 = (String) it;
                Intrinsics.checkNotNullParameter(it4, "it");
                return "'" + it4 + "'";
            case 11:
                Pair it5 = (Pair) it;
                Intrinsics.checkNotNullParameter(it5, "it");
                return (CharSequence) it5.first;
            case FileClientSessionCache.MAX_SIZE /* 12 */:
                String it6 = (String) it;
                Intrinsics.checkNotNullParameter(it6, "it");
                return StringsKt__StringsJVMKt.replace$default(it6, ".", "\\.");
            case 13:
                Intrinsics.checkNotNullParameter((JSONObject) it, "it");
                return Unit.INSTANCE;
            case 14:
                String it7 = (String) it;
                Intrinsics.checkNotNullParameter(it7, "it");
                MatcherMatchResult find = Recents.COMP.find(it7, 0);
                if (find == null) {
                    return null;
                }
                return (String) ((MatcherMatchResult$groupValues$1) find.getGroupValues()).get(1);
            case 15:
                MatcherMatchResult it8 = (MatcherMatchResult) it;
                Intrinsics.checkNotNullParameter(it8, "it");
                return Long.valueOf(Long.parseLong(it8.getValue()));
            case 16:
                Thread.sleep(((Long) it).longValue());
                return Unit.INSTANCE;
            case 17:
                Byte b4 = (Byte) it;
                b4.byteValue();
                return String.format("%02x", Arrays.copyOf(new Object[]{b4}, 1));
            case 18:
                Map.Entry it9 = (Map.Entry) it;
                Intrinsics.checkNotNullParameter(it9, "it");
                return "  " + it9.getKey() + ": " + StringsKt.take((String) it9.getValue(), 160);
            case 19:
                Throwable it10 = (Throwable) it;
                Intrinsics.checkNotNullParameter(it10, "it");
                return it10.getCause();
            case 20:
                Throwable it11 = (Throwable) it;
                Intrinsics.checkNotNullParameter(it11, "it");
                String message = it11.getMessage();
                if (message == null) {
                    return "";
                }
                return message;
            case 21:
                Byte b5 = (Byte) it;
                b5.byteValue();
                return String.format("%02x", Arrays.copyOf(new Object[]{b5}, 1));
            case 22:
                MatcherMatchResult it12 = (MatcherMatchResult) it;
                Intrinsics.checkNotNullParameter(it12, "it");
                return new Pair(((MatcherMatchResult$groupValues$1) it12.getGroupValues()).get(1), ((MatcherMatchResult$groupValues$1) it12.getGroupValues()).get(2));
            case 23:
                Intrinsics.checkNotNullParameter((Inputs$parseUnsafe$Raw) it, "it");
                return Boolean.valueOf(!Intrinsics.areEqual(r10.kind, "hdmi"));
            case 24:
                Inputs$parseUnsafe$Raw it13 = (Inputs$parseUnsafe$Raw) it;
                Intrinsics.checkNotNullParameter(it13, "it");
                if (it13.port == 0) {
                    z = true;
                }
                return Boolean.valueOf(z);
            case 25:
                Inputs$parseUnsafe$Raw it14 = (Inputs$parseUnsafe$Raw) it;
                Intrinsics.checkNotNullParameter(it14, "it");
                return Integer.valueOf(it14.port);
            case 26:
                return Integer.valueOf(((Integer) it).intValue() + 1);
            case 27:
                MatcherMatchResult m = (MatcherMatchResult) it;
                Intrinsics.checkNotNullParameter(m, "m");
                String str7 = (String) ((MatcherMatchResult$groupValues$1) m.getGroupValues()).get(1);
                Matcher m7m = Census$$ExternalSyntheticOutline0.m7m("(?:^|\\s)id=\"([^\"]+)\"", "compile(...)", str7, "input", str7);
                Intrinsics.checkNotNullExpressionValue(m7m, "matcher(...)");
                MatcherMatchResult access$findNext = MathKt.access$findNext(m7m, 0, str7);
                if (access$findNext == null || (str = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)) == null) {
                    return null;
                }
                MatcherMatchResult access$findNext2 = MathKt.access$findNext(Census$$ExternalSyntheticOutline0.m6m("(?:^|\\s)type=\"([^\"]+)\"", "compile(...)", str7, "matcher(...)"), 0, str7);
                if (access$findNext2 == null || (str2 = (String) ((MatcherMatchResult$groupValues$1) access$findNext2.getGroupValues()).get(1)) == null) {
                    str2 = "appl";
                }
                Object obj2 = Roku.KEYS;
                String unescape = Fleet.unescape(StringsKt.trim((String) ((MatcherMatchResult$groupValues$1) m.getGroupValues()).get(2)).toString());
                if (unescape.length() == 0) {
                    unescape = str;
                }
                return new Triple(str, str2, unescape);
            case 28:
                Intrinsics.checkNotNullParameter((Ssdp.Found) it, "it");
                return Unit.INSTANCE;
            default:
                String it15 = (String) it;
                Intrinsics.checkNotNullParameter(it15, "it");
                return Boolean.valueOf(StringsKt__StringsJVMKt.endsWith(it15, false, "/ui_service/data/authentication"));
        }
    }
}
