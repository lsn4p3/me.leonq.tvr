package dev.tvremote.core.ontv;

import java.io.FilterOutputStream;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class AppCopy$CountingOut extends FilterOutputStream {
    public long count;

    @Override // java.io.FilterOutputStream, java.io.OutputStream
    public final void write(int i) {
        ((FilterOutputStream) this).out.write(i);
        this.count++;
    }

    @Override // java.io.FilterOutputStream, java.io.OutputStream
    public final void write(byte[] b, int i, int i2) {
        Intrinsics.checkNotNullParameter(b, "b");
        ((FilterOutputStream) this).out.write(b, i, i2);
        this.count += i2;
    }
}
