package dev.tvremote.core.ontv;

import dev.tvremote.core.Census;
import dev.tvremote.core.Words$$ExternalSyntheticLambda1;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.ontv.LauncherSwap;
import dev.tvremote.core.ontv.Launchers;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.util.List;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.EmptyMap;
import kotlin.collections.SetsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;

/* loaded from: classes.dex */
public final class LauncherInstall {
    public static final Object DOWNLOAD = new Object();
    public final Adb adb;
    public final File dir;
    public final String lang;
    public final Words$$ExternalSyntheticLambda1 sh;
    public final LauncherSwap swap;

    /* loaded from: classes.dex */
    public interface Progress {
        void at(String str, int i);
    }

    public LauncherInstall(Adb adb, File dir, Launchers.Gallery g, String lang) {
        Intrinsics.checkNotNullParameter(dir, "dir");
        Intrinsics.checkNotNullParameter(g, "g");
        Intrinsics.checkNotNullParameter(lang, "lang");
        this.adb = adb;
        this.dir = dir;
        this.lang = lang;
        Words$$ExternalSyntheticLambda1 words$$ExternalSyntheticLambda1 = new Words$$ExternalSyntheticLambda1(4, this);
        this.sh = words$$ExternalSyntheticLambda1;
        this.swap = new LauncherSwap(words$$ExternalSyntheticLambda1);
    }

    public static String sha(File file) {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        FileInputStream fileInputStream = new FileInputStream(file);
        try {
            byte[] bArr = new byte[65536];
            while (true) {
                int read = fileInputStream.read(bArr);
                if (read > 0) {
                    messageDigest.update(bArr, 0, read);
                } else {
                    fileInputStream.close();
                    byte[] digest = messageDigest.digest();
                    Intrinsics.checkNotNullExpressionValue(digest, "digest(...)");
                    return ArraysKt.joinToString$default(digest, "", new Bloat$$ExternalSyntheticLambda1(7));
                }
            }
        } catch (Throwable th) {
            try {
                throw th;
            } catch (Throwable th2) {
                MathKt.closeFinally(fileInputStream, th);
                throw th2;
            }
        }
    }

    public final String run(Launchers.Entry e, int i, Progress progress, Function0 function0) {
        String str;
        String str2;
        String str3;
        String str4;
        Launchers.Apk apk;
        Function0 function02;
        String str5;
        Intrinsics.checkNotNullParameter(e, "e");
        List list = Launchers.KEYS;
        Launchers.Facts facts = Launchers.facts(this.sh);
        Census.Props fits = Launchers.fits(e, facts);
        if (fits.leanback) {
            String homeNow = this.swap.homeNow();
            if (!StringsKt.contains((CharSequence) this.sh.invoke("pm path ".concat(e.pkg)), "package:", false)) {
                if (!e.kind.equals("play")) {
                    if (e.kind.equals("self")) {
                        apk = Launchers.self();
                    } else {
                        apk = Launchers.apk(e, facts.abis);
                        if (apk == null) {
                            throw new IOException("launcher:fit:abi");
                        }
                    }
                    File dir = this.dir;
                    Intrinsics.checkNotNullParameter(dir, "dir");
                    File file = new File(dir, "launcher-" + e.id + "-" + StringsKt.take(apk.sha256, 10) + ".apk");
                    synchronized (DOWNLOAD) {
                        try {
                            if (file.isFile() && Intrinsics.areEqual(sha(file), apk.sha256)) {
                                function02 = function0;
                            }
                            function02 = function0;
                            Launchers.download(apk, file, new Words$$ExternalSyntheticLambda1(5, progress), function02);
                        } catch (Throwable th) {
                            throw th;
                        }
                    }
                    if (!((Boolean) function02.invoke()).booleanValue()) {
                        progress.at("install", 65);
                        try {
                            String install = new Setup(this.adb, this.dir, this.lang, new Bloat$$ExternalSyntheticLambda0(3)).install(file);
                            if (!StringsKt.contains(install, "Success", false)) {
                                String str6 = (String) CollectionsKt.lastOrNull(StringsKt.lines(StringsKt.trim(install).toString()));
                                if (str6 == null) {
                                    str6 = "";
                                }
                                throw new IOException("launcher:install:".concat(StringsKt.take(str6, 200)));
                            }
                            if (StringsKt.contains((CharSequence) this.sh.invoke("pm path ".concat(e.pkg)), "package:", false)) {
                                progress.at("install", 75);
                                try {
                                    Adb adb = this.adb;
                                    if (e.kind.equals("self")) {
                                        str5 = "pm grant dev.tvremote.home android.permission.ACCESS_FINE_LOCATION >/dev/null 2>&1; pm grant dev.tvremote.home android.permission.BLUETOOTH_CONNECT >/dev/null 2>&1; pm grant dev.tvremote.home android.permission.READ_TV_LISTINGS >/dev/null 2>&1; pm grant dev.tvremote.home android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1; ";
                                    } else {
                                        str5 = "";
                                    }
                                    adb.shell(120000L, str5 + "cmd package compile -m speed -f " + e.pkg + " >/dev/null 2>&1");
                                } catch (IOException unused) {
                                }
                            } else {
                                throw new IOException("launcher:install:removed by the TV right after install");
                            }
                        } finally {
                            if (((Boolean) function0.invoke()).booleanValue()) {
                                file.delete();
                            }
                        }
                    } else {
                        throw new IOException("stopped");
                    }
                } else {
                    throw new IOException("launcher:play");
                }
            }
            if (facts.sdk >= 33) {
                List list2 = Launchers.KEYS;
                Words$$ExternalSyntheticLambda1 words$$ExternalSyntheticLambda1 = this.sh;
                if (Launchers.english(e, Launchers.tvLang(words$$ExternalSyntheticLambda1))) {
                    StringBuilder sb = new StringBuilder("cmd locale get-app-locales ");
                    String str7 = e.pkg;
                    sb.append(str7);
                    sb.append(" 2>&1");
                    if (StringsKt__StringsJVMKt.endsWith(StringsKt.trimEnd((String) words$$ExternalSyntheticLambda1.invoke(sb.toString())).toString(), false, "[]")) {
                        StringsKt.contains((CharSequence) words$$ExternalSyntheticLambda1.invoke("cmd locale set-app-locales " + str7 + " --locales en-US 2>&1"), "rror", false);
                    }
                }
            }
            progress.at("swap", 85);
            if (!((Boolean) function0.invoke()).booleanValue()) {
                if (!this.swap.take(e.pkg, i, homeNow)) {
                    String str8 = this.swap.refused;
                    if (str8.length() == 0) {
                        LauncherSwap.Rec state = this.swap.state();
                        if (state != null) {
                            str8 = state.why;
                        } else {
                            str8 = "";
                        }
                    }
                    if (SetsKt.setOf((Object[]) new String[]{"home", "interrupted", "wifi_unknown", "keys", ""}).contains(str8)) {
                        try {
                            String[] strArr = Setup.GOOGLE;
                            if (str8.length() == 0) {
                                str2 = "?";
                            } else {
                                str2 = str8;
                            }
                            String str9 = "launcher:" + ((Object) str2);
                            String shell = this.adb.shell(120000L, "getprop ro.product.manufacturer; getprop ro.product.model; getprop ro.product.device; getprop ro.build.version.release");
                            String str10 = e.pkg;
                            if (this.swap.opened.length() > 0) {
                                str3 = " (Home opens " + this.swap.opened + ")";
                            } else {
                                str3 = "";
                            }
                            Rescue.report(str9, shell, str10 + str3, EmptyMap.INSTANCE);
                        } catch (IOException unused2) {
                        }
                    }
                    if (LauncherSwap.REFUSED.contains(str8)) {
                        str4 = "launcher:rolledback:".concat(str8);
                    } else {
                        str4 = "launcher:home";
                    }
                    throw new IOException(str4);
                }
                if (SetsKt.setOf((Object[]) new String[]{"home", "wifi_unknown"}).contains(this.swap.via)) {
                    try {
                        String[] strArr2 = Setup.GOOGLE;
                        String concat = "launcher:key:".concat(this.swap.via);
                        String shell2 = this.adb.shell(120000L, "getprop ro.product.manufacturer; getprop ro.product.model; getprop ro.product.device; getprop ro.build.version.release");
                        String str11 = e.pkg;
                        if (this.swap.opened.length() > 0) {
                            str = " (Home opens " + this.swap.opened + ")";
                        } else {
                            str = "";
                        }
                        Rescue.report(concat, shell2, str11 + str, EmptyMap.INSTANCE);
                    } catch (IOException unused3) {
                    }
                }
                LauncherSwap.Rec state2 = this.swap.state();
                if (state2 != null) {
                    return state2.state;
                }
                return "kept";
            }
            throw new IOException("stopped");
        }
        throw new IOException("launcher:fit:".concat((String) fits.map));
    }
}
