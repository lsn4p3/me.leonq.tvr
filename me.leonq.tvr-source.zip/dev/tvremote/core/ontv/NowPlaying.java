package dev.tvremote.core.ontv;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.adb.Adb;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class NowPlaying {
    public final Function0 adb;
    public volatile long asked;
    public volatile long at;
    public volatile long failedAt;
    public final Function0 helper;
    public volatile JSONObject last;
    public final Object lock;
    public volatile Adb.Stream stream;

    public NowPlaying(Function0 function0, Function0 helper) {
        Intrinsics.checkNotNullParameter(helper, "helper");
        this.adb = function0;
        this.helper = helper;
        this.last = Census$$ExternalSyntheticOutline0.m9m("state", "none", "put(...)");
        this.lock = new Object();
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0034, code lost:
    
        if (r6.equals("prev") != false) goto L23;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x003d, code lost:
    
        if (r6.equals("play") != false) goto L23;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x0046, code lost:
    
        if (r6.equals("next") != false) goto L23;
     */
    /* JADX WARN: Code restructure failed: missing block: B:4:0x0014, code lost:
    
        if (r6.equals("pause") != false) goto L23;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0048, code lost:
    
        r0 = r6;
     */
    /* JADX WARN: Failed to find 'out' block for switch in B:2:0x0009. Please report as an issue. */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void command(long j, String what) {
        Intrinsics.checkNotNullParameter(what, "what");
        switch (what.hashCode()) {
            case 3377907:
                break;
            case 3443508:
                break;
            case 3449395:
                break;
            case 3526264:
                if (what.equals("seek")) {
                    long j2 = 0;
                    if (j >= 0) {
                        j2 = j;
                    }
                    String m = ApkSigner$$ExternalSyntheticOutline0.m(j2, "seek ");
                    this.asked = System.currentTimeMillis();
                    start();
                    Adb.Stream stream = this.stream;
                    if (stream != null) {
                        byte[] bytes = Census$$ExternalSyntheticOutline0.m(m, "\n").getBytes(Charsets.UTF_8);
                        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                        stream.write(bytes);
                        if (what.equals("seek")) {
                            synchronized (this.lock) {
                                JSONObject put = new JSONObject(this.last.toString()).put("pos", j);
                                Intrinsics.checkNotNullExpressionValue(put, "put(...)");
                                this.last = put;
                                this.at = System.currentTimeMillis();
                            }
                            return;
                        }
                        return;
                    }
                    throw new IOException("the TV did not answer");
                }
                throw new IllegalArgumentException("unknown: ".concat(what));
            case 106440182:
                break;
            default:
                throw new IllegalArgumentException("unknown: ".concat(what));
        }
    }

    public final void start() {
        final int i = 1;
        synchronized (this.lock) {
            if (this.stream == null && System.currentTimeMillis() - this.failedAt >= 10000) {
                try {
                    Adb adb = (Adb) this.adb.invoke();
                    String str = "shell:CLASSPATH=" + RemoteLabels.Companion.install(adb, (byte[]) this.helper.invoke()) + " app_process / dev.tvremote.core.Playing 2>/dev/null";
                    ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                    final Adb.Stream open = adb.open(10000L, str);
                    this.stream = open;
                    final int i2 = 0;
                    Thread thread = new Thread(new Runnable(this) { // from class: dev.tvremote.core.ontv.NowPlaying$$ExternalSyntheticLambda0
                        public final /* synthetic */ NowPlaying f$0;

                        {
                            this.f$0 = this;
                        }

                        @Override // java.lang.Runnable
                        public final void run() {
                            Object obj;
                            int read;
                            switch (i2) {
                                case 0:
                                    NowPlaying nowPlaying = this.f$0;
                                    Adb.Stream stream = open;
                                    nowPlaying.getClass();
                                    byte[] bArr = new byte[8192];
                                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                                    while (true) {
                                        try {
                                            try {
                                                read = stream.read(0L, bArr, 0, 8192);
                                            } catch (IOException unused) {
                                                obj = nowPlaying.lock;
                                                synchronized (obj) {
                                                    try {
                                                        if (nowPlaying.stream == stream) {
                                                            nowPlaying.stream = null;
                                                        }
                                                        if (nowPlaying.last.has("error")) {
                                                            nowPlaying.failedAt = System.currentTimeMillis();
                                                        }
                                                        JSONObject put = new JSONObject().put("state", "none");
                                                        Intrinsics.checkNotNullExpressionValue(put, "put(...)");
                                                        nowPlaying.last = put;
                                                    } catch (Throwable th) {
                                                        throw th;
                                                    }
                                                }
                                            }
                                            if (read >= 0) {
                                                for (int i3 = 0; i3 < read; i3++) {
                                                    byte b = bArr[i3];
                                                    if (b != 10) {
                                                        byteArrayOutputStream.write(b);
                                                    } else {
                                                        String byteArrayOutputStream2 = byteArrayOutputStream.toString("UTF-8");
                                                        Intrinsics.checkNotNullExpressionValue(byteArrayOutputStream2, "toString(...)");
                                                        String obj2 = StringsKt.trim(byteArrayOutputStream2).toString();
                                                        byteArrayOutputStream.reset();
                                                        try {
                                                            JSONObject jSONObject = new JSONObject(obj2);
                                                            synchronized (nowPlaying.lock) {
                                                                nowPlaying.last = jSONObject;
                                                                nowPlaying.at = System.currentTimeMillis();
                                                            }
                                                        } catch (Exception unused2) {
                                                        }
                                                    }
                                                }
                                            } else {
                                                obj = nowPlaying.lock;
                                                synchronized (obj) {
                                                    try {
                                                        if (nowPlaying.stream == stream) {
                                                            nowPlaying.stream = null;
                                                        }
                                                        if (nowPlaying.last.has("error")) {
                                                            nowPlaying.failedAt = System.currentTimeMillis();
                                                        }
                                                        JSONObject put2 = new JSONObject().put("state", "none");
                                                        Intrinsics.checkNotNullExpressionValue(put2, "put(...)");
                                                        nowPlaying.last = put2;
                                                        stream.close();
                                                        return;
                                                    } catch (Throwable th2) {
                                                        throw th2;
                                                    }
                                                }
                                            }
                                        } catch (Throwable th3) {
                                            synchronized (nowPlaying.lock) {
                                                try {
                                                    if (nowPlaying.stream == stream) {
                                                        nowPlaying.stream = null;
                                                    }
                                                    if (nowPlaying.last.has("error")) {
                                                        nowPlaying.failedAt = System.currentTimeMillis();
                                                    }
                                                    JSONObject put3 = new JSONObject().put("state", "none");
                                                    Intrinsics.checkNotNullExpressionValue(put3, "put(...)");
                                                    nowPlaying.last = put3;
                                                    stream.close();
                                                    throw th3;
                                                } catch (Throwable th4) {
                                                    throw th4;
                                                }
                                            }
                                        }
                                    }
                                default:
                                    NowPlaying nowPlaying2 = this.f$0;
                                    Adb.Stream stream2 = open;
                                    while (nowPlaying2.stream == stream2 && System.currentTimeMillis() - nowPlaying2.asked < 20000) {
                                        try {
                                            byte[] bytes = "\n".getBytes(Charsets.UTF_8);
                                            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                                            stream2.write(bytes);
                                            Thread.sleep(8000L);
                                        } catch (Exception unused3) {
                                        }
                                    }
                                    stream2.close();
                                    return;
                            }
                        }
                    }, "now-playing");
                    thread.setDaemon(true);
                    thread.start();
                    Thread thread2 = new Thread(new Runnable(this) { // from class: dev.tvremote.core.ontv.NowPlaying$$ExternalSyntheticLambda0
                        public final /* synthetic */ NowPlaying f$0;

                        {
                            this.f$0 = this;
                        }

                        @Override // java.lang.Runnable
                        public final void run() {
                            Object obj;
                            int read;
                            switch (i) {
                                case 0:
                                    NowPlaying nowPlaying = this.f$0;
                                    Adb.Stream stream = open;
                                    nowPlaying.getClass();
                                    byte[] bArr = new byte[8192];
                                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                                    while (true) {
                                        try {
                                            try {
                                                read = stream.read(0L, bArr, 0, 8192);
                                            } catch (IOException unused) {
                                                obj = nowPlaying.lock;
                                                synchronized (obj) {
                                                    try {
                                                        if (nowPlaying.stream == stream) {
                                                            nowPlaying.stream = null;
                                                        }
                                                        if (nowPlaying.last.has("error")) {
                                                            nowPlaying.failedAt = System.currentTimeMillis();
                                                        }
                                                        JSONObject put = new JSONObject().put("state", "none");
                                                        Intrinsics.checkNotNullExpressionValue(put, "put(...)");
                                                        nowPlaying.last = put;
                                                    } catch (Throwable th) {
                                                        throw th;
                                                    }
                                                }
                                            }
                                            if (read >= 0) {
                                                for (int i3 = 0; i3 < read; i3++) {
                                                    byte b = bArr[i3];
                                                    if (b != 10) {
                                                        byteArrayOutputStream.write(b);
                                                    } else {
                                                        String byteArrayOutputStream2 = byteArrayOutputStream.toString("UTF-8");
                                                        Intrinsics.checkNotNullExpressionValue(byteArrayOutputStream2, "toString(...)");
                                                        String obj2 = StringsKt.trim(byteArrayOutputStream2).toString();
                                                        byteArrayOutputStream.reset();
                                                        try {
                                                            JSONObject jSONObject = new JSONObject(obj2);
                                                            synchronized (nowPlaying.lock) {
                                                                nowPlaying.last = jSONObject;
                                                                nowPlaying.at = System.currentTimeMillis();
                                                            }
                                                        } catch (Exception unused2) {
                                                        }
                                                    }
                                                }
                                            } else {
                                                obj = nowPlaying.lock;
                                                synchronized (obj) {
                                                    try {
                                                        if (nowPlaying.stream == stream) {
                                                            nowPlaying.stream = null;
                                                        }
                                                        if (nowPlaying.last.has("error")) {
                                                            nowPlaying.failedAt = System.currentTimeMillis();
                                                        }
                                                        JSONObject put2 = new JSONObject().put("state", "none");
                                                        Intrinsics.checkNotNullExpressionValue(put2, "put(...)");
                                                        nowPlaying.last = put2;
                                                        stream.close();
                                                        return;
                                                    } catch (Throwable th2) {
                                                        throw th2;
                                                    }
                                                }
                                            }
                                        } catch (Throwable th3) {
                                            synchronized (nowPlaying.lock) {
                                                try {
                                                    if (nowPlaying.stream == stream) {
                                                        nowPlaying.stream = null;
                                                    }
                                                    if (nowPlaying.last.has("error")) {
                                                        nowPlaying.failedAt = System.currentTimeMillis();
                                                    }
                                                    JSONObject put3 = new JSONObject().put("state", "none");
                                                    Intrinsics.checkNotNullExpressionValue(put3, "put(...)");
                                                    nowPlaying.last = put3;
                                                    stream.close();
                                                    throw th3;
                                                } catch (Throwable th4) {
                                                    throw th4;
                                                }
                                            }
                                        }
                                    }
                                default:
                                    NowPlaying nowPlaying2 = this.f$0;
                                    Adb.Stream stream2 = open;
                                    while (nowPlaying2.stream == stream2 && System.currentTimeMillis() - nowPlaying2.asked < 20000) {
                                        try {
                                            byte[] bytes = "\n".getBytes(Charsets.UTF_8);
                                            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                                            stream2.write(bytes);
                                            Thread.sleep(8000L);
                                        } catch (Exception unused3) {
                                        }
                                    }
                                    stream2.close();
                                    return;
                            }
                        }
                    }, "now-playing-beat");
                    thread2.setDaemon(true);
                    thread2.start();
                } catch (Exception unused) {
                    this.failedAt = System.currentTimeMillis();
                }
            }
        }
    }

    public final JSONObject state() {
        this.asked = System.currentTimeMillis();
        start();
        JSONObject jSONObject = new JSONObject(this.last.toString());
        if (Intrinsics.areEqual(jSONObject.optString("state"), "playing") && jSONObject.has("pos")) {
            long j = jSONObject.getLong("pos") + ((long) (jSONObject.optDouble("speed", 1.0d) * (System.currentTimeMillis() - this.at)));
            if (jSONObject.optLong("dur") > 0) {
                j = Math.min(j, jSONObject.getLong("dur"));
            }
            jSONObject.put("pos", j);
        }
        return jSONObject;
    }
}
