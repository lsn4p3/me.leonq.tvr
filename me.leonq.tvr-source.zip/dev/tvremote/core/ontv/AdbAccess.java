package dev.tvremote.core.ontv;

import dev.tvremote.core.B64;
import java.net.InetAddress;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.CollectionsKt__MutableCollectionsKt;
import kotlin.collections.EmptyList;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgression;
import kotlin.ranges.IntRange;
import kotlin.sequences.SequencesKt;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.RegexOption;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;

/* loaded from: classes.dex */
public abstract class AdbAccess {
    public static final IntRange CLEAR_KEYS = new IntProgression(30, 36, 1);
    public static final Regex KEY = new Regex("(QAAAA[A-Za-z0-9+/]+={0,2})(?:[ \\t]+([^\\r\\n\"]*))?");
    public static final Regex KEY_TAG = new Regex("<adbKey\\b[^>]*>");
    public static final Regex ATTR = new Regex("([\\w-]+)=\"([^\"]*)\"");
    public static final Regex NEXT_FIELD = new Regex("^\\s*(?:[a-z_]+=|[{}])", RegexOption.MULTILINE);
    public static final String READ = "dumpsys adb 2>&1; echo =====TVR=====; getprop service.adb.tls.port; getprop service.adb.tcp.port; echo =====TVR=====; cat /proc/net/tcp6 /proc/net/tcp 2>/dev/null; echo =====TVR=====; getprop ro.build.version.sdk";
    public static final Regex FP = new Regex("(?:[0-9A-F]{2}:){15}[0-9A-F]{2}");

    /* loaded from: classes.dex */
    public final class Client {
        public final String address;
        public final int port;

        public Client(String address, int i) {
            Intrinsics.checkNotNullParameter(address, "address");
            this.address = address;
            this.port = i;
        }
    }

    /* loaded from: classes.dex */
    public final class Key {
        public final String fingerprint;
        public final Long lastSeen;
        public final String name;

        public Key(String str, String str2, Long l) {
            this.fingerprint = str;
            this.name = str2;
            this.lastSeen = l;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:13:0x00eb  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static Pair endpoint(String str) {
        Integer intOrNull;
        String hostAddress;
        List split$default = StringsKt.split$default(str, new char[]{':'});
        if (split$default.size() != 2) {
            split$default = null;
        }
        if (split$default != null && (intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull((String) split$default.get(1), 16)) != null) {
            String hex = (String) split$default.get(0);
            Intrinsics.checkNotNullParameter(hex, "hex");
            if (hex.length() == 8 || hex.length() == 32) {
                try {
                    ArrayList chunked = StringsKt.chunked(hex, 8);
                    ArrayList arrayList = new ArrayList();
                    Iterator it = chunked.iterator();
                    while (it.hasNext()) {
                        ArrayList chunked2 = StringsKt.chunked((String) it.next(), 2);
                        ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(chunked2));
                        Iterator it2 = chunked2.iterator();
                        while (it2.hasNext()) {
                            String str2 = (String) it2.next();
                            MathKt.checkRadix(16);
                            arrayList2.add(Byte.valueOf((byte) Integer.parseInt(str2, 16)));
                        }
                        CollectionsKt__MutableCollectionsKt.addAll(CollectionsKt.reversed(arrayList2), arrayList);
                    }
                    byte[] byteArray = CollectionsKt.toByteArray(arrayList);
                    if (byteArray.length == 16) {
                        List take = ArraysKt.take(10, byteArray);
                        if (!take.isEmpty()) {
                            Iterator it3 = take.iterator();
                            while (it3.hasNext()) {
                                if (((Number) it3.next()).byteValue() != 0) {
                                    break;
                                }
                            }
                        }
                        if (byteArray[10] == -1 && byteArray[11] == -1) {
                            byteArray = ArraysKt.copyOfRange(byteArray, 12, 16);
                        }
                    }
                    hostAddress = InetAddress.getByAddress(byteArray).getHostAddress();
                } catch (NumberFormatException unused) {
                }
                if (hostAddress != null) {
                    if (hostAddress.equals("0:0:0:0:0:0:0:1")) {
                        hostAddress = "::1";
                    }
                    if (hostAddress != null) {
                        return new Pair(hostAddress, intOrNull);
                    }
                }
            }
            hostAddress = null;
            if (hostAddress != null) {
            }
        }
        return null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:17:0x007a A[LOOP:0: B:15:0x0074->B:17:0x007a, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:47:0x017e A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:51:0x0100 A[SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r1v11, types: [java.util.ArrayList] */
    /* JADX WARN: Type inference failed for: r1v2 */
    /* JADX WARN: Type inference failed for: r1v3 */
    /* JADX WARN: Type inference failed for: r1v4, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r1v7, types: [kotlin.collections.EmptyList] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static ArrayList keys(String dumpsys) {
        ?? r1;
        Regex regex;
        String str;
        Key key;
        Pair pair;
        int length;
        Iterator it;
        Intrinsics.checkNotNullParameter(dumpsys, "dumpsys");
        if (!StringsKt.contains(dumpsys, "debugging_manager", false)) {
            return null;
        }
        List list = SequencesKt.toList(SequencesKt.mapNotNull(Regex.findAll$default(KEY_TAG, dumpsys), new Bloat$$ExternalSyntheticLambda1(6)));
        int indexOf$default = StringsKt.indexOf$default(dumpsys, "user_keys=", 0, false, 6);
        Integer valueOf = Integer.valueOf(indexOf$default);
        if (indexOf$default < 0) {
            valueOf = null;
        }
        if (valueOf != null) {
            int intValue = valueOf.intValue() + 10;
            MatcherMatchResult find = NEXT_FIELD.find(dumpsys, intValue);
            if (find != null) {
                Matcher matcher = find.matcher;
                IntRange until = MathKt.until(matcher.start(), matcher.end());
                if (until != null) {
                    length = until.first;
                    String substring = dumpsys.substring(intValue, length);
                    Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
                    List lines = StringsKt.lines(substring);
                    r1 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(lines));
                    it = lines.iterator();
                    while (it.hasNext()) {
                        r1.add(StringsKt.trim((String) it.next()).toString());
                    }
                }
            }
            length = dumpsys.length();
            String substring2 = dumpsys.substring(intValue, length);
            Intrinsics.checkNotNullExpressionValue(substring2, "substring(...)");
            List lines2 = StringsKt.lines(substring2);
            r1 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(lines2));
            it = lines2.iterator();
            while (it.hasNext()) {
            }
        } else {
            r1 = 0;
        }
        if (r1 == 0) {
            r1 = EmptyList.INSTANCE;
        }
        ArrayList arrayList = new ArrayList();
        Iterator it2 = list.iterator();
        while (true) {
            boolean hasNext = it2.hasNext();
            regex = KEY;
            if (!hasNext) {
                break;
            }
            Pair pair2 = (Pair) it2.next();
            String str2 = (String) pair2.first;
            Long l = (Long) pair2.second;
            MatcherMatchResult matchEntire = regex.matchEntire(str2);
            if (matchEntire != null) {
                pair = new Pair(((MatcherMatchResult$groupValues$1) matchEntire.getGroupValues()).get(1), l);
            } else {
                pair = null;
            }
            if (pair != null) {
                arrayList.add(pair);
            }
        }
        Map map = MapsKt__MapsKt.toMap(arrayList);
        ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(list));
        Iterator it3 = list.iterator();
        while (it3.hasNext()) {
            arrayList2.add((String) ((Pair) it3.next()).first);
        }
        ArrayList plus = CollectionsKt.plus((List) r1, (Iterable) arrayList2);
        ArrayList arrayList3 = new ArrayList();
        Iterator it4 = plus.iterator();
        while (it4.hasNext()) {
            MatcherMatchResult matchEntire2 = regex.matchEntire((String) it4.next());
            if (matchEntire2 != null) {
                String base64 = (String) ((MatcherMatchResult$groupValues$1) matchEntire2.getGroupValues()).get(1);
                Intrinsics.checkNotNullParameter(base64, "base64");
                try {
                    byte[] digest = MessageDigest.getInstance("MD5").digest(B64.decode(base64));
                    Intrinsics.checkNotNullExpressionValue(digest, "digest(...)");
                    str = ArraysKt.joinToString$default(digest, ":", new Bloat$$ExternalSyntheticLambda1(5));
                } catch (Exception unused) {
                    str = null;
                }
                if (str != null) {
                    String obj = StringsKt.trim((String) ((MatcherMatchResult$groupValues$1) matchEntire2.getGroupValues()).get(2)).toString();
                    if (obj.length() <= 0) {
                        obj = null;
                    }
                    key = new Key(str, obj, (Long) map.get(((MatcherMatchResult$groupValues$1) matchEntire2.getGroupValues()).get(1)));
                    if (key == null) {
                        arrayList3.add(key);
                    }
                }
            }
            key = null;
            if (key == null) {
            }
        }
        HashSet hashSet = new HashSet();
        ArrayList arrayList4 = new ArrayList();
        Iterator it5 = arrayList3.iterator();
        while (it5.hasNext()) {
            Object next = it5.next();
            if (hashSet.add(((Key) next).fingerprint)) {
                arrayList4.add(next);
            }
        }
        return arrayList4;
    }
}
