package dev.tvremote.core.ontv;

import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.widget.Button;
import android.widget.LinearLayout;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Words;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.remote.Inputs;
import dev.tvremote.core.remote.Lg;
import dev.tvremote.core.web.HttpServer;
import dev.tvremote.phone.MainActivity$onCreate$2;
import dev.tvremote.phone.media.NowApp;
import dev.tvremote.phone.picker.AppRow;
import dev.tvremote.phone.picker.NetKt$reachAroundVpn$2$1;
import dev.tvremote.phone.picker.Part;
import dev.tvremote.phone.picture.DrawingKt$$ExternalSyntheticLambda3;
import dev.tvremote.phone.ui.UiKt;
import java.io.InputStream;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.EmptyList;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$ObjectRef;
import kotlin.math.MathKt;
import kotlin.text.MatcherMatchResult;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.conscrypt.FileClientSessionCache;
import org.conscrypt.metrics.ConscryptStatsLog;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class Setup$$ExternalSyntheticLambda5 implements Function0 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;

    public /* synthetic */ Setup$$ExternalSyntheticLambda5(int i, Object obj) {
        this.$r8$classId = i;
        this.f$0 = obj;
    }

    /* JADX WARN: Type inference failed for: r2v0 */
    /* JADX WARN: Type inference failed for: r2v23 */
    /* JADX WARN: Type inference failed for: r2v4, types: [boolean, int] */
    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        JSONArray optJSONArray;
        String str;
        int i;
        String optString;
        Object obj;
        String str2;
        Boolean bool;
        Iterator it;
        int i2;
        Integer intOrNull;
        String str3;
        NetworkCapabilities networkCapabilities;
        boolean z;
        Network network;
        Network activeNetwork;
        String str4 = "";
        ?? r2 = 0;
        int i3 = 0;
        switch (this.$r8$classId) {
            case 0:
                return ((AdbLink) this.f$0).get();
            case 1:
                try {
                    ((Adb) this.f$0).shell(15000L, "am broadcast -n dev.tvremote.setup/.TrustReceiver --es want adbkey");
                } catch (Exception unused) {
                }
                return Unit.INSTANCE;
            case 2:
                ((HttpURLConnection) this.f$0).disconnect();
                return Unit.INSTANCE;
            case 3:
                ((Tv.Listener) this.f$0).onStatus("error", "decoder");
                return Unit.INSTANCE;
            case 4:
                Object obj2 = Inputs.TYPES;
                JSONObject request$default = Lg.request$default((Lg) this.f$0, "ssap://tv/getExternalInputList", null, 0L, 6);
                if (request$default != null && (optJSONArray = request$default.optJSONArray("devices")) != null) {
                    ArrayList arrayList = new ArrayList();
                    int length = optJSONArray.length();
                    int i4 = 0;
                    while (i4 < length) {
                        JSONObject optJSONObject = optJSONArray.optJSONObject(i4);
                        if (optJSONObject != null) {
                            String optString2 = optJSONObject.optString("id");
                            Intrinsics.checkNotNull(optString2);
                            if (optString2.length() != 0) {
                                String lowerCase = optString2.toLowerCase(Locale.ROOT);
                                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                                if (StringsKt__StringsJVMKt.startsWith(lowerCase, r2, "hdmi")) {
                                    str = "hdmi";
                                } else {
                                    str = "av";
                                    if (!StringsKt__StringsJVMKt.startsWith(lowerCase, r2, "av") && (!StringsKt__StringsJVMKt.startsWith(lowerCase, r2, "comp") || StringsKt__StringsJVMKt.startsWith(lowerCase, r2, "component"))) {
                                        str = StringsKt__StringsJVMKt.startsWith(lowerCase, r2, "component") ? "component" : "other";
                                    }
                                }
                                if (str.equals("hdmi")) {
                                    MatcherMatchResult access$findNext = MathKt.access$findNext(Census$$ExternalSyntheticOutline0.m6m("(\\d+)", "compile(...)", optString2, "matcher(...)"), r2, optString2);
                                    if (access$findNext != null && (intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull(access$findNext.getValue())) != null) {
                                        i2 = intOrNull.intValue();
                                    } else {
                                        i2 = 0;
                                    }
                                    i = optJSONObject.optInt("port", i2);
                                } else {
                                    i = 0;
                                }
                                if (str.equals("hdmi")) {
                                    optString = ApkSigner$$ExternalSyntheticOutline0.m("HDMI ", i);
                                } else {
                                    optString = optJSONObject.optString("label");
                                    if (optString.length() == 0) {
                                        optString = StringsKt__StringsJVMKt.replace$default(optString2, '_', ' ');
                                    }
                                }
                                String optString3 = optJSONObject.optString("label");
                                Intrinsics.checkNotNullExpressionValue(optString3, "optString(...)");
                                String obj3 = StringsKt.trim(optString3).toString();
                                String optString4 = optJSONObject.optString("modelName");
                                Intrinsics.checkNotNullExpressionValue(optString4, "optString(...)");
                                Iterator it2 = ArraysKt.asList(new String[]{obj3, StringsKt.trim(optString4).toString()}).iterator();
                                while (true) {
                                    if (it2.hasNext()) {
                                        obj = it2.next();
                                        String str5 = (String) obj;
                                        if (str5.length() > 0) {
                                            String replace$default = StringsKt__StringsJVMKt.replace$default(str5, " ", "");
                                            Intrinsics.checkNotNull(optString);
                                            it = it2;
                                            if (!replace$default.equalsIgnoreCase(StringsKt__StringsJVMKt.replace$default(optString, " ", "")) && !StringsKt__StringsJVMKt.replace$default(str5, " ", "").equalsIgnoreCase(StringsKt__StringsJVMKt.replace$default(optString2, "_", ""))) {
                                            }
                                        } else {
                                            it = it2;
                                        }
                                        it2 = it;
                                    } else {
                                        obj = null;
                                    }
                                }
                                String str6 = (String) obj;
                                if (str6 == null) {
                                    str2 = "";
                                } else {
                                    str2 = str6;
                                }
                                if (str2.length() != 0) {
                                    optString = Census$$ExternalSyntheticOutline0.m(optString, " · ", str2);
                                }
                                String str7 = optString;
                                Intrinsics.checkNotNull(str7);
                                if (optJSONObject.has("connected")) {
                                    bool = Boolean.valueOf(optJSONObject.optBoolean("connected"));
                                } else {
                                    bool = null;
                                }
                                arrayList.add(new Inputs.Input(optString2, str, i, str2, str7, bool, 64, 0));
                                i4++;
                                r2 = 0;
                            }
                        }
                        i4++;
                        r2 = 0;
                    }
                    return arrayList;
                }
                return EmptyList.INSTANCE;
            case 5:
                ConcurrentHashMap concurrentHashMap = Words.books;
                HttpServer.Request request = (HttpServer.Request) this.f$0;
                String cookie = request.cookie("tvr-lang");
                if (cookie.length() == 0) {
                    cookie = request.q("lang");
                }
                if (cookie.length() == 0) {
                    String str8 = (String) request.headers.get("accept-language");
                    if (str8 != null) {
                        str4 = str8;
                    }
                    cookie = StringsKt.substringBefore(str4, ',', str4);
                }
                return Words.pick(cookie);
            case 6:
                Object obj4 = ((Ref$ObjectRef) this.f$0).element;
                if (obj4 != null) {
                    UiKt.setToggle((Button) obj4, Census.getEnabled(), Fleet.T("about.census", new Pair[0]));
                    return Unit.INSTANCE;
                }
                Intrinsics.throwUninitializedPropertyAccessException("censusRow");
                throw null;
            case 7:
                boolean enabled = Census.getEnabled();
                MainActivity$onCreate$2 mainActivity$onCreate$2 = Census.store;
                if (mainActivity$onCreate$2 != null) {
                    if (!enabled) {
                        str3 = "1";
                    } else {
                        str3 = "0";
                    }
                    mainActivity$onCreate$2.put("census.on", str3);
                }
                ((Setup$$ExternalSyntheticLambda5) this.f$0).invoke();
                return Unit.INSTANCE;
            case 8:
                InputStream open = ((NowApp) this.f$0).a.getAssets().open("tvr-helper.jar");
                try {
                    Intrinsics.checkNotNull(open);
                    byte[] readBytes = MathKt.readBytes(open);
                    MathKt.closeFinally(open, null);
                    return readBytes;
                } catch (Throwable th) {
                    try {
                        throw th;
                    } catch (Throwable th2) {
                        MathKt.closeFinally(open, th);
                        throw th2;
                    }
                }
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                return Boolean.valueOf(((Part) this.f$0).cancel.stopped);
            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                Iterator it3 = ((ArrayList) this.f$0).iterator();
                while (it3.hasNext()) {
                    ((AdbLink) it3.next()).close();
                }
                return Unit.INSTANCE;
            case 11:
                ArrayList arrayList2 = new ArrayList();
                for (Object obj5 : (List) this.f$0) {
                    LinearLayout linearLayout = ((AppRow) obj5).view;
                    if (linearLayout != null) {
                        if (linearLayout.getVisibility() == 0) {
                            arrayList2.add(obj5);
                        }
                    } else {
                        Intrinsics.throwUninitializedPropertyAccessException("view");
                        throw null;
                    }
                }
                return arrayList2;
            case FileClientSessionCache.MAX_SIZE /* 12 */:
                ConnectivityManager connectivityManager = (ConnectivityManager) this.f$0;
                if (Build.VERSION.SDK_INT < 23) {
                    return null;
                }
                try {
                    activeNetwork = connectivityManager.getActiveNetwork();
                    networkCapabilities = connectivityManager.getNetworkCapabilities(activeNetwork);
                } catch (Exception unused2) {
                    networkCapabilities = null;
                }
                if (networkCapabilities != null && networkCapabilities.hasTransport(4)) {
                    z = true;
                } else {
                    z = false;
                }
                if (networkCapabilities != null && !z && (networkCapabilities.hasTransport(1) || networkCapabilities.hasTransport(3))) {
                    return null;
                }
                Network[] allNetworks = connectivityManager.getAllNetworks();
                Intrinsics.checkNotNullExpressionValue(allNetworks, "getAllNetworks(...)");
                int length2 = allNetworks.length;
                while (true) {
                    if (i3 < length2) {
                        network = allNetworks[i3];
                        NetworkCapabilities networkCapabilities2 = connectivityManager.getNetworkCapabilities(network);
                        if (networkCapabilities2 == null || networkCapabilities2.hasTransport(4) || (!networkCapabilities2.hasTransport(1) && !networkCapabilities2.hasTransport(3))) {
                            i3++;
                        }
                    } else {
                        network = null;
                    }
                }
                if (network == null) {
                    return null;
                }
                return new NetKt$reachAroundVpn$2$1(z, network, connectivityManager);
            case 13:
                ((DrawingKt$$ExternalSyntheticLambda3) this.f$0).invoke();
                return Unit.INSTANCE;
            default:
                return (Serializable) this.f$0;
        }
    }
}
