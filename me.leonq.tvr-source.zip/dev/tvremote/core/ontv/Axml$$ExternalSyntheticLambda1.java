package dev.tvremote.core.ontv;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.Mdns;
import dev.tvremote.core.adb.TvShell;
import dev.tvremote.core.manage.AppsApi;
import dev.tvremote.core.manage.FilesApi;
import dev.tvremote.core.manage.HomeApi;
import dev.tvremote.core.ontv.Axml;
import dev.tvremote.core.web.HttpServer;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function3;

/* loaded from: classes.dex */
public final /* synthetic */ class Axml$$ExternalSyntheticLambda1 implements HttpServer.Body, Function3 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;
    public final /* synthetic */ Object f$1;
    public final /* synthetic */ Serializable f$2;

    public /* synthetic */ Axml$$ExternalSyntheticLambda1(Object obj, Object obj2, Serializable serializable, int i) {
        this.$r8$classId = i;
        this.f$0 = obj;
        this.f$1 = obj2;
        this.f$2 = serializable;
    }

    @Override // kotlin.jvm.functions.Function3
    public Object invoke(Object obj, Object obj2, Object obj3) {
        int i;
        String str = (String) obj;
        String str2 = (String) obj2;
        int intValue = ((Integer) obj3).intValue();
        ArrayList arrayList = ((Axml.Pool) this.f$0).strings;
        Set set = Axml.CLASS_ELEMENTS;
        byte[] bArr = (byte[]) this.f$1;
        if ((bArr[intValue + 15] & 255) == 3) {
            i = Axml.i32(intValue + 16, bArr);
        } else {
            i = -1;
        }
        String str3 = (String) CollectionsKt.getOrNull(i, arrayList);
        if (str3 != null) {
            ((ArrayList) this.f$2).add(new Triple(str, str2, str3));
        }
        return Unit.INSTANCE;
    }

    @Override // dev.tvremote.core.web.HttpServer.Body
    public void write(HttpServer.Stall stall) {
        Object obj = this.f$0;
        Object obj2 = this.f$1;
        Serializable serializable = this.f$2;
        switch (this.$r8$classId) {
            case 1:
                TvShell tvShell = TvShell.INSTANCE;
                String str = (String) serializable;
                TvShell.pkg(str);
                ((AppsApi) obj).pipe(((Adb) obj2).exec("trap '' HUP PIPE; p=" + str + "; d=/data/local/tmp/tvr-bk-$$; rm -rf $d; mkdir -p $d/apk && cd $d || exit 1; for f in $(pm path $p | sed 's/^package://'); do ln -s \"$f\" apk/${f##*/}; done; for k in obb data; do [ -d /sdcard/Android/$k/$p ] && ln -s /sdcard/Android/$k/$p $k; done; echo $p > package.txt; dumpsys package $p | grep -m1 versionName | cut -d= -f2 > version.txt; tar -chf - * 2>/dev/null; cd /; rm -rf $d"), stall);
                return;
            case 2:
                ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                ((FilesApi) obj).pipe(((Adb) obj2).exec(ApkSigner$$ExternalSyntheticOutline0.m("cat ", Mdns.q((String) serializable), " 2>/dev/null")), stall);
                return;
            default:
                ConcurrentHashMap concurrentHashMap2 = Adb.ASKING;
                ((HomeApi) obj).pipe(((Adb) obj2).exec(ApkSigner$$ExternalSyntheticOutline0.m("cat ", Mdns.q((String) serializable), " 2>/dev/null")), stall);
                return;
        }
    }
}
