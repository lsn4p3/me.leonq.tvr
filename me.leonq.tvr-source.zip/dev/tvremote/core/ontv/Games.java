package dev.tvremote.core.ontv;

import dev.tvremote.core.B64;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Fleet$$ExternalSyntheticLambda0;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.Mdns;
import dev.tvremote.core.manage.Manage$$ExternalSyntheticLambda18;
import dev.tvremote.core.ontv.Checkout;
import dev.tvremote.core.picture.Jpeg;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.web.HttpServer;
import dev.tvremote.home.HomeConfig;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyList;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$BooleanRef;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgressionIterator;
import kotlin.ranges.IntRange;
import kotlin.text.Charsets;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public abstract class Games {
    public static final OwnApp app = new OwnApp("dev.tvremote.games", "tv-games.apk", "games", "games:none", "appops set dev.tvremote.games SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1");

    public static boolean badHome(String comp) {
        Intrinsics.checkNotNullParameter(comp, "comp");
        String substringBefore = StringsKt.substringBefore(comp, '/', comp);
        if (substringBefore.length() != 0 && !substringBefore.equals("android") && !ArraysKt.contains(substringBefore, Setup.WIZARD) && !StringsKt.contains(comp, "FallbackHome", false) && !LauncherSwap.FACTORY.containsMatchIn(comp)) {
            return false;
        }
        return true;
    }

    public static void check(ThemeShare$Job themeShare$Job) {
        if (!themeShare$Job.cancel) {
        } else {
            throw new IOException("cancelled");
        }
    }

    public static boolean isAddress(String host) {
        Intrinsics.checkNotNullParameter(host, "host");
        if (!StringsKt__StringsJVMKt.endsWith(host, false, ".ts.net")) {
            Pattern compile = Pattern.compile("100\\.(?:6[4-9]|[7-9]\\d|1[01]\\d|12[0-7])\\..*");
            Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
            if (!compile.matcher(host).matches()) {
                return false;
            }
            return true;
        }
        return true;
    }

    public static Long kb(String text, String key) {
        String str;
        Intrinsics.checkNotNullParameter(text, "text");
        Intrinsics.checkNotNullParameter(key, "key");
        String pattern = "^" + key + ":\\s+(\\d+)";
        Intrinsics.checkNotNullParameter(pattern, "pattern");
        Pattern compile = Pattern.compile(pattern, 8);
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        Matcher matcher = compile.matcher(text);
        Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
        MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, text);
        if (access$findNext != null && (str = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)) != null) {
            return StringsKt__StringNumberConversionsKt.toLongOrNull(str);
        }
        return null;
    }

    public static String last(String out) {
        List list;
        String obj;
        Intrinsics.checkNotNullParameter(out, "out");
        List split$default = StringsKt.split$default(out, new String[]{"\n"}, 0, 6);
        if (!split$default.isEmpty()) {
            ListIterator listIterator = split$default.listIterator(split$default.size());
            while (listIterator.hasPrevious()) {
                if (!StringsKt.isBlank((String) listIterator.previous())) {
                    list = CollectionsKt.take(split$default, listIterator.nextIndex() + 1);
                    break;
                }
            }
        }
        list = EmptyList.INSTANCE;
        String str = (String) CollectionsKt.lastOrNull(list);
        if (str != null && (obj = StringsKt.trim(str).toString()) != null) {
            return obj;
        }
        return "";
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v0, types: [kotlin.collections.EmptyList] */
    /* JADX WARN: Type inference failed for: r2v1, types: [java.lang.Iterable] */
    /* JADX WARN: Type inference failed for: r2v6, types: [java.util.ArrayList] */
    public static List mediaKeys(JSONObject jSONObject) {
        ?? r2;
        JSONArray optJSONArray = jSONObject.optJSONArray("walls");
        if (optJSONArray != null) {
            IntRange until = MathKt.until(0, optJSONArray.length());
            r2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until));
            Iterator it = until.iterator();
            while (((IntProgressionIterator) it).hasNext) {
                r2.add(optJSONArray.optString(((IntProgressionIterator) it).nextInt()));
            }
        } else {
            r2 = EmptyList.INSTANCE;
        }
        ArrayList plus = CollectionsKt.plus(MathKt.listOf(jSONObject.optString("wall")), (Iterable) r2);
        ArrayList arrayList = new ArrayList();
        Iterator it2 = plus.iterator();
        while (it2.hasNext()) {
            Object next = it2.next();
            String str = (String) next;
            List list = HomeConfig.PLAIN;
            Intrinsics.checkNotNull(str);
            if (HomeConfig.isPhoto(str) || HomeConfig.isVideo(str)) {
                arrayList.add(next);
            }
        }
        return CollectionsKt.distinct(arrayList);
    }

    public static String pad(String host, Function1 function1) {
        Intrinsics.checkNotNullParameter(host, "host");
        String file = (String) function1.invoke("cat /sdcard/Android/data/dev.tvremote.games/files/pad.txt 2>/dev/null");
        Intrinsics.checkNotNullParameter(file, "file");
        List split$default = StringsKt.split$default(StringsKt.trim(file).toString(), new char[]{' '});
        if (split$default.size() == 2 && StringsKt__StringNumberConversionsKt.toIntOrNull((String) split$default.get(0)) != null && ((String) split$default.get(1)).length() >= 16) {
            return "http://" + host + ":" + split$default.get(0) + "/?k=" + split$default.get(1);
        }
        return null;
    }

    /* renamed from: parse, reason: collision with other method in class */
    public static String m13parse(String out) {
        String str;
        Intrinsics.checkNotNullParameter(out, "out");
        MatcherMatchResult find = Foreground.PKG.find(out, 0);
        return (find == null || (str = (String) ((MatcherMatchResult$groupValues$1) find.getGroupValues()).get(1)) == null) ? "" : str;
    }

    public static JSONObject read(Manage$$ExternalSyntheticLambda18 manage$$ExternalSyntheticLambda18) {
        Long longOrNull;
        Long longOrNull2;
        Long longOrNull3;
        String out = (String) manage$$ExternalSyntheticLambda18.invoke("cat /data/local/tmp/tvr-speed.txt 2>/dev/null; pgrep -f 'core[.]Speed' >/dev/null && echo running");
        Intrinsics.checkNotNullParameter(out, "out");
        JSONObject put = new JSONObject().put("phase", "");
        HashMap hashMap = new HashMap();
        for (String str : StringsKt.lines(out)) {
            List split$default = StringsKt.split$default(StringsKt.trim(str).toString(), new String[]{" "}, 0, 6);
            String str2 = (String) split$default.get(0);
            switch (str2.hashCode()) {
                case 3739:
                    if (str2.equals("up")) {
                        break;
                    } else {
                        break;
                    }
                case 3089282:
                    if (str2.equals("done")) {
                        put.put("phase", "done");
                        break;
                    } else {
                        continue;
                    }
                case 3089570:
                    if (str2.equals("down")) {
                        break;
                    } else {
                        break;
                    }
                case 3441010:
                    if (str2.equals("ping")) {
                        String str3 = (String) CollectionsKt.getOrNull(1, split$default);
                        if (str3 != null && (longOrNull3 = StringsKt__StringNumberConversionsKt.toLongOrNull(str3)) != null) {
                            put.put("ping", longOrNull3.longValue());
                            put.put("phase", "ping");
                            break;
                        }
                    } else {
                        continue;
                    }
                    break;
                case 96784904:
                    if (str2.equals("error")) {
                        JSONObject put2 = put.put("phase", "error");
                        String removePrefix = StringsKt.removePrefix(StringsKt.trim(str).toString(), "error ");
                        put2.put("error", StringsKt.substringAfter(removePrefix, "Exception: ", removePrefix));
                        break;
                    } else {
                        continue;
                    }
                case 1550783935:
                    if (str2.equals("running")) {
                        put.put("running", true);
                        break;
                    } else {
                        continue;
                    }
            }
            String str4 = (String) CollectionsKt.getOrNull(1, split$default);
            if (str4 != null && (longOrNull = StringsKt__StringNumberConversionsKt.toLongOrNull(str4)) != null) {
                long longValue = longOrNull.longValue();
                String str5 = (String) CollectionsKt.getOrNull(2, split$default);
                if (str5 != null && (longOrNull2 = StringsKt__StringNumberConversionsKt.toLongOrNull(str5)) != null) {
                    long longValue2 = longOrNull2.longValue();
                    if (longValue2 >= 1000 && !hashMap.containsKey(split$default.get(0))) {
                        hashMap.put(split$default.get(0), new Pair(longOrNull, longOrNull2));
                    }
                    Pair pair = (Pair) hashMap.get(split$default.get(0));
                    if (pair == null) {
                        pair = new Pair(0L, 0L);
                    }
                    long longValue3 = ((Number) pair.first).longValue();
                    if (longValue2 > ((Number) pair.second).longValue()) {
                        put.put((String) split$default.get(0), Math.round((((longValue - longValue3) * 8.0d) / (longValue2 - r13)) / 100) / 10.0d);
                    }
                    put.put("phase", split$default.get(0));
                }
            }
        }
        if (!put.has("running")) {
            put.put("running", false);
        }
        if (!put.optBoolean("running") && SetsKt.setOf((Object[]) new String[]{"ping", "down", "up"}).contains(put.optString("phase"))) {
            put.put("phase", "error").put("error", "stopped");
        }
        return put;
    }

    public static byte[] readFile(Adb adb, String str) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byte[] bArr = new byte[65536];
        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
        Adb.Stream open = adb.open(10000L, "exec:cat " + Mdns.q(str));
        do {
            try {
                int read = open.read(10000L, bArr, 0, 65536);
                if (read <= 0) {
                    break;
                }
                byteArrayOutputStream.write(bArr, 0, read);
            } finally {
            }
        } while (byteArrayOutputStream.size() <= 12582912);
        open.close();
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        Intrinsics.checkNotNullExpressionValue(byteArray, "toByteArray(...)");
        return byteArray;
    }

    public static void run(Adb adb, String str, byte[] bArr) {
        String install = RemoteLabels.Companion.install(adb, bArr);
        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
        adb.shell(120000L, "pkill -f 'core[.]Screen off' && pkill -x getevent");
        String obj = StringsKt.trim(adb.shell(120000L, "rm -f /data/local/tmp/tvr-screen.txt; (CLASSPATH=" + install + " nohup setsid app_process / dev.tvremote.core.Screen " + str + " >/data/local/tmp/tvr-screen.txt 2>&1 </dev/null &); for i in 1 2 3 4 5 6 7 8 9 10; do [ -s /data/local/tmp/tvr-screen.txt ] && break; sleep 0.3; done; head -1 /data/local/tmp/tvr-screen.txt")).toString();
        if (Intrinsics.areEqual(obj, "ok")) {
        } else {
            throw new IOException(obj.length() == 0 ? "the TV did not answer" : StringsKt.removePrefix(obj, "error "));
        }
    }

    public static String whyId(String why) {
        Intrinsics.checkNotNullParameter(why, "why");
        if (LauncherSwap.WHYS.contains(why) && !why.equals("user") && !why.equals("key")) {
            return "launcher.why_".concat(why);
        }
        return "launcher.why_user";
    }

    public static final void write$lambda$4$type(Ref$BooleanRef ref$BooleanRef, HttpServer.Stall stall, String key, byte[] head, int i) {
        String str;
        if (!ref$BooleanRef.element) {
            ref$BooleanRef.element = true;
            Intrinsics.checkNotNullParameter(key, "key");
            Intrinsics.checkNotNullParameter(head, "head");
            if (!HomeConfig.isVideo(key)) {
                str = "image/jpeg";
            } else if (i >= 4 && head[0] == 26 && head[1] == 69 && head[2] == -33 && head[3] == -93) {
                str = "video/webm";
            } else {
                str = "video/mp4";
            }
            byte[] bytes = str.concat(";base64,").getBytes(Charsets.UTF_8);
            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
            stall.write(bytes);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [kotlin.collections.EmptyList] */
    /* JADX WARN: Type inference failed for: r0v2 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.util.ArrayList] */
    public static Checkout.Result parse(String str) {
        List list;
        Integer intOrNull;
        Integer intOrNull2;
        Integer intOrNull3;
        Integer intOrNull4;
        ArrayList arrayList = null;
        if (!StringsKt__StringsJVMKt.startsWith(str, false, "checkout:")) {
            return null;
        }
        String substring = str.substring(9);
        Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
        List split$default = StringsKt.split$default(substring, new char[]{','});
        ArrayList arrayList2 = new ArrayList();
        Iterator it = split$default.iterator();
        while (it.hasNext()) {
            List split$default2 = StringsKt.split$default((String) it.next(), new char[]{'='});
            if (split$default2.size() != 2) {
                split$default2 = null;
            }
            if (split$default2 != null) {
                arrayList2.add(split$default2);
            }
        }
        int mapCapacity = MapsKt__MapsKt.mapCapacity(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList2));
        if (mapCapacity < 16) {
            mapCapacity = 16;
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap(mapCapacity);
        Iterator it2 = arrayList2.iterator();
        while (it2.hasNext()) {
            List list2 = (List) it2.next();
            linkedHashMap.put(list2.get(0), list2.get(1));
        }
        String str2 = (String) linkedHashMap.get("x");
        if (str2 != null) {
            List split$default3 = StringsKt.split$default(str2, new char[]{'+'});
            arrayList = new ArrayList();
            for (Object obj : split$default3) {
                if (((String) obj).length() > 0) {
                    arrayList.add(obj);
                }
            }
        }
        String str3 = (String) linkedHashMap.get("c");
        int intValue = (str3 == null || (intOrNull4 = StringsKt__StringNumberConversionsKt.toIntOrNull(str3)) == null) ? 0 : intOrNull4.intValue();
        if (arrayList == null) {
            String str4 = (String) linkedHashMap.get("f");
            int intValue2 = (str4 == null || (intOrNull3 = StringsKt__StringNumberConversionsKt.toIntOrNull(str4)) == null) ? 0 : intOrNull3.intValue();
            arrayList = new ArrayList(intValue2);
            for (int i = 0; i < intValue2; i++) {
                arrayList.add("?");
            }
        }
        ArrayList arrayList3 = arrayList;
        String str5 = (String) linkedHashMap.get("v");
        int intValue3 = (str5 == null || (intOrNull2 = StringsKt__StringNumberConversionsKt.toIntOrNull(str5)) == null) ? 0 : intOrNull2.intValue();
        String str6 = (String) linkedHashMap.get("w");
        if (str6 == null) {
            str6 = "";
        }
        String str7 = str6;
        String str8 = (String) linkedHashMap.get("n");
        int intValue4 = (str8 == null || (intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull(str8)) == null) ? 0 : intOrNull.intValue();
        boolean areEqual = Intrinsics.areEqual(linkedHashMap.get("h"), "1");
        String str9 = (String) linkedHashMap.get("a");
        if (str9 != null) {
            List split$default4 = StringsKt.split$default(str9, new char[]{'+'});
            list = new ArrayList();
            for (Object obj2 : split$default4) {
                if (((String) obj2).length() > 0) {
                    list.add(obj2);
                }
            }
        } else {
            list = EmptyList.INSTANCE;
        }
        return new Checkout.Result(intValue, arrayList3, intValue3, str7, intValue4, areEqual, list);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:221:0x04b0 A[Catch: all -> 0x01d8, TryCatch #6 {all -> 0x01d8, blocks: (B:59:0x01b5, B:61:0x01be, B:62:0x01dd, B:64:0x01ea, B:71:0x01fe, B:73:0x020e, B:75:0x0225, B:77:0x0231, B:79:0x0247, B:81:0x0253, B:82:0x025e, B:84:0x0264, B:86:0x027d, B:88:0x0284, B:90:0x028a, B:92:0x0290, B:94:0x0298, B:95:0x029f, B:98:0x02a0, B:99:0x02a7, B:103:0x02a8, B:104:0x02ba, B:106:0x02c0, B:108:0x02c9, B:217:0x04a4, B:218:0x04a9, B:219:0x04aa, B:220:0x04af, B:221:0x04b0, B:222:0x04b7), top: B:58:0x01b5 }] */
    /* JADX WARN: Removed duplicated region for block: B:71:0x01fe A[Catch: all -> 0x01d8, LOOP:5: B:69:0x01fa->B:71:0x01fe, LOOP_END, TryCatch #6 {all -> 0x01d8, blocks: (B:59:0x01b5, B:61:0x01be, B:62:0x01dd, B:64:0x01ea, B:71:0x01fe, B:73:0x020e, B:75:0x0225, B:77:0x0231, B:79:0x0247, B:81:0x0253, B:82:0x025e, B:84:0x0264, B:86:0x027d, B:88:0x0284, B:90:0x028a, B:92:0x0290, B:94:0x0298, B:95:0x029f, B:98:0x02a0, B:99:0x02a7, B:103:0x02a8, B:104:0x02ba, B:106:0x02c0, B:108:0x02c9, B:217:0x04a4, B:218:0x04a9, B:219:0x04aa, B:220:0x04af, B:221:0x04b0, B:222:0x04b7), top: B:58:0x01b5 }] */
    /* JADX WARN: Removed duplicated region for block: B:75:0x0225 A[Catch: all -> 0x01d8, TryCatch #6 {all -> 0x01d8, blocks: (B:59:0x01b5, B:61:0x01be, B:62:0x01dd, B:64:0x01ea, B:71:0x01fe, B:73:0x020e, B:75:0x0225, B:77:0x0231, B:79:0x0247, B:81:0x0253, B:82:0x025e, B:84:0x0264, B:86:0x027d, B:88:0x0284, B:90:0x028a, B:92:0x0290, B:94:0x0298, B:95:0x029f, B:98:0x02a0, B:99:0x02a7, B:103:0x02a8, B:104:0x02ba, B:106:0x02c0, B:108:0x02c9, B:217:0x04a4, B:218:0x04a9, B:219:0x04aa, B:220:0x04af, B:221:0x04b0, B:222:0x04b7), top: B:58:0x01b5 }] */
    /* JADX WARN: Type inference failed for: r10v29, types: [java.util.ArrayList] */
    /* JADX WARN: Type inference failed for: r10v7 */
    /* JADX WARN: Type inference failed for: r10v8, types: [java.util.Collection, java.lang.Iterable] */
    /* JADX WARN: Type inference failed for: r8v11 */
    /* JADX WARN: Type inference failed for: r8v12, types: [java.lang.Iterable] */
    /* JADX WARN: Type inference failed for: r8v19, types: [java.util.ArrayList] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static void run(ThemeShare$Job themeShare$Job, Adb adb, String str, String str2, String str3) {
        Object obj;
        String str4;
        ?? r10;
        ?? r8;
        List<String> list;
        long j;
        long j2;
        byte[] bArr;
        JSONObject jSONObject;
        Adb adb2 = adb;
        if (str2.length() != 0) {
            Fleet$$ExternalSyntheticLambda0 fleet$$ExternalSyntheticLambda0 = new Fleet$$ExternalSyntheticLambda0(adb2, 14);
            String str5 = "";
            JSONObject call = Home.call("", fleet$$ExternalSyntheticLambda0, null);
            if (call.optBoolean("installed")) {
                JSONObject optJSONObject = call.optJSONObject("config");
                if (optJSONObject != null) {
                    JSONObject optJSONObject2 = call.optJSONObject("config");
                    Intrinsics.checkNotNull(optJSONObject2);
                    if (optJSONObject2.optBoolean("themesOk")) {
                        JSONArray optJSONArray = optJSONObject.optJSONArray("themes");
                        if (optJSONArray != null) {
                            IntRange until = MathKt.until(0, optJSONArray.length());
                            ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until));
                            Iterator it = until.iterator();
                            while (((IntProgressionIterator) it).hasNext) {
                                arrayList.add(optJSONArray.getJSONObject(((IntProgressionIterator) it).nextInt()));
                            }
                            Iterator it2 = arrayList.iterator();
                            while (true) {
                                if (it2.hasNext()) {
                                    obj = it2.next();
                                    if (Intrinsics.areEqual(((JSONObject) obj).optString("id"), str)) {
                                        break;
                                    }
                                } else {
                                    obj = null;
                                    break;
                                }
                            }
                            JSONObject jSONObject2 = (JSONObject) obj;
                            if (jSONObject2 != null) {
                                String optString = jSONObject2.optString("name");
                                List list2 = HomeConfig.PLAIN;
                                JSONObject optJSONObject3 = jSONObject2.optJSONObject("conf");
                                if (optJSONObject3 == null) {
                                    optJSONObject3 = new JSONObject();
                                }
                                JSONObject pickTheme = HomeConfig.pickTheme(optJSONObject3);
                                String optString2 = pickTheme.optString("wall");
                                String str6 = "walls";
                                JSONArray optJSONArray2 = pickTheme.optJSONArray("walls");
                                EmptyList emptyList = EmptyList.INSTANCE;
                                if (optJSONArray2 != null) {
                                    str4 = "name";
                                    IntRange until2 = MathKt.until(0, optJSONArray2.length());
                                    r10 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until2));
                                    Iterator it3 = until2.iterator();
                                    while (((IntProgressionIterator) it3).hasNext) {
                                        r10.add(optJSONArray2.optString(((IntProgressionIterator) it3).nextInt()));
                                    }
                                } else {
                                    str4 = "name";
                                    r10 = emptyList;
                                }
                                Intrinsics.checkNotNull(optString2);
                                if (!StringsKt__StringsJVMKt.startsWith(optString2, false, "vid:")) {
                                    if (!r10.isEmpty()) {
                                        Iterator it4 = r10.iterator();
                                        while (it4.hasNext()) {
                                            String str7 = (String) it4.next();
                                            Intrinsics.checkNotNull(str7);
                                            Iterator it5 = it4;
                                            if (!StringsKt__StringsJVMKt.startsWith(str7, false, "vid:")) {
                                                it4 = it5;
                                            }
                                        }
                                    }
                                    JSONArray optJSONArray3 = pickTheme.optJSONArray("walls");
                                    if (optJSONArray3 != null) {
                                        IntRange until3 = MathKt.until(0, optJSONArray3.length());
                                        r8 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until3));
                                        Iterator it6 = until3.iterator();
                                        while (((IntProgressionIterator) it6).hasNext) {
                                            r8.add(optJSONArray3.optString(((IntProgressionIterator) it6).nextInt()));
                                        }
                                    } else {
                                        r8 = emptyList;
                                    }
                                    ArrayList plus = CollectionsKt.plus(MathKt.listOf(pickTheme.optString("wall")), (Iterable) r8);
                                    ArrayList arrayList2 = new ArrayList();
                                    Iterator it7 = plus.iterator();
                                    while (it7.hasNext()) {
                                        Object next = it7.next();
                                        String str8 = (String) next;
                                        List list3 = HomeConfig.PLAIN;
                                        Intrinsics.checkNotNull(str8);
                                        if (HomeConfig.isPhoto(str8)) {
                                            arrayList2.add(next);
                                        }
                                    }
                                    List take = CollectionsKt.take(CollectionsKt.distinct(arrayList2), 10);
                                    String optString3 = optJSONObject.optString("theme");
                                    LinkedHashMap linkedHashMap = new LinkedHashMap();
                                    try {
                                        check(themeShare$Job);
                                        if (Intrinsics.areEqual(optString3, str)) {
                                            list = take;
                                        } else {
                                            Regex regex = Home.PIN_KEY;
                                            list = take;
                                            Home.call("", fleet$$ExternalSyntheticLambda0, new JSONObject().put("theme", new JSONObject().put("apply", str)));
                                        }
                                        fleet$$ExternalSyntheticLambda0.invoke("input keyevent 3");
                                        if (!optString2.equals("web") && !optString2.equals("bing")) {
                                            j = 3500;
                                            j2 = 0;
                                            while (j2 < j) {
                                                check(themeShare$Job);
                                                Thread.sleep(250L);
                                                j2 += 250;
                                                str6 = str6;
                                            }
                                            String str9 = str6;
                                            themeShare$Job.step = "shot";
                                            check(themeShare$Job);
                                            if (!StringsKt.contains((CharSequence) fleet$$ExternalSyntheticLambda0.invoke("dumpsys activity activities | grep -m1 -E 'topResumedActivity|mResumedActivity'"), "dev.tvremote.home/", false)) {
                                                long currentTimeMillis = System.currentTimeMillis();
                                                byte[] bArr2 = Tv.MOUSE_DESC;
                                                byte[] screencap = Fleet.screencap(adb2);
                                                if (screencap != null) {
                                                    themeShare$Job.shotMs = System.currentTimeMillis() - currentTimeMillis;
                                                    themeShare$Job.shotKb = screencap.length / 1024;
                                                    byte[] fromPng = Jpeg.fromPng(screencap);
                                                    if (fromPng != null) {
                                                        themeShare$Job.previewKb = fromPng.length / 1024;
                                                        if (list.isEmpty()) {
                                                            bArr = fromPng;
                                                        } else {
                                                            themeShare$Job.step = "photo";
                                                            check(themeShare$Job);
                                                            for (String str10 : list) {
                                                                check(themeShare$Job);
                                                                byte[] readFile = readFile(adb2, HomeConfig.photoPath(str10));
                                                                byte[] bArr3 = fromPng;
                                                                if (readFile.length >= 4 && readFile[0] == -1 && readFile[1] == -40) {
                                                                    byte[] shrink = Jpeg.shrink(readFile);
                                                                    if (shrink == null) {
                                                                        throw new ThemeShare$Fail("photo_big", "photo_big");
                                                                    }
                                                                    linkedHashMap.put(str10, shrink);
                                                                    adb2 = adb;
                                                                    fromPng = bArr3;
                                                                } else {
                                                                    throw new ThemeShare$Fail("photo_missing", "photo_missing");
                                                                }
                                                            }
                                                            bArr = fromPng;
                                                            Collection values = linkedHashMap.values();
                                                            Intrinsics.checkNotNullExpressionValue(values, "<get-values>(...)");
                                                            Iterator it8 = values.iterator();
                                                            int i = 0;
                                                            while (it8.hasNext()) {
                                                                i += ((byte[]) it8.next()).length;
                                                            }
                                                            themeShare$Job.wallKb = i / 1024;
                                                        }
                                                        if (!Intrinsics.areEqual(optString3, str)) {
                                                            try {
                                                                Regex regex2 = Home.PIN_KEY;
                                                                Home.call("", fleet$$ExternalSyntheticLambda0, new JSONObject().put("theme", new JSONObject().put("apply", optString3.length() == 0 ? "before" : optString3)));
                                                            } catch (Exception unused) {
                                                            }
                                                        }
                                                        themeShare$Job.step = "send";
                                                        check(themeShare$Job);
                                                        JSONObject put = new JSONObject().put("tvtheme", 1).put(str4, optString).put("by", str2).put("lang", str3).put("conf", pickTheme).put("preview", B64.encode(bArr));
                                                        if (!linkedHashMap.isEmpty()) {
                                                            JSONObject jSONObject3 = new JSONObject();
                                                            for (Map.Entry entry : linkedHashMap.entrySet()) {
                                                                jSONObject3.put((String) entry.getKey(), B64.encode((byte[]) entry.getValue()));
                                                            }
                                                            put.put(str9, jSONObject3);
                                                        }
                                                        String jSONObject4 = put.toString();
                                                        Intrinsics.checkNotNullExpressionValue(jSONObject4, "toString(...)");
                                                        Charset charset = Charsets.UTF_8;
                                                        byte[] bytes = jSONObject4.getBytes(charset);
                                                        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                                                        String str11 = "too_big";
                                                        if (bytes.length <= 5200000) {
                                                            String str12 = System.getenv("TVR_THEME_STORE");
                                                            if (str12 == null && (str12 = System.getProperty("tvr.themestore")) == null) {
                                                                str12 = "https://tvr-themes.99-hoangtran.workers.dev/v1/themes";
                                                            }
                                                            URLConnection openConnection = new URL(str12).openConnection();
                                                            Intrinsics.checkNotNull(openConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
                                                            HttpURLConnection httpURLConnection = (HttpURLConnection) openConnection;
                                                            themeShare$Job.conn = httpURLConnection;
                                                            try {
                                                                httpURLConnection.setRequestMethod("POST");
                                                                httpURLConnection.setDoOutput(true);
                                                                httpURLConnection.setConnectTimeout(10000);
                                                                httpURLConnection.setReadTimeout(60000);
                                                                httpURLConnection.setRequestProperty("Content-Type", "application/json");
                                                                httpURLConnection.setFixedLengthStreamingMode(bytes.length);
                                                                try {
                                                                    OutputStream outputStream = httpURLConnection.getOutputStream();
                                                                    try {
                                                                        outputStream.write(bytes);
                                                                        outputStream.close();
                                                                        try {
                                                                            int responseCode = httpURLConnection.getResponseCode();
                                                                            try {
                                                                                InputStream inputStream = responseCode < 400 ? httpURLConnection.getInputStream() : httpURLConnection.getErrorStream();
                                                                                if (inputStream != null) {
                                                                                    try {
                                                                                        String str13 = new String(MathKt.readBytes(inputStream), charset);
                                                                                        inputStream.close();
                                                                                        str5 = str13;
                                                                                    } finally {
                                                                                    }
                                                                                }
                                                                            } catch (IOException unused2) {
                                                                            }
                                                                            try {
                                                                                jSONObject = new JSONObject(str5);
                                                                            } catch (Exception unused3) {
                                                                                jSONObject = new JSONObject();
                                                                            }
                                                                            if (responseCode != 200 && responseCode != 202) {
                                                                                String optString4 = jSONObject.optString("error");
                                                                                Intrinsics.checkNotNullExpressionValue(optString4, "optString(...)");
                                                                                String lowerCase = optString4.toLowerCase(Locale.ROOT);
                                                                                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                                                                                if (responseCode != 413) {
                                                                                    if (responseCode == 429 && StringsKt.contains(lowerCase, "queue_full", false)) {
                                                                                        str11 = "queue";
                                                                                    } else if (responseCode == 429) {
                                                                                        str11 = "limit";
                                                                                    } else if (responseCode == 400) {
                                                                                        str11 = "rejected";
                                                                                    } else {
                                                                                        str11 = "server";
                                                                                    }
                                                                                }
                                                                                if (lowerCase.length() == 0) {
                                                                                    lowerCase = "http " + responseCode;
                                                                                }
                                                                                throw new ThemeShare$Fail(str11, lowerCase);
                                                                            }
                                                                            String optString5 = jSONObject.optString("id");
                                                                            if (optString5.length() == 0) {
                                                                                optString5 = "ok";
                                                                            }
                                                                            httpURLConnection.disconnect();
                                                                            themeShare$Job.conn = null;
                                                                            themeShare$Job.id = optString5;
                                                                            return;
                                                                        } catch (IOException unused4) {
                                                                            check(themeShare$Job);
                                                                            throw new ThemeShare$Fail("network", "network");
                                                                        }
                                                                    } finally {
                                                                    }
                                                                } catch (IOException unused5) {
                                                                    check(themeShare$Job);
                                                                    throw new ThemeShare$Fail("network", "network");
                                                                }
                                                            } finally {
                                                                httpURLConnection.disconnect();
                                                                themeShare$Job.conn = null;
                                                            }
                                                        } else {
                                                            throw new ThemeShare$Fail("too_big", "too_big");
                                                        }
                                                    } else {
                                                        throw new ThemeShare$Fail("shot", "shot");
                                                    }
                                                } else {
                                                    throw new ThemeShare$Fail("shot", "shot");
                                                }
                                            } else {
                                                throw new ThemeShare$Fail("not_home", "not_home");
                                            }
                                        }
                                        j = 7000;
                                        j2 = 0;
                                        while (j2 < j) {
                                        }
                                        String str92 = str6;
                                        themeShare$Job.step = "shot";
                                        check(themeShare$Job);
                                        if (!StringsKt.contains((CharSequence) fleet$$ExternalSyntheticLambda0.invoke("dumpsys activity activities | grep -m1 -E 'topResumedActivity|mResumedActivity'"), "dev.tvremote.home/", false)) {
                                        }
                                    } catch (Throwable th) {
                                        if (!Intrinsics.areEqual(optString3, str)) {
                                            try {
                                                Regex regex3 = Home.PIN_KEY;
                                                Home.call("", fleet$$ExternalSyntheticLambda0, new JSONObject().put("theme", new JSONObject().put("apply", optString3.length() == 0 ? "before" : optString3)));
                                            } catch (Exception unused6) {
                                            }
                                        }
                                        throw th;
                                    }
                                }
                                throw new ThemeShare$Fail("video", "video");
                            }
                        }
                        throw new ThemeShare$Fail("theme_missing", "theme_missing");
                    }
                    throw new ThemeShare$Fail("home_old", "home_old");
                }
                throw new ThemeShare$Fail("home_missing", "home_missing");
            }
            throw new ThemeShare$Fail("home_missing", "home_missing");
        }
        throw new ThemeShare$Fail("by", "by");
    }
}
