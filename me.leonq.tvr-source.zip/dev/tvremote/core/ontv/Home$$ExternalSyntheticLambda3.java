package dev.tvremote.core.ontv;

import dev.tvremote.update.Release;
import kotlin.jvm.functions.Function1;

/* loaded from: classes.dex */
public final /* synthetic */ class Home$$ExternalSyntheticLambda3 implements Release.Progress {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Function1 f$0;

    public /* synthetic */ Home$$ExternalSyntheticLambda3(int i, Function1 function1) {
        this.$r8$classId = i;
        this.f$0 = function1;
    }

    @Override // dev.tvremote.update.Release.Progress
    public final void at(int i) {
        switch (this.$r8$classId) {
            case 0:
                this.f$0.invoke(Integer.valueOf(i));
                return;
            default:
                this.f$0.invoke(Integer.valueOf(i));
                return;
        }
    }
}
