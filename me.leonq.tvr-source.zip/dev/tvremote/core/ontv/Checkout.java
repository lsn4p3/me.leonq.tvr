package dev.tvremote.core.ontv;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import com.android.apksig.SigningCertificateLineage$SignerCapabilities;
import com.android.apksig.internal.apk.v3.V3SigningCertificateLineage$SigningCertificateNode;
import dev.tvremote.core.Fleet$$ExternalSyntheticLambda0;
import dev.tvremote.core.SupportAndroid$store$1;
import dev.tvremote.core.adb.Pkg;
import java.security.InvalidKeyException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;

/* loaded from: classes.dex */
public abstract class Checkout {
    public static final LinkedHashMap SUGGEST = MapsKt__MapsKt.linkedMapOf(new Pair("com.google.android.youtube.tv", "YouTube"), new Pair("com.google.android.youtube.tvkids", "YouTube Kids"), new Pair("com.google.android.youtube.tvmusic", "YouTube Music"), new Pair("com.netflix.ninja", "Netflix"), new Pair("com.amazon.amazonvideo.livingroom", "Prime Video"), new Pair("com.disney.disneyplus", "Disney+"), new Pair("in.startv.hotstar", "Disney+ Hotstar"), new Pair("com.wbd.stream", "Max"), new Pair("com.apple.atve.androidtv.appletv", "Apple TV"), new Pair("com.spotify.tv.android", "Spotify"), new Pair("com.plexapp.android", "Plex"), new Pair("tv.twitch.android.app", "Twitch"), new Pair("com.android.chrome", "Chrome"), new Pair("org.mozilla.firefox", "Firefox"), new Pair("com.brave.browser", "Brave"), new Pair("com.microsoft.emmx", "Edge"), new Pair("com.opera.browser", "Opera"), new Pair("com.puffin.tv", "Puffin TV Browser"), new Pair("com.tv.browser", "TV Browser"));
    public static final Regex ALSO = new Regex("dev\\.tvremote\\..*|com\\.android\\.(tv\\..*|launcher.*|provision.*|managedprovisioning|keychain|certinstaller|location|server.*|inputdevices|nfc|dynsystem)|com\\.google\\.android\\.(tv|apps\\.tv\\.).*|com\\.google\\.android\\.(setupwizard|partnersetup|onetimeinitializer|backuptransport|syncadapters.*|ext\\..*|webview|trichromelibrary.*|play\\.games\\.tv)|.*launcher.*|.*\\.systemui|.*\\.settings");

    /* loaded from: classes.dex */
    public final class Config {
        public final List apps;
        public final int volume;

        public Config(List list, int i) {
            this.apps = list;
            this.volume = i;
        }

        public Config getSubLineage(X509Certificate x509Certificate) {
            if (x509Certificate != null) {
                int i = 0;
                while (true) {
                    List list = this.apps;
                    if (i < list.size()) {
                        if (((V3SigningCertificateLineage$SigningCertificateNode) list.get(i)).signingCert.equals(x509Certificate)) {
                            return new Config(this.volume, new ArrayList(list.subList(0, i + 1)));
                        }
                        i++;
                    } else {
                        throw new IllegalArgumentException("Certificate not found in SigningCertificateLineage");
                    }
                }
            } else {
                throw new NullPointerException("x509Certificate == null");
            }
        }

        public Config mergeLineageWith(Config config) {
            Config config2;
            Config config3;
            List list;
            int i = 0;
            X509Certificate x509Certificate = ((V3SigningCertificateLineage$SigningCertificateNode) this.apps.get(0)).signingCert;
            if (x509Certificate != null) {
                int i2 = 0;
                while (true) {
                    List list2 = config.apps;
                    if (i2 < list2.size()) {
                        if (((V3SigningCertificateLineage$SigningCertificateNode) list2.get(i2)).signingCert.equals(x509Certificate)) {
                            config3 = this;
                            config2 = config;
                            break;
                        }
                        i2++;
                    } else {
                        config2 = this;
                        config3 = config;
                        break;
                    }
                }
                List list3 = config3.apps;
                V3SigningCertificateLineage$SigningCertificateNode v3SigningCertificateLineage$SigningCertificateNode = (V3SigningCertificateLineage$SigningCertificateNode) list3.get(0);
                ArrayList arrayList = new ArrayList();
                while (true) {
                    list = config2.apps;
                    if (i >= list.size()) {
                        break;
                    }
                    int i3 = i + 1;
                    V3SigningCertificateLineage$SigningCertificateNode v3SigningCertificateLineage$SigningCertificateNode2 = (V3SigningCertificateLineage$SigningCertificateNode) list.get(i);
                    if (v3SigningCertificateLineage$SigningCertificateNode2.signingCert.equals(v3SigningCertificateLineage$SigningCertificateNode.signingCert)) {
                        i = i3;
                        break;
                    }
                    arrayList.add(v3SigningCertificateLineage$SigningCertificateNode2);
                    i = i3;
                }
                if (i != arrayList.size()) {
                    arrayList.add(v3SigningCertificateLineage$SigningCertificateNode);
                    int i4 = 1;
                    while (i < list.size() && i4 < list3.size()) {
                        int i5 = i + 1;
                        V3SigningCertificateLineage$SigningCertificateNode v3SigningCertificateLineage$SigningCertificateNode3 = (V3SigningCertificateLineage$SigningCertificateNode) list.get(i);
                        int i6 = i4 + 1;
                        V3SigningCertificateLineage$SigningCertificateNode v3SigningCertificateLineage$SigningCertificateNode4 = (V3SigningCertificateLineage$SigningCertificateNode) list3.get(i4);
                        if (v3SigningCertificateLineage$SigningCertificateNode3.signingCert.equals(v3SigningCertificateLineage$SigningCertificateNode4.signingCert)) {
                            arrayList.add(v3SigningCertificateLineage$SigningCertificateNode4);
                            i = i5;
                            i4 = i6;
                        } else {
                            throw new IllegalArgumentException("The provided lineage diverges from this lineage");
                        }
                    }
                    while (i < list.size()) {
                        arrayList.add((V3SigningCertificateLineage$SigningCertificateNode) list.get(i));
                        i++;
                    }
                    while (i4 < list3.size()) {
                        arrayList.add((V3SigningCertificateLineage$SigningCertificateNode) list3.get(i4));
                        i4++;
                    }
                    return new Config(Math.min(this.volume, config.volume), arrayList);
                }
                throw new IllegalArgumentException("The provided lineage is not a descendant or an ancestor of this lineage");
            }
            throw new NullPointerException("cert == null");
        }

        public Config spawnFirstDescendant(SupportAndroid$store$1 supportAndroid$store$1, SigningCertificateLineage$SignerCapabilities signingCertificateLineage$SignerCapabilities) {
            if (this.apps.isEmpty()) {
                try {
                    return new Config(this.volume, Collections.singletonList(new V3SigningCertificateLineage$SigningCertificateNode((X509Certificate) supportAndroid$store$1.$p, null, null, new byte[0], 23)));
                } catch (InvalidKeyException e) {
                    throw new IllegalArgumentException("Algorithm associated with first signing certificate invalid on desired platform versions", e);
                }
            }
            throw new IllegalStateException("SigningCertificateLineage already has its first node");
        }

        public Config(int i, List list) {
            this.volume = i;
            this.apps = list;
        }
    }

    /* loaded from: classes.dex */
    public final class Result {
        public final Object apps;
        public final int cleared;
        public final ArrayList failed;
        public final int forgot;
        public final boolean home;
        public final int volume;
        public final String web;

        public Result(int i, ArrayList arrayList, int i2, String web, int i3, boolean z, List list) {
            Intrinsics.checkNotNullParameter(web, "web");
            this.cleared = i;
            this.failed = arrayList;
            this.volume = i2;
            this.web = web;
            this.forgot = i3;
            this.home = z;
            this.apps = list;
        }
    }

    /* loaded from: classes.dex */
    public final class Step {
        public final String kind;
        public final String pkg;
        public final String skip;

        public Step(int i, String str, String pkg, String str2) {
            pkg = (i & 2) != 0 ? "" : pkg;
            str2 = (i & 4) != 0 ? "" : str2;
            Intrinsics.checkNotNullParameter(pkg, "pkg");
            this.kind = str;
            this.pkg = pkg;
            this.skip = str2;
        }

        public final String toString() {
            String str;
            String str2 = this.pkg;
            String str3 = "";
            if (str2.length() <= 0) {
                str = "";
            } else {
                str = ApkSigner$$ExternalSyntheticOutline0.m(":", str2);
            }
            String str4 = this.skip;
            if (str4.length() > 0) {
                str3 = ApkSigner$$ExternalSyntheticOutline0.m(" (skip ", str4, ")");
            }
            return this.kind + str + str3;
        }
    }

    public static String blocked(String pkg) {
        Intrinsics.checkNotNullParameter(pkg, "pkg");
        Regex regex = Pkg.RE;
        if (!Pkg.RE.matches(pkg)) {
            return "bad package name";
        }
        String[] strArr = Setup.GOOGLE;
        if (!Rescue.mustKeep(pkg) && !ALSO.matches(pkg)) {
            if (Bloat.factory(pkg)) {
                return "protected: the TV's own app";
            }
            return null;
        }
        return "protected: the TV needs this app";
    }

    public static List clean(List list) {
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(list));
        Iterator it = list.iterator();
        while (it.hasNext()) {
            arrayList.add(StringsKt.trim((String) it.next()).toString());
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator it2 = arrayList.iterator();
        while (it2.hasNext()) {
            Object next = it2.next();
            String str = (String) next;
            if (str.length() > 0 && blocked(str) == null) {
                arrayList2.add(next);
            }
        }
        return CollectionsKt.distinct(arrayList2);
    }

    public static ArrayList here(Fleet$$ExternalSyntheticLambda0 fleet$$ExternalSyntheticLambda0) {
        List lines = StringsKt.lines((CharSequence) fleet$$ExternalSyntheticLambda0.invoke("pm list packages 2>/dev/null"));
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(lines));
        Iterator it = lines.iterator();
        while (it.hasNext()) {
            arrayList.add(StringsKt.trim(StringsKt.removePrefix((String) it.next(), "package:")).toString());
        }
        return preselect(CollectionsKt.toSet(arrayList));
    }

    public static int index(String rangeOut, int i) {
        int i2;
        String str;
        Integer intOrNull;
        Intrinsics.checkNotNullParameter(rangeOut, "rangeOut");
        Pattern compile = Pattern.compile("range \\[\\d+\\.\\.(\\d+)]");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        Matcher matcher = compile.matcher(rangeOut);
        Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
        MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, rangeOut);
        if (access$findNext != null && (str = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)) != null && (intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull(str)) != null) {
            if (intOrNull.intValue() <= 0) {
                intOrNull = null;
            }
            if (intOrNull != null) {
                i2 = intOrNull.intValue();
                return MathKt.coerceIn((int) Math.round((MathKt.coerceIn(i, 0, 100) * i2) / 100.0d), 0, i2);
            }
        }
        i2 = 15;
        return MathKt.coerceIn((int) Math.round((MathKt.coerceIn(i, 0, 100) * i2) / 100.0d), 0, i2);
    }

    public static ArrayList preselect(Set set) {
        Set keySet = SUGGEST.keySet();
        Intrinsics.checkNotNullExpressionValue(keySet, "<get-keys>(...)");
        ArrayList arrayList = new ArrayList();
        for (Object obj : keySet) {
            if (set.contains((String) obj)) {
                arrayList.add(obj);
            }
        }
        return arrayList;
    }
}
