package dev.tvremote.core.ontv;

import java.io.IOException;

/* loaded from: classes.dex */
public final class ThemeShare$Cancelled extends IOException {
}
