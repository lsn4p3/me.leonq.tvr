package dev.tvremote.core.ontv;

import android.content.Intent;
import dev.tvremote.core.ontv.Launchers;
import dev.tvremote.home.HomeConfig;
import dev.tvremote.phone.ListenService;
import dev.tvremote.phone.WorkService;
import java.util.List;
import java.util.Locale;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.io.LinesSequence;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class Home$$ExternalSyntheticLambda6 implements Function1 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ JSONObject f$0;

    public /* synthetic */ Home$$ExternalSyntheticLambda6(JSONObject jSONObject, int i) {
        this.$r8$classId = i;
        this.f$0 = jSONObject;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        JSONObject jSONObject = this.f$0;
        switch (this.$r8$classId) {
            case 0:
                String str = (String) obj;
                String optString = jSONObject.optString(str);
                Intrinsics.checkNotNullExpressionValue(optString, "optString(...)");
                String obj2 = StringsKt.trim(optString).toString();
                if (obj2.length() <= 0) {
                    obj2 = null;
                }
                if (obj2 == null) {
                    return null;
                }
                return new Pair(str, obj2);
            case 1:
                jSONObject.put("pct", ((Integer) obj).intValue());
                return Unit.INSTANCE;
            case 2:
                String str2 = (String) obj;
                Intrinsics.checkNotNull(str2);
                String string = jSONObject.getJSONObject(str2).getString("url");
                Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                String string2 = jSONObject.getJSONObject(str2).getString("sha256");
                Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
                String lowerCase = string2.toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                return new Launchers.Apk(str2, string, lowerCase);
            case 3:
                return jSONObject.getJSONObject((String) obj);
            case 4:
                List list = HomeConfig.PLAIN;
                return new LinesSequence(1, HomeConfig.strs(jSONObject.getJSONObject((String) obj).optJSONArray("apps")));
            case 5:
                String k = (String) obj;
                WorkService.Companion companion = ListenService.Companion;
                Intrinsics.checkNotNullParameter(k, "k");
                if (jSONObject != null && !jSONObject.isNull(k)) {
                    return jSONObject.optString(k);
                }
                return "";
            default:
                Intent it = (Intent) obj;
                Intrinsics.checkNotNullParameter(it, "it");
                Intent putExtra = it.putExtra("scene", jSONObject.optString("id"));
                Intrinsics.checkNotNullExpressionValue(putExtra, "putExtra(...)");
                return putExtra;
        }
    }
}
