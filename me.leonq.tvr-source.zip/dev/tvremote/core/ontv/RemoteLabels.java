package dev.tvremote.core.ontv;

import dev.tvremote.core.Fleet$$ExternalSyntheticLambda0;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.Adb$$ExternalSyntheticLambda0;
import dev.tvremote.core.adb.AdbLink;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import kotlin.SynchronizedLazyImpl;
import kotlin.collections.EmptyMap;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.sequences.ConstrainedOnceSequence;
import kotlin.sequences.Sequence;
import kotlin.sequences.SequencesKt;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class RemoteLabels {
    public static final Rescue Companion = new Object();
    public static final Regex PKG = new Regex("[\\w.]+");
    public final File cache;
    public volatile String caps;
    public volatile long failedAt;
    public final SynchronizedLazyImpl jar$delegate;
    public final AdbLink link;
    public volatile HashMap names;
    public volatile boolean ok;
    public volatile Map own = EmptyMap.INSTANCE;
    public final Object running = new Object();
    public volatile HashMap stamps;
    public volatile boolean waited;

    public RemoteLabels(AdbLink adbLink, Function0 function0, File file) {
        this.link = adbLink;
        this.cache = file;
        this.jar$delegate = new SynchronizedLazyImpl(function0);
    }

    public final Map ask() {
        HashMap hashMap;
        Map map;
        synchronized (this.running) {
            try {
                hashMap = new HashMap();
                String str = "";
                try {
                    Adb adb = this.link.get();
                    String str2 = "CLASSPATH=" + Companion.install(adb, (byte[]) this.jar$delegate.getValue()) + " app_process / dev.tvremote.core.Meta /data/local/tmp/tvr-meta 2>&1";
                    ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                    String shell = adb.shell(120000L, str2);
                    for (String str3 : StringsKt.split$default(shell, new String[]{"\n"}, 0, 6)) {
                        int indexOf$default = StringsKt.indexOf$default(str3, '\t', 6);
                        if (indexOf$default > 0) {
                            String substring = str3.substring(0, indexOf$default);
                            Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
                            if (PKG.matches(substring)) {
                                String substring2 = str3.substring(0, indexOf$default);
                                Intrinsics.checkNotNullExpressionValue(substring2, "substring(...)");
                                String substring3 = str3.substring(indexOf$default + 1);
                                Intrinsics.checkNotNullExpressionValue(substring3, "substring(...)");
                                hashMap.put(substring2, StringsKt.trim(substring3).toString());
                            }
                        }
                    }
                    if (hashMap.isEmpty()) {
                        str = "Meta printed no app names: " + StringsKt.take(StringsKt.trim(shell).toString(), 300);
                    }
                    if (!hashMap.isEmpty()) {
                        HashMap hashMap2 = new HashMap();
                        Iterator it = StringsKt.split$default(adb.shell(120000L, "cd /data/local/tmp/tvr-meta && stat -c '%n %Y %s' *.png 2>/dev/null"), new String[]{"\n"}, 0, 6).iterator();
                        while (it.hasNext()) {
                            List split$default = StringsKt.split$default(StringsKt.trim((String) it.next()).toString(), new String[]{" "}, 0, 6);
                            if (split$default.size() == 3 && StringsKt__StringsJVMKt.endsWith((String) split$default.get(0), false, ".png")) {
                                hashMap2.put(StringsKt.removeSuffix((String) split$default.get(0), ".png"), split$default.get(1) + " " + split$default.get(2));
                            }
                        }
                        this.stamps = hashMap2;
                        try {
                            map = Home.names(Home.ownConfig(new Fleet$$ExternalSyntheticLambda0(adb, 12)));
                        } catch (Exception unused) {
                            map = this.own;
                        }
                        this.own = map;
                        this.ok = true;
                        this.names = hashMap;
                        save(hashMap);
                    }
                } catch (Exception e) {
                    str = e.toString();
                }
                if (hashMap.isEmpty()) {
                    this.failedAt = System.currentTimeMillis();
                    System.err.println("RemoteLabels: no app names from the TV, trying again in 15 s: " + str);
                } else {
                    this.failedAt = 0L;
                }
                HashMap hashMap3 = this.names;
                if (hashMap3 != null) {
                    hashMap = hashMap3;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return hashMap;
    }

    public final String caps() {
        String install;
        String str = this.caps;
        if (str == null) {
            str = null;
            try {
                Adb adb = this.link.get();
                synchronized (this.running) {
                    install = Companion.install(adb, (byte[]) this.jar$delegate.getValue());
                }
                String shell = adb.shell(20000L, "CLASSPATH=" + install + " app_process / dev.tvremote.core.Caps 2>/dev/null");
                if (StringsKt.isBlank(shell)) {
                    shell = null;
                }
                if (shell != null) {
                    this.caps = shell;
                    return shell;
                }
            } catch (IOException unused) {
            }
        }
        return str;
    }

    /* JADX WARN: Code restructure failed: missing block: B:37:0x008e, code lost:
    
        if (kotlin.math.MathKt.readText$default(r4).equals(r1.get(r15)) != false) goto L39;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final byte[] icon(String pkg) {
        File file;
        File file2;
        String str;
        HashMap hashMap;
        Intrinsics.checkNotNullParameter(pkg, "pkg");
        byte[] bArr = null;
        if (this.ok) {
            Pattern compile = Pattern.compile("[\\w.]+");
            Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
            if (compile.matcher(pkg).matches()) {
                File file3 = this.cache;
                if (file3 != null) {
                    file = new File(file3, pkg.concat(".png"));
                } else {
                    file = null;
                }
                File file4 = this.cache;
                if (file4 != null) {
                    file2 = new File(file4, pkg.concat(".stamp"));
                } else {
                    file2 = null;
                }
                HashMap hashMap2 = this.stamps;
                if (hashMap2 == null) {
                    synchronized (this.running) {
                        try {
                            if (this.stamps == null && System.currentTimeMillis() - this.failedAt >= 15000) {
                                ask();
                            }
                            hashMap = this.stamps;
                        } finally {
                        }
                    }
                    hashMap2 = hashMap;
                }
                if (file != null) {
                    try {
                        if (file.length() > 0) {
                            if (hashMap2 != null) {
                                if (hashMap2.get(pkg) != null) {
                                    Intrinsics.checkNotNull(file2);
                                }
                            }
                            return MathKt.readBytes(file);
                        }
                    } catch (IOException unused) {
                    }
                }
                try {
                    ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                    Adb.Stream open = this.link.get().open(10000L, "exec:cat /data/local/tmp/tvr-meta/" + pkg + ".png");
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    byte[] bArr2 = new byte[65536];
                    while (true) {
                        try {
                            int read = open.read(10000L, bArr2, 0, 65536);
                            if (read <= 0) {
                                break;
                            }
                            byteArrayOutputStream.write(bArr2, 0, read);
                        } finally {
                        }
                    }
                    open.close();
                    if (byteArrayOutputStream.size() != 0) {
                        bArr = byteArrayOutputStream.toByteArray();
                        if (file != null) {
                            File parentFile = file.getParentFile();
                            if (parentFile != null) {
                                parentFile.mkdirs();
                            }
                            Intrinsics.checkNotNull(bArr);
                            MathKt.writeBytes(file, bArr);
                            Intrinsics.checkNotNull(file2);
                            if (hashMap2 == null || (str = (String) hashMap2.get(pkg)) == null) {
                                str = "";
                            }
                            MathKt.writeText$default(file2, str);
                        }
                    }
                } catch (IOException unused2) {
                }
            }
        }
        return bArr;
    }

    public final String label(String pkg) {
        Map map;
        Intrinsics.checkNotNullParameter(pkg, "pkg");
        String str = (String) this.own.get(pkg);
        if (str == null && (str = (String) system().get(pkg)) == null) {
            if (!this.waited && this.ok) {
                this.waited = true;
                synchronized (this.running) {
                    try {
                        if (this.stamps == null) {
                            ask();
                        }
                        map = this.names;
                        if (map == null) {
                            map = EmptyMap.INSTANCE;
                        }
                    } catch (Throwable th) {
                        throw th;
                    }
                }
            } else {
                map = EmptyMap.INSTANCE;
            }
            return (String) map.get(pkg);
        }
        return str;
    }

    public final LinkedHashMap load() {
        try {
            File file = this.cache;
            if (file != null) {
                JSONObject jSONObject = new JSONObject(MathKt.readText$default(new File(file, "names.json")));
                Iterator<String> keys = jSONObject.keys();
                Intrinsics.checkNotNullExpressionValue(keys, "keys(...)");
                Sequence asSequence = SequencesKt.asSequence(keys);
                LinkedHashMap linkedHashMap = new LinkedHashMap();
                Iterator it = ((ConstrainedOnceSequence) asSequence).iterator();
                while (it.hasNext()) {
                    Object next = it.next();
                    linkedHashMap.put(next, jSONObject.getString((String) next));
                }
                if (!linkedHashMap.isEmpty()) {
                    return linkedHashMap;
                }
                return null;
            }
            return null;
        } catch (Exception unused) {
            return null;
        }
    }

    public final Map names() {
        Map system = system();
        if (this.own.isEmpty()) {
            return system;
        }
        return MapsKt__MapsKt.plus(system, this.own);
    }

    public final void save(HashMap hashMap) {
        File file = this.cache;
        if (file != null) {
            try {
                file.mkdirs();
                File file2 = new File(file, "names.json.tmp");
                String jSONObject = new JSONObject(hashMap).toString();
                Intrinsics.checkNotNullExpressionValue(jSONObject, "toString(...)");
                MathKt.writeText$default(file2, jSONObject);
                file2.renameTo(new File(file, "names.json"));
            } catch (Exception unused) {
            }
        }
    }

    public final String stamp(String str) {
        String str2;
        HashMap hashMap;
        HashMap hashMap2 = this.stamps;
        if (hashMap2 == null) {
            synchronized (this.running) {
                try {
                    if (this.stamps == null && System.currentTimeMillis() - this.failedAt >= 15000) {
                        ask();
                    }
                    hashMap = this.stamps;
                } finally {
                }
            }
            hashMap2 = hashMap;
        }
        if (hashMap2 != null && (str2 = (String) hashMap2.get(str)) != null) {
            return str2;
        }
        try {
            File file = this.cache;
            if (file != null) {
                File file2 = new File(file, str.concat(".stamp"));
                if (!file2.exists()) {
                    file2 = null;
                }
                if (file2 != null) {
                    return MathKt.readText$default(file2);
                }
            }
        } catch (IOException unused) {
        }
        return null;
    }

    public final synchronized Map system() {
        HashMap hashMap = this.names;
        if (hashMap != null) {
            return hashMap;
        }
        if (System.currentTimeMillis() - this.failedAt < 15000) {
            return EmptyMap.INSTANCE;
        }
        LinkedHashMap load = load();
        if (load != null) {
            this.names = load;
            this.ok = true;
            new Thread(new Adb$$ExternalSyntheticLambda0(1, this), "meta-refresh");
            return load;
        }
        return ask();
    }
}
