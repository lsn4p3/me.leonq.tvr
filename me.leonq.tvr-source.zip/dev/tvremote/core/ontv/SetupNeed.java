package dev.tvremote.core.ontv;

import dev.tvremote.core.Words;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.update.Release;
import java.io.IOException;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.sequences.SequencesKt;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;

/* loaded from: classes.dex */
public abstract class SetupNeed {
    public static final LinkedHashMap MIN = MapsKt__MapsKt.linkedMapOf(new Pair("rules", "0.1.0"), new Pair("draw", "0.1.0"), new Pair("pic", "0.1.0"), new Pair("volume", "0.1.0"), new Pair("bedtimes", "0.3.1"), new Pair("notify", "0.4.2"), new Pair("invite", "0.4.2"), new Pair("ram", "0.4.2"), new Pair("ramauto", "0.42.3"), new Pair("awake", "0.7.1"), new Pair("launcher", "0.12.0"), new Pair("files", "0.8.1"), new Pair("welcome", "0.12.0"), new Pair("lock", "0.12.1"), new Pair("dim", "0.12.1"), new Pair("unextra", "0.12.1"), new Pair("holdkeys", "0.19.1"), new Pair("mic", "0.21.1"), new Pair("checkout", "0.19.1"), new Pair("schedule", "0.20.1"), new Pair("schedule_windows", "0.21.1"), new Pair("telegram", "0.21.1"), new Pair("kids", "0.21.1"), new Pair("homekey", "0.26.3"), new Pair("keytest", "0.30.1"), new Pair("support", "0.33.2"), new Pair("scenepin", "0.34.3"), new Pair("mic_offline", "0.38.1"), new Pair("mic_freespeech", "0.44.0"), new Pair("mic_engine", "0.39.1"), new Pair("family", "0.38.5"), new Pair("video", "0.42.0"), new Pair("speak", "0.42.3"), new Pair("homebar", "0.42.3"), new Pair("home_usage", "0.14.1"));

    /* loaded from: classes.dex */
    public final class Missing extends IOException {
        /* JADX WARN: Illegal instructions before constructor call */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public Missing(String str, String str2) {
            super("setup:" + r0 + ":" + str + ":" + (r1 == null ? "" : r1) + ":" + str2);
            String str3;
            if (str2.length() == 0) {
                str3 = "missing";
            } else {
                str3 = "old";
            }
            String str4 = (String) SetupNeed.MIN.get(str);
        }
    }

    public static void check(Adb adb, String str) {
        Intrinsics.checkNotNullParameter(adb, "adb");
        Regex regex = SetupUpdate.VERSION;
        String installed = SetupUpdate.installed(adb);
        if (ok(installed, str)) {
        } else {
            throw new Missing(str, installed);
        }
    }

    public static String have(Function1 sh) {
        String str;
        Intrinsics.checkNotNullParameter(sh, "sh");
        Pattern compile = Pattern.compile("versionName=(\\S+)");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        CharSequence input = (CharSequence) sh.invoke("dumpsys package dev.tvremote.setup 2>/dev/null | grep -m1 versionName=");
        Intrinsics.checkNotNullParameter(input, "input");
        Matcher matcher = compile.matcher(input);
        Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
        MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, input);
        if (access$findNext != null && (str = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)) != null) {
            return str;
        }
        return "";
    }

    public static boolean ok(String str, String str2) {
        String str3 = (String) MIN.get(str2);
        if (str3 != null) {
            if (str.length() > 0) {
                List list = Release.KEYS;
                if (MathKt.compare(str, str3) >= 0) {
                    return true;
                }
                return false;
            }
            return false;
        }
        return true;
    }

    public static String say(String lang, Throwable e) {
        Intrinsics.checkNotNullParameter(e, "e");
        Intrinsics.checkNotNullParameter(lang, "lang");
        Pattern compile = Pattern.compile("setup:(old|missing):(\\w+):([0-9.]*):(\\S*)");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        String input = SequencesKt.joinToString$default(SequencesKt.generateSequence(e, new Bloat$$ExternalSyntheticLambda1(19)), " ", new Bloat$$ExternalSyntheticLambda1(20), 30);
        Intrinsics.checkNotNullParameter(input, "input");
        Matcher matcher = compile.matcher(input);
        Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
        MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, input);
        if (access$findNext == null) {
            return null;
        }
        String str = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1);
        String feature = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(2);
        String str2 = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(3);
        String str3 = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(4);
        Intrinsics.checkNotNullParameter(feature, "feature");
        switch (feature.hashCode()) {
            case -1854767153:
                if (feature.equals("support")) {
                    feature = Words.get(lang, "core.need_support", new Pair[0]);
                    break;
                }
                break;
            case -1407250528:
                if (feature.equals("launcher")) {
                    feature = Words.get(lang, "core.need_launcher", new Pair[0]);
                    break;
                }
                break;
            case -1360467711:
                if (feature.equals("telegram")) {
                    feature = Words.get(lang, "core.need_telegram", new Pair[0]);
                    break;
                }
                break;
            case -1281860764:
                if (feature.equals("family")) {
                    feature = Words.get(lang, "core.need_family", new Pair[0]);
                    break;
                }
                break;
            case -1183699191:
                if (feature.equals("invite")) {
                    feature = Words.get(lang, "core.need_invite", new Pair[0]);
                    break;
                }
                break;
            case -1039689911:
                if (feature.equals("notify")) {
                    feature = Words.get(lang, "core.need_notify", new Pair[0]);
                    break;
                }
                break;
            case -814507151:
                if (feature.equals("keytest")) {
                    feature = Words.get(lang, "core.need_keytest", new Pair[0]);
                    break;
                }
                break;
            case -810883302:
                if (feature.equals("volume")) {
                    feature = Words.get(lang, "core.need_volume", new Pair[0]);
                    break;
                }
                break;
            case -775471735:
                if (feature.equals("scenepin")) {
                    feature = Words.get(lang, "core.need_scenepin", new Pair[0]);
                    break;
                }
                break;
            case -697920873:
                if (feature.equals("schedule")) {
                    feature = Words.get(lang, "core.need_schedule", new Pair[0]);
                    break;
                }
                break;
            case -515069133:
                if (feature.equals("holdkeys")) {
                    feature = Words.get(lang, "core.need_holdkeys", new Pair[0]);
                    break;
                }
                break;
            case -290079465:
                if (feature.equals("unextra")) {
                    feature = Words.get(lang, "core.need_unextra", new Pair[0]);
                    break;
                }
                break;
            case 99464:
                if (feature.equals("dim")) {
                    feature = Words.get(lang, "core.need_dim", new Pair[0]);
                    break;
                }
                break;
            case 108103:
                if (feature.equals("mic")) {
                    feature = Words.get(lang, "core.need_mic", new Pair[0]);
                    break;
                }
                break;
            case 110986:
                if (feature.equals("pic")) {
                    feature = Words.get(lang, "core.need_pic", new Pair[0]);
                    break;
                }
                break;
            case 112670:
                if (feature.equals("ram")) {
                    feature = Words.get(lang, "core.need_ram", new Pair[0]);
                    break;
                }
                break;
            case 3091780:
                if (feature.equals("draw")) {
                    feature = Words.get(lang, "setup_need.drawing_tv", new Pair[0]);
                    break;
                }
                break;
            case 3291757:
                if (feature.equals("kids")) {
                    feature = Words.get(lang, "kids.need_name", new Pair[0]);
                    break;
                }
                break;
            case 3327275:
                if (feature.equals("lock")) {
                    feature = Words.get(lang, "core.need_lock", new Pair[0]);
                    break;
                }
                break;
            case 93223301:
                if (feature.equals("awake")) {
                    feature = Words.get(lang, "core.need_awake", new Pair[0]);
                    break;
                }
                break;
            case 97434231:
                if (feature.equals("files")) {
                    feature = Words.get(lang, "core.need_files", new Pair[0]);
                    break;
                }
                break;
            case 108873975:
                if (feature.equals("rules")) {
                    feature = Words.get(lang, "core.need_rules", new Pair[0]);
                    break;
                }
                break;
            case 109641682:
                if (feature.equals("speak")) {
                    feature = Words.get(lang, "core.need_speak", new Pair[0]);
                    break;
                }
                break;
            case 112202875:
                if (feature.equals("video")) {
                    feature = Words.get(lang, "core.need_video", new Pair[0]);
                    break;
                }
                break;
            case 506995691:
                if (feature.equals("mic_offline")) {
                    feature = Words.get(lang, "core.need_mic_offline", new Pair[0]);
                    break;
                }
                break;
            case 976901837:
                if (feature.equals("ramauto")) {
                    feature = Words.get(lang, "core.need_ramauto", new Pair[0]);
                    break;
                }
                break;
            case 985492294:
                if (feature.equals("mic_freespeech")) {
                    feature = Words.get(lang, "core.need_mic_freespeech", new Pair[0]);
                    break;
                }
                break;
            case 1092708052:
                if (feature.equals("homebar")) {
                    feature = Words.get(lang, "core.need_homebar", new Pair[0]);
                    break;
                }
                break;
            case 1092716832:
                if (feature.equals("homekey")) {
                    feature = Words.get(lang, "core.need_homekey", new Pair[0]);
                    break;
                }
                break;
            case 1233099618:
                if (feature.equals("welcome")) {
                    feature = Words.get(lang, "core.need_welcome", new Pair[0]);
                    break;
                }
                break;
            case 1241150017:
                if (feature.equals("home_usage")) {
                    feature = Words.get(lang, "core.need_home_usage", new Pair[0]);
                    break;
                }
                break;
            case 1400046394:
                if (feature.equals("mic_engine")) {
                    feature = Words.get(lang, "core.need_mic_engine", new Pair[0]);
                    break;
                }
                break;
            case 1413559141:
                if (feature.equals("bedtimes")) {
                    feature = Words.get(lang, "core.need_bedtimes", new Pair[0]);
                    break;
                }
                break;
            case 1536904518:
                if (feature.equals("checkout")) {
                    feature = Words.get(lang, "core.need_checkout", new Pair[0]);
                    break;
                }
                break;
            case 1762743515:
                if (feature.equals("schedule_windows")) {
                    feature = Words.get(lang, "core.need_schedule_windows", new Pair[0]);
                    break;
                }
                break;
        }
        if (Intrinsics.areEqual(str, "missing")) {
            Pair[] pairArr = {new Pair("feature", feature)};
            ConcurrentHashMap concurrentHashMap = Words.books;
            return Words.get(lang, "setup_need.needs_tv_setup_app", (Pair[]) Arrays.copyOf(pairArr, 1));
        }
        Pair[] pairArr2 = {new Pair("feature", feature), new Pair("min", str2), new Pair("have", str3)};
        ConcurrentHashMap concurrentHashMap2 = Words.books;
        return Words.get(lang, "setup_need.needs_tv_setup_newer", (Pair[]) Arrays.copyOf(pairArr2, 3));
    }
}
