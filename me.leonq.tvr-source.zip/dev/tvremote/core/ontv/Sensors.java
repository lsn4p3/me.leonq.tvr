package dev.tvremote.core.ontv;

import kotlin.Pair;
import kotlin.collections.MapsKt__MapsKt;

/* loaded from: classes.dex */
public abstract class Sensors {
    public static final Object HAL_TYPES = MapsKt__MapsKt.mapOf(new Pair(0, "CPU"), new Pair(1, "GPU"), new Pair(2, "battery"), new Pair(3, "skin"), new Pair(4, "USB"), new Pair(5, "amplifier"), new Pair(9, "NPU"), new Pair(10, "TPU"), new Pair(11, "display"), new Pair(12, "modem"), new Pair(13, "SoC"), new Pair(14, "Wi-Fi"), new Pair(18, "ambient"));
}
