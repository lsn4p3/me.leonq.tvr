package dev.tvremote.core.ontv;

import dev.tvremote.core.B64;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Charsets;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.StringsKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public abstract class RulesClient {
    public static final Set SETUP_KEYS = SetsKt.setOf((Object[]) new Integer[]{183, 184, 185, 186, 190, 191, 195, 284});
    public static final Object APP_KEYS = MapsKt__MapsKt.mapOf(new Pair(190, "com.google.android.youtube.tv"), new Pair(191, "com.netflix.ninja"), new Pair(195, "com.amazon.amazonvideo.livingroom"));

    public static boolean acted(String out) {
        Intrinsics.checkNotNullParameter(out, "out");
        Pattern compile = Pattern.compile("data=\"([A-Za-z0-9+/=]+)\"");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        Matcher matcher = compile.matcher(out);
        Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
        MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, out);
        if (access$findNext != null) {
            try {
                int[] iArr = B64.INDEX;
                return new JSONObject(new String(B64.decode((String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)), Charsets.UTF_8)).optBoolean("acted");
            } catch (Exception unused) {
                return false;
            }
        }
        return false;
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [java.util.Map, java.lang.Object] */
    public static boolean appMissing(int i, Function1 function1) {
        if (((String) APP_KEYS.get(Integer.valueOf(i))) != null) {
            try {
                return !StringsKt.contains((CharSequence) function1.invoke("pm path " + r3 + " 2>/dev/null"), "package:", false);
            } catch (Exception unused) {
                return false;
            }
        }
        return false;
    }

    public static JSONObject call(Function1 sh, JSONObject jSONObject) {
        String concat;
        String str;
        Intrinsics.checkNotNullParameter(sh, "sh");
        if (jSONObject == null) {
            concat = "";
        } else {
            int[] iArr = B64.INDEX;
            String jSONObject2 = jSONObject.toString();
            Intrinsics.checkNotNullExpressionValue(jSONObject2, "toString(...)");
            byte[] bytes = jSONObject2.getBytes(Charsets.UTF_8);
            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
            concat = " --es set ".concat(B64.encode(bytes));
        }
        String str2 = (String) sh.invoke("am broadcast --include-stopped-packages -n dev.tvremote.setup/.RulesReceiver" + concat + " 2>&1");
        Matcher m7m = Census$$ExternalSyntheticOutline0.m7m("data=\"([A-Za-z0-9+/=]+)\"", "compile(...)", str2, "input", str2);
        Intrinsics.checkNotNullExpressionValue(m7m, "matcher(...)");
        MatcherMatchResult access$findNext = MathKt.access$findNext(m7m, 0, str2);
        if (access$findNext != null) {
            int[] iArr2 = B64.INDEX;
            JSONObject jSONObject3 = new JSONObject(new String(B64.decode((String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)), Charsets.UTF_8));
            if (jSONObject3.optBoolean("wanted") && !jSONObject3.optBoolean("running")) {
                sh.invoke("for p in dev.tvremote.setup dev.tvremote.home; do pm path $p >/dev/null 2>&1 || continue; dumpsys deviceidle whitelist +$p >/dev/null 2>&1; am set-standby-bucket $p active >/dev/null 2>&1; cmd appops set $p RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1; done; cmd deviceidle whitelist +dev.tvremote.setup >/dev/null 2>&1; am startservice -n dev.tvremote.setup/.RemoteService 2>&1 | grep -q Error && am start-foreground-service -n dev.tvremote.setup/.RemoteService >/dev/null 2>&1");
            }
            return jSONObject3;
        }
        String have = SetupNeed.have(sh);
        if (have.length() == 0) {
            str = "missing";
        } else if (SetupNeed.ok(have, "rules")) {
            str = "busy";
        } else {
            str = "old";
        }
        JSONObject put = Census$$ExternalSyntheticOutline0.m10m("setup", str, "have", have).put("min", SetupNeed.MIN.get("rules"));
        Intrinsics.checkNotNullExpressionValue(put, "put(...)");
        return put;
    }

    public static boolean key(int i, Function1 function1) {
        try {
            int[] iArr = B64.INDEX;
            String jSONObject = new JSONObject().put("do", "key").put("code", i).toString();
            Intrinsics.checkNotNullExpressionValue(jSONObject, "toString(...)");
            byte[] bytes = jSONObject.getBytes(Charsets.UTF_8);
            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
            return acted((String) function1.invoke("am broadcast --include-stopped-packages -n dev.tvremote.setup/.RulesReceiver" + " --es set ".concat(B64.encode(bytes)) + " 2>&1"));
        } catch (Exception unused) {
            return false;
        }
    }
}
