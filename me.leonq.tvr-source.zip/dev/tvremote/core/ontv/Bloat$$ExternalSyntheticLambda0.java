package dev.tvremote.core.ontv;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import com.android.apksig.util.RunnablesExecutor;
import dev.tvremote.core.Census;
import dev.tvremote.core.ontv.Bloat;
import dev.tvremote.core.ontv.Launchers;
import dev.tvremote.core.ontv.Setup;
import dev.tvremote.core.ontv.Wallpapers;
import dev.tvremote.update.SignedList;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyList;
import kotlin.collections.EmptyMap;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgressionIterator;
import kotlin.ranges.IntRange;
import kotlin.sequences.ConstrainedOnceSequence;
import kotlin.sequences.FilteringSequence;
import kotlin.sequences.FilteringSequence$iterator$1;
import kotlin.sequences.Sequence;
import kotlin.sequences.SequencesKt;
import kotlin.text.Charsets;
import kotlin.text.Regex;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class Bloat$$ExternalSyntheticLambda0 implements RunnablesExecutor, Function4, Setup.Log, Function3 {
    public final /* synthetic */ int $r8$classId;

    public /* synthetic */ Bloat$$ExternalSyntheticLambda0(int i) {
        this.$r8$classId = i;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // kotlin.jvm.functions.Function3
    public Object invoke(Object obj, Object obj2, Object obj3) {
        Map map;
        Iterator<String> keys;
        File file;
        EmptyList emptyList;
        JSONArray jSONArray;
        String str;
        String str2;
        String str3;
        Wallpapers.Link link;
        switch (this.$r8$classId) {
            case 0:
                byte[] bArr = (byte[]) obj;
                Intrinsics.checkNotNullParameter((String) obj3, "<unused var>");
                try {
                    JSONObject jSONObject = new JSONObject(new String(bArr, Charsets.UTF_8));
                    if (jSONObject.optInt("v") == 1) {
                        JSONObject optJSONObject = jSONObject.optJSONObject("suggest");
                        if (optJSONObject == null || (keys = optJSONObject.keys()) == null) {
                            map = null;
                        } else {
                            FilteringSequence filteringSequence = new FilteringSequence(SequencesKt.asSequence(keys), true, new Bloat$$ExternalSyntheticLambda1(0));
                            Map linkedHashMap = new LinkedHashMap();
                            FilteringSequence$iterator$1 filteringSequence$iterator$1 = new FilteringSequence$iterator$1(filteringSequence);
                            while (filteringSequence$iterator$1.hasNext()) {
                                Object next = filteringSequence$iterator$1.next();
                                linkedHashMap.put(next, optJSONObject.getString((String) next));
                            }
                            map = linkedHashMap;
                        }
                        if (map == null) {
                            map = EmptyMap.INSTANCE;
                        }
                        Set set = CollectionsKt.toSet(Bloat.parse$strings("drop", jSONObject));
                        List<String> parse$strings = Bloat.parse$strings("keep", jSONObject);
                        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(parse$strings));
                        for (String str4 : parse$strings) {
                            Intrinsics.checkNotNull(str4);
                            arrayList.add(new Regex(str4));
                        }
                        List<String> parse$strings2 = Bloat.parse$strings("factory", jSONObject);
                        ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(parse$strings2));
                        for (String str5 : parse$strings2) {
                            Intrinsics.checkNotNull(str5);
                            arrayList2.add(new Regex(str5));
                        }
                        return new Bloat.Extra(map, set, arrayList, arrayList2);
                    }
                    throw new IOException("bloat list: unknown version");
                } catch (Exception e) {
                    throw new IOException(ApkSigner$$ExternalSyntheticOutline0.m("bloat list: ", e.getMessage()));
                }
            case 5:
                byte[] bArr2 = (byte[]) obj;
                String str6 = (String) obj2;
                String b = (String) obj3;
                Intrinsics.checkNotNullParameter(b, "b");
                List list = Launchers.KEYS;
                Launchers.Gallery parse = Launchers.parse(b, bArr2);
                Launchers.cache = new Pair(Long.valueOf(System.currentTimeMillis()), parse);
                if (Launchers.testBase == null && (file = Launchers.dir) != null) {
                    try {
                        file.mkdirs();
                        List list2 = SignedList.KEYS;
                        SignedList.keep(new File(file, "launchers.json"), bArr2, str6);
                        MathKt.writeText$default(new File(file, "launchers.json.base"), b);
                    } catch (IOException unused) {
                    }
                }
                return parse;
            default:
                byte[] bArr3 = (byte[]) obj;
                String b2 = (String) obj3;
                Intrinsics.checkNotNullParameter(b2, "b");
                try {
                    JSONObject jSONObject2 = new JSONObject(new String(bArr3, Charsets.UTF_8));
                    if (jSONObject2.optInt("v") == 1) {
                        JSONArray jSONArray2 = jSONObject2.getJSONArray("walls");
                        IntRange until = MathKt.until(0, jSONArray2.length());
                        ArrayList arrayList3 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until));
                        Iterator it = until.iterator();
                        while (true) {
                            boolean z = ((IntProgressionIterator) it).hasNext;
                            Regex regex = Wallpapers.NAME;
                            String str7 = "keys(...)";
                            String str8 = "id";
                            Iterator it2 = it;
                            String str9 = "name";
                            if (z) {
                                String str10 = b2;
                                JSONObject jSONObject3 = jSONArray2.getJSONObject(((IntProgressionIterator) it2).nextInt());
                                JSONObject jSONObject4 = jSONObject3.getJSONObject("name");
                                String string = jSONObject3.getString("id");
                                Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                                Iterator<String> keys2 = jSONObject4.keys();
                                Intrinsics.checkNotNullExpressionValue(keys2, "keys(...)");
                                Sequence asSequence = SequencesKt.asSequence(keys2);
                                LinkedHashMap linkedHashMap2 = new LinkedHashMap();
                                Iterator it3 = ((ConstrainedOnceSequence) asSequence).iterator();
                                while (it3.hasNext()) {
                                    Iterator it4 = it3;
                                    Object next2 = it4.next();
                                    linkedHashMap2.put(next2, jSONObject4.getString((String) next2));
                                    it3 = it4;
                                    jSONArray2 = jSONArray2;
                                }
                                JSONArray jSONArray3 = jSONArray2;
                                String string2 = jSONObject3.getString("file");
                                Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
                                String string3 = jSONObject3.getString("sha256");
                                Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
                                Locale locale = Locale.ROOT;
                                String lowerCase = string3.toLowerCase(locale);
                                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                                String string4 = jSONObject3.getString("thumb");
                                Intrinsics.checkNotNullExpressionValue(string4, "getString(...)");
                                String string5 = jSONObject3.getString("thumb_sha256");
                                Intrinsics.checkNotNullExpressionValue(string5, "getString(...)");
                                String lowerCase2 = string5.toLowerCase(locale);
                                Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
                                String optString = jSONObject3.optString("credit");
                                Intrinsics.checkNotNullExpressionValue(optString, "optString(...)");
                                String optString2 = jSONObject3.optString("source");
                                Intrinsics.checkNotNullExpressionValue(optString2, "optString(...)");
                                String optString3 = jSONObject3.optString("license");
                                Intrinsics.checkNotNullExpressionValue(optString3, "optString(...)");
                                Wallpapers.Wall wall = new Wallpapers.Wall(string, linkedHashMap2, string2, lowerCase, string4, lowerCase2, optString, optString2, optString3, jSONObject3.optInt("bytes"));
                                if (regex.matches(string2) && regex.matches(string4) && lowerCase.length() == 64 && lowerCase2.length() == 64) {
                                    arrayList3.add(wall);
                                    it = it2;
                                    b2 = str10;
                                    jSONArray2 = jSONArray3;
                                }
                            } else {
                                String str11 = b2;
                                JSONArray optJSONArray = jSONObject2.optJSONArray("links");
                                if (optJSONArray != null) {
                                    IntRange until2 = MathKt.until(0, optJSONArray.length());
                                    ArrayList arrayList4 = new ArrayList();
                                    Iterator it5 = until2.iterator();
                                    while (((IntProgressionIterator) it5).hasNext) {
                                        JSONObject optJSONObject2 = optJSONArray.optJSONObject(((IntProgressionIterator) it5).nextInt());
                                        if (optJSONObject2 == null) {
                                            str2 = str7;
                                            str = str8;
                                            jSONArray = optJSONArray;
                                            str3 = str9;
                                            link = null;
                                        } else {
                                            JSONObject optJSONObject3 = optJSONObject2.optJSONObject(str9);
                                            if (optJSONObject3 == null) {
                                                optJSONObject3 = new JSONObject();
                                            }
                                            jSONArray = optJSONArray;
                                            JSONObject jSONObject5 = optJSONObject3;
                                            String optString4 = optJSONObject2.optString(str8);
                                            Intrinsics.checkNotNullExpressionValue(optString4, "optString(...)");
                                            str = str8;
                                            String optString5 = optJSONObject2.optString("kind");
                                            Intrinsics.checkNotNullExpressionValue(optString5, "optString(...)");
                                            Iterator<String> keys3 = jSONObject5.keys();
                                            Intrinsics.checkNotNullExpressionValue(keys3, str7);
                                            Sequence asSequence2 = SequencesKt.asSequence(keys3);
                                            str2 = str7;
                                            LinkedHashMap linkedHashMap3 = new LinkedHashMap();
                                            Iterator it6 = ((ConstrainedOnceSequence) asSequence2).iterator();
                                            while (it6.hasNext()) {
                                                Iterator it7 = it6;
                                                Object next3 = it7.next();
                                                String str12 = str9;
                                                JSONObject jSONObject6 = jSONObject5;
                                                linkedHashMap3.put(next3, jSONObject6.getString((String) next3));
                                                jSONObject5 = jSONObject6;
                                                it6 = it7;
                                                optString4 = optString4;
                                                str9 = str12;
                                            }
                                            String str13 = optString4;
                                            str3 = str9;
                                            String optString6 = optJSONObject2.optString("url");
                                            Intrinsics.checkNotNullExpressionValue(optString6, "optString(...)");
                                            String optString7 = optJSONObject2.optString("thumb");
                                            Intrinsics.checkNotNullExpressionValue(optString7, "optString(...)");
                                            String optString8 = optJSONObject2.optString("thumb_sha256");
                                            Intrinsics.checkNotNullExpressionValue(optString8, "optString(...)");
                                            String lowerCase3 = optString8.toLowerCase(Locale.ROOT);
                                            Intrinsics.checkNotNullExpressionValue(lowerCase3, "toLowerCase(...)");
                                            String optString9 = optJSONObject2.optString("credit");
                                            Intrinsics.checkNotNullExpressionValue(optString9, "optString(...)");
                                            String optString10 = optJSONObject2.optString("source");
                                            Intrinsics.checkNotNullExpressionValue(optString10, "optString(...)");
                                            String optString11 = optJSONObject2.optString("license");
                                            Intrinsics.checkNotNullExpressionValue(optString11, "optString(...)");
                                            Wallpapers.Link link2 = new Wallpapers.Link(str13, optString5, linkedHashMap3, optString6, optString7, lowerCase3, optString9, optString10, optString11, optJSONObject2.optBoolean("fade"));
                                            if (str13.length() <= 0 || !Wallpapers.KINDS.contains(optString5) || !StringsKt__StringsJVMKt.startsWith(optString6, false, "https://") || (optString7.length() != 0 && !regex.matches(optString7))) {
                                                link2 = null;
                                            }
                                            link = link2;
                                        }
                                        if (link != null) {
                                            arrayList4.add(link);
                                        }
                                        optJSONArray = jSONArray;
                                        str8 = str;
                                        str7 = str2;
                                        str9 = str3;
                                    }
                                    emptyList = arrayList4;
                                } else {
                                    emptyList = null;
                                }
                                if (emptyList == null) {
                                    emptyList = EmptyList.INSTANCE;
                                }
                                Wallpapers.Gallery gallery = new Wallpapers.Gallery(arrayList3, str11, emptyList);
                                Wallpapers.cache = new Pair(Long.valueOf(System.currentTimeMillis()), gallery);
                                return gallery;
                            }
                        }
                        throw new IOException("wallpaper list: bad entry");
                    }
                    throw new IOException("wallpaper list: unknown version");
                } catch (JSONException e2) {
                    throw new IOException(ApkSigner$$ExternalSyntheticOutline0.m("wallpaper list: ", e2.getMessage()));
                }
        }
    }

    public Object invoke(Object obj, Object obj2, String stack, Object obj3) {
        String kind = (String) obj;
        String msg = (String) obj2;
        Intrinsics.checkNotNullParameter(kind, "kind");
        Intrinsics.checkNotNullParameter(msg, "msg");
        Intrinsics.checkNotNullParameter(stack, "stack");
        Census.crash(kind, msg, stack, (Function1) obj3);
        return Unit.INSTANCE;
    }
}
