package dev.tvremote.core.ontv;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.adb.Mdns;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda5;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.collections.AbstractList;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptySet;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.ArrayIterator;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class Privacy {
    public static final LinkedHashMap PERM_TAG = MapsKt__MapsKt.linkedMapOf(new Pair("RECORD_AUDIO", "mic"), new Pair("CAMERA", "cam"), new Pair("ACCESS_FINE_LOCATION", "loc"), new Pair("ACCESS_COARSE_LOCATION", "loc"), new Pair("ACCESS_BACKGROUND_LOCATION", "loc"), new Pair("READ_CONTACTS", "contacts"), new Pair("READ_PHONE_STATE", "phone"), new Pair("READ_CALL_LOG", "phone"), new Pair("READ_SMS", "phone"), new Pair("BLUETOOTH_SCAN", "nearby"), new Pair("NEARBY_WIFI_DEVICES", "nearby"));
    public static final Object OP_TAG = MapsKt__MapsKt.mapOf(new Pair("RECORD_AUDIO", "mic"), new Pair("CAMERA", "cam"), new Pair("FINE_LOCATION", "loc"), new Pair("COARSE_LOCATION", "loc"));
    public static final List ORDER = ArraysKt.asList(new String[]{"mic", "cam", "loc", "a11y", "notif", "acr", "track", "ads", "admin", "overlay", "usage", "assist", "contacts", "phone", "nearby", "boot"});
    public static final Regex PKG = new Regex("[A-Za-z][\\w]*(\\.[\\w]+)+");
    public static final Regex PERM = new Regex("^ +android\\.permission\\.(\\w+): granted=true");
    public static final Regex OPLINE = new Regex("^(?:Uid mode: )?(RECORD_AUDIO|CAMERA|FINE_LOCATION|COARSE_LOCATION): (\\w+)(?:; time=\\+?([0-9dhms]+) ago)?");

    /* loaded from: classes.dex */
    public final class Job {
        public long at;
        public int id;
        public final AdbLink link;
        public final Object lock;
        public String msg;
        public final ArrayList rows;
        public String state;
        public boolean stopped;
        public Adb.Stream stream;
        public long took;
        public int total;

        public Job(AdbLink link) {
            Intrinsics.checkNotNullParameter(link, "link");
            this.link = link;
            this.lock = new Object();
            this.rows = new ArrayList();
            this.state = "none";
            this.msg = "";
        }

        public final JSONObject change(String str, Function1 function1) {
            JSONObject jSONObject;
            Object obj;
            synchronized (this.lock) {
                try {
                    Iterator it = this.rows.iterator();
                    while (true) {
                        jSONObject = null;
                        if (it.hasNext()) {
                            obj = it.next();
                            if (Intrinsics.areEqual(((JSONObject) obj).optString("pkg"), str)) {
                                break;
                            }
                        } else {
                            obj = null;
                            break;
                        }
                    }
                    JSONObject jSONObject2 = (JSONObject) obj;
                    if (jSONObject2 != null) {
                        function1.invoke(jSONObject2);
                        jSONObject = new JSONObject(jSONObject2.toString());
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
            return jSONObject;
        }

        public final JSONObject snapshot(int i, int i2) {
            JSONObject put;
            synchronized (this.lock) {
                try {
                    int i3 = 0;
                    if (i2 == this.id) {
                        i3 = MathKt.coerceIn(i, 0, this.rows.size());
                    }
                    JSONObject put2 = new JSONObject().put("id", this.id).put("state", this.state).put("total", this.total).put("n", this.rows.size()).put("at", this.at).put("took", this.took).put("msg", this.msg);
                    ArrayList arrayList = this.rows;
                    List subList = arrayList.subList(i3, arrayList.size());
                    Intrinsics.checkNotNullExpressionValue(subList, "subList(...)");
                    ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(subList));
                    Iterator it = subList.iterator();
                    while (it.hasNext()) {
                        arrayList2.add(new JSONObject(((JSONObject) it.next()).toString()));
                    }
                    put = put2.put("rows", new JSONArray((Collection) arrayList2));
                } catch (Throwable th) {
                    throw th;
                }
            }
            Intrinsics.checkNotNullExpressionValue(put, "synchronized(...)");
            return put;
        }

        /* JADX WARN: Type inference failed for: r0v0, types: [kotlin.jvm.internal.Ref$IntRef, java.lang.Object] */
        public final JSONObject start() {
            ?? obj = new Object();
            synchronized (this.lock) {
                if (Intrinsics.areEqual(this.state, "running")) {
                    return snapshot(0, this.id);
                }
                this.rows.clear();
                int i = this.id + 1;
                this.id = i;
                obj.element = i;
                this.state = "running";
                this.total = 0;
                this.msg = "";
                this.stopped = false;
                this.at = System.currentTimeMillis();
                this.took = 0L;
                Thread thread = new Thread(new Guard$$ExternalSyntheticLambda5(7, this, (Object) obj), "privacy");
                thread.setDaemon(true);
                thread.start();
                return snapshot(0, obj.element);
            }
        }
    }

    /* loaded from: classes.dex */
    public final class Reader {
        public final HashSet a11y;
        public final HashSet admin;
        public final HashSet assist;
        public String cur;
        public boolean done;
        public final HashSet kn;
        public final Map known;
        public final HashSet notif;
        public final HashSet off;
        public final HashSet overlay;
        public final HashMap perms;
        public final HashMap revoked;
        public String sec;
        public final HashSet sys;
        public int total;
        public final HashSet usage;

        public Reader() {
            LinkedHashMap linkedHashMap = Privacy.PERM_TAG;
            this.known = Privacy.known();
            this.sec = "";
            this.sys = new HashSet();
            this.off = new HashSet();
            this.kn = new HashSet();
            this.a11y = new HashSet();
            this.notif = new HashSet();
            this.assist = new HashSet();
            this.admin = new HashSet();
            this.overlay = new HashSet();
            this.usage = new HashSet();
            this.perms = new HashMap();
            this.revoked = new HashMap();
        }

        /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
        /* JADX WARN: Failed to find 'out' block for switch in B:311:0x0754. Please report as an issue. */
        /* JADX WARN: Type inference failed for: r12v8, types: [java.util.Map, java.lang.Object] */
        public final JSONObject line(String str) {
            Object obj;
            Object obj2;
            HashSet hashSet;
            HashSet hashSet2;
            Object obj3;
            HashSet hashSet3;
            HashSet hashSet4;
            Object obj4;
            Object obj5;
            HashMap hashMap;
            MatcherMatchResult find;
            Object obj6;
            String str2;
            Object obj7;
            Pair pair;
            boolean z;
            String str3;
            String str4;
            Set set;
            HashSet hashSet5;
            String str5;
            Object obj8;
            String str6;
            String str7;
            String str8;
            String str9;
            Long valueOf;
            long j;
            long j2;
            int i = 0;
            String trimEnd = StringsKt.trimEnd(str, '\r');
            if (StringsKt__StringsJVMKt.startsWith(trimEnd, false, "#")) {
                String substring = trimEnd.substring(1);
                Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
                String obj9 = StringsKt.trim(substring).toString();
                if (StringsKt__StringsJVMKt.startsWith(obj9, false, "total ")) {
                    String substring2 = obj9.substring(6);
                    Intrinsics.checkNotNullExpressionValue(substring2, "substring(...)");
                    Integer intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull(StringsKt.trim(substring2).toString());
                    if (intOrNull != null) {
                        i = intOrNull.intValue();
                    }
                    this.total = i;
                    return null;
                }
                if (obj9.equals("done")) {
                    this.done = true;
                    return null;
                }
                this.sec = obj9;
                this.cur = null;
                return null;
            }
            boolean startsWith = StringsKt__StringsJVMKt.startsWith(trimEnd, false, "A ");
            HashSet hashSet6 = this.usage;
            HashSet hashSet7 = this.overlay;
            HashSet hashSet8 = this.admin;
            HashSet hashSet9 = this.notif;
            HashSet hashSet10 = this.a11y;
            HashMap hashMap2 = this.revoked;
            HashSet hashSet11 = this.sys;
            HashMap hashMap3 = this.perms;
            HashSet hashSet12 = this.off;
            HashSet hashSet13 = this.kn;
            HashSet hashSet14 = this.assist;
            String str10 = "overlay";
            String str11 = "admin";
            String str12 = "notif";
            if (!startsWith) {
                obj = "overlay";
                obj2 = "usage";
                hashSet = hashSet7;
                hashSet2 = hashSet11;
                obj3 = "revoked";
                hashSet3 = hashSet12;
                hashSet4 = hashSet13;
                obj4 = "assist";
                obj5 = "notif";
                hashMap = hashMap2;
            } else if (!Intrinsics.areEqual(this.sec, "perms")) {
                obj = "overlay";
                obj2 = "usage";
                hashSet2 = hashSet11;
                obj3 = "revoked";
                hashSet3 = hashSet12;
                obj4 = "assist";
                obj5 = "notif";
                hashSet = hashSet7;
                hashMap = hashMap2;
                hashSet4 = hashSet13;
            } else {
                List split$default = StringsKt.split$default(trimEnd, new String[]{" "}, 4, 2);
                if (split$default.size() < 3 || !Privacy.PKG.matches((CharSequence) split$default.get(2))) {
                    return null;
                }
                String str13 = (String) split$default.get(2);
                if (3 < split$default.size()) {
                    obj6 = split$default.get(3);
                } else {
                    obj6 = "";
                }
                String str14 = (String) obj6;
                Set set2 = (Set) hashMap3.get(str13);
                EmptySet emptySet = EmptySet.INSTANCE;
                if (set2 == null) {
                    set2 = emptySet;
                }
                HashSet hashSet15 = new HashSet();
                ArrayList arrayList = new ArrayList();
                Iterator it = set2.iterator();
                while (it.hasNext()) {
                    ArrayList arrayList2 = arrayList;
                    HashSet hashSet16 = hashSet6;
                    String str15 = (String) Privacy.PERM_TAG.get((String) it.next());
                    if (str15 != null) {
                        hashSet15.add(str15);
                    }
                    hashSet6 = hashSet16;
                    arrayList = arrayList2;
                }
                HashSet hashSet17 = hashSet6;
                ArrayList arrayList3 = arrayList;
                if (set2.contains("RECEIVE_BOOT_COMPLETED") && !hashSet11.contains(str13)) {
                    hashSet15.add("boot");
                }
                Set set3 = (Set) hashMap2.get(str13);
                if (set3 == null) {
                    set3 = emptySet;
                }
                ArrayList arrayList4 = new ArrayList();
                Iterator it2 = set3.iterator();
                while (it2.hasNext()) {
                    Set set4 = set2;
                    Iterator it3 = it2;
                    String str16 = (String) Privacy.PERM_TAG.get((String) it2.next());
                    if (str16 != null) {
                        arrayList4.add(str16);
                    }
                    it2 = it3;
                    set2 = set4;
                }
                Set set5 = set2;
                Set set6 = CollectionsKt.toSet(arrayList4);
                HashMap hashMap4 = new HashMap();
                HashSet hashSet18 = new HashSet();
                Set set7 = set6;
                Iterator it4 = StringsKt.split$default(str14, new char[]{'|'}).iterator();
                while (it4.hasNext()) {
                    String str17 = (String) it4.next();
                    Iterator it5 = it4;
                    HashSet hashSet19 = hashSet11;
                    MatcherMatchResult find2 = Privacy.OPLINE.find(StringsKt.trim(str17).toString(), 0);
                    if (find2 == null || (str6 = (String) Privacy.OP_TAG.get(((MatcherMatchResult$groupValues$1) find2.getGroupValues()).get(1))) == null || Intrinsics.areEqual(((MatcherMatchResult$groupValues$1) find2.getGroupValues()).get(2), "ignore") || Intrinsics.areEqual(((MatcherMatchResult$groupValues$1) find2.getGroupValues()).get(2), "deny") || Intrinsics.areEqual(((MatcherMatchResult$groupValues$1) find2.getGroupValues()).get(2), "errored")) {
                        hashSet11 = hashSet19;
                        it4 = it5;
                    } else {
                        if (((CharSequence) ((MatcherMatchResult$groupValues$1) find2.getGroupValues()).get(3)).length() > 0) {
                            String t = (String) ((MatcherMatchResult$groupValues$1) find2.getGroupValues()).get(3);
                            Intrinsics.checkNotNullParameter(t, "t");
                            Pattern compile = Pattern.compile("^(?:(\\d+)d)?(?:(\\d+)h)?(?:(\\d+)m(?!s))?(?:(\\d+)s)?(?:(\\d+)ms)?$");
                            str8 = str10;
                            Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                            Matcher matcher = compile.matcher(t);
                            Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
                            MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, t);
                            if (access$findNext == null || t.length() == 0) {
                                valueOf = null;
                                str9 = str11;
                            } else {
                                List groupValues = access$findNext.getGroupValues();
                                ArrayList arrayList5 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(groupValues));
                                ArrayIterator arrayIterator = new ArrayIterator((AbstractList) groupValues);
                                while (arrayIterator.hasNext()) {
                                    Long longOrNull = StringsKt__StringNumberConversionsKt.toLongOrNull((String) arrayIterator.next());
                                    if (longOrNull != null) {
                                        j = longOrNull.longValue();
                                    } else {
                                        j = 0;
                                    }
                                    arrayList5.add(Long.valueOf(j));
                                }
                                str9 = str11;
                                valueOf = Long.valueOf(((Number) arrayList5.get(4)).longValue() + (((Number) arrayList5.get(3)).longValue() * 60) + (3600 * ((Number) arrayList5.get(2)).longValue()) + (((Number) arrayList5.get(1)).longValue() * 86400));
                            }
                            if (valueOf != null) {
                                long longValue = valueOf.longValue();
                                Long l = (Long) hashMap4.get(str6);
                                if (l != null) {
                                    j2 = l.longValue();
                                } else {
                                    j2 = Long.MAX_VALUE;
                                }
                                str7 = str9;
                                hashMap4.put(str6, Long.valueOf(Math.min(j2, longValue)));
                            } else {
                                str7 = str9;
                            }
                        } else {
                            str7 = str11;
                            str8 = str10;
                        }
                        if (StringsKt.contains(str17, "(running)", false)) {
                            hashSet18.add(str6);
                        }
                        hashSet11 = hashSet19;
                        it4 = it5;
                        str10 = str8;
                        str11 = str7;
                    }
                }
                String str18 = str11;
                String str19 = str10;
                HashSet hashSet20 = hashSet11;
                if (hashSet10.contains(str13)) {
                    hashSet15.add("a11y");
                }
                if (hashSet9.contains(str13)) {
                    hashSet15.add("notif");
                }
                String str20 = str18;
                if (hashSet8.contains(str13)) {
                    hashSet15.add(str20);
                }
                if (hashSet7.contains(str13)) {
                    str2 = str19;
                    hashSet15.add(str2);
                } else {
                    str2 = str19;
                }
                if (hashSet17.contains(str13)) {
                    hashSet15.add("usage");
                }
                if (hashSet14.contains(str13)) {
                    obj7 = "assist";
                    hashSet15.add(obj7);
                } else {
                    obj7 = "assist";
                }
                if (hashSet13.contains(str13)) {
                    pair = (Pair) this.known.get(str13);
                } else {
                    pair = null;
                }
                if (pair != null) {
                    hashSet15.add(pair.first);
                }
                boolean contains = hashSet20.contains(str13);
                boolean contains2 = hashSet12.contains(str13);
                HashSet hashSet21 = new HashSet();
                Iterator it6 = ArraysKt.asList(new String[]{"mic", "cam", "loc"}).iterator();
                while (true) {
                    z = contains2;
                    if (!it6.hasNext()) {
                        break;
                    }
                    boolean z2 = contains;
                    String str21 = (String) it6.next();
                    if (hashSet18.contains(str21)) {
                        hashSet5 = hashSet18;
                        JSONObject jSONObject = new JSONObject();
                        str5 = str2;
                        StringBuilder sb = new StringBuilder();
                        sb.append(str21);
                        obj8 = obj7;
                        sb.append("_now");
                        arrayList3.add(jSONObject.put("id", sb.toString()));
                        hashSet21.add(str21);
                        hashSet15.add(str21);
                    } else {
                        str5 = str2;
                        obj8 = obj7;
                        hashSet5 = hashSet18;
                        ArrayList arrayList6 = arrayList3;
                        Long l2 = (Long) hashMap4.get(str21);
                        if (l2 != null) {
                            String str22 = str20;
                            arrayList6.add(new JSONObject().put("id", str21 + "_used").put("n", l2.longValue()));
                            hashSet21.add(str21);
                            hashSet15.add(str21);
                            arrayList3 = arrayList6;
                            contains2 = z;
                            contains = z2;
                            hashSet18 = hashSet5;
                            hashMap4 = hashMap4;
                            obj7 = obj8;
                            str12 = str12;
                            str2 = str5;
                            str20 = str22;
                        } else {
                            arrayList3 = arrayList6;
                        }
                    }
                    contains2 = z;
                    contains = z2;
                    hashSet18 = hashSet5;
                    obj7 = obj8;
                    str2 = str5;
                }
                String str23 = str2;
                String str24 = str12;
                Object obj10 = obj7;
                HashMap hashMap5 = hashMap4;
                boolean z3 = contains;
                String str25 = str20;
                HashSet hashSet22 = hashSet18;
                ArrayList arrayList7 = arrayList3;
                for (String str26 : ArraysKt.asList(new String[]{"a11y", "notif", "admin", "overlay", "usage", "assist", "boot"})) {
                    if (hashSet15.contains(str26)) {
                        arrayList7.add(new JSONObject().put("id", str26));
                    }
                }
                if (pair != null) {
                    arrayList7.add(new JSONObject().put("id", pair.first).put("name", pair.second));
                }
                for (String str27 : ArraysKt.asList(new String[]{"mic", "cam", "loc"})) {
                    if (hashSet15.contains(str27) && !hashSet21.contains(str27)) {
                        arrayList7.add(new JSONObject().put("id", str27 + "_idle"));
                    }
                }
                boolean startsWith2 = StringsKt__StringsJVMKt.startsWith(str13, false, "dev.tvremote.");
                if (startsWith2) {
                    str4 = "own";
                } else {
                    LinkedHashMap linkedHashMap = Privacy.PERM_TAG;
                    LinkedHashMap linkedHashMap2 = new LinkedHashMap();
                    for (Map.Entry entry : hashMap5.entrySet()) {
                        if (hashSet21.contains((String) entry.getKey())) {
                            linkedHashMap2.put(entry.getKey(), entry.getValue());
                        }
                    }
                    if (pair != null) {
                        str3 = (String) pair.first;
                    } else {
                        str3 = null;
                    }
                    str4 = "low";
                    if (!z) {
                        if (!hashSet22.isEmpty()) {
                            Iterator it7 = hashSet22.iterator();
                            while (it7.hasNext()) {
                                String str28 = (String) it7.next();
                                if (Intrinsics.areEqual(str28, "mic") || Intrinsics.areEqual(str28, "cam")) {
                                    break;
                                }
                            }
                        }
                        if (!linkedHashMap2.isEmpty()) {
                            for (Map.Entry entry2 : linkedHashMap2.entrySet()) {
                                String str29 = (String) entry2.getKey();
                                long longValue2 = ((Number) entry2.getValue()).longValue();
                                if (Intrinsics.areEqual(str29, "mic") || Intrinsics.areEqual(str29, "cam")) {
                                    if (longValue2 <= 86400) {
                                        break;
                                    }
                                }
                            }
                        }
                        if (!Intrinsics.areEqual(str3, "acr") && !hashSet15.contains("a11y")) {
                            if (!linkedHashMap2.isEmpty() || !hashSet22.isEmpty() || hashSet15.contains(str24) || hashSet15.contains(str25) || hashSet15.contains(obj10) || str3 != null || (!z3 && (hashSet15.contains("mic") || hashSet15.contains("cam") || hashSet15.contains("loc") || hashSet15.contains(str23)))) {
                                str4 = "med";
                            }
                        }
                        str4 = "high";
                    }
                }
                ArrayList arrayList8 = new ArrayList();
                for (Object obj11 : set5) {
                    if (Privacy.PERM_TAG.containsKey((String) obj11)) {
                        arrayList8.add(obj11);
                    }
                }
                JSONObject put = Census$$ExternalSyntheticOutline0.m10m("pkg", str13, "grade", str4).put("sys", z3);
                String[] strArr = Setup.GOOGLE;
                JSONObject put2 = put.put("keep", Rescue.mustKeep(str13)).put("off", z).put("own", startsWith2);
                List list = Privacy.ORDER;
                ArrayList arrayList9 = new ArrayList();
                for (Object obj12 : list) {
                    if (hashSet15.contains((String) obj12)) {
                        arrayList9.add(obj12);
                    }
                }
                JSONObject put3 = put2.put("tags", new JSONArray((Collection) arrayList9));
                List list2 = Privacy.ORDER;
                ArrayList arrayList10 = new ArrayList();
                for (Object obj13 : list2) {
                    String str30 = (String) obj13;
                    Set set8 = set7;
                    if (set8.contains(str30) && !hashSet15.contains(str30)) {
                        arrayList10.add(obj13);
                    }
                    set7 = set8;
                }
                JSONObject put4 = put3.put("gone", new JSONArray((Collection) arrayList10)).put("ev", new JSONArray((Collection) arrayList7)).put("perms", new JSONArray((Collection) arrayList8));
                Set set9 = (Set) hashMap2.get(str13);
                if (set9 == null) {
                    set = emptySet;
                } else {
                    set = set9;
                }
                JSONObject put5 = put4.put("revoked", new JSONArray((Collection) CollectionsKt.toList(set)));
                Intrinsics.checkNotNullExpressionValue(put5, "put(...)");
                return put5;
            }
            String obj14 = StringsKt.trim(trimEnd).toString();
            if (obj14.length() != 0 && !obj14.equals("null")) {
                String str31 = this.sec;
                switch (str31.hashCode()) {
                    case -1408204183:
                        if (str31.equals(obj4)) {
                            Iterator it8 = StringsKt.split$default(obj14, new char[]{':'}).iterator();
                            while (it8.hasNext()) {
                                hashSet14.add(Privacy.access$comp((String) it8.next()));
                            }
                        }
                        return null;
                    case -1091287984:
                        if (!str31.equals(obj)) {
                            return null;
                        }
                        hashSet.add(obj14);
                        return null;
                    case 109935:
                        if (!str31.equals("off")) {
                            return null;
                        }
                        hashSet3.add(StringsKt.removePrefix(obj14, "package:"));
                        return null;
                    case 114381:
                        if (str31.equals("sys")) {
                            hashSet2.add(StringsKt.removePrefix(obj14, "package:"));
                            return null;
                        }
                        return null;
                    case 2938456:
                        if (str31.equals("a11y")) {
                            Iterator it9 = StringsKt.split$default(obj14, new char[]{':'}).iterator();
                            while (it9.hasNext()) {
                                hashSet10.add(Privacy.access$comp((String) it9.next()));
                            }
                        }
                        return null;
                    case 92668751:
                        if (!str31.equals("admin")) {
                            return null;
                        }
                        hashSet8.add(Privacy.access$comp(obj14));
                        return null;
                    case 102204227:
                        if (str31.equals("known")) {
                            hashSet4.add(StringsKt.removePrefix(obj14, "package:"));
                            return null;
                        }
                        return null;
                    case 105008944:
                        if (str31.equals(obj5)) {
                            Iterator it10 = StringsKt.split$default(obj14, new char[]{':'}).iterator();
                            while (it10.hasNext()) {
                                hashSet9.add(Privacy.access$comp((String) it10.next()));
                            }
                        }
                        return null;
                    case 106556291:
                        if (str31.equals("perms")) {
                            if (StringsKt__StringsJVMKt.startsWith(trimEnd, false, "  Package [")) {
                                String substringAfter = StringsKt.substringAfter(trimEnd, '[', trimEnd);
                                this.cur = StringsKt.substringBefore(substringAfter, ']', substringAfter);
                                return null;
                            }
                            if (!StringsKt__StringsJVMKt.startsWith(trimEnd, false, " ")) {
                                this.cur = null;
                                return null;
                            }
                            String str32 = this.cur;
                            if (str32 != null && (find = Privacy.PERM.find(trimEnd, 0)) != null) {
                                Object obj15 = hashMap3.get(str32);
                                if (obj15 == null) {
                                    obj15 = new LinkedHashSet();
                                    hashMap3.put(str32, obj15);
                                }
                                ((Set) obj15).add(((MatcherMatchResult$groupValues$1) find.getGroupValues()).get(1));
                                return null;
                            }
                            return null;
                        }
                        break;
                    case 111574433:
                        if (str31.equals(obj2)) {
                            hashSet6.add(obj14);
                            return null;
                        }
                        break;
                    case 1100137118:
                        if (str31.equals(obj3)) {
                            List split$default2 = StringsKt.split$default(obj14, new String[]{" "}, 0, 6);
                            if (split$default2.size() == 2 && Privacy.PKG.matches((CharSequence) split$default2.get(0))) {
                                Object obj16 = split$default2.get(0);
                                Object obj17 = hashMap.get(obj16);
                                if (obj17 == null) {
                                    obj17 = new LinkedHashSet();
                                    hashMap.put(obj16, obj17);
                                }
                                ((Set) obj17).add(split$default2.get(1));
                                return null;
                            }
                        }
                        break;
                }
            }
            return null;
        }
    }

    public static final String access$comp(String str) {
        String obj = StringsKt.trim(str).toString();
        return StringsKt.trim(StringsKt.substringBefore(obj, '/', obj)).toString();
    }

    public static String command(Set knownPkgs) {
        int i;
        Comparable comparable;
        int i2;
        String str;
        Intrinsics.checkNotNullParameter(knownPkgs, "knownPkgs");
        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
        Set keySet = PERM_TAG.keySet();
        Intrinsics.checkNotNullExpressionValue(keySet, "<get-keys>(...)");
        String m = Census$$ExternalSyntheticOutline0.m(CollectionsKt.joinToString$default(keySet, "|", null, null, null, 62), "|RECEIVE_BOOT_COMPLETED");
        ArrayList arrayList = new ArrayList();
        for (Object obj : knownPkgs) {
            if (PKG.matches((String) obj)) {
                arrayList.add(obj);
            }
        }
        String joinToString$default = CollectionsKt.joinToString$default(arrayList, "|", null, null, new Bloat$$ExternalSyntheticLambda1(12), 30);
        if (joinToString$default.length() == 0) {
            joinToString$default = "x\\.none";
        }
        String m2 = Census$$ExternalSyntheticOutline0.m("\nionice -c 3 -p $$ 2>/dev/null\necho '#sys'; pm list packages -s 2>/dev/null\necho '#off'; pm list packages -d 2>/dev/null\nKN=$(pm list packages 2>/dev/null | grep -E '^package:(", joinToString$default, ")$')\necho '#known'; echo \"$KN\"\nA=$(settings get secure enabled_accessibility_services 2>/dev/null); echo '#a11y'; echo \"$A\"\nL=$(settings get secure enabled_notification_listeners 2>/dev/null); echo '#notif'; echo \"$L\"\nV=$(settings get secure assistant 2>/dev/null; settings get secure voice_interaction_service 2>/dev/null; settings get secure voice_recognition_service 2>/dev/null); echo '#assist'; echo \"$V\"\nM=$(dumpsys device_policy 2>/dev/null | grep -A8 'Enabled Device Admins' | grep -E '^ +[A-Za-z0-9_.]+/[A-Za-z0-9_.$]+:$'); echo '#admin'; echo \"$M\"\nO=$(appops query-op SYSTEM_ALERT_WINDOW allow 2>/dev/null); echo '#overlay'; echo \"$O\"\nU=$(appops query-op GET_USAGE_STATS allow 2>/dev/null); echo '#usage'; echo \"$U\"\nR=$(cat /data/local/tmp/tvr-privacy-revoked.txt 2>/dev/null); echo '#revoked'; echo \"$R\"\nD=$(dumpsys package packages 2>/dev/null | grep -E '^[A-Za-z]|^  Package \\[|^ +android\\.permission\\.(", m, "): granted=true')\necho '#perms'; echo \"$D\"\nH=$(echo \"$D\" | sed -nE -e '/^[A-Za-z]/{s/.*//;h;}' -e '/^  Package \\[/{s/^  Package \\[([^]]*)\\].*/\\1/;h;}' -e '/permission\\.(RECORD_AUDIO|CAMERA|ACCESS_[A-Z_]*LOCATION|READ_CONTACTS|READ_PHONE_STATE|READ_CALL_LOG|READ_SMS|BLUETOOTH_SCAN|NEARBY_WIFI_DEVICES): granted/{g;p;}')\nC=$(printf '%s\\n' \"$H\" \"$A\" \"$L\" \"$V\" \"$M\" \"$O\" \"$U\" \"$KN\" \"$R\" | tr ':' '\\n' | sed -E 's|/.*||;s/ .*//;s/^ +//;s/^package://' | grep -E '^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$' | sort -u)\necho \"#total $(echo \"$C\" | wc -l)\"\nn=0\nfor p in $C; do n=$((n+1)); echo \"A $n $p $(appops get $p 2>/dev/null | grep -E '(RECORD_AUDIO|CAMERA|FINE_LOCATION|COARSE_LOCATION):' | tr '\\n' '|')\"; sleep 0.05; done\necho '#done'\n");
        Intrinsics.checkNotNullParameter(m2, "<this>");
        List lines = StringsKt.lines(m2);
        ArrayList arrayList2 = new ArrayList();
        for (Object obj2 : lines) {
            if (!StringsKt.isBlank((String) obj2)) {
                arrayList2.add(obj2);
            }
        }
        ArrayList arrayList3 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList2));
        Iterator it = arrayList2.iterator();
        while (true) {
            i = 0;
            if (!it.hasNext()) {
                break;
            }
            String str2 = (String) it.next();
            int length = str2.length();
            while (true) {
                if (i < length) {
                    if (!MathKt.isWhitespace(str2.charAt(i))) {
                        break;
                    }
                    i++;
                } else {
                    i = -1;
                    break;
                }
            }
            if (i == -1) {
                i = str2.length();
            }
            arrayList3.add(Integer.valueOf(i));
        }
        Iterator it2 = arrayList3.iterator();
        if (!it2.hasNext()) {
            comparable = null;
        } else {
            comparable = (Comparable) it2.next();
            while (it2.hasNext()) {
                Comparable comparable2 = (Comparable) it2.next();
                if (comparable.compareTo(comparable2) > 0) {
                    comparable = comparable2;
                }
            }
        }
        Integer num = (Integer) comparable;
        if (num != null) {
            i2 = num.intValue();
        } else {
            i2 = 0;
        }
        int length2 = m2.length();
        lines.size();
        int lastIndex = CollectionsKt__CollectionsKt.getLastIndex(lines);
        ArrayList arrayList4 = new ArrayList();
        for (Object obj3 : lines) {
            int i3 = i + 1;
            if (i >= 0) {
                String str3 = (String) obj3;
                if ((i == 0 || i == lastIndex) && StringsKt.isBlank(str3)) {
                    str = null;
                } else {
                    str = StringsKt.drop(str3, i2);
                }
                if (str != null) {
                    arrayList4.add(str);
                }
                i = i3;
            } else {
                CollectionsKt__CollectionsKt.throwIndexOverflow();
                throw null;
            }
        }
        StringBuilder sb = new StringBuilder(length2);
        CollectionsKt.joinTo(arrayList4, sb, "\n", "", "", "...", null);
        return ApkSigner$$ExternalSyntheticOutline0.m("nice -n 19 sh -c ", Mdns.q(sb.toString()));
    }

    public static Map known() {
        String str;
        LinkedHashMap suggest = Bloat.suggest();
        ArrayList arrayList = new ArrayList();
        for (Map.Entry entry : suggest.entrySet()) {
            String str2 = (String) entry.getKey();
            String input = (String) entry.getValue();
            Pattern compile = Pattern.compile("(?i)recogni");
            Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
            Intrinsics.checkNotNullParameter(input, "input");
            Pair pair = null;
            if (compile.matcher(input).find()) {
                str = "acr";
            } else {
                Pattern compile2 = Pattern.compile("(?i)telemetry|analytics|tracking|usage logger");
                Intrinsics.checkNotNullExpressionValue(compile2, "compile(...)");
                if (compile2.matcher(input).find()) {
                    str = "track";
                } else {
                    Pattern compile3 = Pattern.compile("(?i)\\bads?\\b|advert");
                    Intrinsics.checkNotNullExpressionValue(compile3, "compile(...)");
                    if (compile3.matcher(input).find()) {
                        str = "ads";
                    } else {
                        str = null;
                    }
                }
            }
            if (str != null) {
                pair = new Pair(str2, new Pair(str, input));
            }
            if (pair != null) {
                arrayList.add(pair);
            }
        }
        return MapsKt__MapsKt.toMap(arrayList);
    }
}
