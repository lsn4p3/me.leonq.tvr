package dev.tvremote.core.ontv;

import java.util.HashMap;
import java.util.Locale;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt__StringNumberConversionsKt;

/* loaded from: classes.dex */
public final /* synthetic */ class Power$$ExternalSyntheticLambda2 implements Function1 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ HashMap f$0;

    public /* synthetic */ Power$$ExternalSyntheticLambda2(HashMap hashMap, int i) {
        this.$r8$classId = i;
        this.f$0 = hashMap;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        int i;
        String k = (String) obj;
        switch (this.$r8$classId) {
            case 0:
                Intrinsics.checkNotNullParameter(k, "k");
                String str = (String) this.f$0.get(k);
                if (str != null) {
                    return StringsKt__StringNumberConversionsKt.toLongOrNull(str);
                }
                return null;
            case 1:
                Intrinsics.checkNotNullParameter(k, "it");
                Integer num = (Integer) this.f$0.get(k);
                if (num != null) {
                    i = num.intValue();
                } else {
                    i = 0;
                }
                return Integer.valueOf(-i);
            default:
                Intrinsics.checkNotNullParameter(k, "it");
                String str2 = (String) this.f$0.get(k);
                if (str2 != null) {
                    k = str2;
                }
                String lowerCase = k.toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                return lowerCase;
        }
    }
}
