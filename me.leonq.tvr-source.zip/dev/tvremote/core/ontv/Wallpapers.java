package dev.tvremote.core.ontv;

import java.io.IOException;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;

/* loaded from: classes.dex */
public abstract class Wallpapers {
    public static final Set KINDS;
    public static final Regex NAME;
    public static final List bases = ArraysKt.asList(new String[]{"https://tvremote.pages.dev/home/", "https://raw.githubusercontent.com/HoangTran0410/tv-remote/main/docs/home/"});
    public static volatile Pair cache;
    public static volatile String testBase;

    /* loaded from: classes.dex */
    public final class Gallery {
        public final String base;
        public final Object links;
        public final ArrayList walls;

        public Gallery(ArrayList arrayList, String base, List list) {
            Intrinsics.checkNotNullParameter(base, "base");
            this.walls = arrayList;
            this.base = base;
            this.links = list;
        }

        public final Wall get(String str) {
            Object obj;
            Iterator it = this.walls.iterator();
            while (true) {
                if (it.hasNext()) {
                    obj = it.next();
                    if (((Wall) obj).id.equals(str)) {
                        break;
                    }
                } else {
                    obj = null;
                    break;
                }
            }
            return (Wall) obj;
        }
    }

    /* loaded from: classes.dex */
    public final class Link {
        public final String credit;
        public final boolean fade;
        public final String id;
        public final String kind;
        public final String license;
        public final LinkedHashMap name;
        public final String source;
        public final String thumb;
        public final String thumbSha;
        public final String url;

        public Link(String str, String str2, LinkedHashMap linkedHashMap, String str3, String str4, String str5, String str6, String str7, String str8, boolean z) {
            this.id = str;
            this.kind = str2;
            this.name = linkedHashMap;
            this.url = str3;
            this.thumb = str4;
            this.thumbSha = str5;
            this.credit = str6;
            this.source = str7;
            this.license = str8;
            this.fade = z;
        }
    }

    /* loaded from: classes.dex */
    public final class Wall {
        public final int bytes;
        public final String credit;
        public final String file;
        public final String id;
        public final String license;
        public final LinkedHashMap name;
        public final String sha;
        public final String source;
        public final String thumb;
        public final String thumbSha;

        public Wall(String str, LinkedHashMap linkedHashMap, String str2, String str3, String str4, String str5, String str6, String str7, String str8, int i) {
            this.id = str;
            this.name = linkedHashMap;
            this.file = str2;
            this.sha = str3;
            this.thumb = str4;
            this.thumbSha = str5;
            this.credit = str6;
            this.source = str7;
            this.license = str8;
            this.bytes = i;
        }
    }

    static {
        String obj;
        String str = System.getenv("TVR_WALLPAPERS");
        String str2 = null;
        if (str != null && (obj = StringsKt.trim(str).toString()) != null) {
            if (obj.length() <= 0) {
                obj = null;
            }
            if (obj != null) {
                if (!StringsKt__StringsJVMKt.endsWith(obj, false, "/")) {
                    obj = obj.concat("/");
                }
                str2 = obj;
            }
        }
        testBase = str2;
        NAME = new Regex("[a-z0-9][a-z0-9-]*\\.jpg");
        KINDS = SetsKt.setOf((Object[]) new String[]{"slides", "video", "page"});
    }

    public static void checked(String str, byte[] bArr) {
        List list = Launchers.KEYS;
        byte[] digest = MessageDigest.getInstance("SHA-256").digest(bArr);
        Intrinsics.checkNotNullExpressionValue(digest, "digest(...)");
        if (Intrinsics.areEqual(Launchers.hex$shared_release(digest), str)) {
        } else {
            throw new IOException("launcher file does not match its signed checksum");
        }
    }

    public static Gallery fetch() {
        List list;
        Pair pair = cache;
        if (pair != null && System.currentTimeMillis() - ((Number) pair.first).longValue() < 60000) {
            return (Gallery) pair.second;
        }
        List list2 = Launchers.KEYS;
        String str = testBase;
        if (str != null) {
            list = MathKt.listOf(str);
        } else {
            list = bases;
        }
        return (Gallery) Launchers.first(list, "wallpapers.json", new Bloat$$ExternalSyntheticLambda0(6));
    }

    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Object, java.lang.Iterable] */
    public static byte[] thumb(String str) {
        Object obj;
        Gallery fetch = fetch();
        Wall wall = fetch.get(str);
        String str2 = fetch.base;
        if (wall != null) {
            List list = Launchers.KEYS;
            byte[] bArr = Launchers.get$shared_release(str2 + wall.thumb);
            checked(wall.thumbSha, bArr);
            return bArr;
        }
        Iterator it = fetch.links.iterator();
        while (true) {
            if (it.hasNext()) {
                obj = it.next();
                if (((Link) obj).id.equals(str)) {
                    break;
                }
            } else {
                obj = null;
                break;
            }
        }
        Link link = (Link) obj;
        if (link != null) {
            if (link.thumb.length() <= 0 || link.thumbSha.length() != 64) {
                link = null;
            }
            if (link != null) {
                List list2 = Launchers.KEYS;
                byte[] bArr2 = Launchers.get$shared_release(str2 + link.thumb);
                checked(link.thumbSha, bArr2);
                return bArr2;
            }
        }
        return null;
    }
}
