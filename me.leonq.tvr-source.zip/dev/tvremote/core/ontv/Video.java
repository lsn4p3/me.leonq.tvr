package dev.tvremote.core.ontv;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import com.android.apksig.internal.apk.AndroidBinXmlParser;
import dev.tvremote.core.B64;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.Mdns;
import dev.tvremote.core.manage.Manage$$ExternalSyntheticLambda0;
import dev.tvremote.core.ontv.SetupNeed;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Charsets;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class Video {
    public final Manage$$ExternalSyntheticLambda0 adb;
    public Adb.Stream cam;
    public final Object camLock = new Object();
    public Adb.Stream ctl;
    public Adb from;
    public Way way;

    /* loaded from: classes.dex */
    public final class Way {
        public final Object dir;
        public final int port;
        public final Object token;

        public /* synthetic */ Way(int i, Object obj, Object obj2) {
            this.port = i;
            this.token = obj;
            this.dir = obj2;
        }

        public static Way get(ByteBuffer byteBuffer) {
            if (byteBuffer.remaining() < 8) {
                byteBuffer.position(byteBuffer.limit());
                return null;
            }
            int position = byteBuffer.position();
            int i = byteBuffer.getShort() & 65535;
            int i2 = 65535 & byteBuffer.getShort();
            long j = byteBuffer.getInt() & 4294967295L;
            if (j - 8 > byteBuffer.remaining()) {
                byteBuffer.position(byteBuffer.limit());
                return null;
            }
            if (i2 >= 8) {
                if (i2 <= j) {
                    int i3 = i2 + position;
                    long j2 = position + j;
                    Way way = new Way(i, AndroidBinXmlParser.sliceFromTo(byteBuffer, position, i3), AndroidBinXmlParser.sliceFromTo(byteBuffer, i3, j2));
                    byteBuffer.position((int) j2);
                    return way;
                }
                throw new Exception("Malformed chunk: header too long: " + i2 + " bytes. Chunk size: " + j + " bytes");
            }
            throw new Exception(ApkSigner$$ExternalSyntheticOutline0.m("Malformed chunk: header too short: ", i2, " bytes"));
        }

        public ByteBuffer getContents() {
            ByteBuffer byteBuffer = (ByteBuffer) this.dir;
            ByteBuffer slice = byteBuffer.slice();
            slice.order(byteBuffer.order());
            return slice;
        }
    }

    public Video(Manage$$ExternalSyntheticLambda0 manage$$ExternalSyntheticLambda0) {
        this.adb = manage$$ExternalSyntheticLambda0;
    }

    public static JSONObject answer(Adb.Stream stream) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byte[] bArr = new byte[1];
        long currentTimeMillis = System.currentTimeMillis() + 8000;
        while (System.currentTimeMillis() < currentTimeMillis) {
            Adb.Stream stream2 = stream;
            int read = stream2.read(8000L, bArr, 0, 1);
            if (read >= 0) {
                if (read != 0) {
                    byte b = bArr[0];
                    if (b == 10) {
                        return new JSONObject(byteArrayOutputStream.toString("UTF-8"));
                    }
                    byteArrayOutputStream.write(b);
                }
                stream = stream2;
            } else {
                throw new IOException("video: closed");
            }
        }
        throw new IOException("video: no answer");
    }

    public final synchronized void closeControl() {
        try {
            Adb.Stream stream = this.ctl;
            if (stream != null) {
                stream.close();
            }
        } catch (Exception unused) {
        }
        this.ctl = null;
    }

    public final Adb.Stream control() {
        Adb adb = (Adb) this.adb.invoke();
        Adb.Stream stream = this.ctl;
        if (stream != null && this.from == adb && !adb.dead) {
            return stream;
        }
        closeControl();
        Way open = open();
        String m = ApkSigner$$ExternalSyntheticOutline0.m("tcp:", open.port);
        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
        Adb.Stream open2 = adb.open(10000L, m);
        byte[] bytes = ((String) open.token).concat("\n").getBytes(Charsets.UTF_8);
        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        open2.write(bytes);
        this.ctl = open2;
        return open2;
    }

    public final JSONObject file(String str, JSONObject jSONObject) {
        String str2;
        Way open = open();
        String str3 = "mp4";
        String substringAfterLast = StringsKt.substringAfterLast(str, '.', "mp4");
        StringBuilder sb = new StringBuilder();
        int length = substringAfterLast.length();
        for (int i = 0; i < length; i++) {
            char charAt = substringAfterLast.charAt(i);
            if (Character.isLetterOrDigit(charAt)) {
                sb.append(charAt);
            }
        }
        String take = StringsKt.take(sb.toString(), 5);
        if (take.length() != 0) {
            str3 = take;
        }
        String concat = "v.".concat(str3);
        if (jSONObject.optBoolean("sent")) {
            str2 = "mv";
        } else {
            str2 = "cp";
        }
        Adb adb = (Adb) this.adb.invoke();
        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
        String str4 = (String) open.dir;
        String shell = adb.shell(60000L, "mkdir -p " + Mdns.q(str4) + " && rm -f " + Mdns.q(str4) + "/* && " + str2 + " " + Mdns.q(str) + " " + Mdns.q(str4 + "/" + concat) + " && chmod 644 " + Mdns.q(str4 + "/" + concat) + " && echo ok 2>&1");
        if (StringsKt.contains(shell, "ok", false)) {
            JSONObject put = new JSONObject(jSONObject.toString()).put("o", "file").put("name", concat);
            Intrinsics.checkNotNullExpressionValue(put, "put(...)");
            return op(put);
        }
        throw new IOException("video:copy ".concat(StringsKt.take(StringsKt.trim(shell).toString(), 200)));
    }

    public final boolean frame(byte[] bArr, int i, boolean z, long j) {
        synchronized (this.camLock) {
            Adb.Stream stream = this.cam;
            if (stream == null) {
                return false;
            }
            if (i > 0 && i <= 4000000) {
                byte[] array = ByteBuffer.allocate(13).putInt(i).put(z ? (byte) 1 : (byte) 0).putLong(j).array();
                try {
                    try {
                        Intrinsics.checkNotNull(array);
                        stream.write(array);
                        stream.write(i, bArr);
                        return true;
                    } catch (Exception unused) {
                        this.cam = null;
                        return false;
                    }
                } catch (IOException unused2) {
                    Adb.Stream stream2 = this.cam;
                    if (stream2 != null) {
                        stream2.close();
                    }
                    this.cam = null;
                    return false;
                }
            }
            throw new IllegalArgumentException("bad frame");
        }
    }

    public final synchronized JSONObject op(JSONObject jSONObject) {
        Adb.Stream control;
        byte[] bytes = (jSONObject + "\n").getBytes(Charsets.UTF_8);
        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        for (int i = 0; i < 2; i++) {
            try {
                control = control();
                control.write(bytes);
            } catch (IOException e) {
                closeControl();
                this.way = null;
                if (i == 1 || (e instanceof SetupNeed.Missing) || Intrinsics.areEqual(e.getMessage(), "video:nooverlay")) {
                    throw e;
                }
            }
        }
        throw new IOException("video: no answer");
        return answer(control);
    }

    public final synchronized Way open() {
        Adb adb = (Adb) this.adb.invoke();
        Way way = this.way;
        if (way != null && this.from == adb && !adb.dead) {
            return way;
        }
        String input = adb.shell(20000L, "appops set dev.tvremote.setup SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1; am broadcast --include-stopped-packages -n dev.tvremote.setup/.VideoReceiver 2>&1");
        Pattern compile = Pattern.compile("data=\"([A-Za-z0-9+/=]+)\"");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        Intrinsics.checkNotNullParameter(input, "input");
        Matcher matcher = compile.matcher(input);
        Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
        MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, input);
        if (access$findNext != null) {
            int[] iArr = B64.INDEX;
            JSONObject jSONObject = new JSONObject(new String(B64.decode((String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)), Charsets.UTF_8));
            if (jSONObject.optBoolean("overlay")) {
                int i = jSONObject.getInt("port");
                String string = jSONObject.getString("token");
                Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                String optString = jSONObject.optString("dir");
                if (optString.length() == 0) {
                    optString = "/sdcard/Android/data/dev.tvremote.setup/files/video";
                }
                Way way2 = new Way(i, string, optString);
                this.way = way2;
                this.from = adb;
                return way2;
            }
            throw new IOException("video:nooverlay");
        }
        Regex regex = SetupUpdate.VERSION;
        throw new SetupNeed.Missing("video", SetupUpdate.installed(adb));
    }

    public final void start(JSONObject jSONObject) {
        Adb.Stream open;
        synchronized (this.camLock) {
            try {
                Adb.Stream stream = this.cam;
                if (stream != null) {
                    stream.close();
                }
            } catch (Exception unused) {
            }
            this.cam = null;
            try {
                Adb adb = (Adb) this.adb.invoke();
                String str = "tcp:" + open().port;
                ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                open = adb.open(10000L, str);
            } catch (IOException e) {
                if (!(e instanceof SetupNeed.Missing)) {
                    this.way = null;
                    Adb adb2 = (Adb) this.adb.invoke();
                    String str2 = "tcp:" + open().port;
                    ConcurrentHashMap concurrentHashMap2 = Adb.ASKING;
                    open = adb2.open(10000L, str2);
                } else {
                    throw e;
                }
            }
            byte[] bytes = (((String) open().token) + "\n" + new JSONObject(jSONObject.toString()).put("o", "live") + "\n").getBytes(Charsets.UTF_8);
            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
            open.write(bytes);
            this.cam = open;
        }
    }

    public final void stop() {
        synchronized (this.camLock) {
            try {
                Adb.Stream stream = this.cam;
                if (stream != null) {
                    stream.close();
                }
            } catch (Exception unused) {
            }
            this.cam = null;
        }
    }
}
