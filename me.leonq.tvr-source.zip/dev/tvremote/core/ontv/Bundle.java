package dev.tvremote.core.ontv;

import java.util.List;
import kotlin.collections.ArraysKt;
import kotlin.jvm.functions.Function4;

/* loaded from: classes.dex */
public abstract class Bundle {
    public static final List apps;

    /* loaded from: classes.dex */
    public final class App {
        public final String name;
        public final String pkg;

        public App(String str, String str2, String str3, String str4, Function4 function4) {
            this.name = str;
            this.pkg = str2;
        }
    }

    static {
        new OwnApp("dev.tvremote.home", "tv-home.apk", "home", "home:none", "pm grant dev.tvremote.home android.permission.ACCESS_FINE_LOCATION >/dev/null 2>&1; pm grant dev.tvremote.home android.permission.BLUETOOTH_CONNECT >/dev/null 2>&1; pm grant dev.tvremote.home android.permission.READ_TV_LISTINGS >/dev/null 2>&1; pm grant dev.tvremote.home android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1; ");
        apps = ArraysKt.asList(new App[]{new App("TV Home", "dev.tvremote.home", "home", "tv-home.apk", new Bloat$$ExternalSyntheticLambda0(4)), new App("TV Channels", "dev.tvremote.channels", "channels", "tv-channels.apk", new Bloat$$ExternalSyntheticLambda0(4)), new App("TV Games", "dev.tvremote.games", "games", "tv-games.apk", new Bloat$$ExternalSyntheticLambda0(4)), new App("TV Apps", "dev.tvremote.apps", "tvapps", "tv-apps.apk", new Bloat$$ExternalSyntheticLambda0(4))});
    }
}
