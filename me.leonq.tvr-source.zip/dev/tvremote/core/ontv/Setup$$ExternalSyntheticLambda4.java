package dev.tvremote.core.ontv;

import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.ontv.SetupNeed;
import dev.tvremote.core.scenes.Scenes;
import java.util.HashMap;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class Setup$$ExternalSyntheticLambda4 implements Function1 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ AdbLink f$0;

    public /* synthetic */ Setup$$ExternalSyntheticLambda4(AdbLink adbLink, int i) {
        this.$r8$classId = i;
        this.f$0 = adbLink;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        AdbLink adbLink = this.f$0;
        switch (this.$r8$classId) {
            case 0:
                String it = (String) obj;
                Intrinsics.checkNotNullParameter(it, "it");
                Adb adb = adbLink.get();
                ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                return adb.shell(120000L, it);
            case 1:
                JSONObject sc = (JSONObject) obj;
                Intrinsics.checkNotNullParameter(sc, "sc");
                HashMap hashMap = Scenes.KEYS;
                Setup$$ExternalSyntheticLambda4 setup$$ExternalSyntheticLambda4 = new Setup$$ExternalSyntheticLambda4(adbLink, 5);
                Set set = RulesClient.SETUP_KEYS;
                JSONObject call = RulesClient.call(setup$$ExternalSyntheticLambda4, new JSONObject().put("do", "scenepin").put("scene", sc));
                if (!call.has("setup")) {
                    return call;
                }
                String optString = call.optString("have");
                Intrinsics.checkNotNullExpressionValue(optString, "optString(...)");
                throw new SetupNeed.Missing("scenepin", optString);
            case 2:
                JSONArray sl = (JSONArray) obj;
                Intrinsics.checkNotNullParameter(sl, "sl");
                HashMap hashMap2 = Scenes.KEYS;
                Setup$$ExternalSyntheticLambda4 setup$$ExternalSyntheticLambda42 = new Setup$$ExternalSyntheticLambda4(adbLink, 3);
                try {
                    Set set2 = RulesClient.SETUP_KEYS;
                    RulesClient.call(setup$$ExternalSyntheticLambda42, new JSONObject().put("do", "scenes").put("scenes", sl));
                } catch (Exception unused) {
                }
                return Unit.INSTANCE;
            case 3:
                String it2 = (String) obj;
                Intrinsics.checkNotNullParameter(it2, "it");
                Adb adb2 = adbLink.get();
                ConcurrentHashMap concurrentHashMap2 = Adb.ASKING;
                return adb2.shell(120000L, it2);
            case 4:
                String it3 = (String) obj;
                Intrinsics.checkNotNullParameter(it3, "it");
                Adb adb3 = adbLink.get();
                ConcurrentHashMap concurrentHashMap3 = Adb.ASKING;
                return adb3.shell(120000L, it3);
            case 5:
                String it4 = (String) obj;
                Intrinsics.checkNotNullParameter(it4, "it");
                Adb adb4 = adbLink.get();
                ConcurrentHashMap concurrentHashMap4 = Adb.ASKING;
                return adb4.shell(120000L, it4);
            default:
                String it5 = (String) obj;
                Intrinsics.checkNotNullParameter(it5, "it");
                Adb adb5 = adbLink.get();
                ConcurrentHashMap concurrentHashMap5 = Adb.ASKING;
                return adb5.shell(120000L, it5);
        }
    }
}
