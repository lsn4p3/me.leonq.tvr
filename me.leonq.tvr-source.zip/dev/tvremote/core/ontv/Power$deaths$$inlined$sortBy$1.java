package dev.tvremote.core.ontv;

import java.util.Comparator;
import java.util.Map;
import kotlin.math.MathKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class Power$deaths$$inlined$sortBy$1 implements Comparator {
    public final /* synthetic */ int $r8$classId;

    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        switch (this.$r8$classId) {
            case 0:
                return MathKt.compareValues(Double.valueOf(((Power$deaths$D) obj).t), Double.valueOf(((Power$deaths$D) obj2).t));
            case 1:
                return MathKt.compareValues(Boolean.valueOf(((JSONObject) obj2).getBoolean("connected")), Boolean.valueOf(((JSONObject) obj).getBoolean("connected")));
            default:
                return MathKt.compareValues((Double) ((Map.Entry) obj2).getValue(), (Double) ((Map.Entry) obj).getValue());
        }
    }
}
