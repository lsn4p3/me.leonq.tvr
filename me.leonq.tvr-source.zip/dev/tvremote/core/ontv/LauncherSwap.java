package dev.tvremote.core.ontv;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.ontv.SetupNeed;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyList;
import kotlin.collections.SetsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgressionIterator;
import kotlin.ranges.IntRange;
import kotlin.sequences.GeneratorSequence$iterator$1;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.RegexOption;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class LauncherSwap {
    public final Function1 log;
    public String opened;
    public String refused;
    public final Function1 sh;
    public String via;
    public static final Regex PKG = new Regex("[A-Za-z][\\w]*(\\.[\\w]+)+");
    public static final Set NO_SWAP = SetsKt.setOf((Object[]) new String[]{"moka", "kalley", "prismplus", "prism+"});
    public static final List WHYS = ArraysKt.asList(new String[]{"crash", "home", "timeout", "interrupted", "user", "wifi", "wifi_unknown", "cast", "zte", "users", "board", "boot", "keys", "key"});
    public static final Set REFUSED = SetsKt.setOf((Object[]) new String[]{"wifi", "wifi_unknown", "cast", "zte", "users", "board", "boot", "keys"});
    public static final Set CAST_HOSTS = SetsKt.setOf((Object[]) new String[]{"sabrina", "boreal", "kirkwood"});
    public static final Regex FACTORY = new Regex("factorytest|factory_test|factorymode", RegexOption.IGNORE_CASE);

    /* loaded from: classes.dex */
    public final class Rec {
        public final long at;
        public final String comp;
        public final Object off;
        public final String pkg;
        public final String prev;
        public final String state;
        public final long until;
        public final String why;

        public Rec(String str, String str2, String str3, List list, long j, String str4, long j2, String str5) {
            this.pkg = str;
            this.comp = str2;
            this.prev = str3;
            this.off = list;
            this.at = j;
            this.state = str4;
            this.until = j2;
            this.why = str5;
        }

        public final boolean getActive() {
            String str = this.state;
            if (!Intrinsics.areEqual(str, "swapping") && !Intrinsics.areEqual(str, "pending") && !Intrinsics.areEqual(str, "kept")) {
                return false;
            }
            return true;
        }
    }

    public LauncherSwap(Function1 sh) {
        Bloat$$ExternalSyntheticLambda1 bloat$$ExternalSyntheticLambda1 = new Bloat$$ExternalSyntheticLambda1(8);
        Intrinsics.checkNotNullParameter(sh, "sh");
        this.sh = sh;
        this.log = bloat$$ExternalSyntheticLambda1;
        this.refused = "";
        this.opened = "";
        this.via = "";
    }

    /* JADX WARN: Code restructure failed: missing block: B:22:0x0061, code lost:
    
        if (r1 == null) goto L26;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean byKey(String str, String str2) {
        Object obj;
        String homeNow;
        boolean z;
        boolean optBoolean;
        Iterator it = homes().iterator();
        while (true) {
            if (it.hasNext()) {
                obj = it.next();
                if (StringsKt__StringsJVMKt.startsWith((String) obj, false, str.concat("/"))) {
                    break;
                }
            } else {
                obj = null;
                break;
            }
        }
        String str3 = (String) obj;
        if (str3 == null) {
            return false;
        }
        LinkedHashMap linkedHashMap = SetupNeed.MIN;
        Function1 function1 = this.sh;
        String have = SetupNeed.have(function1);
        if (SetupNeed.ok(have, "homekey")) {
            Rec state = state();
            if (state != null) {
                if (state.why.equals("key")) {
                    state = null;
                }
                if (state != null) {
                    homeNow = state.prev;
                    if (!StringsKt.contains$default(homeNow, '/')) {
                        homeNow = null;
                    }
                }
            }
            homeNow = homeNow();
            Set set = RulesClient.SETUP_KEYS;
            JSONObject call = RulesClient.call(function1, new JSONObject().put("do", "homekey").put("pkg", str));
            boolean areEqual = Intrinsics.areEqual(call.optString("homekey"), str);
            Function1 function12 = this.log;
            if (!areEqual) {
                function12.invoke("TV Setup did not take Home: " + call);
                this.refused = str2;
                return false;
            }
            if (!call.has("keys")) {
                optBoolean = true;
                z = false;
            } else {
                int i = 0;
                z = false;
                while (true) {
                    if (i < 45) {
                        if (call.optBoolean("keys")) {
                            optBoolean = true;
                            break;
                        }
                        function1.invoke("sleep 1");
                        call = RulesClient.call(function1, null);
                        i++;
                    } else {
                        optBoolean = call.optBoolean("keys");
                        break;
                    }
                }
            }
            if (!optBoolean) {
                Set set2 = RulesClient.SETUP_KEYS;
                RulesClient.call(function1, new JSONObject().put("do", "homekey").put("pkg", ""));
                function12.invoke("TV Setup's key filter did not start");
                this.refused = "keys";
                return z;
            }
            if (!str2.equals("boot")) {
                function1.invoke("cmd package set-home-activity " + str3 + " 2>/dev/null");
            }
            save(new Rec(str, str3, homeNow, EmptyList.INSTANCE, tvNow(), "kept", 0L, "key"));
            this.via = str2;
            function1.invoke("am start -n ".concat(str3));
            function12.invoke("Home by TV Setup's key filter: ".concat(str2));
            return true;
        }
        throw new SetupNeed.Missing("homekey", have);
    }

    public final boolean cast() {
        String lowerCase = StringsKt.trim((String) this.sh.invoke("getprop ro.product.device")).toString().toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        return CAST_HOSTS.contains(lowerCase);
    }

    public final void dropKey() {
        String str;
        try {
            Rec state = state();
            if (state != null) {
                str = state.why;
            } else {
                str = null;
            }
            boolean areEqual = Intrinsics.areEqual(str, "key");
            Function1 function1 = this.sh;
            if ((areEqual || cast() || StringsKt.contains((CharSequence) function1.invoke("pm path com.control.device 2>/dev/null"), "package:", false)) && SetupNeed.ok(SetupNeed.have(function1), "homekey")) {
                Set set = RulesClient.SETUP_KEYS;
                RulesClient.call(function1, new JSONObject().put("do", "homekey").put("pkg", ""));
            }
        } catch (Exception unused) {
        }
    }

    public final String homeNow() {
        return Games.last((String) this.sh.invoke("p=$(cmd role get-role-holders android.app.role.HOME 2>/dev/null); c=$([ -n \"$p\" ] && cmd package query-activities --brief -a android.intent.action.MAIN -c android.intent.category.HOME 2>/dev/null | grep -m1 \"^ *$p/\"); if [ -n \"$c\" ]; then echo $c; else cmd package resolve-activity --brief -c android.intent.category.HOME -a android.intent.action.MAIN; fi"));
    }

    public final String homeOpens() {
        Rec state = state();
        if (state != null) {
            if (!state.why.equals("key") || !state.state.equals("kept") || !homes().contains(state.comp)) {
                state = null;
            }
            if (state != null) {
                return state.comp;
            }
        }
        return homeNow();
    }

    public final ArrayList homes() {
        List split$default = StringsKt.split$default((CharSequence) this.sh.invoke("cmd package query-activities --brief -a android.intent.action.MAIN -c android.intent.category.HOME 2>/dev/null"), new String[]{"\n"}, 0, 6);
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(split$default));
        Iterator it = split$default.iterator();
        while (it.hasNext()) {
            arrayList.add(StringsKt.trim((String) it.next()).toString());
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator it2 = arrayList.iterator();
        while (it2.hasNext()) {
            Object next = it2.next();
            String str = (String) next;
            if (StringsKt.contains$default(str, '/') && !StringsKt__StringsJVMKt.startsWith(str, false, "priority") && !FACTORY.containsMatchIn(str)) {
                arrayList2.add(next);
            }
        }
        return arrayList2;
    }

    /* JADX WARN: Code restructure failed: missing block: B:34:0x0100, code lost:
    
        if (r8 != null) goto L79;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r7v15, types: [java.util.List, java.lang.Object] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void rollback(String str, ArrayList arrayList) {
        String str2;
        ArrayList arrayList2;
        String str3;
        Object obj;
        String str4;
        String str5;
        String str6;
        Object obj2;
        Rec state = state();
        Object obj3 = null;
        if (state != null) {
            str2 = state.why;
        } else {
            str2 = null;
        }
        if (Intrinsics.areEqual(str2, "key")) {
            dropKey();
        }
        Function1 function1 = this.sh;
        if (state != null) {
            arrayList2 = state.off;
        } else if (arrayList == null) {
            ArrayList plus = CollectionsKt.plus(ArraysKt.toList(Setup.LAUNCHER), (Object[]) Setup.WIZARD);
            ArrayList arrayList3 = new ArrayList();
            Iterator it = plus.iterator();
            while (it.hasNext()) {
                Object next = it.next();
                String str7 = (String) next;
                List split$default = StringsKt.split$default((CharSequence) function1.invoke("pm list packages -d 2>/dev/null"), new String[]{"\n"}, 0, 6);
                ArrayList arrayList4 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(split$default));
                Iterator it2 = split$default.iterator();
                while (it2.hasNext()) {
                    arrayList4.add(StringsKt.trim(StringsKt.removePrefix((String) it2.next(), "package:")).toString());
                }
                if (CollectionsKt.toSet(arrayList4).contains(str7)) {
                    arrayList3.add(next);
                }
            }
            arrayList2 = arrayList3;
        } else {
            arrayList2 = arrayList;
        }
        Iterator it3 = CollectionsKt.reversed(arrayList2).iterator();
        while (it3.hasNext()) {
            function1.invoke("pm enable --user 0 " + ((String) it3.next()));
        }
        ArrayList homes = homes();
        if (state != null) {
            str3 = state.prev;
        } else {
            str3 = "";
        }
        if (StringsKt.contains$default(str3, '/') && !Games.badHome(str3)) {
            String substringBefore = StringsKt.substringBefore(str3, '/', str3);
            if (state != null) {
                str6 = state.pkg;
            } else {
                str6 = null;
            }
            if (!substringBefore.equals(str6)) {
                Iterator it4 = homes.iterator();
                while (true) {
                    if (it4.hasNext()) {
                        obj2 = it4.next();
                        if (Intrinsics.areEqual((String) obj2, str3)) {
                            break;
                        }
                    } else {
                        obj2 = null;
                        break;
                    }
                }
                str4 = (String) obj2;
            }
        }
        Iterator it5 = homes.iterator();
        while (true) {
            if (it5.hasNext()) {
                obj = it5.next();
                String str8 = (String) obj;
                if (arrayList2.contains(StringsKt.substringBefore(str8, '/', str8))) {
                    if (!ArraysKt.contains(StringsKt.substringBefore(str8, '/', str8), Setup.WIZARD)) {
                        break;
                    }
                }
            } else {
                obj = null;
                break;
            }
        }
        str4 = (String) obj;
        if (str4 == null) {
            Iterator it6 = homes.iterator();
            while (true) {
                if (!it6.hasNext()) {
                    break;
                }
                Object next2 = it6.next();
                String str9 = (String) next2;
                if (!Games.badHome(str9)) {
                    String substringBefore2 = StringsKt.substringBefore(str9, '/', str9);
                    if (state != null) {
                        str5 = state.pkg;
                    } else {
                        str5 = null;
                    }
                    if (substringBefore2.equals(str5)) {
                        continue;
                    } else {
                        if (!ArraysKt.contains(StringsKt.substringBefore(str9, '/', str9), Setup.WIZARD)) {
                            obj3 = next2;
                            break;
                        }
                    }
                }
            }
            str4 = (String) obj3;
        }
        if (str4 != null) {
            function1.invoke("cmd package set-home-activity " + str4 + " 2>/dev/null");
        }
        function1.invoke("am start -a android.intent.action.MAIN -c android.intent.category.HOME");
        if (state != null) {
            save(new Rec(state.pkg, state.comp, state.prev, state.off, state.at, "rolledback", 0L, str));
        }
        this.log.invoke("rolled back: ".concat(str));
    }

    /* JADX WARN: Type inference failed for: r2v3, types: [java.util.Collection, java.lang.Object] */
    public final void save(Rec rec) {
        JSONObject put = new JSONObject().put("pkg", rec.pkg).put("comp", rec.comp).put("prev", rec.prev).put("off", new JSONArray((Collection) rec.off)).put("at", rec.at).put("state", rec.state).put("until", rec.until).put("why", rec.why);
        Intrinsics.checkNotNullExpressionValue(put, "put(...)");
        String jSONObject = put.toString();
        Intrinsics.checkNotNullExpressionValue(jSONObject, "toString(...)");
        this.sh.invoke(ApkSigner$$ExternalSyntheticOutline0.m("echo '", StringsKt__StringsJVMKt.replace$default(jSONObject, "'", ""), "' > /data/local/tmp/tvr-launcher.json"));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r7v0, types: [kotlin.collections.EmptyList] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r7v3, types: [java.util.ArrayList] */
    public final Rec state() {
        ?? r7;
        String obj = StringsKt.trim((String) this.sh.invoke("cat /data/local/tmp/tvr-launcher.json 2>/dev/null")).toString();
        if (obj.length() != 0) {
            try {
                JSONObject jSONObject = new JSONObject(obj);
                String string = jSONObject.getString("pkg");
                Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                String optString = jSONObject.optString("comp");
                Intrinsics.checkNotNullExpressionValue(optString, "optString(...)");
                String optString2 = jSONObject.optString("prev");
                Intrinsics.checkNotNullExpressionValue(optString2, "optString(...)");
                JSONArray optJSONArray = jSONObject.optJSONArray("off");
                if (optJSONArray != null) {
                    IntRange until = MathKt.until(0, optJSONArray.length());
                    r7 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until));
                    Iterator it = until.iterator();
                    while (((IntProgressionIterator) it).hasNext) {
                        r7.add(optJSONArray.getString(((IntProgressionIterator) it).nextInt()));
                    }
                } else {
                    r7 = EmptyList.INSTANCE;
                }
                long optLong = jSONObject.optLong("at");
                String optString3 = jSONObject.optString("state");
                Intrinsics.checkNotNullExpressionValue(optString3, "optString(...)");
                long optLong2 = jSONObject.optLong("until");
                String optString4 = jSONObject.optString("why");
                Intrinsics.checkNotNullExpressionValue(optString4, "optString(...)");
                return new Rec(string, optString, optString2, r7, optLong, optString3, optLong2, optString4);
            } catch (JSONException unused) {
                return null;
            }
        }
        return null;
    }

    /* JADX WARN: Code restructure failed: missing block: B:211:0x040b, code lost:
    
        if (r6.isEmpty() != false) goto L155;
     */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0163  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0168  */
    /* JADX WARN: Type inference failed for: r7v6, types: [java.util.List, java.lang.Object] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean take(String str, int i, String str2) {
        Object obj;
        String str3;
        Rec rec;
        String str4;
        ArrayList arrayList;
        String str5;
        Function1 function1;
        String str6;
        ArrayList arrayList2;
        String str7;
        String str8;
        String str9;
        long j;
        String str10;
        String str11;
        long j2;
        Object obj2;
        String str12;
        boolean z;
        if (PKG.matches(str)) {
            this.refused = "";
            this.opened = "";
            this.via = "";
            ArrayList homes = homes();
            Iterator it = homes.iterator();
            while (true) {
                if (it.hasNext()) {
                    obj = it.next();
                    if (StringsKt__StringsJVMKt.startsWith((String) obj, false, str.concat("/"))) {
                        break;
                    }
                } else {
                    obj = null;
                    break;
                }
            }
            String str13 = (String) obj;
            Function1 function12 = this.log;
            if (str13 == null) {
                function12.invoke("no home activity");
                return false;
            }
            Rec state = state();
            if (state != null) {
                str3 = state.why;
            } else {
                str3 = null;
            }
            if (Intrinsics.areEqual(str3, "key")) {
                dropKey();
            }
            boolean cast = cast();
            Function1 function13 = this.sh;
            if (cast) {
                str4 = "cast";
            } else if (StringsKt.contains((CharSequence) function13.invoke("pm path com.control.device 2>/dev/null"), "package:", false)) {
                str4 = "zte";
            } else {
                if (StringsKt.contains((CharSequence) function13.invoke("pm path com.smartdevice.global.service 2>/dev/null"), "package:", false)) {
                    String out = (String) function13.invoke("pm list users");
                    Intrinsics.checkNotNullParameter(out, "out");
                    rec = null;
                    GeneratorSequence$iterator$1 generatorSequence$iterator$1 = new GeneratorSequence$iterator$1(Regex.findAll$default(new Regex("UserInfo\\{"), out));
                    int i2 = 0;
                    while (generatorSequence$iterator$1.hasNext()) {
                        generatorSequence$iterator$1.next();
                        i2++;
                        if (i2 < 0) {
                            CollectionsKt__CollectionsKt.throwCountOverflow();
                            throw null;
                        }
                    }
                    if (i2 > 1) {
                        str4 = "users";
                        if (str4 == null) {
                            return byKey(str, str4);
                        }
                        String str14 = str2;
                        if (!StringsKt.contains$default(str14, '/') || Games.badHome(str14)) {
                            str14 = rec;
                        }
                        if (str14 == null) {
                            str14 = homeNow();
                        }
                        function13.invoke("am start -n ".concat(str13));
                        List split$default = StringsKt.split$default((CharSequence) function13.invoke("pm list packages -e"), new String[]{"\n"}, 0, 6);
                        ArrayList arrayList3 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(split$default));
                        Iterator it2 = split$default.iterator();
                        while (it2.hasNext()) {
                            arrayList3.add(StringsKt.trim(StringsKt.removePrefix((String) it2.next(), "package:")).toString());
                        }
                        ArrayList arrayList4 = new ArrayList();
                        Iterator it3 = arrayList3.iterator();
                        while (it3.hasNext()) {
                            Object next = it3.next();
                            if (((String) next).length() > 0) {
                                arrayList4.add(next);
                            }
                        }
                        Set set = CollectionsKt.toSet(arrayList4);
                        ArrayList homes2 = homes();
                        ArrayList arrayList5 = new ArrayList();
                        Iterator it4 = homes2.iterator();
                        while (it4.hasNext()) {
                            Object next2 = it4.next();
                            String str15 = (String) next2;
                            String str16 = str14;
                            if (ArraysKt.contains(StringsKt.substringBefore(str15, '/', str15), Setup.WIZARD)) {
                                arrayList5.add(next2);
                            }
                            str14 = str16;
                        }
                        String str17 = str14;
                        String[] strArr = Setup.LAUNCHER;
                        ArrayList arrayList6 = new ArrayList();
                        for (int i3 = 0; i3 < 5; i3++) {
                            String str18 = strArr[i3];
                            if (set.contains(str18) && !Intrinsics.areEqual(str18, str)) {
                                arrayList6.add(str18);
                            }
                        }
                        ArrayList plus = CollectionsKt.plus((List) arrayList5, (Iterable) arrayList6);
                        long tvNow = tvNow();
                        ArrayList arrayList7 = arrayList5;
                        save(new Rec(str, str13, str17, plus, tvNow, "swapping", 0L, ""));
                        Iterator it5 = arrayList7.iterator();
                        while (it5.hasNext()) {
                            String str19 = (String) it5.next();
                            function13.invoke("pm disable --user 0 " + str19 + " 2>&1");
                            if (!homes().contains(str19)) {
                                function13.invoke(Census$$ExternalSyntheticOutline0.m("grep -qx '", str19, "' /data/local/tmp/tvr-disabled.txt 2>/dev/null || echo '", str19, "' >> /data/local/tmp/tvr-disabled.txt"));
                            }
                        }
                        ArrayList homes3 = homes();
                        ArrayList arrayList8 = new ArrayList();
                        Iterator it6 = homes3.iterator();
                        while (it6.hasNext()) {
                            Object next3 = it6.next();
                            ArrayList arrayList9 = arrayList7;
                            if (arrayList9.contains((String) next3)) {
                                arrayList8.add(next3);
                            }
                            arrayList7 = arrayList9;
                        }
                        ArrayList arrayList10 = arrayList7;
                        ArrayList arrayList11 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList8));
                        Iterator it7 = arrayList8.iterator();
                        while (it7.hasNext()) {
                            String str20 = (String) it7.next();
                            arrayList11.add(StringsKt.substringBefore(str20, '/', str20));
                        }
                        List distinct = CollectionsKt.distinct(arrayList11);
                        if (!distinct.isEmpty()) {
                            String lowerCase = StringsKt.trim((String) function13.invoke("getprop ro.product.device")).toString().toLowerCase(Locale.ROOT);
                            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                            if (CAST_HOSTS.contains(lowerCase)) {
                                str10 = str13;
                                j2 = tvNow;
                                str12 = "cast";
                                str6 = "out";
                                str11 = str17;
                            } else {
                                String out2 = (String) function13.invoke("dumpsys wifi 2>/dev/null | grep -oE 'cname=[^ ]*|ID: [0-9]+ SSID|WifiConfigManager' | sort -u");
                                str10 = str13;
                                str11 = str17;
                                String obj3 = StringsKt.trim(StringsKt.substringAfter((String) function13.invoke("pm list packages -U " + distinct.get(0)), "uid:", "")).toString();
                                String substringBefore = StringsKt.substringBefore(obj3, ',', obj3);
                                Intrinsics.checkNotNullParameter(out2, "out");
                                str6 = "out";
                                j2 = tvNow;
                                List split$default2 = StringsKt.split$default(out2, new String[]{"\n"}, 0, 6);
                                ArrayList arrayList12 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(split$default2));
                                Iterator it8 = split$default2.iterator();
                                while (it8.hasNext()) {
                                    arrayList12.add(StringsKt.trim((String) it8.next()).toString());
                                }
                                if (!arrayList12.isEmpty()) {
                                    Iterator it9 = arrayList12.iterator();
                                    while (true) {
                                        if (!it9.hasNext()) {
                                            break;
                                        }
                                        if (Intrinsics.areEqual((String) it9.next(), "WifiConfigManager")) {
                                            ArrayList arrayList13 = new ArrayList();
                                            Iterator it10 = arrayList12.iterator();
                                            while (it10.hasNext()) {
                                                Object next4 = it10.next();
                                                ArrayList arrayList14 = arrayList12;
                                                Iterator it11 = it10;
                                                if (StringsKt__StringsJVMKt.startsWith((String) next4, false, "cname=")) {
                                                    arrayList13.add(next4);
                                                }
                                                arrayList12 = arrayList14;
                                                it10 = it11;
                                            }
                                            ArrayList arrayList15 = arrayList12;
                                            if (!arrayList15.isEmpty()) {
                                                Iterator it12 = arrayList15.iterator();
                                                while (true) {
                                                    if (!it12.hasNext()) {
                                                        break;
                                                    }
                                                    if (StringsKt__StringsJVMKt.startsWith((String) it12.next(), false, "ID: ")) {
                                                    }
                                                }
                                            }
                                            if (!arrayList13.isEmpty()) {
                                                Iterator it13 = arrayList13.iterator();
                                                while (it13.hasNext()) {
                                                    String str21 = (String) it13.next();
                                                    if (StringsKt.contains(str21, "setupwraith", false) || (substringBefore.length() > 0 && StringsKt__StringsJVMKt.endsWith(str21, false, ":".concat(substringBefore)))) {
                                                        z = false;
                                                        break;
                                                    }
                                                }
                                            }
                                            z = true;
                                            obj2 = Boolean.valueOf(z);
                                        }
                                    }
                                }
                                obj2 = rec;
                                if (Intrinsics.areEqual(obj2, Boolean.TRUE)) {
                                    str12 = rec;
                                } else if (Intrinsics.areEqual(obj2, Boolean.FALSE)) {
                                    str12 = "wifi";
                                } else if (obj2 == null) {
                                    str12 = "wifi_unknown";
                                } else {
                                    throw new RuntimeException();
                                }
                            }
                            if (str12 != null) {
                                function12.invoke("wizard stays: ".concat(str12));
                                rollback(str12, plus);
                                return byKey(str, str12);
                            }
                            ArrayList arrayList16 = new ArrayList();
                            Iterator it14 = plus.iterator();
                            while (it14.hasNext()) {
                                Object next5 = it14.next();
                                String str22 = (String) next5;
                                if (!distinct.contains(StringsKt.substringBefore(str22, '/', str22))) {
                                    arrayList16.add(next5);
                                }
                            }
                            ArrayList plus2 = CollectionsKt.plus(distinct, (Iterable) arrayList16);
                            str13 = str10;
                            List list = distinct;
                            arrayList = arrayList10;
                            str5 = "";
                            arrayList2 = plus;
                            String str23 = str11;
                            function1 = function13;
                            str7 = "home";
                            save(new Rec(str, str13, str23, plus2, j2, "swapping", 0L, ""));
                            Iterator it15 = list.iterator();
                            while (it15.hasNext()) {
                                turnOff((String) it15.next());
                            }
                            ArrayList homes4 = homes();
                            if (!homes4.isEmpty()) {
                                Iterator it16 = homes4.iterator();
                                while (it16.hasNext()) {
                                    String str24 = (String) it16.next();
                                    List list2 = list;
                                    if (list2.contains(StringsKt.substringBefore(str24, '/', str24))) {
                                        function12.invoke("wizard home stays");
                                        this.opened = (String) list2.get(0);
                                        rollback(str7, plus2);
                                        return byKey(str, str7);
                                    }
                                    list = list2;
                                }
                            }
                        } else {
                            arrayList = arrayList10;
                            str5 = "";
                            function1 = function13;
                            str6 = "out";
                            arrayList2 = plus;
                            str7 = "home";
                        }
                        Iterator it17 = CollectionsKt.minus(arrayList2, arrayList).iterator();
                        while (it17.hasNext()) {
                            turnOff((String) it17.next());
                        }
                        Function1 function14 = function1;
                        function14.invoke("cmd package set-home-activity " + str13 + " 2>/dev/null");
                        Rec state2 = state();
                        if (state2 != null) {
                            if (!state2.state.equals("rolledback")) {
                                state2 = rec;
                            }
                            if (state2 != null) {
                                rollback(state2.why, rec);
                                return false;
                            }
                        }
                        String homeNow = homeNow();
                        if (!StringsKt.substringBefore(homeNow, '/', homeNow).equals(str)) {
                            str8 = "-";
                        } else {
                            String str25 = (String) function14.invoke("input keyevent 3; sleep 2; dumpsys activity activities 2>/dev/null | grep -m4 -E 'mFocusedApp|ResumedActivity'");
                            Intrinsics.checkNotNullParameter(str25, str6);
                            Pattern compile = Pattern.compile("\\bu\\d+ ([\\w.]+/[\\w.$]+)");
                            Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                            Matcher matcher = compile.matcher(str25);
                            Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
                            MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, str25);
                            if (access$findNext == null || (str8 = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)) == null) {
                                str8 = str5;
                            }
                        }
                        if (!str8.equals("-") && (str8.length() == 0 || !Games.badHome(str8))) {
                            Rec state3 = state();
                            if (state3 != null) {
                                if (i > 0) {
                                    str9 = "pending";
                                } else {
                                    str9 = "kept";
                                }
                                String str26 = str9;
                                if (i > 0) {
                                    j = tvNow() + i;
                                } else {
                                    j = 0;
                                }
                                save(new Rec(state3.pkg, state3.comp, state3.prev, state3.off, state3.at, str26, j, state3.why));
                                return true;
                            }
                            return true;
                        }
                        if (str8.equals("-")) {
                            str8 = homeNow();
                        }
                        this.opened = StringsKt.substringBefore(str8, '/', str8);
                        rollback(str7, arrayList2);
                        return byKey(str, str7);
                    }
                } else {
                    rec = null;
                }
                String lowerCase2 = ((String) function13.invoke("getprop ro.product.manufacturer; getprop ro.product.brand")).toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
                List split$default3 = StringsKt.split$default(lowerCase2, new String[]{"\n"}, 0, 6);
                if (!split$default3.isEmpty()) {
                    Iterator it18 = split$default3.iterator();
                    while (it18.hasNext()) {
                        if (NO_SWAP.contains(StringsKt.trim((String) it18.next()).toString())) {
                            str4 = "board";
                            break;
                        }
                    }
                }
                if (!homes.isEmpty()) {
                    Iterator it19 = homes.iterator();
                    while (it19.hasNext()) {
                        if (StringsKt.contains((String) it19.next(), "FallbackHome", false)) {
                            break;
                        }
                    }
                }
                Integer intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull(StringsKt.trim((String) function13.invoke("dumpsys package " + str + " 2>/dev/null | grep -c DIRECT_BOOT_AWARE")).toString());
                if (intOrNull != null && intOrNull.intValue() == 0) {
                    str4 = "boot";
                    if (str4 == null) {
                    }
                }
                str4 = rec;
                if (str4 == null) {
                }
            }
            rec = null;
            if (str4 == null) {
            }
        } else {
            throw new IOException("bad package name");
        }
    }

    public final void turnOff(String str) {
        String m = ApkSigner$$ExternalSyntheticOutline0.m("pm disable-user --user 0 ", str);
        Function1 function1 = this.sh;
        function1.invoke(m);
        function1.invoke("am force-stop " + str);
        function1.invoke("grep -qx '" + str + "' /data/local/tmp/tvr-disabled.txt 2>/dev/null || echo '" + str + "' >> /data/local/tmp/tvr-disabled.txt");
    }

    public final long tvNow() {
        Long longOrNull = StringsKt__StringNumberConversionsKt.toLongOrNull(StringsKt.trim((String) this.sh.invoke("date +%s")).toString());
        if (longOrNull != null) {
            return longOrNull.longValue();
        }
        return System.currentTimeMillis() / 1000;
    }
}
