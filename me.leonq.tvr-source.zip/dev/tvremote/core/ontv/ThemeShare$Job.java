package dev.tvremote.core.ontv;

import java.net.HttpURLConnection;
import kotlin.jvm.internal.Intrinsics;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class ThemeShare$Job {
    public volatile boolean cancel;
    public volatile HttpURLConnection conn;
    public volatile long previewKb;
    public volatile long shotKb;
    public volatile long shotMs;
    public volatile long wallKb;
    public volatile String state = "run";
    public volatile String step = "apply";
    public volatile String error = "";
    public volatile String id = "";

    public final JSONObject json() {
        JSONObject put = new JSONObject().put("state", this.state).put("step", this.step).put("error", this.error).put("id", this.id).put("shot_ms", this.shotMs).put("shot_kb", this.shotKb).put("preview_kb", this.previewKb).put("wall_kb", this.wallKb);
        Intrinsics.checkNotNullExpressionValue(put, "put(...)");
        return put;
    }
}
