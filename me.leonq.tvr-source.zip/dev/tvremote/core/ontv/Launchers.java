package dev.tvremote.core.ontv;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Words$$ExternalSyntheticLambda1;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda3;
import dev.tvremote.update.Release;
import dev.tvremote.update.SignedList;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyList;
import kotlin.collections.EmptyMap;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgressionIterator;
import kotlin.ranges.IntRange;
import kotlin.sequences.ConstrainedOnceSequence;
import kotlin.sequences.GeneratorSequence;
import kotlin.sequences.Sequence;
import kotlin.sequences.SequencesKt;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class Launchers {
    public static volatile Pair cache;
    public static volatile File dir;
    public static volatile String testBase;
    public static final ConcurrentHashMap thumbs;
    public static final List KEYS = SignedList.KEYS;
    public static final EmptyList testKeys = EmptyList.INSTANCE;
    public static final List bases = ArraysKt.asList(new String[]{"https://tvremote.pages.dev/launchers/", "https://raw.githubusercontent.com/HoangTran0410/tv-remote/main/docs/launchers/"});

    /* loaded from: classes.dex */
    public final class Apk {
        public final String abi;
        public final String sha256;
        public final String url;

        public Apk(String abi, String url, String str) {
            Intrinsics.checkNotNullParameter(abi, "abi");
            Intrinsics.checkNotNullParameter(url, "url");
            this.abi = abi;
            this.url = url;
            this.sha256 = str;
        }
    }

    /* loaded from: classes.dex */
    public final class Entry {
        public final boolean atv;
        public final Object desc;
        public final String fallback;
        public final List files;
        public final boolean fire;
        public final boolean gtv;
        public final String id;
        public final String kind;
        public final Object langs;
        public final String license;
        public final int minSdk;
        public final String name;
        public final Object notes;
        public final String pkg;
        public final String playUrl;
        public final String source;
        public final String thumb;
        public final String thumbSha;
        public final String version;

        public Entry(String str, String str2, String str3, Map map, String str4, String str5, String str6, String str7, String str8, String str9, List list, String str10, boolean z, boolean z2, int i, boolean z3, Map map2, List list2, String str11) {
            this.id = str;
            this.pkg = str2;
            this.name = str3;
            this.desc = map;
            this.thumb = str4;
            this.thumbSha = str5;
            this.source = str6;
            this.license = str7;
            this.kind = str8;
            this.version = str9;
            this.files = list;
            this.playUrl = str10;
            this.atv = z;
            this.gtv = z2;
            this.minSdk = i;
            this.fire = z3;
            this.notes = map2;
            this.langs = list2;
            this.fallback = str11;
        }
    }

    /* loaded from: classes.dex */
    public final class Facts {
        public final ArrayList abis;
        public final boolean fire;
        public final boolean googleTv;
        public final boolean leanback;
        public final int sdk;

        public Facts(int i, ArrayList arrayList, boolean z, boolean z2, boolean z3) {
            this.sdk = i;
            this.abis = arrayList;
            this.leanback = z;
            this.googleTv = z2;
            this.fire = z3;
        }
    }

    /* loaded from: classes.dex */
    public final class Gallery {
        public final String base;
        public final ArrayList entries;
        public final String updated;

        public Gallery(String str, ArrayList arrayList, String base) {
            Intrinsics.checkNotNullParameter(base, "base");
            this.updated = str;
            this.entries = arrayList;
            this.base = base;
        }

        public final Entry get(String str) {
            Object obj;
            Iterator it = this.entries.iterator();
            while (true) {
                if (it.hasNext()) {
                    obj = it.next();
                    if (((Entry) obj).id.equals(str)) {
                        break;
                    }
                } else {
                    obj = null;
                    break;
                }
            }
            return (Entry) obj;
        }
    }

    static {
        String obj;
        String str = System.getenv("TVR_LAUNCHERS");
        String str2 = null;
        if (str != null && (obj = StringsKt.trim(str).toString()) != null) {
            if (obj.length() <= 0) {
                obj = null;
            }
            if (obj != null) {
                if (!StringsKt__StringsJVMKt.endsWith(obj, false, "/")) {
                    obj = obj.concat("/");
                }
                str2 = obj;
            }
        }
        testBase = str2;
        thumbs = new ConcurrentHashMap();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static Apk apk(Entry e, ArrayList arrayList) {
        ArrayList arrayList2;
        Apk apk;
        Intrinsics.checkNotNullParameter(e, "e");
        if (arrayList.contains("armeabi-v7a")) {
            List listOf = MathKt.listOf("armeabi-v7a");
            ArrayList arrayList3 = new ArrayList();
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                Object next = it.next();
                String str = (String) next;
                if (!Intrinsics.areEqual(str, "armeabi-v7a") && !Intrinsics.areEqual(str, "armeabi")) {
                    arrayList3.add(next);
                }
            }
            arrayList2 = CollectionsKt.plus(listOf, (Iterable) arrayList3);
        } else {
            ArrayList arrayList4 = new ArrayList();
            Iterator it2 = arrayList.iterator();
            while (it2.hasNext()) {
                Object next2 = it2.next();
                if (!Intrinsics.areEqual((String) next2, "armeabi")) {
                    arrayList4.add(next2);
                }
            }
            arrayList2 = arrayList4;
        }
        Iterator it3 = CollectionsKt.plus(arrayList2, "any").iterator();
        do {
            apk = null;
            if (!it3.hasNext()) {
                break;
            }
            String str2 = (String) it3.next();
            Iterator it4 = e.files.iterator();
            while (true) {
                if (!it4.hasNext()) {
                    break;
                }
                Object next3 = it4.next();
                if (Intrinsics.areEqual(((Apk) next3).abi, str2)) {
                    apk = next3;
                    break;
                }
            }
            apk = apk;
        } while (apk == null);
        return apk;
    }

    public static void download(Apk apk, File file, Words$$ExternalSyntheticLambda1 words$$ExternalSyntheticLambda1, Function0 function0) {
        long j;
        Long longOrNull;
        URLConnection openConnection = new URL(apk.url).openConnection();
        Intrinsics.checkNotNull(openConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
        HttpURLConnection httpURLConnection = (HttpURLConnection) openConnection;
        httpURLConnection.setConnectTimeout(10000);
        httpURLConnection.setReadTimeout(30000);
        httpURLConnection.setInstanceFollowRedirects(true);
        httpURLConnection.setRequestProperty("User-Agent", "tv-remote");
        try {
            try {
                if (httpURLConnection.getResponseCode() == 200) {
                    MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
                    String headerField = httpURLConnection.getHeaderField("content-length");
                    if (headerField != null && (longOrNull = StringsKt__StringNumberConversionsKt.toLongOrNull(headerField)) != null) {
                        j = longOrNull.longValue();
                    } else {
                        j = -1;
                    }
                    InputStream inputStream = httpURLConnection.getInputStream();
                    try {
                        FileOutputStream fileOutputStream = new FileOutputStream(file);
                        try {
                            byte[] bArr = new byte[65536];
                            long j2 = 0;
                            while (!((Boolean) function0.invoke()).booleanValue()) {
                                int read = inputStream.read(bArr);
                                if (read > 0) {
                                    fileOutputStream.write(bArr, 0, read);
                                    messageDigest.update(bArr, 0, read);
                                    j2 += read;
                                    if (j > 0) {
                                        words$$ExternalSyntheticLambda1.invoke(Integer.valueOf((int) ((100 * j2) / j)));
                                    }
                                } else {
                                    fileOutputStream.close();
                                    inputStream.close();
                                    if (j > 0 && j2 != j) {
                                        throw new IOException("download incomplete (" + j2 + " of " + j + " bytes)");
                                    }
                                    byte[] digest = messageDigest.digest();
                                    Intrinsics.checkNotNullExpressionValue(digest, "digest(...)");
                                    if (Intrinsics.areEqual(hex$shared_release(digest), apk.sha256)) {
                                        httpURLConnection.disconnect();
                                        return;
                                    }
                                    throw new IOException("launcher file does not match its signed checksum");
                                }
                            }
                            throw new IOException("stopped");
                        } finally {
                        }
                    } catch (Throwable th) {
                        try {
                            throw th;
                        } catch (Throwable th2) {
                            MathKt.closeFinally(inputStream, th);
                            throw th2;
                        }
                    }
                } else {
                    throw new IOException("HTTP " + httpURLConnection.getResponseCode());
                }
            } catch (Exception e) {
                file.delete();
                if (e instanceof IOException) {
                    throw e;
                }
                throw new IOException(e);
            }
        } catch (Throwable th3) {
            httpURLConnection.disconnect();
            throw th3;
        }
    }

    /* JADX WARN: Type inference failed for: r1v1, types: [java.util.List, java.util.Collection, java.lang.Object] */
    public static boolean english(Entry e, String str) {
        Intrinsics.checkNotNullParameter(e, "e");
        ?? r1 = e.langs;
        if (!r1.isEmpty() && str.length() > 0 && !r1.contains(str) && r1.contains("en")) {
            return true;
        }
        return false;
    }

    public static Facts facts(Function1 function1) {
        int i;
        boolean z;
        List split$default = StringsKt.split$default(StringsKt__StringsJVMKt.replace$default((String) function1.invoke("getprop ro.build.version.sdk; echo @@; getprop ro.product.cpu.abilist; echo @@; pm has-feature android.software.leanback; echo @@; pm path com.google.android.apps.tv.launcherx; echo @@; getprop ro.product.manufacturer; echo @@; pm path com.amazon.tv.launcher"), "\r", ""), new String[]{"\n@@\n", "@@\n"}, 0, 6);
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(split$default));
        Iterator it = split$default.iterator();
        while (it.hasNext()) {
            arrayList.add(StringsKt.trim((String) it.next()).toString());
        }
        ArrayList arrayList2 = new ArrayList(6);
        for (int i2 = 0; i2 < 6; i2++) {
            arrayList2.add("");
        }
        ArrayList plus = CollectionsKt.plus((List) arrayList, (Iterable) arrayList2);
        Integer intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull((String) plus.get(0));
        if (intOrNull != null) {
            i = intOrNull.intValue();
        } else {
            i = 0;
        }
        List split$default2 = StringsKt.split$default((CharSequence) plus.get(1), new char[]{','});
        ArrayList arrayList3 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(split$default2));
        Iterator it2 = split$default2.iterator();
        while (it2.hasNext()) {
            arrayList3.add(StringsKt.trim((String) it2.next()).toString());
        }
        ArrayList arrayList4 = new ArrayList();
        Iterator it3 = arrayList3.iterator();
        while (it3.hasNext()) {
            Object next = it3.next();
            if (((String) next).length() > 0) {
                arrayList4.add(next);
            }
        }
        boolean z2 = !Intrinsics.areEqual(plus.get(2), "false");
        boolean contains = StringsKt.contains((CharSequence) plus.get(3), "package:", false);
        if (!StringsKt__StringsJVMKt.equals((String) plus.get(4), "amazon") && !StringsKt.contains((CharSequence) plus.get(5), "package:", false)) {
            z = false;
        } else {
            z = true;
        }
        return new Facts(i, arrayList4, z2, contains, z);
    }

    public static Gallery fetch$default() {
        List list;
        File file;
        Pair pair = cache;
        if (pair != null && System.currentTimeMillis() - ((Number) pair.first).longValue() < 60000) {
            return (Gallery) pair.second;
        }
        Gallery gallery = null;
        if (testBase == null && (file = dir) != null) {
            File file2 = new File(file, "launchers.json");
            List list2 = SignedList.KEYS;
            byte[] kept = SignedList.kept(file2, CollectionsKt.plus(KEYS, (Iterable) testKeys));
            if (kept != null) {
                try {
                    gallery = parse(MathKt.readText$default(new File(file2.getPath() + ".base")), kept);
                } catch (IOException unused) {
                }
            }
        }
        if (gallery != null) {
            cache = new Pair(Long.valueOf(System.currentTimeMillis()), gallery);
            Thread thread = new Thread(new Guard$$ExternalSyntheticLambda3(2), "launchers");
            thread.setDaemon(true);
            thread.setPriority(1);
            thread.start();
            return gallery;
        }
        String str = testBase;
        if (str != null) {
            list = MathKt.listOf(str);
        } else {
            list = bases;
        }
        return (Gallery) first(list, "launchers.json", new Bloat$$ExternalSyntheticLambda0(5));
    }

    public static Object first(List places, String str, Function3 function3) {
        Intrinsics.checkNotNullParameter(places, "places");
        List list = SignedList.KEYS;
        return SignedList.fetch$default(places, str, CollectionsKt.plus(KEYS, (Iterable) testKeys), function3, 96);
    }

    public static Census.Props fits(Entry e, Facts facts) {
        Intrinsics.checkNotNullParameter(e, "e");
        if (!facts.leanback) {
            return new Census.Props(false, "not_tv");
        }
        if (facts.fire && !e.fire) {
            return new Census.Props(false, "fire");
        }
        int i = facts.sdk;
        if (1 <= i && i < e.minSdk) {
            return new Census.Props(false, "sdk");
        }
        boolean z = facts.googleTv;
        if (z && !e.gtv) {
            return new Census.Props(false, "gtv");
        }
        if (!z && !e.atv) {
            return new Census.Props(false, "atv");
        }
        if (e.kind.equals("apk") && apk(e, facts.abis) == null) {
            return new Census.Props(false, "abi");
        }
        return new Census.Props(true, "");
    }

    public static byte[] get$shared_release(String url) {
        Intrinsics.checkNotNullParameter(url, "url");
        return SignedList.get(url, 1048576, 10000, 30000);
    }

    public static String hex$shared_release(byte[] bArr) {
        return ArraysKt.joinToString$default(bArr, "", new Bloat$$ExternalSyntheticLambda1(9));
    }

    public static String lang(String str) {
        String substringBefore = StringsKt.substringBefore(str, '-', str);
        String lowerCase = StringsKt.substringBefore(substringBefore, '_', substringBefore).toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        if (lowerCase.equals("in")) {
            return "id";
        }
        if (lowerCase.equals("iw")) {
            return "he";
        }
        return lowerCase;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:29:0x014f A[Catch: JSONException -> 0x01ee, TryCatch #0 {JSONException -> 0x01ee, blocks: (B:3:0x000b, B:5:0x0022, B:6:0x0047, B:9:0x0052, B:12:0x0071, B:13:0x00a1, B:17:0x00fd, B:21:0x010d, B:23:0x0113, B:27:0x0121, B:29:0x014f, B:30:0x0165, B:32:0x016c, B:35:0x0187, B:42:0x01b0, B:43:0x01b9, B:45:0x01bf, B:47:0x01ce, B:49:0x01d4, B:52:0x01dc, B:59:0x01e0, B:62:0x01e6, B:63:0x01ed), top: B:2:0x000b }] */
    /* JADX WARN: Removed duplicated region for block: B:36:0x0185  */
    /* JADX WARN: Type inference failed for: r15v0, types: [kotlin.collections.EmptyList] */
    /* JADX WARN: Type inference failed for: r15v1 */
    /* JADX WARN: Type inference failed for: r15v3, types: [java.util.ArrayList] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static Gallery parse(String base, byte[] bArr) {
        JSONArray jSONArray;
        List list;
        String str;
        String str2;
        JSONObject optJSONObject;
        String str3;
        JSONArray optJSONArray;
        String optString;
        String str4 = "getString(...)";
        Intrinsics.checkNotNullParameter(base, "base");
        try {
            JSONObject jSONObject = new JSONObject(new String(bArr, Charsets.UTF_8));
            if (jSONObject.optInt("v") == 1) {
                JSONArray jSONArray2 = jSONObject.getJSONArray("launchers");
                String optString2 = jSONObject.optString("updated");
                Intrinsics.checkNotNullExpressionValue(optString2, "optString(...)");
                IntRange until = MathKt.until(0, jSONArray2.length());
                ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until));
                Iterator it = until.iterator();
                while (((IntProgressionIterator) it).hasNext) {
                    JSONObject jSONObject2 = jSONArray2.getJSONObject(((IntProgressionIterator) it).nextInt());
                    JSONObject jSONObject3 = jSONObject2.getJSONObject("supports");
                    String string = jSONObject2.getString("kind");
                    boolean areEqual = Intrinsics.areEqual(string, "apk");
                    ?? r15 = EmptyList.INSTANCE;
                    if (areEqual) {
                        JSONObject jSONObject4 = jSONObject2.getJSONObject("apk").getJSONObject("files");
                        Iterator<String> keys = jSONObject4.keys();
                        Intrinsics.checkNotNullExpressionValue(keys, "keys(...)");
                        jSONArray = jSONArray2;
                        list = SequencesKt.toList(new GeneratorSequence(SequencesKt.asSequence(keys), new Home$$ExternalSyntheticLambda6(jSONObject4, 2), 2));
                    } else {
                        jSONArray = jSONArray2;
                        list = r15;
                    }
                    String string2 = jSONObject2.getString("id");
                    Intrinsics.checkNotNullExpressionValue(string2, str4);
                    String string3 = jSONObject2.getString("package");
                    Intrinsics.checkNotNullExpressionValue(string3, str4);
                    String string4 = jSONObject2.getString("name");
                    Intrinsics.checkNotNullExpressionValue(string4, str4);
                    Map parse$words = parse$words(jSONObject2.optJSONObject("desc"));
                    String string5 = jSONObject2.getString("thumb");
                    Intrinsics.checkNotNullExpressionValue(string5, str4);
                    String optString3 = jSONObject2.optString("thumb_sha256");
                    Intrinsics.checkNotNullExpressionValue(optString3, "optString(...)");
                    String string6 = jSONObject2.getString("source");
                    Intrinsics.checkNotNullExpressionValue(string6, str4);
                    String str5 = str4;
                    String optString4 = jSONObject2.optString("license");
                    Intrinsics.checkNotNullExpressionValue(optString4, "optString(...)");
                    Intrinsics.checkNotNull(string);
                    JSONObject optJSONObject2 = jSONObject2.optJSONObject("apk");
                    if (optJSONObject2 != null) {
                        str = optString4;
                        String optString5 = optJSONObject2.optString("version");
                        if (optString5 != null) {
                            str2 = optString5;
                            optJSONObject = jSONObject2.optJSONObject("play");
                            if (optJSONObject != null && (optString = optJSONObject.optString("url")) != null) {
                                str3 = optString;
                                boolean optBoolean = jSONObject3.optBoolean("android_tv", true);
                                boolean optBoolean2 = jSONObject3.optBoolean("google_tv", true);
                                int optInt = jSONObject3.optInt("min_sdk", 21);
                                boolean optBoolean3 = jSONObject3.optBoolean("fire_os", false);
                                Map parse$words2 = parse$words(jSONObject3.optJSONObject("notes"));
                                optJSONArray = jSONObject2.optJSONArray("langs");
                                if (optJSONArray == null) {
                                    IntRange until2 = MathKt.until(0, optJSONArray.length());
                                    r15 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until2));
                                    Iterator it2 = until2.iterator();
                                    while (((IntProgressionIterator) it2).hasNext) {
                                        String optString6 = optJSONArray.optString(((IntProgressionIterator) it2).nextInt());
                                        Intrinsics.checkNotNullExpressionValue(optString6, "optString(...)");
                                        r15.add(lang(optString6));
                                    }
                                }
                                List list2 = r15;
                                String optString7 = jSONObject2.optString("fallback");
                                Intrinsics.checkNotNullExpressionValue(optString7, "optString(...)");
                                arrayList.add(new Entry(string2, string3, string4, parse$words, string5, optString3, string6, str, string, str2, list, str3, optBoolean, optBoolean2, optInt, optBoolean3, parse$words2, list2, lang(optString7)));
                                jSONArray2 = jSONArray;
                                str4 = str5;
                            }
                            str3 = "";
                            boolean optBoolean4 = jSONObject3.optBoolean("android_tv", true);
                            boolean optBoolean22 = jSONObject3.optBoolean("google_tv", true);
                            int optInt2 = jSONObject3.optInt("min_sdk", 21);
                            boolean optBoolean32 = jSONObject3.optBoolean("fire_os", false);
                            Map parse$words22 = parse$words(jSONObject3.optJSONObject("notes"));
                            optJSONArray = jSONObject2.optJSONArray("langs");
                            if (optJSONArray == null) {
                            }
                            List list22 = r15;
                            String optString72 = jSONObject2.optString("fallback");
                            Intrinsics.checkNotNullExpressionValue(optString72, "optString(...)");
                            arrayList.add(new Entry(string2, string3, string4, parse$words, string5, optString3, string6, str, string, str2, list, str3, optBoolean4, optBoolean22, optInt2, optBoolean32, parse$words22, list22, lang(optString72)));
                            jSONArray2 = jSONArray;
                            str4 = str5;
                        }
                    } else {
                        str = optString4;
                    }
                    str2 = "";
                    optJSONObject = jSONObject2.optJSONObject("play");
                    if (optJSONObject != null) {
                        str3 = optString;
                        boolean optBoolean42 = jSONObject3.optBoolean("android_tv", true);
                        boolean optBoolean222 = jSONObject3.optBoolean("google_tv", true);
                        int optInt22 = jSONObject3.optInt("min_sdk", 21);
                        boolean optBoolean322 = jSONObject3.optBoolean("fire_os", false);
                        Map parse$words222 = parse$words(jSONObject3.optJSONObject("notes"));
                        optJSONArray = jSONObject2.optJSONArray("langs");
                        if (optJSONArray == null) {
                        }
                        List list222 = r15;
                        String optString722 = jSONObject2.optString("fallback");
                        Intrinsics.checkNotNullExpressionValue(optString722, "optString(...)");
                        arrayList.add(new Entry(string2, string3, string4, parse$words, string5, optString3, string6, str, string, str2, list, str3, optBoolean42, optBoolean222, optInt22, optBoolean322, parse$words222, list222, lang(optString722)));
                        jSONArray2 = jSONArray;
                        str4 = str5;
                    }
                    str3 = "";
                    boolean optBoolean422 = jSONObject3.optBoolean("android_tv", true);
                    boolean optBoolean2222 = jSONObject3.optBoolean("google_tv", true);
                    int optInt222 = jSONObject3.optInt("min_sdk", 21);
                    boolean optBoolean3222 = jSONObject3.optBoolean("fire_os", false);
                    Map parse$words2222 = parse$words(jSONObject3.optJSONObject("notes"));
                    optJSONArray = jSONObject2.optJSONArray("langs");
                    if (optJSONArray == null) {
                    }
                    List list2222 = r15;
                    String optString7222 = jSONObject2.optString("fallback");
                    Intrinsics.checkNotNullExpressionValue(optString7222, "optString(...)");
                    arrayList.add(new Entry(string2, string3, string4, parse$words, string5, optString3, string6, str, string, str2, list, str3, optBoolean422, optBoolean2222, optInt222, optBoolean3222, parse$words2222, list2222, lang(optString7222)));
                    jSONArray2 = jSONArray;
                    str4 = str5;
                }
                ArrayList arrayList2 = new ArrayList();
                Iterator it3 = arrayList.iterator();
                while (it3.hasNext()) {
                    Object next = it3.next();
                    String str6 = ((Entry) next).kind;
                    if (str6.equals("apk") || str6.equals("play") || str6.equals("self")) {
                        arrayList2.add(next);
                    }
                }
                return new Gallery(optString2, arrayList2, base);
            }
            throw new IOException("launcher list: unknown version");
        } catch (JSONException e) {
            throw new IOException(ApkSigner$$ExternalSyntheticOutline0.m("launcher list: ", e.getMessage()));
        }
    }

    public static final Map parse$words(JSONObject jSONObject) {
        Iterator<String> keys;
        if (jSONObject != null && (keys = jSONObject.keys()) != null) {
            Sequence asSequence = SequencesKt.asSequence(keys);
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            Iterator it = ((ConstrainedOnceSequence) asSequence).iterator();
            while (it.hasNext()) {
                Object next = it.next();
                linkedHashMap.put(next, jSONObject.optString((String) next));
            }
            return linkedHashMap;
        }
        return EmptyMap.INSTANCE;
    }

    public static Apk self() {
        try {
            List list = Release.KEYS;
            Release newer = MathKt.newer("0", "home", "tv-home.apk");
            if (newer != null) {
                return new Apk("any", newer.url, newer.sha256);
            }
            throw new IOException("launcher:self");
        } catch (IOException e) {
            throw e;
        } catch (Exception e2) {
            throw new IOException(e2.getMessage(), e2);
        }
    }

    public static byte[] thumb(Gallery g, Entry e) {
        File file;
        File file2;
        File file3;
        Intrinsics.checkNotNullParameter(g, "g");
        Intrinsics.checkNotNullParameter(e, "e");
        String str = e.thumbSha;
        if (str.length() == 0) {
            str = Census$$ExternalSyntheticOutline0.m(g.base, e.thumb);
        }
        ConcurrentHashMap concurrentHashMap = thumbs;
        byte[] bArr = (byte[]) concurrentHashMap.get(str);
        if (bArr != null) {
            return bArr;
        }
        byte[] bArr2 = null;
        if (e.thumbSha.length() > 0 && (file3 = dir) != null) {
            file = new File(file3, e.thumbSha.concat(".jpg"));
        } else {
            file = null;
        }
        if (file != null) {
            try {
                if (file.isFile()) {
                    file2 = file;
                } else {
                    file2 = null;
                }
                if (file2 != null) {
                    byte[] readBytes = MathKt.readBytes(file2);
                    byte[] digest = MessageDigest.getInstance("SHA-256").digest(readBytes);
                    Intrinsics.checkNotNullExpressionValue(digest, "digest(...)");
                    if (Intrinsics.areEqual(hex$shared_release(digest), e.thumbSha)) {
                        bArr2 = readBytes;
                    }
                    if (bArr2 != null) {
                        concurrentHashMap.put(str, bArr2);
                        return bArr2;
                    }
                }
            } catch (IOException unused) {
            }
        }
        byte[] bArr3 = get$shared_release(g.base + e.thumb);
        if (e.thumbSha.length() > 0) {
            byte[] digest2 = MessageDigest.getInstance("SHA-256").digest(bArr3);
            Intrinsics.checkNotNullExpressionValue(digest2, "digest(...)");
            if (!Intrinsics.areEqual(hex$shared_release(digest2), e.thumbSha)) {
                throw new IOException("launcher file does not match its signed checksum");
            }
        }
        thumbs.put(str, bArr3);
        if (file != null) {
            try {
                File parentFile = file.getParentFile();
                if (parentFile != null) {
                    parentFile.mkdirs();
                }
                MathKt.writeBytes(file, bArr3);
            } catch (IOException unused2) {
            }
        }
        return bArr3;
    }

    public static String tvLang(Function1 function1) {
        Object obj;
        List lines = StringsKt.lines((CharSequence) function1.invoke("settings get system system_locales; getprop persist.sys.locale; getprop ro.product.locale"));
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(lines));
        Iterator it = lines.iterator();
        while (it.hasNext()) {
            arrayList.add(StringsKt.trim((String) it.next()).toString());
        }
        Iterator it2 = arrayList.iterator();
        while (true) {
            if (it2.hasNext()) {
                obj = it2.next();
                String str = (String) obj;
                if (str.length() > 0 && !str.equals("null")) {
                    break;
                }
            } else {
                obj = null;
                break;
            }
        }
        String str2 = (String) obj;
        if (str2 != null) {
            return lang(StringsKt.substringBefore(str2, ',', str2));
        }
        return "";
    }

    public static void useTestFile(File file) {
        String str = null;
        try {
            File file2 = new File(file, "launchers-url.txt");
            if (!file2.isFile()) {
                file2 = null;
            }
            if (file2 != null) {
                str = StringsKt.trim(MathKt.readText$default(file2)).toString();
            }
        } catch (IOException unused) {
        }
        if (str != null && str.length() != 0) {
            if (!StringsKt__StringsJVMKt.endsWith(str, false, "/")) {
                str = str.concat("/");
            }
            testBase = str;
        }
    }
}
