package dev.tvremote.core.ontv;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyList;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgressionIterator;
import kotlin.ranges.IntRange;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public abstract class Bloat {
    public static final Regex PKG;
    public static volatile long asked;
    public static volatile Extra extra;
    public static volatile String testBase;
    public static final LinkedHashMap SUGGEST = MapsKt__MapsKt.linkedMapOf(new Pair("com.google.android.feedback", "Google Feedback"), new Pair("com.google.android.tv.bugreportsender", "Bug report sender"), new Pair("com.android.tv.feedbackconsent", "Feedback consent"), new Pair("android.autoinstalls.config.google.gtvpai", "Google TV partner app installer"), new Pair("android.autoinstalls.config.JVC", "JVC app installer"), new Pair("android.autoinstalls.config.SW", "Skyworth app installer"), new Pair("android.autoinstalls.config.skyworth", "Skyworth app installer"), new Pair("android.autoinstalls.config.haier.hanyang", "Haier app installer"), new Pair("android.autoinstalls.config.hisense.xiaoyushan", "Hisense app installer"), new Pair("android.autoinstalls.config.nvidia", "NVIDIA app installer"), new Pair("android.autoinstalls.config.sei", "Free app installer"), new Pair("android.autoinstalls.config.soc.amlogic", "Amlogic app installer"), new Pair("android.autoinstalls.config.tcl.device", "TCL app installer"), new Pair("android.autoinstalls.config.tpv.device", "TP Vision app installer"), new Pair("android.autoinstalls.config.xioami.dangal", "Xiaomi app installer"), new Pair("android.autoinstalls.config.xioami.mibox3", "Xiaomi app installer"), new Pair("android.autoinstalls.config.hisense", "Hisense app installer"), new Pair("android.autoinstalls.config.hisense.hayward", "Hisense app installer"), new Pair("android.autoinstalls.config.hkc", "HKC app installer"), new Pair("android.autoinstalls.config.sharp", "Sharp app installer"), new Pair("android.autoinstalls.config.scbc.device", "SCBC app installer"), new Pair("android.autoinstalls.config.sdmc", "SDMC app installer"), new Pair("android.autoinstalls.config.vestel.coma", "Vestel app installer"), new Pair("android.autoinstalls.config.vestel.cosmos", "Vestel app installer"), new Pair("android.autoinstalls.config.vestel.medusa", "Vestel app installer"), new Pair("tv.anoki.acr.anokiacroptin", "Anoki content recognition"), new Pair("tv.anoki.acr.controller", "Anoki content recognition"), new Pair("tv.inscape.tvclient.inscapeacr", "Inscape content recognition"), new Pair("com.sony.dtv.da.service", "Sony device agent"), new Pair("com.qterics.da.product", "Sony remote support agent"), new Pair("com.sony.dtv.sonybugreportsys", "Sony bug reports"), new Pair("android.autoinstalls.config.sony.bravia", "Sony app installer"), new Pair("com.sonyericsson.idd.agent", "Sony usage data"), new Pair("com.sony.dtv.promos", "Sony promotions (My BRAVIA)"), new Pair("com.sony.dtv.demosystemsupport", "Sony demo support"), new Pair("tv.samba.ssm.ui", "Samba TV opt-in screens"), new Pair("com.sony.dtv.demomode", "Sony demo mode"), new Pair("com.miui.tv.analytics", "Xiaomi analytics"), new Pair("com.xiaomi.statistic", "Xiaomi statistics"), new Pair("com.xm.webcontent", "Xiaomi web content"), new Pair("com.mitv.tvhome.oemtab", "Mi Home tab"), new Pair("com.mitv.tvhome.michannel", "Mi Channel"), new Pair("com.mitv.tvhome.mitvplus", "Mi TV+"), new Pair("android.autoinstalls.config.xiaomi.amelie", "Xiaomi app installer"), new Pair("com.xiaomi.tvqs", "Xiaomi quality stats"), new Pair("com.miui.misightservice", "Xiaomi usage data"), new Pair("com.mitv.cloudcontrol", "Xiaomi remote app push"), new Pair("com.miui.analytics", "Xiaomi MIUI analytics"), new Pair("com.tcl.bi", "TCL analytics"), new Pair("com.tcl.logkit", "TCL log uploader"), new Pair("com.tcl.esticker", "TCL e-sticker (shop demo)"), new Pair("com.tcl.bootadservice", "TCL start-up ads"), new Pair("com.tcl.smartlink.core", "TCL silent app installer"), new Pair("com.tcl.tv.tclhome_passive", "TCL home-screen promotions"), new Pair("com.hisense.app.logreport", "Hisense log reports"), new Pair("android.autoinstalls.config.hisense.laohushan", "Hisense app installer"), new Pair("com.vidaa.oemtabcontentprovider", "Hisense tab"), new Pair("com.vt.storemode", "Hisense store mode"), new Pair("com.hisense.storemode", "Hisense store mode"), new Pair("com.hisense.logupload", "Hisense log upload"), new Pair("com.hisense.platformreport", "Hisense platform reports"), new Pair("com.hisense.business.ad", "Hisense business ads"), new Pair("com.hisense.service.ad", "Hisense ad service"), new Pair("com.hisense.demonstrate", "Hisense demo"), new Pair("org.droidtv.usagelogger", "Philips usage logger"), new Pair("org.droidtv.candeebug", "Philips DAC analytics"), new Pair("org.droidtv.gel", "Philips DAC analytics"), new Pair("org.droidtv.demome", "Philips demo"), new Pair("org.droidtv.sticker", "Philips shop sticker"), new Pair("org.droidtv.tv.frameworklogger", "Philips framework logger"), new Pair("com.vestel.vestelreporter", "Vestel reporter"), new Pair("com.vestel.smartlogger", "Vestel logger"), new Pair("com.cvte.gaia.ad.service", "CVTE ad service"), new Pair("com.cvte.wonder.cloud.service", "CVTE ads and analytics"), new Pair("com.cvte.tv.pictorial", "CVTE screensaver ads"), new Pair("com.xgimi.datareporter", "XGIMI data reporter"), new Pair("com.xgimi.bugreportsender", "XGIMI bug reports"), new Pair("com.verizon.tv.ams", "Verizon event recorder"), new Pair("com.wnc.wnclogger", "WNC logger"), new Pair("com.htc.eventuploadservice", "HTC event upload"), new Pair("com.smartdevice.common.demonow", "Shop demo"), new Pair("com.panasonic.demomode", "Panasonic demo mode"), new Pair("com.nvidia.stats", "NVIDIA statistics"), new Pair("com.nvidia.feedback", "NVIDIA feedback"), new Pair("com.apps.esticker3", "Shop energy-label sticker"), new Pair("com.amazon.kso.blackbird", "Fire TV ads (screensaver)"), new Pair("com.amazon.tv.fw.metrics", "Fire TV metrics"), new Pair("com.amazon.wirelessmetrics.service", "Fire TV Wi-Fi metrics"), new Pair("com.amazon.perfcollection", "Fire TV performance data"), new Pair("com.amazon.hybridadidservice", "Fire TV ad ID"), new Pair("com.amazon.device.sale.service", "Amazon deals"), new Pair("com.amazon.tv.acr", "Fire TV content recognition"), new Pair("com.amazon.client.metrics.api", "Fire TV metrics API"), new Pair("com.amazon.metrics.api", "Fire TV metrics API"), new Pair("com.amazon.neo.minerva", "Fire TV metrics (Minerva)"), new Pair("com.amazon.neo.minerva.logcat", "Fire TV log collector"), new Pair("com.amazon.perfc", "Fire TV performance data"), new Pair("com.amazon.dp.logger", "Fire TV logger"), new Pair("com.amazon.wifilocker", "Fire TV Wi-Fi password upload"), new Pair("com.amazon.sneakpeek", "Fire TV sponsored previews"), new Pair("com.amazon.tv.easyupgrade", "Fire TV upgrade promos"), new Pair("com.amazon.shoptv.client", "Amazon shopping on TV"), new Pair("com.amazon.shoptv.firetv.client", "Amazon shopping on TV"), new Pair("com.amazon.tv.releasenotes", "Fire TV release notes"), new Pair("com.amazon.device.telemetry.emitter", "Fire TV telemetry"), new Pair("com.amazon.tv.democontent.provider", "Fire TV demo content"));
    public static final Regex FACTORY = new Regex("(?i)(.*\\.)?(\\w*fac|\\w*factory\\w*)(\\..*)?");
    public static final Regex KEEP = new Regex("com\\.tcl\\.(tv|tvinput|tvpassthrough|sourcemananger|keycustomfunctionservice|keyhelp|framework\\.custom|settings|inputmethod\\.international|globalkeyoverlay|TFDS\\.service|xian\\.StartandroidService|showmode|system\\.?server|systemserver|tcl_bt_rcu_service|autopair|suspension|interactive|ttvs|providers\\.config|initsetup|factory\\.view|dashboard|eva|appstatecontroller|rc\\.ota|UpdatePeripheral|useragreement|copydatatotv|guard|cyberui)|.*\\.partnercustomizer|com\\.android\\.WifiCountryService|com\\.tvos|com\\.sohu\\.inputmethod\\.sogou\\.tv|com\\.mitv\\.livetv|mitv\\.service|com\\.mitv\\.overseaservice|com\\.mi\\.bluetooth|com\\.xiaomi\\.android\\.tvsetup\\.partnercustomizer|com\\.xiaomi\\.mitv\\.(res|tvmanager|upgrade|tvplayer|settings|smartpanel)|com\\.mitv\\.(tvhome|codec\\.update)|com\\.sony\\.dtv\\.(tvx|tvinput\\..*|braviasync.*|remotepairing|uinputservice|imeproxy|dialservice|tvapi|sonysystemservice|rcpowerkey|settingsprovider|smartui|tvlin|tvplayer.*|remotecontrolsettings|systemupdate|update|youview|irblaster|irbservice)|com\\.youview\\.tv\\.servicehost|com\\.uei\\.quicksetsdk|com\\.hisense\\.(hitvinput|kpad|favkey|uifac|audio_update_service|bluetoothpair|mixbar|tv\\.(hitvinput|inputs|baseservice|tiletransition|smartsense|smartservice|customerlauncher))|com\\.hisense\\.tv\\.hitvinput|com\\.jamdeo\\.tv\\.(livetv|service)|com\\.mstar\\.netflixobserver|com\\.vidaa\\.persistent\\.service|com\\.vt\\.tv\\.(ota|smartsense.*|ai_sense|aiot.*|tvcenter|input|commonui|smartservice|aipq|videocolor|customerlauncher)|com\\.vt\\.(remoteupgrade|source\\..*|tvservice|avmiddleware|tvplayer|edv\\.drmp|eula|udpserver)|org\\.droidtv\\.(ambiair|ambihuecommon|alhuewizard|audiocalibration|calmancalibrator|bluetoothaudiosink|xtv|xtvsystem|playtv|channels|epgdata|dvbi|teletext|ci|hdmiservice|euinstallertc|euinstallersat|hbbtvopapp|tv\\.tptvservice|icp|sunrise|tvsystemui|tvpowermanagerservice|GlobalKey|lkb|settings|menudataapp|homeintentresolver|oad|devicesetup|networkwizard|nettvregistration|nettvbrowser|contentexplorer|eum|aurora|fastip|exoplayerservice|usbbreakin|dlna)|com\\.easy\\.oad|com\\.vewd\\.core\\.browserui|com\\.tpv_soem\\..*|com\\.realtek\\.(dtv|tv|tv\\.atv|tv\\.passthrough|systemservice|menu|netflix\\.setting)|com\\.realtek\\.keyinterceptserver|com\\.apps\\.(ota|authota|smartkey|tvmanager|globalkeyhandler|bluetoothremote|virtualkey)|com\\.mk\\.(service\\.tvmidware|tv\\.fivekey)|com\\.realsil\\.ota|com\\.homwee\\.(dmt\\.upgrade|factory|synckey|dynamicbacklight)|com\\.gdch\\.android\\.tv\\.inputplayer|com\\.haier\\.(tv\\.hmagicboard|hkcfac|appmanager\\.dispatcher|bt_pair_tips)|com\\.cvte\\.tv\\.(hkcfac|at|fac\\..*|androidsetting|api\\.impl|setting|globalui|systemupgrade)|com\\.cvte\\.(tvservice|hotkey\\.dispatcher|tv\\.launcher\\..*)|com\\.at\\.factory\\..*|com\\.example\\.bt_pair_tips|com\\.telink\\.lt\\.ota|fusion\\.android\\.tv\\.demo|com\\.smartdevice\\.(livetv|global\\.service|factory|duplebluetooth|dailyshortcut)|com\\.cltv\\.(hybrid|mal)|com\\.coocaa\\.factory|net\\.oqee\\.androidtv|org\\.dtvkit\\.inputsource|fr\\.freebox\\..*|com\\.nes\\.(dtvkitdatabackup|blerc|tvglobalkeyhandler|freeboxburnkey)|com\\.sdt\\.(projector\\.observer|customization|globalkey|app\\.skysettings|projectionservice)|com\\.hisilicon\\..*|com\\.skyworthdigital\\..*|com\\.vestel\\.(tv\\..*|overlay\\..*)|com\\.xgimi\\.(autokst|windowsystem|tof|misckey|uiconfiguration|xrmservice|xgimiservice|hardware|inputs|mirroring)|com\\.nbcast\\.wirelessscreen|com\\.sdmc\\.(tv|bluetoothconnect|GlobalKey)|com\\.google\\.android\\.tv\\.inputplayer|com\\.mft\\.(rcupair|frontpanelledsservice)|com\\.jmgo\\.(hippo|autofocus|tofautofocus|autokeystone|dewarping|ptz|autobrightness|a2dpsinkservice|android\\.tv\\.globalkeyoverlay|remotecontrolota|factory)|com\\.google\\.android\\.tv\\.dfuservice|com\\.dolby\\.android\\.audio\\.service|com\\.gretzky\\.GlobalKey|com\\.amazon\\.(venezia|tigris|vizzini|cardinal|logan|tv\\.(settings.*|oobe|quicksettings|livetv|launcher|ime)|whisperlink.*|whisperjoin.*|aria)|com\\.mediatek\\..*|com\\.droidlogic(\\..*)?");
    public static final List bases = ArraysKt.asList(new String[]{"https://tvremote.pages.dev/optimize/", "https://raw.githubusercontent.com/HoangTran0410/tv-remote/main/docs/optimize/"});

    /* loaded from: classes.dex */
    public final class Extra {
        public final Set drop;
        public final ArrayList factory;
        public final ArrayList keep;
        public final Object suggest;

        public Extra(Map map, Set set, ArrayList arrayList, ArrayList arrayList2) {
            this.suggest = map;
            this.drop = set;
            this.keep = arrayList;
            this.factory = arrayList2;
        }
    }

    static {
        String obj;
        String str = System.getenv("TVR_BLOAT");
        String str2 = null;
        if (str != null && (obj = StringsKt.trim(str).toString()) != null) {
            if (obj.length() <= 0) {
                obj = null;
            }
            if (obj != null) {
                if (!StringsKt__StringsJVMKt.endsWith(obj, false, "/")) {
                    obj = obj.concat("/");
                }
                str2 = obj;
            }
        }
        testBase = str2;
        PKG = new Regex("[A-Za-z][\\w]*(\\.[\\w]+)+");
    }

    public static boolean factory(String p) {
        Intrinsics.checkNotNullParameter(p, "p");
        if (!FACTORY.matches(p)) {
            Extra extra2 = extra;
            if (extra2 != null) {
                ArrayList arrayList = extra2.factory;
                if (!arrayList.isEmpty()) {
                    Iterator it = arrayList.iterator();
                    while (it.hasNext()) {
                        if (((Regex) it.next()).matches(p)) {
                            return true;
                        }
                    }
                    return false;
                }
                return false;
            }
            return false;
        }
        return true;
    }

    public static void fresh() {
        long j;
        List list;
        long currentTimeMillis = System.currentTimeMillis();
        long j2 = currentTimeMillis - asked;
        if (extra != null) {
            j = 21600000;
        } else {
            j = 1800000;
        }
        if (j2 >= j) {
            asked = currentTimeMillis;
            try {
                List list2 = Launchers.KEYS;
                String str = testBase;
                if (str != null) {
                    list = MathKt.listOf(str);
                } else {
                    list = bases;
                }
                extra = (Extra) Launchers.first(list, "bloat.json", new Bloat$$ExternalSyntheticLambda0(0));
            } catch (IOException unused) {
            }
        }
    }

    public static final List parse$strings(String str, JSONObject jSONObject) {
        ArrayList arrayList;
        JSONArray optJSONArray = jSONObject.optJSONArray(str);
        if (optJSONArray != null) {
            IntRange until = MathKt.until(0, optJSONArray.length());
            arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until));
            Iterator it = until.iterator();
            while (((IntProgressionIterator) it).hasNext) {
                arrayList.add(optJSONArray.getString(((IntProgressionIterator) it).nextInt()));
            }
        } else {
            arrayList = null;
        }
        if (arrayList == null) {
            return EmptyList.INSTANCE;
        }
        return arrayList;
    }

    /* JADX WARN: Type inference failed for: r0v2, types: [java.util.Map, java.lang.Object] */
    public static LinkedHashMap suggest() {
        Extra extra2 = extra;
        if (extra2 != null) {
            LinkedHashMap linkedHashMap = SUGGEST;
            LinkedHashMap linkedHashMap2 = new LinkedHashMap();
            for (Map.Entry entry : linkedHashMap.entrySet()) {
                if (!extra2.drop.contains((String) entry.getKey())) {
                    linkedHashMap2.put(entry.getKey(), entry.getValue());
                }
            }
            return MapsKt__MapsKt.plus(linkedHashMap2, extra2.suggest);
        }
        return SUGGEST;
    }
}
