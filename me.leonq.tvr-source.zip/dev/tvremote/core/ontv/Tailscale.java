package dev.tvremote.core.ontv;

import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.adb.Adb;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.sequences.SequencesKt;
import kotlin.text.Charsets;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.RegexOption;
import kotlin.text.StringsKt;

/* loaded from: classes.dex */
public final class Tailscale {
    public final Adb adb;
    public static final Regex LOGIN = new Regex("^(get started|continue|log ?in|sign ?in|bắt đầu|đăng nhập|anmelden|connexion|iniciar sesión|ログイン|登录|로그인)$", RegexOption.IGNORE_CASE);
    public static final Regex CODE = new Regex("^[0-9a-f]{8,20}$");
    public static final Regex NODE = new Regex("<node [^>]*?text=\"([^\"]*)\"[^>]*?bounds=\"\\[(\\d+),(\\d+)\\]\\[(\\d+),(\\d+)\\]\"");

    public Tailscale(Adb adb, File file) {
        this.adb = adb;
    }

    public static String get(String str) {
        URLConnection openConnection = new URL(str).openConnection();
        Intrinsics.checkNotNull(openConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
        HttpURLConnection httpURLConnection = (HttpURLConnection) openConnection;
        httpURLConnection.setConnectTimeout(15000);
        httpURLConnection.setReadTimeout(20000);
        try {
            InputStream inputStream = httpURLConnection.getInputStream();
            Intrinsics.checkNotNullExpressionValue(inputStream, "getInputStream(...)");
            return MathKt.readText(new BufferedReader(new InputStreamReader(inputStream, Charsets.UTF_8), 8192));
        } finally {
            httpURLConnection.disconnect();
        }
    }

    public final String ip() {
        String str;
        Pattern compile = Pattern.compile("inet (100\\.[0-9.]+)/32");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        Adb adb = this.adb;
        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
        String input = adb.shell(120000L, "ip -4 addr show");
        Intrinsics.checkNotNullParameter(input, "input");
        Matcher matcher = compile.matcher(input);
        Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
        MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, input);
        if (access$findNext != null && (str = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)) != null) {
            return str;
        }
        return "";
    }

    public final void keepAlive() {
        Adb adb = this.adb;
        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
        adb.shell(120000L, "dumpsys deviceidle whitelist +com.tailscale.ipn");
        adb.shell(120000L, "am set-standby-bucket com.tailscale.ipn active");
        adb.shell(120000L, "cmd appops set com.tailscale.ipn RUN_IN_BACKGROUND allow; cmd appops set com.tailscale.ipn RUN_ANY_IN_BACKGROUND allow");
        adb.shell(120000L, "settings put secure always_on_vpn_app com.tailscale.ipn; settings put secure always_on_vpn_lockdown 0");
    }

    public final String signIn() {
        Object obj;
        Object obj2;
        int i = 0;
        for (int i2 = 0; i2 < 20; i2++) {
            Thread.sleep(1500L);
            if (ip().length() > 0) {
                return "";
            }
            Adb adb = this.adb;
            List list = SequencesKt.toList(Regex.findAll$default(NODE, adb.shell(120000L, "uiautomator dump /sdcard/tvr-ui.xml >/dev/null 2>&1; cat /sdcard/tvr-ui.xml; rm -f /sdcard/tvr-ui.xml")));
            Iterator it = list.iterator();
            while (true) {
                obj = null;
                if (it.hasNext()) {
                    obj2 = it.next();
                    if (CODE.matches((CharSequence) ((MatcherMatchResult$groupValues$1) ((MatcherMatchResult) obj2).getGroupValues()).get(1))) {
                        break;
                    }
                } else {
                    obj2 = null;
                    break;
                }
            }
            MatcherMatchResult matcherMatchResult = (MatcherMatchResult) obj2;
            if (matcherMatchResult != null) {
                return "https://login.tailscale.com/a/" + ((MatcherMatchResult$groupValues$1) matcherMatchResult.getGroupValues()).get(1);
            }
            Iterator it2 = list.iterator();
            while (true) {
                if (!it2.hasNext()) {
                    break;
                }
                Object next = it2.next();
                if (LOGIN.matches(StringsKt.trim((String) ((MatcherMatchResult$groupValues$1) ((MatcherMatchResult) next).getGroupValues()).get(1)).toString())) {
                    obj = next;
                    break;
                }
            }
            MatcherMatchResult matcherMatchResult2 = (MatcherMatchResult) obj;
            String shell = adb.shell(120000L, "dumpsys window | grep -E 'mCurrentFocus|mFocusedWindow'");
            if (StringsKt.contains(shell, "com.tailscale.ipn", false) && !StringsKt.contains(shell, "UsbDebugging", false)) {
                if (matcherMatchResult2 != null && i < 5) {
                    List drop = CollectionsKt.drop(2, matcherMatchResult2.getGroupValues());
                    ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(drop));
                    Iterator it3 = drop.iterator();
                    while (it3.hasNext()) {
                        arrayList.add(Integer.valueOf(Integer.parseInt((String) it3.next())));
                    }
                    adb.shell(120000L, Census$$ExternalSyntheticOutline0.m("input tap ", (((Number) arrayList.get(0)).intValue() + ((Number) arrayList.get(2)).intValue()) / 2, " ", (((Number) arrayList.get(1)).intValue() + ((Number) arrayList.get(3)).intValue()) / 2));
                } else if (matcherMatchResult2 == null && i2 == 4 && i == 0) {
                    adb.shell(120000L, "input keyevent 23");
                }
                i++;
            }
        }
        throw new IOException("no sign-in link on the TV's screen");
    }
}
