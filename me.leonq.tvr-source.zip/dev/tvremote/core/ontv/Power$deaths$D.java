package dev.tvremote.core.ontv;

import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class Power$deaths$D {
    public final String pkg;
    public final double t;
    public String why;

    public Power$deaths$D(double d, String str, String why) {
        Intrinsics.checkNotNullParameter(why, "why");
        this.t = d;
        this.pkg = str;
        this.why = why;
    }
}
