package dev.tvremote.core.ontv;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.Mdns;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgressionIterator;
import kotlin.text.Charsets;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class SetupUpdate {
    public static final Regex VERSION = new Regex("[0-9]+(\\.[0-9]+)*");
    public static final String SCRIPT = "D=/data/local/tmp/tvr-update; P=dev.tvremote.setup; A=$1; V=$2; O=$3; echo $$ > $D/pid   # on its own now: see start()\ntrap 'rmdir $D/lock 2>/dev/null' EXIT                    # the next update may start\nsvc() { for p in dev.tvremote.setup dev.tvremote.home; do pm path $p >/dev/null 2>&1 || continue; dumpsys deviceidle whitelist +$p >/dev/null 2>&1; am set-standby-bucket $p active >/dev/null 2>&1; cmd appops set $p RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1; done; cmd deviceidle whitelist +dev.tvremote.setup >/dev/null 2>&1; am startservice -n dev.tvremote.setup/.RemoteService 2>&1 | grep -q Error && am start-foreground-service -n dev.tvremote.setup/.RemoteService >/dev/null 2>&1; }                             # no 10 s deadline: RulesClient.START\nsay() { echo \"$1 $(date +%s) $V ${old:--} $2\" > $D/state; }\nver() { dumpsys package $P 2>/dev/null | grep -m1 versionName= | sed 's/.*versionName=//'; }\n# Not the TV's own refusal to let a background start become a foreground service (\"did not then call Service.startForeground()\", seen on TCL):\n# that says nothing about this version, and the old one dies the same way. awk drops those crashes from the count.\ncrashes() { logcat -b crash -d 2>/dev/null | awk -v p=\"Process: $P,\" 'index($0, p) { n++; c = 1; next } /FATAL EXCEPTION/ { c = 0 } c && /did not then call Service.startForeground/ { n--; c = 0 } END { print n + 0 }'; }\n# the same three pm calls as PmInstall.kt, one per call\nsess() { s=$(pm install-create -r -S $size 2>&1 | sed -n 's/.*\\[\\([0-9]*\\)\\].*/\\1/p'); [ -n \"$s\" ] || { echo \"install-create failed\"; return; }\n  w=$(cat \"$A\" | pm install-write -S $size $s base.apk - 2>&1)\n  case \"$w\" in *Success*) pm install-commit $s 2>&1 ;; *) pm install-abandon $s >/dev/null 2>&1; echo \"$w\" ;; esac; }\nold=$(ver); rm -f $D/ok; say installing\nsize=$(stat -c %s \"$A\"); c0=$(crashes); rb=1\nout=$(cat \"$A\" | pm install -r --enable-rollback -S $size 2>&1)\ncase \"$out\" in *Success*) ;; *) rb=0; out=$(cat \"$A\" | pm install -r -S $size 2>&1) ;; esac   # Android 9: no rollback\ncase \"$out\" in *Success*) ;; *\"disabled from pm\"*) rb=0; out=$(sess) ;; esac   # firmware that refuses pm install: a session\n[ \"$A\" = $D/new.apk ] && rm -f \"$A\"\ncase \"$out\" in *Success*) ;; *) say failed \"$(echo $out | tr -s ' \\n' ' ' | cut -c1-200)\"; exit 0 ;; esac\necho \"installed $V (rollback $rb)\"; say checking\nsvc\ngood=0; i=0\nwhile [ $i -lt 90 ]; do                                    # up to 90 s for it to say it runs, fewer if it keeps crashing\n  sleep 1; i=$((i + 1))\n  [ \"$(cat $D/ok 2>/dev/null)\" = \"$V\" ] && { good=1; break; }\n  [ $(($(crashes) - c0)) -ge 2 ] && break\n  [ $((i % 20)) = 0 ] && svc\ndone\n[ $good = 1 ] && sleep 20                                  # and still running a little later\n# what a person needs to see why, on a TV nobody here can reach: the model, its ADB, TV Setup's crashes and ADB lines (report())\nfacts() { { echo \"$1 $V from ${old:--}\"; for k in ro.product.manufacturer ro.product.brand ro.product.model ro.product.device ro.build.version.release ro.build.version.sdk ro.build.fingerprint ro.adb.secure service.adb.tcp.port persist.adb.tcp.port sys.usb.config; do echo \"$k=$(getprop $k)\"; done\n  echo \"adb_enabled=$(settings get global adb_enabled) adb_wifi=$(settings get global adb_wifi_enabled) pid=$(pidof $P) crashes=$c0->$(crashes)\"\n  echo \"key: $(am broadcast -n $P/.TrustReceiver --es want adbkey 2>&1 | grep -o 'data=.*')\"\n  echo \"listen: $( (netstat -ltn 2>/dev/null || ss -ltn 2>/dev/null) | grep -oE ':(5555|5037) ' | sort -u | tr -d '\\n')\"\n  echo \"== crash\"; logcat -b crash -d 2>/dev/null | grep -A30 \"Process: $P,\" | tail -70\n  echo \"== log\"; logcat -d -t 3000 2>/dev/null | grep -iE \"adbd|$P|tvremote\" | grep -iE \"adb|auth|key|exception|error|refused|denied\" | grep -vE \"spawning|Adapter|transport|offline|read failed: Success|terminated\" | tail -40\n  } 2>&1 | cut -c1-300 | head -170 > $D/report; }\nshow() { [ \"$O\" = open ] && am start -n $P/.MainActivity >/dev/null 2>&1; }\nif [ $good = 1 ] && [ \"$(crashes)\" = \"$c0\" ]; then rm -f $D/ok; say ok; show; exit 0; fi\n# running, never crashed, only not through to the TV's ADB itself (its key not allowed, ADB slow to come up on that box): that is\n# not this version's fault, and every update of such a TV was undone the same way\nif [ \"$(crashes)\" = \"$c0\" ] && pidof $P >/dev/null 2>&1; then echo \"$V runs, no ADB of its own: kept\"; facts noadb; say ok noadb; show; exit 0; fi\nfacts \"ok=$good\"\necho \"$V did not start well (ok=$good, crashes $c0 -> $(crashes))\"; echo $V >> $D/bad\nif [ $rb = 1 ] && [ \"$old\" != \"\" ]; then\n  for t in 1 2 3 4 5; do pm rollback-app $P 2>&1; [ \"$(ver)\" = \"$old\" ] && break; sleep 3; done\nfi\nif [ \"$old\" != \"\" ] && [ \"$(ver)\" = \"$old\" ]; then\n  svc; say rolledback \"ok=$good crashes=$(($(crashes) - c0))\"; show   # why, in the state line's detail\nelse say broken; fi\nrm -f $D/ok\n";

    public static boolean bad(String str, JSONObject jSONObject) {
        JSONArray optJSONArray = jSONObject.optJSONArray("bad");
        if (optJSONArray != null) {
            Iterable until = MathKt.until(0, optJSONArray.length());
            if (!(until instanceof Collection) || !((Collection) until).isEmpty()) {
                Iterator it = until.iterator();
                while (((IntProgressionIterator) it).hasNext) {
                    if (Intrinsics.areEqual(optJSONArray.optString(((IntProgressionIterator) it).nextInt()), str)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public static String installed(Adb adb) {
        String str;
        Intrinsics.checkNotNullParameter(adb, "adb");
        Pattern compile = Pattern.compile("versionName=(\\S+)");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
        String input = adb.shell(120000L, "dumpsys package dev.tvremote.setup 2>/dev/null | grep -m1 versionName=");
        Intrinsics.checkNotNullParameter(input, "input");
        Matcher matcher = compile.matcher(input);
        Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
        MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, input);
        if (access$findNext != null && (str = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)) != null) {
            return str;
        }
        return "";
    }

    public static void launch(Adb adb, String str) {
        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
        adb.shell(120000L, "mkdir -p /data/local/tmp/tvr-update; rm -f /data/local/tmp/tvr-update/run.sh");
        byte[] bytes = SCRIPT.getBytes(Charsets.UTF_8);
        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        adb.put("/data/local/tmp/tvr-update/run.sh", bytes, false);
        String m = ApkSigner$$ExternalSyntheticOutline0.m("[ \"$(stat -c %s /data/local/tmp/tvr-update/run.sh 2>/dev/null)\" = ", bytes.length, " ]");
        for (int i = 0; i < 50; i++) {
            if (StringsKt.contains(adb.shell(120000L, m + " && echo whole"), "whole", false)) {
                break;
            }
            Thread.sleep(100L);
        }
        ConcurrentHashMap concurrentHashMap2 = Adb.ASKING;
        String q = Mdns.q("/data/local/tmp/tvr-update/new.apk");
        StringBuilder sb = new StringBuilder("rm -f /data/local/tmp/tvr-update/pid; setsid sh /data/local/tmp/tvr-update/run.sh ");
        sb.append(q);
        sb.append(" ");
        sb.append(str);
        sb.append(" ");
        if (!StringsKt.contains(adb.shell(120000L, m + " && { " + Census$$ExternalSyntheticOutline0.m(sb, "-", " </dev/null >/data/local/tmp/tvr-update/log 2>&1 & for i in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20; do [ -s /data/local/tmp/tvr-update/pid ] && break; sleep 0.2; done; [ -s /data/local/tmp/tvr-update/pid ] && echo started") + "; }"), "started", false)) {
            throw new IOException("could not write the update script on the TV (is its storage full?)");
        }
    }

    public static JSONObject parse(String out) {
        long j;
        Object obj;
        Intrinsics.checkNotNullParameter(out, "out");
        List split$default = StringsKt.split$default(out, new String[]{"|"}, 2, 2);
        List split = new Regex("\\s+").split(StringsKt.trim((String) split$default.get(0)).toString(), 5);
        Object obj2 = "";
        JSONObject put = new JSONObject().put("state", "").put("at", 0).put("version", "").put("from", "").put("detail", "");
        if (split.size() >= 4) {
            JSONObject put2 = put.put("state", split.get(0));
            Long longOrNull = StringsKt__StringNumberConversionsKt.toLongOrNull((String) split.get(1));
            if (longOrNull != null) {
                j = longOrNull.longValue();
            } else {
                j = 0;
            }
            JSONObject put3 = put2.put("at", j * 1000).put("version", split.get(2)).put("from", split.get(3));
            if (4 >= split.size()) {
                obj = "";
            } else {
                obj = split.get(4);
            }
            put3.put("detail", obj);
        }
        JSONArray jSONArray = new JSONArray();
        if (1 < split$default.size()) {
            obj2 = split$default.get(1);
        }
        List split2 = new Regex("\\s+").split((CharSequence) obj2, 0);
        ArrayList arrayList = new ArrayList();
        for (Object obj3 : split2) {
            if (VERSION.matches((String) obj3)) {
                arrayList.add(obj3);
            }
        }
        Iterator it = CollectionsKt.distinct(arrayList).iterator();
        while (it.hasNext()) {
            jSONArray.put((String) it.next());
        }
        JSONObject put4 = put.put("bad", jSONArray);
        Intrinsics.checkNotNullExpressionValue(put4, "put(...)");
        return put4;
    }

    public static JSONObject state(Adb adb) {
        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
        return parse(adb.shell(120000L, "cat /data/local/tmp/tvr-update/state 2>/dev/null; echo '|'; cat /data/local/tmp/tvr-update/bad 2>/dev/null"));
    }
}
