package dev.tvremote.core.ontv;

import dev.tvremote.core.B64;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.manage.Manage$$ExternalSyntheticLambda18;
import dev.tvremote.core.ontv.SetupNeed;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.regex.Matcher;
import kotlin.Pair;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Charsets;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsJVMKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public abstract class Dim {
    public static final LinkedHashMap COLORS = MapsKt__MapsKt.linkedMapOf(new Pair("dark", 0), new Pair("amber", 16747038), new Pair("yellow", 16762880), new Pair("sepia", 7356948), new Pair("red", 10092544), new Pair("blue", 1060986));

    public static JSONObject call(Manage$$ExternalSyntheticLambda18 manage$$ExternalSyntheticLambda18, JSONObject jSONObject) {
        int i;
        String concat;
        String optString;
        String str = "";
        if (jSONObject == null) {
            concat = "";
        } else {
            int[] iArr = B64.INDEX;
            String optString2 = jSONObject.optString("color");
            Double d = null;
            if (!COLORS.containsKey(optString2)) {
                optString2 = null;
            }
            if (optString2 == null) {
                optString2 = "dark";
            }
            JSONObject put = new JSONObject().put("on", jSONObject.optBoolean("on")).put("color", optString2);
            Object opt = jSONObject.opt("pct");
            if (opt instanceof Number) {
                d = Double.valueOf(((Number) opt).doubleValue());
            } else if (opt instanceof String) {
                d = StringsKt__StringNumberConversionsJVMKt.toDoubleOrNull(StringsKt.trim((String) opt).toString());
            }
            if (d != null && !Double.isNaN(d.doubleValue())) {
                i = (int) Math.round(MathKt.coerceIn(d.doubleValue(), 5.0d, 90.0d));
            } else {
                i = 40;
            }
            JSONObject put2 = put.put("pct", i);
            Intrinsics.checkNotNullExpressionValue(put2, "put(...)");
            String jSONObject2 = put2.toString();
            Intrinsics.checkNotNullExpressionValue(jSONObject2, "toString(...)");
            byte[] bytes = jSONObject2.getBytes(Charsets.UTF_8);
            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
            concat = " --es d ".concat(B64.encode(bytes));
        }
        if (jSONObject != null && jSONObject.optBoolean("on")) {
            str = "appops set dev.tvremote.setup SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1; ";
        }
        String str2 = (String) manage$$ExternalSyntheticLambda18.invoke(str + "am broadcast --include-stopped-packages -n dev.tvremote.setup/.DimReceiver" + concat + " 2>&1");
        Matcher m7m = Census$$ExternalSyntheticOutline0.m7m("data=\"([A-Za-z0-9+/=]+)\"", "compile(...)", str2, "input", str2);
        Intrinsics.checkNotNullExpressionValue(m7m, "matcher(...)");
        MatcherMatchResult access$findNext = MathKt.access$findNext(m7m, 0, str2);
        if (access$findNext != null) {
            int[] iArr2 = B64.INDEX;
            JSONObject jSONObject3 = new JSONObject(new String(B64.decode((String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)), Charsets.UTF_8));
            if (jSONObject3.has("error")) {
                if (Intrinsics.areEqual(jSONObject3.optString("error"), "overlay")) {
                    optString = "notify:nooverlay";
                } else {
                    optString = jSONObject3.optString("error");
                }
                throw new IOException(optString);
            }
            return jSONObject3;
        }
        throw new SetupNeed.Missing("dim", SetupNeed.have(manage$$ExternalSyntheticLambda18));
    }
}
