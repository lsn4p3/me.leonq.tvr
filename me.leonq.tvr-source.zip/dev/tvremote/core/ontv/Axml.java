package dev.tvremote.core.ontv;

import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Diagnose;
import dev.tvremote.core.ontv.Axml;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$IntRef;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.conscrypt.PSKKeyManager;

/* loaded from: classes.dex */
public abstract class Axml {
    public static final Set CLASS_ELEMENTS = SetsKt.setOf((Object[]) new String[]{"application", "activity", "activity-alias", "service", "receiver", "provider"});
    public static final Set CLASS_ATTRS = SetsKt.setOf((Object[]) new String[]{"targetActivity", "parentActivityName", "backupAgent", "manageSpaceActivity"});
    public static final Set PERM_ATTRS = SetsKt.setOf((Object[]) new String[]{"permission", "readPermission", "writePermission"});
    public static final Set PERM_ELEMENTS = SetsKt.setOf((Object[]) new String[]{"permission", "permission-tree", "permission-group"});

    /* loaded from: classes.dex */
    public final class Pool {
        public final int end;
        public final ArrayList strings;
        public final boolean utf8;

        public Pool(ArrayList arrayList, boolean z, int i) {
            this.strings = arrayList;
            this.utf8 = z;
            this.end = i;
        }
    }

    /* loaded from: classes.dex */
    public final class Unusual extends IOException {
    }

    /* JADX WARN: Type inference failed for: r1v12, types: [dev.tvremote.core.Diagnose$Real, java.lang.Object] */
    public static Diagnose.Real clone(byte[] bArr) {
        Object obj;
        final String oldPkg;
        int i;
        int length;
        final Pool readPool = readPool(bArr);
        ArrayList arrayList = new ArrayList();
        Pool readPool2 = readPool(bArr);
        walk(bArr, readPool2, new Axml$$ExternalSyntheticLambda1(readPool2, bArr, arrayList, 0));
        Iterator it = arrayList.iterator();
        while (true) {
            if (it.hasNext()) {
                obj = it.next();
                Triple triple = (Triple) obj;
                if (Intrinsics.areEqual(triple.first, "manifest") && Intrinsics.areEqual(triple.second, "package")) {
                    break;
                }
            } else {
                obj = null;
                break;
            }
        }
        Triple triple2 = (Triple) obj;
        if (triple2 != null && (oldPkg = (String) triple2.third) != null) {
            final String newPkg = oldPkg.concat(".copy");
            final byte[] copyOf = Arrays.copyOf(bArr, bArr.length);
            Intrinsics.checkNotNullExpressionValue(copyOf, "copyOf(...)");
            final ArrayList arrayList2 = new ArrayList(readPool.strings);
            final HashMap hashMap = new HashMap();
            walk(copyOf, readPool, new Function3() { // from class: dev.tvremote.core.ontv.Axml$$ExternalSyntheticLambda0
                /* JADX WARN: Code restructure failed: missing block: B:47:0x00c9, code lost:
                
                    if (kotlin.jvm.internal.Intrinsics.areEqual(r9, r6) == false) goto L49;
                 */
                @Override // kotlin.jvm.functions.Function3
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                */
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    int i2;
                    String str = (String) obj2;
                    String str2 = (String) obj3;
                    int intValue = ((Integer) obj4).intValue();
                    ArrayList arrayList3 = Axml.Pool.this.strings;
                    Set set = Axml.CLASS_ELEMENTS;
                    byte[] bArr2 = copyOf;
                    if ((bArr2[intValue + 15] & 255) == 3) {
                        i2 = Axml.i32(intValue + 16, bArr2);
                    } else {
                        i2 = -1;
                    }
                    String str3 = (String) CollectionsKt.getOrNull(i2, arrayList3);
                    if (str3 != null) {
                        boolean equals = str.equals("manifest");
                        String str4 = newPkg;
                        if (!equals || !str2.equals("package")) {
                            if (str2.equals("label") && (str.equals("application") || str.equals("activity") || str.equals("activity-alias"))) {
                                str4 = str3.concat(" (2)");
                            } else {
                                boolean equals2 = str2.equals("name");
                                String str5 = oldPkg;
                                if (equals2 && Axml.CLASS_ELEMENTS.contains(str)) {
                                    str4 = Axml.clone$cls(str5, str3);
                                } else if (Axml.CLASS_ATTRS.contains(str2)) {
                                    str4 = Axml.clone$cls(str5, str3);
                                } else if (str.equals("provider") && str2.equals("authorities")) {
                                    str4 = CollectionsKt.joinToString$default(StringsKt.split$default(str3, new char[]{';'}), ";", null, null, new Axml$$ExternalSyntheticLambda2(0, str5, str4), 30);
                                } else if (str2.equals("name") && (Axml.PERM_ELEMENTS.contains(str) || StringsKt__StringsJVMKt.startsWith(str, false, "uses-permission"))) {
                                    str4 = Axml.clone$own(str5, str4, str3);
                                } else {
                                    if (Axml.PERM_ATTRS.contains(str2)) {
                                        str4 = Axml.clone$own(str5, str4, str3);
                                    }
                                    str4 = null;
                                }
                            }
                        }
                        if (str4 != null && !str4.equals(str3)) {
                            HashMap hashMap2 = hashMap;
                            Object obj5 = hashMap2.get(str4);
                            if (obj5 == null) {
                                ArrayList arrayList4 = arrayList2;
                                arrayList4.add(str4);
                                obj5 = Integer.valueOf(arrayList4.size() - 1);
                                hashMap2.put(str4, obj5);
                            }
                            int intValue2 = ((Number) obj5).intValue();
                            int i3 = intValue + 8;
                            for (int i4 = 0; i4 < 4; i4++) {
                                bArr2[i3 + i4] = (byte) (intValue2 >> (i4 * 8));
                            }
                            int i5 = intValue + 16;
                            for (int i6 = 0; i6 < 4; i6++) {
                                bArr2[i5 + i6] = (byte) (intValue2 >> (i6 * 8));
                            }
                        }
                    }
                    return Unit.INSTANCE;
                }
            });
            byte[] copyOfRange = ArraysKt.copyOfRange(copyOf, readPool.end, copyOf.length);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            byte[] array = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putShort((short) 3).putShort((short) 8).putInt(0).array();
            ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
            int size = arrayList2.size();
            int[] iArr = new int[size];
            Iterator it2 = arrayList2.iterator();
            int i2 = 0;
            while (true) {
                boolean hasNext = it2.hasNext();
                boolean z = readPool.utf8;
                if (hasNext) {
                    Object next = it2.next();
                    int i3 = i2 + 1;
                    if (i2 >= 0) {
                        String str = (String) next;
                        iArr[i2] = byteArrayOutputStream2.size();
                        if (z) {
                            byte[] bytes = str.getBytes(Charsets.UTF_8);
                            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                            int length2 = str.length();
                            if (length2 > 127) {
                                byteArrayOutputStream2.write((length2 >> 8) | 128);
                                byteArrayOutputStream2.write(length2 & 255);
                            } else {
                                byteArrayOutputStream2.write(length2);
                            }
                            int length3 = bytes.length;
                            if (length3 > 127) {
                                byteArrayOutputStream2.write((length3 >> 8) | 128);
                                length3 &= 255;
                            }
                            byteArrayOutputStream2.write(length3);
                            byteArrayOutputStream2.write(bytes);
                            byteArrayOutputStream2.write(0);
                        } else {
                            if (str.length() > 32767) {
                                writePool$lambda$7$u16(byteArrayOutputStream2, (str.length() >> 16) | 32768);
                                length = str.length() & 65535;
                            } else {
                                length = str.length();
                            }
                            writePool$lambda$7$u16(byteArrayOutputStream2, length);
                            byte[] bytes2 = str.getBytes(Charsets.UTF_16LE);
                            Intrinsics.checkNotNullExpressionValue(bytes2, "getBytes(...)");
                            byteArrayOutputStream2.write(bytes2);
                            byteArrayOutputStream2.write(0);
                            byteArrayOutputStream2.write(0);
                        }
                        i2 = i3;
                    } else {
                        CollectionsKt__CollectionsKt.throwIndexOverflow();
                        throw null;
                    }
                } else {
                    while (byteArrayOutputStream2.size() % 4 != 0) {
                        byteArrayOutputStream2.write(0);
                    }
                    int size2 = (arrayList2.size() * 4) + 28;
                    int size3 = byteArrayOutputStream2.size() + size2;
                    ByteBuffer order = ByteBuffer.allocate(size3).order(ByteOrder.LITTLE_ENDIAN);
                    ByteBuffer putInt = order.putShort((short) 1).putShort((short) 28).putInt(size3).putInt(arrayList2.size()).putInt(0);
                    if (z) {
                        i = PSKKeyManager.MAX_KEY_LENGTH_BYTES;
                    } else {
                        i = 0;
                    }
                    putInt.putInt(i).putInt(size2).putInt(0);
                    for (int i4 = 0; i4 < size; i4++) {
                        order.putInt(iArr[i4]);
                    }
                    order.put(byteArrayOutputStream2.toByteArray());
                    byte[] array2 = order.array();
                    Intrinsics.checkNotNullExpressionValue(array2, "array(...)");
                    byteArrayOutputStream.write(array);
                    byteArrayOutputStream.write(array2);
                    byteArrayOutputStream.write(copyOfRange);
                    byte[] byteArray = byteArrayOutputStream.toByteArray();
                    ByteBuffer.wrap(byteArray).order(ByteOrder.LITTLE_ENDIAN).putInt(4, byteArray.length);
                    Intrinsics.checkNotNullParameter(oldPkg, "oldPkg");
                    Intrinsics.checkNotNullParameter(newPkg, "newPkg");
                    ?? obj2 = new Object();
                    obj2.link = byteArray;
                    obj2.bindUdp = newPkg;
                    return obj2;
                }
            }
        } else {
            throw new IOException("no package in the manifest");
        }
    }

    public static final String clone$cls(String str, String str2) {
        if (StringsKt__StringsJVMKt.startsWith(str2, false, ".")) {
            return Census$$ExternalSyntheticOutline0.m(str, str2);
        }
        if (!StringsKt.contains$default(str2, '.')) {
            return Census$$ExternalSyntheticOutline0.m(str, ".", str2);
        }
        return null;
    }

    public static final String clone$own(String str, String str2, String str3) {
        if (!Intrinsics.areEqual(str3, str)) {
            if (!StringsKt__StringsJVMKt.startsWith(str3, false, str + ".")) {
                return null;
            }
        }
        String substring = str3.substring(str.length());
        Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
        return Census$$ExternalSyntheticOutline0.m(str2, substring);
    }

    public static int i32(int i, byte[] bArr) {
        return (u16(i + 2, bArr) << 16) | u16(i, bArr);
    }

    /* JADX WARN: Type inference failed for: r8v2, types: [kotlin.jvm.internal.Ref$IntRef, java.lang.Object] */
    public static Pool readPool(byte[] bArr) {
        int i;
        if (bArr.length >= 36) {
            if (u16(0, bArr) == 3) {
                int u16 = u16(2, bArr);
                boolean z = true;
                if (u16(u16, bArr) == 1) {
                    int u162 = u16(u16 + 2, bArr);
                    int i32 = i32(u16 + 4, bArr);
                    int i322 = i32(u16 + 8, bArr);
                    int i323 = i32(u16 + 12, bArr);
                    int i324 = i32(u16 + 16, bArr);
                    int i325 = i32(u16 + 20, bArr);
                    if (i323 == 0) {
                        if (i322 >= 0 && i322 <= 200000 && (i = i32 + u16) <= bArr.length) {
                            if ((i324 & PSKKeyManager.MAX_KEY_LENGTH_BYTES) == 0) {
                                z = false;
                            }
                            ArrayList arrayList = new ArrayList(i322);
                            for (int i2 = 0; i2 < i322; i2++) {
                                ?? obj = new Object();
                                int i326 = i32((i2 * 4) + u16 + u162, bArr) + u16 + i325;
                                obj.element = i326;
                                if (z) {
                                    readPool$len(obj, bArr);
                                    arrayList.add(new String(bArr, obj.element, readPool$len(obj, bArr), Charsets.UTF_8));
                                } else {
                                    int u163 = u16(i326, bArr);
                                    int i3 = obj.element + 2;
                                    obj.element = i3;
                                    if ((32768 & u163) != 0) {
                                        u163 = ((u163 & 32767) << 16) | u16(i3, bArr);
                                        obj.element += 2;
                                    }
                                    arrayList.add(new String(bArr, obj.element, u163 * 2, Charsets.UTF_16LE));
                                }
                            }
                            return new Pool(arrayList, z, i);
                        }
                        throw new IOException("bad string pool");
                    }
                    throw new IOException("styled strings in the manifest");
                }
                throw new IOException("no string pool");
            }
        }
        throw new IOException("not a binary manifest");
    }

    public static final int readPool$len(Ref$IntRef ref$IntRef, byte[] bArr) {
        int i = ref$IntRef.element;
        int i2 = i + 1;
        ref$IntRef.element = i2;
        byte b = bArr[i];
        int i3 = b & 255;
        if ((b & 128) != 0) {
            ref$IntRef.element = i + 2;
            return (bArr[i2] & 255) | ((b & Byte.MAX_VALUE) << 8);
        }
        return i3;
    }

    public static int u16(int i, byte[] bArr) {
        return ((bArr[i + 1] & 255) << 8) | (bArr[i] & 255);
    }

    public static void walk(byte[] bArr, Pool pool, Function3 function3) {
        int i;
        int i2 = pool.end;
        while (i2 + 8 <= bArr.length) {
            int u16 = u16(i2, bArr);
            int i32 = i32(i2 + 4, bArr);
            if (i32 >= 8 && (i = i32 + i2) <= bArr.length) {
                if (u16 == 258) {
                    int i322 = i32(i2 + 20, bArr);
                    ArrayList arrayList = pool.strings;
                    String str = (String) CollectionsKt.getOrNull(i322, arrayList);
                    if (str == null) {
                        str = "";
                    }
                    int u162 = u16(i2 + 24, bArr);
                    int u163 = u16(i2 + 26, bArr);
                    int u164 = u16(i2 + 28, bArr);
                    for (int i3 = 0; i3 < u164; i3++) {
                        int i4 = (i3 * u163) + i2 + 16 + u162;
                        String str2 = (String) CollectionsKt.getOrNull(i32(i4 + 4, bArr), arrayList);
                        if (str2 == null) {
                            str2 = "";
                        }
                        function3.invoke(str, str2, Integer.valueOf(i4));
                    }
                }
                i2 = i;
            } else {
                throw new IOException("bad chunk");
            }
        }
    }

    public static final void writePool$lambda$7$u16(ByteArrayOutputStream byteArrayOutputStream, int i) {
        byteArrayOutputStream.write(i & 255);
        byteArrayOutputStream.write((i >> 8) & 255);
    }
}
