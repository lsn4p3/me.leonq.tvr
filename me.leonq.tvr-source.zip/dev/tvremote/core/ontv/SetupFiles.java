package dev.tvremote.core.ontv;

import dev.tvremote.core.B64;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.ontv.SetupNeed;
import java.io.ByteArrayInputStream;
import java.util.NoSuchElementException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Charsets;
import kotlin.text.LinesIterator;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public abstract class SetupFiles {
    public static final Regex NAME = new Regex("[A-Za-z0-9_][A-Za-z0-9_./-]*");

    /* JADX WARN: Removed duplicated region for block: B:18:0x00d8  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0138 A[ORIG_RETURN, RETURN] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static String read(int i, String name, Function1 function1) {
        Intrinsics.checkNotNullParameter(name, "name");
        if (NAME.matches(name) && !StringsKt.contains(name, "..", false)) {
            String str = (String) function1.invoke("tail -n " + i + " /sdcard/Android/data/dev.tvremote.setup/files/" + name + " 2>&1");
            if (!StringsKt__StringsJVMKt.startsWith(str, false, "tail:")) {
                return str;
            }
            LinesIterator linesIterator = (LinesIterator) StringsKt.lineSequence(str).iterator();
            if (linesIterator.hasNext()) {
                String str2 = "";
                if (!StringsKt.contains((CharSequence) linesIterator.next(), "denied", false)) {
                    return "";
                }
                String str3 = (String) function1.invoke("am broadcast -n dev.tvremote.setup/.RulesReceiver --es get file --es name " + name + " --ei lines " + i + " 2>&1");
                Matcher m7m = Census$$ExternalSyntheticOutline0.m7m("data=\"([A-Za-z0-9+/=]*)\"", "compile(...)", str3, "input", str3);
                Intrinsics.checkNotNullExpressionValue(m7m, "matcher(...)");
                MatcherMatchResult access$findNext = MathKt.access$findNext(m7m, 0, str3);
                String str4 = null;
                if (access$findNext != null) {
                    if (((CharSequence) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)).length() != 0) {
                        try {
                            int[] iArr = B64.INDEX;
                            str2 = new String(MathKt.readBytes(new GZIPInputStream(new ByteArrayInputStream(B64.decode((String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1))))), Charsets.UTF_8);
                        } catch (Exception unused) {
                        }
                    }
                    if (str2 != null) {
                        if (name.equals("stats/power.jsonl")) {
                            Pattern compile = Pattern.compile("data=\"([A-Za-z0-9+/=]+)\"");
                            Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                            CharSequence input = (CharSequence) function1.invoke("am broadcast -n dev.tvremote.setup/.RulesReceiver --es get power 2>&1");
                            Intrinsics.checkNotNullParameter(input, "input");
                            Matcher matcher = compile.matcher(input);
                            Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
                            MatcherMatchResult access$findNext2 = MathKt.access$findNext(matcher, 0, input);
                            if (access$findNext2 != null) {
                                try {
                                    int[] iArr2 = B64.INDEX;
                                    str4 = new JSONObject(new String(B64.decode((String) ((MatcherMatchResult$groupValues$1) access$findNext2.getGroupValues()).get(1)), Charsets.UTF_8)).optString("power");
                                } catch (Exception unused2) {
                                }
                            }
                        }
                        if (str4 != null) {
                            return str4;
                        }
                        throw new SetupNeed.Missing("files", SetupNeed.have(function1));
                    }
                    return str2;
                }
                str2 = null;
                if (str2 != null) {
                }
            } else {
                throw new NoSuchElementException("Sequence is empty.");
            }
        } else {
            throw new IllegalArgumentException("bad name");
        }
    }
}
