package dev.tvremote.core.ontv;

import dev.tvremote.core.B64;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.ontv.SetupNeed;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import kotlin.collections.SetsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Charsets;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.StringsKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public abstract class Welcome {
    public static final Set VIDEO = SetsKt.setOf((Object[]) new String[]{"mp4", "m4v", "webm", "mkv"});
    public static final Set IMAGE = SetsKt.setOf((Object[]) new String[]{"jpg", "jpeg", "png", "webp"});

    public static JSONObject call(Function1 function1, JSONObject jSONObject) {
        String concat;
        String str;
        String str2 = "";
        if (jSONObject == null) {
            concat = "";
        } else {
            int[] iArr = B64.INDEX;
            String jSONObject2 = jSONObject.toString();
            Intrinsics.checkNotNullExpressionValue(jSONObject2, "toString(...)");
            byte[] bytes = jSONObject2.getBytes(Charsets.UTF_8);
            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
            concat = " --es set ".concat(B64.encode(bytes));
        }
        if (jSONObject != null && !Intrinsics.areEqual(jSONObject.optString("do"), "thumb")) {
            str2 = "appops set dev.tvremote.setup SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1; ";
        }
        String str3 = (String) function1.invoke(str2 + "am broadcast --include-stopped-packages -n dev.tvremote.setup/.WelcomeReceiver" + concat + " 2>&1");
        Matcher m7m = Census$$ExternalSyntheticOutline0.m7m("data=\"([A-Za-z0-9+/=]+)\"", "compile(...)", str3, "input", str3);
        Intrinsics.checkNotNullExpressionValue(m7m, "matcher(...)");
        MatcherMatchResult access$findNext = MathKt.access$findNext(m7m, 0, str3);
        if (access$findNext != null) {
            int[] iArr2 = B64.INDEX;
            JSONObject jSONObject3 = new JSONObject(new String(B64.decode((String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)), Charsets.UTF_8));
            if (!jSONObject3.has("error")) {
                if (jSONObject3.optBoolean("wanted") && !jSONObject3.optBoolean("running")) {
                    function1.invoke("for p in dev.tvremote.setup dev.tvremote.home; do pm path $p >/dev/null 2>&1 || continue; dumpsys deviceidle whitelist +$p >/dev/null 2>&1; am set-standby-bucket $p active >/dev/null 2>&1; cmd appops set $p RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1; done; cmd deviceidle whitelist +dev.tvremote.setup >/dev/null 2>&1; am startservice -n dev.tvremote.setup/.RemoteService 2>&1 | grep -q Error && am start-foreground-service -n dev.tvremote.setup/.RemoteService >/dev/null 2>&1");
                }
                return jSONObject3;
            }
            throw new IllegalArgumentException(jSONObject3.optString("error"));
        }
        String have = SetupNeed.have(function1);
        if (have.length() == 0) {
            str = "missing";
        } else if (SetupNeed.ok(have, "welcome")) {
            str = "busy";
        } else {
            str = "old";
        }
        if (jSONObject != null && !str.equals("busy")) {
            throw new SetupNeed.Missing("welcome", have);
        }
        JSONObject put = Census$$ExternalSyntheticOutline0.m10m("setup", str, "have", have).put("min", SetupNeed.MIN.get("welcome"));
        Intrinsics.checkNotNullExpressionValue(put, "put(...)");
        return put;
    }

    public static String ext(String str) {
        if (str == null) {
            str = "";
        }
        String lowerCase = StringsKt.substringAfterLast(str, '.', "").toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        return lowerCase;
    }
}
