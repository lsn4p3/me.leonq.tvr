package dev.tvremote.core.ontv;

import dev.tvremote.core.B64;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.ontv.SetupNeed;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgression;
import kotlin.text.Charsets;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsJVMKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public abstract class Notify {
    public static final List CORNERS = ArraysKt.asList(new String[]{"top-left", "top-right", "bottom-left", "bottom-right"});

    static {
        Intrinsics.checkNotNullExpressionValue(Pattern.compile("[ăơưđĂƠƯĐẠ-ỹ]"), "compile(...)");
        CollectionsKt__CollectionsKt.listOf((Object[]) new Pair[]{new Pair(new IntProgression(1024, 1279, 1), "ru"), new Pair(new IntProgression(880, 1023, 1), "el"), new Pair(new IntProgression(1424, 1535, 1), "he"), new Pair(new IntProgression(1536, 1791, 1), "ar"), new Pair(new IntProgression(3584, 3711, 1), "th"), new Pair(new IntProgression(2304, 2431, 1), "hi"), new Pair(new IntProgression(12352, 12543, 1), "ja"), new Pair(new IntProgression(44032, 55215, 1), "ko"), new Pair(new IntProgression(1328, 1423, 1), "hy"), new Pair(new IntProgression(4256, 4351, 1), "ka")});
    }

    /* JADX WARN: Code restructure failed: missing block: B:18:0x007b, code lost:
    
        if (r4 == null) goto L22;
     */
    /* JADX WARN: Removed duplicated region for block: B:53:0x017a  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x0182  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x0185  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x0188  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static JSONObject clean(JSONObject jSONObject) {
        String str;
        String str2;
        Double d;
        int i;
        boolean contains;
        String str3;
        String str4;
        String obj;
        boolean z = true;
        String optString = jSONObject.optString("title");
        Intrinsics.checkNotNullExpressionValue(optString, "optString(...)");
        String take = StringsKt.take(StringsKt.trim(optString).toString(), 60);
        String optString2 = jSONObject.optString("text");
        Intrinsics.checkNotNullExpressionValue(optString2, "optString(...)");
        String take2 = StringsKt.take(StringsKt.trim(optString2).toString(), 300);
        if (take.length() == 0 && take2.length() == 0) {
            throw new IllegalArgumentException("empty");
        }
        JSONObject m10m = Census$$ExternalSyntheticOutline0.m10m("title", take, "text", take2);
        Object opt = jSONObject.opt("corner");
        String str5 = null;
        if (opt instanceof String) {
            str = (String) opt;
        } else {
            str = null;
        }
        if (str != null && (obj = StringsKt.trim(str).toString()) != null) {
            str2 = obj.toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(str2, "toLowerCase(...)");
            if (!CORNERS.contains(str2)) {
                str2 = null;
            }
        }
        str2 = "top-right";
        JSONObject put = m10m.put("corner", str2);
        Object opt2 = jSONObject.opt("seconds");
        if (opt2 instanceof Number) {
            d = Double.valueOf(((Number) opt2).doubleValue());
        } else if (opt2 instanceof String) {
            d = StringsKt__StringNumberConversionsJVMKt.toDoubleOrNull(StringsKt.trim((String) opt2).toString());
        } else {
            d = null;
        }
        if (d != null && !Double.isNaN(d.doubleValue())) {
            i = (int) Math.round(MathKt.coerceIn(d.doubleValue(), 1.0d, 60.0d));
        } else {
            i = 5;
        }
        JSONObject put2 = put.put("seconds", i);
        Object opt3 = jSONObject.opt("speak");
        if (opt3 instanceof Boolean) {
            contains = ((Boolean) opt3).booleanValue();
        } else if (opt3 instanceof Number) {
            if (((Number) opt3).intValue() == 1) {
                contains = true;
            }
            contains = false;
        } else {
            if (opt3 instanceof String) {
                Set of = SetsKt.setOf((Object[]) new String[]{"true", "1", "on", "yes"});
                String lowerCase = StringsKt.trim((String) opt3).toString().toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                contains = of.contains(lowerCase);
            }
            contains = false;
        }
        if (contains) {
            put2.put("speak", true);
            Object opt4 = jSONObject.opt("lang");
            if (opt4 instanceof String) {
                str3 = (String) opt4;
            } else {
                str3 = null;
            }
            String str6 = "";
            if (str3 == null) {
                str3 = "";
            }
            String lowerCase2 = StringsKt.trim(str3).toString().toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
            Object first = CollectionsKt.first(StringsKt.split$default(lowerCase2, new char[]{'-', '_'}));
            String str7 = (String) first;
            int length = str7.length();
            if (2 <= length && length < 4) {
                for (int i2 = 0; i2 < str7.length(); i2++) {
                    char charAt = str7.charAt(i2);
                    if ('a' <= charAt && charAt < '{') {
                    }
                }
                str4 = (String) first;
                if (str4 != null) {
                    str6 = str4;
                }
                if (str6.length() <= 0) {
                    z = false;
                }
                if (z) {
                    str5 = str6;
                }
                if (str5 != null) {
                    put2.put("lang", str5);
                }
            }
            first = null;
            str4 = (String) first;
            if (str4 != null) {
            }
            if (str6.length() <= 0) {
            }
            if (z) {
            }
            if (str5 != null) {
            }
        }
        Intrinsics.checkNotNull(put2);
        return put2;
    }

    public static JSONObject send(Function1 function1, JSONObject jSONObject) {
        String optString;
        JSONObject clean = clean(jSONObject);
        if (clean.optBoolean("speak")) {
            String have = SetupNeed.have(function1);
            if (!SetupNeed.ok(have, "speak")) {
                throw new SetupNeed.Missing("speak", have);
            }
        }
        int[] iArr = B64.INDEX;
        String jSONObject2 = clean.toString();
        Intrinsics.checkNotNullExpressionValue(jSONObject2, "toString(...)");
        Charset charset = Charsets.UTF_8;
        byte[] bytes = jSONObject2.getBytes(charset);
        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        String str = (String) function1.invoke("appops set dev.tvremote.setup SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1; am broadcast --include-stopped-packages -n dev.tvremote.setup/.NotifyReceiver --es n " + B64.encode(bytes) + " 2>&1");
        Matcher m7m = Census$$ExternalSyntheticOutline0.m7m("data=\"([A-Za-z0-9+/=]+)\"", "compile(...)", str, "input", str);
        Intrinsics.checkNotNullExpressionValue(m7m, "matcher(...)");
        MatcherMatchResult access$findNext = MathKt.access$findNext(m7m, 0, str);
        if (access$findNext != null) {
            JSONObject jSONObject3 = new JSONObject(new String(B64.decode((String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)), charset));
            if (jSONObject3.has("error")) {
                if (Intrinsics.areEqual(jSONObject3.optString("error"), "overlay")) {
                    optString = "notify:nooverlay";
                } else {
                    optString = jSONObject3.optString("error");
                }
                throw new IOException(optString);
            }
            return jSONObject3;
        }
        throw new SetupNeed.Missing("notify", SetupNeed.have(function1));
    }
}
