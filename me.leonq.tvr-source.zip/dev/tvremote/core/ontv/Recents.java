package dev.tvremote.core.ontv;

import dev.tvremote.core.manage.AppsApi$$ExternalSyntheticLambda2;
import java.util.ArrayList;
import java.util.Iterator;
import kotlin.jvm.internal.Intrinsics;
import kotlin.sequences.FilteringSequence$iterator$1;
import kotlin.sequences.SequencesKt;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.StringsKt;

/* loaded from: classes.dex */
public abstract class Recents {
    public static final Regex HEAD = new Regex("\\* Recent #\\d+: Task(?:Record)?\\{\\S+ #(\\d+)([^}]*)\\}");
    public static final Regex TYPE = new Regex("\\btype=(\\w+)");
    public static final Regex AFF = new Regex("\\b[AI]=(?:\\d+:)?([A-Za-z][\\w.]*)");
    public static final Regex COMP = new Regex("^\\s*(?:mActivityComponent|realActivity)=([A-Za-z][\\w.]*)/");
    public static final Regex AGO = new Regex("lastActiveTime=\\d+ \\(inactive for (\\d+)s\\)");
    public static final Regex ROOT = new Regex("\\brootTaskId=(\\d+)");
    public static final Regex EMPTY = new Regex("\\bStackId=-1 sz=0\\b");

    /* loaded from: classes.dex */
    public final class Task {
        public final long ago;
        public final boolean home;
        public final int id;
        public final String pkg;
        public final boolean root;
        public final Boolean running;

        public Task(int i, String str, long j, Boolean bool, boolean z, boolean z2) {
            this.id = i;
            this.pkg = str;
            this.ago = j;
            this.running = bool;
            this.root = z;
            this.home = z2;
        }
    }

    public static void close(AppsApi$$ExternalSyntheticLambda2 appsApi$$ExternalSyntheticLambda2, String str) {
        Iterator it = parse((String) appsApi$$ExternalSyntheticLambda2.invoke("dumpsys activity recents")).iterator();
        while (it.hasNext()) {
            Task task = (Task) it.next();
            if (task.pkg.equals(str) && task.root && !task.home) {
                appsApi$$ExternalSyntheticLambda2.invoke("am stack remove " + task.id);
            }
        }
        appsApi$$ExternalSyntheticLambda2.invoke("am force-stop ".concat(str));
    }

    public static ArrayList parse(String out) {
        String str;
        Object next;
        boolean z;
        boolean z2;
        long j;
        String str2;
        String str3;
        Intrinsics.checkNotNullParameter(out, "out");
        ArrayList arrayList = new ArrayList();
        for (String str4 : new Regex("(?=\\n\\s*\\* Recent #)").split(out, 0)) {
            MatcherMatchResult find = HEAD.find(str4, 0);
            if (find != null) {
                int parseInt = Integer.parseInt((String) ((MatcherMatchResult$groupValues$1) find.getGroupValues()).get(1));
                String str5 = (String) ((MatcherMatchResult$groupValues$1) find.getGroupValues()).get(2);
                MatcherMatchResult find2 = TYPE.find(str5, 0);
                Boolean bool = null;
                if (find2 != null) {
                    str = (String) ((MatcherMatchResult$groupValues$1) find2.getGroupValues()).get(1);
                } else {
                    str = null;
                }
                FilteringSequence$iterator$1 filteringSequence$iterator$1 = new FilteringSequence$iterator$1(SequencesKt.mapNotNull(StringsKt.lineSequence(str4), new Bloat$$ExternalSyntheticLambda1(14)));
                if (!filteringSequence$iterator$1.hasNext()) {
                    next = null;
                } else {
                    next = filteringSequence$iterator$1.next();
                }
                String str6 = (String) next;
                if (str6 == null) {
                    MatcherMatchResult find3 = AFF.find(str5, 0);
                    if (find3 != null) {
                        str6 = (String) ((MatcherMatchResult$groupValues$1) find3.getGroupValues()).get(1);
                    } else {
                        str6 = null;
                    }
                    if (str6 == null) {
                    }
                }
                if (!Intrinsics.areEqual(str, "home") && !StringsKt.contains(str4, "android.intent.category.HOME", false)) {
                    z = false;
                } else {
                    z = true;
                }
                if (str == null || str.equals("standard") || str.equals("undefined") || str.equals("home")) {
                    if (!EMPTY.containsMatchIn(str5)) {
                        if (StringsKt.contains(str4, "mRootProcess=null", false)) {
                            bool = Boolean.FALSE;
                        } else if (StringsKt.contains(str4, "mRootProcess=ProcessRecord", false)) {
                            bool = Boolean.TRUE;
                        }
                        Boolean bool2 = bool;
                        MatcherMatchResult find4 = ROOT.find(str4, 0);
                        if (find4 != null && (str3 = (String) ((MatcherMatchResult$groupValues$1) find4.getGroupValues()).get(1)) != null && Integer.parseInt(str3) == parseInt) {
                            z2 = true;
                        } else {
                            z2 = false;
                        }
                        MatcherMatchResult find5 = AGO.find(str4, 0);
                        if (find5 != null && (str2 = (String) ((MatcherMatchResult$groupValues$1) find5.getGroupValues()).get(1)) != null) {
                            j = Long.parseLong(str2);
                        } else {
                            j = 0;
                        }
                        arrayList.add(new Task(parseInt, str6, j, bool2, z2, z));
                    }
                }
            }
        }
        return arrayList;
    }
}
