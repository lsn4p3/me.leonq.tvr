package dev.tvremote.core.ontv;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.B64;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.update.Release;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.io.LinesSequence;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgressionIterator;
import kotlin.ranges.IntRange;
import kotlin.sequences.ConstrainedOnceSequence;
import kotlin.sequences.Sequence;
import kotlin.text.Charsets;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.RegexOption;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class Channels {
    public static volatile Pair counted;
    public static final OwnApp app = new OwnApp("dev.tvremote.channels", "tv-channels.apk", "channels", "channels:none", "appops set dev.tvremote.channels SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1");
    public static final ConcurrentHashMap cats = new ConcurrentHashMap();
    public static final List CATS = ArraysKt.asList(new String[]{"https://tvremote.pages.dev/channels/categories/", "https://raw.githubusercontent.com/HoangTran0410/tv-remote/main/docs/channels/categories/"});
    public static final Regex STREAM = new Regex("\\.(m3u8|m3u|mpd|mp4|m4v|mkv|webm|ts|mov|mp3|aac|m4a|flac|ogg)$", RegexOption.IGNORE_CASE);

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* loaded from: classes.dex */
    public final class Play {
        public static final /* synthetic */ Play[] $VALUES;
        public static final Play MISSING;
        public static final Play OK;
        public static final Play OLD;

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r3v0, types: [java.lang.Enum, dev.tvremote.core.ontv.Channels$Play] */
        /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Enum, dev.tvremote.core.ontv.Channels$Play] */
        /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Enum, dev.tvremote.core.ontv.Channels$Play] */
        static {
            ?? r3 = new Enum("OK", 0);
            OK = r3;
            ?? r4 = new Enum("OLD", 1);
            OLD = r4;
            ?? r5 = new Enum("MISSING", 2);
            MISSING = r5;
            $VALUES = new Play[]{r3, r4, r5};
        }

        public static Play valueOf(String str) {
            return (Play) Enum.valueOf(Play.class, str);
        }

        public static Play[] values() {
            return (Play[]) $VALUES.clone();
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:23:0x007c, code lost:
    
        if (r5 == null) goto L23;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static LinkedHashMap count$shared_release(Sequence sequence, LinkedHashMap linkedHashMap) {
        String str;
        String str2;
        String obj;
        HashMap hashMap = new HashMap();
        Pattern compile = Pattern.compile("group-title=\"([^\"]*)\"");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        Pattern compile2 = Pattern.compile("tvg-id=\"([^\"@]*)");
        Intrinsics.checkNotNullExpressionValue(compile2, "compile(...)");
        Iterator it = sequence.iterator();
        while (it.hasNext()) {
            String str3 = (String) it.next();
            if (StringsKt__StringsJVMKt.startsWith(str3, false, "#EXTINF")) {
                Matcher matcher = compile.matcher(str3);
                Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
                MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, str3);
                if (access$findNext != null && (str = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)) != null && (str2 = (String) linkedHashMap.get(str)) != null) {
                    Matcher matcher2 = compile2.matcher(str3);
                    Intrinsics.checkNotNullExpressionValue(matcher2, "matcher(...)");
                    MatcherMatchResult access$findNext2 = MathKt.access$findNext(matcher2, 0, str3);
                    if (access$findNext2 != null && (obj = (String) ((MatcherMatchResult$groupValues$1) access$findNext2.getGroupValues()).get(1)) != null) {
                        if (obj.length() == 0) {
                            obj = null;
                        }
                    }
                    obj = StringsKt.trim(StringsKt.substringAfterLast(str3, ',', str3)).toString();
                    Object obj2 = hashMap.get(str2);
                    if (obj2 == null) {
                        obj2 = new HashSet();
                        hashMap.put(str2, obj2);
                    }
                    ((HashSet) obj2).add(obj);
                }
            }
        }
        LinkedHashMap linkedHashMap2 = new LinkedHashMap(MapsKt__MapsKt.mapCapacity(hashMap.size()));
        for (Map.Entry entry : hashMap.entrySet()) {
            linkedHashMap2.put(entry.getKey(), Integer.valueOf(((HashSet) entry.getValue()).size()));
        }
        return linkedHashMap2;
    }

    public static Map counts() {
        Pair pair = counted;
        if (pair != null) {
            long longValue = ((Number) pair.first).longValue();
            Map map = (Map) pair.second;
            if (System.currentTimeMillis() - longValue < 86400000) {
                return map;
            }
        }
        try {
            InputStream fetch = fetch("https://iptv-org.github.io/api/countries.json");
            try {
                byte[] readBytes = MathKt.readBytes(fetch);
                fetch.close();
                JSONArray jSONArray = new JSONArray(new String(readBytes, Charsets.UTF_8));
                IntRange until = MathKt.until(0, jSONArray.length());
                ArrayList arrayList = new ArrayList();
                Iterator it = until.iterator();
                while (((IntProgressionIterator) it).hasNext) {
                    JSONObject optJSONObject = jSONArray.optJSONObject(((IntProgressionIterator) it).nextInt());
                    if (optJSONObject != null) {
                        arrayList.add(optJSONObject);
                    }
                }
                int mapCapacity = MapsKt__MapsKt.mapCapacity(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList));
                if (mapCapacity < 16) {
                    mapCapacity = 16;
                }
                LinkedHashMap linkedHashMap = new LinkedHashMap(mapCapacity);
                Iterator it2 = arrayList.iterator();
                while (it2.hasNext()) {
                    JSONObject jSONObject = (JSONObject) it2.next();
                    String optString = jSONObject.optString("name");
                    String optString2 = jSONObject.optString("code");
                    Intrinsics.checkNotNullExpressionValue(optString2, "optString(...)");
                    String lowerCase = optString2.toLowerCase(Locale.ROOT);
                    Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                    linkedHashMap.put(optString, lowerCase);
                }
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(fetch("https://iptv-org.github.io/iptv/index.country.m3u"), Charsets.UTF_8), 8192);
                try {
                    LinkedHashMap count$shared_release = count$shared_release(new ConstrainedOnceSequence(new LinesSequence(0, bufferedReader)), linkedHashMap);
                    bufferedReader.close();
                    counted = new Pair(Long.valueOf(System.currentTimeMillis()), count$shared_release);
                    return count$shared_release;
                } finally {
                }
            } finally {
            }
        } catch (Exception unused) {
            Pair pair2 = counted;
            if (pair2 != null) {
                return (Map) pair2.second;
            }
            return null;
        }
    }

    public static InputStream fetch(String str) {
        URLConnection openConnection = new URL(str).openConnection();
        Intrinsics.checkNotNull(openConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
        HttpURLConnection httpURLConnection = (HttpURLConnection) openConnection;
        httpURLConnection.setConnectTimeout(10000);
        httpURLConnection.setReadTimeout(30000);
        httpURLConnection.setRequestProperty("User-Agent", "tv-remote");
        if (httpURLConnection.getResponseCode() == 200) {
            InputStream inputStream = httpURLConnection.getInputStream();
            Intrinsics.checkNotNullExpressionValue(inputStream, "run(...)");
            return inputStream;
        }
        throw new IOException(ApkSigner$$ExternalSyntheticOutline0.m("HTTP ", httpURLConnection.getResponseCode()));
    }

    public static JSONObject manage$default(Function1 function1, JSONObject jSONObject, String str, boolean z, boolean z2, JSONObject jSONObject2, int i) {
        String concat;
        String m;
        int i2;
        String str2 = (i & 4) != 0 ? null : str;
        boolean z3 = (i & 8) != 0 ? false : z;
        boolean z4 = (i & 16) != 0 ? false : z2;
        JSONObject jSONObject3 = (i & 32) != 0 ? null : jSONObject2;
        boolean z5 = (i & 64) == 0;
        if (str2 != null) {
            Pattern compile = Pattern.compile("[a-zA-Z]{2}");
            Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
            if (!compile.matcher(str2).matches()) {
                throw new IllegalArgumentException("country");
            }
        }
        String str3 = "";
        if (jSONObject == null) {
            concat = "";
        } else {
            int[] iArr = B64.INDEX;
            String jSONObject4 = jSONObject.toString();
            Intrinsics.checkNotNullExpressionValue(jSONObject4, "toString(...)");
            byte[] bytes = jSONObject4.getBytes(Charsets.UTF_8);
            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
            concat = " --es set ".concat(B64.encode(bytes));
        }
        if (str2 == null) {
            m = "";
        } else {
            m = ApkSigner$$ExternalSyntheticOutline0.m(" --es list ", str2, z3 ? " --ez fresh true" : "");
        }
        String str4 = z4 ? " --ez countries true" : "";
        String str5 = z5 ? " --ez export true" : "";
        if (jSONObject3 != null) {
            int[] iArr2 = B64.INDEX;
            String jSONObject5 = jSONObject3.toString();
            Intrinsics.checkNotNullExpressionValue(jSONObject5, "toString(...)");
            byte[] bytes2 = jSONObject5.getBytes(Charsets.UTF_8);
            Intrinsics.checkNotNullExpressionValue(bytes2, "getBytes(...)");
            String encode = B64.encode(bytes2);
            if (encode.length() > 100000) {
                JSONObject jSONObject6 = new JSONObject(jSONObject3.toString()).getJSONObject("doc");
                JSONArray optJSONArray = jSONObject6.optJSONArray("favourites");
                if (optJSONArray != null) {
                    int length = optJSONArray.length();
                    int i3 = 0;
                    while (i3 < length) {
                        int i4 = length;
                        JSONObject optJSONObject = optJSONArray.optJSONObject(i3);
                        if (optJSONObject != null) {
                            optJSONObject.remove("url");
                        }
                        i3++;
                        length = i4;
                    }
                }
                JSONArray optJSONArray2 = jSONObject6.optJSONArray("groups");
                if (optJSONArray2 != null) {
                    int length2 = optJSONArray2.length();
                    int i5 = 0;
                    while (i5 < length2) {
                        int i6 = length2;
                        JSONObject optJSONObject2 = optJSONArray2.optJSONObject(i5);
                        JSONArray optJSONArray3 = optJSONObject2 != null ? optJSONObject2.optJSONArray("channels") : null;
                        JSONArray jSONArray = optJSONArray2;
                        if (optJSONArray3 != null) {
                            int length3 = optJSONArray3.length();
                            i2 = i5;
                            int i7 = 0;
                            while (i7 < length3) {
                                int i8 = length3;
                                JSONObject optJSONObject3 = optJSONArray3.optJSONObject(i7);
                                if (optJSONObject3 != null) {
                                    optJSONObject3.remove("url");
                                }
                                i7++;
                                length3 = i8;
                            }
                        } else {
                            i2 = i5;
                        }
                        i5 = i2 + 1;
                        length2 = i6;
                        optJSONArray2 = jSONArray;
                    }
                }
                int[] iArr3 = B64.INDEX;
                String jSONObject7 = new JSONObject().put("mode", jSONObject3.optString("mode")).put("doc", jSONObject6).toString();
                Intrinsics.checkNotNullExpressionValue(jSONObject7, "toString(...)");
                byte[] bytes3 = jSONObject7.getBytes(Charsets.UTF_8);
                Intrinsics.checkNotNullExpressionValue(bytes3, "getBytes(...)");
                encode = B64.encode(bytes3);
            }
            if (encode.length() <= 100000) {
                str3 = " --es import ".concat(encode);
            } else {
                throw new IllegalArgumentException("channels:file_big");
            }
        }
        String str6 = (String) function1.invoke("appops set dev.tvremote.channels SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1; am broadcast --include-stopped-packages -n dev.tvremote.channels/.ChannelsReceiver" + (concat + m + str4 + str5 + str3) + " 2>&1");
        Matcher m7m = Census$$ExternalSyntheticOutline0.m7m("data=\"([A-Za-z0-9+/=]+)\"", "compile(...)", str6, "input", str6);
        Intrinsics.checkNotNullExpressionValue(m7m, "matcher(...)");
        MatcherMatchResult access$findNext = MathKt.access$findNext(m7m, 0, str6);
        OwnApp ownApp = app;
        if (access$findNext == null) {
            JSONObject put = ownApp.state(function1).put("receiver", false);
            Intrinsics.checkNotNullExpressionValue(put, "put(...)");
            return put;
        }
        int[] iArr4 = B64.INDEX;
        JSONObject jSONObject8 = new JSONObject(new String(B64.decode((String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)), Charsets.UTF_8));
        if (!jSONObject8.has("error")) {
            jSONObject8.put("installed", true).put("receiver", true);
            JSONObject optJSONObject4 = jSONObject8.optJSONObject("list");
            if (optJSONObject4 != null) {
                String optString = optJSONObject4.optString("path");
                Intrinsics.checkNotNull(optString);
                Pattern compile2 = Pattern.compile("/[A-Za-z0-9_./-]+\\.json");
                Intrinsics.checkNotNullExpressionValue(compile2, "compile(...)");
                if (compile2.matcher(optString).matches()) {
                    String obj = StringsKt.trim((String) function1.invoke("cat ".concat(optString))).toString();
                    if (obj.length() == 0) {
                        obj = "[]";
                    }
                    optJSONObject4.put("channels", new JSONArray(obj)).remove("path");
                }
            }
            String optString2 = jSONObject8.optString("version");
            Intrinsics.checkNotNullExpressionValue(optString2, "optString(...)");
            ownApp.getClass();
            Release release = ownApp.look(optString2).release;
            if (release != null) {
                jSONObject8.put("latest", release.version);
            }
            return jSONObject8;
        }
        throw new IOException(jSONObject8.optString("error"));
    }

    public static boolean open(String words, Function1 function1) {
        Intrinsics.checkNotNullParameter(words, "words");
        String str = "tvchannels://find/";
        if (!StringsKt.isBlank(words)) {
            String encode = URLEncoder.encode(StringsKt.take(StringsKt.trim(words).toString(), 80), "UTF-8");
            Intrinsics.checkNotNullExpressionValue(encode, "encode(...)");
            str = "tvchannels://find/".concat(StringsKt__StringsJVMKt.replace$default(encode, "+", "%20"));
        }
        String str2 = (String) function1.invoke("appops set dev.tvremote.channels SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1; am start -a android.intent.action.VIEW -d '" + str + "' dev.tvremote.channels 2>&1");
        if (StringsKt.contains(str2, "Error", false) || StringsKt.contains(str2, "unable to resolve", true)) {
            return false;
        }
        return true;
    }

    public static Play playResult(String url, Function1 function1) {
        Intrinsics.checkNotNullParameter(url, "url");
        if (validStream(StringsKt.trim(url).toString())) {
            String url2 = StringsKt.trim(url).toString();
            Intrinsics.checkNotNullParameter(url2, "url");
            String encode = URLEncoder.encode(url2, "UTF-8");
            Intrinsics.checkNotNullExpressionValue(encode, "encode(...)");
            String out = (String) function1.invoke("am start -a android.intent.action.VIEW -d '" + "tvchannels://url?u=".concat(StringsKt__StringsJVMKt.replace$default(encode, "+", "%20")) + "' dev.tvremote.channels 2>&1");
            Intrinsics.checkNotNullParameter(out, "out");
            if (!StringsKt.contains(out, "Error", false) && !StringsKt.contains(out, "unable to resolve", true)) {
                return Play.OK;
            }
            if (StringsKt.contains((CharSequence) function1.invoke("pm path dev.tvremote.channels"), "package:", false)) {
                return Play.OLD;
            }
            return Play.MISSING;
        }
        throw new IllegalArgumentException("channels:bad_link");
    }

    /* JADX WARN: Code restructure failed: missing block: B:22:0x004a, code lost:
    
        if (r4.length() == 0) goto L22;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static boolean validStream(String u) {
        Intrinsics.checkNotNullParameter(u, "u");
        boolean z = false;
        if (u.length() <= 500) {
            int i = 0;
            while (true) {
                if (i < u.length()) {
                    char charAt = u.charAt(i);
                    if (MathKt.isWhitespace(charAt) || Character.isISOControl(charAt)) {
                        break;
                    }
                    i++;
                } else if (StringsKt__StringsJVMKt.startsWith(u, true, "http://") || StringsKt__StringsJVMKt.startsWith(u, true, "https://")) {
                    try {
                        String host = new URI(u).getHost();
                        if (host != null) {
                        }
                        z = true;
                        return !z;
                    } catch (Exception unused) {
                    }
                }
            }
        }
        return false;
    }
}
