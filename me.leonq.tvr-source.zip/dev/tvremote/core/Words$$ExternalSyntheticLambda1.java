package dev.tvremote.core;

import android.net.Network;
import android.os.Build;
import dev.tvremote.core.Census;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.ontv.LauncherInstall;
import dev.tvremote.core.ontv.Setup;
import dev.tvremote.core.scenes.Phrases;
import dev.tvremote.core.scenes.RemoteSpec$Entry;
import dev.tvremote.core.web.WebPage;
import dev.tvremote.phone.PhoneApp;
import dev.tvremote.phone.ir.IrRemoteKt$$ExternalSyntheticLambda22;
import dev.tvremote.phone.manage.Managing$$ExternalSyntheticLambda2;
import dev.tvremote.phone.picker.Part;
import dev.tvremote.phone.picture.Air;
import dev.tvremote.phone.picture.DrawingKt$$ExternalSyntheticLambda0;
import dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda16;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.collections.AbstractList;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgressionIterator;
import kotlin.ranges.IntRange;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.conscrypt.FileClientSessionCache;
import org.conscrypt.metrics.ConscryptStatsLog;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class Words$$ExternalSyntheticLambda1 implements Function1 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;

    public /* synthetic */ Words$$ExternalSyntheticLambda1(int i, Object obj) {
        this.$r8$classId = i;
        this.f$0 = obj;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        Object obj2;
        JSONObject optJSONObject;
        int i;
        int i2;
        Network network;
        Object obj3 = null;
        String str = null;
        MatcherMatchResult matcherMatchResult = null;
        int i3 = 1;
        Object obj4 = this.f$0;
        switch (this.$r8$classId) {
            case 0:
                MatcherMatchResult r = (MatcherMatchResult) obj;
                Intrinsics.checkNotNullParameter(r, "r");
                Map map = (Map) obj4;
                if (map.containsKey(((MatcherMatchResult$groupValues$1) r.getGroupValues()).get(1))) {
                    return String.valueOf(map.get(((MatcherMatchResult$groupValues$1) r.getGroupValues()).get(1)));
                }
                return r.getValue();
            case 1:
                Adb.Stream it = (Adb.Stream) obj;
                Intrinsics.checkNotNullParameter(it, "it");
                it.write((byte[]) obj4);
                return Unit.INSTANCE;
            case 2:
                int intValue = ((Integer) obj).intValue();
                if (intValue >= 0) {
                    List list = (List) obj4;
                    if (intValue < list.size()) {
                        obj2 = list.get(intValue);
                        return (String) obj2;
                    }
                }
                obj2 = "";
                return (String) obj2;
            case 3:
                Integer num = (Integer) obj;
                num.getClass();
                List split$default = StringsKt.split$default((CharSequence) ((Words$$ExternalSyntheticLambda1) obj4).invoke(num), new String[]{"\n"}, 0, 6);
                ArrayList arrayList = new ArrayList();
                for (Object obj5 : split$default) {
                    if (StringsKt__StringsJVMKt.startsWith((String) obj5, false, "package:")) {
                        arrayList.add(obj5);
                    }
                }
                ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList));
                Iterator it2 = arrayList.iterator();
                while (it2.hasNext()) {
                    String substring = ((String) it2.next()).substring(8);
                    Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
                    arrayList2.add(StringsKt.trim(substring).toString());
                }
                return CollectionsKt.sorted(arrayList2);
            case 4:
                String it3 = (String) obj;
                Intrinsics.checkNotNullParameter(it3, "it");
                Adb adb = ((LauncherInstall) obj4).adb;
                ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                return adb.shell(120000L, it3);
            case 5:
                ((LauncherInstall.Progress) obj4).at("download", (((Integer) obj).intValue() * 6) / 10);
                return Unit.INSTANCE;
            case 6:
                Adb.Stream s = (Adb.Stream) obj;
                Intrinsics.checkNotNullParameter(s, "s");
                FileInputStream fileInputStream = new FileInputStream((File) obj4);
                try {
                    byte[] bArr = new byte[65536];
                    while (true) {
                        int read = fileInputStream.read(bArr);
                        if (read > 0) {
                            s.write(read, bArr);
                        } else {
                            fileInputStream.close();
                            return Unit.INSTANCE;
                        }
                    }
                } catch (Throwable th) {
                    try {
                        throw th;
                    } catch (Throwable th2) {
                        MathKt.closeFinally(fileInputStream, th);
                        throw th2;
                    }
                }
            case 7:
                String it4 = (String) obj;
                Intrinsics.checkNotNullParameter(it4, "it");
                Adb adb2 = ((Setup) obj4).getAdb();
                Intrinsics.checkNotNull(adb2);
                return adb2.shell(600000L, it4);
            case 8:
                JSONObject m = (JSONObject) obj;
                Intrinsics.checkNotNullParameter(m, "m");
                if (!Intrinsics.areEqual(m.optString("type"), "error") && (optJSONObject = m.optJSONObject("payload")) != null && optJSONObject.optBoolean("returnValue", true)) {
                    ((Function1) obj4).invoke(optJSONObject);
                }
                return Unit.INSTANCE;
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                String string = ((Phrases) obj4).o.getJSONArray("channel_names").getString(((Integer) obj).intValue());
                Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                return string;
            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                String id = (String) obj;
                Intrinsics.checkNotNullParameter(id, "id");
                JSONArray jSONArray = (JSONArray) ((Managing$$ExternalSyntheticLambda2) ((Census.Ok) obj4).adb).invoke();
                IntRange until = MathKt.until(0, jSONArray.length());
                ArrayList arrayList3 = new ArrayList();
                Iterator it5 = until.iterator();
                while (((IntProgressionIterator) it5).hasNext) {
                    JSONObject optJSONObject2 = jSONArray.optJSONObject(((IntProgressionIterator) it5).nextInt());
                    if (optJSONObject2 != null) {
                        arrayList3.add(optJSONObject2);
                    }
                }
                Iterator it6 = arrayList3.iterator();
                while (true) {
                    if (it6.hasNext()) {
                        Object next = it6.next();
                        if (Intrinsics.areEqual(((JSONObject) next).optString("id"), id)) {
                            obj3 = next;
                        }
                    }
                }
                return (JSONObject) obj3;
            case 11:
                MatcherMatchResult it7 = (MatcherMatchResult) obj;
                Intrinsics.checkNotNullParameter(it7, "it");
                return ((MatcherMatchResult$groupValues$1) it7.getGroupValues()).get(1) + "?v=" + ((WebPage) obj4).stamp + "\"";
            case FileClientSessionCache.MAX_SIZE /* 12 */:
                PhoneApp phoneApp = (PhoneApp) obj4;
                String name = (String) obj;
                int i4 = PhoneApp.$r8$clinit;
                Intrinsics.checkNotNullParameter(name, "name");
                try {
                    return phoneApp.getAssets().open(name);
                } catch (IOException unused) {
                    return null;
                }
            case 13:
                String it8 = (String) obj;
                Intrinsics.checkNotNullParameter(it8, "it");
                return Boolean.valueOf(!((Set) obj4).contains(it8));
            case 14:
                String it9 = (String) obj;
                Intrinsics.checkNotNullParameter(it9, "it");
                Pattern compile = Pattern.compile("checkout (clear|volume|web|home)(?: (\\d+)/(\\d+))?");
                Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                Matcher matcher = compile.matcher(it9);
                Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
                if (matcher.matches()) {
                    matcherMatchResult = new MatcherMatchResult(matcher, it9);
                }
                if (matcherMatchResult != null) {
                    String str2 = (String) ((MatcherMatchResult$groupValues$1) matcherMatchResult.getGroupValues()).get(1);
                    int hashCode = str2.hashCode();
                    if (hashCode != -810883302) {
                        if (hashCode != 117588) {
                            if (hashCode == 94746189 && str2.equals("clear")) {
                                Integer intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull((String) ((MatcherMatchResult$groupValues$1) matcherMatchResult.getGroupValues()).get(2));
                                if (intOrNull != null) {
                                    i = intOrNull.intValue();
                                } else {
                                    i = 0;
                                }
                                Pair pair = new Pair("i", Integer.valueOf(i));
                                Integer intOrNull2 = StringsKt__StringNumberConversionsKt.toIntOrNull((String) ((MatcherMatchResult$groupValues$1) matcherMatchResult.getGroupValues()).get(3));
                                if (intOrNull2 != null) {
                                    i2 = intOrNull2.intValue();
                                } else {
                                    i2 = 0;
                                }
                                it9 = Fleet.T("fleet.co_step_clear", pair, new Pair("n", Integer.valueOf(i2)));
                            }
                            it9 = Fleet.T("fleet.co_step_home", new Pair[0]);
                        } else {
                            if (str2.equals("web")) {
                                it9 = Fleet.T("fleet.co_step_web", new Pair[0]);
                            }
                            it9 = Fleet.T("fleet.co_step_home", new Pair[0]);
                        }
                    } else {
                        if (str2.equals("volume")) {
                            it9 = Fleet.T("fleet.co_step_volume", new Pair[0]);
                        }
                        it9 = Fleet.T("fleet.co_step_home", new Pair[0]);
                    }
                }
                ((Part) obj4).setStep(it9);
                return Unit.INSTANCE;
            case 15:
                InetAddress inetAddress = (InetAddress) obj;
                if (inetAddress != null) {
                    str = inetAddress.getHostAddress();
                }
                if (str != null && (inetAddress instanceof Inet4Address) && ((Inet4Address) inetAddress).isSiteLocalAddress()) {
                    String substring2 = str.substring(0, StringsKt.lastIndexOf$default(str, '.', 6) + 1);
                    Intrinsics.checkNotNullExpressionValue(substring2, "substring(...)");
                    ArrayList arrayList4 = (ArrayList) obj4;
                    if (!arrayList4.contains(substring2)) {
                        arrayList4.add(substring2);
                    }
                }
                return Unit.INSTANCE;
            case 16:
                String ip = (String) obj;
                Intrinsics.checkNotNullParameter(ip, "ip");
                new Thread(new DrawingKt$$ExternalSyntheticLambda0(i3, (IrRemoteKt$$ExternalSyntheticLambda22) obj4, ip)).start();
                return Unit.INSTANCE;
            case 17:
                DatagramSocket so = (DatagramSocket) obj;
                Intrinsics.checkNotNullParameter(so, "so");
                if (Build.VERSION.SDK_INT >= 22 && (network = (Network) obj4) != null) {
                    network.bindSocket(so);
                }
                return Unit.INSTANCE;
            case 18:
                Pair it10 = (Pair) obj;
                Intrinsics.checkNotNullParameter(it10, "it");
                return Boolean.valueOf(Intrinsics.areEqual(((RemoteSpec$Entry) it10.second).id, ((RemoteSpec$Entry) obj4).id));
            case 19:
                String m2 = (String) obj;
                Intrinsics.checkNotNullParameter(m2, "m");
                if (m2.equals(Air.mode)) {
                    m2 = "arrows";
                }
                ((RemoteScreenKt$$ExternalSyntheticLambda16) obj4).invoke(m2, Boolean.TRUE);
                return Unit.INSTANCE;
            default:
                if (obj == ((AbstractList) obj4)) {
                    return "(this Collection)";
                }
                return String.valueOf(obj);
        }
    }
}
