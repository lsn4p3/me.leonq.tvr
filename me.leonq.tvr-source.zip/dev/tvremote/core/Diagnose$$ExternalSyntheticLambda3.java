package dev.tvremote.core;

import dev.tvremote.core.Diagnose;
import dev.tvremote.core.adb.Mdns;
import dev.tvremote.core.remote.Ssdp;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.regex.Pattern;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.CollectionsKt__MutableCollectionsKt;
import kotlin.collections.EmptyList;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;

/* loaded from: classes.dex */
public final /* synthetic */ class Diagnose$$ExternalSyntheticLambda3 implements Callable {
    public final /* synthetic */ int $r8$classId = 0;
    public final /* synthetic */ Object f$1;

    public /* synthetic */ Diagnose$$ExternalSyntheticLambda3(Diagnose.Real real, String str) {
        this.f$1 = str;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r3v18, types: [java.util.AbstractCollection, java.util.ArrayList] */
    /* JADX WARN: Type inference failed for: r3v2 */
    /* JADX WARN: Type inference failed for: r3v3, types: [java.lang.Iterable] */
    @Override // java.util.concurrent.Callable
    public final Object call() {
        ?? r3;
        List list;
        switch (this.$r8$classId) {
            case 0:
                List<NetworkInterface> list2 = EmptyList.INSTANCE;
                String host = (String) this.f$1;
                Intrinsics.checkNotNullParameter(host, "host");
                Regex regex = Diagnose.OTHER_BRANDS;
                try {
                    Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
                    Intrinsics.checkNotNullExpressionValue(networkInterfaces, "getNetworkInterfaces(...)");
                    ArrayList list3 = Collections.list(networkInterfaces);
                    Intrinsics.checkNotNullExpressionValue(list3, "list(...)");
                    ArrayList arrayList = new ArrayList();
                    for (Object obj : list3) {
                        NetworkInterface networkInterface = (NetworkInterface) obj;
                        try {
                            if (networkInterface.isUp() && !networkInterface.isLoopback()) {
                                Regex regex2 = Diagnose.NOT_LAN;
                                String name = networkInterface.getName();
                                Intrinsics.checkNotNullExpressionValue(name, "getName(...)");
                                if (!regex2.containsMatchIn(name)) {
                                    arrayList.add(obj);
                                }
                            }
                        } catch (Exception unused) {
                        }
                    }
                    r3 = new ArrayList();
                    Iterator it = arrayList.iterator();
                    while (it.hasNext()) {
                        List<InterfaceAddress> interfaceAddresses = ((NetworkInterface) it.next()).getInterfaceAddresses();
                        Intrinsics.checkNotNullExpressionValue(interfaceAddresses, "getInterfaceAddresses(...)");
                        ArrayList arrayList2 = new ArrayList();
                        for (Object obj2 : interfaceAddresses) {
                            if (((InterfaceAddress) obj2).getAddress() instanceof Inet4Address) {
                                arrayList2.add(obj2);
                            }
                        }
                        ArrayList arrayList3 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList2));
                        Iterator it2 = arrayList2.iterator();
                        while (it2.hasNext()) {
                            InterfaceAddress interfaceAddress = (InterfaceAddress) it2.next();
                            InetAddress address = interfaceAddress.getAddress();
                            Intrinsics.checkNotNullExpressionValue(address, "getAddress(...)");
                            arrayList3.add(new Diagnose.Local(address, interfaceAddress.getNetworkPrefixLength()));
                        }
                        CollectionsKt__MutableCollectionsKt.addAll(arrayList3, r3);
                    }
                } catch (Exception unused2) {
                    r3 = list2;
                }
                Pattern compile = Pattern.compile("\\d{1,3}(\\.\\d{1,3}){3}");
                Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                boolean matches = compile.matcher(host).matches();
                Diagnose.Net net = Diagnose.Net.NA;
                if (matches) {
                    try {
                        InetAddress byName = InetAddress.getByName(host);
                        if ((byName instanceof Inet4Address) && !((Inet4Address) byName).isLoopbackAddress()) {
                            boolean tailnet = Diagnose.tailnet(byName);
                            Diagnose.Net net2 = Diagnose.Net.OK;
                            if (tailnet) {
                                Enumeration<NetworkInterface> networkInterfaces2 = NetworkInterface.getNetworkInterfaces();
                                if (networkInterfaces2 != null) {
                                    list = Collections.list(networkInterfaces2);
                                    Intrinsics.checkNotNullExpressionValue(list, "list(...)");
                                } else {
                                    list = null;
                                }
                                if (list != null) {
                                    list2 = list;
                                }
                                if (!list2.isEmpty()) {
                                    for (NetworkInterface networkInterface2 : list2) {
                                        try {
                                            if (networkInterface2.isUp()) {
                                                Enumeration<InetAddress> inetAddresses = networkInterface2.getInetAddresses();
                                                Intrinsics.checkNotNullExpressionValue(inetAddresses, "getInetAddresses(...)");
                                                ArrayList<InetAddress> list4 = Collections.list(inetAddresses);
                                                Intrinsics.checkNotNullExpressionValue(list4, "list(...)");
                                                if (!list4.isEmpty()) {
                                                    for (InetAddress inetAddress : list4) {
                                                        if (!(inetAddress instanceof Inet4Address) || !Diagnose.tailnet(inetAddress)) {
                                                        }
                                                    }
                                                }
                                            } else {
                                                continue;
                                            }
                                        } catch (Exception unused3) {
                                        }
                                    }
                                }
                                return Diagnose.Net.TAILSCALE_OFF;
                            }
                            Function0 function0 = Lan.wifi;
                            if (Lan.home(host) != null) {
                                ArrayList arrayList4 = new ArrayList();
                                for (Object obj3 : r3) {
                                    Diagnose.Local local = (Diagnose.Local) obj3;
                                    Function0 function02 = Lan.wifi;
                                    String hostAddress = local.ip.getHostAddress();
                                    if (hostAddress == null) {
                                        hostAddress = "";
                                    }
                                    if (Lan.home(hostAddress) != null && !Diagnose.tailnet(local.ip)) {
                                        arrayList4.add(obj3);
                                    }
                                }
                                if (arrayList4.isEmpty()) {
                                    return Diagnose.Net.NONE;
                                }
                                if (!arrayList4.isEmpty()) {
                                    Iterator it3 = arrayList4.iterator();
                                    while (it3.hasNext()) {
                                        Diagnose.Local local2 = (Diagnose.Local) it3.next();
                                        Function0 function03 = Lan.wifi;
                                        if (Lan.inSubnet(byName, local2.ip, local2.prefix)) {
                                        }
                                    }
                                }
                            } else {
                                return net;
                            }
                            return net2;
                        }
                        return net;
                    } catch (Exception unused4) {
                        return net;
                    }
                }
                return Diagnose.Net.OTHER;
            default:
                Mdns.Service service = (Mdns.Service) this.f$1;
                String str = service.ip;
                String castName$default = Ssdp.castName$default(str);
                if (castName$default.length() == 0) {
                    castName$default = service.name;
                }
                return new Diagnose.Found(str, castName$default);
        }
    }

    public /* synthetic */ Diagnose$$ExternalSyntheticLambda3(Mdns.Service service) {
        this.f$1 = service;
    }
}
