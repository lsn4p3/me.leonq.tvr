package dev.tvremote.core.remote;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticLambda6;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.WireLog;
import dev.tvremote.core.Words;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.Adb$$ExternalSyntheticLambda0;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.adb.AdbTls;
import dev.tvremote.core.ontv.Axml$$ExternalSyntheticLambda2;
import dev.tvremote.core.ontv.Home;
import dev.tvremote.core.ontv.Launchers;
import dev.tvremote.core.ontv.RemoteLabels;
import dev.tvremote.core.ontv.RulesClient;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.scenes.Scenes;
import dev.tvremote.core.scenes.Voice;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda5;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda7;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda9;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda10;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda15;
import dev.tvremote.phone.ir.IrHear;
import dev.tvremote.phone.ir.IrLearn;
import dev.tvremote.phone.ir.IrProfile;
import dev.tvremote.phone.ir.IrRemoteKt;
import dev.tvremote.phone.ir.IrRemoteKt$$ExternalSyntheticLambda25;
import dev.tvremote.phone.ir.IrState;
import dev.tvremote.phone.manage.Managing;
import dev.tvremote.phone.media.MediaKt$$ExternalSyntheticLambda15;
import dev.tvremote.phone.media.MediaKt$$ExternalSyntheticLambda4;
import dev.tvremote.phone.media.TalkKt$$ExternalSyntheticLambda1;
import dev.tvremote.phone.media.TalkKt$$ExternalSyntheticLambda2;
import dev.tvremote.phone.media.TalkKt$$ExternalSyntheticLambda4;
import dev.tvremote.phone.picker.AdbHelpKt;
import dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda63;
import dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda67;
import dev.tvremote.phone.picker.AppRow;
import dev.tvremote.phone.picker.ManyTvsKt;
import dev.tvremote.phone.picture.Air;
import dev.tvremote.phone.picture.AirFx;
import dev.tvremote.phone.remote.KeysOnlyKt$$ExternalSyntheticLambda3;
import dev.tvremote.phone.remote.RescuingKt$$ExternalSyntheticLambda2;
import dev.tvremote.phone.remote.TypingKt;
import dev.tvremote.phone.ui.DlApp;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.phone.ui.UiKt;
import dev.tvremote.phone.ui.UiKt$$ExternalSyntheticLambda8;
import dev.tvremote.tvapps.ApkCert$$ExternalSyntheticLambda0;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.EmptyList;
import kotlin.collections.EmptyMap;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$BooleanRef;
import kotlin.jvm.internal.Ref$ObjectRef;
import kotlin.math.MathKt;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.conscrypt.FileClientSessionCache;
import org.conscrypt.metrics.ConscryptStatsLog;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class Vidaa$$ExternalSyntheticLambda3 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;
    public final /* synthetic */ Object f$1;
    public final /* synthetic */ Object f$2;
    public final /* synthetic */ Object f$3;

    public /* synthetic */ Vidaa$$ExternalSyntheticLambda3(MainActivity mainActivity, Ref$ObjectRef ref$ObjectRef, String str, String str2) {
        this.$r8$classId = 3;
        this.f$0 = mainActivity;
        this.f$3 = ref$ObjectRef;
        this.f$1 = str;
        this.f$2 = str2;
    }

    private final void run$dev$tvremote$phone$picker$AdbHelpKt$$ExternalSyntheticLambda24() {
        Remote remote = (Remote) this.f$0;
        Ref$BooleanRef ref$BooleanRef = (Ref$BooleanRef) this.f$1;
        MainActivity mainActivity = (MainActivity) this.f$2;
        AtomicBoolean atomicBoolean = mainActivity.tvBusy;
        try {
            remote.launch("https://github.com/hoangtran0410/tv-remote/releases/latest/download/tv-setup.apk");
            for (int i = 0; i < 3; i++) {
                Thread.sleep(1500L);
                if (!Intrinsics.areEqual(remote.getApp(), "android") || ref$BooleanRef.element) {
                    break;
                }
                remote.pulse(23, 110L);
            }
        } catch (Exception unused) {
        } catch (Throwable th) {
            atomicBoolean.set(false);
            throw th;
        }
        atomicBoolean.set(false);
        mainActivity.ui.post(new Adb$$ExternalSyntheticLambda0(10, (Popup) this.f$3));
    }

    private final void run$dev$tvremote$phone$picker$AdbHelpKt$$ExternalSyntheticLambda37() {
        Popup popup = (Popup) this.f$0;
        if (popup.isShowing()) {
            popup.dismiss();
        }
        if (!((Ref$BooleanRef) this.f$1).element) {
            MainActivity mainActivity = (MainActivity) this.f$2;
            if (!mainActivity.isFinishing()) {
                Popup.Builder builder = new Popup.Builder(mainActivity);
                DlApp dlApp = (DlApp) this.f$3;
                builder.title = Fleet.T((String) dlApp.title, new Pair[0]);
                builder.message = Fleet.T("setup.moved", new Pair[0]);
                builder.setPositiveButton(Fleet.T("core.try_again", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda67(mainActivity, dlApp, 0));
                builder.setNeutralButton(Fleet.T("adb_help.step_by_step", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda67(mainActivity, dlApp, 1));
                builder.setNegativeButton(Fleet.T("common.close", new Pair[0]), null);
                builder.show();
            }
        }
    }

    /* JADX WARN: Type inference failed for: r4v8, types: [kotlin.jvm.internal.Ref$IntRef, java.lang.Object] */
    private final void run$dev$tvremote$phone$picker$AdbHelpKt$$ExternalSyntheticLambda38() {
        int i = 1;
        int i2 = 0;
        MainActivity mainActivity = (MainActivity) this.f$0;
        String str = (String) this.f$1;
        MatcherMatchResult matcherMatchResult = (MatcherMatchResult) this.f$3;
        String str2 = (String) this.f$2;
        try {
            AdbTls adbTls = AdbTls.INSTANCE;
            File filesDir = mainActivity.getFilesDir();
            Intrinsics.checkNotNullExpressionValue(filesDir, "getFilesDir(...)");
            AdbTls.pair(new Adb(filesDir), str, Integer.parseInt((String) ((MatcherMatchResult$groupValues$1) matcherMatchResult.getGroupValues()).get(2)), str2);
            ?? obj = new Object();
            for (int i3 = 0; i3 < 3; i3++) {
                if (obj.element <= 0) {
                    obj.element = AdbTls.discoverConnect$default(str);
                }
            }
            int i4 = obj.element;
            Handler handler = mainActivity.ui;
            if (i4 > 0) {
                handler.post(new Lg$$ExternalSyntheticLambda2(mainActivity, str, obj, 17));
            } else {
                handler.post(new AdbHelpKt$$ExternalSyntheticLambda63(mainActivity, str, i2));
            }
        } catch (Exception e) {
            mainActivity.ui.post(new MediaKt$$ExternalSyntheticLambda15(mainActivity, e, i));
        }
    }

    /* JADX WARN: Type inference failed for: r0v15, types: [java.util.Map, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v18, types: [java.util.Map, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r3v4, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    private final void run$dev$tvremote$phone$picker$ManyTvsKt$$ExternalSyntheticLambda35() {
        List list;
        String T;
        ImageView imageView;
        ArrayList arrayList;
        String str;
        String str2;
        String str3;
        String str4;
        ViewGroup.LayoutParams gap;
        Popup popup = (Popup) this.f$0;
        MainActivity mainActivity = (MainActivity) this.f$1;
        Launchers.Gallery gallery = (Launchers.Gallery) this.f$2;
        Ref$ObjectRef ref$ObjectRef = (Ref$ObjectRef) this.f$3;
        popup.dismiss();
        if (mainActivity.isFinishing()) {
            return;
        }
        if (gallery != null) {
            list = gallery.entries;
        } else {
            list = null;
        }
        if (list == null) {
            list = EmptyList.INSTANCE;
        }
        if (gallery != null && !list.isEmpty()) {
            Axml$$ExternalSyntheticLambda2 axml$$ExternalSyntheticLambda2 = new Axml$$ExternalSyntheticLambda2(10, mainActivity, gallery);
            ConcurrentHashMap concurrentHashMap = Words.books;
            String lang = Words.lang;
            LinearLayout col = UiKt.col(mainActivity);
            float f = 16;
            float f2 = 2;
            col.setPadding(UiKt.dp(mainActivity, f), UiKt.dp(mainActivity, f2), UiKt.dp(mainActivity, f), UiKt.dp(mainActivity, f2));
            ?? obj = new Object();
            ArrayList arrayList2 = new ArrayList();
            Iterator it = gallery.entries.iterator();
            while (it.hasNext()) {
                Launchers.Entry entry = (Launchers.Entry) it.next();
                LinearLayout col2 = UiKt.col(mainActivity);
                col2.setBackground(UiKt.box(mainActivity, UiKt.BTN, 14));
                float f3 = 12;
                col2.setPadding(UiKt.dp(mainActivity, f3), UiKt.dp(mainActivity, f3), UiKt.dp(mainActivity, f3), UiKt.dp(mainActivity, f3));
                LinearLayout linearLayout = new LinearLayout(mainActivity);
                ImageView imageView2 = new ImageView(mainActivity);
                imageView2.setScaleType(ImageView.ScaleType.CENTER_CROP);
                imageView2.setBackground(UiKt.box(mainActivity, UiKt.BG, 8));
                imageView2.setClipToOutline(true);
                imageView2.setImportantForAccessibility(2);
                Launchers.Gallery gallery2 = gallery;
                linearLayout.addView(imageView2, new LinearLayout.LayoutParams(UiKt.dp(mainActivity, 112), UiKt.dp(mainActivity, 63)));
                LinearLayout col3 = UiKt.col(mainActivity);
                Iterator it2 = it;
                TextView label = UiKt.label(mainActivity, entry.name, 16, UiKt.TEXT);
                label.setTypeface(Typeface.DEFAULT_BOLD);
                col3.addView(label);
                TextView label2 = UiKt.label(mainActivity, "", 12, UiKt.ACCENT_TEXT);
                if (entry.kind.equals("play")) {
                    imageView = imageView2;
                    arrayList = arrayList2;
                    str = ApkSigner$$ExternalSyntheticOutline0.m("▶ ", Fleet.T("launcher.badge_play", new Pair[0]));
                } else {
                    imageView = imageView2;
                    arrayList = arrayList2;
                    str = entry.version;
                }
                UiKt.setMarked(label2, str);
                col3.addView(label2, UiKt.gap(mainActivity, 2));
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
                layoutParams.leftMargin = UiKt.dp(mainActivity, f3);
                linearLayout.addView(col3, layoutParams);
                col2.addView(linearLayout);
                Intrinsics.checkNotNullParameter(lang, "lang");
                ?? r0 = entry.desc;
                String str5 = (String) r0.get(lang);
                if (str5 == null && (str5 = (String) r0.get("en")) == null) {
                    str5 = "";
                }
                TextView label3 = UiKt.label(mainActivity, str5, 14, UiKt.MUTED);
                label3.setLineSpacing(UiKt.dp(mainActivity, f2), 1.0f);
                col2.addView(label3, UiKt.gap(mainActivity, 8));
                ?? r02 = entry.notes;
                String str6 = (String) r02.get(lang);
                if (str6 == null) {
                    str2 = (String) r02.get("en");
                    if (str2 == null) {
                        str2 = "";
                    }
                } else {
                    str2 = str6;
                }
                if (str2.length() <= 0) {
                    str2 = null;
                }
                if (str2 != null) {
                    col2.addView(UiKt.label(mainActivity, str2, 13, UiKt.MUTED), UiKt.gap(mainActivity, 4));
                }
                LinearLayout linearLayout2 = new LinearLayout(mainActivity);
                linearLayout2.setGravity(16);
                if (entry.kind.equals("play")) {
                    str3 = "launcher.source_play";
                } else {
                    str3 = "launcher.source";
                }
                TextView label4 = UiKt.label(mainActivity, Census$$ExternalSyntheticOutline0.m(Fleet.T(str3, new Pair[0]), " ↗"), 14, UiKt.ACCENT_TEXT);
                label4.setPadding(0, UiKt.dp(mainActivity, f3), UiKt.dp(mainActivity, f3), UiKt.dp(mainActivity, f3));
                label4.setOnClickListener(new Guard$$ExternalSyntheticLambda9(3, mainActivity, entry));
                linearLayout2.addView(label4, new LinearLayout.LayoutParams(0, -2, 1.0f));
                if (entry.kind.equals("play")) {
                    str4 = "launcher.use";
                } else {
                    str4 = "fleet.launcher_use";
                }
                Button button = UiKt.button(mainActivity, Fleet.T(str4, new Pair[0]), UiKt.ACCENT);
                float f4 = 18;
                button.setPadding(UiKt.dp(mainActivity, f4), 0, UiKt.dp(mainActivity, f4), 0);
                button.setOnClickListener(new Guard$$ExternalSyntheticLambda7(obj, axml$$ExternalSyntheticLambda2, entry, 4));
                linearLayout2.addView(button, new LinearLayout.LayoutParams(-2, UiKt.dp(mainActivity, 44)));
                col2.addView(linearLayout2, UiKt.gap(mainActivity, 4));
                if (col.getChildCount() == 0) {
                    gap = new LinearLayout.LayoutParams(-1, -2);
                } else {
                    gap = UiKt.gap(mainActivity, 10);
                }
                col.addView(col2, gap);
                ArrayList arrayList3 = arrayList;
                arrayList3.add(new Pair(entry, imageView));
                arrayList2 = arrayList3;
                gallery = gallery2;
                it = it2;
            }
            Launchers.Gallery gallery3 = gallery;
            ExecutorService newFixedThreadPool = Executors.newFixedThreadPool(4);
            Iterator it3 = arrayList2.iterator();
            Intrinsics.checkNotNullExpressionValue(it3, "iterator(...)");
            while (it3.hasNext()) {
                Object next = it3.next();
                Intrinsics.checkNotNullExpressionValue(next, "next(...)");
                Pair pair = (Pair) next;
                newFixedThreadPool.execute(new Vidaa$$ExternalSyntheticLambda3(gallery3, (Launchers.Entry) pair.first, mainActivity, (ImageView) pair.second, 10));
            }
            newFixedThreadPool.shutdown();
            Popup.Builder builder = new Popup.Builder(mainActivity);
            builder.title = Fleet.T("fleet.which_launcher", new Pair[0]);
            builder.message = Fleet.T("fleet.launcher_note", new Pair[0]);
            builder.view = col;
            builder.setNegativeButton(Fleet.T("common.cancel", new Pair[0]), null);
            obj.element = builder.show();
            return;
        }
        if (((CharSequence) ref$ObjectRef.element).length() > 0) {
            T = (String) ref$ObjectRef.element;
        } else {
            T = Fleet.T("launcher.none", new Pair[0]);
        }
        ManyTvsKt.toast(mainActivity, T);
    }

    private final void run$dev$tvremote$phone$picker$ManyTvsKt$$ExternalSyntheticLambda53() {
        MainActivity mainActivity;
        Launchers.Gallery gallery = (Launchers.Gallery) this.f$0;
        Launchers.Entry entry = (Launchers.Entry) this.f$1;
        try {
            List list = Launchers.KEYS;
            byte[] thumb = Launchers.thumb(gallery, entry);
            BitmapFactory.Options options = new BitmapFactory.Options();
            int i = 1;
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(thumb, 0, thumb.length, options);
            while (true) {
                int i2 = i * 2;
                int i3 = options.outWidth / i2;
                mainActivity = (MainActivity) this.f$2;
                boolean z = UiKt.LIGHT;
                if (i3 < UiKt.dp(mainActivity, 112)) {
                    break;
                } else {
                    i = i2;
                }
            }
            int length = thumb.length;
            BitmapFactory.Options options2 = new BitmapFactory.Options();
            options2.inSampleSize = i;
            Bitmap decodeByteArray = BitmapFactory.decodeByteArray(thumb, 0, length, options2);
            if (decodeByteArray != null) {
                mainActivity.ui.post(new Guard$$ExternalSyntheticLambda5(28, (ImageView) this.f$3, decodeByteArray));
            }
        } catch (Exception unused) {
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x003f A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:25:? A[LOOP:0: B:6:0x0020->B:25:?, LOOP_END, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private final void run$dev$tvremote$phone$picker$ManyTvsKt$$ExternalSyntheticLambda62() {
        Bitmap decodeByteArray;
        byte[] bArr;
        RemoteLabels remoteLabels;
        HashMap hashMap = (HashMap) this.f$3;
        Ref$ObjectRef ref$ObjectRef = (Ref$ObjectRef) this.f$0;
        Object obj = ref$ObjectRef.element;
        byte[] bArr2 = null;
        if (obj != null) {
            if (((Popup) obj).isShowing()) {
                AppRow appRow = (AppRow) this.f$1;
                Iterator it = appRow.on.iterator();
                while (true) {
                    if (!it.hasNext()) {
                        break;
                    }
                    try {
                        remoteLabels = (RemoteLabels) hashMap.get((String) it.next());
                    } catch (Exception unused) {
                    }
                    if (remoteLabels != null) {
                        bArr = remoteLabels.icon(appRow.pkg);
                        if (bArr == null) {
                            bArr2 = bArr;
                            break;
                        }
                    }
                    bArr = null;
                    if (bArr == null) {
                    }
                }
                if (bArr2 != null && (decodeByteArray = BitmapFactory.decodeByteArray(bArr2, 0, bArr2.length)) != null) {
                    ((MainActivity) this.f$2).ui.post(new Lg$$ExternalSyntheticLambda2(ref$ObjectRef, appRow, decodeByteArray, 20));
                    return;
                }
                return;
            }
            return;
        }
        Intrinsics.throwUninitializedPropertyAccessException("box");
        throw null;
    }

    private final void run$dev$tvremote$phone$remote$KeysOnlyKt$$ExternalSyntheticLambda26() {
        CodePairing codePairing = (CodePairing) this.f$0;
        String str = (String) this.f$1;
        MainActivity mainActivity = (MainActivity) this.f$3;
        String str2 = (String) this.f$2;
        try {
            codePairing.finishPairing(str);
            mainActivity.ui.post(new AdbHelpKt$$ExternalSyntheticLambda63(mainActivity, str2, 5));
        } catch (Exception unused) {
            codePairing.close();
            mainActivity.ui.post(new MainActivity$$ExternalSyntheticLambda15(mainActivity, 24));
        }
    }

    private final void run$dev$tvremote$phone$scenes$AutomationKt$$ExternalSyntheticLambda11() {
        HashMap hashMap = Scenes.KEYS;
        String run$default = Scenes.run$default((JSONArray) this.f$0, (Scenes.Target) this.f$1);
        MainActivity mainActivity = (MainActivity) this.f$2;
        mainActivity.ui.post(new RescuingKt$$ExternalSyntheticLambda2(mainActivity, run$default, (JSONObject) this.f$3));
    }

    /* JADX WARN: Code restructure failed: missing block: B:260:0x0664, code lost:
    
        if (r0 != null) goto L278;
     */
    /* JADX WARN: Code restructure failed: missing block: B:263:0x05a6, code lost:
    
        r0.close();
     */
    /* JADX WARN: Code restructure failed: missing block: B:289:0x04dc, code lost:
    
        if (r0 != null) goto L216;
     */
    /* JADX WARN: Code restructure failed: missing block: B:292:0x04b4, code lost:
    
        r0.close();
     */
    /* JADX WARN: Code restructure failed: missing block: B:296:0x04ec, code lost:
    
        if (r0 != null) goto L216;
     */
    /* JADX WARN: Code restructure failed: missing block: B:348:0x05a4, code lost:
    
        if (r0 != null) goto L278;
     */
    /* JADX WARN: Code restructure failed: missing block: B:353:0x05f3, code lost:
    
        if (r0 != null) goto L278;
     */
    /* JADX WARN: Code restructure failed: missing block: B:356:0x063e, code lost:
    
        if (r0 != null) goto L278;
     */
    /* JADX WARN: Code restructure failed: missing block: B:373:0x04b2, code lost:
    
        if (r0 != null) goto L216;
     */
    /* JADX WARN: Removed duplicated region for block: B:215:0x041f  */
    /* JADX WARN: Removed duplicated region for block: B:256:0x0654 A[Catch: all -> 0x056c, TRY_LEAVE, TryCatch #2 {all -> 0x056c, blocks: (B:316:0x0550, B:317:0x0552, B:319:0x0558, B:321:0x055c, B:323:0x0560, B:325:0x0566, B:327:0x0572, B:329:0x0578, B:331:0x057e, B:254:0x0649, B:256:0x0654, B:345:0x0599, B:349:0x05ad, B:351:0x05e4, B:354:0x05f6), top: B:315:0x0550 }] */
    /* JADX WARN: Removed duplicated region for block: B:258:0x065f  */
    /* JADX WARN: Removed duplicated region for block: B:267:0x066b  */
    /* JADX WARN: Removed duplicated region for block: B:270:0x0674  */
    /* JADX WARN: Removed duplicated region for block: B:288:0x04da  */
    /* JADX WARN: Removed duplicated region for block: B:293:0x04df  */
    /* JADX WARN: Removed duplicated region for block: B:347:0x059f  */
    /* JADX WARN: Removed duplicated region for block: B:349:0x05ad A[Catch: all -> 0x056c, Exception -> 0x056f, TRY_ENTER, TryCatch #0 {Exception -> 0x056f, blocks: (B:316:0x0550, B:317:0x0552, B:319:0x0558, B:321:0x055c, B:323:0x0560, B:325:0x0566, B:327:0x0572, B:329:0x0578, B:331:0x057e, B:345:0x0599, B:349:0x05ad, B:351:0x05e4, B:354:0x05f6), top: B:315:0x0550 }] */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void run() {
        AdbLink adbLink;
        IrHear irHear;
        AdbLink adbLink2;
        AdbLink adbLink3;
        Adb adb;
        AdbLink adbLink4;
        LinkedHashMap linkedHashMap;
        int i;
        AdbLink adbLink5;
        char c;
        String T;
        boolean z;
        HttpURLConnection httpURLConnection;
        OutputStream outputStream;
        long j;
        long j2;
        InputStream inputStream;
        Throwable th;
        String str;
        int i2;
        byte[] bArr;
        String str2;
        Long longOrNull;
        Uri uri;
        String str3;
        Map map;
        Object obj;
        Voice.Prefs prefs;
        JSONObject put;
        int i3 = 3;
        AdbLink adbLink6 = null;
        String str4 = "error";
        String str5 = "";
        int i4 = 0;
        switch (this.$r8$classId) {
            case 0:
                MqttLite mqttLite = (MqttLite) this.f$0;
                String str6 = (String) this.f$1;
                String str7 = (String) this.f$2;
                Vidaa vidaa = (Vidaa) this.f$3;
                try {
                    mqttLite.publish(str6, str7);
                    WireLog.all.add("→", "VIDAA " + vidaa.host + " " + StringsKt.substringAfterLast(str6, "/", str6) + " " + StringsKt.take(str7, 80));
                    return;
                } catch (IOException unused) {
                    mqttLite.lost = true;
                    mqttLite.close();
                    return;
                }
            case 1:
                String str8 = (String) this.f$1;
                MainActivity mainActivity = (MainActivity) this.f$0;
                MainActivity$$ExternalSyntheticLambda10 mainActivity$$ExternalSyntheticLambda10 = (MainActivity$$ExternalSyntheticLambda10) this.f$3;
                String str9 = (String) this.f$2;
                try {
                    List asList = ArraysKt.asList(new String[]{str8, mainActivity.pref$android_release("ts:" + str8), mainActivity.pref$android_release("lan:" + str8)});
                    ArrayList arrayList = new ArrayList();
                    for (Object obj2 : asList) {
                        try {
                            try {
                                if (((String) obj2).length() > 0) {
                                    arrayList.add(obj2);
                                }
                            } catch (Exception e) {
                                e = e;
                                irHear = null;
                                adbLink = null;
                                Log.w("TvrIr", "learn", e);
                                Object obj3 = IrState.catalog;
                                if (!IrState.stop) {
                                }
                                if (irHear != null) {
                                }
                                adbLink3 = IrState.link;
                                break;
                            }
                        } catch (Throwable th2) {
                            th = th2;
                            irHear = null;
                            adbLink = null;
                            if (irHear != null) {
                            }
                            Object obj4 = IrState.catalog;
                            adbLink2 = IrState.link;
                            if (adbLink2 != null) {
                            }
                            IrState.link = adbLink;
                            throw th;
                        }
                    }
                    adb = null;
                } catch (Exception e2) {
                    e = e2;
                    adbLink = null;
                    irHear = null;
                } catch (Throwable th3) {
                    th = th3;
                    adbLink = null;
                    irHear = null;
                }
                for (String str10 : CollectionsKt.distinct(arrayList)) {
                    Object obj5 = IrState.catalog;
                    if (IrState.stop) {
                        adbLink4 = IrState.link;
                        break;
                    } else {
                        File filesDir = mainActivity.getFilesDir();
                        Intrinsics.checkNotNullExpressionValue(filesDir, "getFilesDir(...)");
                        adbLink5 = new AdbLink(filesDir, str10);
                        IrState.link = adbLink5;
                        try {
                            adb = adbLink5.get();
                        } catch (Exception unused2) {
                            adb = null;
                        }
                        if (adb != null) {
                            Object obj6 = IrState.catalog;
                            if (!IrState.stop) {
                                adbLink4 = IrState.link;
                                break;
                            } else if (adb == null) {
                                mainActivity$$ExternalSyntheticLambda10.invoke(new MediaKt$$ExternalSyntheticLambda4(mainActivity, str9, 2));
                                adbLink4 = IrState.link;
                                break;
                            } else {
                                try {
                                    ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                                    str5 = StringsKt.trim(adb.shell(120000L, "getprop ro.product.model")).toString();
                                } catch (Exception unused3) {
                                }
                                if (str5.length() == 0) {
                                    str5 = str9;
                                }
                                irHear = new IrHear(adb);
                                try {
                                    Thread.sleep(600L);
                                    linkedHashMap = new LinkedHashMap();
                                    i = 0;
                                } catch (Exception e3) {
                                    e = e3;
                                    adbLink = adbLink6;
                                } catch (Throwable th4) {
                                    th = th4;
                                    adbLink = adbLink6;
                                }
                                for (String str11 : IrLearn.KEYS) {
                                    int i5 = i + 1;
                                    Object obj7 = IrState.catalog;
                                    if (!IrState.finish && !IrState.stop) {
                                        IrState.skip = false;
                                        mainActivity$$ExternalSyntheticLambda10.invoke(new UiKt$$ExternalSyntheticLambda8(mainActivity, str11, i, linkedHashMap, 1));
                                        adbLink = adbLink6;
                                        try {
                                            try {
                                                long nanoTime = System.nanoTime() / 1000000;
                                                while (true) {
                                                    Object obj8 = IrState.catalog;
                                                    if (!IrState.skip && !IrState.finish && !IrState.stop && irHear.lastScan <= nanoTime) {
                                                        Thread.sleep(40L);
                                                    }
                                                }
                                                if (irHear.lastScan > nanoTime && irHear.scanValue >= 0) {
                                                    linkedHashMap.put(str11, Long.valueOf(irHear.scanValue));
                                                    Thread.sleep(500L);
                                                }
                                                adbLink6 = adbLink;
                                                i = i5;
                                            } catch (Exception e4) {
                                                e = e4;
                                                Log.w("TvrIr", "learn", e);
                                                Object obj32 = IrState.catalog;
                                                if (!IrState.stop) {
                                                    mainActivity$$ExternalSyntheticLambda10.invoke(new MediaKt$$ExternalSyntheticLambda4(mainActivity, str9, 3));
                                                }
                                                if (irHear != null) {
                                                    irHear.close();
                                                }
                                                adbLink3 = IrState.link;
                                            }
                                        } catch (Throwable th5) {
                                            th = th5;
                                            if (irHear != null) {
                                                irHear.close();
                                            }
                                            Object obj42 = IrState.catalog;
                                            adbLink2 = IrState.link;
                                            if (adbLink2 != null) {
                                                adbLink2.close();
                                            }
                                            IrState.link = adbLink;
                                            throw th;
                                        }
                                    }
                                    adbLink = adbLink6;
                                    Object obj9 = IrState.catalog;
                                    if (!IrState.stop) {
                                        irHear.close();
                                        adbLink3 = IrState.link;
                                        break;
                                    } else {
                                        Set entrySet = linkedHashMap.entrySet();
                                        Intrinsics.checkNotNullExpressionValue(entrySet, "<get-entries>(...)");
                                        Log.i("TvrIr", "learned scancodes " + CollectionsKt.joinToString$default(entrySet, null, null, null, new ApkCert$$ExternalSyntheticLambda0(1), 31));
                                        LinkedHashMap build = IrLearn.build(linkedHashMap);
                                        if (build == null) {
                                            mainActivity$$ExternalSyntheticLambda10.invoke(new TalkKt$$ExternalSyntheticLambda1(mainActivity, 9));
                                            irHear.close();
                                            adbLink3 = IrState.link;
                                            break;
                                        } else {
                                            IrProfile irCustomKeep = IrRemoteKt.irCustomKeep(mainActivity, "custom:" + str8, str5, build);
                                            IrRemoteKt.irSave(mainActivity, irCustomKeep);
                                            mainActivity.getPrefs$android_release().edit().putString("ir:profile:" + str8, irCustomKeep.id).apply();
                                            mainActivity$$ExternalSyntheticLambda10.invoke(new IrRemoteKt$$ExternalSyntheticLambda25(mainActivity, irCustomKeep, 1));
                                            irHear.close();
                                            adbLink3 = IrState.link;
                                            break;
                                        }
                                    }
                                    IrState.link = adbLink;
                                    return;
                                    break;
                                }
                                adbLink = adbLink6;
                                Object obj92 = IrState.catalog;
                                if (!IrState.stop) {
                                }
                                IrState.link = adbLink;
                                return;
                            }
                            IrState.link = null;
                            return;
                        }
                    }
                }
                Object obj62 = IrState.catalog;
                if (!IrState.stop) {
                }
                IrState.link = null;
                return;
            case 2:
                String str12 = (String) this.f$1;
                Managing managing = (Managing) this.f$0;
                Ref$ObjectRef ref$ObjectRef = (Ref$ObjectRef) this.f$3;
                String str13 = (String) this.f$2;
                try {
                    URLConnection openConnection = new URL(str12).openConnection();
                    Intrinsics.checkNotNull(openConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
                    httpURLConnection = (HttpURLConnection) openConnection;
                    httpURLConnection.setRequestProperty("Cookie", "tvr=" + managing.token);
                    int i6 = Build.VERSION.SDK_INT;
                    MainActivity mainActivity2 = managing.a;
                    if (i6 >= 29) {
                        ContentValues contentValues = new ContentValues();
                        contentValues.put("_display_name", (String) ref$ObjectRef.element);
                        contentValues.put("relative_path", Environment.DIRECTORY_DOWNLOADS);
                        ContentResolver contentResolver = mainActivity2.getContentResolver();
                        ContentResolver contentResolver2 = mainActivity2.getContentResolver();
                        uri = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                        Uri insert = contentResolver2.insert(uri, contentValues);
                        Intrinsics.checkNotNull(insert);
                        outputStream = contentResolver.openOutputStream(insert);
                        Intrinsics.checkNotNull(outputStream);
                        T = Fleet.T("managing.saved_to_download", new Pair("name", ref$ObjectRef.element));
                    } else {
                        File file = new File(mainActivity2.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), (String) ref$ObjectRef.element);
                        FileOutputStream fileOutputStream = new FileOutputStream(file);
                        T = Fleet.T("pc.saved_file", new Pair("path", file.getAbsolutePath()));
                        outputStream = fileOutputStream;
                    }
                    String headerField = httpURLConnection.getHeaderField("content-length");
                    if (headerField != null && (longOrNull = StringsKt__StringNumberConversionsKt.toLongOrNull(headerField)) != null) {
                        j = longOrNull.longValue();
                    } else {
                        j = -1;
                    }
                    j2 = j;
                } catch (Exception e5) {
                    e = e5;
                    c = 0;
                }
                try {
                    try {
                        inputStream = httpURLConnection.getInputStream();
                    } catch (Throwable th6) {
                        th = th6;
                        c = 0;
                    }
                } catch (Exception e6) {
                    e = e6;
                    Pair pair = new Pair("error", e.getMessage());
                    Pair[] pairArr = new Pair[1];
                    pairArr[c] = pair;
                    T = Fleet.T("managing.download_failed", pairArr);
                    z = false;
                    String str14 = T;
                    if (z) {
                    }
                    managing.a.ui.post(new Guard$$ExternalSyntheticLambda5(22, managing, Census$$ExternalSyntheticOutline0.m8m("id", str13).put("label", ref$ObjectRef.element).put("status", str4).put("pct", 100).put("msg", str14)));
                    return;
                }
                try {
                    try {
                        byte[] bArr2 = new byte[65536];
                        long j3 = 0;
                        long j4 = 0;
                        while (true) {
                            int read = inputStream.read(bArr2);
                            if (read >= 0) {
                                outputStream.write(bArr2, i4, read);
                                long j5 = read + j3;
                                long currentTimeMillis = System.currentTimeMillis();
                                if (currentTimeMillis - j4 > 300) {
                                    if (j2 > 0) {
                                        c = 0;
                                        str = str13;
                                        try {
                                            i2 = (int) ((100 * j5) / j2);
                                        } catch (Throwable th7) {
                                            th = th7;
                                            str13 = str;
                                            try {
                                                throw th;
                                            } catch (Throwable th8) {
                                                MathKt.closeFinally(inputStream, th);
                                                throw th8;
                                            }
                                        }
                                    } else {
                                        str = str13;
                                        c = 0;
                                        i2 = -1;
                                    }
                                    try {
                                        String size = Managing.size(j5);
                                        if (j2 > 0) {
                                            String size2 = Managing.size(j2);
                                            StringBuilder sb = new StringBuilder();
                                            bArr = bArr2;
                                            sb.append(" / ");
                                            sb.append(size2);
                                            str2 = sb.toString();
                                        } else {
                                            bArr = bArr2;
                                            str2 = "";
                                        }
                                        str13 = str;
                                        try {
                                            managing.a.ui.post(new Guard$$ExternalSyntheticLambda5(22, managing, Census$$ExternalSyntheticOutline0.m8m("id", str13).put("label", ref$ObjectRef.element).put("status", "running").put("pct", i2).put("msg", size + str2)));
                                            j3 = j5;
                                            j4 = currentTimeMillis;
                                            bArr2 = bArr;
                                            i4 = 0;
                                        } catch (Throwable th9) {
                                            th = th9;
                                            th = th;
                                            throw th;
                                        }
                                    } catch (Throwable th10) {
                                        th = th10;
                                        str13 = str;
                                    }
                                } else {
                                    j3 = j5;
                                }
                            } else {
                                inputStream.close();
                                outputStream.close();
                                z = true;
                                String str142 = T;
                                if (z) {
                                    str4 = "done";
                                }
                                managing.a.ui.post(new Guard$$ExternalSyntheticLambda5(22, managing, Census$$ExternalSyntheticOutline0.m8m("id", str13).put("label", ref$ObjectRef.element).put("status", str4).put("pct", 100).put("msg", str142)));
                                return;
                            }
                        }
                    } catch (Throwable th11) {
                        th = th11;
                        Throwable th12 = th;
                        try {
                            throw th12;
                        } catch (Throwable th13) {
                            MathKt.closeFinally(outputStream, th12);
                            throw th13;
                        }
                    }
                } catch (Throwable th14) {
                    th = th14;
                    c = 0;
                }
                break;
            case 3:
                MainActivity mainActivity3 = (MainActivity) this.f$0;
                Ref$ObjectRef ref$ObjectRef2 = (Ref$ObjectRef) this.f$3;
                String str15 = (String) this.f$1;
                String str16 = (String) this.f$2;
                Tv tv = mainActivity3.sound;
                Object obj10 = ref$ObjectRef2.element;
                if (obj10 != null) {
                    if (tv == ((Tv) obj10) && (str3 = mainActivity3.host) != null) {
                        switch (str15.hashCode()) {
                            case -1357520532:
                                if (!str15.equals("closed")) {
                                    return;
                                }
                                break;
                            case 3322092:
                                if (str15.equals("live")) {
                                    mainActivity3.soundTries = 0;
                                    return;
                                }
                                return;
                            case 93074625:
                                if (str15.equals("arate")) {
                                    if (!mainActivity3.video || mainActivity3.bgListen) {
                                        TextView status$android_release = mainActivity3.getStatus$android_release();
                                        String str17 = mainActivity3.entry;
                                        if (str17 != null) {
                                            str3 = str17;
                                        }
                                        status$android_release.setText(mainActivity3.title$android_release(str3) + " · 🎧 " + str16 + " KB/s");
                                        return;
                                    }
                                    return;
                                }
                                return;
                            case 93166550:
                                if (str15.equals("audio")) {
                                    if (Intrinsics.areEqual(str16, "tvloud")) {
                                        mainActivity3.listenTvLoud = true;
                                        Toast.makeText(mainActivity3, Fleet.T("listen.tv_still_loud", new Pair[0]), 1).show();
                                        TypingKt.layoutRemote(mainActivity3);
                                        return;
                                    } else {
                                        if (Intrinsics.areEqual(str16, "tvsilent")) {
                                            mainActivity3.listenTvLoud = false;
                                            return;
                                        }
                                        if (Intrinsics.areEqual(str16, "noshare")) {
                                            mainActivity3.listenShare = false;
                                            Toast.makeText(mainActivity3, Fleet.T("listen.private_only", new Pair[0]), 1).show();
                                            return;
                                        } else if (StringsKt__StringsJVMKt.startsWith(str16, false, "refused")) {
                                            Fleet.stopListen(mainActivity3, Fleet.T("listen.refused", new Pair("sdk", StringsKt.substringAfter(str16, ":", "?"))));
                                            return;
                                        } else {
                                            Fleet.stopListen(mainActivity3, Fleet.T("listen.this_tv_cannot_send", new Pair[0]));
                                            return;
                                        }
                                    }
                                }
                                return;
                            case 96784904:
                                if (!str15.equals("error")) {
                                    return;
                                }
                                break;
                            default:
                                return;
                        }
                        mainActivity3.sound = null;
                        if (mainActivity3.listen) {
                            if (StringsKt.contains(str16, "cannot send its sound", false)) {
                                Fleet.stopListen(mainActivity3, Fleet.T("listen.this_tv_cannot_send", new Pair[0]));
                                return;
                            }
                            int i7 = mainActivity3.soundTries;
                            int i8 = 1 + i7;
                            mainActivity3.soundTries = i8;
                            if (i7 < 6) {
                                mainActivity3.ui.postDelayed(new MainActivity$$ExternalSyntheticLambda15(mainActivity3, 10), i8 * 1000);
                                return;
                            } else {
                                Fleet.stopListen(mainActivity3, Fleet.T("listen.gave_up", new Pair[0]));
                                return;
                            }
                        }
                        return;
                    }
                    return;
                }
                Intrinsics.throwUninitializedPropertyAccessException("s");
                throw null;
            case 4:
                Tv tv2 = (Tv) this.f$2;
                MainActivity mainActivity4 = (MainActivity) this.f$0;
                File filesDir2 = mainActivity4.getFilesDir();
                Intrinsics.checkNotNullExpressionValue(filesDir2, "getFilesDir(...)");
                String str18 = (String) this.f$1;
                adbLink5 = new AdbLink(filesDir2, str18);
                try {
                    try {
                        map = new RemoteLabels(adbLink5, new TalkKt$$ExternalSyntheticLambda1(mainActivity4, 0), null).names();
                    } catch (Exception unused4) {
                        map = EmptyMap.INSTANCE;
                    }
                    adbLink5.close();
                    Map map2 = map;
                    try {
                        obj = Home.ownPins(new TalkKt$$ExternalSyntheticLambda2(tv2, 0));
                    } catch (Exception unused5) {
                        obj = EmptyList.INSTANCE;
                    }
                    Object obj11 = obj;
                    try {
                        JSONObject call = RulesClient.call(new TalkKt$$ExternalSyntheticLambda2(tv2, 6), null);
                        String optString = call.optString("voice_search");
                        Intrinsics.checkNotNullExpressionValue(optString, "optString(...)");
                        String optString2 = call.optString("voice_youtube");
                        Intrinsics.checkNotNullExpressionValue(optString2, "optString(...)");
                        prefs = new Voice.Prefs(optString, optString2);
                    } catch (Exception unused6) {
                        prefs = new Voice.Prefs();
                    }
                    mainActivity4.ui.post(new TalkKt$$ExternalSyntheticLambda4(mainActivity4, str18, map2, obj11, prefs, (Census$$ExternalSyntheticLambda6) this.f$3, 0));
                    return;
                } finally {
                    adbLink5.close();
                }
            case 5:
                run$dev$tvremote$phone$picker$AdbHelpKt$$ExternalSyntheticLambda24();
                return;
            case 6:
                run$dev$tvremote$phone$picker$AdbHelpKt$$ExternalSyntheticLambda37();
                return;
            case 7:
                run$dev$tvremote$phone$picker$AdbHelpKt$$ExternalSyntheticLambda38();
                return;
            case 8:
                MainActivity mainActivity5 = (MainActivity) this.f$0;
                if (!mainActivity5.isFinishing() && mainActivity5.basic == ((Remote) this.f$1)) {
                    if (((Ref$BooleanRef) this.f$2).element) {
                        ((Function0) this.f$3).invoke();
                        return;
                    } else {
                        AdbHelpKt.installSetup(mainActivity5, UiKt.HOME_APP);
                        return;
                    }
                }
                return;
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                run$dev$tvremote$phone$picker$ManyTvsKt$$ExternalSyntheticLambda35();
                return;
            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                run$dev$tvremote$phone$picker$ManyTvsKt$$ExternalSyntheticLambda53();
                return;
            case 11:
                run$dev$tvremote$phone$picker$ManyTvsKt$$ExternalSyntheticLambda62();
                return;
            case FileClientSessionCache.MAX_SIZE /* 12 */:
                if (Air.touching && !((Ref$BooleanRef) this.f$0).element && Air.buttons == 0) {
                    Air.padHeld = true;
                    Air.airButton((MainActivity) this.f$1, true);
                    Air.airHaptic((FrameLayout) this.f$2, 0);
                    AirFx airFx = (AirFx) this.f$3;
                    airFx.held = true;
                    airFx.invalidate();
                    return;
                }
                return;
            case 13:
                run$dev$tvremote$phone$remote$KeysOnlyKt$$ExternalSyntheticLambda26();
                return;
            case 14:
                run$dev$tvremote$phone$scenes$AutomationKt$$ExternalSyntheticLambda11();
                return;
            default:
                try {
                    put = RulesClient.call(new TalkKt$$ExternalSyntheticLambda2((Tv) this.f$2, 18), (JSONObject) this.f$0);
                } catch (Exception e7) {
                    JSONObject jSONObject = new JSONObject();
                    String message = e7.getMessage();
                    if (message != null) {
                        str5 = message;
                    }
                    put = jSONObject.put("error", str5);
                }
                MainActivity mainActivity6 = (MainActivity) this.f$1;
                mainActivity6.ui.post(new KeysOnlyKt$$ExternalSyntheticLambda3(mainActivity6, (Function1) this.f$3, put, i3));
                return;
        }
    }

    public /* synthetic */ Vidaa$$ExternalSyntheticLambda3(Object obj, Object obj2, Object obj3, Object obj4, int i) {
        this.$r8$classId = i;
        this.f$0 = obj;
        this.f$1 = obj2;
        this.f$2 = obj3;
        this.f$3 = obj4;
    }

    public /* synthetic */ Vidaa$$ExternalSyntheticLambda3(Object obj, String str, Object obj2, String str2, int i) {
        this.$r8$classId = i;
        this.f$0 = obj;
        this.f$1 = str;
        this.f$3 = obj2;
        this.f$2 = str2;
    }

    public /* synthetic */ Vidaa$$ExternalSyntheticLambda3(String str, Object obj, Object obj2, String str2, int i) {
        this.$r8$classId = i;
        this.f$1 = str;
        this.f$0 = obj;
        this.f$3 = obj2;
        this.f$2 = str2;
    }
}
