package dev.tvremote.core.remote;

import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import java.io.IOException;
import java.util.regex.Pattern;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class Lg$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Lg f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ Lg$$ExternalSyntheticLambda0(int i, Lg lg, String str) {
        this.$r8$classId = i;
        this.f$0 = lg;
        this.f$1 = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        String str;
        switch (this.$r8$classId) {
            case 0:
                Lg.request$default(this.f$0, "ssap://com.webos.service.ime/insertText", new JSONObject().put("text", this.f$1).put("replace", 0), 0L, 4);
                return;
            case 1:
                Lg lg = this.f$0;
                try {
                    lg.pointer().send(this.f$1);
                    return;
                } catch (IOException unused) {
                    WebSocket webSocket = lg.pointer;
                    if (webSocket != null) {
                        webSocket.close();
                    }
                    lg.pointer = null;
                    return;
                }
            default:
                Pattern compile = Pattern.compile("^[a-zA-Z][a-zA-Z0-9+.-]*:");
                Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                String input = this.f$1;
                Intrinsics.checkNotNullParameter(input, "input");
                boolean find = compile.matcher(input).find();
                Lg lg2 = this.f$0;
                if (find) {
                    MatcherMatchResult access$findNext = MathKt.access$findNext(Census$$ExternalSyntheticOutline0.m6m("(?:youtube\\.com/watch\\?v=|youtu\\.be/)([\\w-]{6,})", "compile(...)", input, "matcher(...)"), 0, input);
                    if (access$findNext != null) {
                        str = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1);
                    } else {
                        str = null;
                    }
                    if (str != null) {
                        Lg.request$default(lg2, "ssap://system.launcher/launch", Census$$ExternalSyntheticOutline0.m10m("id", "youtube.leanback.v4", "contentId", str), 0L, 4);
                        return;
                    } else {
                        Lg.request$default(lg2, "ssap://system.launcher/open", Census$$ExternalSyntheticOutline0.m8m("target", input), 0L, 4);
                        return;
                    }
                }
                Lg.request$default(lg2, "ssap://system.launcher/launch", Census$$ExternalSyntheticOutline0.m8m("id", input), 0L, 4);
                return;
        }
    }

    public /* synthetic */ Lg$$ExternalSyntheticLambda0(String str, Lg lg) {
        this.$r8$classId = 2;
        this.f$1 = str;
        this.f$0 = lg;
    }
}
