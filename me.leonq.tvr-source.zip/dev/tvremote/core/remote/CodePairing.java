package dev.tvremote.core.remote;

import java.io.Closeable;

/* loaded from: classes.dex */
public interface CodePairing extends Closeable {
    void finishPairing(String str);

    void startPairing();
}
