package dev.tvremote.core.remote;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.os.Build;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticLambda4;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.scenes.RemoteSpec$Entry;
import dev.tvremote.core.web.Cancel;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda9;
import dev.tvremote.phone.ir.IrProfile;
import dev.tvremote.phone.ir.IrRemoteKt;
import dev.tvremote.phone.ir.IrRemoteKt$$ExternalSyntheticLambda25;
import dev.tvremote.phone.ir.IrRemoteKt$$ExternalSyntheticLambda49;
import dev.tvremote.phone.manage.Managing;
import dev.tvremote.phone.picker.AdbHelpKt;
import dev.tvremote.phone.picture.Air;
import dev.tvremote.phone.remote.PhoneRemoteKt;
import dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda16;
import dev.tvremote.phone.ui.DlApp;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.phone.ui.UiKt;
import dev.tvremote.tvapps.ApkCert$$ExternalSyntheticLambda0;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$BooleanRef;
import kotlin.jvm.internal.Ref$ObjectRef;
import kotlin.math.MathKt;
import org.conscrypt.metrics.ConscryptStatsLog;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class Vidaa$$ExternalSyntheticLambda6 implements Function0 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;
    public final /* synthetic */ Object f$1;
    public final /* synthetic */ Object f$2;

    public /* synthetic */ Vidaa$$ExternalSyntheticLambda6(MainActivity mainActivity, String str, List list) {
        this.$r8$classId = 7;
        this.f$0 = mainActivity;
        this.f$2 = str;
        this.f$1 = list;
    }

    /* JADX WARN: Type inference failed for: r1v40, types: [java.util.Map, java.lang.Object] */
    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        boolean z;
        String str;
        String str2;
        String str3;
        String str4 = null;
        String str5 = "";
        int i = 0;
        switch (this.$r8$classId) {
            case 0:
                String platform = ((Vidaa) this.f$1).platform("gettoken", "data");
                String jSONObject = new JSONObject().put("refreshtoken", (String) this.f$2).toString();
                Intrinsics.checkNotNullExpressionValue(jSONObject, "toString(...)");
                ((MqttLite) this.f$0).publish(platform, jSONObject);
                return Unit.INSTANCE;
            case 1:
                Ref$BooleanRef ref$BooleanRef = (Ref$BooleanRef) this.f$0;
                Cancel cancel = (Cancel) this.f$1;
                JSONObject jSONObject2 = (JSONObject) this.f$2;
                if (cancel != null && cancel.stopped) {
                    z = true;
                } else {
                    z = false;
                }
                ref$BooleanRef.element = !z;
                if (!z) {
                    jSONObject2.put("msg", "install").put("pct", 95);
                }
                return Boolean.valueOf(ref$BooleanRef.element);
            case 2:
                ArrayList arrayList = (ArrayList) this.f$0;
                int size = arrayList.size();
                MainActivity mainActivity = (MainActivity) this.f$1;
                if (size == 1) {
                    IrRemoteKt.irSave(mainActivity, (IrProfile) arrayList.get(0));
                    IrRemoteKt.irRemote(mainActivity);
                } else {
                    IrProfile irProfile = IrRemoteKt.irProfile(mainActivity);
                    if (irProfile != null) {
                        str4 = irProfile.id;
                    }
                    ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList));
                    Iterator it = arrayList.iterator();
                    while (it.hasNext()) {
                        IrProfile irProfile2 = (IrProfile) it.next();
                        Pair[] pairArr = new Pair[1];
                        pairArr[i] = new Pair("n", Integer.valueOf(irProfile2.kind));
                        String T = Fleet.T("ir.kind", pairArr);
                        if (irProfile2.kind != 1) {
                            str = "";
                        } else {
                            str = ApkSigner$$ExternalSyntheticOutline0.m(" · ", Fleet.T("ir.common", new Pair[i]));
                        }
                        if (!Intrinsics.areEqual(irProfile2.id, str4)) {
                            str2 = "";
                        } else {
                            str2 = "  ✓";
                        }
                        String m = Census$$ExternalSyntheticOutline0.m("@tv|", T, str, str2);
                        List list = irProfile2.models;
                        String joinToString$default = CollectionsKt.joinToString$default(CollectionsKt.take(list, 2), ", ", null, null, null, 62);
                        if (list.size() <= 2) {
                            str3 = "";
                        } else {
                            str3 = ApkSigner$$ExternalSyntheticOutline0.m(" +", list.size() - 2);
                        }
                        arrayList2.add(new Triple(m, Census$$ExternalSyntheticOutline0.m(Fleet.T("ir.models", new Pair("list", Census$$ExternalSyntheticOutline0.m(joinToString$default, str3))), " · ", Fleet.T("ir.n_keys", new Pair("n", Integer.valueOf(irProfile2.keys.size())))), new IrRemoteKt$$ExternalSyntheticLambda25(mainActivity, irProfile2, 0)));
                        i = 0;
                    }
                    UiKt.menu(mainActivity, (String) this.f$2, -1, arrayList2);
                }
                return Unit.INSTANCE;
            case 3:
                String str6 = (String) this.f$2;
                if (!Intrinsics.areEqual(str6, (String) this.f$0)) {
                    MainActivity mainActivity2 = (MainActivity) this.f$1;
                    mainActivity2.getPrefs$android_release().edit().putString("lang", str6).apply();
                    mainActivity2.recreate();
                }
                return Unit.INSTANCE;
            case 4:
                FrameLayout frameLayout = (FrameLayout) this.f$0;
                frameLayout.removeAllViews();
                List asList = ArraysKt.asList(new Pair[]{new Pair("quick", Fleet.T("talk.mode_quick_short", new Pair[0])), new Pair("old", Fleet.T("talk.mode_old_short", new Pair[0]))});
                MainActivity mainActivity3 = (MainActivity) this.f$1;
                frameLayout.addView(UiKt.chips(mainActivity3, asList, mainActivity3.pref$android_release("talkMode"), new IrRemoteKt$$ExternalSyntheticLambda49(mainActivity3, (Ref$ObjectRef) this.f$2)));
                return Unit.INSTANCE;
            case 5:
                MainActivity mainActivity4 = (MainActivity) this.f$0;
                Object systemService = mainActivity4.getSystemService("clipboard");
                Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.content.ClipboardManager");
                ((ClipboardManager) systemService).setPrimaryClip(ClipData.newPlainText("TV", ((EditText) this.f$1).getText().toString()));
                if (Build.VERSION.SDK_INT < 33) {
                    Toast.makeText(mainActivity4, Fleet.T("playing.copied_here", new Pair[0]), 0).show();
                }
                ((Popup) this.f$2).dismiss();
                return Unit.INSTANCE;
            case 6:
                AdbHelpKt.openOnTv((MainActivity) this.f$0, (Remote) this.f$1, (String) ((DlApp) this.f$2).pkg, true, new Census$$ExternalSyntheticLambda4(18));
                return Unit.INSTANCE;
            case 7:
                MainActivity mainActivity5 = (MainActivity) this.f$0;
                HashMap hashMap = mainActivity5.setupNews;
                String str7 = (String) this.f$2;
                hashMap.remove(str7);
                mainActivity5.setupChecked.remove(str7);
                MathKt.showSetup(mainActivity5, str7);
                Managing.open$default(mainActivity5.getManaging$android_release(), str7, null, ApkSigner$$ExternalSyntheticOutline0.m("updateAll(", CollectionsKt.joinToString$default((List) this.f$1, ",", "[", "]", new ApkCert$$ExternalSyntheticLambda0(12), 24), ")"), 2);
                return Unit.INSTANCE;
            case 8:
                new Thread(new MainActivity$$ExternalSyntheticLambda9((String) this.f$2, (MainActivity) this.f$0, (Tv) this.f$1, 9)).start();
                return Unit.INSTANCE;
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                String str8 = (String) PhoneRemoteKt.remoteGroups.get(((RemoteSpec$Entry) this.f$1).arg);
                if (str8 != null) {
                    str5 = str8;
                }
                UiKt.menu((MainActivity) this.f$0, Fleet.T(str5, new Pair[0]), -1, (List) this.f$2);
                return Unit.INSTANCE;
            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                ((Function2) this.f$0).invoke((MainActivity) this.f$1, (String) this.f$2);
                return Unit.INSTANCE;
            default:
                String str9 = (String) this.f$2;
                if (Intrinsics.areEqual(str9, "mouse")) {
                    MainActivity mainActivity6 = (MainActivity) this.f$0;
                    if (!Air.airCan(mainActivity6)) {
                        Fleet.say(mainActivity6, Fleet.T("air.needs_adb", new Pair[0]), true);
                    }
                }
                ((RemoteScreenKt$$ExternalSyntheticLambda16) this.f$1).invoke(str9, Boolean.TRUE);
                return Unit.INSTANCE;
        }
    }

    public /* synthetic */ Vidaa$$ExternalSyntheticLambda6(Object obj, Object obj2, Object obj3, int i) {
        this.$r8$classId = i;
        this.f$0 = obj;
        this.f$1 = obj2;
        this.f$2 = obj3;
    }

    public /* synthetic */ Vidaa$$ExternalSyntheticLambda6(String str, Object obj, Object obj2, int i) {
        this.$r8$classId = i;
        this.f$2 = str;
        this.f$0 = obj;
        this.f$1 = obj2;
    }
}
