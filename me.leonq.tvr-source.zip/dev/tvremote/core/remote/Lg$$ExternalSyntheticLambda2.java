package dev.tvremote.core.remote;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.ConsumerIrManager;
import android.net.Network;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.B64;
import dev.tvremote.core.Census$$ExternalSyntheticLambda4;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Errors;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.FleetStatus;
import dev.tvremote.core.SupportRelay;
import dev.tvremote.core.WireLog;
import dev.tvremote.core.Words;
import dev.tvremote.core.Words$$ExternalSyntheticLambda1;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.AdbPrompt;
import dev.tvremote.core.adb.AdbTls;
import dev.tvremote.core.adb.Mdns;
import dev.tvremote.core.ontv.SetupNeed;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.remote.Inputs;
import dev.tvremote.core.remote.Lg;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.core.web.HttpServer;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda5;
import dev.tvremote.phone.ListenService;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda15;
import dev.tvremote.phone.WorkService;
import dev.tvremote.phone.ir.Ir$Signal;
import dev.tvremote.phone.ir.IrRemoteKt;
import dev.tvremote.phone.ir.IrRemoteKt$$ExternalSyntheticLambda2;
import dev.tvremote.phone.ir.IrRemoteKt$$ExternalSyntheticLambda22;
import dev.tvremote.phone.manage.UpdaterKt;
import dev.tvremote.phone.media.PlayingBar;
import dev.tvremote.phone.picker.AdbHelpKt;
import dev.tvremote.phone.picker.AppRow;
import dev.tvremote.phone.picker.NetKt$$ExternalSyntheticLambda1;
import dev.tvremote.phone.picker.PickerScreenKt;
import dev.tvremote.phone.picker.SetupNews;
import dev.tvremote.phone.picker.TvStatus;
import dev.tvremote.phone.picker.TvStatusKt;
import dev.tvremote.phone.ui.DlApp;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.phone.ui.UiKt;
import dev.tvremote.update.Release;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicInteger;
import javax.net.ssl.SSLSocket;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$BooleanRef;
import kotlin.jvm.internal.Ref$IntRef;
import kotlin.jvm.internal.Ref$ObjectRef;
import kotlin.math.MathKt;
import kotlin.text.Charsets;
import kotlin.text.Regex$$ExternalSyntheticLambda0;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.conscrypt.FileClientSessionCache;
import org.conscrypt.metrics.ConscryptStatsLog;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class Lg$$ExternalSyntheticLambda2 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;
    public final /* synthetic */ Object f$1;
    public final /* synthetic */ Object f$2;

    public /* synthetic */ Lg$$ExternalSyntheticLambda2(Object obj, Object obj2, Object obj3, int i) {
        this.$r8$classId = i;
        this.f$0 = obj;
        this.f$1 = obj2;
        this.f$2 = obj3;
    }

    private final void run$dev$tvremote$phone$picker$AdbHelpKt$$ExternalSyntheticLambda62() {
        int i = ((Ref$IntRef) this.f$2).element;
        String str = (String) this.f$1;
        AdbTls adbTls = AdbTls.INSTANCE;
        MainActivity mainActivity = (MainActivity) this.f$0;
        File filesDir = mainActivity.getFilesDir();
        Intrinsics.checkNotNullExpressionValue(filesDir, "getFilesDir(...)");
        adbTls.save(filesDir, str, i);
        mainActivity.adbFailed.remove(str);
        String str2 = mainActivity.entry;
        mainActivity.disconnect$android_release(null);
        mainActivity.connect$android_release(str, str2);
    }

    /* JADX WARN: Type inference failed for: r4v0, types: [kotlin.jvm.internal.Ref$BooleanRef, java.lang.Object] */
    private final void run$dev$tvremote$phone$picker$AdbHelpKt$$ExternalSyntheticLambda66() {
        Remote remote = (Remote) this.f$0;
        MainActivity mainActivity = (MainActivity) this.f$1;
        ?? obj = new Object();
        try {
            if (remote.getApp().length() == 0) {
                remote.launch((String) UiKt.HOME_APP.pkg);
                obj.element = true;
            } else {
                obj.element = AdbHelpKt.openOnTv(mainActivity, remote, (String) UiKt.HOME_APP.pkg, false, new Census$$ExternalSyntheticLambda4(18));
            }
        } catch (Exception unused) {
        } catch (Throwable th) {
            mainActivity.tvBusy.set(false);
            throw th;
        }
        mainActivity.tvBusy.set(false);
        mainActivity.ui.post(new Vidaa$$ExternalSyntheticLambda3(mainActivity, remote, (Object) obj, (Function0) this.f$2, 8));
    }

    private final void run$dev$tvremote$phone$picker$AdbHelpKt$$ExternalSyntheticLambda8() {
        Object obj;
        MainActivity mainActivity = (MainActivity) this.f$0;
        String str = (String) this.f$1;
        EditText editText = (EditText) this.f$2;
        try {
            List list = (List) AdbTls.discover$default().first;
            Iterator it = list.iterator();
            while (true) {
                if (it.hasNext()) {
                    obj = it.next();
                    if (((Mdns.Service) obj).ip.equals(str)) {
                        break;
                    }
                } else {
                    obj = null;
                    break;
                }
            }
            Mdns.Service service = (Mdns.Service) obj;
            if (service == null) {
                service = (Mdns.Service) CollectionsKt.firstOrNull(list);
            }
            if (service != null) {
                mainActivity.ui.post(new Guard$$ExternalSyntheticLambda5(26, editText, service));
            }
        } catch (Exception unused) {
        }
    }

    private final void run$dev$tvremote$phone$picker$ManyTvsKt$$ExternalSyntheticLambda78() {
        Object obj = ((Ref$ObjectRef) this.f$0).element;
        if (obj != null) {
            if (((Popup) obj).isShowing()) {
                AppRow appRow = (AppRow) this.f$1;
                appRow.getImage().setImageBitmap((Bitmap) this.f$2);
                appRow.getImage().setVisibility(0);
                appRow.getLetter().setVisibility(8);
                return;
            }
            return;
        }
        Intrinsics.throwUninitializedPropertyAccessException("box");
        throw null;
    }

    private final void run$dev$tvremote$phone$picker$PickerScreenKt$$ExternalSyntheticLambda23() {
        String str = (String) this.f$0;
        Network network = (Network) this.f$1;
        if (!MathKt.open(str, 6466, 900, network) && !MathKt.open(str, 5555, 900, network)) {
            return;
        }
        ((IrRemoteKt$$ExternalSyntheticLambda22) this.f$2).invoke(str);
    }

    private final void run$dev$tvremote$phone$picker$SetupBannerKt$$ExternalSyntheticLambda15() {
        MainActivity mainActivity = (MainActivity) this.f$0;
        Exception exc = (Exception) this.f$1;
        Function0 function0 = (Function0) this.f$2;
        if (!mainActivity.isFinishing()) {
            if (exc == null) {
                function0.invoke();
            } else if (!MathKt.offerSetup(mainActivity, exc)) {
                Object obj = Errors.ANDROID;
                ConcurrentHashMap concurrentHashMap = Words.books;
                Toast.makeText(mainActivity, Errors.say(Words.lang, exc), 1).show();
            }
        }
    }

    private final void run$dev$tvremote$phone$picker$SetupBannerKt$$ExternalSyntheticLambda6() {
        MainActivity mainActivity = (MainActivity) this.f$0;
        if (mainActivity.isFinishing()) {
            return;
        }
        HashMap hashMap = mainActivity.setupNews;
        SetupNews setupNews = (SetupNews) this.f$1;
        String str = (String) this.f$2;
        if (setupNews == null) {
            hashMap.remove(str);
        } else {
            hashMap.put(str, setupNews);
        }
        MathKt.showSetup(mainActivity, str);
    }

    private final void run$dev$tvremote$phone$picker$SetupBannerKt$$ExternalSyntheticLambda7() {
        Adb adb;
        Tv tv = (Tv) this.f$0;
        MainActivity mainActivity = (MainActivity) this.f$1;
        Function0 function0 = (Function0) this.f$2;
        try {
            LinkedHashMap linkedHashMap = SetupNeed.MIN;
            adb = tv.adb;
        } catch (Exception e) {
            e = e;
        }
        if (adb != null) {
            SetupNeed.check(adb, "pic");
            e = null;
            mainActivity.ui.post(new Lg$$ExternalSyntheticLambda2(mainActivity, e, function0, 23));
            return;
        }
        throw new IOException("no TV");
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [java.util.List, java.lang.Object] */
    private final void run$dev$tvremote$phone$picker$TvStatusKt$$ExternalSyntheticLambda10() {
        MainActivity mainActivity = (MainActivity) this.f$0;
        ?? r1 = this.f$1;
        ArrayList arrayList = (ArrayList) this.f$2;
        if (!mainActivity.isFinishing()) {
            for (FleetStatus.Status status : r1) {
                if (!Intrinsics.areEqual(status.state, "unknown")) {
                    TvStatus.last.put(status.host, status);
                }
            }
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                String str = (String) it.next();
                PickerScreenKt.showReach(mainActivity, str, (Boolean) mainActivity.reach.get(str));
            }
            TvStatusKt.showThumbs(mainActivity);
            if (mainActivity.host == null) {
                mainActivity.ui.removeCallbacks(TvStatusKt.getStatusTick(mainActivity));
                mainActivity.ui.postDelayed(TvStatusKt.getStatusTick(mainActivity), 10000L);
                boolean z = TvStatus.shots;
                if (TvStatus.shots) {
                    mainActivity.ui.removeCallbacks(TvStatusKt.getShotTick(mainActivity));
                    mainActivity.ui.post(TvStatusKt.getShotTick(mainActivity));
                }
            }
        }
    }

    private final void run$dev$tvremote$phone$picker$TvStatusKt$$ExternalSyntheticLambda11() {
        TvStatusKt.$r8$lambda$oPFA35vlznG0Zi1vl6HF8mLIEAg((ImageView) this.f$0, (Ref$ObjectRef) this.f$1, (String) this.f$2);
    }

    /* JADX WARN: Type inference failed for: r3v0, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    private final void run$dev$tvremote$phone$picker$TvStatusKt$$ExternalSyntheticLambda4() {
        byte[] bArr;
        Handler handler;
        Lg$$ExternalSyntheticLambda2 lg$$ExternalSyntheticLambda2;
        String str = (String) this.f$0;
        MainActivity mainActivity = (MainActivity) this.f$1;
        ImageView imageView = (ImageView) this.f$2;
        ?? obj = new Object();
        try {
            Semaphore semaphore = TvStatus.gate;
            semaphore.acquire();
            try {
                Triple triple = (Triple) TvStatus.resolve.invoke(str);
                if (triple == null) {
                    semaphore.release();
                    handler = mainActivity.ui;
                    lg$$ExternalSyntheticLambda2 = new Lg$$ExternalSyntheticLambda2(imageView, obj, str, 27);
                } else {
                    String str2 = (String) triple.first;
                    String str3 = (String) triple.second;
                    File file = (File) triple.third;
                    if (!Intrinsics.areEqual(str3, "android")) {
                        semaphore.release();
                        handler = mainActivity.ui;
                        lg$$ExternalSyntheticLambda2 = new Lg$$ExternalSyntheticLambda2(imageView, obj, str, 27);
                    } else {
                        byte[] screen = Fleet.screen(TvStatus.link(file, str, str2).get());
                        if (screen != null) {
                            bArr = Fleet.small(screen);
                        } else {
                            bArr = null;
                        }
                        if (bArr != null) {
                            obj.element = BitmapFactory.decodeByteArray(bArr, 0, bArr.length);
                        }
                        semaphore.release();
                        handler = mainActivity.ui;
                        lg$$ExternalSyntheticLambda2 = new Lg$$ExternalSyntheticLambda2(imageView, obj, str, 27);
                    }
                }
                handler.post(lg$$ExternalSyntheticLambda2);
            } catch (Throwable th) {
                TvStatus.gate.release();
                throw th;
            }
        } catch (Exception unused) {
            mainActivity.ui.post(new Lg$$ExternalSyntheticLambda2(imageView, obj, str, 27));
        } catch (Throwable th2) {
            mainActivity.ui.post(new Lg$$ExternalSyntheticLambda2(imageView, obj, str, 27));
            throw th2;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:151:0x0314 A[Catch: Exception -> 0x0306, TryCatch #15 {Exception -> 0x0306, blocks: (B:134:0x02c0, B:137:0x02dd, B:139:0x02e5, B:142:0x02ef, B:144:0x02f9, B:146:0x02ff, B:149:0x030e, B:151:0x0314, B:155:0x0309, B:157:0x0318, B:161:0x032a, B:163:0x0321, B:167:0x032f, B:171:0x0338, B:173:0x033e, B:175:0x034e, B:178:0x0369), top: B:133:0x02c0 }] */
    /* JADX WARN: Removed duplicated region for block: B:154:0x02f7 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:194:0x03aa  */
    /* JADX WARN: Removed duplicated region for block: B:346:0x07d5  */
    /* JADX WARN: Removed duplicated region for block: B:348:? A[RETURN, SYNTHETIC] */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void run() {
        String read;
        Thread thread;
        SupportRelay supportRelay;
        SupportRelay supportRelay2;
        Thread thread2;
        String str;
        String str2;
        int i;
        JSONArray jSONArray;
        SupportRelay supportRelay3;
        Pair pair;
        String str3;
        String str4;
        Object obj;
        int i2;
        SSLSocket sSLSocket;
        byte[] frame$shared_release;
        boolean z;
        CountDownLatch countDownLatch;
        String read2;
        Pair pair2;
        byte[] bArr;
        JSONArray jSONArray2;
        CountDownLatch countDownLatch2;
        String T;
        String T2;
        String T3;
        String str5 = "getBytes(...)";
        String str6 = "error";
        String str7 = "";
        boolean z2 = true;
        switch (this.$r8$classId) {
            case 0:
                Lg lg = (Lg) this.f$0;
                WebSocket webSocket = (WebSocket) this.f$1;
                Function0 function0 = (Function0) this.f$2;
                lg.getClass();
                while (true) {
                    try {
                        read = webSocket.read();
                    } catch (Exception e) {
                        WireLog.all.add("·", "LG " + lg.host + " read: " + e);
                    }
                    if (read != null) {
                        WireLog.all.add("←", "LG " + lg.host + " " + read);
                        try {
                            JSONObject jSONObject = new JSONObject(read);
                            String optString = jSONObject.optString("id");
                            Function1 function1 = (Function1) lg.subs.get(optString);
                            if (function1 != null) {
                                try {
                                    function1.invoke(jSONObject);
                                } catch (Exception unused) {
                                }
                            }
                            Lg.Pending pending = (Lg.Pending) lg.pending.remove(optString);
                            if (pending != null) {
                                pending.got = jSONObject;
                                pending.done.countDown();
                            }
                        } catch (Exception unused2) {
                        }
                    } else {
                        WireLog.all.add("·", "LG " + lg.host + " closed");
                        boolean z3 = lg.live;
                        lg.live = false;
                        for (Object obj2 : lg.pending.values()) {
                            Intrinsics.checkNotNullExpressionValue(obj2, "next(...)");
                            ((Lg.Pending) obj2).done.countDown();
                        }
                        if (z3 && !lg.closed) {
                            function0.invoke();
                            return;
                        }
                        return;
                    }
                }
                break;
            case 1:
                SupportRelay supportRelay4 = (SupportRelay) this.f$0;
                String str8 = (String) this.f$1;
                String str9 = (String) this.f$2;
                supportRelay4.getClass();
                String str10 = "put(...)";
                Thread currentThread = Thread.currentThread();
                while (supportRelay4.thread == currentThread && System.currentTimeMillis() < supportRelay4.until) {
                    try {
                        String str11 = SupportRelay.base() + "/poll";
                        JSONObject put = new JSONObject().put("code", str8).put("key", str9);
                        Intrinsics.checkNotNullExpressionValue(put, str10);
                        JSONObject post = SupportRelay.post(str11, put);
                        if (post != null && post.has(str6)) {
                            supportRelay = supportRelay4;
                            thread = currentThread;
                            if (supportRelay.thread != thread) {
                                supportRelay.thread = null;
                                supportRelay.until = 0L;
                                supportRelay.store.put("live_until", "0");
                                return;
                            }
                            return;
                        }
                        if (post != null) {
                            if (post.has("live")) {
                                thread2 = currentThread;
                                str2 = str10;
                                supportRelay4.until = SupportRelay.ends(post, supportRelay4.until);
                            } else {
                                thread2 = currentThread;
                                str2 = str10;
                            }
                            JSONArray optJSONArray = post.optJSONArray("asks");
                            if (optJSONArray != null) {
                                i = optJSONArray.length();
                            } else {
                                i = 0;
                            }
                            String str12 = str2;
                            int i3 = 0;
                            while (i3 < i) {
                                Intrinsics.checkNotNull(optJSONArray);
                                int i4 = i;
                                JSONObject jSONObject2 = optJSONArray.getJSONObject(i3);
                                int i5 = i3;
                                String optString2 = jSONObject2.optString("path");
                                try {
                                    NetKt$$ExternalSyntheticLambda1 netKt$$ExternalSyntheticLambda1 = supportRelay4.answer;
                                    Intrinsics.checkNotNull(optString2);
                                    pair = (Pair) netKt$$ExternalSyntheticLambda1.invoke(optString2);
                                    supportRelay3 = supportRelay4;
                                    jSONArray = optJSONArray;
                                } catch (Exception e2) {
                                    String message = e2.getMessage();
                                    if (message == null) {
                                        message = e2.getClass().getSimpleName();
                                    }
                                    jSONArray = optJSONArray;
                                    String str13 = message;
                                    supportRelay3 = supportRelay4;
                                    pair = new Pair(0, str13);
                                }
                                int intValue = ((Number) pair.first).intValue();
                                String s = (String) pair.second;
                                Intrinsics.checkNotNull(optString2);
                                String str14 = str6;
                                boolean contains = StringsKt.contains(optString2, "log", false);
                                Intrinsics.checkNotNullParameter(s, "s");
                                while (true) {
                                    String quote = JSONObject.quote(s);
                                    boolean z4 = contains;
                                    Intrinsics.checkNotNullExpressionValue(quote, "quote(...)");
                                    byte[] bytes = quote.getBytes(Charsets.UTF_8);
                                    Intrinsics.checkNotNullExpressionValue(bytes, str5);
                                    if (bytes.length > 200000) {
                                        if (z4) {
                                            s = StringsKt.takeLast(s, (s.length() * 4) / 5);
                                        } else {
                                            s = StringsKt.take(s, (s.length() * 4) / 5);
                                        }
                                        contains = z4;
                                    } else {
                                        WireLog wireLog = WireLog.all;
                                        String take = StringsKt.take(optString2, 120);
                                        StringBuilder sb = new StringBuilder();
                                        String str15 = str5;
                                        sb.append("support GET ");
                                        sb.append(take);
                                        sb.append(" -> ");
                                        sb.append(intValue);
                                        wireLog.add("·", sb.toString());
                                        JSONObject put2 = new JSONObject().put("code", str8).put("key", str9).put("id", jSONObject2.optInt("id")).put("status", intValue).put("body", s);
                                        String str16 = SupportRelay.base() + "/answer";
                                        Intrinsics.checkNotNull(put2);
                                        JSONObject post2 = SupportRelay.post(str16, put2);
                                        if (post2 == null) {
                                            Thread.sleep(2000L);
                                            post2 = SupportRelay.post(SupportRelay.base() + "/answer", put2);
                                        }
                                        if (post2 != null) {
                                            str3 = str14;
                                            if (!post2.has(str3)) {
                                                str4 = str12;
                                                str6 = str3;
                                                str12 = str4;
                                                i = i4;
                                                optJSONArray = jSONArray;
                                                supportRelay4 = supportRelay3;
                                                str5 = str15;
                                                i3 = i5 + 1;
                                            }
                                        } else {
                                            str3 = str14;
                                        }
                                        String str17 = SupportRelay.base() + "/answer";
                                        JSONObject put3 = new JSONObject().put("code", str8).put("key", str9).put("id", jSONObject2.optInt("id")).put("status", 0).put("body", "answer not delivered (" + intValue + ", " + s.length() + " chars)");
                                        str4 = str12;
                                        Intrinsics.checkNotNullExpressionValue(put3, str4);
                                        SupportRelay.post(str17, put3);
                                        str6 = str3;
                                        str12 = str4;
                                        i = i4;
                                        optJSONArray = jSONArray;
                                        supportRelay4 = supportRelay3;
                                        str5 = str15;
                                        i3 = i5 + 1;
                                    }
                                }
                            }
                            supportRelay2 = supportRelay4;
                            str = str12;
                        } else {
                            supportRelay2 = supportRelay4;
                            thread2 = currentThread;
                            str = str10;
                        }
                        String str18 = str5;
                        String str19 = str6;
                        Thread.sleep(2000L);
                        str6 = str19;
                        str10 = str;
                        currentThread = thread2;
                        supportRelay4 = supportRelay2;
                        str5 = str18;
                    } catch (InterruptedException unused3) {
                        return;
                    }
                }
                thread = currentThread;
                supportRelay = supportRelay4;
                if (supportRelay.thread != thread) {
                }
                break;
            case 2:
                Iterator it = ((Iterable) ((Function1) this.f$1).invoke("_adb-tls-pairing._tcp")).iterator();
                while (true) {
                    if (it.hasNext()) {
                        Object next = it.next();
                        AdbTls adbTls = AdbTls.INSTANCE;
                        if (AdbTls.same((String) this.f$2, ((Mdns.Service) next).ip)) {
                            obj = next;
                        }
                    } else {
                        obj = null;
                    }
                }
                Mdns.Service service = (Mdns.Service) obj;
                if (service != null) {
                    i2 = service.port;
                } else {
                    i2 = 0;
                }
                ((Ref$IntRef) this.f$0).element = i2;
                return;
            case 3:
                Tv tv = (Tv) this.f$0;
                Adb.Stream stream = (Adb.Stream) this.f$1;
                try {
                    Object obj3 = ((Ref$ObjectRef) this.f$2).element;
                    Intrinsics.checkNotNull(obj3);
                    tv.hear(stream, (String) obj3);
                    return;
                } catch (Throwable unused4) {
                    return;
                }
            case 4:
                Tv tv2 = (Tv) this.f$0;
                Adb adb = (Adb) this.f$1;
                Adb.Stream stream2 = (Adb.Stream) this.f$2;
                try {
                    Thread.sleep(8000L);
                    if (!tv2.stopped && !tv2.framed) {
                        if (tv2.encoders(adb) == null) {
                            tv2.status("error", "encoders: the TV did not list its video encoders");
                            stream2.close();
                            return;
                        }
                        String softFor = tv2.softFor(adb);
                        if (softFor != null && !tv2.stopped && !tv2.framed) {
                            WireLog.all.add("·", Census$$ExternalSyntheticOutline0.m("picture ", tv2.host, " no frame from the hardware encoder: ", softFor));
                            Tv.softEncoder.put(tv2.host, softFor);
                            tv2.stalled = true;
                            stream2.close();
                            return;
                        }
                        return;
                    }
                    return;
                } catch (InterruptedException unused5) {
                    return;
                }
            case 5:
                String str20 = (String) this.f$2;
                JSONObject jSONObject3 = (JSONObject) this.f$0;
                boolean areEqual = Intrinsics.areEqual(jSONObject3.optString("a"), "move");
                Tv tv3 = (Tv) this.f$1;
                if (!areEqual || (jSONObject3 = (JSONObject) tv3.pendingMove.getAndSet(null)) != null) {
                    try {
                        AdbPrompt adbPrompt = AdbPrompt.INSTANCE;
                        HttpURLConnection openSetup = AdbPrompt.openSetup(tv3.host, str20, "/api/touch");
                        openSetup.setReadTimeout(5000);
                        openSetup.setRequestMethod("POST");
                        openSetup.setDoOutput(true);
                        openSetup.setRequestProperty("Content-Type", "application/json");
                        OutputStream outputStream = openSetup.getOutputStream();
                        try {
                            String jSONObject4 = jSONObject3.toString();
                            Intrinsics.checkNotNullExpressionValue(jSONObject4, "toString(...)");
                            byte[] bytes2 = jSONObject4.getBytes(Charsets.UTF_8);
                            Intrinsics.checkNotNullExpressionValue(bytes2, "getBytes(...)");
                            outputStream.write(bytes2);
                            outputStream.close();
                            openSetup.getResponseCode();
                            openSetup.getInputStream().close();
                            return;
                        } finally {
                        }
                    } catch (Exception unused6) {
                        return;
                    }
                } else {
                    return;
                }
            case 6:
                Atv atv = (Atv) this.f$0;
                Ref$ObjectRef ref$ObjectRef = (Ref$ObjectRef) this.f$1;
                Function0 function02 = (Function0) this.f$2;
                while (true) {
                    try {
                        Object obj4 = ref$ObjectRef.element;
                        sSLSocket = (SSLSocket) obj4;
                        InputStream inputStream = ((SSLSocket) obj4).getInputStream();
                        Intrinsics.checkNotNullExpressionValue(inputStream, "getInputStream(...)");
                        frame$shared_release = Fleet.frame$shared_release(inputStream);
                    } catch (Exception e3) {
                        WireLog.all.add("·", "remote " + atv.host + " " + e3);
                    }
                    if (frame$shared_release != null) {
                        atv.handle(sSLSocket, frame$shared_release);
                    } else {
                        WireLog.all.add("·", "remote " + atv.host + " dropped, dialling again");
                        atv.live = false;
                        try {
                            ((SSLSocket) ref$ObjectRef.element).close();
                        } catch (Exception unused7) {
                        }
                        SSLSocket sSLSocket2 = null;
                        for (int i6 = 0; i6 < 4 && !atv.closed; i6++) {
                            try {
                                Thread.sleep(600L);
                            } catch (InterruptedException unused8) {
                            }
                            try {
                                sSLSocket2 = atv.open();
                            } catch (Exception unused9) {
                                sSLSocket2 = null;
                            }
                            if (sSLSocket2 == null) {
                            }
                        }
                        if (sSLSocket2 != null && atv.closed) {
                            try {
                                sSLSocket2.close();
                            } catch (Exception unused10) {
                            }
                        } else if (sSLSocket2 != null) {
                            ref$ObjectRef.element = sSLSocket2;
                        }
                    }
                }
                if (!atv.closed) {
                    WireLog.all.add("·", "remote " + atv.host + " gone");
                    function02.invoke();
                    return;
                }
                return;
            case 7:
                Samsung samsung = (Samsung) this.f$0;
                WebSocket webSocket2 = (WebSocket) this.f$1;
                Function0 function03 = (Function0) this.f$2;
                samsung.getClass();
                while (true) {
                    try {
                        read2 = webSocket2.read();
                    } catch (Exception e4) {
                        e = e4;
                    }
                    if (read2 != null) {
                        try {
                            WireLog.all.add("←", "Samsung " + samsung.host + " " + read2);
                            try {
                                JSONObject jSONObject5 = new JSONObject(read2);
                                String optString3 = jSONObject5.optString("event");
                                if (optString3 != null) {
                                    switch (optString3.hashCode()) {
                                        case -1547647002:
                                            if (optString3.equals("ed.apps.icon")) {
                                                JSONObject optJSONObject = jSONObject5.optJSONObject("data");
                                                if (optJSONObject != null && (pair2 = (Pair) samsung.iconWait.remove(optJSONObject.optString("iconPath"))) != null) {
                                                    CountDownLatch countDownLatch3 = (CountDownLatch) pair2.first;
                                                    byte[][] bArr2 = (byte[][]) pair2.second;
                                                    try {
                                                        int[] iArr = B64.INDEX;
                                                        String optString4 = optJSONObject.optString("imageBase64");
                                                        Intrinsics.checkNotNullExpressionValue(optString4, "optString(...)");
                                                        bArr = B64.decode(optString4);
                                                    } catch (Exception unused11) {
                                                        bArr = null;
                                                    }
                                                    bArr2[0] = bArr;
                                                    countDownLatch3.countDown();
                                                    break;
                                                }
                                            } else {
                                                continue;
                                            }
                                            break;
                                        case -904743551:
                                            if (!optString3.equals("ms.remote.imeStart")) {
                                                break;
                                            }
                                            break;
                                        case -188664390:
                                            if (!optString3.equals("ms.remote.imeEnd")) {
                                                break;
                                            }
                                            break;
                                        case 661104286:
                                            if (optString3.equals("ed.installedApp.get")) {
                                                JSONObject optJSONObject2 = jSONObject5.optJSONObject("data");
                                                if (optJSONObject2 != null) {
                                                    jSONArray2 = optJSONObject2.optJSONArray("data");
                                                    if (jSONArray2 == null) {
                                                    }
                                                    samsung.appsGot = jSONArray2;
                                                    countDownLatch2 = samsung.appsWait;
                                                    if (countDownLatch2 == null) {
                                                        countDownLatch2.countDown();
                                                        break;
                                                    } else {
                                                        break;
                                                    }
                                                }
                                                jSONArray2 = new JSONArray();
                                                samsung.appsGot = jSONArray2;
                                                countDownLatch2 = samsung.appsWait;
                                                if (countDownLatch2 == null) {
                                                }
                                            } else {
                                                continue;
                                            }
                                    }
                                    samsung.keyboardNew = true;
                                    samsung.typed = "";
                                }
                            } catch (Exception unused12) {
                            }
                        } catch (Exception e5) {
                            e = e5;
                            WireLog.all.add("·", "Samsung " + samsung.host + " read: " + e);
                            WireLog.all.add("·", "Samsung " + samsung.host + " closed");
                            z = samsung.live;
                            samsung.live = false;
                            countDownLatch = samsung.appsWait;
                            if (countDownLatch != null) {
                            }
                            if (!z) {
                                return;
                            } else {
                                return;
                            }
                        }
                    } else {
                        WireLog.all.add("·", "Samsung " + samsung.host + " closed");
                        z = samsung.live;
                        samsung.live = false;
                        countDownLatch = samsung.appsWait;
                        if (countDownLatch != null) {
                            countDownLatch.countDown();
                        }
                        if (!z && !samsung.closed) {
                            function03.invoke();
                            return;
                        }
                        return;
                    }
                }
                break;
            case 8:
                HttpServer httpServer = (HttpServer) this.f$0;
                Semaphore semaphore = httpServer.slots;
                Socket socket = (Socket) this.f$1;
                AtomicInteger atomicInteger = (AtomicInteger) this.f$2;
                try {
                    httpServer.serve(socket);
                    if (atomicInteger != null) {
                        return;
                    } else {
                        return;
                    }
                } finally {
                    semaphore.release();
                    if (atomicInteger != null) {
                        atomicInteger.decrementAndGet();
                    }
                }
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                if (((MainActivity) this.f$0).allowBox != null) {
                    String str21 = (String) this.f$2;
                    if (str21.equals("allowed")) {
                        T = Fleet.T("phone.tv_setup_allowed_it", new Pair[0]);
                    } else if (str21.equals("forgotten")) {
                        T = Fleet.T("phone.tv_setup_has_unpaired", new Pair[0]);
                    } else if (str21.equals("unreachable")) {
                        T = Fleet.T("phone.could_not_reach_tv", new Pair[0]);
                    } else if (StringsKt__StringsJVMKt.startsWith(str21, false, "other:")) {
                        T = Fleet.T("phone.the_tv_is_asking", new Pair[0]);
                    } else {
                        T = Fleet.T("phone.tv_setup_could_not", new Pair[0]);
                    }
                    ((TextView) this.f$1).setText(T);
                    return;
                }
                return;
            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                ConsumerIrManager consumerIrManager = (ConsumerIrManager) this.f$0;
                Ir$Signal ir$Signal = (Ir$Signal) this.f$1;
                try {
                    consumerIrManager.transmit(IrRemoteKt.nearest(consumerIrManager, ir$Signal.hz), (int[]) ir$Signal.pattern);
                    return;
                } catch (Exception e6) {
                    Log.w("TvrIr", "transmit failed", e6);
                    MainActivity mainActivity = (MainActivity) this.f$2;
                    mainActivity.ui.post(new MainActivity$$ExternalSyntheticLambda15(mainActivity, 9));
                    return;
                }
            case 11:
                String str22 = (String) this.f$0;
                MainActivity mainActivity2 = (MainActivity) this.f$1;
                if (str22 == null) {
                    UpdaterKt.progress(mainActivity2, Fleet.T("updater.waiting_for_android_to", new Pair[0]));
                    return;
                }
                mainActivity2.updating = false;
                UpdaterKt.showUpdate(mainActivity2);
                UpdaterKt.failed(mainActivity2, (Release) this.f$2, Fleet.T("updater.could_not_update", new Pair("error", str22)));
                return;
            case FileClientSessionCache.MAX_SIZE /* 12 */:
                MainActivity mainActivity3 = (MainActivity) this.f$0;
                if (!mainActivity3.isFinishing()) {
                    Remote remote = mainActivity3.basic;
                    Remote remote2 = (Remote) this.f$1;
                    if (remote == remote2) {
                        String T4 = Fleet.T("rkey.open_apps", new Pair[0]);
                        List<Remote.App> list = (List) this.f$2;
                        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(list));
                        for (Remote.App app : list) {
                            arrayList.add(new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@play|", app.label), "", new Regex$$ExternalSyntheticLambda0(12, remote2, app)));
                        }
                        UiKt.menu(mainActivity3, T4, -1, arrayList);
                        return;
                    }
                    return;
                }
                return;
            case 13:
                Exception exc = (Exception) this.f$1;
                if (exc != null) {
                    T2 = Fleet.T("now_playing.this_tv_cannot_turn", new Pair[0]);
                } else if (((Ref$BooleanRef) this.f$2).element) {
                    T2 = Fleet.T("playing.screen_on", new Pair[0]);
                } else {
                    T2 = Fleet.T("playing.screen_off", new Pair[0]);
                }
                if (exc == null) {
                    z2 = false;
                }
                Fleet.say((MainActivity) this.f$0, T2, z2);
                return;
            case 14:
                PlayingBar playingBar = (PlayingBar) this.f$0;
                View view = (View) this.f$1;
                Ref$BooleanRef ref$BooleanRef = (Ref$BooleanRef) this.f$2;
                playingBar.busy = false;
                playingBar.mark(view, false);
                if (ref$BooleanRef.element) {
                    Fleet.say(playingBar.a, Fleet.T("now_playing.the_tv_did_not", new Pair[0]), true);
                    return;
                }
                WorkService.Companion companion = ListenService.Companion;
                JSONObject jSONObject6 = playingBar.o;
                MainActivity mainActivity4 = playingBar.a;
                String str23 = mainActivity4.host;
                if (str23 != null) {
                    str7 = str23;
                }
                WorkService.Companion.show(mainActivity4.title$android_release(str7), jSONObject6);
                return;
            case 15:
                ((Popup) this.f$0).dismiss();
                DlApp dlApp = UiKt.SETUP_APP;
                MainActivity mainActivity5 = (MainActivity) this.f$1;
                if (((DlApp) this.f$2) == dlApp) {
                    AdbHelpKt.installSetupByHand(mainActivity5);
                    return;
                } else {
                    AdbHelpKt.otherHome(mainActivity5);
                    return;
                }
            case 16:
                Popup popup = (Popup) this.f$0;
                if (popup.isShowing()) {
                    popup.setMessage(Fleet.T("adb_help.step_3", new Pair("step", Integer.valueOf(((Ref$IntRef) this.f$1).element)), new Pair("msg", Fleet.T((String) this.f$2, new Pair[0]))));
                    return;
                }
                return;
            case 17:
                run$dev$tvremote$phone$picker$AdbHelpKt$$ExternalSyntheticLambda62();
                return;
            case 18:
                run$dev$tvremote$phone$picker$AdbHelpKt$$ExternalSyntheticLambda66();
                return;
            case 19:
                run$dev$tvremote$phone$picker$AdbHelpKt$$ExternalSyntheticLambda8();
                return;
            case 20:
                run$dev$tvremote$phone$picker$ManyTvsKt$$ExternalSyntheticLambda78();
                return;
            case 21:
                List list2 = Ssdp.SEARCH;
                Ssdp.find(3000, new Words$$ExternalSyntheticLambda1(17, (Network) this.f$0), new IrRemoteKt$$ExternalSyntheticLambda2(1 == true ? 1 : 0, (MainActivity) this.f$2, (List) this.f$1));
                return;
            case 22:
                run$dev$tvremote$phone$picker$PickerScreenKt$$ExternalSyntheticLambda23();
                return;
            case 23:
                run$dev$tvremote$phone$picker$SetupBannerKt$$ExternalSyntheticLambda15();
                return;
            case 24:
                run$dev$tvremote$phone$picker$SetupBannerKt$$ExternalSyntheticLambda6();
                return;
            case 25:
                run$dev$tvremote$phone$picker$SetupBannerKt$$ExternalSyntheticLambda7();
                return;
            case 26:
                run$dev$tvremote$phone$picker$TvStatusKt$$ExternalSyntheticLambda10();
                return;
            case 27:
                run$dev$tvremote$phone$picker$TvStatusKt$$ExternalSyntheticLambda11();
                return;
            case 28:
                run$dev$tvremote$phone$picker$TvStatusKt$$ExternalSyntheticLambda4();
                return;
            default:
                MainActivity mainActivity6 = (MainActivity) this.f$0;
                if (!mainActivity6.isFinishing()) {
                    if (((Exception) this.f$1) == null) {
                        T3 = Fleet.T("remote.switched_to", new Pair("name", ((Inputs.Input) this.f$2).label));
                    } else {
                        T3 = Fleet.T("inputs_menu.the_tv_did_not", new Pair[0]);
                    }
                    Toast.makeText(mainActivity6, T3, 0).show();
                    return;
                }
                return;
        }
    }
}
