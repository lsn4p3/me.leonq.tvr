package dev.tvremote.core.remote;

import android.widget.Toast;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.remote.Inputs;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.core.scenes.Scenes;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda10;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda38;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda9;
import dev.tvremote.phone.ir.IrRemoteKt;
import dev.tvremote.phone.manage.Managing;
import dev.tvremote.phone.media.MediaKt$$ExternalSyntheticLambda9;
import dev.tvremote.phone.media.NowApp$tick$1$$ExternalSyntheticLambda0;
import dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda3;
import dev.tvremote.phone.picker.Part;
import dev.tvremote.phone.picture.Air;
import dev.tvremote.phone.remote.InputsMenuKt;
import dev.tvremote.phone.remote.KeysOnlyKt$$ExternalSyntheticLambda3;
import dev.tvremote.phone.remote.PhoneRemoteKt;
import dev.tvremote.phone.remote.TypingKt;
import dev.tvremote.phone.ui.IconButton;
import dev.tvremote.phone.ui.UiKt;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.CollectionsKt__MutableCollectionsKt;
import kotlin.collections.EmptyList;
import kotlin.collections.EmptySet;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgression;
import kotlin.ranges.IntProgressionIterator;
import kotlin.text.StringsKt;
import org.conscrypt.FileClientSessionCache;
import org.conscrypt.metrics.ConscryptStatsLog;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class Vidaa$$ExternalSyntheticLambda0 implements Function2 {
    public final /* synthetic */ int $r8$classId;

    public /* synthetic */ Vidaa$$ExternalSyntheticLambda0(int i) {
        this.$r8$classId = i;
    }

    /* JADX WARN: Removed duplicated region for block: B:118:0x0308  */
    /* JADX WARN: Type inference failed for: r2v55, types: [java.util.Map, java.lang.Object] */
    @Override // kotlin.jvm.functions.Function2
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object invoke(Object obj, Object obj2) {
        Iterable iterable;
        Tv tv;
        Tv tv2;
        boolean z;
        String str;
        Object obj3;
        Object putIfAbsent;
        String str2;
        int i = 12;
        int i2 = 16;
        int i3 = 6;
        int i4 = -1;
        int i5 = 2;
        String str3 = null;
        String str4 = null;
        Remote remote = null;
        str3 = null;
        int i6 = 0;
        int i7 = 1;
        switch (this.$r8$classId) {
            case 0:
                String mac = (String) obj;
                String lan = (String) obj2;
                Intrinsics.checkNotNullParameter(mac, "mac");
                Intrinsics.checkNotNullParameter(lan, "lan");
                StringBuilder sb = new StringBuilder();
                int length = mac.length();
                for (int i8 = 0; i8 < length; i8++) {
                    char charAt = mac.charAt(i8);
                    if (Character.isLetterOrDigit(charAt)) {
                        sb.append(charAt);
                    }
                }
                String sb2 = sb.toString();
                if (sb2.length() == 12) {
                    ArrayList chunked = StringsKt.chunked(sb2, 2);
                    ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(chunked));
                    Iterator it = chunked.iterator();
                    while (it.hasNext()) {
                        String str5 = (String) it.next();
                        MathKt.checkRadix(16);
                        arrayList.add(Byte.valueOf((byte) Integer.parseInt(str5, 16)));
                    }
                    byte[] byteArray = CollectionsKt.toByteArray(arrayList);
                    byte[] bArr = new byte[6];
                    for (int i9 = 0; i9 < 6; i9++) {
                        bArr[i9] = -1;
                    }
                    IntProgression intProgression = new IntProgression(1, 16, 1);
                    ArrayList arrayList2 = new ArrayList();
                    Iterator it2 = intProgression.iterator();
                    while (((IntProgressionIterator) it2).hasNext) {
                        ((IntProgressionIterator) it2).nextInt();
                        CollectionsKt__MutableCollectionsKt.addAll(ArraysKt.toList(byteArray), arrayList2);
                    }
                    byte[] copyOf = Arrays.copyOf(bArr, arrayList2.size() + 6);
                    Iterator it3 = arrayList2.iterator();
                    while (it3.hasNext()) {
                        copyOf[i3] = ((Number) it3.next()).byteValue();
                        i3++;
                    }
                    Intrinsics.checkNotNull(copyOf);
                    List listOf = MathKt.listOf("255.255.255.255");
                    int i10 = 0;
                    for (int i11 = 0; i11 < lan.length(); i11++) {
                        if (lan.charAt(i11) == '.') {
                            i10++;
                        }
                    }
                    if (i10 == 3) {
                        iterable = MathKt.listOf(StringsKt.substringBeforeLast(lan, '.', lan).concat(".255"));
                    } else {
                        iterable = EmptyList.INSTANCE;
                    }
                    ArrayList plus = CollectionsKt.plus(listOf, iterable);
                    DatagramSocket datagramSocket = new DatagramSocket();
                    try {
                        datagramSocket.setBroadcast(true);
                        Iterator it4 = plus.iterator();
                        while (it4.hasNext()) {
                            String str6 = (String) it4.next();
                            Iterator it5 = ArraysKt.asList(new Integer[]{9, 7}).iterator();
                            while (it5.hasNext()) {
                                int intValue = ((Number) it5.next()).intValue();
                                for (int i12 = 0; i12 < 3; i12++) {
                                    try {
                                        datagramSocket.send(new DatagramPacket(copyOf, copyOf.length, InetAddress.getByName(str6), intValue));
                                        Thread.sleep(100L);
                                    } catch (Exception unused) {
                                    }
                                }
                            }
                        }
                        datagramSocket.close();
                    } finally {
                    }
                }
                return Unit.INSTANCE;
            case 1:
                JSONObject jSONObject = (JSONObject) obj;
                JSONObject jSONObject2 = (JSONObject) obj2;
                if (jSONObject.optBoolean("dir") != jSONObject2.optBoolean("dir")) {
                    if (!jSONObject.optBoolean("dir")) {
                        i4 = 1;
                    }
                } else {
                    String optString = jSONObject.optString("name");
                    Intrinsics.checkNotNullExpressionValue(optString, "optString(...)");
                    Locale ROOT = Locale.ROOT;
                    Intrinsics.checkNotNullExpressionValue(ROOT, "ROOT");
                    String lowerCase = optString.toLowerCase(ROOT);
                    Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                    String optString2 = jSONObject2.optString("name");
                    Intrinsics.checkNotNullExpressionValue(optString2, "optString(...)");
                    String lowerCase2 = optString2.toLowerCase(ROOT);
                    Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
                    i4 = lowerCase.compareTo(lowerCase2);
                }
                return Integer.valueOf(i4);
            case 2:
                AdbLink link = (AdbLink) obj;
                Intrinsics.checkNotNullParameter(link, "link");
                Intrinsics.checkNotNullParameter((Part) obj2, "<unused var>");
                Adb adb = link.get();
                adb.shell(15000L, "case \"$(settings get secure always_on_vpn_app)\" in com.tailscale.ipn) ;; *) pm path com.tailscale.ipn >/dev/null 2>&1 && ip addr | grep -qE 'inet 100\\.(6[4-9]|[7-9][0-9]|1[01][0-9]|12[0-7])\\.' && { settings put secure always_on_vpn_app com.tailscale.ipn; settings put secure always_on_vpn_lockdown 0; };; esac; echo ok");
                try {
                    Adb.Stream open = adb.open(10000L, "reboot:");
                    try {
                        open.readAll(3000L);
                        open.close();
                    } finally {
                    }
                } catch (Exception unused2) {
                }
                return Fleet.T("many_tvs.restarting", new Pair[0]);
            case 3:
                MainActivity act = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act, "$this$act");
                if (!act.needsAdb$android_release()) {
                    Tv tv3 = act.tv;
                    if (tv3 != null && tv3.ready()) {
                        IconButton iconButton = act.shotBtn;
                        if (iconButton == null || !iconButton.getBusy()) {
                            if (iconButton != null) {
                                iconButton.setBusy(true);
                            }
                            Toast.makeText(act, Fleet.T("remote_screen.taking_a_screenshot_of", new Pair[0]), 0).show();
                            new Thread(new KeysOnlyKt$$ExternalSyntheticLambda3(tv3, act, iconButton)).start();
                        }
                    } else {
                        Toast.makeText(act, Fleet.T("errors.still_connecting_tv_over", new Pair[0]), 0).show();
                    }
                }
                return Unit.INSTANCE;
            case 4:
                MainActivity act2 = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act2, "$this$act");
                Fleet.askText(act2, Fleet.T("remote.turn_off_when", new Pair[0]), Fleet.T("automation.e_g_40_minutes", new Pair[0]), Fleet.T("remote.set_timer", new Pair[0]), "", new MainActivity$$ExternalSyntheticLambda10(act2, 17));
                return Unit.INSTANCE;
            case 5:
                MainActivity act3 = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act3, "$this$act");
                if (act3.live$android_release()) {
                    UiKt.menu(act3, Fleet.T("files.open_on_tv", new Pair[0]), -1, PhoneRemoteKt.remoteMenu$default(act3, "open", null, 6));
                }
                return Unit.INSTANCE;
            case 6:
                MainActivity act4 = (MainActivity) obj;
                String str7 = (String) obj2;
                Intrinsics.checkNotNullParameter(act4, "$this$act");
                if (!act4.needsAdb$android_release()) {
                    Managing managing$android_release = act4.getManaging$android_release();
                    String str8 = act4.host;
                    if (str7 != null) {
                        StringBuilder sb3 = new StringBuilder();
                        int length2 = str7.length();
                        while (i6 < length2) {
                            char charAt2 = str7.charAt(i6);
                            if (Character.isLetter(charAt2)) {
                                sb3.append(charAt2);
                            }
                            i6++;
                        }
                        String sb4 = sb3.toString();
                        if (sb4 != null) {
                            str3 = ApkSigner$$ExternalSyntheticOutline0.m("goTo('auto','", sb4, "')");
                        }
                    }
                    managing$android_release.open(str8, "auto", str3);
                }
                return Unit.INSTANCE;
            case 7:
                MainActivity act5 = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act5, "$this$act");
                if (!act5.needsAdb$android_release() && (tv = act5.tv) != null && tv.ready()) {
                    new Thread(new MainActivity$$ExternalSyntheticLambda38(tv, act5, i5)).start();
                }
                return Unit.INSTANCE;
            case 8:
                MainActivity act6 = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act6, "$this$act");
                Remote remote2 = act6.basic;
                if (remote2 != null) {
                    if (!Intrinsics.areEqual(remote2.getKind(), "android")) {
                        remote = remote2;
                    }
                    if (remote != null) {
                        new Thread(new MediaKt$$ExternalSyntheticLambda9(remote, act6, i7)).start();
                        return Unit.INSTANCE;
                    }
                }
                if (!act6.needsAdb$android_release() && (tv2 = act6.tv) != null && tv2.ready()) {
                    new Thread(new MainActivity$$ExternalSyntheticLambda38(tv2, act6, 3)).start();
                }
                return Unit.INSTANCE;
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                MainActivity act7 = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act7, "$this$act");
                if (!act7.needsAdb$android_release()) {
                    Managing.open$default(act7.getManaging$android_release(), act7.host, null, "fromRemote(dimOpen)", 2);
                }
                return Unit.INSTANCE;
            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                MainActivity act8 = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act8, "$this$act");
                if (!act8.needsAdb$android_release()) {
                    Managing.open$default(act8.getManaging$android_release(), act8.host, null, "fromRemote(videoOpen)", 2);
                }
                return Unit.INSTANCE;
            case 11:
                MainActivity act9 = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act9, "$this$act");
                if (!act9.needsAdb$android_release()) {
                    Managing.open$default(act9.getManaging$android_release(), act9.host, null, "fromRemote(shareDialog)", 2);
                }
                return Unit.INSTANCE;
            case FileClientSessionCache.MAX_SIZE /* 12 */:
                MainActivity act10 = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act10, "$this$act");
                ConcurrentHashMap concurrentHashMap = InputsMenuKt.inputCaches;
                Tv tv4 = act10.tv;
                Remote remote3 = act10.basic;
                if (remote3 != null && !Intrinsics.areEqual(remote3.getKind(), "android")) {
                    List list = Remote.Kind.ALL;
                    if (Remote.Kind.caps(remote3.getKind()).contains("inputs")) {
                        z = true;
                        if (z && (tv4 == null || !tv4.ready())) {
                            TypingKt.opens(178, act10);
                        } else {
                            ConcurrentHashMap concurrentHashMap2 = InputsMenuKt.inputCaches;
                            str = act10.host;
                            if (str == null) {
                                str = "";
                            }
                            obj3 = concurrentHashMap2.get(str);
                            if (obj3 == null && (putIfAbsent = concurrentHashMap2.putIfAbsent(str, (obj3 = new Inputs.Cache()))) != null) {
                                obj3 = putIfAbsent;
                            }
                            new Thread(new NowApp$tick$1$$ExternalSyntheticLambda0((Inputs.Cache) obj3, act10, z, remote3, tv4)).start();
                        }
                        return Unit.INSTANCE;
                    }
                }
                z = false;
                if (z) {
                }
                ConcurrentHashMap concurrentHashMap22 = InputsMenuKt.inputCaches;
                str = act10.host;
                if (str == null) {
                }
                obj3 = concurrentHashMap22.get(str);
                if (obj3 == null) {
                    obj3 = putIfAbsent;
                }
                new Thread(new NowApp$tick$1$$ExternalSyntheticLambda0((Inputs.Cache) obj3, act10, z, remote3, tv4)).start();
                return Unit.INSTANCE;
            case 13:
                MainActivity act11 = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act11, "$this$act");
                if (!Air.mode.equals("mouse") && !Air.airCan(act11)) {
                    Fleet.say(act11, Fleet.T("air.needs_adb", new Pair[0]), true);
                }
                Air.airPick.invoke("mouse");
                return Unit.INSTANCE;
            case 14:
                MainActivity act12 = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act12, "$this$act");
                Fleet.askText(act12, Fleet.T("remote.search_play_store", new Pair[0]), Fleet.T("phone_remote.e_g_vlc", new Pair[0]), Fleet.T("remote.search", new Pair[0]), "", new MainActivity$$ExternalSyntheticLambda10(act12, 13));
                return Unit.INSTANCE;
            case 15:
                MainActivity act13 = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act13, "$this$act");
                if (!act13.needsAdb$android_release()) {
                    TypingKt.gamesPointerOpen(act13);
                }
                return Unit.INSTANCE;
            case 16:
                MainActivity act14 = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act14, "$this$act");
                String str9 = act14.entry;
                if (str9 == null) {
                    str9 = act14.host;
                }
                IrRemoteKt.irOpen(act14, str9);
                return Unit.INSTANCE;
            case 17:
                MainActivity act15 = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act15, "$this$act");
                if (!PhoneRemoteKt.kind(act15).equals("android")) {
                    Remote remote4 = act15.basic;
                    if (remote4 != null) {
                        new Thread(new MediaKt$$ExternalSyntheticLambda9(remote4, act15, i6)).start();
                    }
                } else if (!act15.needsAdb$android_release()) {
                    Managing.open$default(act15.getManaging$android_release(), act15.host, "apps", null, 4);
                }
                return Unit.INSTANCE;
            case 18:
                MainActivity act16 = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act16, "$this$act");
                if (!act16.needsAdb$android_release()) {
                    Managing.open$default(act16.getManaging$android_release(), act16.host, null, null, 6);
                }
                return Unit.INSTANCE;
            case 19:
                MainActivity act17 = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act17, "$this$act");
                if (!act17.needsAdb$android_release()) {
                    act17.getManaging$android_release().open(act17.host, "tv", "fromRemote(homeOpen)");
                }
                return Unit.INSTANCE;
            case 20:
                MainActivity act18 = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act18, "$this$act");
                if (!act18.needsAdb$android_release()) {
                    Tv tv5 = act18.tv;
                    String str10 = act18.host;
                    if (tv5 != null && tv5.ready() && str10 != null) {
                        new Thread(new MainActivity$$ExternalSyntheticLambda9(act18, tv5, str10, 10)).start();
                    }
                }
                return Unit.INSTANCE;
            case 21:
                MainActivity hook = (MainActivity) obj;
                IconButton it6 = (IconButton) obj2;
                Intrinsics.checkNotNullParameter(hook, "$this$hook");
                Intrinsics.checkNotNullParameter(it6, "it");
                hook.drawBtn = it6;
                Air.drawLit(hook);
                return Unit.INSTANCE;
            case 22:
                MainActivity hook2 = (MainActivity) obj;
                IconButton it7 = (IconButton) obj2;
                Intrinsics.checkNotNullParameter(hook2, "$this$hook");
                Intrinsics.checkNotNullParameter(it7, "it");
                hook2.shotBtn = it7;
                return Unit.INSTANCE;
            case 23:
                MainActivity hook3 = (MainActivity) obj;
                IconButton it8 = (IconButton) obj2;
                Intrinsics.checkNotNullParameter(hook3, "$this$hook");
                Intrinsics.checkNotNullParameter(it8, "it");
                hook3.airBtn = it8;
                UiKt.setOn$default(it8, Air.mode.equals("mouse"), 16, 4);
                return Unit.INSTANCE;
            case 24:
                MainActivity act19 = (MainActivity) obj;
                String str11 = (String) obj2;
                Intrinsics.checkNotNullParameter(act19, "$this$act");
                String str12 = (String) PhoneRemoteKt.remoteGroups.get(str11);
                if (str12 != null) {
                    String T = Fleet.T(str12, new Pair[0]);
                    Intrinsics.checkNotNull(str11);
                    if (IrRemoteKt.irAvailable(act19)) {
                        str2 = "ir";
                    } else {
                        str2 = null;
                    }
                    if (!PhoneRemoteKt.kind(act19).equals("android")) {
                        str4 = "native";
                    }
                    String[] strArr = {str2, str4};
                    LinkedHashSet linkedHashSet = new LinkedHashSet();
                    while (i6 < 2) {
                        String str13 = strArr[i6];
                        if (str13 != null) {
                            linkedHashSet.add(str13);
                        }
                        i6++;
                    }
                    UiKt.menu(act19, T, -1, PhoneRemoteKt.remoteMenu$default(act19, str11, linkedHashSet, 4));
                }
                return Unit.INSTANCE;
            case 25:
                MainActivity act20 = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act20, "$this$act");
                Fleet.askText(act20, Fleet.T("remote.package_id", new Pair[0]), "org.videolan.vlc", Fleet.T("apps.open", new Pair[0]), "", new MainActivity$$ExternalSyntheticLambda10(act20, i));
                return Unit.INSTANCE;
            case 26:
                MainActivity act21 = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act21, "$this$act");
                Integer num = (Integer) Scenes.KEYS.get((String) obj2);
                if (num != null) {
                    int intValue2 = num.intValue();
                    if (Tv.OPENERS.contains(num)) {
                        TypingKt.opens(intValue2, act21);
                    } else {
                        int i13 = MainActivity.$r8$clinit;
                        act21.press$android_release(true, intValue2);
                    }
                }
                return Unit.INSTANCE;
            case 27:
                MainActivity act22 = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act22, "$this$act");
                if (!PhoneRemoteKt.kind(act22).equals("android")) {
                    UiKt.menu(act22, Fleet.T("remote.tv_screen", new Pair[0]), -1, PhoneRemoteKt.remoteMenu$default(act22, "timer", null, 6));
                } else if (!act22.needsAdb$android_release()) {
                    MathKt.rules(act22, null, new MainActivity$$ExternalSyntheticLambda10(act22, i2));
                }
                return Unit.INSTANCE;
            case 28:
                MainActivity act23 = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act23, "$this$act");
                UiKt.menu(act23, Fleet.T("remote.scenes", new Pair[0]), -1, PhoneRemoteKt.remoteMenu(act23, "scenes", EmptySet.INSTANCE, MapsKt__MapsKt.mapOf(new Pair("scenes", new AdbHelpKt$$ExternalSyntheticLambda3(act23, 21)))));
                return Unit.INSTANCE;
            default:
                MainActivity act24 = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act24, "$this$act");
                PhoneRemoteKt.trackingMenu(act24);
                return Unit.INSTANCE;
        }
    }
}
