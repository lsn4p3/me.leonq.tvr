package dev.tvremote.core.remote;

import dev.tvremote.core.Fleet;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.ir.IrProfile;
import dev.tvremote.phone.ir.IrRemoteKt;
import java.util.ArrayList;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class Vidaa$$ExternalSyntheticLambda18 implements Function0 {
    public final /* synthetic */ int $r8$classId = 1;
    public final /* synthetic */ Object f$0;
    public final /* synthetic */ Object f$1;
    public final /* synthetic */ int f$2;

    public /* synthetic */ Vidaa$$ExternalSyntheticLambda18(int i, MainActivity mainActivity, ArrayList arrayList) {
        this.f$0 = mainActivity;
        this.f$2 = i;
        this.f$1 = arrayList;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        Object obj = this.f$0;
        Object obj2 = this.f$1;
        int i = this.f$2;
        switch (this.$r8$classId) {
            case 0:
                String ui = ((Vidaa) obj2).ui("authenticationcode");
                String jSONObject = new JSONObject().put("authNum", i).toString();
                Intrinsics.checkNotNullExpressionValue(jSONObject, "toString(...)");
                ((MqttLite) obj).publish(ui, jSONObject);
                return Unit.INSTANCE;
            default:
                ArrayList arrayList = (ArrayList) obj2;
                IrRemoteKt.irAuto$default((MainActivity) obj, Fleet.T("ir.auto_trying", new Pair("n", Integer.valueOf(i + 1)), new Pair("total", Integer.valueOf(arrayList.size()))), IrRemoteKt.getTitle((IrProfile) ((Pair) arrayList.get(i)).first), null, 4);
                return Unit.INSTANCE;
        }
    }

    public /* synthetic */ Vidaa$$ExternalSyntheticLambda18(MqttLite mqttLite, Vidaa vidaa, int i) {
        this.f$0 = mqttLite;
        this.f$1 = vidaa;
        this.f$2 = i;
    }
}
