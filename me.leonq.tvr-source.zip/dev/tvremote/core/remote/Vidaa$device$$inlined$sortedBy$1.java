package dev.tvremote.core.remote;

import java.util.Comparator;
import java.util.Locale;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;

/* loaded from: classes.dex */
public final class Vidaa$device$$inlined$sortedBy$1 implements Comparator {
    public final /* synthetic */ int $r8$classId;

    public /* synthetic */ Vidaa$device$$inlined$sortedBy$1(int i) {
        this.$r8$classId = i;
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x003c  */
    @Override // java.util.Comparator
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final int compare(Object obj, Object obj2) {
        int i;
        int i2;
        String str;
        switch (this.$r8$classId) {
            case 0:
                String str2 = (String) obj;
                Intrinsics.checkNotNull(str2);
                Locale locale = Locale.ROOT;
                String lowerCase = str2.toLowerCase(locale);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                int i3 = 2;
                if (lowerCase.equals("eth0")) {
                    i = 0;
                } else if (lowerCase.equals("wlan0")) {
                    i = 1;
                } else {
                    i = 2;
                }
                Integer valueOf = Integer.valueOf(i);
                String str3 = (String) obj2;
                Intrinsics.checkNotNull(str3);
                String lowerCase2 = str3.toLowerCase(locale);
                Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
                if (lowerCase2.equals("eth0")) {
                    i3 = 0;
                } else if (lowerCase2.equals("wlan0")) {
                    i3 = 1;
                }
                return MathKt.compareValues(valueOf, Integer.valueOf(i3));
            default:
                String str4 = (String) ((Pair) obj).first;
                int i4 = 0;
                if (!StringsKt__StringsJVMKt.endsWith(str4, false, "El.p12")) {
                    String lowerCase3 = str4.toLowerCase(Locale.ROOT);
                    Intrinsics.checkNotNullExpressionValue(lowerCase3, "toLowerCase(...)");
                    if (!StringsKt.contains(lowerCase3, "vidaa", false)) {
                        i2 = 1;
                        Integer valueOf2 = Integer.valueOf(i2);
                        str = (String) ((Pair) obj2).first;
                        if (!StringsKt__StringsJVMKt.endsWith(str, false, "El.p12")) {
                            String lowerCase4 = str.toLowerCase(Locale.ROOT);
                            Intrinsics.checkNotNullExpressionValue(lowerCase4, "toLowerCase(...)");
                            if (!StringsKt.contains(lowerCase4, "vidaa", false)) {
                                i4 = 1;
                            }
                        }
                        return MathKt.compareValues(valueOf2, Integer.valueOf(i4));
                    }
                }
                i2 = 0;
                Integer valueOf22 = Integer.valueOf(i2);
                str = (String) ((Pair) obj2).first;
                if (!StringsKt__StringsJVMKt.endsWith(str, false, "El.p12")) {
                }
                return MathKt.compareValues(valueOf22, Integer.valueOf(i4));
        }
    }
}
