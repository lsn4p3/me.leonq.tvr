package dev.tvremote.core.remote;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticLambda6;
import dev.tvremote.core.Census$$ExternalSyntheticLambda7;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Diagnose$$ExternalSyntheticLambda1;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Lan;
import dev.tvremote.core.WireLog;
import dev.tvremote.core.remote.Inputs;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda5;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$ObjectRef;
import kotlin.math.MathKt;
import kotlin.text.Charsets;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex$$ExternalSyntheticLambda0;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;

/* loaded from: classes.dex */
public final class Roku implements Remote {
    public static final Object KEYS = MapsKt__MapsKt.mapOf(new Pair(19, "Up"), new Pair(20, "Down"), new Pair(21, "Left"), new Pair(22, "Right"), new Pair(23, "Select"), new Pair(66, "Select"), new Pair(4, "Back"), new Pair(3, "Home"), new Pair(82, "Info"), new Pair(165, "Info"), new Pair(85, "Play"), new Pair(126, "Play"), new Pair(127, "Play"), new Pair(89, "Rev"), new Pair(90, "Fwd"), new Pair(88, "InstantReplay"), new Pair(67, "Backspace"), new Pair(84, "Search"), new Pair(24, "VolumeUp"), new Pair(25, "VolumeDown"), new Pair(164, "VolumeMute"), new Pair(166, "ChannelUp"), new Pair(167, "ChannelDown"), new Pair(26, "PowerOff"), new Pair(223, "PowerOff"), new Pair(224, "PowerOn"), new Pair(170, "InputTuner"));
    public static final Set TV_ONLY = SetsKt.setOf((Object[]) new Integer[]{24, 25, 164, 166, 167, 26, 223, 224, 170});
    public volatile String app;
    public volatile boolean closed;
    public final String host;
    public volatile Boolean isOn;
    public volatile boolean live;
    public volatile String mac;
    public volatile String model;
    public final ExecutorService out;
    public volatile boolean tv;
    public volatile String vendor;
    public volatile String version;

    public Roku(File file, String host) {
        Intrinsics.checkNotNullParameter(host, "host");
        this.host = host;
        this.model = "";
        this.vendor = "Roku";
        this.version = "";
        this.app = "";
        this.mac = "";
        this.out = Executors.newSingleThreadExecutor(new Diagnose$$ExternalSyntheticLambda1(4));
    }

    @Override // dev.tvremote.core.remote.Remote
    public final List apps() {
        String fetch = fetch("/query/apps");
        if (fetch == null) {
            fetch = "";
        }
        List parseApps$shared_release = Fleet.parseApps$shared_release(fetch);
        ArrayList arrayList = new ArrayList();
        for (Object obj : parseApps$shared_release) {
            if (Intrinsics.areEqual(((Triple) obj).second, "appl")) {
                arrayList.add(obj);
            }
        }
        ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList));
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            Triple triple = (Triple) it.next();
            Object obj2 = triple.first;
            arrayList2.add(new Remote.App((String) obj2, (String) triple.third, "/query/icon/" + obj2));
        }
        return arrayList2;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        this.closed = true;
        this.live = false;
        this.out.shutdownNow();
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void connect(Function0 function0) {
        String field$shared_release;
        String fetch = fetch("/query/device-info");
        if (fetch != null) {
            WireLog wireLog = WireLog.all;
            String str = this.host;
            Pattern compile = Pattern.compile("\\s+");
            Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
            String replaceAll = compile.matcher(fetch).replaceAll(" ");
            Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
            wireLog.add("←", Census$$ExternalSyntheticOutline0.m("Roku ", str, " device-info ", StringsKt.take(replaceAll, 400)));
            String field$shared_release2 = Fleet.field$shared_release(fetch, "friendly-model-name");
            if (field$shared_release2.length() == 0) {
                field$shared_release2 = Fleet.field$shared_release(fetch, "model-name");
            }
            this.model = field$shared_release2;
            String field$shared_release3 = Fleet.field$shared_release(fetch, "vendor-name");
            if (field$shared_release3.length() == 0) {
                field$shared_release3 = "Roku";
            }
            this.vendor = field$shared_release3;
            this.version = Fleet.field$shared_release(fetch, "software-version");
            if (Fleet.field$shared_release(fetch, "network-type").equals("wifi")) {
                field$shared_release = Fleet.field$shared_release(fetch, "wifi-mac");
                if (field$shared_release.length() == 0) {
                    field$shared_release = Fleet.field$shared_release(fetch, "ethernet-mac");
                }
            } else {
                field$shared_release = Fleet.field$shared_release(fetch, "ethernet-mac");
                if (field$shared_release.length() == 0) {
                    field$shared_release = Fleet.field$shared_release(fetch, "wifi-mac");
                }
            }
            Locale locale = Locale.ROOT;
            String upperCase = field$shared_release.toUpperCase(locale);
            Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
            this.mac = upperCase;
            this.tv = Fleet.field$shared_release(fetch, "is-tv").equals("true");
            String field$shared_release4 = Fleet.field$shared_release(fetch, "power-mode");
            if (field$shared_release4.length() <= 0) {
                field$shared_release4 = null;
            }
            if (field$shared_release4 != null) {
                this.isOn = Boolean.valueOf(field$shared_release4.equals("PowerOn"));
            }
            Set of = SetsKt.setOf((Object[]) new String[]{"limited", "disabled"});
            String lowerCase = Fleet.field$shared_release(fetch, "ecp-setting-mode").toLowerCase(locale);
            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
            if (!of.contains(lowerCase)) {
                Pair http = http("/query/active-app", 3000, "GET");
                int intValue = ((Number) http.first).intValue();
                byte[] bArr = (byte[]) http.second;
                if (intValue != 403) {
                    if (intValue == 200) {
                        this.app = Fleet.activeApp$shared_release(new String(bArr, Charsets.UTF_8));
                    }
                    this.live = true;
                    Thread thread = new Thread(new Guard$$ExternalSyntheticLambda5(17, this, function0), "roku-poll");
                    thread.setDaemon(true);
                    thread.start();
                    return;
                }
                throw new IOException("roku: control by mobile apps is off: ".concat(StringsKt.take(new String(bArr, Charsets.UTF_8), 60)));
            }
            throw new IOException("roku: control by mobile apps is off");
        }
        throw new IOException("the Roku did not answer on port 8060");
    }

    public final String fetch(String str) {
        Pair http = http(str, 3000, "GET");
        int intValue = ((Number) http.first).intValue();
        byte[] bArr = (byte[]) http.second;
        if (intValue == 200) {
            return new String(bArr, Charsets.UTF_8);
        }
        return null;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getApp() {
        return this.app;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean getAsking() {
        return false;
    }

    /* JADX WARN: Type inference failed for: r0v1, types: [java.util.Map, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.util.Map, java.lang.Object] */
    @Override // dev.tvremote.core.remote.Remote
    public final Set getKeys() {
        if (this.tv) {
            return KEYS.keySet();
        }
        return SetsKt.minus(KEYS.keySet(), TV_ONLY);
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getKind() {
        return "roku";
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getMac() {
        return this.mac;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getModel() {
        return this.model;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getVendor() {
        return this.vendor;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getVersion() {
        return this.version;
    }

    public final Pair http(String str, int i, String str2) {
        InputStream errorStream;
        byte[] readBytes;
        try {
            Function0 function0 = Lan.wifi;
            HttpURLConnection httpURLConnection = (HttpURLConnection) Lan.open(new URL("http://" + this.host + ":8060" + str));
            httpURLConnection.setConnectTimeout(i);
            httpURLConnection.setReadTimeout(i);
            httpURLConnection.setRequestMethod(str2);
            if (str2.equals("POST")) {
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setFixedLengthStreamingMode(0);
            }
            try {
                int responseCode = httpURLConnection.getResponseCode();
                Integer valueOf = Integer.valueOf(responseCode);
                if (200 <= responseCode && responseCode < 300) {
                    errorStream = httpURLConnection.getInputStream();
                } else {
                    errorStream = httpURLConnection.getErrorStream();
                }
                if (errorStream != null) {
                    try {
                        readBytes = MathKt.readBytes(errorStream);
                        errorStream.close();
                    } finally {
                    }
                } else {
                    readBytes = new byte[0];
                }
                Pair pair = new Pair(valueOf, readBytes);
                httpURLConnection.disconnect();
                return pair;
            } catch (Throwable th) {
                httpURLConnection.disconnect();
                throw th;
            }
        } catch (IOException unused) {
            return new Pair(0, new byte[0]);
        }
    }

    @Override // dev.tvremote.core.remote.Remote
    public final List inputs() {
        String str;
        int i;
        MatcherMatchResult access$findNext;
        Integer intOrNull;
        String fetch = fetch("/query/apps");
        if (fetch == null) {
            fetch = "";
        }
        List parseApps$shared_release = Fleet.parseApps$shared_release(fetch);
        ArrayList arrayList = new ArrayList();
        for (Object obj : parseApps$shared_release) {
            if (Intrinsics.areEqual(((Triple) obj).second, "tvin")) {
                arrayList.add(obj);
            }
        }
        ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList));
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            Triple triple = (Triple) it.next();
            String str2 = (String) triple.first;
            String str3 = (String) triple.third;
            String lowerCase = str2.toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
            if (StringsKt.contains(lowerCase, "hdmi", false)) {
                str = "hdmi";
            } else {
                String str4 = "tuner";
                if (!StringsKt.contains(lowerCase, "dtv", false) && !StringsKt.contains(lowerCase, "tuner", false)) {
                    str4 = "av";
                    if (!StringsKt.contains(lowerCase, "av", false) && !StringsKt.contains(lowerCase, "cvbs", false)) {
                        str4 = "other";
                    }
                }
                str = str4;
            }
            if (str.equals("hdmi") && (access$findNext = MathKt.access$findNext(Census$$ExternalSyntheticOutline0.m6m("(\\d+)$", "compile(...)", str2, "matcher(...)"), 0, str2)) != null && (intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull(access$findNext.getValue())) != null) {
                i = intOrNull.intValue();
            } else {
                i = 0;
            }
            arrayList2.add(new Inputs.Input(str2, str, i, "", str3, null, 96, 0));
        }
        return arrayList2;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final Boolean isOn() {
        return this.isOn;
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    /* JADX WARN: Type inference failed for: r1v0, types: [java.util.Map, java.lang.Object] */
    @Override // dev.tvremote.core.remote.Remote
    public final void key(final int i, final int i2) {
        String str;
        final ?? obj = new Object();
        String str2 = (String) KEYS.get(Integer.valueOf(i));
        if (str2 != null) {
            obj.element = str2;
            if (!this.closed) {
                if (this.tv || !TV_ONLY.contains(Integer.valueOf(i))) {
                    if (i == 26) {
                        if (i2 != 2) {
                            if (Intrinsics.areEqual(this.isOn, Boolean.FALSE)) {
                                str = "PowerOn";
                            } else {
                                str = "PowerOff";
                            }
                            obj.element = str;
                        } else {
                            return;
                        }
                    }
                    run(new Function0() { // from class: dev.tvremote.core.remote.Roku$$ExternalSyntheticLambda1
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            Roku roku = Roku.this;
                            int i3 = i;
                            int i4 = i2;
                            Ref$ObjectRef ref$ObjectRef = obj;
                            if (roku.ready()) {
                                if (i3 == 26) {
                                    i4 = 3;
                                }
                                if (i4 != 1) {
                                    if (i4 != 2) {
                                        roku.post("/keypress/" + ref$ObjectRef.element);
                                    } else {
                                        roku.post("/keyup/" + ref$ObjectRef.element);
                                    }
                                } else {
                                    roku.post("/keydown/" + ref$ObjectRef.element);
                                }
                                if (i3 == 26) {
                                    roku.isOn = Boolean.valueOf(Intrinsics.areEqual(ref$ObjectRef.element, "PowerOn"));
                                }
                            }
                            return Unit.INSTANCE;
                        }
                    });
                }
            }
        }
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void launch(String link) {
        String str;
        String concat;
        Intrinsics.checkNotNullParameter(link, "link");
        Pattern compile = Pattern.compile("(?:youtube\\.com/watch\\?v=|youtu\\.be/)([\\w-]{6,})");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        Matcher matcher = compile.matcher(link);
        Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
        MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, link);
        if (access$findNext != null) {
            str = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1);
        } else {
            str = null;
        }
        String str2 = str;
        if (str2 != null) {
            concat = ApkSigner$$ExternalSyntheticOutline0.m("/launch/837?contentId=", str2, "&mediaType=movie");
        } else {
            Pattern compile2 = Pattern.compile("^[\\w.-]{1,80}$");
            Intrinsics.checkNotNullExpressionValue(compile2, "compile(...)");
            if (compile2.matcher(link).matches()) {
                concat = "/launch/".concat(link);
            }
        }
        String str3 = concat;
        if (!this.closed) {
            run(new Census$$ExternalSyntheticLambda6(this, str3, str2, link, 1));
        }
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void pointer(int i, int i2) {
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void pointerClick() {
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void pointerHold(boolean z) {
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void pointerScroll(int i) {
    }

    public final void post(String str) {
        Pair http = http(str, 2500, "POST");
        int intValue = ((Number) http.first).intValue();
        byte[] bArr = (byte[]) http.second;
        WireLog wireLog = WireLog.all;
        WireLog wireLog2 = WireLog.all;
        StringBuilder sb = new StringBuilder("Roku ");
        String str2 = this.host;
        sb.append(str2);
        sb.append(" POST ");
        sb.append(str);
        sb.append(" ");
        sb.append(intValue);
        wireLog2.add("→", sb.toString());
        if (intValue == 403) {
            wireLog2.add("·", Census$$ExternalSyntheticOutline0.m("Roku ", str2, " refused: ", StringsKt.take(new String(bArr, Charsets.UTF_8), 80)));
        }
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void pulse(int i, long j) {
        key(i, 3);
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean ready() {
        if (this.live && !this.closed) {
            return true;
        }
        return false;
    }

    public final void run(Function0 function0) {
        try {
            this.out.execute(new Census$$ExternalSyntheticLambda7(function0, 1));
        } catch (RejectedExecutionException unused) {
        }
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean screenOff() {
        return false;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean search(String q) {
        Intrinsics.checkNotNullParameter(q, "q");
        return false;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean setVolume(int i) {
        return false;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean switchInput(String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        Pattern compile = Pattern.compile("^tvinput\\.[\\w.-]{1,40}$");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        if (compile.matcher(id).matches() && ready()) {
            post("/launch/".concat(id));
            return true;
        }
        return false;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void text(String t) {
        Intrinsics.checkNotNullParameter(t, "t");
        if (this.closed) {
            return;
        }
        run(new Regex$$ExternalSyntheticLambda0(2, t, this));
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void type(String str, int i) {
        Fleet.type(this, i, str);
    }
}
