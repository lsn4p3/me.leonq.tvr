package dev.tvremote.core.remote;

import android.widget.TextView;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Lan;
import dev.tvremote.core.Lan$$ExternalSyntheticLambda0;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.manage.UpdaterKt;
import dev.tvremote.update.Release;
import java.net.Socket;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class Lg$$ExternalSyntheticLambda5 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ int f$0;
    public final /* synthetic */ Object f$1;
    public final /* synthetic */ Object f$2;

    public /* synthetic */ Lg$$ExternalSyntheticLambda5(int i, Lg lg, String str) {
        this.$r8$classId = 0;
        this.f$0 = i;
        this.f$1 = lg;
        this.f$2 = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Socket connect;
        String str;
        switch (this.$r8$classId) {
            case 0:
                int i = this.f$0;
                Lg lg = (Lg) this.f$1;
                if (i > 0) {
                    Lg.request$default(lg, "ssap://com.webos.service.ime/deleteCharacters", new JSONObject().put("count", i), 0L, 4);
                }
                String str2 = (String) this.f$2;
                if (str2.length() > 0) {
                    Lg.request$default(lg, "ssap://com.webos.service.ime/insertText", new JSONObject().put("text", str2).put("replace", 0), 0L, 4);
                    return;
                }
                return;
            case 1:
                String str3 = (String) this.f$2;
                int i2 = this.f$0;
                try {
                    connect = Lan.connect(str3, i2, 800, new Lan$$ExternalSyntheticLambda0(0));
                    connect.close();
                    ((ConcurrentHashMap) this.f$1).put(Integer.valueOf(i2), Boolean.TRUE);
                    return;
                } catch (Exception unused) {
                    return;
                }
            case 2:
                MainActivity mainActivity = (MainActivity) this.f$1;
                String str4 = (String) this.f$2;
                int i3 = this.f$0;
                if (mainActivity.pic == null && Intrinsics.areEqual(mainActivity.host, str4)) {
                    TextView status$android_release = mainActivity.getStatus$android_release();
                    String str5 = mainActivity.entry;
                    if (str5 != null) {
                        str4 = str5;
                    }
                    String title$android_release = mainActivity.title$android_release(str4);
                    if (i3 > 0) {
                        str = "phone.others_watching";
                    } else {
                        str = "phone.the_tv_did_not";
                    }
                    status$android_release.setText(title$android_release + " · " + Fleet.T(str, new Pair[0]));
                    return;
                }
                return;
            default:
                UpdaterKt.progress((MainActivity) this.f$1, Fleet.T("updater.downloading", new Pair("version", ((Release) this.f$2).version), new Pair("pct", Integer.valueOf(this.f$0))));
                return;
        }
    }

    public /* synthetic */ Lg$$ExternalSyntheticLambda5(MainActivity mainActivity, Object obj, int i, int i2) {
        this.$r8$classId = i2;
        this.f$1 = mainActivity;
        this.f$2 = obj;
        this.f$0 = i;
    }

    public /* synthetic */ Lg$$ExternalSyntheticLambda5(String str, int i, ConcurrentHashMap concurrentHashMap) {
        this.$r8$classId = 1;
        this.f$2 = str;
        this.f$0 = i;
        this.f$1 = concurrentHashMap;
    }
}
