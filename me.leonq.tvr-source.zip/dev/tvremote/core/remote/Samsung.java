package dev.tvremote.core.remote;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.B64;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Diagnose;
import dev.tvremote.core.Diagnose$$ExternalSyntheticLambda1;
import dev.tvremote.core.Lan;
import dev.tvremote.core.WireLog;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.core.remote.Vidaa;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.EmptyList;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$ObjectRef;
import kotlin.math.MathKt;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class Samsung implements Remote {
    public static final HashMap KEYS;
    public static final List PORTS = ArraysKt.asList(new Pair[]{new Pair(8002, Boolean.TRUE), new Pair(8001, Boolean.FALSE)});
    public volatile String app;
    public volatile JSONArray appsGot;
    public volatile CountDownLatch appsWait;
    public volatile boolean asking;
    public volatile boolean closed;
    public final ConcurrentHashMap deep;
    public final String host;
    public final ConcurrentHashMap iconWait;
    public final ConcurrentHashMap icons;
    public volatile Boolean isOn;
    public volatile boolean keyboardNew;
    public volatile boolean live;
    public volatile String mac;
    public volatile String model;
    public final ExecutorService out;
    public volatile boolean playing;
    public final List ports;
    public final Diagnose.Real saved;
    public volatile String typed;
    public volatile String version;
    public volatile WebSocket ws;

    static {
        HashMap hashMap = new HashMap();
        hashMap.putAll(MapsKt__MapsKt.mapOf(new Pair(19, "KEY_UP"), new Pair(20, "KEY_DOWN"), new Pair(21, "KEY_LEFT"), new Pair(22, "KEY_RIGHT"), new Pair(23, "KEY_ENTER"), new Pair(66, "KEY_ENTER"), new Pair(4, "KEY_RETURN"), new Pair(3, "KEY_HOME"), new Pair(82, "KEY_MENU"), new Pair(176, "KEY_MENU"), new Pair(24, "KEY_VOLUP"), new Pair(25, "KEY_VOLDOWN"), new Pair(164, "KEY_MUTE"), new Pair(166, "KEY_CHUP"), new Pair(167, "KEY_CHDOWN"), new Pair(85, "KEY_PLAY"), new Pair(89, "KEY_REWIND"), new Pair(90, "KEY_FF"), new Pair(86, "KEY_STOP"), new Pair(165, "KEY_INFO"), new Pair(172, "KEY_GUIDE"), new Pair(170, "KEY_TV"), new Pair(175, "KEY_CAPTION"), new Pair(178, "KEY_SOURCE"), new Pair(26, "KEY_POWER"), new Pair(223, "KEY_POWER"), new Pair(67, "KEY_DEL")));
        for (int i = 0; i < 10; i++) {
            hashMap.put(Integer.valueOf(i + 7), "KEY_" + i);
        }
        KEYS = hashMap;
    }

    public Samsung(File file, String host) {
        List ports = PORTS;
        Intrinsics.checkNotNullParameter(host, "host");
        Intrinsics.checkNotNullParameter(ports, "ports");
        this.host = host;
        this.ports = ports;
        this.model = "";
        this.version = "";
        this.app = "";
        this.mac = "";
        this.saved = new Diagnose.Real(file, "samsung");
        this.out = Executors.newSingleThreadExecutor(new Diagnose$$ExternalSyntheticLambda1(5));
        this.icons = new ConcurrentHashMap();
        this.deep = new ConcurrentHashMap();
        this.iconWait = new ConcurrentHashMap();
        this.keyboardNew = true;
        this.typed = "";
    }

    public static byte[] get$default(Samsung samsung) {
        byte[] bArr;
        samsung.getClass();
        Function0 function0 = Lan.wifi;
        HttpURLConnection httpURLConnection = (HttpURLConnection) Lan.open(new URL("http://" + samsung.host + ":8001/api/v2/"));
        httpURLConnection.setConnectTimeout(2500);
        httpURLConnection.setReadTimeout(4000);
        httpURLConnection.setRequestMethod("GET");
        try {
            int responseCode = httpURLConnection.getResponseCode();
            if (200 <= responseCode && responseCode < 300) {
                InputStream inputStream = httpURLConnection.getInputStream();
                try {
                    Intrinsics.checkNotNull(inputStream);
                    bArr = MathKt.readBytes(inputStream);
                    inputStream.close();
                } finally {
                }
            } else {
                bArr = null;
            }
            return bArr;
        } finally {
            httpURLConnection.disconnect();
        }
    }

    @Override // dev.tvremote.core.remote.Remote
    public final List apps() {
        boolean z;
        boolean ready = ready();
        EmptyList emptyList = EmptyList.INSTANCE;
        if (!ready) {
            return emptyList;
        }
        CountDownLatch countDownLatch = new CountDownLatch(1);
        this.appsWait = countDownLatch;
        this.appsGot = null;
        JSONObject put = Census$$ExternalSyntheticOutline0.m8m("method", "ms.channel.emit").put("params", Census$$ExternalSyntheticOutline0.m10m("event", "ed.installedApp.get", "to", "host"));
        Intrinsics.checkNotNullExpressionValue(put, "put(...)");
        send$1(put);
        countDownLatch.await(6L, TimeUnit.SECONDS);
        JSONArray jSONArray = this.appsGot;
        if (jSONArray == null) {
            return emptyList;
        }
        ArrayList arrayList = new ArrayList();
        int length = jSONArray.length();
        for (int i = 0; i < length; i++) {
            JSONObject optJSONObject = jSONArray.optJSONObject(i);
            if (optJSONObject != null) {
                String optString = optJSONObject.optString("appId");
                Intrinsics.checkNotNull(optString);
                if (optString.length() != 0) {
                    String optString2 = optJSONObject.optString("icon");
                    Intrinsics.checkNotNull(optString2);
                    if (optString2.length() > 0) {
                        this.icons.put(optString, optString2);
                    }
                    if (optJSONObject.has("app_type")) {
                        ConcurrentHashMap concurrentHashMap = this.deep;
                        if (optJSONObject.optInt("app_type") == 2) {
                            z = true;
                        } else {
                            z = false;
                        }
                        concurrentHashMap.put(optString, Boolean.valueOf(z));
                    }
                    String optString3 = optJSONObject.optString("name");
                    if (optString3.length() == 0) {
                        optString3 = optString;
                    }
                    arrayList.add(new Remote.App(optString, optString3, optString2));
                }
            }
        }
        return arrayList;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        this.closed = true;
        this.live = false;
        this.out.shutdownNow();
        new Thread(new Lg$$ExternalSyntheticLambda14(this.ws, 1)).start();
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x004c  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x0114  */
    /* JADX WARN: Removed duplicated region for block: B:66:0x01d3  */
    /* JADX WARN: Removed duplicated region for block: B:68:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:69:0x002c  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0029  */
    @Override // dev.tvremote.core.remote.Remote
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void connect(Function0 function0) {
        JSONObject jSONObject;
        Object obj;
        String str;
        WebSocket open$default;
        byte[] bArr;
        IOException e = null;
        try {
            bArr = get$default(this);
        } catch (Exception unused) {
        }
        if (bArr != null) {
            jSONObject = new JSONObject(new String(bArr, Charsets.UTF_8)).optJSONObject("device");
            WireLog wireLog = WireLog.all;
            String str2 = this.host;
            if (jSONObject != null) {
                obj = "no answer";
            } else {
                obj = jSONObject;
            }
            wireLog.add("←", "Samsung " + str2 + " /api/v2/ " + obj);
            if (jSONObject != null) {
                String optString = jSONObject.optString("modelName");
                if (optString.length() == 0) {
                    optString = jSONObject.optString("name");
                }
                Intrinsics.checkNotNullExpressionValue(optString, "ifEmpty(...)");
                this.model = optString;
                String optString2 = jSONObject.optString("OS");
                String optString3 = jSONObject.optString("firmwareVersion");
                if (Intrinsics.areEqual(optString3, "Unknown")) {
                    optString3 = null;
                }
                if (optString3 == null) {
                    optString3 = "";
                }
                List asList = ArraysKt.asList(new String[]{optString2, optString3});
                ArrayList arrayList = new ArrayList();
                for (Object obj2 : asList) {
                    String str3 = (String) obj2;
                    Intrinsics.checkNotNull(str3);
                    if (str3.length() > 0) {
                        arrayList.add(obj2);
                    }
                }
                this.version = CollectionsKt.joinToString$default(arrayList, " ", null, null, null, 62);
                String optString4 = jSONObject.optString("wifiMac");
                Intrinsics.checkNotNullExpressionValue(optString4, "optString(...)");
                String upperCase = optString4.toUpperCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
                this.mac = upperCase;
                String optString5 = jSONObject.optString("PowerState");
                Intrinsics.checkNotNull(optString5);
                if (optString5.length() <= 0) {
                    optString5 = null;
                }
                if (optString5 != null) {
                    this.isOn = Boolean.valueOf(optString5.equals("on"));
                }
            }
            int[] iArr = B64.INDEX;
            byte[] bytes = "TV Remote".getBytes(Charsets.UTF_8);
            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
            String encode = B64.encode(bytes);
            String str4 = this.saved.get(this.host);
            for (Pair pair : this.ports) {
                int intValue = ((Number) pair.first).intValue();
                boolean booleanValue = ((Boolean) pair.second).booleanValue();
                if (str4.length() <= 0) {
                    str = "";
                } else {
                    str = "&token=".concat(str4);
                }
                String m = ApkSigner$$ExternalSyntheticOutline0.m("/api/v2/channels/samsung.remote.control?name=", encode, str);
                try {
                    SecureRandom secureRandom = WebSocket.RANDOM;
                    open$default = Vidaa.Companion.open$default(this.host, intValue, m, booleanValue);
                    WireLog.all.add("·", "Samsung " + this.host + ":" + intValue + " open " + m);
                } catch (IOException e2) {
                    e = e2;
                    WireLog.all.add("·", "Samsung " + this.host + ":" + intValue + " " + e);
                }
                try {
                    hello(open$default, function0);
                    return;
                } catch (Remote.Refused e3) {
                    WireLog wireLog2 = WireLog.all;
                    WireLog.all.add("·", Census$$ExternalSyntheticOutline0.m("Samsung ", this.host, " refused: ", e3.getMessage()));
                    open$default.close();
                    throw e3;
                } catch (IOException e4) {
                    e = e4;
                    WireLog wireLog3 = WireLog.all;
                    WireLog.all.add("·", "Samsung " + this.host + ":" + intValue + " " + e);
                    open$default.close();
                }
            }
            if (e == null) {
                throw e;
            }
            throw new IOException("no port");
        }
        jSONObject = null;
        WireLog wireLog4 = WireLog.all;
        String str22 = this.host;
        if (jSONObject != null) {
        }
        wireLog4.add("←", "Samsung " + str22 + " /api/v2/ " + obj);
        if (jSONObject != null) {
        }
        int[] iArr2 = B64.INDEX;
        byte[] bytes2 = "TV Remote".getBytes(Charsets.UTF_8);
        Intrinsics.checkNotNullExpressionValue(bytes2, "getBytes(...)");
        String encode2 = B64.encode(bytes2);
        String str42 = this.saved.get(this.host);
        while (r8.hasNext()) {
        }
        if (e == null) {
        }
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getApp() {
        return this.app;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean getAsking() {
        return this.asking;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final Set getKeys() {
        return KEYS.keySet();
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getKind() {
        return "samsung";
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getMac() {
        return this.mac;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getModel() {
        return this.model;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getVendor() {
        return "Samsung";
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getVersion() {
        return this.version;
    }

    /* JADX WARN: Code restructure failed: missing block: B:60:0x0017, code lost:
    
        continue;
     */
    /* JADX WARN: Failed to find 'out' block for switch in B:19:0x0045. Please report as an issue. */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void hello(WebSocket webSocket, Function0 function0) {
        String read;
        String optString;
        webSocket.sock.setSoTimeout(1500);
        long j = 1000000;
        long nanoTime = (System.nanoTime() / j) + 40000;
        while (!this.closed) {
            try {
                read = webSocket.read();
            } catch (SocketTimeoutException unused) {
                if (System.nanoTime() / j <= nanoTime) {
                    this.asking = true;
                } else {
                    throw new IOException("nobody accepted on the TV");
                }
            }
            if (read != null) {
                WireLog.all.add("←", Census$$ExternalSyntheticOutline0.m("Samsung ", this.host, " ", read));
                try {
                    JSONObject jSONObject = new JSONObject(read);
                    String optString2 = jSONObject.optString("event");
                    if (optString2 != null) {
                        switch (optString2.hashCode()) {
                            case -355299570:
                                if (!optString2.equals("ms.channel.timeOut")) {
                                    break;
                                } else {
                                    this.asking = false;
                                    throw new IOException("nobody accepted on the TV");
                                }
                            case -355268818:
                                if (!optString2.equals("ms.channel.timeout")) {
                                    break;
                                } else {
                                    this.asking = false;
                                    throw new IOException("nobody accepted on the TV");
                                }
                            case 941340487:
                                if (!optString2.equals("ms.channel.unauthorized")) {
                                    break;
                                } else {
                                    this.asking = false;
                                    throw new IOException("the TV said no");
                                }
                            case 1909994167:
                                if (!optString2.equals("ms.channel.connect")) {
                                    break;
                                } else {
                                    this.asking = false;
                                    JSONObject optJSONObject = jSONObject.optJSONObject("data");
                                    if (optJSONObject != null && (optString = optJSONObject.optString("token")) != null) {
                                        if (optString.length() <= 0) {
                                            optString = null;
                                        }
                                        if (optString != null) {
                                            this.saved.put(this.host, optString);
                                        }
                                    }
                                    this.ws = webSocket;
                                    this.live = true;
                                    if (this.isOn == null) {
                                        this.isOn = Boolean.TRUE;
                                    }
                                    webSocket.sock.setSoTimeout(0);
                                    Thread thread = new Thread(new Lg$$ExternalSyntheticLambda2(this, webSocket, function0, 7), "samsung-in");
                                    thread.setDaemon(true);
                                    thread.start();
                                    return;
                                }
                        }
                    } else {
                        continue;
                    }
                } catch (Exception unused2) {
                }
            } else {
                throw new IOException("the TV closed the connection");
            }
        }
        throw new IOException("closed");
    }

    @Override // dev.tvremote.core.remote.Remote
    public final List inputs() {
        return EmptyList.INSTANCE;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final Boolean isOn() {
        return this.isOn;
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    @Override // dev.tvremote.core.remote.Remote
    public final void key(final int i, final int i2) {
        String str;
        final ?? obj = new Object();
        String str2 = (String) KEYS.get(Integer.valueOf(i));
        if (str2 != null) {
            obj.element = str2;
            if (this.closed) {
                return;
            }
            if (i == 85 && i2 != 2) {
                this.playing = !this.playing;
                if (this.playing) {
                    str = "KEY_PLAY";
                } else {
                    str = "KEY_PAUSE";
                }
                obj.element = str;
            }
            this.out.execute(new Runnable() { // from class: dev.tvremote.core.remote.Samsung$$ExternalSyntheticLambda3
                @Override // java.lang.Runnable
                public final void run() {
                    String str3;
                    Samsung samsung = Samsung.this;
                    int i3 = i2;
                    Ref$ObjectRef ref$ObjectRef = obj;
                    int i4 = i;
                    if (!samsung.ready()) {
                        return;
                    }
                    if (i3 != 1) {
                        if (i3 != 2) {
                            samsung.press((String) ref$ObjectRef.element, "Click");
                            return;
                        }
                        if (i4 == 85) {
                            if (samsung.playing) {
                                str3 = "KEY_PLAY";
                            } else {
                                str3 = "KEY_PAUSE";
                            }
                        } else {
                            str3 = (String) ref$ObjectRef.element;
                        }
                        samsung.press(str3, "Release");
                        return;
                    }
                    samsung.press((String) ref$ObjectRef.element, "Press");
                }
            });
        }
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void launch(String link) {
        Intrinsics.checkNotNullParameter(link, "link");
        this.out.execute(new Samsung$$ExternalSyntheticLambda0(link, this));
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void pointer(int i, int i2) {
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void pointerClick() {
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void pointerHold(boolean z) {
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void pointerScroll(int i) {
    }

    public final void press(String str, String str2) {
        JSONObject put = Census$$ExternalSyntheticOutline0.m8m("method", "ms.remote.control").put("params", Census$$ExternalSyntheticOutline0.m10m("Cmd", str2, "DataOfCmd", str).put("Option", "false").put("TypeOfRemote", "SendRemoteKey"));
        Intrinsics.checkNotNullExpressionValue(put, "put(...)");
        send$1(put);
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void pulse(int i, long j) {
        key(i, 3);
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean ready() {
        if (this.live && !this.closed) {
            return true;
        }
        return false;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean screenOff() {
        return false;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean search(String q) {
        Intrinsics.checkNotNullParameter(q, "q");
        return false;
    }

    public final void send$1(JSONObject jSONObject) {
        String jSONObject2 = jSONObject.toString();
        Intrinsics.checkNotNullExpressionValue(jSONObject2, "toString(...)");
        WireLog.all.add("→", Census$$ExternalSyntheticOutline0.m("Samsung ", this.host, " ", jSONObject2));
        try {
            WebSocket webSocket = this.ws;
            if (webSocket != null) {
                webSocket.send(jSONObject2);
            }
        } catch (IOException e) {
            WireLog.all.add("·", "Samsung " + this.host + " send: " + e);
        }
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean setVolume(int i) {
        return false;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean switchInput(String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        return false;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void text(String t) {
        Intrinsics.checkNotNullParameter(t, "t");
        this.out.execute(new Samsung$$ExternalSyntheticLambda0(this, t));
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void type(String str, int i) {
        String str2 = this.typed;
        Intrinsics.checkNotNullParameter(str2, "<this>");
        if (i >= 0) {
            int length = str2.length() - i;
            if (length < 0) {
                length = 0;
            }
            String concat = StringsKt.take(str2, length).concat(str);
            if (!Intrinsics.areEqual(concat, this.typed)) {
                this.typed = concat;
                text(concat);
                return;
            }
            return;
        }
        throw new IllegalArgumentException(ApkSigner$$ExternalSyntheticOutline0.m("Requested character count ", i, " is less than zero.").toString());
    }
}
