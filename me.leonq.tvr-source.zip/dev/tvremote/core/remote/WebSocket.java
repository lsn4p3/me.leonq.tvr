package dev.tvremote.core.remote;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.security.SecureRandom;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;
import org.conscrypt.metrics.ConscryptStatsLog;

/* loaded from: classes.dex */
public final class WebSocket implements Closeable {
    public static final SecureRandom RANDOM = new SecureRandom();
    public static final Atv$dial$anyTv$1 TRUST_ANY = new Atv$dial$anyTv$1(2);
    public volatile boolean closed;
    public final BufferedInputStream input;
    public final OutputStream output;
    public final Socket sock;

    public WebSocket(Socket socket) {
        BufferedInputStream bufferedInputStream;
        this.sock = socket;
        InputStream inputStream = socket.getInputStream();
        Intrinsics.checkNotNullExpressionValue(inputStream, "getInputStream(...)");
        if (inputStream instanceof BufferedInputStream) {
            bufferedInputStream = (BufferedInputStream) inputStream;
        } else {
            bufferedInputStream = new BufferedInputStream(inputStream, 8192);
        }
        this.input = bufferedInputStream;
        OutputStream outputStream = socket.getOutputStream();
        Intrinsics.checkNotNullExpressionValue(outputStream, "getOutputStream(...)");
        this.output = outputStream;
    }

    /* renamed from: byte, reason: not valid java name */
    public final int m15byte() {
        int read = this.input.read();
        if (read >= 0) {
            return read;
        }
        throw new IOException("cut short");
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        if (!this.closed) {
            try {
                frame(8, new byte[]{3, -24});
            } catch (Exception unused) {
            }
        }
        this.closed = true;
        try {
            this.sock.close();
        } catch (Exception unused2) {
        }
    }

    public final synchronized void frame(int i, byte[] bArr) {
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(bArr.length + 14);
            byteArrayOutputStream.write(i | 128);
            if (bArr.length < 126) {
                byteArrayOutputStream.write(bArr.length | 128);
            } else if (bArr.length < 65536) {
                byteArrayOutputStream.write(254);
                byteArrayOutputStream.write(bArr.length >> 8);
                byteArrayOutputStream.write(bArr.length & 255);
            } else {
                byteArrayOutputStream.write(255);
                for (int i2 = 7; -1 < i2; i2--) {
                    byteArrayOutputStream.write((int) ((bArr.length >> (i2 * 8)) & 255));
                }
            }
            byte[] bArr2 = new byte[4];
            RANDOM.nextBytes(bArr2);
            byteArrayOutputStream.write(bArr2);
            int length = bArr.length;
            for (int i3 = 0; i3 < length; i3++) {
                byteArrayOutputStream.write(bArr[i3] ^ bArr2[i3 & 3]);
            }
            this.output.write(byteArrayOutputStream.toByteArray());
            this.output.flush();
        } catch (Throwable th) {
            throw th;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:60:0x00d4, code lost:
    
        throw new java.io.IOException("message too big");
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final String read() {
        byte[] bArr;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        while (true) {
            int read = this.input.read();
            if (read < 0) {
                this.closed = true;
                return null;
            }
            int read2 = this.input.read();
            if (read2 < 0) {
                this.closed = true;
                return null;
            }
            long j = read2 & 127;
            if (j == 126) {
                j = (m15byte() << 8) | m15byte();
            } else if (j == 127) {
                j = 0;
                for (int i = 0; i < 8; i++) {
                    j = (j << 8) | m15byte();
                }
            }
            if (j >= 0 && j <= 16777216 && byteArrayOutputStream.size() + j <= 16777216) {
                if ((read2 & 128) != 0) {
                    bArr = new byte[4];
                    for (int i2 = 0; i2 < 4; i2++) {
                        bArr[i2] = (byte) m15byte();
                    }
                } else {
                    bArr = null;
                }
                int i3 = (int) j;
                byte[] bArr2 = new byte[i3];
                int i4 = 0;
                while (i4 < i3) {
                    int read3 = this.input.read(bArr2, i4, i3 - i4);
                    if (read3 >= 0) {
                        i4 += read3;
                    } else {
                        throw new IOException("cut short");
                    }
                }
                if (bArr != null) {
                    for (int i5 = 0; i5 < i3; i5++) {
                        bArr2[i5] = (byte) (bArr2[i5] ^ bArr[i5 & 3]);
                    }
                }
                switch (read & 15) {
                    case 8:
                        this.closed = true;
                        try {
                            frame(8, new byte[0]);
                        } catch (IOException unused) {
                        }
                        return null;
                    case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                        frame(10, bArr2);
                        break;
                    case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                        break;
                    default:
                        byteArrayOutputStream.write(bArr2);
                        if ((read & 128) != 0) {
                            byte[] byteArray = byteArrayOutputStream.toByteArray();
                            Intrinsics.checkNotNullExpressionValue(byteArray, "toByteArray(...)");
                            return new String(byteArray, Charsets.UTF_8);
                        }
                        break;
                }
            }
        }
    }

    public final void send(String text) {
        Intrinsics.checkNotNullParameter(text, "text");
        byte[] bytes = text.getBytes(Charsets.UTF_8);
        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        frame(1, bytes);
    }
}
