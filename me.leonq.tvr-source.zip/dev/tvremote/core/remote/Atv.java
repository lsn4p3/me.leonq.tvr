package dev.tvremote.core.remote;

import com.android.apksig.util.DataSink;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Lan;
import dev.tvremote.core.WireLog;
import dev.tvremote.core.adb.Adb$$ExternalSyntheticLambda0;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda5;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.ByteBuffer;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLSocket;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.EmptyList;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;

/* loaded from: classes.dex */
public final class Atv implements Remote, CodePairing {
    public volatile String app;
    public final X509Certificate cert;
    public volatile boolean closed;
    public volatile long field;
    public volatile boolean hasField;
    public final String host;
    public volatile long ime;
    public volatile Boolean isOn;
    public final PrivateKey key;
    public volatile boolean live;
    public volatile String model;
    public final ExecutorService out;
    public volatile SSLSocket sock;
    public volatile String vendor;
    public volatile String version;

    /* loaded from: classes.dex */
    public final class NotPaired extends Exception {
        public NotPaired() {
            super("not paired");
        }
    }

    /* loaded from: classes.dex */
    public final class Pb implements DataSink {
        public final ByteArrayOutputStream o;

        public Pb(ByteArrayOutputStream byteArrayOutputStream) {
            if (byteArrayOutputStream != null) {
                this.o = byteArrayOutputStream;
                return;
            }
            throw new NullPointerException("out == null");
        }

        public byte[] bytes() {
            byte[] byteArray = this.o.toByteArray();
            Intrinsics.checkNotNullExpressionValue(byteArray, "toByteArray(...)");
            return byteArray;
        }

        @Override // com.android.apksig.util.DataSink
        public void consume(byte[] bArr, int i, int i2) {
            this.o.write(bArr, 0, i2);
        }

        public void str(String v, int i) {
            Intrinsics.checkNotNullParameter(v, "v");
            byte[] bytes = v.getBytes(Charsets.UTF_8);
            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
            ByteArrayOutputStream byteArrayOutputStream = this.o;
            Fleet.varint(byteArrayOutputStream, (i << 3) | 2);
            Fleet.varint(byteArrayOutputStream, bytes.length);
            byteArrayOutputStream.write(bytes);
        }

        @Override // com.android.apksig.util.DataSink
        public void consume(ByteBuffer byteBuffer) {
            if (byteBuffer.hasRemaining()) {
                boolean hasArray = byteBuffer.hasArray();
                ByteArrayOutputStream byteArrayOutputStream = this.o;
                if (hasArray) {
                    byteArrayOutputStream.write(byteBuffer.array(), byteBuffer.position() + byteBuffer.arrayOffset(), byteBuffer.remaining());
                    byteBuffer.position(byteBuffer.limit());
                    return;
                }
                int min = Math.min(byteBuffer.remaining(), 65536);
                byte[] bArr = new byte[min];
                while (byteBuffer.hasRemaining()) {
                    int min2 = Math.min(byteBuffer.remaining(), min);
                    byteBuffer.get(bArr, 0, min2);
                    byteArrayOutputStream.write(bArr, 0, min2);
                }
            }
        }

        public Pb() {
            this.o = new ByteArrayOutputStream();
        }
    }

    public Atv(File file, String host) {
        Intrinsics.checkNotNullParameter(host, "host");
        this.host = host;
        this.out = Executors.newSingleThreadExecutor();
        this.model = "";
        this.vendor = "";
        this.version = "";
        File file2 = new File(file, "atv.pk8");
        File file3 = new File(file, "atv.crt");
        if (!file2.exists() || !file3.exists()) {
            KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
            keyPairGenerator.initialize(2048);
            KeyPair generateKeyPair = keyPairGenerator.generateKeyPair();
            byte[] encoded = generateKeyPair.getPublic().getEncoded();
            Intrinsics.checkNotNullExpressionValue(encoded, "getEncoded(...)");
            PrivateKey privateKey = generateKeyPair.getPrivate();
            Intrinsics.checkNotNullExpressionValue(privateKey, "getPrivate(...)");
            MathKt.writeBytes(file3, Fleet.certificate(privateKey, encoded, "tv-remote"));
            byte[] encoded2 = generateKeyPair.getPrivate().getEncoded();
            Intrinsics.checkNotNullExpressionValue(encoded2, "getEncoded(...)");
            MathKt.writeBytes(file2, encoded2);
        }
        PrivateKey generatePrivate = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(MathKt.readBytes(file2)));
        Intrinsics.checkNotNullExpressionValue(generatePrivate, "generatePrivate(...)");
        this.key = generatePrivate;
        Certificate generateCertificate = CertificateFactory.getInstance("X.509").generateCertificate(new FileInputStream(file3));
        Intrinsics.checkNotNull(generateCertificate, "null cannot be cast to non-null type java.security.cert.X509Certificate");
        this.cert = (X509Certificate) generateCertificate;
        this.app = "";
    }

    public static void answer(SSLSocket sSLSocket, int i) {
        Object obj;
        long j;
        InputStream inputStream = sSLSocket.getInputStream();
        Intrinsics.checkNotNullExpressionValue(inputStream, "getInputStream(...)");
        byte[] frame$shared_release = Fleet.frame$shared_release(inputStream);
        if (frame$shared_release != null) {
            HashMap read = Fleet.read(frame$shared_release);
            List list = (List) read.get(2);
            Long l = null;
            if (list != null) {
                obj = CollectionsKt.firstOrNull(list);
            } else {
                obj = null;
            }
            if (obj instanceof Long) {
                l = (Long) obj;
            }
            if (l != null) {
                j = l.longValue();
            } else {
                j = 0;
            }
            if (j == 200 && read.get(Integer.valueOf(i)) != null) {
                return;
            } else {
                throw new IOException("pairing refused");
            }
        }
        throw new IOException("the TV closed the pairing");
    }

    public static final void handle$lambda$10$n(HashMap hashMap, int i) {
        Object obj;
        List list = (List) hashMap.get(Integer.valueOf(i));
        if (list != null) {
            obj = CollectionsKt.firstOrNull(list);
        } else {
            obj = null;
        }
        boolean z = obj instanceof Long;
    }

    public static final String handle$lambda$6$str(HashMap hashMap, int i) {
        Object obj;
        List list = (List) hashMap.get(Integer.valueOf(i));
        byte[] bArr = null;
        if (list != null) {
            obj = CollectionsKt.firstOrNull(list);
        } else {
            obj = null;
        }
        if (obj instanceof byte[]) {
            bArr = (byte[]) obj;
        }
        if (bArr != null) {
            return new String(bArr, Charsets.UTF_8);
        }
        return "";
    }

    public static final void startPairing$step(Atv atv, SSLSocket sSLSocket, int i, byte[] bArr, int i2) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        Fleet.varint(byteArrayOutputStream, 1 << 3);
        Fleet.varint(byteArrayOutputStream, 2L);
        Fleet.varint(byteArrayOutputStream, 2 << 3);
        Fleet.varint(byteArrayOutputStream, 200L);
        Fleet.varint(byteArrayOutputStream, (i << 3) | 2);
        Fleet.varint(byteArrayOutputStream, bArr.length);
        byteArrayOutputStream.write(bArr);
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        Intrinsics.checkNotNullExpressionValue(byteArray, "toByteArray(...)");
        atv.send(sSLSocket, byteArray);
        answer(sSLSocket, i2);
    }

    @Override // dev.tvremote.core.remote.Remote
    public final List apps() {
        return EmptyList.INSTANCE;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        this.closed = true;
        this.out.shutdown();
        new Thread(new Adb$$ExternalSyntheticLambda0(3, this.sock)).start();
    }

    /* JADX WARN: Type inference failed for: r3v0, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    @Override // dev.tvremote.core.remote.Remote
    public final void connect(Function0 function0) {
        ?? obj = new Object();
        try {
            SSLSocket open = open();
            if (open != null) {
                obj.element = open;
                WireLog.all.add("·", "remote " + this.host + " connected: " + this.vendor + " " + this.model + " " + this.version);
                Thread thread = new Thread(new Lg$$ExternalSyntheticLambda2(this, obj, function0, 6), "atv");
                thread.setDaemon(true);
                thread.start();
                return;
            }
            WireLog.all.add("·", "remote " + this.host + " not paired");
            throw new NotPaired();
        } catch (Exception e) {
            WireLog wireLog = WireLog.all;
            WireLog.all.add("·", "remote " + this.host + " " + e);
            throw e;
        }
    }

    public final SSLSocket dial(int i) {
        KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
        keyStore.load(null);
        keyStore.setKeyEntry("k", this.key, new char[0], new X509Certificate[]{this.cert});
        KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        keyManagerFactory.init(keyStore, new char[0]);
        Atv$dial$anyTv$1 atv$dial$anyTv$1 = new Atv$dial$anyTv$1(0);
        SSLContext sSLContext = SSLContext.getInstance("TLS");
        sSLContext.init(keyManagerFactory.getKeyManagers(), new Atv$dial$anyTv$1[]{atv$dial$anyTv$1}, null);
        Function0 function0 = Lan.wifi;
        String str = this.host;
        Socket createSocket = sSLContext.getSocketFactory().createSocket(Lan.connect$default(str, i, 5000), str, i, true);
        Intrinsics.checkNotNull(createSocket, "null cannot be cast to non-null type javax.net.ssl.SSLSocket");
        SSLSocket sSLSocket = (SSLSocket) createSocket;
        try {
            sSLSocket.setSoTimeout(15000);
            sSLSocket.startHandshake();
            sSLSocket.setSoTimeout(0);
            return sSLSocket;
        } catch (Exception e) {
            try {
                sSLSocket.close();
            } catch (Exception unused) {
            }
            throw e;
        }
    }

    @Override // dev.tvremote.core.remote.CodePairing
    public final void finishPairing(String code) {
        Intrinsics.checkNotNullParameter(code, "code");
        SSLSocket sSLSocket = this.sock;
        if (sSLSocket != null) {
            String upperCase = StringsKt.trim(code).toString().toUpperCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
            if (upperCase.length() == 6) {
                for (int i = 0; i < upperCase.length(); i++) {
                    if (StringsKt.contains$default("0123456789ABCDEF", upperCase.charAt(i))) {
                    }
                }
                PublicKey publicKey = this.cert.getPublicKey();
                Intrinsics.checkNotNull(publicKey, "null cannot be cast to non-null type java.security.interfaces.RSAPublicKey");
                RSAPublicKey rSAPublicKey = (RSAPublicKey) publicKey;
                PublicKey publicKey2 = sSLSocket.getSession().getPeerCertificates()[0].getPublicKey();
                Intrinsics.checkNotNull(publicKey2, "null cannot be cast to non-null type java.security.interfaces.RSAPublicKey");
                RSAPublicKey rSAPublicKey2 = (RSAPublicKey) publicKey2;
                MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
                for (BigInteger bigInteger : ArraysKt.asList(new BigInteger[]{rSAPublicKey.getModulus(), rSAPublicKey.getPublicExponent(), rSAPublicKey2.getModulus(), rSAPublicKey2.getPublicExponent()})) {
                    Intrinsics.checkNotNull(bigInteger);
                    byte[] byteArray = bigInteger.toByteArray();
                    if (byteArray.length > 1 && byteArray[0] == 0) {
                        byteArray = ArraysKt.copyOfRange(byteArray, 1, byteArray.length);
                    }
                    messageDigest.update(byteArray);
                }
                String substring = upperCase.substring(2);
                Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
                int length = substring.length() / 2;
                byte[] bArr = new byte[length];
                for (int i2 = 0; i2 < length; i2++) {
                    int i3 = i2 * 2;
                    String substring2 = substring.substring(i3, i3 + 2);
                    Intrinsics.checkNotNullExpressionValue(substring2, "substring(...)");
                    MathKt.checkRadix(16);
                    bArr[i2] = (byte) Integer.parseInt(substring2, 16);
                }
                messageDigest.update(bArr);
                byte[] digest = messageDigest.digest();
                byte b = digest[0];
                String substring3 = upperCase.substring(0, 2);
                Intrinsics.checkNotNullExpressionValue(substring3, "substring(...)");
                int length2 = substring3.length() / 2;
                byte[] bArr2 = new byte[length2];
                for (int i4 = 0; i4 < length2; i4++) {
                    int i5 = i4 * 2;
                    String substring4 = substring3.substring(i5, i5 + 2);
                    Intrinsics.checkNotNullExpressionValue(substring4, "substring(...)");
                    MathKt.checkRadix(16);
                    bArr2[i4] = (byte) Integer.parseInt(substring4, 16);
                }
                if (b != bArr2[0]) {
                    digest = null;
                }
                if (digest != null) {
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    Fleet.varint(byteArrayOutputStream, 8);
                    Fleet.varint(byteArrayOutputStream, 2L);
                    Fleet.varint(byteArrayOutputStream, 16);
                    Fleet.varint(byteArrayOutputStream, 200L);
                    ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
                    Fleet.varint(byteArrayOutputStream2, 10);
                    Fleet.varint(byteArrayOutputStream2, digest.length);
                    byteArrayOutputStream2.write(digest);
                    byte[] byteArray2 = byteArrayOutputStream2.toByteArray();
                    Intrinsics.checkNotNullExpressionValue(byteArray2, "toByteArray(...)");
                    Fleet.varint(byteArrayOutputStream, 322);
                    Fleet.varint(byteArrayOutputStream, byteArray2.length);
                    byteArrayOutputStream.write(byteArray2);
                    byte[] byteArray3 = byteArrayOutputStream.toByteArray();
                    Intrinsics.checkNotNullExpressionValue(byteArray3, "toByteArray(...)");
                    send(sSLSocket, byteArray3);
                    answer(sSLSocket, 41);
                    close();
                    return;
                }
                throw new IllegalArgumentException("bad code");
            }
            throw new IllegalArgumentException("bad code");
        }
        throw new IllegalStateException("startPairing first");
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getApp() {
        return this.app;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean getAsking() {
        return false;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final Set getKeys() {
        return null;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getKind() {
        return "android";
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getMac() {
        return "";
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getModel() {
        return this.model;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getVendor() {
        return this.vendor;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getVersion() {
        return this.version;
    }

    public final void handle(SSLSocket sSLSocket, byte[] bArr) {
        int i;
        byte[] bArr2;
        Object obj;
        byte[] bArr3;
        String str;
        Object obj2;
        byte[] bArr4;
        byte[] bArr5;
        Object obj3;
        Long l;
        long j;
        Object obj4;
        Long l2;
        byte[] bArr6;
        byte[] bArr7;
        Object obj5;
        Long l3;
        long j2;
        boolean z;
        byte[] bArr8;
        Object obj6;
        Long l4;
        long j3;
        byte[] bArr9;
        Object obj7;
        byte[] bArr10;
        HashMap read = Fleet.read(bArr);
        if (!read.containsKey(8)) {
            WireLog.all.add("←", "remote " + this.host + " " + CollectionsKt.joinToString$default(CollectionsKt.sorted(read.keySet()), ",", "message ", null, null, 60) + " (" + bArr.length + " B)");
        }
        List list = (List) read.get(1);
        if (list != null) {
            Object obj8 = list.get(0);
            if (obj8 instanceof byte[]) {
                bArr9 = (byte[]) obj8;
            } else {
                bArr9 = null;
            }
            if (bArr9 == null) {
                bArr9 = new byte[0];
            }
            List list2 = (List) Fleet.read(bArr9).get(2);
            if (list2 != null) {
                obj7 = CollectionsKt.firstOrNull(list2);
            } else {
                obj7 = null;
            }
            if (obj7 instanceof byte[]) {
                bArr10 = (byte[]) obj7;
            } else {
                bArr10 = null;
            }
            if (bArr10 != null) {
                HashMap read2 = Fleet.read(bArr10);
                this.model = handle$lambda$6$str(read2, 1);
                this.vendor = handle$lambda$6$str(read2, 2);
                this.version = handle$lambda$6$str(read2, 6);
            }
            Pb pb = new Pb();
            pb.str("TV Remote", 1);
            pb.str("tv-remote", 2);
            i = 2;
            ByteArrayOutputStream byteArrayOutputStream = pb.o;
            Fleet.varint(byteArrayOutputStream, 3 << 3);
            Fleet.varint(byteArrayOutputStream, 1L);
            pb.str("1", 4);
            pb.str("atvremote", 5);
            pb.str("1.0.0", 6);
            byte[] bytes = pb.bytes();
            ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
            ByteArrayOutputStream byteArrayOutputStream3 = new ByteArrayOutputStream();
            Fleet.varint(byteArrayOutputStream3, 8);
            Fleet.varint(byteArrayOutputStream3, 622L);
            Fleet.varint(byteArrayOutputStream3, 18);
            Fleet.varint(byteArrayOutputStream3, bytes.length);
            byteArrayOutputStream3.write(bytes);
            byte[] byteArray = byteArrayOutputStream3.toByteArray();
            Intrinsics.checkNotNullExpressionValue(byteArray, "toByteArray(...)");
            Fleet.varint(byteArrayOutputStream2, 10);
            Fleet.varint(byteArrayOutputStream2, byteArray.length);
            byteArrayOutputStream2.write(byteArray);
            byte[] byteArray2 = byteArrayOutputStream2.toByteArray();
            Intrinsics.checkNotNullExpressionValue(byteArray2, "toByteArray(...)");
            send(sSLSocket, byteArray2);
        } else {
            i = 2;
        }
        if (((List) read.get(Integer.valueOf(i))) != null) {
            ByteArrayOutputStream byteArrayOutputStream4 = new ByteArrayOutputStream();
            ByteArrayOutputStream byteArrayOutputStream5 = new ByteArrayOutputStream();
            Fleet.varint(byteArrayOutputStream5, 8);
            Fleet.varint(byteArrayOutputStream5, 622L);
            byte[] byteArray3 = byteArrayOutputStream5.toByteArray();
            Intrinsics.checkNotNullExpressionValue(byteArray3, "toByteArray(...)");
            Fleet.varint(byteArrayOutputStream4, 18);
            Fleet.varint(byteArrayOutputStream4, byteArray3.length);
            byteArrayOutputStream4.write(byteArray3);
            byte[] byteArray4 = byteArrayOutputStream4.toByteArray();
            Intrinsics.checkNotNullExpressionValue(byteArray4, "toByteArray(...)");
            send(sSLSocket, byteArray4);
            this.live = true;
        }
        List list3 = (List) read.get(8);
        long j4 = 0;
        if (list3 != null) {
            Object obj9 = list3.get(0);
            if (obj9 instanceof byte[]) {
                bArr8 = (byte[]) obj9;
            } else {
                bArr8 = null;
            }
            if (bArr8 == null) {
                bArr8 = new byte[0];
            }
            List list4 = (List) Fleet.read(bArr8).get(1);
            if (list4 != null) {
                obj6 = CollectionsKt.firstOrNull(list4);
            } else {
                obj6 = null;
            }
            if (obj6 instanceof Long) {
                l4 = (Long) obj6;
            } else {
                l4 = null;
            }
            if (l4 != null) {
                j3 = l4.longValue();
            } else {
                j3 = 0;
            }
            ByteArrayOutputStream byteArrayOutputStream6 = new ByteArrayOutputStream();
            ByteArrayOutputStream byteArrayOutputStream7 = new ByteArrayOutputStream();
            Fleet.varint(byteArrayOutputStream7, 8);
            Fleet.varint(byteArrayOutputStream7, j3);
            byte[] byteArray5 = byteArrayOutputStream7.toByteArray();
            Intrinsics.checkNotNullExpressionValue(byteArray5, "toByteArray(...)");
            Fleet.varint(byteArrayOutputStream6, 74);
            Fleet.varint(byteArrayOutputStream6, byteArray5.length);
            byteArrayOutputStream6.write(byteArray5);
            byte[] byteArray6 = byteArrayOutputStream6.toByteArray();
            Intrinsics.checkNotNullExpressionValue(byteArray6, "toByteArray(...)");
            send(sSLSocket, byteArray6);
        }
        List list5 = (List) read.get(40);
        if (list5 != null) {
            Object obj10 = list5.get(0);
            if (obj10 instanceof byte[]) {
                bArr7 = (byte[]) obj10;
            } else {
                bArr7 = null;
            }
            if (bArr7 == null) {
                bArr7 = new byte[0];
            }
            List list6 = (List) Fleet.read(bArr7).get(1);
            if (list6 != null) {
                obj5 = CollectionsKt.firstOrNull(list6);
            } else {
                obj5 = null;
            }
            if (obj5 instanceof Long) {
                l3 = (Long) obj5;
            } else {
                l3 = null;
            }
            if (l3 != null) {
                j2 = l3.longValue();
            } else {
                j2 = 0;
            }
            if (j2 != 0) {
                z = true;
            } else {
                z = false;
            }
            this.isOn = Boolean.valueOf(z);
        }
        List list7 = (List) read.get(50);
        if (list7 != null) {
            Object obj11 = list7.get(0);
            if (obj11 instanceof byte[]) {
                bArr6 = (byte[]) obj11;
            } else {
                bArr6 = null;
            }
            if (bArr6 == null) {
                bArr6 = new byte[0];
            }
            HashMap read3 = Fleet.read(bArr6);
            handle$lambda$10$n(read3, 7);
            handle$lambda$10$n(read3, 6);
            handle$lambda$10$n(read3, 8);
        }
        List list8 = (List) read.get(21);
        if (list8 != null) {
            Object obj12 = list8.get(0);
            if (obj12 instanceof byte[]) {
                bArr5 = (byte[]) obj12;
            } else {
                bArr5 = null;
            }
            if (bArr5 == null) {
                bArr5 = new byte[0];
            }
            HashMap read4 = Fleet.read(bArr5);
            List list9 = (List) read4.get(1);
            if (list9 != null) {
                obj3 = CollectionsKt.firstOrNull(list9);
            } else {
                obj3 = null;
            }
            if (obj3 instanceof Long) {
                l = (Long) obj3;
            } else {
                l = null;
            }
            if (l != null) {
                j = l.longValue();
            } else {
                j = 0;
            }
            this.ime = j;
            List list10 = (List) read4.get(Integer.valueOf(i));
            if (list10 != null) {
                obj4 = CollectionsKt.firstOrNull(list10);
            } else {
                obj4 = null;
            }
            if (obj4 instanceof Long) {
                l2 = (Long) obj4;
            } else {
                l2 = null;
            }
            if (l2 != null) {
                j4 = l2.longValue();
            }
            this.field = j4;
            this.hasField = true;
        }
        List list11 = (List) read.get(20);
        if (list11 != null) {
            Object obj13 = list11.get(0);
            if (obj13 instanceof byte[]) {
                bArr2 = (byte[]) obj13;
            } else {
                bArr2 = null;
            }
            if (bArr2 == null) {
                bArr2 = new byte[0];
            }
            List list12 = (List) Fleet.read(bArr2).get(1);
            if (list12 != null) {
                obj = CollectionsKt.firstOrNull(list12);
            } else {
                obj = null;
            }
            if (obj instanceof byte[]) {
                bArr3 = (byte[]) obj;
            } else {
                bArr3 = null;
            }
            if (bArr3 != null) {
                List list13 = (List) Fleet.read(bArr3).get(12);
                if (list13 != null) {
                    obj2 = CollectionsKt.firstOrNull(list13);
                } else {
                    obj2 = null;
                }
                if (obj2 instanceof byte[]) {
                    bArr4 = (byte[]) obj2;
                } else {
                    bArr4 = null;
                }
                if (bArr4 != null) {
                    str = new String(bArr4, Charsets.UTF_8);
                    if (str == null && str.length() != 0) {
                        if (!str.equals(this.app)) {
                            this.hasField = false;
                        }
                        this.app = str;
                        return;
                    }
                }
            }
            str = null;
            if (str == null) {
            }
        }
    }

    @Override // dev.tvremote.core.remote.Remote
    public final List inputs() {
        return EmptyList.INSTANCE;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final Boolean isOn() {
        return this.isOn;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void key(int i, int i2) {
        String str;
        WireLog wireLog = WireLog.all;
        if (i2 != 1) {
            if (i2 != 3) {
                str = "up";
            } else {
                str = "tap";
            }
        } else {
            str = "down";
        }
        wireLog.add("→", "remote " + this.host + " key " + i + " " + str);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
        Fleet.varint(byteArrayOutputStream2, (long) 8);
        Fleet.varint(byteArrayOutputStream2, (long) i);
        Fleet.varint(byteArrayOutputStream2, (long) 16);
        Fleet.varint(byteArrayOutputStream2, (long) i2);
        byte[] byteArray = byteArrayOutputStream2.toByteArray();
        Intrinsics.checkNotNullExpressionValue(byteArray, "toByteArray(...)");
        Fleet.varint(byteArrayOutputStream, 82);
        Fleet.varint(byteArrayOutputStream, byteArray.length);
        byteArrayOutputStream.write(byteArray);
        byte[] byteArray2 = byteArrayOutputStream.toByteArray();
        Intrinsics.checkNotNullExpressionValue(byteArray2, "toByteArray(...)");
        post(byteArray2);
    }

    public final void keys(String t) {
        int code;
        Intrinsics.checkNotNullParameter(t, "t");
        int length = t.length();
        for (int i = 0; i < length; i++) {
            char charAt = t.charAt(i);
            int code2 = Fleet.code(charAt);
            Integer valueOf = Integer.valueOf(code2);
            if (code2 == 0) {
                valueOf = null;
            }
            if (valueOf != null) {
                code = valueOf.intValue();
            } else {
                code = Fleet.code(Character.toLowerCase(charAt));
            }
            if (code != 0) {
                key(code, 3);
            }
        }
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void launch(String v) {
        Intrinsics.checkNotNullParameter(v, "link");
        Pattern compile = Pattern.compile("^[a-zA-Z][a-zA-Z0-9+.-]*:");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        if (!compile.matcher(v).find()) {
            v = "market://launch?id=".concat(v);
        }
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
        Intrinsics.checkNotNullParameter(v, "v");
        byte[] bytes = v.getBytes(Charsets.UTF_8);
        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        Fleet.varint(byteArrayOutputStream2, (1 << 3) | 2);
        Fleet.varint(byteArrayOutputStream2, bytes.length);
        byteArrayOutputStream2.write(bytes);
        byte[] byteArray = byteArrayOutputStream2.toByteArray();
        Intrinsics.checkNotNullExpressionValue(byteArray, "toByteArray(...)");
        Fleet.varint(byteArrayOutputStream, 722);
        Fleet.varint(byteArrayOutputStream, byteArray.length);
        byteArrayOutputStream.write(byteArray);
        byte[] byteArray2 = byteArrayOutputStream.toByteArray();
        Intrinsics.checkNotNullExpressionValue(byteArray2, "toByteArray(...)");
        post(byteArray2);
    }

    public final SSLSocket open() {
        try {
            SSLSocket dial = dial(6466);
            this.sock = dial;
            dial.setSoTimeout(8000);
            while (!this.live) {
                try {
                    try {
                        InputStream inputStream = dial.getInputStream();
                        Intrinsics.checkNotNullExpressionValue(inputStream, "getInputStream(...)");
                        byte[] frame$shared_release = Fleet.frame$shared_release(inputStream);
                        if (frame$shared_release == null) {
                            break;
                        }
                        handle(dial, frame$shared_release);
                    } catch (Exception unused) {
                        throw new IOException("timed out");
                    }
                } catch (SocketTimeoutException unused2) {
                    dial.close();
                    throw new IOException("timed out");
                } catch (Exception unused3) {
                }
            }
            if (!this.live) {
                dial.close();
                return null;
            }
            dial.setSoTimeout(0);
            return dial;
        } catch (SSLException | Exception unused4) {
            return null;
        }
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void pointer(int i, int i2) {
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void pointerClick() {
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void pointerHold(boolean z) {
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void pointerScroll(int i) {
    }

    public final void post(byte[] bArr) {
        if (!this.closed && this.sock != null) {
            this.out.execute(new Guard$$ExternalSyntheticLambda5(15, this, bArr));
        }
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void pulse(int i, final long j) {
        if (!this.closed && this.sock != null) {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
            long j2 = i;
            long j3 = 8;
            Fleet.varint(byteArrayOutputStream2, j3);
            Fleet.varint(byteArrayOutputStream2, j2);
            long j4 = 16;
            Fleet.varint(byteArrayOutputStream2, j4);
            Fleet.varint(byteArrayOutputStream2, 1L);
            byte[] byteArray = byteArrayOutputStream2.toByteArray();
            Intrinsics.checkNotNullExpressionValue(byteArray, "toByteArray(...)");
            long j5 = 82;
            Fleet.varint(byteArrayOutputStream, j5);
            Fleet.varint(byteArrayOutputStream, byteArray.length);
            byteArrayOutputStream.write(byteArray);
            final byte[] byteArray2 = byteArrayOutputStream.toByteArray();
            Intrinsics.checkNotNullExpressionValue(byteArray2, "toByteArray(...)");
            ByteArrayOutputStream byteArrayOutputStream3 = new ByteArrayOutputStream();
            ByteArrayOutputStream byteArrayOutputStream4 = new ByteArrayOutputStream();
            Fleet.varint(byteArrayOutputStream4, j3);
            Fleet.varint(byteArrayOutputStream4, j2);
            Fleet.varint(byteArrayOutputStream4, j4);
            Fleet.varint(byteArrayOutputStream4, 2L);
            byte[] byteArray3 = byteArrayOutputStream4.toByteArray();
            Intrinsics.checkNotNullExpressionValue(byteArray3, "toByteArray(...)");
            Fleet.varint(byteArrayOutputStream3, j5);
            Fleet.varint(byteArrayOutputStream3, byteArray3.length);
            byteArrayOutputStream3.write(byteArray3);
            final byte[] byteArray4 = byteArrayOutputStream3.toByteArray();
            Intrinsics.checkNotNullExpressionValue(byteArray4, "toByteArray(...)");
            this.out.execute(new Runnable() { // from class: dev.tvremote.core.remote.Atv$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    Atv atv = Atv.this;
                    byte[] bArr = byteArray2;
                    long j6 = j;
                    byte[] bArr2 = byteArray4;
                    SSLSocket sSLSocket = atv.sock;
                    if (atv.live && sSLSocket != null) {
                        try {
                            try {
                                atv.send(sSLSocket, bArr);
                                try {
                                    Thread.sleep(j6);
                                } catch (InterruptedException unused) {
                                }
                                atv.send(sSLSocket, bArr2);
                            } catch (Exception unused2) {
                            }
                        } catch (Exception unused3) {
                            sSLSocket.close();
                        }
                    }
                }
            });
        }
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean ready() {
        if (this.live && !this.closed) {
            return true;
        }
        return false;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean screenOff() {
        return false;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean search(String q) {
        Intrinsics.checkNotNullParameter(q, "q");
        return false;
    }

    public final synchronized void send(SSLSocket sSLSocket, byte[] bArr) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        long length = bArr.length;
        while (((-128) & length) != 0) {
            byteArrayOutputStream.write((int) ((127 & length) | 128));
            length >>>= 7;
        }
        byteArrayOutputStream.write((int) length);
        byteArrayOutputStream.write(bArr);
        sSLSocket.getOutputStream().write(byteArrayOutputStream.toByteArray());
        sSLSocket.getOutputStream().flush();
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean setVolume(int i) {
        return false;
    }

    @Override // dev.tvremote.core.remote.CodePairing
    public final void startPairing() {
        WireLog.all.add("·", "remote " + this.host + " pairing");
        try {
            SSLSocket sSLSocket = this.sock;
            if (sSLSocket != null) {
                sSLSocket.close();
            }
        } catch (Exception unused) {
        }
        SSLSocket dial = dial(6467);
        this.sock = dial;
        try {
            dial.setSoTimeout(15000);
        } catch (Exception unused2) {
        }
        try {
            Pb pb = new Pb();
            pb.str("atvremote", 1);
            pb.str("TV Remote", 2);
            startPairing$step(this, dial, 10, pb.bytes(), 11);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            Fleet.varint(byteArrayOutputStream, 8);
            Fleet.varint(byteArrayOutputStream, 3L);
            long j = 16;
            Fleet.varint(byteArrayOutputStream, j);
            Fleet.varint(byteArrayOutputStream, 6L);
            byte[] byteArray = byteArrayOutputStream.toByteArray();
            Intrinsics.checkNotNullExpressionValue(byteArray, "toByteArray(...)");
            ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
            long j2 = 10;
            Fleet.varint(byteArrayOutputStream2, j2);
            Fleet.varint(byteArrayOutputStream2, byteArray.length);
            byteArrayOutputStream2.write(byteArray);
            Fleet.varint(byteArrayOutputStream2, 24);
            Fleet.varint(byteArrayOutputStream2, 1L);
            byte[] byteArray2 = byteArrayOutputStream2.toByteArray();
            Intrinsics.checkNotNullExpressionValue(byteArray2, "toByteArray(...)");
            startPairing$step(this, dial, 20, byteArray2, 20);
            ByteArrayOutputStream byteArrayOutputStream3 = new ByteArrayOutputStream();
            Fleet.varint(byteArrayOutputStream3, j2);
            Fleet.varint(byteArrayOutputStream3, byteArray.length);
            byteArrayOutputStream3.write(byteArray);
            Fleet.varint(byteArrayOutputStream3, j);
            Fleet.varint(byteArrayOutputStream3, 1L);
            byte[] byteArray3 = byteArrayOutputStream3.toByteArray();
            Intrinsics.checkNotNullExpressionValue(byteArray3, "toByteArray(...)");
            startPairing$step(this, dial, 30, byteArray3, 31);
        } catch (Exception e) {
            try {
                dial.close();
            } catch (Exception unused3) {
            }
            throw e;
        }
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean switchInput(String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        return false;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void text(String t) {
        Intrinsics.checkNotNullParameter(t, "t");
        if (t.length() == 0) {
            return;
        }
        long length = t.length() - 1;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        long j = 8;
        Fleet.varint(byteArrayOutputStream, j);
        Fleet.varint(byteArrayOutputStream, 1L);
        ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
        Fleet.varint(byteArrayOutputStream2, 1 << 3);
        Fleet.varint(byteArrayOutputStream2, length);
        Fleet.varint(byteArrayOutputStream2, 2 << 3);
        Fleet.varint(byteArrayOutputStream2, length);
        byte[] bytes = t.getBytes(Charsets.UTF_8);
        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        Fleet.varint(byteArrayOutputStream2, (3 << 3) | 2);
        Fleet.varint(byteArrayOutputStream2, bytes.length);
        byteArrayOutputStream2.write(bytes);
        byte[] byteArray = byteArrayOutputStream2.toByteArray();
        Intrinsics.checkNotNullExpressionValue(byteArray, "toByteArray(...)");
        Fleet.varint(byteArrayOutputStream, 18);
        Fleet.varint(byteArrayOutputStream, byteArray.length);
        byteArrayOutputStream.write(byteArray);
        byte[] byteArray2 = byteArrayOutputStream.toByteArray();
        Intrinsics.checkNotNullExpressionValue(byteArray2, "toByteArray(...)");
        ByteArrayOutputStream byteArrayOutputStream3 = new ByteArrayOutputStream();
        ByteArrayOutputStream byteArrayOutputStream4 = new ByteArrayOutputStream();
        long j2 = this.ime;
        Fleet.varint(byteArrayOutputStream4, j);
        Fleet.varint(byteArrayOutputStream4, j2);
        long j3 = this.field;
        Fleet.varint(byteArrayOutputStream4, 16);
        Fleet.varint(byteArrayOutputStream4, j3);
        Fleet.varint(byteArrayOutputStream4, 26);
        Fleet.varint(byteArrayOutputStream4, byteArray2.length);
        byteArrayOutputStream4.write(byteArray2);
        byte[] byteArray3 = byteArrayOutputStream4.toByteArray();
        Intrinsics.checkNotNullExpressionValue(byteArray3, "toByteArray(...)");
        Fleet.varint(byteArrayOutputStream3, 170);
        Fleet.varint(byteArrayOutputStream3, byteArray3.length);
        byteArrayOutputStream3.write(byteArray3);
        byte[] byteArray4 = byteArrayOutputStream3.toByteArray();
        Intrinsics.checkNotNullExpressionValue(byteArray4, "toByteArray(...)");
        post(byteArray4);
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void type(String str, int i) {
        Fleet.type(this, i, str);
    }
}
