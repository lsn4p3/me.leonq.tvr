package dev.tvremote.core.remote;

import java.io.Closeable;
import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import kotlin.collections.ArraysKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;

/* loaded from: classes.dex */
public interface Remote extends Closeable {

    /* loaded from: classes.dex */
    public final class App {
        public final String id;
        public final String label;

        public App(String id, String label, String icon) {
            Intrinsics.checkNotNullParameter(id, "id");
            Intrinsics.checkNotNullParameter(label, "label");
            Intrinsics.checkNotNullParameter(icon, "icon");
            this.id = id;
            this.label = label;
        }
    }

    /* loaded from: classes.dex */
    public abstract class Kind {
        public static final List ALL = ArraysKt.asList(new String[]{"android", "lg", "samsung", "roku", "vidaa"});

        public static Set caps(String kind) {
            Intrinsics.checkNotNullParameter(kind, "kind");
            int hashCode = kind.hashCode();
            if (hashCode != 3451) {
                if (hashCode != 3506279) {
                    if (hashCode != 112202737) {
                        if (hashCode == 1864941562 && kind.equals("samsung")) {
                            return SetsKt.setOf((Object[]) new String[]{"keys", "text", "apps", "app_list", "wol", "scenes"});
                        }
                    } else if (kind.equals("vidaa")) {
                        return SetsKt.setOf((Object[]) new String[]{"keys", "text", "apps", "app_list", "volume_set", "screen_off", "wol", "scenes", "inputs", "pair_code"});
                    }
                } else if (kind.equals("roku")) {
                    return SetsKt.setOf((Object[]) new String[]{"keys", "text", "apps", "app_list", "wol", "scenes", "inputs"});
                }
            } else if (kind.equals("lg")) {
                return SetsKt.setOf((Object[]) new String[]{"keys", "text", "apps", "app_list", "volume_set", "link", "screen_off", "wol", "scenes", "inputs", "mouse"});
            }
            return SetsKt.setOf((Object[]) new String[]{"keys", "text", "apps", "volume_set", "link", "screen_off", "wol", "scenes", "adb", "pair_code", "store", "inputs", "mouse"});
        }

        public static String name(String kind) {
            Intrinsics.checkNotNullParameter(kind, "kind");
            int hashCode = kind.hashCode();
            if (hashCode != 3451) {
                if (hashCode != 3506279) {
                    if (hashCode != 112202737) {
                        if (hashCode == 1864941562 && kind.equals("samsung")) {
                            return "Samsung";
                        }
                        return "Android TV";
                    }
                    if (kind.equals("vidaa")) {
                        return "Hisense VIDAA";
                    }
                    return "Android TV";
                }
                if (kind.equals("roku")) {
                    return "Roku";
                }
                return "Android TV";
            }
            if (kind.equals("lg")) {
                return "LG";
            }
            return "Android TV";
        }

        public static String of(String str) {
            String lowerCase = str.toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
            if (!ALL.contains(lowerCase)) {
                lowerCase = null;
            }
            if (lowerCase == null) {
                return "android";
            }
            return lowerCase;
        }

        public static List ports(String kind) {
            int i;
            Intrinsics.checkNotNullParameter(kind, "kind");
            int hashCode = kind.hashCode();
            if (hashCode != 3451) {
                if (hashCode != 3506279) {
                    if (hashCode != 112202737) {
                        if (hashCode == 1864941562 && kind.equals("samsung")) {
                            return ArraysKt.asList(new Integer[]{8001, 8002});
                        }
                    } else if (kind.equals("vidaa")) {
                        i = 36669;
                        return MathKt.listOf(Integer.valueOf(i));
                    }
                } else if (kind.equals("roku")) {
                    i = 8060;
                    return MathKt.listOf(Integer.valueOf(i));
                }
            } else if (kind.equals("lg")) {
                return ArraysKt.asList(new Integer[]{3000, 3001});
            }
            i = 6466;
            return MathKt.listOf(Integer.valueOf(i));
        }
    }

    /* loaded from: classes.dex */
    public final class Refused extends IOException {
    }

    List apps();

    void connect(Function0 function0);

    String getApp();

    boolean getAsking();

    Set getKeys();

    String getKind();

    String getMac();

    String getModel();

    String getVendor();

    String getVersion();

    List inputs();

    Boolean isOn();

    void key(int i, int i2);

    void launch(String str);

    void pointer(int i, int i2);

    void pointerClick();

    void pointerHold(boolean z);

    void pointerScroll(int i);

    void pulse(int i, long j);

    boolean ready();

    boolean screenOff();

    boolean search(String str);

    boolean setVolume(int i);

    boolean switchInput(String str);

    void text(String str);

    void type(String str, int i);
}
