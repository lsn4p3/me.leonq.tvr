package dev.tvremote.core.remote;

import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Lan;
import dev.tvremote.core.Lan$$ExternalSyntheticLambda0;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Charsets;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.StringsKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class Ssdp {
    public static final List SEARCH = CollectionsKt__CollectionsKt.listOf((Object[]) new String[]{"urn:lge-com:service:webos-second-screen:1", "urn:samsung.com:device:RemoteControlReceiver:1", "roku:ecp", "urn:schemas-upnp-org:device:MediaRenderer:1"});

    /* loaded from: classes.dex */
    public final class Found {
        public final String ip;
        public final String kind;
        public final String name;

        public Found(String str, String str2, String str3) {
            this.ip = str;
            this.kind = str2;
            this.name = str3;
        }
    }

    public static String atMost$shared_release(InputStream inputStream) {
        int read;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byte[] bArr = new byte[8192];
        long currentTimeMillis = System.currentTimeMillis() + 4000;
        while (byteArrayOutputStream.size() < 262144 && System.currentTimeMillis() < currentTimeMillis && (read = inputStream.read(bArr, 0, Math.min(8192, 262144 - byteArrayOutputStream.size()))) >= 0) {
            byteArrayOutputStream.write(bArr, 0, read);
        }
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        Intrinsics.checkNotNullExpressionValue(byteArray, "toByteArray(...)");
        return new String(byteArray, Charsets.UTF_8);
    }

    public static String castName$default(String ip) {
        String str;
        int read;
        String str2;
        Intrinsics.checkNotNullParameter(ip, "ip");
        try {
            Socket connect = Lan.connect(ip, 8008, 800, new Lan$$ExternalSyntheticLambda0(0));
            try {
                connect.setSoTimeout(1500);
                OutputStream outputStream = connect.getOutputStream();
                byte[] bytes = ("GET /setup/eureka_info HTTP/1.1\r\nHost: " + ip + ":8008\r\nConnection: close\r\n\r\n").getBytes(Charsets.UTF_8);
                Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                outputStream.write(bytes);
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                byte[] bArr = new byte[2048];
                loop0: while (true) {
                    str = "";
                    while (str.length() == 0 && byteArrayOutputStream.size() < 20000 && (read = connect.getInputStream().read(bArr)) >= 0) {
                        try {
                            byteArrayOutputStream.write(bArr, 0, read);
                            Pattern compile = Pattern.compile("\"name\"\\s*:\\s*\"([^\"]{1,60})\"");
                            Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                            String byteArrayOutputStream2 = byteArrayOutputStream.toString("UTF-8");
                            Intrinsics.checkNotNullExpressionValue(byteArrayOutputStream2, "toString(...)");
                            Matcher matcher = compile.matcher(byteArrayOutputStream2);
                            Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
                            MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, byteArrayOutputStream2);
                            if (access$findNext != null && (str2 = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)) != null) {
                                str = str2;
                            }
                        } catch (Exception unused) {
                        }
                    }
                }
                connect.close();
                return str;
            } catch (Throwable th) {
                try {
                    throw th;
                } catch (Throwable th2) {
                    MathKt.closeFinally(connect, th);
                    throw th2;
                }
            }
        } catch (Exception unused2) {
            return "";
        }
    }

    public static List find(int i, Function1 bind, Function1 function1) {
        Intrinsics.checkNotNullParameter(bind, "bind");
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        try {
            DatagramSocket datagramSocket = new DatagramSocket();
            try {
                bind.invoke(datagramSocket);
                datagramSocket.setSoTimeout(300);
                InetAddress byName = InetAddress.getByName("239.255.255.250");
                for (int i2 = 0; i2 < 2; i2++) {
                    Iterator it = SEARCH.iterator();
                    while (it.hasNext()) {
                        byte[] bytes = ("M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\nST: " + ((String) it.next()) + "\r\n\r\n").getBytes(Charsets.UTF_8);
                        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                        datagramSocket.send(new DatagramPacket(bytes, bytes.length, byName, 1900));
                    }
                }
                long currentTimeMillis = System.currentTimeMillis() + i;
                byte[] bArr = new byte[4096];
                while (System.currentTimeMillis() < currentTimeMillis) {
                    DatagramPacket datagramPacket = new DatagramPacket(bArr, 4096);
                    try {
                        datagramSocket.receive(datagramPacket);
                        String hostAddress = datagramPacket.getAddress().getHostAddress();
                        if (hostAddress != null && !linkedHashMap.containsKey(hostAddress)) {
                            byte[] data = datagramPacket.getData();
                            Intrinsics.checkNotNullExpressionValue(data, "getData(...)");
                            String str = new String(data, 0, datagramPacket.getLength(), Charsets.UTF_8);
                            String kind = kind(str);
                            if (kind != null) {
                                Found found = new Found(hostAddress, kind, name(hostAddress, kind, location$shared_release(str, hostAddress)));
                                linkedHashMap.put(hostAddress, found);
                                function1.invoke(found);
                            }
                        }
                    } catch (SocketTimeoutException unused) {
                    }
                }
                datagramSocket.close();
            } finally {
            }
        } catch (Exception unused2) {
        }
        Collection values = linkedHashMap.values();
        Intrinsics.checkNotNullExpressionValue(values, "<get-values>(...)");
        return CollectionsKt.toList(values);
    }

    public static String get(String str) {
        String atMost$shared_release;
        try {
            Function0 function0 = Lan.wifi;
            HttpURLConnection httpURLConnection = (HttpURLConnection) Lan.open(new URL(str));
            httpURLConnection.setConnectTimeout(1200);
            httpURLConnection.setReadTimeout(1500);
            try {
                if (httpURLConnection.getResponseCode() != 200) {
                    atMost$shared_release = null;
                } else {
                    InputStream inputStream = httpURLConnection.getInputStream();
                    try {
                        Intrinsics.checkNotNull(inputStream);
                        atMost$shared_release = atMost$shared_release(inputStream);
                        inputStream.close();
                    } finally {
                    }
                }
                return atMost$shared_release;
            } finally {
                httpURLConnection.disconnect();
            }
        } catch (Exception unused) {
            return null;
        }
    }

    public static String kind(String str) {
        Pattern compile = Pattern.compile("(?i)roku:ecp");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        if (compile.matcher(str).find()) {
            return "roku";
        }
        Pattern compile2 = Pattern.compile("(?i)lge-com|webos");
        Intrinsics.checkNotNullExpressionValue(compile2, "compile(...)");
        if (compile2.matcher(str).find()) {
            return "lg";
        }
        Pattern compile3 = Pattern.compile("(?i)samsung|tizen");
        Intrinsics.checkNotNullExpressionValue(compile3, "compile(...)");
        if (compile3.matcher(str).find()) {
            return "samsung";
        }
        Pattern compile4 = Pattern.compile("(?i)vidaa|:38400/|:18400/");
        Intrinsics.checkNotNullExpressionValue(compile4, "compile(...)");
        if (compile4.matcher(str).find()) {
            return "vidaa";
        }
        return null;
    }

    public static String location$shared_release(String str, String str2) {
        String str3;
        MatcherMatchResult access$findNext = MathKt.access$findNext(Census$$ExternalSyntheticOutline0.m6m("(?im)^location:\\s*(\\S+)", "compile(...)", str, "matcher(...)"), 0, str);
        if (access$findNext != null && (str3 = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)) != null) {
            try {
                URL url = new URL(str3);
                if (Intrinsics.areEqual(url.getProtocol(), "http") || Intrinsics.areEqual(url.getProtocol(), "https")) {
                    String host = url.getHost();
                    Intrinsics.checkNotNullExpressionValue(host, "getHost(...)");
                    if (StringsKt.removeSuffix(StringsKt.removePrefix(host, "["), "]").equals(str2)) {
                        return str3;
                    }
                    return null;
                }
                return null;
            } catch (Exception unused) {
                return null;
            }
        }
        return null;
    }

    public static String name(String str, String str2, String str3) {
        String str4;
        MatcherMatchResult access$findNext;
        String str5;
        String obj;
        String optString;
        String str6 = null;
        if (str2.equals("roku")) {
            String str7 = get("http://" + str + ":8060/query/device-info");
            if (str7 != null) {
                Object obj2 = Roku.KEYS;
                String field$shared_release = Fleet.field$shared_release(str7, "user-device-name");
                if (field$shared_release.length() == 0) {
                    field$shared_release = Fleet.field$shared_release(str7, "friendly-device-name");
                }
                if (field$shared_release.length() <= 0) {
                    field$shared_release = null;
                }
                if (field$shared_release != null) {
                    return field$shared_release;
                }
            }
        }
        if (str2.equals("samsung")) {
            String str8 = get("http://" + str + ":8001/api/v2/");
            if (str8 != null) {
                try {
                    JSONObject optJSONObject = new JSONObject(str8).optJSONObject("device");
                    if (optJSONObject != null && (optString = optJSONObject.optString("name")) != null) {
                        if (optString.length() > 0) {
                            str6 = optString;
                        }
                        if (str6 != null) {
                            return StringsKt.removePrefix(str6, "[TV] ");
                        }
                    }
                } catch (Exception unused) {
                }
            }
        }
        if (str3 == null || (str4 = get(str3)) == null || (access$findNext = MathKt.access$findNext(Census$$ExternalSyntheticOutline0.m6m("<friendlyName>([^<]{1,80})</friendlyName>", "compile(...)", str4, "matcher(...)"), 0, str4)) == null || (str5 = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)) == null || (obj = StringsKt.trim(str5).toString()) == null) {
            return "";
        }
        return StringsKt.removePrefix(obj, "[TV] ");
    }
}
