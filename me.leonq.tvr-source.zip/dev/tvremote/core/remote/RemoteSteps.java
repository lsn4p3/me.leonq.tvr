package dev.tvremote.core.remote;

import dev.tvremote.core.scenes.Scenes;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class RemoteSteps implements Scenes.Target {
    public final Remote r;
    public final Function0 wake;

    public RemoteSteps(Remote r, Function0 function0) {
        Intrinsics.checkNotNullParameter(r, "r");
        this.r = r;
        this.wake = function0;
    }

    @Override // dev.tvremote.core.scenes.Scenes.Target
    public final void app(String str) {
        this.r.launch(str);
    }

    @Override // dev.tvremote.core.scenes.Scenes.Target
    public final void input(String str) {
        if (this.r.switchInput(str)) {
        } else {
            throw new IllegalArgumentException("this TV cannot switch inputs from here");
        }
    }

    @Override // dev.tvremote.core.scenes.Scenes.Target
    public final void key(int i) {
        Remote remote = this.r;
        if (i == 224) {
            if (!Intrinsics.areEqual(remote.isOn(), Boolean.TRUE)) {
                this.wake.invoke();
            }
        } else if (i == 223) {
            if (!Intrinsics.areEqual(remote.isOn(), Boolean.FALSE)) {
                remote.key(26, 3);
            }
        } else {
            remote.key(i, 3);
            Thread.sleep(150L);
        }
    }

    @Override // dev.tvremote.core.scenes.Scenes.Target
    public final void link(String str) {
        this.r.launch(str);
    }

    @Override // dev.tvremote.core.scenes.Scenes.Target
    public final void notify(JSONObject jSONObject) {
        throw new IllegalArgumentException("a message on the TV needs ADB and TV Setup");
    }

    @Override // dev.tvremote.core.scenes.Scenes.Target
    public final void timer(int i) {
        throw new IllegalArgumentException("the sleep timer needs TV Setup on an Android TV");
    }

    @Override // dev.tvremote.core.scenes.Scenes.Target
    public final void volume(int i) {
        if (this.r.setVolume(i)) {
        } else {
            throw new IllegalArgumentException("this TV only has the volume keys");
        }
    }
}
