package dev.tvremote.core.remote;

import dev.tvremote.phone.remote.Gp;
import kotlin.math.MathKt;

/* loaded from: classes.dex */
public final /* synthetic */ class Lg$$ExternalSyntheticLambda14 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ WebSocket f$0;

    public /* synthetic */ Lg$$ExternalSyntheticLambda14(WebSocket webSocket, int i) {
        this.$r8$classId = i;
        this.f$0 = webSocket;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i;
        int i2;
        switch (this.$r8$classId) {
            case 0:
                do {
                    try {
                    } catch (Exception unused) {
                        return;
                    }
                } while (this.f$0.read() != null);
                return;
            case 1:
                WebSocket webSocket = this.f$0;
                if (webSocket != null) {
                    webSocket.close();
                    return;
                }
                return;
            case 2:
                WebSocket webSocket2 = this.f$0;
                if (webSocket2 != null) {
                    try {
                        webSocket2.send("pc");
                        return;
                    } catch (Exception unused2) {
                        return;
                    }
                }
                return;
            case 3:
                WebSocket webSocket3 = this.f$0;
                long j = 0;
                while (true) {
                    try {
                        Gp gp = Gp.INSTANCE;
                        if (Gp.alive && Gp.ws == webSocket3) {
                            Thread.sleep(8L);
                            synchronized (gp) {
                                float[] fArr = Gp.pending;
                                float f = fArr[0];
                                i = (int) f;
                                float f2 = fArr[1];
                                i2 = (int) f2;
                                fArr[0] = f - i;
                                fArr[1] = f2 - i2;
                            }
                            if (i != 0 || i2 != 0) {
                                webSocket3.send("m " + MathKt.coerceIn(i, -400, 400) + " " + MathKt.coerceIn(i2, -400, 400));
                            }
                            long currentTimeMillis = System.currentTimeMillis();
                            if (currentTimeMillis - j > 2000) {
                                webSocket3.send("p " + currentTimeMillis);
                                j = currentTimeMillis;
                            }
                        } else {
                            return;
                        }
                    } catch (Exception unused3) {
                        return;
                    }
                }
                break;
            case 4:
                WebSocket webSocket4 = this.f$0;
                if (webSocket4 != null) {
                    try {
                        webSocket4.send("d A " + System.currentTimeMillis());
                        return;
                    } catch (Exception unused4) {
                        return;
                    }
                }
                return;
            default:
                WebSocket webSocket5 = this.f$0;
                if (webSocket5 != null) {
                    try {
                        webSocket5.send("u A " + System.currentTimeMillis());
                        return;
                    } catch (Exception unused5) {
                        return;
                    }
                }
                return;
        }
    }
}
