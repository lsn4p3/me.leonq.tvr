package dev.tvremote.core.remote;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Diagnose;
import dev.tvremote.core.Diagnose$$ExternalSyntheticLambda1;
import dev.tvremote.core.WireLog;
import dev.tvremote.core.Words$$ExternalSyntheticLambda1;
import dev.tvremote.core.adb.Adb$$ExternalSyntheticLambda0;
import dev.tvremote.core.adb.Adb$$ExternalSyntheticLambda5;
import dev.tvremote.core.ontv.Setup$$ExternalSyntheticLambda5;
import dev.tvremote.core.remote.Inputs;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.core.remote.Vidaa;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda5;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.net.URLEncoder;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.EmptyList;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class Lg implements Remote {
    public static final HashMap KEYS;
    public static final String MANIFEST;
    public volatile String app;
    public volatile boolean asking;
    public volatile boolean closed;
    public volatile boolean external;
    public final ConcurrentHashMap held;
    public final String host;
    public final ConcurrentHashMap icons;
    public final AtomicInteger ids;
    public final Inputs.Cache inputList;
    public volatile Boolean isOn;
    public volatile boolean live;
    public volatile String mac;
    public volatile String model;
    public final ScheduledExecutorService out;
    public final ConcurrentHashMap pending;
    public volatile boolean playing;
    public volatile WebSocket pointer;
    public volatile int pointerDown;
    public volatile int port;
    public final List ports;
    public volatile boolean powerUnknown;
    public final Diagnose.Real saved;
    public volatile boolean secure;
    public final ConcurrentHashMap subs;
    public volatile String version;
    public volatile Triple volume;
    public volatile WebSocket ws;
    public static final List PORTS = ArraysKt.asList(new Pair[]{new Pair(3000, Boolean.FALSE), new Pair(3001, Boolean.TRUE)});
    public static final Set OFF = SetsKt.setOf((Object[]) new String[]{"Power Off", "Suspend", "Active Standby"});
    public static final Set REPEATS = SetsKt.setOf((Object[]) new Integer[]{19, 20, 21, 22, 24, 25, 166, 167, 89, 90, 67});

    /* loaded from: classes.dex */
    public final class Pending {
        public final CountDownLatch done = new CountDownLatch(1);
        public volatile JSONObject got;
    }

    static {
        HashMap hashMap = new HashMap();
        hashMap.putAll(MapsKt__MapsKt.mapOf(new Pair(19, "UP"), new Pair(20, "DOWN"), new Pair(21, "LEFT"), new Pair(22, "RIGHT"), new Pair(23, "ENTER"), new Pair(4, "BACK"), new Pair(3, "HOME"), new Pair(82, "MENU"), new Pair(176, "MENU"), new Pair(165, "INFO"), new Pair(172, "GUIDE"), new Pair(175, "CC"), new Pair(86, "STOP"), new Pair(89, "REWIND"), new Pair(90, "FASTFORWARD"), new Pair(24, "VOLUMEUP"), new Pair(25, "VOLUMEDOWN"), new Pair(166, "CHANNELUP"), new Pair(167, "CHANNELDOWN"), new Pair(26, ""), new Pair(223, ""), new Pair(224, ""), new Pair(66, ""), new Pair(67, ""), new Pair(164, ""), new Pair(170, ""), new Pair(85, "")));
        for (int i = 0; i < 10; i++) {
            hashMap.put(Integer.valueOf(i + 7), String.valueOf(i));
        }
        KEYS = hashMap;
        String jSONObject = new JSONObject().put("forcePairing", false).put("pairingType", "PROMPT").put("manifest", new JSONObject().put("manifestVersion", 1).put("appVersion", "1.1").put("signed", Census$$ExternalSyntheticOutline0.m10m("created", "20140509", "appId", "com.lge.test").put("vendorId", "com.lge").put("localizedAppNames", Census$$ExternalSyntheticOutline0.m10m("", "LG Remote App", "ko-KR", "리모컨 앱").put("zxx-XX", "ЛГ Rэмotэ AПП")).put("localizedVendorNames", new JSONObject().put("", "LG Electronics")).put("permissions", new JSONArray((Collection) ArraysKt.asList(new String[]{"TEST_SECURE", "CONTROL_INPUT_TEXT", "CONTROL_MOUSE_AND_KEYBOARD", "READ_INSTALLED_APPS", "READ_LGE_SDX", "READ_NOTIFICATIONS", "SEARCH", "WRITE_SETTINGS", "WRITE_NOTIFICATION_ALERT", "CONTROL_POWER", "READ_CURRENT_CHANNEL", "READ_RUNNING_APPS", "READ_UPDATE_INFO", "UPDATE_FROM_REMOTE_APP", "READ_LGE_TV_INPUT_EVENTS", "READ_TV_CURRENT_TIME"}))).put("serial", "2f930e2d2cfe083771f68e4fe7bb07")).put("permissions", new JSONArray((Collection) ArraysKt.asList(new String[]{"LAUNCH", "LAUNCH_WEBAPP", "APP_TO_APP", "CLOSE", "TEST_OPEN", "TEST_PROTECTED", "CONTROL_AUDIO", "CONTROL_DISPLAY", "CONTROL_INPUT_JOYSTICK", "CONTROL_INPUT_MEDIA_RECORDING", "CONTROL_INPUT_MEDIA_PLAYBACK", "CONTROL_INPUT_TV", "CONTROL_POWER", "READ_APP_STATUS", "READ_CURRENT_CHANNEL", "READ_INPUT_DEVICE_LIST", "READ_NETWORK_STATE", "READ_RUNNING_APPS", "READ_TV_CHANNEL_LIST", "WRITE_NOTIFICATION_TOAST", "READ_POWER_STATE", "READ_COUNTRY_INFO", "READ_SETTINGS", "CONTROL_TV_SCREEN", "CONTROL_TV_STANBY", "CONTROL_FAVORITE_GROUP", "CONTROL_USER_INFO", "CHECK_BLUETOOTH_DEVICE", "CONTROL_BLUETOOTH", "CONTROL_TIMER_INFO", "STB_INTERNAL_CONNECTION", "CONTROL_RECORDING", "READ_RECORDING_STATE", "WRITE_RECORDING_LIST", "READ_RECORDING_LIST", "READ_RECORDING_SCHEDULE", "WRITE_RECORDING_SCHEDULE", "READ_STORAGE_DEVICE_LIST", "READ_TV_PROGRAM_INFO", "CONTROL_BOX_CHANNEL", "READ_TV_ACR_AUTH_TOKEN", "READ_TV_CONTENT_STATE", "READ_TV_CURRENT_TIME", "ADD_LAUNCHER_CHANNEL", "SET_CHANNEL_SKIP", "RELEASE_CHANNEL_SKIP", "CONTROL_CHANNEL_BLOCK", "DELETE_SELECT_CHANNEL", "CONTROL_CHANNEL_GROUP", "SCAN_TV_CHANNELS", "CONTROL_TV_POWER", "CONTROL_WOL"}))).put("signatures", new JSONArray().put(new JSONObject().put("signatureVersion", 1).put("signature", "eyJhbGdvcml0aG0iOiJSU0EtU0hBMjU2Iiwia2V5SWQiOiJ0ZXN0LXNpZ25pbmctY2VydCIsInNpZ25hdHVyZVZlcnNpb24iOjF9.hrVRgjCwXVvE2OOSpDZ58hR+59aFNwYDyjQgKk3auukd7pcegmE2CzPCa0bJ0ZsRAcKkCTJrWo5iDzNhMBWRyaMOv5zWSrthlf7G128qvIlpMT0YNY+n/FaOHE73uLrS/g7swl3/qH/BGFG2Hu4RlL48eb3lLKqTt2xKHdCs6Cd4RMfJPYnzgvI4BNrFUKsjkcu+WD4OO2A27Pq1n50cMchmcaXadJhGrOqH5YmHdOCj5NSHzJYrsW0HPlpuAx/ECMeIZYDh6RMqaFM2DXzdKX9NmmyqzJ3o/0lkk/N97gfVRLW5hA29yeAwaCViZNCP8iC9aO0q9fQojoa7NQnAtw==")))).toString();
        Intrinsics.checkNotNullExpressionValue(jSONObject, "toString(...)");
        MANIFEST = jSONObject;
    }

    public Lg(File file, String host) {
        List ports = PORTS;
        Intrinsics.checkNotNullParameter(host, "host");
        Intrinsics.checkNotNullParameter(ports, "ports");
        this.host = host;
        this.ports = ports;
        this.model = "";
        this.version = "";
        this.app = "";
        this.mac = "";
        this.saved = new Diagnose.Real(file, "lg");
        this.ids = new AtomicInteger();
        this.pending = new ConcurrentHashMap();
        this.subs = new ConcurrentHashMap();
        this.out = Executors.newSingleThreadScheduledExecutor(new Diagnose$$ExternalSyntheticLambda1(3));
        this.held = new ConcurrentHashMap();
        this.icons = new ConcurrentHashMap();
        this.inputList = new Inputs.Cache();
    }

    public static JSONObject request$default(Lg lg, String str, JSONObject jSONObject, long j, int i) {
        if ((i & 2) != 0) {
            jSONObject = null;
        }
        if ((i & 4) != 0) {
            j = 5000;
        }
        lg.getClass();
        String m = ApkSigner$$ExternalSyntheticOutline0.m("r", lg.ids.incrementAndGet());
        Pending pending = new Pending();
        lg.pending.put(m, pending);
        try {
            JSONObject put = new JSONObject().put("id", m).put("type", "request").put("uri", str);
            if (jSONObject != null) {
                put.put("payload", jSONObject);
            }
            Intrinsics.checkNotNullExpressionValue(put, "apply(...)");
            lg.send(put);
            pending.done.await(j, TimeUnit.MILLISECONDS);
            lg.pending.remove(m);
            JSONObject jSONObject2 = pending.got;
            if (jSONObject2 != null && !Intrinsics.areEqual(jSONObject2.optString("type"), "error")) {
                JSONObject optJSONObject = jSONObject2.optJSONObject("payload");
                if (optJSONObject == null) {
                    optJSONObject = new JSONObject();
                }
                if (optJSONObject.optBoolean("returnValue", true)) {
                    return optJSONObject;
                }
            }
        } catch (Exception unused) {
            lg.pending.remove(m);
        } catch (Throwable th) {
            lg.pending.remove(m);
            throw th;
        }
        return null;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final List apps() {
        JSONArray optJSONArray;
        JSONObject request$default = request$default(this, "ssap://com.webos.applicationManager/listLaunchPoints", null, 8000L, 2);
        if (request$default != null && (optJSONArray = request$default.optJSONArray("launchPoints")) != null) {
            ArrayList arrayList = new ArrayList();
            int length = optJSONArray.length();
            for (int i = 0; i < length; i++) {
                JSONObject optJSONObject = optJSONArray.optJSONObject(i);
                if (optJSONObject != null) {
                    String optString = optJSONObject.optString("id");
                    Intrinsics.checkNotNull(optString);
                    if (optString.length() != 0) {
                        String optString2 = optJSONObject.optString("icon");
                        if (optString2.length() == 0) {
                            optString2 = optJSONObject.optString("largeIcon");
                        }
                        Intrinsics.checkNotNull(optString2);
                        if (optString2.length() > 0) {
                            this.icons.put(optString, optString2);
                        }
                        String optString3 = optJSONObject.optString("title");
                        if (optString3.length() == 0) {
                            optString3 = optString;
                        }
                        arrayList.add(new Remote.App(optString, optString3, optString2));
                    }
                }
            }
            return arrayList;
        }
        return EmptyList.INSTANCE;
    }

    public final void button(String str) {
        WireLog.all.add("→", Census$$ExternalSyntheticOutline0.m("LG ", this.host, " button ", str));
        try {
            pointer().send("type:button\nname:" + str + "\n\n");
        } catch (IOException unused) {
            WebSocket webSocket = this.pointer;
            if (webSocket != null) {
                webSocket.close();
            }
            this.pointer = null;
            try {
                pointer().send("type:button\nname:" + str + "\n\n");
            } catch (IOException unused2) {
            }
        }
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        this.closed = true;
        this.live = false;
        this.out.shutdownNow();
        new Thread(new Guard$$ExternalSyntheticLambda5(16, this.ws, this.pointer)).start();
    }

    /* JADX WARN: Type inference failed for: r3v10, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    @Override // dev.tvremote.core.remote.Remote
    public final void connect(Function0 function0) {
        final int i;
        IOException iOException;
        int i2;
        WebSocket webSocket;
        String str;
        String str2;
        String str3;
        String str4;
        String str5;
        String optString;
        String str6;
        int intValue;
        String str7 = "error";
        String str8 = this.saved.get(this.host);
        Integer intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull(StringsKt.substringBefore(str8, ' ', str8));
        if (intOrNull != null) {
            i = intOrNull.intValue();
        } else {
            i = 0;
        }
        Iterator it = CollectionsKt.sortedWith(this.ports, new Comparator() { // from class: dev.tvremote.core.remote.Lg$connect$$inlined$sortedBy$1
            @Override // java.util.Comparator
            public final int compare(Object obj, Object obj2) {
                int i3;
                int intValue2 = ((Number) ((Pair) obj).first).intValue();
                int i4 = 1;
                int i5 = i;
                if (intValue2 == i5) {
                    i3 = 0;
                } else {
                    i3 = 1;
                }
                Integer valueOf = Integer.valueOf(i3);
                if (((Number) ((Pair) obj2).first).intValue() == i5) {
                    i4 = 0;
                }
                return MathKt.compareValues(valueOf, Integer.valueOf(i4));
            }
        }).iterator();
        IOException e = null;
        WebSocket webSocket2 = null;
        while (true) {
            Iterator it2 = it;
            WebSocket webSocket3 = webSocket2;
            if (it.hasNext()) {
                Pair pair = (Pair) it2.next();
                intValue = ((Number) pair.first).intValue();
                boolean booleanValue = ((Boolean) pair.second).booleanValue();
                try {
                    SecureRandom secureRandom = WebSocket.RANDOM;
                    iOException = e;
                    i2 = i;
                    try {
                        WebSocket open$default = Vidaa.Companion.open$default(this.host, intValue, "/", booleanValue);
                        try {
                            this.port = intValue;
                            this.secure = booleanValue;
                            webSocket = open$default;
                            break;
                        } catch (IOException e2) {
                            e = e2;
                            webSocket3 = open$default;
                        }
                    } catch (IOException e3) {
                        e = e3;
                    }
                } catch (IOException e4) {
                    e = e4;
                    i2 = i;
                }
            } else {
                iOException = e;
                i2 = i;
                webSocket = webSocket3;
                break;
            }
            WireLog.all.add("·", "LG " + this.host + ":" + intValue + " " + e);
            it = it2;
            webSocket2 = webSocket3;
            i = i2;
            str7 = str7;
        }
        String str9 = str7;
        if (webSocket == null) {
            if (iOException != null) {
                throw iOException;
            }
            throw new IOException("no port");
        }
        if (!this.closed) {
            this.ws = webSocket;
            WireLog wireLog = WireLog.all;
            String str10 = this.host;
            int i3 = this.port;
            String str11 = "";
            if (this.secure) {
                str = " ";
                str2 = " (wss)";
            } else {
                str = " ";
                str2 = "";
            }
            Object obj = "register_0";
            wireLog.add("·", "LG " + str10 + ":" + i3 + " open" + str2);
            webSocket.sock.setSoTimeout(0);
            Thread thread = new Thread(new Lg$$ExternalSyntheticLambda2(this, webSocket, function0, 0), "lg-in");
            thread.setDaemon(true);
            thread.start();
            try {
                JSONObject put = new JSONObject().put("id", "hello_0").put("type", "hello").put("payload", new JSONObject());
                Intrinsics.checkNotNullExpressionValue(put, "put(...)");
                send(put);
                str4 = "·";
                str3 = "LG ";
                int i4 = i2;
                try {
                    JSONObject request$default = request$default(this, "ssap://system/getSystemInfo", null, 2000L, 2);
                    if (request$default != null) {
                        String optString2 = request$default.optString("modelName");
                        Intrinsics.checkNotNullExpressionValue(optString2, "optString(...)");
                        this.model = optString2;
                    }
                    if (i4 != this.port) {
                        str5 = "";
                    } else {
                        str5 = StringsKt.substringAfter(str8, ' ', "");
                    }
                    JSONObject jSONObject = new JSONObject(MANIFEST);
                    if (str5.length() > 0) {
                        jSONObject.put("client-key", str5);
                    }
                    CountDownLatch countDownLatch = new CountDownLatch(1);
                    ?? obj2 = new Object();
                    Object obj3 = obj;
                    try {
                        this.subs.put(obj3, new Adb$$ExternalSyntheticLambda5(this, obj2, countDownLatch, 2));
                        JSONObject put2 = new JSONObject().put("id", obj3).put("type", "register").put("payload", jSONObject);
                        Intrinsics.checkNotNullExpressionValue(put2, "put(...)");
                        send(put2);
                        long j = 1000000;
                        long nanoTime = (System.nanoTime() / j) + 60000;
                        while (obj2.element == null) {
                            try {
                                if (System.nanoTime() / j >= nanoTime || this.closed) {
                                    break;
                                }
                                try {
                                    if (webSocket.closed) {
                                        break;
                                    }
                                    Object obj4 = obj3;
                                    countDownLatch.await(300L, TimeUnit.MILLISECONDS);
                                    obj3 = obj4;
                                } catch (Exception e5) {
                                    e = e5;
                                    obj = obj3;
                                    obj3 = obj;
                                    WireLog.all.add(str4, str3 + this.host + " pairing: " + e);
                                    this.asking = false;
                                    this.subs.remove(obj3);
                                    webSocket.close();
                                    this.ws = null;
                                    throw e;
                                }
                            } catch (Exception e6) {
                                e = e6;
                                WireLog.all.add(str4, str3 + this.host + " pairing: " + e);
                                this.asking = false;
                                this.subs.remove(obj3);
                                webSocket.close();
                                this.ws = null;
                                throw e;
                            }
                        }
                        obj = obj3;
                        this.subs.remove(obj);
                        this.asking = false;
                        JSONObject jSONObject2 = (JSONObject) obj2.element;
                        if (jSONObject2 == null) {
                            if (webSocket.closed) {
                                str6 = "the TV closed the connection";
                            } else {
                                str6 = "nobody accepted on the TV";
                            }
                            throw new IOException(str6);
                        }
                        if (Intrinsics.areEqual(jSONObject2.optString("type"), str9)) {
                            String optString3 = jSONObject2.optString(str9);
                            if (optString3.length() == 0) {
                                optString3 = "the TV said no";
                            }
                            throw new IOException(optString3);
                        }
                        JSONObject optJSONObject = jSONObject2.optJSONObject("payload");
                        if (optJSONObject != null && (optString = optJSONObject.optString("client-key")) != null) {
                            str11 = optString;
                        }
                        if (str11.length() != 0) {
                            this.saved.put(this.host, this.port + str + str11);
                            this.live = true;
                            Thread thread2 = new Thread(new Adb$$ExternalSyntheticLambda0(4, this), "lg-learn");
                            thread2.setDaemon(true);
                            thread2.start();
                            return;
                        }
                        throw new IOException("the TV gave no client key");
                    } catch (Exception e7) {
                        e = e7;
                    }
                } catch (Exception e8) {
                    e = e8;
                }
            } catch (Exception e9) {
                e = e9;
                str3 = "LG ";
                str4 = "·";
            }
        } else {
            webSocket.close();
            throw new IOException("closed");
        }
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getApp() {
        return this.app;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean getAsking() {
        return this.asking;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final Set getKeys() {
        return KEYS.keySet();
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getKind() {
        return "lg";
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getMac() {
        return this.mac;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getModel() {
        return this.model;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getVendor() {
        return "LG";
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getVersion() {
        return this.version;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final List inputs() {
        return this.inputList.get(false, new Setup$$ExternalSyntheticLambda5(4, this));
    }

    @Override // dev.tvremote.core.remote.Remote
    public final Boolean isOn() {
        return this.isOn;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void key(int i, int i2) {
        if (!this.closed && KEYS.containsKey(Integer.valueOf(i))) {
            if (i2 != 1) {
                if (i2 == 2) {
                    ScheduledFuture scheduledFuture = (ScheduledFuture) this.held.remove(Integer.valueOf(i));
                    if (scheduledFuture != null) {
                        scheduledFuture.cancel(false);
                        return;
                    }
                    return;
                }
            } else {
                ScheduledFuture scheduledFuture2 = (ScheduledFuture) this.held.remove(Integer.valueOf(i));
                if (scheduledFuture2 != null) {
                    scheduledFuture2.cancel(false);
                }
                if (REPEATS.contains(Integer.valueOf(i))) {
                    this.held.put(Integer.valueOf(i), this.out.scheduleWithFixedDelay(new Lg$$ExternalSyntheticLambda8(this, i, 0), 180L, 180L, TimeUnit.MILLISECONDS));
                }
            }
            this.out.execute(new Lg$$ExternalSyntheticLambda8(this, i, 1));
        }
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void launch(String link) {
        Intrinsics.checkNotNullParameter(link, "link");
        this.out.execute(new Lg$$ExternalSyntheticLambda0(link, this));
    }

    public final WebSocket pointer() {
        String optString;
        WebSocket webSocket = this.pointer;
        if (webSocket != null && !webSocket.closed) {
            return webSocket;
        }
        JSONObject request$default = request$default(this, "ssap://com.webos.service.networkinput/getPointerInputSocket", null, 0L, 6);
        if (request$default != null && (optString = request$default.optString("socketPath")) != null) {
            Pattern compile = Pattern.compile("^ws");
            Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
            String replaceFirst = compile.matcher(optString).replaceFirst("http");
            Intrinsics.checkNotNullExpressionValue(replaceFirst, "replaceFirst(...)");
            URL url = new URL(replaceFirst);
            boolean startsWith = StringsKt__StringsJVMKt.startsWith(optString, false, "wss");
            SecureRandom secureRandom = WebSocket.RANDOM;
            String host = url.getHost();
            Intrinsics.checkNotNullExpressionValue(host, "getHost(...)");
            int port = url.getPort() > 0 ? url.getPort() : startsWith ? 443 : 80;
            String file = url.getFile();
            if (file.length() == 0) {
                file = "/";
            }
            WebSocket open$default = Vidaa.Companion.open$default(host, port, file, startsWith);
            open$default.sock.setSoTimeout(0);
            Thread thread = new Thread(new Lg$$ExternalSyntheticLambda14(open$default, 0), "lg-pointer");
            thread.setDaemon(true);
            thread.start();
            this.pointer = open$default;
            return open$default;
        }
        throw new IOException("the TV gave no input socket");
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void pointerClick() {
        if (ready()) {
            this.out.execute(new Lg$$ExternalSyntheticLambda0(1, this, "type:click\n\n"));
        }
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void pointerHold(boolean z) {
        this.pointerDown = z ? 1 : 0;
        pointer(0, 0);
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void pointerScroll(int i) {
        if (ready()) {
            this.out.execute(new Lg$$ExternalSyntheticLambda0(1, this, ApkSigner$$ExternalSyntheticOutline0.m("type:scroll\ndx:0\ndy:", -i, "\n\n")));
        }
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void pulse(int i, long j) {
        key(i, 3);
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean ready() {
        if (this.live && !this.closed) {
            return true;
        }
        return false;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean screenOff() {
        if (request$default(this, "ssap://com.webos.service.tvpower/power/turnOffScreen", null, 0L, 6) != null) {
            return true;
        }
        return false;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean search(String q) {
        Intrinsics.checkNotNullParameter(q, "q");
        String encode = URLEncoder.encode(q, "UTF-8");
        Intrinsics.checkNotNullExpressionValue(encode, "encode(...)");
        if (request$default(this, "ssap://system.launcher/launch", Census$$ExternalSyntheticOutline0.m8m("id", "youtube.leanback.v4").put("params", new JSONObject().put("contentTarget", "https://www.youtube.com/tv?#/search?q=".concat(StringsKt__StringsJVMKt.replace$default(encode, "+", "%20")))), 0L, 4) != null) {
            return true;
        }
        return false;
    }

    public final void send(JSONObject jSONObject) {
        WebSocket webSocket = this.ws;
        if (webSocket != null) {
            String jSONObject2 = jSONObject.toString();
            Intrinsics.checkNotNullExpressionValue(jSONObject2, "toString(...)");
            WireLog.all.add("→", Census$$ExternalSyntheticOutline0.m("LG ", this.host, " ", jSONObject2));
            webSocket.send(jSONObject2);
            return;
        }
        throw new IOException("not connected");
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean setVolume(int i) {
        Lg lg;
        String str;
        if (ready()) {
            if (!this.external) {
                lg = this;
                if (request$default(this, "ssap://audio/setVolume", new JSONObject().put("volume", i), 0L, 4) != null) {
                    return true;
                }
            } else {
                lg = this;
            }
            int i2 = 0;
            while (i2 < 60) {
                Triple triple = lg.volume;
                if (triple != null) {
                    int intValue = ((Number) triple.first).intValue();
                    if (intValue != i) {
                        if (intValue < i) {
                            str = "ssap://audio/volumeUp";
                        } else {
                            str = "ssap://audio/volumeDown";
                        }
                        request$default(lg, str, null, 0L, 6);
                        Thread.sleep(300L);
                        i2++;
                        lg = this;
                    } else {
                        return true;
                    }
                }
            }
            return true;
        }
        return false;
    }

    public final boolean subscribe(String str, Function1 function1) {
        JSONObject optJSONObject;
        String m = ApkSigner$$ExternalSyntheticOutline0.m("s", this.ids.incrementAndGet());
        Pending pending = new Pending();
        this.pending.put(m, pending);
        this.subs.put(m, new Words$$ExternalSyntheticLambda1(8, function1));
        try {
            JSONObject put = new JSONObject().put("id", m).put("type", "subscribe").put("uri", str);
            Intrinsics.checkNotNullExpressionValue(put, "put(...)");
            send(put);
            pending.done.await(5000L, TimeUnit.MILLISECONDS);
            JSONObject jSONObject = pending.got;
            if (jSONObject != null && !Intrinsics.areEqual(jSONObject.optString("type"), "error") && ((optJSONObject = jSONObject.optJSONObject("payload")) == null || optJSONObject.optBoolean("returnValue", true))) {
                return true;
            }
            this.subs.remove(m);
            return false;
        } catch (Exception unused) {
            this.subs.remove(m);
            return false;
        }
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean switchInput(String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        Object obj = Inputs.TYPES;
        if (Inputs.SAFE_ID.matches(id) && request$default(this, "ssap://tv/switchInput", Census$$ExternalSyntheticOutline0.m8m("inputId", id), 0L, 4) != null) {
            return true;
        }
        return false;
    }

    public final void tap(int i) {
        String str;
        String str2;
        if (ready()) {
            if (i != 26) {
                if (i != 85) {
                    if (i != 164) {
                        if (i != 170) {
                            if (i != 66) {
                                if (i != 67) {
                                    if (i != 223) {
                                        if (i != 224 && (str2 = (String) KEYS.get(Integer.valueOf(i))) != null) {
                                            button(str2);
                                            return;
                                        }
                                        return;
                                    }
                                } else {
                                    request$default(this, "ssap://com.webos.service.ime/deleteCharacters", new JSONObject().put("count", 1), 0L, 4);
                                    return;
                                }
                            } else {
                                request$default(this, "ssap://com.webos.service.ime/sendEnterKey", null, 0L, 6);
                                return;
                            }
                        } else {
                            request$default(this, "ssap://system.launcher/launch", Census$$ExternalSyntheticOutline0.m8m("id", "com.webos.app.livetv"), 0L, 4);
                            return;
                        }
                    } else {
                        JSONObject jSONObject = new JSONObject();
                        Triple triple = this.volume;
                        boolean z = false;
                        if (triple != null && ((Boolean) triple.third).booleanValue()) {
                            z = true;
                        }
                        request$default(this, "ssap://audio/setMute", jSONObject.put("mute", !z), 0L, 4);
                        return;
                    }
                } else {
                    this.playing = !this.playing;
                    if (this.playing) {
                        str = "PLAY";
                    } else {
                        str = "PAUSE";
                    }
                    button(str);
                    return;
                }
            }
            if (!Intrinsics.areEqual(this.isOn, Boolean.FALSE)) {
                try {
                    JSONObject put = new JSONObject().put("id", "f" + this.ids.incrementAndGet()).put("type", "request").put("uri", "ssap://system/turnOff");
                    Intrinsics.checkNotNullExpressionValue(put, "put(...)");
                    send(put);
                } catch (IOException unused) {
                }
            }
        }
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void text(String t) {
        Intrinsics.checkNotNullParameter(t, "t");
        this.out.execute(new Lg$$ExternalSyntheticLambda0(0, this, t));
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void type(String str, int i) {
        this.out.execute(new Lg$$ExternalSyntheticLambda5(i, this, str));
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void pointer(int i, int i2) {
        if (ready()) {
            this.out.execute(new Lg$$ExternalSyntheticLambda0(1, this, "type:move\ndx:" + i + "\ndy:" + i2 + "\ndown:" + this.pointerDown + "\n\n"));
        }
    }
}
