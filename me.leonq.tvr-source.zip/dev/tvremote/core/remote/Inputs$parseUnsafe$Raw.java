package dev.tvremote.core.remote;

import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class Inputs$parseUnsafe$Raw {
    public final Boolean connected;
    public final String id;
    public final String kind;
    public final int port;

    public Inputs$parseUnsafe$Raw(String str, String str2, int i, Boolean bool) {
        this.id = str;
        this.kind = str2;
        this.port = i;
        this.connected = bool;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Inputs$parseUnsafe$Raw)) {
            return false;
        }
        Inputs$parseUnsafe$Raw inputs$parseUnsafe$Raw = (Inputs$parseUnsafe$Raw) obj;
        return Intrinsics.areEqual(this.id, inputs$parseUnsafe$Raw.id) && Intrinsics.areEqual(this.kind, inputs$parseUnsafe$Raw.kind) && this.port == inputs$parseUnsafe$Raw.port && Intrinsics.areEqual(this.connected, inputs$parseUnsafe$Raw.connected);
    }

    public final int hashCode() {
        int hashCode = (((this.kind.hashCode() + (this.id.hashCode() * 31)) * 31) + this.port) * 31;
        Boolean bool = this.connected;
        return hashCode + (bool == null ? 0 : bool.hashCode());
    }

    public final String toString() {
        return "Raw(id=" + this.id + ", kind=" + this.kind + ", port=" + this.port + ", connected=" + this.connected + ")";
    }
}
