package dev.tvremote.core.remote;

import dev.tvremote.core.B64;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import java.util.regex.Pattern;
import kotlin.Triple;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Charsets;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.StringsKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class Samsung$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ int $r8$classId = 1;
    public final /* synthetic */ String f$0;
    public final /* synthetic */ Samsung f$1;

    public /* synthetic */ Samsung$$ExternalSyntheticLambda0(Samsung samsung, String str) {
        this.f$1 = samsung;
        this.f$0 = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        String str;
        Triple triple;
        boolean z = false;
        switch (this.$r8$classId) {
            case 0:
                String input = this.f$0;
                Samsung samsung = this.f$1;
                Pattern compile = Pattern.compile("^[a-zA-Z][a-zA-Z0-9+.-]*:");
                Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                Intrinsics.checkNotNullParameter(input, "input");
                boolean find = compile.matcher(input).find();
                MatcherMatchResult access$findNext = MathKt.access$findNext(Census$$ExternalSyntheticOutline0.m6m("(?:youtube\\.com/watch\\?v=|youtu\\.be/)([\\w-]{6,})", "compile(...)", input, "matcher(...)"), 0, input);
                if (access$findNext != null) {
                    str = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1);
                } else {
                    str = null;
                }
                String str2 = "DEEP_LINK";
                if (str != null) {
                    triple = new Triple("111299001912", "DEEP_LINK", str);
                } else if (find) {
                    triple = new Triple("org.tizen.browser", "NATIVE_LAUNCH", input);
                } else {
                    Boolean bool = (Boolean) samsung.deep.get(input);
                    if (bool != null) {
                        z = bool.booleanValue();
                    } else if (!StringsKt.contains$default(input, '.')) {
                        z = true;
                    }
                    if (!z) {
                        str2 = "NATIVE_LAUNCH";
                    }
                    triple = new Triple(input, str2, "");
                }
                String str3 = (String) triple.first;
                String str4 = (String) triple.second;
                JSONObject put = Census$$ExternalSyntheticOutline0.m8m("method", "ms.channel.emit").put("params", Census$$ExternalSyntheticOutline0.m10m("event", "ed.apps.launch", "to", "host").put("data", Census$$ExternalSyntheticOutline0.m10m("appId", str3, "action_type", str4).put("metaTag", (String) triple.third)));
                Intrinsics.checkNotNullExpressionValue(put, "put(...)");
                samsung.send$1(put);
                samsung.app = str3;
                return;
            default:
                Samsung samsung2 = this.f$1;
                String str5 = this.f$0;
                if (samsung2.keyboardNew) {
                    samsung2.keyboardNew = false;
                    JSONObject put2 = Census$$ExternalSyntheticOutline0.m8m("method", "ms.channel.emit").put("params", Census$$ExternalSyntheticOutline0.m10m("event", "custom.remote.textReceived", "to", "broadcast"));
                    Intrinsics.checkNotNullExpressionValue(put2, "put(...)");
                    samsung2.send$1(put2);
                }
                JSONObject m8m = Census$$ExternalSyntheticOutline0.m8m("method", "ms.remote.control");
                JSONObject jSONObject = new JSONObject();
                int[] iArr = B64.INDEX;
                byte[] bytes = str5.getBytes(Charsets.UTF_8);
                Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                JSONObject put3 = m8m.put("params", jSONObject.put("Cmd", B64.encode(bytes)).put("DataOfCmd", "base64").put("TypeOfRemote", "SendInputString"));
                Intrinsics.checkNotNullExpressionValue(put3, "put(...)");
                samsung2.send$1(put3);
                return;
        }
    }

    public /* synthetic */ Samsung$$ExternalSyntheticLambda0(String str, Samsung samsung) {
        this.f$0 = str;
        this.f$1 = samsung;
    }
}
