package dev.tvremote.core.remote;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.Mdns;
import dev.tvremote.core.ontv.Bloat$$ExternalSyntheticLambda1;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyList;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.sequences.GeneratorSequence$iterator$1;
import kotlin.sequences.SequencesKt;
import kotlin.text.LinesIterator;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.RegexOption;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public abstract class Inputs {
    public static final Regex LOGICAL;
    public static final Regex NAME;
    public static final Regex PHYS;
    public static final Regex PORT;
    public static final Regex SAFE_ID;
    public static final Object TYPES = MapsKt__MapsKt.mapOf(new Pair(2, "tuner"), new Pair(3, "av"), new Pair(6, "component"), new Pair(7, "vga"), new Pair(8, "other"), new Pair(9, "hdmi"), new Pair(10, "other"), new Pair(1001, "av"), new Pair(1004, "component"), new Pair(1005, "vga"), new Pair(1006, "other"), new Pair(1007, "hdmi"), new Pair(1008, "other"), new Pair(0, "tuner"));
    public static final Regex ID = new Regex("TvInputInfo\\{id=([^,}\\s]+)");
    public static final Regex HW = new Regex("(?:/|\\bHW)(?:HW)?(\\d+)$");
    public static final Regex HW_INFO = new Regex("TvInputHardwareInfo\\s*\\{([^}]*)\\}");
    public static final Regex INFO_TYPE = new Regex("\\btype=(\\d+)");
    public static final Regex INFO_ID = new Regex("\\bid=(\\d+)");
    public static final Regex INFO_PORT = new Regex("hdmi_port(?:_id)?=(\\d+)");
    public static final Regex INFO_CABLE = new Regex("cable_connection_status=(\\d+)");

    /* loaded from: classes.dex */
    public final class Box {
        public final String name;
        public final int physical;
        public final int port;

        public Box(String str, int i, int i2) {
            this.name = str;
            this.port = i;
            this.physical = i2;
        }
    }

    /* loaded from: classes.dex */
    public final class Cache {
        public long at;
        public final Function0 now;
        public final long ttlMs;
        public List value;

        /* renamed from: dev.tvremote.core.remote.Inputs$Cache$1, reason: invalid class name */
        /* loaded from: classes.dex */
        public final /* synthetic */ class AnonymousClass1 extends FunctionReferenceImpl implements Function0 {
            public static final AnonymousClass1 INSTANCE = new FunctionReferenceImpl(0, System.class, "currentTimeMillis", "currentTimeMillis()J");

            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return Long.valueOf(System.currentTimeMillis());
            }
        }

        public Cache() {
            AnonymousClass1 anonymousClass1 = AnonymousClass1.INSTANCE;
            this.ttlMs = 60000L;
            this.now = anonymousClass1;
        }

        public final synchronized List get(boolean z, Function0 function0) {
            List list = this.value;
            if (!z && list != null && ((Number) this.now.invoke()).longValue() - this.at < this.ttlMs) {
                return list;
            }
            Object invoke = function0.invoke();
            this.value = (List) invoke;
            this.at = ((Number) this.now.invoke()).longValue();
            return (List) invoke;
        }

        public final synchronized List peek() {
            return this.value;
        }
    }

    /* loaded from: classes.dex */
    public final class Hw {
        public final Boolean connected;
        public final String kind;
        public final int port;

        public Hw(String str, int i, Boolean bool) {
            this.kind = str;
            this.port = i;
            this.connected = bool;
        }
    }

    /* loaded from: classes.dex */
    public final class Input {
        public final Boolean connected;
        public final String device;
        public final String id;
        public final int key;
        public final String kind;
        public final String label;
        public final int port;

        public Input(String id, String str, int i, String str2, String label, Boolean bool, int i2) {
            Intrinsics.checkNotNullParameter(id, "id");
            Intrinsics.checkNotNullParameter(label, "label");
            this.id = id;
            this.kind = str;
            this.port = i;
            this.device = str2;
            this.label = label;
            this.connected = bool;
            this.key = i2;
        }

        public /* synthetic */ Input(String str, String str2, int i, String str3, String str4, Boolean bool, int i2, int i3) {
            this(str, str2, i, str3, str4, (i2 & 32) != 0 ? null : bool, 0);
        }
    }

    static {
        RegexOption regexOption = RegexOption.IGNORE_CASE;
        NAME = new Regex("display_?name[:=]\\s*(.*?)(?=\\s+(?:power_?status|physical_?address|port_?id|device_?type|vendor_?id|logical_?address|cec_?version|status|device_?power_?status|adopt)\\b|\\s*[,}]|\\s*$)", regexOption);
        PHYS = new Regex("physical_?address[:=]\\s*(?:0x)?([0-9a-fA-F]{4})", regexOption);
        PORT = new Regex("\\bport_?id[:=]\\s*(\\d+)", regexOption);
        LOGICAL = new Regex("logical_?address[:=]\\s*(?:0x)?([0-9a-fA-F]{1,2})", regexOption);
        SAFE_ID = new Regex("[A-Za-z0-9_.:/$-]{1,200}");
    }

    public static JSONObject json(List list) {
        Intrinsics.checkNotNullParameter(list, "list");
        JSONObject jSONObject = new JSONObject();
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(list));
        Iterator it = list.iterator();
        while (it.hasNext()) {
            Input input = (Input) it.next();
            input.getClass();
            JSONObject put = new JSONObject().put("id", input.id).put("kind", input.kind).put("port", input.port).put("device", input.device).put("label", input.label);
            Boolean bool = input.connected;
            if (bool != null) {
                put.put("connected", bool.booleanValue());
            }
            Intrinsics.checkNotNullExpressionValue(put, "apply(...)");
            arrayList.add(put);
        }
        JSONObject put2 = jSONObject.put("inputs", new JSONArray((Collection) arrayList));
        Intrinsics.checkNotNullExpressionValue(put2, "put(...)");
        return put2;
    }

    /* JADX WARN: Removed duplicated region for block: B:196:0x03a1  */
    /* JADX WARN: Removed duplicated region for block: B:200:0x03a4  */
    /* JADX WARN: Removed duplicated region for block: B:313:0x0536  */
    /* JADX WARN: Removed duplicated region for block: B:323:0x05eb  */
    /* JADX WARN: Removed duplicated region for block: B:327:0x05f9  */
    /* JADX WARN: Removed duplicated region for block: B:332:0x0610  */
    /* JADX WARN: Removed duplicated region for block: B:335:0x0617  */
    /* JADX WARN: Removed duplicated region for block: B:364:0x065a  */
    /* JADX WARN: Removed duplicated region for block: B:371:0x0603  */
    /* JADX WARN: Removed duplicated region for block: B:372:0x05fc  */
    /* JADX WARN: Removed duplicated region for block: B:373:0x05f0  */
    /* JADX WARN: Removed duplicated region for block: B:401:0x059d  */
    /* JADX WARN: Type inference failed for: r14v26, types: [java.util.Map, java.lang.Object] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static List parseUnsafe(String str) {
        String substring;
        String substring2;
        Regex regex;
        int i;
        ArrayList arrayList;
        LinkedHashSet linkedHashSet;
        Iterator it;
        ArrayList arrayList2;
        String str2;
        int hashCode;
        int i2;
        String str3;
        int i3;
        boolean z;
        int hashCode2;
        int i4;
        int i5;
        int i6;
        Object obj;
        int i7;
        Integer num;
        Hw hw;
        Integer num2;
        int i8;
        String str4;
        Boolean bool;
        String str5;
        String str6;
        String obj2;
        Integer num3;
        int i9;
        int i10;
        String str7;
        Integer intOrNull;
        String str8;
        Integer intOrNull2;
        String str9;
        String str10;
        Integer intOrNull3;
        String str11;
        Integer intOrNull4;
        int i11;
        Integer num4;
        Boolean bool2;
        String str12;
        String str13;
        Integer intOrNull5;
        int i12 = 2;
        int i13 = 1;
        int i14 = 0;
        int indexOf$default = StringsKt.indexOf$default(str, "#--tvr-inputs--", 0, false, 6);
        if (indexOf$default < 0) {
            substring = str;
        } else {
            substring = str.substring(0, indexOf$default);
            Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
        }
        if (indexOf$default < 0) {
            substring2 = "";
        } else {
            substring2 = str.substring(indexOf$default + 15);
            Intrinsics.checkNotNullExpressionValue(substring2, "substring(...)");
        }
        HashMap hashMap = new HashMap();
        GeneratorSequence$iterator$1 generatorSequence$iterator$1 = new GeneratorSequence$iterator$1(Regex.findAll$default(HW_INFO, substring));
        while (true) {
            String str14 = "other";
            if (!generatorSequence$iterator$1.hasNext()) {
                break;
            }
            String str15 = (String) ((MatcherMatchResult$groupValues$1) ((MatcherMatchResult) generatorSequence$iterator$1.next()).getGroupValues()).get(1);
            MatcherMatchResult find = INFO_ID.find(str15, 0);
            if (find != null && (str10 = (String) ((MatcherMatchResult$groupValues$1) find.getGroupValues()).get(1)) != null && (intOrNull3 = StringsKt__StringNumberConversionsKt.toIntOrNull(str10)) != null) {
                ?? r14 = TYPES;
                MatcherMatchResult find2 = INFO_TYPE.find(str15, 0);
                if (find2 != null && (str11 = (String) ((MatcherMatchResult$groupValues$1) find2.getGroupValues()).get(1)) != null && (intOrNull4 = StringsKt__StringNumberConversionsKt.toIntOrNull(str11)) != null) {
                    String str16 = (String) r14.get(intOrNull4);
                    if (str16 != null) {
                        str14 = str16;
                    }
                    MatcherMatchResult find3 = INFO_PORT.find(str15, 0);
                    if (find3 != null && (str13 = (String) ((MatcherMatchResult$groupValues$1) find3.getGroupValues()).get(1)) != null && (intOrNull5 = StringsKt__StringNumberConversionsKt.toIntOrNull(str13)) != null) {
                        i11 = intOrNull5.intValue();
                    } else {
                        i11 = 0;
                    }
                    MatcherMatchResult find4 = INFO_CABLE.find(str15, 0);
                    if (find4 != null && (str12 = (String) ((MatcherMatchResult$groupValues$1) find4.getGroupValues()).get(1)) != null) {
                        num4 = StringsKt__StringNumberConversionsKt.toIntOrNull(str12);
                    } else {
                        num4 = null;
                    }
                    if (num4 != null && num4.intValue() == 1) {
                        bool2 = Boolean.TRUE;
                    } else if (num4 != null && num4.intValue() == 2) {
                        bool2 = Boolean.FALSE;
                    } else {
                        bool2 = null;
                    }
                    hashMap.put(intOrNull3, new Hw(str14, i11, bool2));
                }
            }
        }
        ArrayList arrayList3 = new ArrayList();
        HashSet hashSet = new HashSet();
        Iterator it2 = StringsKt.lineSequence(substring2).iterator();
        while (true) {
            LinesIterator linesIterator = (LinesIterator) it2;
            if (!linesIterator.hasNext()) {
                break;
            }
            String str17 = (String) linesIterator.next();
            if (StringsKt.contains(str17, "display_name", true) || StringsKt.contains(str17, "displayname", true)) {
                MatcherMatchResult find5 = NAME.find(str17, 0);
                if (find5 != null && (str6 = (String) ((MatcherMatchResult$groupValues$1) find5.getGroupValues()).get(1)) != null && (obj2 = StringsKt.trim(str6).toString()) != null) {
                    char[] cArr = new char[i12];
                    // fill-array-data instruction
                    cArr[0] = '\"';
                    cArr[1] = '\'';
                    String trim = StringsKt.trim(obj2, cArr);
                    if (trim != null) {
                        if (trim.length() != 0 && !trim.equalsIgnoreCase("null")) {
                            MatcherMatchResult find6 = LOGICAL.find(str17, 0);
                            if (find6 != null && (str9 = (String) ((MatcherMatchResult$groupValues$1) find6.getGroupValues()).get(1)) != null) {
                                num3 = StringsKt__StringNumberConversionsKt.toIntOrNull(str9, 16);
                            } else {
                                num3 = null;
                            }
                            if (num3 == null || num3.intValue() != 0) {
                                if (num3 == null || num3.intValue() != 15) {
                                    MatcherMatchResult find7 = PHYS.find(str17, 0);
                                    if (find7 != null && (str8 = (String) ((MatcherMatchResult$groupValues$1) find7.getGroupValues()).get(1)) != null && (intOrNull2 = StringsKt__StringNumberConversionsKt.toIntOrNull(str8, 16)) != null) {
                                        i9 = intOrNull2.intValue();
                                    } else {
                                        i9 = 0;
                                    }
                                    MatcherMatchResult find8 = PORT.find(str17, 0);
                                    if (find8 != null && (str7 = (String) ((MatcherMatchResult$groupValues$1) find8.getGroupValues()).get(1)) != null && (intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull(str7)) != null) {
                                        i10 = intOrNull.intValue();
                                    } else {
                                        i10 = 0;
                                    }
                                    if (i10 != 0 || i9 != 0) {
                                        if (hashSet.add(trim + "/" + i9 + "/" + i10)) {
                                            arrayList3.add(new Box(trim, i10, i9));
                                        }
                                        i12 = 2;
                                    }
                                }
                            }
                        }
                    }
                }
                i12 = 2;
            }
        }
        LinkedHashSet linkedHashSet2 = new LinkedHashSet();
        GeneratorSequence$iterator$1 generatorSequence$iterator$12 = new GeneratorSequence$iterator$1(Regex.findAll$default(ID, substring));
        while (generatorSequence$iterator$12.hasNext()) {
            linkedHashSet2.add(((MatcherMatchResult$groupValues$1) ((MatcherMatchResult) generatorSequence$iterator$12.next()).getGroupValues()).get(1));
        }
        Iterator it3 = StringsKt.lineSequence(substring).iterator();
        while (true) {
            LinesIterator linesIterator2 = (LinesIterator) it3;
            boolean hasNext = linesIterator2.hasNext();
            regex = HW;
            if (!hasNext) {
                break;
            }
            String obj3 = StringsKt.trim((String) linesIterator2.next()).toString();
            String obj4 = StringsKt.trim(StringsKt.substringBefore(obj3, ':', obj3)).toString();
            if (StringsKt.contains$default(obj4, '/') && !StringsKt.contains$default(obj4, ' ') && regex.containsMatchIn(obj4)) {
                linkedHashSet2.add(obj4);
            }
        }
        ArrayList arrayList4 = new ArrayList();
        Iterator it4 = linkedHashSet2.iterator();
        Intrinsics.checkNotNullExpressionValue(it4, "iterator(...)");
        boolean z2 = false;
        while (true) {
            String str18 = "vga";
            if (!it4.hasNext()) {
                break;
            }
            Object next = it4.next();
            Intrinsics.checkNotNullExpressionValue(next, "next(...)");
            String str19 = (String) next;
            MatcherMatchResult find9 = regex.find(str19, i14);
            if (find9 != null && (str5 = (String) ((MatcherMatchResult$groupValues$1) find9.getGroupValues()).get(i13)) != null) {
                num = StringsKt__StringNumberConversionsKt.toIntOrNull(str5);
            } else {
                num = null;
            }
            if (num != null) {
                hw = (Hw) hashMap.get(num);
            } else {
                hw = null;
            }
            String lowerCase = str19.toLowerCase(Locale.ROOT);
            Iterator it5 = it4;
            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
            if (hw != null) {
                str18 = hw.kind;
            } else if (StringsKt.contains(lowerCase, "hdmi", false)) {
                str18 = "hdmi";
            } else if (StringsKt.contains(lowerCase, "composite", false) || StringsKt__StringsJVMKt.endsWith(lowerCase, false, "av") || StringsKt.contains(lowerCase, "/av", false)) {
                str18 = "av";
            } else if (StringsKt.contains(lowerCase, "component", false)) {
                str18 = "component";
            } else if (!StringsKt.contains(lowerCase, "vga", false)) {
                if (num != null) {
                    str18 = "other";
                } else {
                    str18 = null;
                }
            }
            if (str18 == null) {
                if (StringsKt.contains(lowerCase, "tuner", false) || StringsKt.contains(lowerCase, "dtv", false) || StringsKt.contains(lowerCase, "atsc", false) || StringsKt.contains(lowerCase, "dvb", false)) {
                    z2 = true;
                }
            } else if (str18.equals("tuner")) {
                it4 = it5;
                i13 = 1;
                i14 = 0;
                z2 = true;
            } else {
                if (hw != null) {
                    int i15 = hw.port;
                    Integer valueOf = Integer.valueOf(i15);
                    if (i15 <= 0) {
                        valueOf = null;
                    }
                    if (valueOf != null) {
                        i8 = valueOf.intValue();
                        if (hw == null) {
                            bool = hw.connected;
                        } else {
                            bool = null;
                        }
                        arrayList4.add(new Inputs$parseUnsafe$Raw(str19, str18, i8, bool));
                    }
                }
                MatcherMatchResult access$findNext = MathKt.access$findNext(Census$$ExternalSyntheticOutline0.m6m("hdmi_?(\\d)", "compile(...)", lowerCase, "matcher(...)"), 0, lowerCase);
                if (access$findNext != null && (str4 = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)) != null) {
                    num2 = StringsKt__StringNumberConversionsKt.toIntOrNull(str4);
                } else {
                    num2 = null;
                }
                if (num2 != null) {
                    i8 = num2.intValue();
                } else {
                    i8 = 0;
                }
                if (hw == null) {
                }
                arrayList4.add(new Inputs$parseUnsafe$Raw(str19, str18, i8, bool));
            }
            it4 = it5;
            i13 = 1;
            i14 = 0;
        }
        if (arrayList4.isEmpty()) {
            return EmptyList.INSTANCE;
        }
        HashMap hashMap2 = new HashMap();
        ArrayList arrayList5 = new ArrayList();
        Iterator it6 = arrayList4.iterator();
        while (it6.hasNext()) {
            Object next2 = it6.next();
            Inputs$parseUnsafe$Raw inputs$parseUnsafe$Raw = (Inputs$parseUnsafe$Raw) next2;
            if (inputs$parseUnsafe$Raw.kind.equals("hdmi") && inputs$parseUnsafe$Raw.port > 0) {
                arrayList5.add(next2);
            }
        }
        ArrayList arrayList6 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList5));
        Iterator it7 = arrayList5.iterator();
        while (it7.hasNext()) {
            arrayList6.add(Integer.valueOf(((Inputs$parseUnsafe$Raw) it7.next()).port));
        }
        LinkedHashSet linkedHashSet3 = new LinkedHashSet(arrayList6);
        ArrayList arrayList7 = new ArrayList();
        Iterator it8 = CollectionsKt.sortedWith(arrayList4, MathKt.compareBy(new Bloat$$ExternalSyntheticLambda1(23), new Bloat$$ExternalSyntheticLambda1(24), new Bloat$$ExternalSyntheticLambda1(25))).iterator();
        while (it8.hasNext()) {
            Inputs$parseUnsafe$Raw inputs$parseUnsafe$Raw2 = (Inputs$parseUnsafe$Raw) it8.next();
            Integer num5 = (Integer) hashMap2.get(inputs$parseUnsafe$Raw2.kind);
            if (num5 != null) {
                i = num5.intValue();
            } else {
                i = 0;
            }
            int i16 = i + 1;
            Integer valueOf2 = Integer.valueOf(i16);
            String str20 = inputs$parseUnsafe$Raw2.kind;
            hashMap2.put(str20, valueOf2);
            boolean equals = str20.equals("hdmi");
            HashMap hashMap3 = hashMap2;
            int i17 = inputs$parseUnsafe$Raw2.port;
            if (equals && i17 == 0) {
                arrayList = arrayList4;
                for (Number number : SequencesKt.generateSequence(Integer.valueOf(i16), new Bloat$$ExternalSyntheticLambda1(26))) {
                    if (!linkedHashSet3.contains(Integer.valueOf(number.intValue()))) {
                        i17 = number.intValue();
                        linkedHashSet3.add(Integer.valueOf(i17));
                    }
                }
                throw new NoSuchElementException("Sequence contains no element matching the predicate.");
            }
            arrayList = arrayList4;
            if (str20.equals("hdmi")) {
                ArrayList arrayList8 = new ArrayList();
                Iterator it9 = arrayList3.iterator();
                while (it9.hasNext()) {
                    LinkedHashSet linkedHashSet4 = linkedHashSet3;
                    Object next3 = it9.next();
                    Iterator it10 = it8;
                    Box box = (Box) next3;
                    ArrayList arrayList9 = arrayList3;
                    if (box.port == i17 || ((i7 = box.physical) > 0 && (i7 >> 12) == i17)) {
                        arrayList8.add(next3);
                    }
                    linkedHashSet3 = linkedHashSet4;
                    it8 = it10;
                    arrayList3 = arrayList9;
                }
                linkedHashSet = linkedHashSet3;
                it = it8;
                arrayList2 = arrayList3;
                Iterator it11 = arrayList8.iterator();
                while (true) {
                    if (it11.hasNext()) {
                        obj = it11.next();
                        if ((((Box) obj).physical & 4095) == 0) {
                            break;
                        }
                    } else {
                        obj = null;
                        break;
                    }
                }
                Box box2 = (Box) obj;
                if (box2 == null) {
                    box2 = (Box) CollectionsKt.firstOrNull(arrayList8);
                }
                if (box2 != null) {
                    str2 = box2.name;
                    hashCode = str20.hashCode();
                    if (hashCode == -1399907075) {
                        if (hashCode != 3125) {
                            if (hashCode != 116688) {
                                if (hashCode == 3197848 && str20.equals("hdmi")) {
                                    str3 = ApkSigner$$ExternalSyntheticOutline0.m("HDMI ", i17);
                                }
                                str3 = ApkSigner$$ExternalSyntheticOutline0.m("Input ", i16);
                            } else {
                                if (str20.equals("vga")) {
                                    str3 = "VGA";
                                }
                                str3 = ApkSigner$$ExternalSyntheticOutline0.m("Input ", i16);
                            }
                        } else {
                            if (str20.equals("av")) {
                                if (arrayList.isEmpty()) {
                                    i6 = 0;
                                } else {
                                    Iterator it12 = arrayList.iterator();
                                    i6 = 0;
                                    while (it12.hasNext()) {
                                        if (((Inputs$parseUnsafe$Raw) it12.next()).kind.equals("av") && (i6 = i6 + 1) < 0) {
                                            CollectionsKt__CollectionsKt.throwCountOverflow();
                                            throw null;
                                        }
                                    }
                                }
                                if (i6 > 1) {
                                    str3 = ApkSigner$$ExternalSyntheticOutline0.m("AV ", i16);
                                } else {
                                    str3 = "AV";
                                }
                            }
                            str3 = ApkSigner$$ExternalSyntheticOutline0.m("Input ", i16);
                        }
                    } else {
                        if (str20.equals("component")) {
                            if (arrayList.isEmpty()) {
                                i2 = 0;
                            } else {
                                Iterator it13 = arrayList.iterator();
                                i2 = 0;
                                while (it13.hasNext()) {
                                    if (((Inputs$parseUnsafe$Raw) it13.next()).kind.equals("component") && (i2 = i2 + 1) < 0) {
                                        CollectionsKt__CollectionsKt.throwCountOverflow();
                                        throw null;
                                    }
                                }
                            }
                            if (i2 > 1) {
                                str3 = ApkSigner$$ExternalSyntheticOutline0.m("Component ", i16);
                            } else {
                                str3 = "Component";
                            }
                        }
                        str3 = ApkSigner$$ExternalSyntheticOutline0.m("Input ", i16);
                    }
                    if (!str20.equals("hdmi")) {
                        i3 = i17;
                    } else {
                        i3 = 0;
                    }
                    if (str2.length() != 0) {
                        z = true;
                    } else {
                        z = false;
                    }
                    if (!z) {
                        str3 = Census$$ExternalSyntheticOutline0.m(str3, " · ", str2);
                    }
                    String str21 = str3;
                    if (str20.equals("hdmi")) {
                        i16 = i17;
                    }
                    hashCode2 = str20.hashCode();
                    if (hashCode2 == -1399907075) {
                        if (hashCode2 != 3125) {
                            if (hashCode2 != 116688) {
                                if (hashCode2 == 3197848 && str20.equals("hdmi") && 1 <= i16 && i16 < 5) {
                                    i5 = i16 + 242;
                                    i4 = i5;
                                }
                            } else if (str20.equals("vga")) {
                                i4 = 251;
                            }
                        } else if (str20.equals("av") && 1 <= i16 && i16 < 3) {
                            i5 = i16 + 246;
                            i4 = i5;
                        }
                        arrayList7.add(new Input(inputs$parseUnsafe$Raw2.id, str20, i3, str2, str21, inputs$parseUnsafe$Raw2.connected, i4));
                        hashMap2 = hashMap3;
                        arrayList4 = arrayList;
                        linkedHashSet3 = linkedHashSet;
                        it8 = it;
                        arrayList3 = arrayList2;
                    } else if (str20.equals("component")) {
                        if (1 <= i16 && i16 < 3) {
                            i4 = i16 + 248;
                            arrayList7.add(new Input(inputs$parseUnsafe$Raw2.id, str20, i3, str2, str21, inputs$parseUnsafe$Raw2.connected, i4));
                            hashMap2 = hashMap3;
                            arrayList4 = arrayList;
                            linkedHashSet3 = linkedHashSet;
                            it8 = it;
                            arrayList3 = arrayList2;
                        }
                    }
                    i4 = 0;
                    arrayList7.add(new Input(inputs$parseUnsafe$Raw2.id, str20, i3, str2, str21, inputs$parseUnsafe$Raw2.connected, i4));
                    hashMap2 = hashMap3;
                    arrayList4 = arrayList;
                    linkedHashSet3 = linkedHashSet;
                    it8 = it;
                    arrayList3 = arrayList2;
                }
            } else {
                linkedHashSet = linkedHashSet3;
                it = it8;
                arrayList2 = arrayList3;
            }
            str2 = "";
            hashCode = str20.hashCode();
            if (hashCode == -1399907075) {
            }
            if (!str20.equals("hdmi")) {
            }
            if (str2.length() != 0) {
            }
            if (!z) {
            }
            String str212 = str3;
            if (str20.equals("hdmi")) {
            }
            hashCode2 = str20.hashCode();
            if (hashCode2 == -1399907075) {
            }
            i4 = 0;
            arrayList7.add(new Input(inputs$parseUnsafe$Raw2.id, str20, i3, str2, str212, inputs$parseUnsafe$Raw2.connected, i4));
            hashMap2 = hashMap3;
            arrayList4 = arrayList;
            linkedHashSet3 = linkedHashSet;
            it8 = it;
            arrayList3 = arrayList2;
        }
        if (z2) {
            arrayList7.add(new Input("tuner", "tuner", 0, "", "TV", null, 170));
        }
        return arrayList7;
    }

    /* renamed from: switch, reason: not valid java name */
    public static String m14switch(Function1 function1, String id, List list) {
        Object obj;
        Intrinsics.checkNotNullParameter(id, "id");
        if (SAFE_ID.matches(id)) {
            if (id.equals("tuner")) {
                function1.invoke("input keyevent 170");
                return "key";
            }
            ConcurrentHashMap concurrentHashMap = Adb.ASKING;
            String out = (String) function1.invoke("am start -a android.intent.action.VIEW -d " + Mdns.q("content://android.media.tv/passthrough/".concat(StringsKt__StringsJVMKt.replace$default(StringsKt__StringsJVMKt.replace$default(StringsKt__StringsJVMKt.replace$default(id, "%", "%25"), "/", "%2F"), "$", "%24"))) + " 2>&1");
            Intrinsics.checkNotNullParameter(out, "out");
            String lowerCase = out.toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
            int i = 0;
            if (!StringsKt.contains(lowerCase, "error", false) && !StringsKt.contains(lowerCase, "exception", false) && !StringsKt.contains(lowerCase, "unable to resolve", false) && !StringsKt.contains(lowerCase, "no activity found", false)) {
                return "intent";
            }
            if (list == null) {
                String out2 = (String) function1.invoke("dumpsys tv_input 2>/dev/null; echo '#--tvr-inputs--'; dumpsys hdmi_control 2>/dev/null");
                Intrinsics.checkNotNullParameter(out2, "out");
                try {
                    list = parseUnsafe(out2);
                } catch (Exception unused) {
                    list = EmptyList.INSTANCE;
                }
            }
            Iterator it = list.iterator();
            while (true) {
                if (it.hasNext()) {
                    obj = it.next();
                    if (Intrinsics.areEqual(((Input) obj).id, id)) {
                        break;
                    }
                } else {
                    obj = null;
                    break;
                }
            }
            Input input = (Input) obj;
            if (input != null) {
                i = input.key;
            }
            if (i != 0) {
                function1.invoke("input keyevent " + i);
                return "key";
            }
            throw new IllegalArgumentException("this TV did not take the switch");
        }
        throw new IllegalArgumentException("bad input");
    }
}
