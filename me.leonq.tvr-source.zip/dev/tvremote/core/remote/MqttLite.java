package dev.tvremote.core.remote;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$post$1;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;
import kotlin.text.Regex$$ExternalSyntheticLambda0;

/* loaded from: classes.dex */
public final class MqttLite implements Closeable {
    public volatile boolean closed;
    public final DataInputStream input;
    public volatile long lastSent;
    public volatile boolean lost;
    public final Regex$$ExternalSyntheticLambda0 onClosed;
    public final Census$post$1 onMessage;
    public final OutputStream output;
    public int packetId;
    public final Socket socket;

    /* loaded from: classes.dex */
    public final class Rejected extends IOException {
        public final int code;

        public Rejected(int i) {
            super(ApkSigner$$ExternalSyntheticOutline0.m("mqtt connection refused (code ", i, ")"));
            this.code = i;
        }
    }

    public MqttLite(Socket socket, Census$post$1 census$post$1, Regex$$ExternalSyntheticLambda0 regex$$ExternalSyntheticLambda0) {
        BufferedInputStream bufferedInputStream;
        this.socket = socket;
        this.onMessage = census$post$1;
        this.onClosed = regex$$ExternalSyntheticLambda0;
        InputStream inputStream = socket.getInputStream();
        Intrinsics.checkNotNullExpressionValue(inputStream, "getInputStream(...)");
        if (inputStream instanceof BufferedInputStream) {
            bufferedInputStream = (BufferedInputStream) inputStream;
        } else {
            bufferedInputStream = new BufferedInputStream(inputStream, 8192);
        }
        this.input = new DataInputStream(bufferedInputStream);
        OutputStream outputStream = socket.getOutputStream();
        Intrinsics.checkNotNullExpressionValue(outputStream, "getOutputStream(...)");
        this.output = outputStream;
        this.packetId = 1;
    }

    public static void connect$default(MqttLite mqttLite, String clientId, String user, String pass) {
        Intrinsics.checkNotNullParameter(clientId, "clientId");
        Intrinsics.checkNotNullParameter(user, "user");
        Intrinsics.checkNotNullParameter(pass, "pass");
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byteArrayOutputStream.write(str("MQTT"));
        byteArrayOutputStream.write(4);
        byteArrayOutputStream.write(194);
        byteArrayOutputStream.write(0);
        byteArrayOutputStream.write(30);
        byteArrayOutputStream.write(str(clientId));
        byteArrayOutputStream.write(str(user));
        byteArrayOutputStream.write(str(pass));
        Socket socket = mqttLite.socket;
        socket.setSoTimeout(8000);
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        Intrinsics.checkNotNullExpressionValue(byteArray, "toByteArray(...)");
        mqttLite.send(16, byteArray);
        Pair read = mqttLite.read();
        if (read != null) {
            int intValue = ((Number) read.first).intValue();
            byte[] bArr = (byte[]) read.second;
            if ((intValue >> 4) == 2 && bArr.length >= 2) {
                if (bArr[1] == 0) {
                    socket.setSoTimeout(0);
                    final int i = 0;
                    Thread thread = new Thread(new Runnable(mqttLite) { // from class: dev.tvremote.core.remote.MqttLite$$ExternalSyntheticLambda0
                        public final /* synthetic */ MqttLite f$0;

                        {
                            this.f$0 = mqttLite;
                        }

                        @Override // java.lang.Runnable
                        public final void run() {
                            Pair read2;
                            boolean z = false;
                            switch (i) {
                                case 0:
                                    MqttLite mqttLite2 = this.f$0;
                                    while (!mqttLite2.closed && (read2 = mqttLite2.read()) != null) {
                                        try {
                                            int intValue2 = ((Number) read2.first).intValue();
                                            byte[] bArr2 = (byte[]) read2.second;
                                            if ((intValue2 >> 4) == 3) {
                                                int i2 = ((bArr2[0] & 255) << 8) | (bArr2[1] & 255);
                                                String str = new String(bArr2, 2, i2, Charsets.UTF_8);
                                                int i3 = i2 + 2;
                                                if (((intValue2 >> 1) & 3) > 0) {
                                                    mqttLite2.send(64, new byte[]{bArr2[i3], bArr2[i2 + 3]});
                                                    i3 = i2 + 4;
                                                }
                                                try {
                                                    mqttLite2.onMessage.invoke(str, ArraysKt.copyOfRange(bArr2, i3, bArr2.length));
                                                } catch (Exception unused) {
                                                }
                                            }
                                        } catch (Exception unused2) {
                                        }
                                    }
                                    if (!mqttLite2.closed || mqttLite2.lost) {
                                        z = true;
                                    }
                                    mqttLite2.close();
                                    if (z) {
                                        mqttLite2.onClosed.invoke();
                                        return;
                                    }
                                    return;
                                default:
                                    MqttLite mqttLite3 = this.f$0;
                                    while (!mqttLite3.closed) {
                                        long j = 30 * 500;
                                        try {
                                            Thread.sleep(j);
                                            if (!mqttLite3.closed && System.currentTimeMillis() - mqttLite3.lastSent > j) {
                                                try {
                                                    mqttLite3.send(192, new byte[0]);
                                                } catch (IOException unused3) {
                                                    mqttLite3.lost = true;
                                                    mqttLite3.close();
                                                }
                                            }
                                        } catch (InterruptedException unused4) {
                                            return;
                                        }
                                    }
                                    return;
                            }
                        }
                    }, "mqtt-read");
                    thread.setDaemon(true);
                    thread.start();
                    final int i2 = 1;
                    Thread thread2 = new Thread(new Runnable(mqttLite) { // from class: dev.tvremote.core.remote.MqttLite$$ExternalSyntheticLambda0
                        public final /* synthetic */ MqttLite f$0;

                        {
                            this.f$0 = mqttLite;
                        }

                        @Override // java.lang.Runnable
                        public final void run() {
                            Pair read2;
                            boolean z = false;
                            switch (i2) {
                                case 0:
                                    MqttLite mqttLite2 = this.f$0;
                                    while (!mqttLite2.closed && (read2 = mqttLite2.read()) != null) {
                                        try {
                                            int intValue2 = ((Number) read2.first).intValue();
                                            byte[] bArr2 = (byte[]) read2.second;
                                            if ((intValue2 >> 4) == 3) {
                                                int i22 = ((bArr2[0] & 255) << 8) | (bArr2[1] & 255);
                                                String str = new String(bArr2, 2, i22, Charsets.UTF_8);
                                                int i3 = i22 + 2;
                                                if (((intValue2 >> 1) & 3) > 0) {
                                                    mqttLite2.send(64, new byte[]{bArr2[i3], bArr2[i22 + 3]});
                                                    i3 = i22 + 4;
                                                }
                                                try {
                                                    mqttLite2.onMessage.invoke(str, ArraysKt.copyOfRange(bArr2, i3, bArr2.length));
                                                } catch (Exception unused) {
                                                }
                                            }
                                        } catch (Exception unused2) {
                                        }
                                    }
                                    if (!mqttLite2.closed || mqttLite2.lost) {
                                        z = true;
                                    }
                                    mqttLite2.close();
                                    if (z) {
                                        mqttLite2.onClosed.invoke();
                                        return;
                                    }
                                    return;
                                default:
                                    MqttLite mqttLite3 = this.f$0;
                                    while (!mqttLite3.closed) {
                                        long j = 30 * 500;
                                        try {
                                            Thread.sleep(j);
                                            if (!mqttLite3.closed && System.currentTimeMillis() - mqttLite3.lastSent > j) {
                                                try {
                                                    mqttLite3.send(192, new byte[0]);
                                                } catch (IOException unused3) {
                                                    mqttLite3.lost = true;
                                                    mqttLite3.close();
                                                }
                                            }
                                        } catch (InterruptedException unused4) {
                                            return;
                                        }
                                    }
                                    return;
                            }
                        }
                    }, "mqtt-ping");
                    thread2.setDaemon(true);
                    thread2.start();
                    return;
                }
                throw new Rejected(bArr[1]);
            }
            throw new IOException("mqtt: no CONNACK");
        }
        throw new IOException("the TV closed the connection");
    }

    public static byte[] str(String str) {
        byte[] bytes = str.getBytes(Charsets.UTF_8);
        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        return ArraysKt.plus(new byte[]{(byte) (bytes.length >> 8), (byte) (bytes.length & 255)}, bytes);
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        if (!this.closed) {
            this.closed = true;
            try {
                synchronized (this.output) {
                    this.output.write(new byte[]{-32, 0});
                    this.output.flush();
                }
            } catch (Exception unused) {
            }
            try {
                this.socket.close();
            } catch (Exception unused2) {
            }
        }
    }

    public final void publish(String topic, String payload) {
        Intrinsics.checkNotNullParameter(topic, "topic");
        Intrinsics.checkNotNullParameter(payload, "payload");
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byteArrayOutputStream.write(str(topic));
        byte[] bytes = payload.getBytes(Charsets.UTF_8);
        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        byteArrayOutputStream.write(bytes);
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        Intrinsics.checkNotNullExpressionValue(byteArray, "toByteArray(...)");
        send(48, byteArray);
    }

    public final Pair read() {
        DataInputStream dataInputStream = this.input;
        int read = dataInputStream.read();
        if (read < 0) {
            return null;
        }
        int i = 0;
        int i2 = 1;
        do {
            int readUnsignedByte = dataInputStream.readUnsignedByte();
            i += (readUnsignedByte & 127) * i2;
            if ((readUnsignedByte & 128) != 0) {
                i2 *= 128;
            } else {
                if (i <= 4194304) {
                    byte[] bArr = new byte[i];
                    dataInputStream.readFully(bArr);
                    return new Pair(Integer.valueOf(read), bArr);
                }
                throw new IOException("mqtt: packet too big");
            }
        } while (i2 <= 2097152);
        throw new IOException("mqtt: bad length");
    }

    public final void send(int i, byte[] bArr) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byteArrayOutputStream.write(i);
        int length = bArr.length;
        do {
            int i2 = length % 128;
            length /= 128;
            if (length > 0) {
                i2 |= 128;
            }
            byteArrayOutputStream.write(i2);
        } while (length > 0);
        byteArrayOutputStream.write(bArr);
        synchronized (this.output) {
            this.output.write(byteArrayOutputStream.toByteArray());
            this.output.flush();
        }
        this.lastSent = System.currentTimeMillis();
    }

    public final void subscribe(String... topics) {
        int i;
        int i2;
        Intrinsics.checkNotNullParameter(topics, "topics");
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        synchronized (this) {
            i = this.packetId;
            this.packetId = i + 1;
            i2 = 65535 & i;
        }
        byteArrayOutputStream.write(i2 >> 8);
        byteArrayOutputStream.write(i & 255);
        for (String str : topics) {
            byteArrayOutputStream.write(str(str));
            byteArrayOutputStream.write(0);
        }
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        Intrinsics.checkNotNullExpressionValue(byteArray, "toByteArray(...)");
        send(130, byteArray);
    }
}
