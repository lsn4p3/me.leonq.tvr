package dev.tvremote.core.remote;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.B64;
import dev.tvremote.core.Census$$ExternalSyntheticLambda4;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$post$1;
import dev.tvremote.core.Diagnose$$ExternalSyntheticLambda1;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Lan;
import dev.tvremote.core.Lan$$ExternalSyntheticLambda0;
import dev.tvremote.core.WireLog;
import dev.tvremote.core.ontv.Bloat$$ExternalSyntheticLambda1;
import dev.tvremote.core.ontv.Setup$plan$$inlined$sortedBy$1;
import dev.tvremote.core.remote.Atv;
import dev.tvremote.core.remote.Inputs;
import dev.tvremote.core.remote.MqttLite;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda4;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda5;
import dev.tvremote.home.HomeQr$$ExternalSyntheticLambda0;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.Socket;
import java.net.URL;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.X509TrustManager;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyList;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.collections.SetsKt;
import kotlin.collections.builders.ListBuilder;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgression;
import kotlin.ranges.IntProgressionIterator;
import kotlin.ranges.IntRange;
import kotlin.text.Charsets;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.Regex$$ExternalSyntheticLambda0;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class Vidaa implements Remote, CodePairing {
    public static final Set IFACES;
    public static final LinkedHashMap KEYS;
    public static final Regex MAC;
    public static final ArrayList MINE;
    public static final List NAME_FIELDS;
    public static final List P12_PASSWORDS;
    public static final List PUBLIC;
    public static volatile String RAW;
    public static final Regex RAW_MAC;
    public static final Atv$dial$anyTv$1 TRUST_ALL;
    public volatile String app;
    public volatile Object apps;
    public final String cid;
    public volatile boolean closed;
    public final File dir;
    public final String host;
    public volatile Boolean isOn;
    public volatile boolean live;
    public volatile String mac;
    public volatile List macs;
    public final String me;
    public volatile String model;
    public volatile MqttLite mqtt;
    public final ExecutorService out;
    public volatile boolean pairStatic;
    public volatile String pairUser;
    public volatile MqttLite pairing;
    public volatile Object sources;
    public final File tokenFile;
    public volatile String vendor;
    public volatile String version;
    public volatile Triple volume;
    public final CopyOnWriteArrayList waits;
    public final Function2 wol;
    public static final Companion Companion = new Object();
    public static final List APPS = ArraysKt.asList(new String[]{"com.universal.remote.multi", "com.vidaa.smarttv", "com.hisense.tv.remotenow"});

    /* loaded from: classes.dex */
    public final class Companion {

        /* loaded from: classes.dex */
        public final class Capped extends InputStream {
            public final FileInputStream input;
            public long left;

            public Capped(FileInputStream fileInputStream, long j) {
                this.input = fileInputStream;
                this.left = j;
            }

            @Override // java.io.InputStream, java.io.Closeable, java.lang.AutoCloseable
            public final void close() {
            }

            @Override // java.io.InputStream
            public final int read() {
                if (this.left <= 0) {
                    return -1;
                }
                int read = this.input.read();
                if (read >= 0) {
                    this.left--;
                }
                return read;
            }

            @Override // java.io.InputStream
            public final int read(byte[] b, int i, int i2) {
                Intrinsics.checkNotNullParameter(b, "b");
                long j = this.left;
                if (j <= 0 || i2 == 0) {
                    return i2 == 0 ? 0 : -1;
                }
                int read = this.input.read(b, i, (int) Math.min(i2, j));
                if (read > 0) {
                    this.left -= read;
                }
                return read;
            }
        }

        /* loaded from: classes.dex */
        public final class Public {
            public final List at;
            public final String name;
            public final String sha256;

            public Public(String str, String str2, List list) {
                this.name = str;
                this.sha256 = str2;
                this.at = list;
            }
        }

        public static final KeyManager[] access$cert(File file) {
            String str;
            File file2 = new File(file, "vidaa.p12");
            if (!file2.isFile()) {
                file2 = null;
            }
            if (file2 != null) {
                File file3 = new File(file, "vidaa.pass");
                if (!file3.isFile()) {
                    file3 = null;
                }
                if (file3 != null) {
                    str = MathKt.readText$default(file3);
                } else {
                    str = "";
                }
                try {
                    KeyStore keyStore = KeyStore.getInstance("PKCS12");
                    FileInputStream fileInputStream = new FileInputStream(file2);
                    char[] charArray = str.toCharArray();
                    Intrinsics.checkNotNullExpressionValue(charArray, "toCharArray(...)");
                    keyStore.load(fileInputStream, charArray);
                    KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
                    char[] charArray2 = str.toCharArray();
                    Intrinsics.checkNotNullExpressionValue(charArray2, "toCharArray(...)");
                    keyManagerFactory.init(keyStore, charArray2);
                    return keyManagerFactory.getKeyManagers();
                } catch (Exception unused) {
                }
            }
            return null;
        }

        public static final JSONObject access$json(String str) {
            Companion companion = Vidaa.Companion;
            try {
                return new JSONObject(str);
            } catch (Exception unused) {
                return null;
            }
        }

        public static final List access$list(String str, String str2) {
            JSONArray jSONArray;
            Companion companion = Vidaa.Companion;
            try {
                if (StringsKt__StringsJVMKt.startsWith(StringsKt.trim(str).toString(), false, "[")) {
                    jSONArray = new JSONArray(str);
                } else {
                    jSONArray = new JSONObject(str).optJSONArray(str2);
                }
            } catch (Exception unused) {
                jSONArray = null;
            }
            if (jSONArray == null) {
                return EmptyList.INSTANCE;
            }
            IntRange until = MathKt.until(0, jSONArray.length());
            ArrayList arrayList = new ArrayList();
            Iterator it = until.iterator();
            while (((IntProgressionIterator) it).hasNext) {
                JSONObject optJSONObject = jSONArray.optJSONObject(((IntProgressionIterator) it).nextInt());
                if (optJSONObject != null) {
                    arrayList.add(optJSONObject);
                }
            }
            return arrayList;
        }

        public static byte[] atMost(FilterInputStream filterInputStream) {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            byte[] bArr = new byte[16384];
            do {
                int read = filterInputStream.read(bArr);
                if (read >= 0) {
                    byteArrayOutputStream.write(bArr, 0, read);
                } else {
                    return byteArrayOutputStream.toByteArray();
                }
            } while (byteArrayOutputStream.size() <= 1048576);
            return null;
        }

        /* JADX WARN: Code restructure failed: missing block: B:12:0x0031, code lost:
        
            if (r2.length < 65536) goto L20;
         */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public static byte[] download(String str) {
            byte[] bArr;
            try {
                Function0 function0 = Lan.wifi;
                HttpURLConnection httpURLConnection = (HttpURLConnection) Lan.open(new URL(str));
                httpURLConnection.setConnectTimeout(6000);
                httpURLConnection.setReadTimeout(8000);
                try {
                    if (httpURLConnection.getResponseCode() == 200) {
                        InputStream inputStream = httpURLConnection.getInputStream();
                        try {
                            Intrinsics.checkNotNull(inputStream);
                            bArr = MathKt.readBytes(inputStream);
                            inputStream.close();
                        } finally {
                        }
                    }
                    bArr = null;
                    return bArr;
                } finally {
                    httpURLConnection.disconnect();
                }
            } catch (Exception unused) {
                return null;
            }
        }

        public static boolean importCert(File file, FileInputStream fileInputStream, long j) {
            boolean z;
            Pair pair;
            Capped capped = new Capped(fileInputStream, j);
            BufferedInputStream bufferedInputStream = new BufferedInputStream(capped);
            bufferedInputStream.mark(4);
            int i = 1;
            if (bufferedInputStream.read() == 80 && bufferedInputStream.read() == 75) {
                z = true;
            } else {
                z = false;
            }
            bufferedInputStream.reset();
            Pair pair2 = null;
            if (z) {
                ArrayList arrayList = new ArrayList();
                ZipInputStream zipInputStream = new ZipInputStream(bufferedInputStream);
                while (true) {
                    try {
                        ZipEntry nextEntry = zipInputStream.getNextEntry();
                        if (nextEntry == null) {
                            break;
                        }
                        String name = nextEntry.getName();
                        Intrinsics.checkNotNullExpressionValue(name, "getName(...)");
                        String lowerCase = name.toLowerCase(Locale.ROOT);
                        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                        if (!nextEntry.isDirectory()) {
                            if (!StringsKt__StringsJVMKt.endsWith(lowerCase, false, ".p12") && !StringsKt__StringsJVMKt.endsWith(lowerCase, false, ".pfx")) {
                            }
                            if (nextEntry.getSize() < 1048576) {
                                Companion companion = Vidaa.Companion;
                                byte[] atMost = atMost(zipInputStream);
                                if (atMost != null) {
                                    arrayList.add(new Pair(nextEntry.getName(), atMost));
                                }
                            }
                        }
                    } finally {
                    }
                }
                zipInputStream.close();
                Iterator it = CollectionsKt.sortedWith(arrayList, new Vidaa$device$$inlined$sortedBy$1(i)).iterator();
                while (true) {
                    if (!it.hasNext()) {
                        break;
                    }
                    byte[] bArr = (byte[]) ((Pair) it.next()).second;
                    Companion companion2 = Vidaa.Companion;
                    String open = open(bArr);
                    if (open != null) {
                        pair = new Pair(bArr, open);
                    } else {
                        pair = null;
                    }
                    if (pair != null) {
                        pair2 = pair;
                        break;
                    }
                }
            } else {
                byte[] atMost2 = atMost(bufferedInputStream);
                if (atMost2 != null) {
                    Companion companion3 = Vidaa.Companion;
                    String open2 = open(atMost2);
                    if (open2 != null) {
                        pair2 = new Pair(atMost2, open2);
                    }
                }
            }
            do {
            } while (capped.read(new byte[65536]) >= 0);
            if (pair2 == null) {
                return false;
            }
            byte[] bArr2 = (byte[]) pair2.first;
            String str = (String) pair2.second;
            file.mkdirs();
            MathKt.writeBytes(new File(file, "vidaa.p12"), bArr2);
            MathKt.writeText$default(new File(file, "vidaa.pass"), str);
            WireLog.all.add("·", "VIDAA: Hisense's certificate kept");
            return true;
        }

        public static KeyManager[] keyManagers(String str, byte[] bArr, byte[] bArr2) {
            RSAKey rSAKey;
            BigInteger bigInteger;
            try {
                Certificate generateCertificate = CertificateFactory.getInstance("X.509").generateCertificate(new ByteArrayInputStream(bArr));
                Intrinsics.checkNotNull(generateCertificate, "null cannot be cast to non-null type java.security.cert.X509Certificate");
                X509Certificate x509Certificate = (X509Certificate) generateCertificate;
                byte[] digest = MessageDigest.getInstance("SHA-256").digest(x509Certificate.getEncoded());
                Intrinsics.checkNotNullExpressionValue(digest, "digest(...)");
                if (Intrinsics.areEqual(ArraysKt.joinToString$default(digest, "", new HomeQr$$ExternalSyntheticLambda0(9)), str)) {
                    String str2 = new String(bArr2, Charsets.US_ASCII);
                    String substringAfter = StringsKt.substringAfter(str2, "-----BEGIN PRIVATE KEY-----", str2);
                    String substringBefore = StringsKt.substringBefore(substringAfter, "-----END", substringAfter);
                    StringBuilder sb = new StringBuilder();
                    int length = substringBefore.length();
                    for (int i = 0; i < length; i++) {
                        char charAt = substringBefore.charAt(i);
                        if (!MathKt.isWhitespace(charAt)) {
                            sb.append(charAt);
                        }
                    }
                    PrivateKey generatePrivate = KeyFactory.getInstance(x509Certificate.getPublicKey().getAlgorithm()).generatePrivate(new PKCS8EncodedKeySpec(B64.decode(sb.toString())));
                    if (generatePrivate instanceof RSAKey) {
                        PublicKey publicKey = x509Certificate.getPublicKey();
                        if (publicKey instanceof RSAKey) {
                            rSAKey = (RSAKey) publicKey;
                        } else {
                            rSAKey = null;
                        }
                        if (rSAKey != null) {
                            bigInteger = rSAKey.getModulus();
                        } else {
                            bigInteger = null;
                        }
                        if (!Intrinsics.areEqual(bigInteger, ((RSAKey) generatePrivate).getModulus())) {
                        }
                    }
                    char[] charArray = "vidaa".toCharArray();
                    Intrinsics.checkNotNullExpressionValue(charArray, "toCharArray(...)");
                    KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
                    keyStore.load(null, null);
                    keyStore.setKeyEntry("vidaa", generatePrivate, charArray, new X509Certificate[]{x509Certificate});
                    KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
                    keyManagerFactory.init(keyStore, charArray);
                    return keyManagerFactory.getKeyManagers();
                }
            } catch (Exception unused) {
            }
            return null;
        }

        public static String md5(String str) {
            MessageDigest messageDigest = MessageDigest.getInstance("MD5");
            byte[] bytes = str.getBytes(Charsets.UTF_8);
            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
            byte[] digest = messageDigest.digest(bytes);
            Intrinsics.checkNotNullExpressionValue(digest, "digest(...)");
            return ArraysKt.joinToString$default(digest, "", new HomeQr$$ExternalSyntheticLambda0(8));
        }

        public static String norm$shared_release(String s) {
            Intrinsics.checkNotNullParameter(s, "s");
            String lowerCase = s.toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
            StringBuilder sb = new StringBuilder();
            int length = lowerCase.length();
            for (int i = 0; i < length; i++) {
                char charAt = lowerCase.charAt(i);
                if (Character.isLetterOrDigit(charAt)) {
                    sb.append(charAt);
                }
            }
            return sb.toString();
        }

        public static String normMac$shared_release(String str) {
            String obj = StringsKt.trim(str).toString();
            if (!Vidaa.RAW_MAC.matches(obj)) {
                if (Vidaa.MAC.matches(obj)) {
                    Pattern compile = Pattern.compile("[:-]");
                    Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                    obj = compile.matcher(obj).replaceAll("");
                    Intrinsics.checkNotNullExpressionValue(obj, "replaceAll(...)");
                } else {
                    return null;
                }
            }
            String upperCase = obj.toUpperCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
            if (!upperCase.equals("000000000000") && !upperCase.equals("FFFFFFFFFFFF")) {
                return CollectionsKt.joinToString$default(StringsKt.chunked(upperCase, 2), ":", null, null, null, 62);
            }
            return null;
        }

        public static Remote of(File file, String str, String host) {
            Intrinsics.checkNotNullParameter(host, "host");
            int hashCode = str.hashCode();
            if (hashCode != 3451) {
                if (hashCode != 3506279) {
                    if (hashCode != 112202737) {
                        if (hashCode == 1864941562 && str.equals("samsung")) {
                            return new Samsung(file, host);
                        }
                    } else if (str.equals("vidaa")) {
                        return new Vidaa(file, host);
                    }
                } else if (str.equals("roku")) {
                    return new Roku(file, host);
                }
            } else if (str.equals("lg")) {
                return new Lg(file, host);
            }
            return new Atv(file, host);
        }

        public static String open(byte[] bArr) {
            Object obj;
            Iterator it = Vidaa.P12_PASSWORDS.iterator();
            loop0: while (true) {
                if (it.hasNext()) {
                    obj = it.next();
                    String str = (String) obj;
                    try {
                        KeyStore keyStore = KeyStore.getInstance("PKCS12");
                        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bArr);
                        char[] charArray = str.toCharArray();
                        Intrinsics.checkNotNullExpressionValue(charArray, "toCharArray(...)");
                        keyStore.load(byteArrayInputStream, charArray);
                        Enumeration<String> aliases = keyStore.aliases();
                        Intrinsics.checkNotNullExpressionValue(aliases, "aliases(...)");
                        ArrayList<String> list = Collections.list(aliases);
                        Intrinsics.checkNotNullExpressionValue(list, "list(...)");
                        if (!list.isEmpty()) {
                            for (String str2 : list) {
                                if (keyStore.isKeyEntry(str2)) {
                                    char[] charArray2 = str.toCharArray();
                                    Intrinsics.checkNotNullExpressionValue(charArray2, "toCharArray(...)");
                                    if (keyStore.getKey(str2, charArray2) != null) {
                                        break loop0;
                                    }
                                }
                            }
                        }
                    } catch (Exception unused) {
                    }
                } else {
                    obj = null;
                    break;
                }
            }
            return (String) obj;
        }

        public static WebSocket open$default(String host, int i, String path, boolean z) {
            Socket socket;
            Socket socket2;
            SecureRandom secureRandom = WebSocket.RANDOM;
            Intrinsics.checkNotNullParameter(host, "host");
            Intrinsics.checkNotNullParameter(path, "path");
            Socket connect = Lan.connect(host, i, 4000, new Lan$$ExternalSyntheticLambda0(0));
            try {
                connect.setSoTimeout(4000);
                String str = null;
                if (z) {
                    SSLContext sSLContext = SSLContext.getInstance("TLS");
                    sSLContext.init(null, new X509TrustManager[]{WebSocket.TRUST_ANY}, WebSocket.RANDOM);
                    Socket createSocket = sSLContext.getSocketFactory().createSocket(connect, host, i, true);
                    Intrinsics.checkNotNull(createSocket, "null cannot be cast to non-null type javax.net.ssl.SSLSocket");
                    SSLSocket sSLSocket = (SSLSocket) createSocket;
                    sSLSocket.startHandshake();
                    socket2 = sSLSocket;
                } else {
                    socket2 = connect;
                }
                try {
                    int[] iArr = B64.INDEX;
                    byte[] bArr = new byte[16];
                    WebSocket.RANDOM.nextBytes(bArr);
                    String encode = B64.encode(bArr);
                    String str2 = "GET " + path + " HTTP/1.1\r\nHost: " + host + ":" + i + "\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: " + encode + "\r\nSec-WebSocket-Version: 13\r\nOrigin: http://" + host + "\r\n\r\n";
                    OutputStream outputStream = socket2.getOutputStream();
                    byte[] bytes = str2.getBytes(Charsets.ISO_8859_1);
                    Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                    outputStream.write(bytes);
                    socket2.getOutputStream().flush();
                    StringBuilder sb = new StringBuilder();
                    InputStream inputStream = socket2.getInputStream();
                    while (!StringsKt.endsWith$default(sb, "\r\n\r\n")) {
                        int read = inputStream.read();
                        if (read >= 0) {
                            sb.append((char) read);
                            if (sb.length() > 16384) {
                                throw new IOException("bad answer");
                            }
                        } else {
                            throw new IOException("the TV closed the connection");
                        }
                    }
                    String sb2 = sb.toString();
                    Intrinsics.checkNotNullExpressionValue(sb2, "toString(...)");
                    String substringBefore = StringsKt.substringBefore(sb2, "\r\n", sb2);
                    if (StringsKt.contains(substringBefore, " 101", false)) {
                        Pattern compile = Pattern.compile("(?im)^sec-websocket-accept:\\s*(\\S+)");
                        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                        Matcher matcher = compile.matcher(sb);
                        Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
                        MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, sb);
                        if (access$findNext != null) {
                            str = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1);
                        }
                        int[] iArr2 = B64.INDEX;
                        MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
                        byte[] bytes2 = (encode + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").getBytes(Charsets.UTF_8);
                        Intrinsics.checkNotNullExpressionValue(bytes2, "getBytes(...)");
                        byte[] digest = messageDigest.digest(bytes2);
                        Intrinsics.checkNotNullExpressionValue(digest, "digest(...)");
                        String encode2 = B64.encode(digest);
                        if (str != null && !str.equals(encode2)) {
                            throw new IOException("bad websocket answer");
                        }
                        return new WebSocket(socket2);
                    }
                    throw new IOException("the TV said: " + substringBefore);
                } catch (Exception e) {
                    e = e;
                    socket = socket2;
                    try {
                        socket.close();
                    } catch (Exception unused) {
                    }
                    try {
                        connect.close();
                    } catch (Exception unused2) {
                    }
                    if (!(e instanceof IOException)) {
                        String message = e.getMessage();
                        if (message == null) {
                            message = e.getClass().getSimpleName();
                        }
                        throw new IOException(message, e);
                    }
                    throw e;
                }
            } catch (Exception e2) {
                e = e2;
                socket = connect;
            }
        }

        public static KeyManager[] pem(File file, String str) {
            File file2 = new File(file, ApkSigner$$ExternalSyntheticOutline0.m("vidaa-", str, ".crt"));
            File file3 = new File(file, ApkSigner$$ExternalSyntheticOutline0.m("vidaa-", str, ".key"));
            if (file2.isFile() && file3.isFile()) {
                byte[] readBytes = MathKt.readBytes(file2);
                byte[] readBytes2 = MathKt.readBytes(file3);
                for (Public r2 : Vidaa.PUBLIC) {
                    if (r2.name.equals(str)) {
                        return keyManagers(r2.sha256, readBytes, readBytes2);
                    }
                }
                throw new NoSuchElementException("Collection contains no element matching the predicate.");
            }
            return null;
        }
    }

    /* JADX WARN: Type inference failed for: r16v0, types: [dev.tvremote.core.remote.Vidaa$Companion, java.lang.Object] */
    static {
        List asList = ArraysKt.asList(new String[]{"authentication", "authenticationcode", "authenticationcodeclose", "vidaa_app_connect", "gettvstate", "state", "sourcelist", "applist"});
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(asList));
        Iterator it = asList.iterator();
        while (it.hasNext()) {
            arrayList.add("ui_service/data/" + ((String) it.next()));
        }
        List asList2 = ArraysKt.asList(new String[]{"tokenissuance", "gettoken", "getvolume", "getdeviceinfo", "gettvinfo"});
        ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(asList2));
        Iterator it2 = asList2.iterator();
        while (it2.hasNext()) {
            arrayList2.add("platform_service/data/" + ((String) it2.next()));
        }
        MINE = CollectionsKt.plus((List) arrayList, (Iterable) arrayList2);
        P12_PASSWORDS = ArraysKt.asList(new String[]{"186e990688070325a1c4b0ce275d2388", "", "remote", "hisense", "123456"});
        NAME_FIELDS = ArraysKt.asList(new String[]{"devicename", "device_name", "friendly_name", "tv_name"});
        IFACES = SetsKt.setOf((Object[]) new String[]{"eth0", "wlan0"});
        RAW_MAC = new Regex("(?i)^[0-9a-f]{12}$");
        MAC = new Regex("(?i)^[0-9a-f]{2}([:-][0-9a-f]{2}){5}$");
        Map mapOf = MapsKt__MapsKt.mapOf(new Pair(19, "KEY_UP"), new Pair(20, "KEY_DOWN"), new Pair(21, "KEY_LEFT"), new Pair(22, "KEY_RIGHT"), new Pair(23, "KEY_OK"), new Pair(66, "KEY_OK"), new Pair(4, "KEY_RETURNS"), new Pair(3, "KEY_HOME"), new Pair(82, "KEY_MENU"), new Pair(176, "KEY_MENU"), new Pair(111, "KEY_EXIT"), new Pair(26, "KEY_POWER"), new Pair(24, "KEY_VOLUMEUP"), new Pair(25, "KEY_VOLUMEDOWN"), new Pair(164, "KEY_MUTE"), new Pair(85, "KEY_PLAY"), new Pair(126, "KEY_PLAY"), new Pair(127, "KEY_PAUSE"), new Pair(86, "KEY_STOP"), new Pair(90, "KEY_FORWARDS"), new Pair(89, "KEY_BACK"), new Pair(166, "KEY_CHANNELUP"), new Pair(167, "KEY_CHANNELDOWN"), new Pair(183, "KEY_RED"), new Pair(184, "KEY_GREEN"), new Pair(185, "KEY_YELLOW"), new Pair(186, "KEY_BLUE"), new Pair(175, "KEY_SUBTITLE"), new Pair(165, "KEY_INFO"), new Pair(170, "KEY_LIVETV"), new Pair(172, "KEY_EPG"), new Pair(284, "KEY_APPS"), new Pair(190, "KEY_YOUTUBE"), new Pair(191, "KEY_NETFLIX"), new Pair(195, "KEY_PRIME"));
        IntProgression intProgression = new IntProgression(0, 9, 1);
        int mapCapacity = MapsKt__MapsKt.mapCapacity(CollectionsKt__IterablesKt.collectionSizeOrDefault(intProgression));
        if (mapCapacity < 16) {
            mapCapacity = 16;
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap(mapCapacity);
        Iterator it3 = intProgression.iterator();
        while (((IntProgressionIterator) it3).hasNext) {
            int nextInt = ((IntProgressionIterator) it3).nextInt();
            linkedHashMap.put(Integer.valueOf(nextInt + 7), "KEY_" + nextInt);
        }
        KEYS = MapsKt__MapsKt.plus(mapOf, linkedHashMap);
        TRUST_ALL = new Atv$dial$anyTv$1(1);
        PUBLIC = ArraysKt.asList(new Companion.Public[]{new Companion.Public("vidaa_client", "31f914630f8636d6c4313e02e9eb3724b4706c6b5049c838b04213ab56905aa3", ArraysKt.asList(new Pair[]{new Pair("adamazad/vidaa-remote/HEAD/certs/vidaa_client.pem", "adamazad/vidaa-remote/HEAD/certs/vidaa_client.key"), new Pair("tombabolewski/vidaa-control/HEAD/vidaa/certs/vidaa_client.pem", "tombabolewski/vidaa-control/HEAD/vidaa/certs/vidaa_client.key"), new Pair("HoangTran0410/vidaa-certs/main/vidaa_client.pem", "HoangTran0410/vidaa-certs/main/vidaa_client.key")})), new Companion.Public("remoteclientmobile", "857e4d1ad94f892404371ff1cb282c1b890f73ced3fd47051e6e20d590557c59", ArraysKt.asList(new Pair[]{new Pair("Alexa-RR/ha-vidaa/HEAD/custom_components/vidaa/certs/vidaa_client.crt", "Alexa-RR/ha-vidaa/HEAD/custom_components/vidaa/certs/vidaa_client.key"), new Pair("amirburbea/neeo/HEAD/Neeo.Drivers.Hisense/Certificates/rcm_certchain_pem.cer", "amirburbea/neeo/HEAD/Neeo.Drivers.Hisense/Certificates/rcm_pem_privkey.pkcs8"), new Pair("HoangTran0410/vidaa-certs/main/remoteclientmobile.pem", "HoangTran0410/vidaa-certs/main/remoteclientmobile.key")}))});
        RAW = "https://raw.githubusercontent.com/";
    }

    /* JADX WARN: Code restructure failed: missing block: B:11:0x005c, code lost:
    
        if (r3 != null) goto L16;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public Vidaa(File file, String host) {
        File file2;
        String joinToString$default;
        String obj;
        Vidaa$$ExternalSyntheticLambda0 vidaa$$ExternalSyntheticLambda0 = new Vidaa$$ExternalSyntheticLambda0(0);
        Intrinsics.checkNotNullParameter(host, "host");
        this.dir = file;
        this.host = host;
        this.wol = vidaa$$ExternalSyntheticLambda0;
        this.model = "";
        this.vendor = "Hisense";
        this.version = "";
        this.app = "";
        this.mac = "";
        EmptyList emptyList = EmptyList.INSTANCE;
        this.macs = emptyList;
        this.apps = emptyList;
        this.sources = emptyList;
        this.waits = new CopyOnWriteArrayList();
        File file3 = new File(file, "vidaa-id");
        if (file3.isFile()) {
            file2 = file3;
        } else {
            file2 = null;
        }
        if (file2 != null && (obj = StringsKt.trim(MathKt.readText$default(file2)).toString()) != null) {
            joinToString$default = MAC.matches(obj) ? obj : null;
        }
        byte[] bArr = new byte[6];
        new SecureRandom().nextBytes(bArr);
        bArr[0] = (byte) ((bArr[0] & 252) | 2);
        joinToString$default = ArraysKt.joinToString$default(bArr, ":", new HomeQr$$ExternalSyntheticLambda0(7));
        file.mkdirs();
        MathKt.writeText$default(file3, joinToString$default);
        this.me = joinToString$default;
        this.cid = joinToString$default + "$his$" + StringsKt.take(Companion.md5("38D65DC30F45109A369A86FCE866A85B$".concat(joinToString$default)), 6) + "_vidaacommon_001";
        Pattern compile = Pattern.compile("[^\\w.-]");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        String replaceAll = compile.matcher(host).replaceAll("_");
        Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
        this.tokenFile = new File(file, ApkSigner$$ExternalSyntheticOutline0.m("vidaa-", replaceAll, ".json"));
        this.pairUser = "";
        this.out = Executors.newSingleThreadExecutor(new Diagnose$$ExternalSyntheticLambda1(6));
    }

    public static boolean expired(String str, JSONObject jSONObject) {
        long optLong = jSONObject.optLong(str.concat("_time"));
        int optInt = jSONObject.optInt(str.concat("_days"));
        if (optLong > 0 && optInt > 0 && (optInt * 86400) + optLong < System.currentTimeMillis() / 1000) {
            return true;
        }
        return false;
    }

    public static JSONObject fromTokens(JSONObject jSONObject) {
        long currentTimeMillis = System.currentTimeMillis() / 1000;
        JSONObject put = new JSONObject().put("access", jSONObject.optString("accesstoken")).put("refresh", jSONObject.optString("refreshtoken")).put("access_time", jSONObject.optLong("accesstoken_time", currentTimeMillis)).put("access_days", jSONObject.optInt("accesstoken_duration_day", 2)).put("refresh_time", jSONObject.optLong("refreshtoken_time", currentTimeMillis)).put("refresh_days", jSONObject.optInt("refreshtoken_duration_day", 30));
        Intrinsics.checkNotNullExpressionValue(put, "put(...)");
        return put;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final List apps() {
        Remote.App app;
        List<JSONObject> fetch = fetch("applist", "applist");
        ArrayList arrayList = new ArrayList();
        for (JSONObject jSONObject : fetch) {
            String optString = jSONObject.optString("appId");
            if (optString.length() == 0) {
                app = null;
            } else {
                String optString2 = jSONObject.optString("name");
                if (optString2.length() == 0) {
                    optString2 = optString;
                }
                app = new Remote.App(optString, optString2, "");
            }
            if (app != null) {
                arrayList.add(app);
            }
        }
        return arrayList;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        this.closed = true;
        this.live = false;
        MqttLite mqttLite = this.mqtt;
        MqttLite mqttLite2 = this.pairing;
        this.mqtt = null;
        this.pairing = null;
        this.out.shutdown();
        new Thread(new Guard$$ExternalSyntheticLambda5(18, mqttLite, mqttLite2)).start();
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void connect(Function0 function0) {
        String str;
        JSONArray jSONArray;
        String normMac$shared_release;
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        Object remembered = remembered("mac");
        JSONObject jSONObject = null;
        if (remembered instanceof String) {
            str = (String) remembered;
        } else {
            str = null;
        }
        if (str != null && (normMac$shared_release = Companion.normMac$shared_release(str)) != null) {
            linkedHashSet.add(normMac$shared_release);
        }
        Object remembered2 = remembered("macs");
        if (remembered2 instanceof JSONArray) {
            jSONArray = (JSONArray) remembered2;
        } else {
            jSONArray = null;
        }
        if (jSONArray != null) {
            int length = jSONArray.length();
            for (int i = 0; i < length; i++) {
                String optString = jSONArray.optString(i);
                Intrinsics.checkNotNullExpressionValue(optString, "optString(...)");
                String normMac$shared_release2 = Companion.normMac$shared_release(optString);
                if (normMac$shared_release2 != null) {
                    linkedHashSet.add(normMac$shared_release2);
                }
            }
        }
        if (!linkedHashSet.isEmpty()) {
            this.macs = CollectionsKt.toList(linkedHashSet);
            if (this.mac.length() == 0) {
                this.mac = (String) CollectionsKt.first(this.macs);
            }
            if (!portOpen()) {
                WireLog.all.add("→", Census$$ExternalSyntheticOutline0.m("VIDAA ", this.host, " refuses port 36669: Wake-on-LAN to ", CollectionsKt.joinToString$default(this.macs, " ", null, null, null, 62)));
                try {
                    Iterator it = this.macs.iterator();
                    while (it.hasNext()) {
                        this.wol.invoke((String) it.next(), this.host);
                    }
                    long currentTimeMillis = System.currentTimeMillis() + 30000;
                    while (System.currentTimeMillis() < currentTimeMillis) {
                        try {
                            Thread.sleep(2000L);
                            if (portOpen()) {
                                break;
                            }
                        } catch (InterruptedException unused) {
                            Thread.currentThread().interrupt();
                        }
                    }
                } catch (Exception unused2) {
                }
            }
        }
        File file = this.tokenFile;
        try {
            if (file.isFile()) {
                JSONObject jSONObject2 = new JSONObject(MathKt.readText$default(file));
                String optString2 = jSONObject2.optString("access");
                Intrinsics.checkNotNullExpressionValue(optString2, "optString(...)");
                if (optString2.length() > 0) {
                    jSONObject = jSONObject2;
                }
            }
        } catch (Exception unused3) {
        }
        if (jSONObject != null) {
            String optString3 = jSONObject.optString("user");
            String optString4 = jSONObject.optString("access");
            if (!Intrinsics.areEqual(jSONObject.optString("profile"), "legacy") && expired("access", jSONObject) && (optString4 = refresh(jSONObject)) == null) {
                throw forget();
            }
            try {
                Intrinsics.checkNotNull(optString3);
                Intrinsics.checkNotNull(optString4);
                open(optString3, optString4, function0);
                return;
            } catch (MqttLite.Rejected unused4) {
                if (!Intrinsics.areEqual(jSONObject.optString("profile"), "legacy")) {
                    Intrinsics.checkNotNull(optString3);
                    String refresh = refresh(jSONObject);
                    if (refresh != null) {
                        open(optString3, refresh, function0);
                        return;
                    }
                    throw forget();
                }
                throw forget();
            }
        }
        try {
            MqttLite session = session("hisenseservice", "multimqttservice", new Census$$ExternalSyntheticLambda4(11));
            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = new HomeQr$$ExternalSyntheticLambda0(4);
            ArrayBlockingQueue arrayBlockingQueue = new ArrayBlockingQueue(1);
            Pair pair = new Pair(homeQr$$ExternalSyntheticLambda0, arrayBlockingQueue);
            CopyOnWriteArrayList copyOnWriteArrayList = this.waits;
            copyOnWriteArrayList.add(pair);
            try {
                session.publish(ui("gettvstate"), "");
                Pair pair2 = (Pair) arrayBlockingQueue.poll(3000L, TimeUnit.MILLISECONDS);
                copyOnWriteArrayList.remove(pair);
                session.close();
                if (pair2 == null) {
                    JSONObject put = Census$$ExternalSyntheticOutline0.m10m("profile", "legacy", "user", "hisenseservice").put("access", "multimqttservice");
                    Intrinsics.checkNotNullExpressionValue(put, "put(...)");
                    save(put);
                    open("hisenseservice", "multimqttservice", function0);
                    return;
                }
                remember(Boolean.TRUE, "static");
                throw new Atv.NotPaired();
            } catch (Throwable th) {
                copyOnWriteArrayList.remove(pair);
                throw th;
            }
        } catch (MqttLite.Rejected unused5) {
            throw new Atv.NotPaired();
        }
    }

    public final Pair expect(long j, Function1 function1, Function0 function0) {
        ArrayBlockingQueue arrayBlockingQueue = new ArrayBlockingQueue(1);
        Pair pair = new Pair(function1, arrayBlockingQueue);
        CopyOnWriteArrayList copyOnWriteArrayList = this.waits;
        copyOnWriteArrayList.add(pair);
        try {
            function0.invoke();
            return (Pair) arrayBlockingQueue.poll(j, TimeUnit.MILLISECONDS);
        } finally {
            copyOnWriteArrayList.remove(pair);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.util.List, java.util.Collection] */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v8 */
    public final List fetch(String str, String str2) {
        ?? r0;
        if (str2.equals("applist")) {
            r0 = this.apps;
        } else {
            r0 = this.sources;
        }
        if (r0.isEmpty() && ready()) {
            Guard$$ExternalSyntheticLambda4 guard$$ExternalSyntheticLambda4 = new Guard$$ExternalSyntheticLambda4(str, 5);
            ArrayBlockingQueue arrayBlockingQueue = new ArrayBlockingQueue(1);
            Pair pair = new Pair(guard$$ExternalSyntheticLambda4, arrayBlockingQueue);
            CopyOnWriteArrayList copyOnWriteArrayList = this.waits;
            copyOnWriteArrayList.add(pair);
            try {
                send(ui(str), "");
                Pair pair2 = (Pair) arrayBlockingQueue.poll(3000L, TimeUnit.MILLISECONDS);
                if (pair2 == null) {
                    return EmptyList.INSTANCE;
                }
                return Companion.access$list((String) pair2.second, str2);
            } finally {
                copyOnWriteArrayList.remove(pair);
            }
        }
        return r0;
    }

    @Override // dev.tvremote.core.remote.CodePairing
    public final void finishPairing(String code) {
        Intrinsics.checkNotNullParameter(code, "code");
        MqttLite mqttLite = this.pairing;
        if (mqttLite != null) {
            ArrayBlockingQueue arrayBlockingQueue = new ArrayBlockingQueue(1);
            Pair pair = new Pair(new HomeQr$$ExternalSyntheticLambda0(2), arrayBlockingQueue);
            this.waits.add(pair);
            try {
                StringBuilder sb = new StringBuilder();
                int length = code.length();
                for (int i = 0; i < length; i++) {
                    char charAt = code.charAt(i);
                    if (Character.isDigit(charAt)) {
                        sb.append(charAt);
                    }
                }
                Integer intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull(sb.toString());
                if (intOrNull != null) {
                    Pair expect = expect(15000L, new HomeQr$$ExternalSyntheticLambda0(3), new Vidaa$$ExternalSyntheticLambda18(mqttLite, this, intOrNull.intValue()));
                    if (expect != null) {
                        String str = (String) expect.first;
                        String str2 = (String) expect.second;
                        if (!StringsKt__StringsJVMKt.endsWith(str, false, "close")) {
                            JSONObject access$json = Companion.access$json(str2);
                            if (access$json != null && access$json.optInt("result") == 1) {
                                if (this.pairStatic) {
                                    JSONObject put = new JSONObject().put("profile", "legacy").put("user", "hisenseservice").put("access", "multimqttservice");
                                    Intrinsics.checkNotNullExpressionValue(put, "put(...)");
                                    save(put);
                                } else {
                                    Pair pair2 = (Pair) arrayBlockingQueue.poll();
                                    if (pair2 == null) {
                                        mqttLite.publish(platform("gettoken", "data"), "{\"refreshtoken\":\"\"}");
                                        mqttLite.publish(ui("authenticationcodeclose"), "");
                                        pair2 = (Pair) arrayBlockingQueue.poll(15000L, TimeUnit.MILLISECONDS);
                                        if (pair2 == null) {
                                            throw new IOException("the TV gave no token");
                                        }
                                    }
                                    JSONObject access$json2 = Companion.access$json((String) pair2.second);
                                    if (access$json2 != null) {
                                        String optString = access$json2.optString("accesstoken");
                                        Intrinsics.checkNotNullExpressionValue(optString, "optString(...)");
                                        if (optString.length() <= 0) {
                                            access$json2 = null;
                                        }
                                        if (access$json2 != null) {
                                            JSONObject put2 = fromTokens(access$json2).put("profile", "dynamic").put("user", this.pairUser);
                                            Intrinsics.checkNotNullExpressionValue(put2, "put(...)");
                                            save(put2);
                                            WireLog.all.add("←", "VIDAA " + this.host + " paired");
                                        }
                                    }
                                    throw new IOException("the TV gave no token");
                                }
                                this.waits.remove(pair);
                                mqttLite.close();
                                this.pairing = null;
                                return;
                            }
                            throw new IllegalArgumentException("wrong code");
                        }
                        throw new IOException("the TV closed its code");
                    }
                    throw new IOException("the TV did not answer the code");
                }
                throw new IllegalArgumentException("wrong code");
            } catch (Throwable th) {
                this.waits.remove(pair);
                mqttLite.close();
                this.pairing = null;
                throw th;
            }
        }
        throw new IllegalStateException("startPairing first");
    }

    public final Atv.NotPaired forget() {
        this.tokenFile.delete();
        WireLog wireLog = WireLog.all;
        WireLog.all.add("·", "VIDAA " + this.host + ": the token is no longer taken, pair again");
        return new Atv.NotPaired();
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getApp() {
        return this.app;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean getAsking() {
        return false;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final Set getKeys() {
        return KEYS.keySet();
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getKind() {
        return "vidaa";
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getMac() {
        return this.mac;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getModel() {
        return this.model;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getVendor() {
        return this.vendor;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final String getVersion() {
        return this.version;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r6v3, types: [dev.tvremote.core.remote.Inputs$Input] */
    @Override // dev.tvremote.core.remote.Remote
    public final List inputs() {
        String str;
        String str2;
        int i;
        String obj;
        MatcherMatchResult access$findNext;
        Integer intOrNull;
        String m;
        List<JSONObject> fetch = fetch("sourcelist", "sourcelist");
        ArrayList arrayList = new ArrayList();
        for (JSONObject jSONObject : fetch) {
            String optString = jSONObject.optString("sourceid");
            if (optString.length() == 0) {
                optString = jSONObject.optString("sourcename");
            }
            String str3 = optString;
            Boolean bool = null;
            if (str3.length() != 0) {
                String optString2 = jSONObject.optString("sourcename");
                if (optString2.length() == 0) {
                    optString2 = jSONObject.optString("displayname");
                }
                if (optString2.length() == 0) {
                    optString2 = str3;
                }
                String lowerCase = optString2.toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                boolean z = false;
                if (StringsKt.contains(lowerCase, "hdmi", false)) {
                    str = "hdmi";
                } else if (!lowerCase.equals("tv") && !StringsKt.contains(lowerCase, "dtv", false) && !StringsKt.contains(lowerCase, "atv", false)) {
                    str = "av";
                    if (!StringsKt.contains(lowerCase, "av", false) && !StringsKt.contains(lowerCase, "component", false)) {
                        str = "other";
                    }
                } else {
                    str = "tuner";
                }
                String optString3 = jSONObject.optString("displayname2");
                Intrinsics.checkNotNull(optString3);
                if (StringsKt.isBlank(optString3) || optString3.equals(optString2)) {
                    optString3 = null;
                }
                if (optString3 != null && (m = Census$$ExternalSyntheticOutline0.m(optString2, " · ", optString3)) != null) {
                    str2 = m;
                } else {
                    str2 = optString2;
                }
                if (str.equals("hdmi") && (access$findNext = MathKt.access$findNext(Census$$ExternalSyntheticOutline0.m6m("(\\d+)", "compile(...)", optString2, "matcher(...)"), 0, optString2)) != null && (intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull(access$findNext.getValue())) != null) {
                    i = intOrNull.intValue();
                } else {
                    i = 0;
                }
                String optString4 = jSONObject.optString("displayname2");
                Intrinsics.checkNotNullExpressionValue(optString4, "optString(...)");
                Object opt = jSONObject.opt("is_signal");
                if (opt != null && (obj = opt.toString()) != null) {
                    if (obj.equals("1") || obj.equals("true")) {
                        z = true;
                    }
                    bool = Boolean.valueOf(z);
                }
                bool = new Inputs.Input(str3, str, i, optString4, str2, bool, 64, 0);
            }
            if (bool != null) {
                arrayList.add(bool);
            }
        }
        return arrayList;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final Boolean isOn() {
        return this.isOn;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void key(int i, int i2) {
        String str;
        if (i2 != 2 && (str = (String) KEYS.get(Integer.valueOf(i))) != null) {
            send("/remoteapp/tv/remote_service/" + this.cid + "/actions/sendkey", str);
            if (i == 26 && this.isOn != null) {
                Intrinsics.checkNotNull(this.isOn);
                this.isOn = Boolean.valueOf(!r4.booleanValue());
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.util.Collection, java.lang.Object] */
    @Override // dev.tvremote.core.remote.Remote
    public final void launch(String link) {
        JSONObject jSONObject;
        Object obj;
        Object obj2;
        Intrinsics.checkNotNullParameter(link, "link");
        ?? r0 = this.apps;
        boolean isEmpty = r0.isEmpty();
        List list = r0;
        if (isEmpty) {
            list = fetch("applist", "applist");
        }
        Iterator it = list.iterator();
        while (true) {
            jSONObject = null;
            if (it.hasNext()) {
                obj = it.next();
                JSONObject jSONObject2 = (JSONObject) obj;
                if (Intrinsics.areEqual(jSONObject2.optString("appId"), link) || StringsKt__StringsJVMKt.equals(jSONObject2.optString("name"), link)) {
                    break;
                }
            } else {
                obj = null;
                break;
            }
        }
        JSONObject jSONObject3 = (JSONObject) obj;
        if (jSONObject3 != null) {
            jSONObject = jSONObject3;
        } else {
            String norm$shared_release = Companion.norm$shared_release(link);
            if (norm$shared_release.length() != 0) {
                Iterator it2 = list.iterator();
                while (true) {
                    if (it2.hasNext()) {
                        obj2 = it2.next();
                        String optString = ((JSONObject) obj2).optString("name");
                        Intrinsics.checkNotNullExpressionValue(optString, "optString(...)");
                        if (Intrinsics.areEqual(Companion.norm$shared_release(optString), norm$shared_release)) {
                            break;
                        }
                    } else {
                        obj2 = null;
                        break;
                    }
                }
                JSONObject jSONObject4 = (JSONObject) obj2;
                if (jSONObject4 == null) {
                    Iterator it3 = list.iterator();
                    while (true) {
                        if (!it3.hasNext()) {
                            break;
                        }
                        Object next = it3.next();
                        String optString2 = ((JSONObject) next).optString("name");
                        Intrinsics.checkNotNullExpressionValue(optString2, "optString(...)");
                        if (StringsKt__StringsJVMKt.startsWith(Companion.norm$shared_release(optString2), false, norm$shared_release)) {
                            jSONObject = next;
                            break;
                        }
                    }
                    jSONObject = jSONObject;
                } else {
                    jSONObject = jSONObject4;
                }
            }
        }
        if (jSONObject == null) {
            return;
        }
        String ui = ui("launchapp");
        JSONObject put = new JSONObject().put("appId", jSONObject.optString("appId")).put("name", jSONObject.optString("name")).put("url", jSONObject.optString("url"));
        Object opt = jSONObject.opt("urlType");
        if (opt == null) {
            opt = 37;
        }
        JSONObject put2 = put.put("urlType", opt);
        Object opt2 = jSONObject.opt("storeType");
        if (opt2 == null) {
            opt2 = 0;
        }
        String jSONObject5 = put2.put("storeType", opt2).put("appName", jSONObject.optString("name")).put("appUrl", jSONObject.optString("url")).toString();
        Intrinsics.checkNotNullExpressionValue(jSONObject5, "toString(...)");
        send(ui, jSONObject5);
    }

    public final MqttLite login(List list, String str, String str2, Function0 function0, Function1 function1) {
        Iterator it;
        MqttLite mqttLite;
        String str3 = this.cid;
        String str4 = this.host;
        Iterator it2 = CollectionsKt.sortedWith(list, new Setup$plan$$inlined$sortedBy$1(1, remembered("tls"))).iterator();
        while (it2.hasNext()) {
            String str5 = (String) it2.next();
            try {
                it = it2;
                try {
                } catch (Exception e) {
                    e = e;
                }
                try {
                    mqttLite = new MqttLite(socket(str5), new Census$post$1(2, this, Vidaa.class, "message", "message(Ljava/lang/String;[B)V", 1), new Regex$$ExternalSyntheticLambda0(3, this, function0));
                } catch (Exception e2) {
                    e = e2;
                    function1.invoke(e);
                    it2 = it;
                }
            } catch (Exception e3) {
                e = e3;
                it = it2;
            }
            try {
                MqttLite.connect$default(mqttLite, str3, str, str2);
                WireLog.all.add("←", Census$$ExternalSyntheticOutline0.m("VIDAA ", str4, " connected (", str5, ")"));
                remember(str5, "tls");
                List listOf = MathKt.listOf("/remoteapp/mobile/" + str3 + "/#");
                ArrayList arrayList = MINE;
                ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList));
                Iterator it3 = arrayList.iterator();
                while (it3.hasNext()) {
                    arrayList2.add("/remoteapp/mobile/" + str3 + "/" + ((String) it3.next()));
                }
                String[] strArr = (String[]) CollectionsKt.plus(listOf, (Iterable) arrayList2).toArray(new String[0]);
                mqttLite.subscribe((String[]) Arrays.copyOf(strArr, strArr.length));
                return mqttLite;
            } catch (MqttLite.Rejected e4) {
                mqttLite.close();
                WireLog.all.add("←", "VIDAA " + str4 + " (" + str5 + ") refused the login: code " + e4.code);
                remember(str5, "tls");
                throw e4;
            } catch (Exception e5) {
                mqttLite.close();
                function1.invoke(e5);
                it2 = it;
            }
        }
        return null;
    }

    public final void open(String str, String str2, Function0 function0) {
        MqttLite session = session(str, str2, function0);
        this.mqtt = session;
        this.live = true;
        session.subscribe("/remoteapp/mobile/broadcast/ui_service/state", "/remoteapp/mobile/broadcast/platform_service/actions/volumechange", "/remoteapp/mobile/broadcast/ui_service/volume", "/remoteapp/mobile/broadcast/platform_service/actions/tvsleep");
        Iterator it = ArraysKt.asList(new String[]{"gettvstate", "sourcelist", "applist"}).iterator();
        while (it.hasNext()) {
            session.publish(ui((String) it.next()), "");
        }
        session.publish(platform("getvolume", "actions"), "");
        expect(1500L, new HomeQr$$ExternalSyntheticLambda0(6), new Regex$$ExternalSyntheticLambda0(4, session, this));
    }

    public final String platform(String str, String str2) {
        return "/remoteapp/tv/platform_service/" + this.cid + "/" + str2 + "/" + str;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void pointer(int i, int i2) {
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void pointerClick() {
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void pointerHold(boolean z) {
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void pointerScroll(int i) {
    }

    public final boolean portOpen() {
        try {
            String host = this.host;
            Intrinsics.checkNotNullParameter(host, "host");
            Socket connect = Lan.connect(host, 36669, 2500, new Lan$$ExternalSyntheticLambda0(0));
            connect.setTcpNoDelay(true);
            connect.close();
            return true;
        } catch (Exception unused) {
            return false;
        }
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void pulse(int i, long j) {
        key(i, 3);
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean ready() {
        if (this.live && !this.closed) {
            return true;
        }
        return false;
    }

    public final String refresh(JSONObject jSONObject) {
        String optString = jSONObject.optString("refresh");
        if (optString.length() != 0 && !expired("refresh", jSONObject)) {
            try {
                String optString2 = jSONObject.optString("user");
                Intrinsics.checkNotNullExpressionValue(optString2, "optString(...)");
                MqttLite session = session(optString2, optString, new Census$$ExternalSyntheticLambda4(11));
                try {
                    Pair expect = expect(10000L, new HomeQr$$ExternalSyntheticLambda0(5), new Vidaa$$ExternalSyntheticLambda6(session, this, optString, 0));
                    if (expect != null) {
                        JSONObject access$json = Companion.access$json((String) expect.second);
                        if (access$json != null) {
                            String optString3 = access$json.optString("accesstoken");
                            Intrinsics.checkNotNullExpressionValue(optString3, "optString(...)");
                            if (optString3.length() <= 0) {
                                access$json = null;
                            }
                            if (access$json != null) {
                                String optString4 = access$json.optString("refreshtoken");
                                Intrinsics.checkNotNullExpressionValue(optString4, "optString(...)");
                                if (optString4.length() == 0) {
                                    access$json.put("refreshtoken", optString).put("refreshtoken_time", jSONObject.optLong("refresh_time")).put("refreshtoken_duration_day", jSONObject.optInt("refresh_days", 30));
                                }
                                JSONObject put = fromTokens(access$json).put("profile", "dynamic").put("user", jSONObject.optString("user"));
                                Intrinsics.checkNotNullExpressionValue(put, "put(...)");
                                save(put);
                                WireLog.all.add("←", "VIDAA " + this.host + " renewed its token");
                                String optString5 = access$json.optString("accesstoken");
                                session.close();
                                return optString5;
                            }
                        }
                        return null;
                    }
                    throw new IOException("the TV did not renew its token");
                } finally {
                    session.close();
                }
            } catch (MqttLite.Rejected unused) {
            }
        }
        return null;
    }

    public final void remember(Object obj, String str) {
        JSONObject jSONObject;
        File file = this.tokenFile;
        try {
            if (file.isFile()) {
                jSONObject = new JSONObject(MathKt.readText$default(file));
            } else {
                jSONObject = new JSONObject();
            }
        } catch (Exception unused) {
            jSONObject = new JSONObject();
        }
        if (Intrinsics.areEqual(jSONObject.opt(str), obj)) {
            return;
        }
        this.dir.mkdirs();
        String jSONObject2 = jSONObject.put(str, obj).toString();
        Intrinsics.checkNotNullExpressionValue(jSONObject2, "toString(...)");
        MathKt.writeText$default(file, jSONObject2);
    }

    public final Object remembered(String str) {
        File file = this.tokenFile;
        try {
            if (file.isFile()) {
                return new JSONObject(MathKt.readText$default(file)).opt(str);
            }
            return null;
        } catch (Exception unused) {
            return null;
        }
    }

    public final void save(JSONObject jSONObject) {
        JSONObject jSONObject2;
        File file = this.tokenFile;
        try {
            if (file.isFile()) {
                jSONObject2 = new JSONObject(MathKt.readText$default(file));
            } else {
                jSONObject2 = new JSONObject();
            }
        } catch (Exception unused) {
            jSONObject2 = new JSONObject();
        }
        for (String str : ArraysKt.asList(new String[]{"tls", "static", "mac", "macs"})) {
            if (!jSONObject.has(str) && jSONObject2.has(str)) {
                jSONObject.put(str, jSONObject2.get(str));
            }
        }
        this.dir.mkdirs();
        String jSONObject3 = jSONObject.toString();
        Intrinsics.checkNotNullExpressionValue(jSONObject3, "toString(...)");
        MathKt.writeText$default(file, jSONObject3);
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean screenOff() {
        if (!ready()) {
            return false;
        }
        send("/remoteapp/tv/remote_service/" + this.cid + "/actions/sendkey", "KEY_AUDIO");
        return true;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean search(String q) {
        Intrinsics.checkNotNullParameter(q, "q");
        return false;
    }

    public final void send(String str, String str2) {
        MqttLite mqttLite = this.mqtt;
        if (mqttLite != null && ready()) {
            try {
                this.out.execute(new Vidaa$$ExternalSyntheticLambda3(mqttLite, str, str2, this, 0));
            } catch (RejectedExecutionException unused) {
            }
        }
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    public final MqttLite session(String str, String str2, Function0 function0) {
        boolean z;
        String str3;
        ListBuilder ways = ways();
        final ?? obj = new Object();
        final int i = 0;
        MqttLite login = login(ways, str, str2, function0, new Function1() { // from class: dev.tvremote.core.remote.Vidaa$$ExternalSyntheticLambda11
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj2) {
                Exception it = (Exception) obj2;
                switch (i) {
                    case 0:
                        Intrinsics.checkNotNullParameter(it, "it");
                        obj.element = it;
                        return Unit.INSTANCE;
                    default:
                        Intrinsics.checkNotNullParameter(it, "it");
                        obj.element = it;
                        return Unit.INSTANCE;
                }
            }
        });
        if (login != null) {
            return login;
        }
        if (portOpen()) {
            Companion companion = Companion;
            File file = this.dir;
            synchronized (companion) {
                try {
                    z = false;
                    for (Companion.Public r8 : PUBLIC) {
                        if (Companion.pem(file, r8.name) == null) {
                            Iterator it = r8.at.iterator();
                            while (true) {
                                if (it.hasNext()) {
                                    Pair pair = (Pair) it.next();
                                    String str4 = (String) pair.first;
                                    String str5 = (String) pair.second;
                                    byte[] download = Companion.download(RAW + str4);
                                    if (download != null) {
                                        byte[] download2 = Companion.download(RAW + str5);
                                        if (download2 != null) {
                                            if (Companion.keyManagers(r8.sha256, download, download2) == null) {
                                                WireLog.all.add("·", "VIDAA: " + str4 + " is not the certificate expected");
                                            } else {
                                                file.mkdirs();
                                                MathKt.writeBytes(new File(file, "vidaa-" + r8.name + ".crt"), download);
                                                MathKt.writeBytes(new File(file, "vidaa-" + r8.name + ".key"), download2);
                                                WireLog.all.add("·", "VIDAA: certificate " + r8.name + " downloaded");
                                                z = true;
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
            if (z) {
                List minus = CollectionsKt.minus(ways(), CollectionsKt.toSet(ways));
                final int i2 = 1;
                MqttLite login2 = login(minus, str, str2, function0, new Function1() { // from class: dev.tvremote.core.remote.Vidaa$$ExternalSyntheticLambda11
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj2) {
                        Exception it2 = (Exception) obj2;
                        switch (i2) {
                            case 0:
                                Intrinsics.checkNotNullParameter(it2, "it");
                                obj.element = it2;
                                return Unit.INSTANCE;
                            default:
                                Intrinsics.checkNotNullParameter(it2, "it");
                                obj.element = it2;
                                return Unit.INSTANCE;
                        }
                    }
                });
                if (login2 != null) {
                    return login2;
                }
            }
            ListBuilder ways2 = ways();
            if (ways2 == null || !ways2.isEmpty()) {
                ListIterator listIterator = ways2.listIterator(0);
                while (true) {
                    ListBuilder.Itr itr = (ListBuilder.Itr) listIterator;
                    if (!itr.hasNext()) {
                        break;
                    }
                    String str6 = (String) itr.next();
                    if (!Intrinsics.areEqual(str6, "tls") && !Intrinsics.areEqual(str6, "plain")) {
                        Exception exc = (Exception) obj.element;
                        if (exc == null || (str3 = exc.getMessage()) == null) {
                            str3 = "?";
                        }
                        throw new IOException("cannot reach the TV's remote service: ".concat(str3));
                    }
                }
            }
            throw new IOException("vidaa: the certificate from Hisense's app is needed");
        }
        throw new IOException("the TV did not answer on port 36669");
    }

    @Override // dev.tvremote.core.remote.Remote
    public final boolean setVolume(int i) {
        if (!ready()) {
            return false;
        }
        send(platform("changevolume", "actions"), String.valueOf(MathKt.coerceIn(i, 0, 100)));
        Triple triple = this.volume;
        if (triple == null) {
            triple = new Triple(0, 100, Boolean.FALSE);
        }
        this.volume = Triple.copy$default(triple, Integer.valueOf(MathKt.coerceIn(i, 0, 100)), null, 6);
        return true;
    }

    public final Socket socket(String str) {
        KeyManager[] pem;
        String host = this.host;
        Intrinsics.checkNotNullParameter(host, "host");
        Socket connect = Lan.connect(host, 36669, 4000, new Lan$$ExternalSyntheticLambda0(0));
        connect.setTcpNoDelay(true);
        if (Intrinsics.areEqual(str, "plain")) {
            return connect;
        }
        SSLContext sSLContext = SSLContext.getInstance("TLS");
        boolean areEqual = Intrinsics.areEqual(str, "cert");
        File file = this.dir;
        if (areEqual) {
            pem = Companion.access$cert(file);
        } else if (Intrinsics.areEqual(str, "tls")) {
            pem = null;
        } else {
            pem = Companion.pem(file, str);
        }
        sSLContext.init(pem, new Atv$dial$anyTv$1[]{TRUST_ALL}, new SecureRandom());
        Socket createSocket = sSLContext.getSocketFactory().createSocket(connect, host, 36669, true);
        Intrinsics.checkNotNull(createSocket, "null cannot be cast to non-null type javax.net.ssl.SSLSocket");
        SSLSocket sSLSocket = (SSLSocket) createSocket;
        sSLSocket.setSoTimeout(6000);
        try {
            sSLSocket.startHandshake();
            sSLSocket.setSoTimeout(0);
            return sSLSocket;
        } catch (Exception e) {
            try {
                sSLSocket.close();
            } catch (Exception unused) {
            }
            throw e;
        }
    }

    @Override // dev.tvremote.core.remote.CodePairing
    public final void startPairing() {
        Pair pair;
        List<String> asList;
        String str;
        String m;
        Pair pair2;
        Object obj;
        long j;
        MqttLite session;
        Pair pair3;
        HttpURLConnection httpURLConnection;
        long headerFieldDate;
        int i;
        String str2;
        Integer intOrNull;
        MqttLite mqttLite = this.pairing;
        if (mqttLite != null) {
            mqttLite.close();
        }
        Object obj2 = null;
        this.pairing = null;
        Iterator it = ArraysKt.asList(new Integer[]{38400, 18400}).iterator();
        while (true) {
            if (it.hasNext()) {
                int intValue = ((Number) it.next()).intValue();
                try {
                    Function0 function0 = Lan.wifi;
                    httpURLConnection = (HttpURLConnection) Lan.open(new URL("http://" + this.host + ":" + intValue + "/MediaServer/rendererdevicedesc.xml"));
                    httpURLConnection.setConnectTimeout(1500);
                    httpURLConnection.setReadTimeout(1500);
                    try {
                        InputStream inputStream = httpURLConnection.getInputStream();
                        try {
                            Intrinsics.checkNotNull(inputStream);
                            String str3 = new String(MathKt.readBytes(inputStream), Charsets.UTF_8);
                            inputStream.close();
                            headerFieldDate = httpURLConnection.getHeaderFieldDate("Date", 0L) / 1000;
                            Pattern compile = Pattern.compile("transport_protocol>\\s*(\\d+)");
                            Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                            Matcher matcher = compile.matcher(str3);
                            Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
                            MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, str3);
                            if (access$findNext != null && (str2 = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)) != null && (intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull(str2)) != null) {
                                i = intOrNull.intValue();
                            } else {
                                i = 0;
                            }
                        } finally {
                            try {
                                break;
                            } catch (Throwable th) {
                            }
                        }
                    } catch (Throwable th2) {
                        httpURLConnection.disconnect();
                        throw th2;
                    }
                } catch (Exception unused) {
                }
                if (headerFieldDate > 0) {
                    pair = new Pair(Long.valueOf(headerFieldDate), Integer.valueOf(i));
                    httpURLConnection.disconnect();
                    break;
                }
                httpURLConnection.disconnect();
            } else {
                pair = new Pair(Long.valueOf(System.currentTimeMillis() / 1000), 0);
                break;
            }
        }
        long longValue = ((Number) pair.first).longValue();
        int intValue2 = ((Number) pair.second).intValue();
        if (Intrinsics.areEqual(remembered("static"), Boolean.TRUE)) {
            asList = MathKt.listOf("static");
        } else if (3000 <= intValue2 && intValue2 < 3290) {
            asList = ArraysKt.asList(new String[]{"middle", "modern", "remotenow", "static"});
        } else if (1 <= intValue2 && intValue2 < 3000) {
            asList = ArraysKt.asList(new String[]{"remotenow", "middle", "modern", "static"});
        } else {
            asList = ArraysKt.asList(new String[]{"modern", "middle", "remotenow", "static"});
        }
        IOException e = null;
        for (String profile : asList) {
            if (Intrinsics.areEqual(profile, "static")) {
                pair2 = new Pair("hisenseservice", "multimqttservice");
            } else {
                String mac = this.me;
                Intrinsics.checkNotNullParameter(mac, "mac");
                Intrinsics.checkNotNullParameter(profile, "profile");
                if (profile.equals("modern")) {
                    str = "h!i@s#$v%i^d&a*a";
                } else {
                    str = "h*i&s%e!r^v0i1c9";
                }
                if (profile.equals("remotenow")) {
                    m = ApkSigner$$ExternalSyntheticOutline0.m(longValue, "his$");
                } else {
                    m = ApkSigner$$ExternalSyntheticOutline0.m(longValue ^ 6239759785777146216L, "his$");
                }
                int i2 = 0;
                for (int i3 = 0; i3 < String.valueOf(longValue).length(); i3++) {
                    i2 += r3.charAt(i3) - '0';
                }
                pair2 = new Pair(m, Companion.md5(longValue + "$" + StringsKt.take(Companion.md5("his" + (i2 % 10) + str), 6)));
            }
            String str4 = (String) pair2.first;
            try {
                session = session(str4, (String) pair2.second, new Census$$ExternalSyntheticLambda4(11));
                this.pairing = session;
                this.pairUser = str4;
                this.pairStatic = Intrinsics.areEqual(profile, "static");
                if (Intrinsics.areEqual(profile, "static")) {
                    Bloat$$ExternalSyntheticLambda1 bloat$$ExternalSyntheticLambda1 = new Bloat$$ExternalSyntheticLambda1(29);
                    ArrayBlockingQueue arrayBlockingQueue = new ArrayBlockingQueue(1);
                    Pair pair4 = new Pair(bloat$$ExternalSyntheticLambda1, arrayBlockingQueue);
                    CopyOnWriteArrayList copyOnWriteArrayList = this.waits;
                    copyOnWriteArrayList.add(pair4);
                    try {
                        session.publish(ui("gettvstate"), "");
                        pair3 = (Pair) arrayBlockingQueue.poll(8000L, TimeUnit.MILLISECONDS);
                        copyOnWriteArrayList.remove(pair4);
                        j = longValue;
                    } finally {
                    }
                } else {
                    Iterator it2 = MathKt.until(0, 3).iterator();
                    while (true) {
                        if (((IntProgressionIterator) it2).hasNext) {
                            ((IntProgressionIterator) it2).nextInt();
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = new HomeQr$$ExternalSyntheticLambda0(1);
                            ArrayBlockingQueue arrayBlockingQueue2 = new ArrayBlockingQueue(1);
                            this.waits.add(new Pair(homeQr$$ExternalSyntheticLambda0, arrayBlockingQueue2));
                            try {
                                session.publish(ui("vidaa_app_connect"), "{\"app_version\":2,\"connect_result\":0,\"device_type\":\"Mobile App\"}");
                                j = longValue;
                                Pair pair5 = (Pair) arrayBlockingQueue2.poll(4000L, TimeUnit.MILLISECONDS);
                                if (pair5 != null) {
                                    pair3 = pair5;
                                    break;
                                }
                                longValue = j;
                            } finally {
                            }
                        } else {
                            j = longValue;
                            pair3 = null;
                            break;
                        }
                    }
                }
            } catch (MqttLite.Rejected unused2) {
                obj = obj2;
                j = longValue;
            } catch (IOException e2) {
                e = e2;
                obj = obj2;
                j = longValue;
                if (!portOpen()) {
                    throw e;
                }
            }
            if (pair3 == null) {
                session.close();
                obj = null;
                this.pairing = null;
                e = new IOException("the TV did not show a code");
                obj2 = obj;
                longValue = j;
            } else {
                WireLog.all.add("←", Census$$ExternalSyntheticOutline0.m("VIDAA ", this.host, " shows its code (", profile, ")"));
                return;
            }
        }
        if (e != null) {
            throw e;
        }
        throw new IOException("the TV did not take any kind of login");
    }

    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.Object, java.lang.Iterable] */
    @Override // dev.tvremote.core.remote.Remote
    public final boolean switchInput(String id) {
        Object obj;
        Intrinsics.checkNotNullParameter(id, "id");
        if (ready()) {
            Iterator it = this.sources.iterator();
            while (true) {
                if (it.hasNext()) {
                    obj = it.next();
                    if (Intrinsics.areEqual(((JSONObject) obj).optString("sourceid"), id)) {
                        break;
                    }
                } else {
                    obj = null;
                    break;
                }
            }
            JSONObject jSONObject = (JSONObject) obj;
            if (jSONObject == null) {
                return false;
            }
            String ui = ui("changesource");
            JSONObject m8m = Census$$ExternalSyntheticOutline0.m8m("sourceid", id);
            String optString = jSONObject.optString("sourcename");
            if (optString.length() != 0) {
                id = optString;
            }
            String jSONObject2 = m8m.put("sourcename", id).toString();
            Intrinsics.checkNotNullExpressionValue(jSONObject2, "toString(...)");
            send(ui, jSONObject2);
            return true;
        }
        return false;
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void text(String t) {
        Intrinsics.checkNotNullParameter(t, "t");
        String jSONObject = new JSONObject().put("text", t).put("action", "insert").toString();
        Intrinsics.checkNotNullExpressionValue(jSONObject, "toString(...)");
        send(platform("txtinputdata", "actions"), jSONObject);
        send(platform("bwsinputdata", "actions"), jSONObject);
    }

    @Override // dev.tvremote.core.remote.Remote
    public final void type(String str, int i) {
        Fleet.type(this, i, str);
    }

    public final String ui(String str) {
        return "/remoteapp/tv/ui_service/" + this.cid + "/actions/" + str;
    }

    public final ListBuilder ways() {
        ListBuilder listBuilder = new ListBuilder(10);
        File file = this.dir;
        if (Companion.access$cert(file) != null) {
            listBuilder.add("cert");
        }
        for (Companion.Public r3 : PUBLIC) {
            if (Companion.pem(file, r3.name) != null) {
                listBuilder.add(r3.name);
            }
        }
        listBuilder.add("tls");
        listBuilder.add("plain");
        listBuilder.checkIsMutable$1();
        listBuilder.isReadOnly = true;
        if (listBuilder.length > 0) {
            return listBuilder;
        }
        return ListBuilder.Empty;
    }
}
