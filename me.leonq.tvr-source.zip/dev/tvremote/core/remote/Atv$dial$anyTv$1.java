package dev.tvremote.core.remote;

import java.security.cert.X509Certificate;
import javax.net.ssl.X509TrustManager;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class Atv$dial$anyTv$1 implements X509TrustManager {
    public final /* synthetic */ int $r8$classId;

    @Override // javax.net.ssl.X509TrustManager
    public final void checkClientTrusted(X509Certificate[] c, String a) {
        switch (this.$r8$classId) {
            case 0:
                Intrinsics.checkNotNullParameter(c, "c");
                Intrinsics.checkNotNullParameter(a, "a");
                return;
            case 1:
                Intrinsics.checkNotNullParameter(c, "c");
                Intrinsics.checkNotNullParameter(a, "a");
                return;
            default:
                Intrinsics.checkNotNullParameter(c, "c");
                Intrinsics.checkNotNullParameter(a, "a");
                return;
        }
    }

    @Override // javax.net.ssl.X509TrustManager
    public final void checkServerTrusted(X509Certificate[] c, String a) {
        switch (this.$r8$classId) {
            case 0:
                Intrinsics.checkNotNullParameter(c, "c");
                Intrinsics.checkNotNullParameter(a, "a");
                return;
            case 1:
                Intrinsics.checkNotNullParameter(c, "c");
                Intrinsics.checkNotNullParameter(a, "a");
                return;
            default:
                Intrinsics.checkNotNullParameter(c, "c");
                Intrinsics.checkNotNullParameter(a, "a");
                return;
        }
    }

    @Override // javax.net.ssl.X509TrustManager
    public final X509Certificate[] getAcceptedIssuers() {
        switch (this.$r8$classId) {
            case 0:
                return new X509Certificate[0];
            case 1:
                return new X509Certificate[0];
            default:
                return new X509Certificate[0];
        }
    }
}
