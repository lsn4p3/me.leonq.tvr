package dev.tvremote.core.remote;

import java.io.Closeable;

/* loaded from: classes.dex */
public final /* synthetic */ class Lg$$ExternalSyntheticLambda8 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Closeable f$0;
    public final /* synthetic */ int f$1;

    public /* synthetic */ Lg$$ExternalSyntheticLambda8(Closeable closeable, int i, int i2) {
        this.$r8$classId = i2;
        this.f$0 = closeable;
        this.f$1 = i;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.$r8$classId) {
            case 0:
                ((Lg) this.f$0).tap(this.f$1);
                return;
            case 1:
                ((Lg) this.f$0).tap(this.f$1);
                return;
            default:
                int i = this.f$1;
                WebSocket webSocket = (WebSocket) this.f$0;
                if (webSocket != null) {
                    try {
                        webSocket.send("ready " + i);
                        return;
                    } catch (Exception unused) {
                        return;
                    }
                }
                return;
        }
    }
}
