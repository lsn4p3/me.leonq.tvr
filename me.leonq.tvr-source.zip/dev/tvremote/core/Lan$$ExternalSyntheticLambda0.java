package dev.tvremote.core;

import dev.tvremote.core.adb.AdbPrompt;
import java.io.File;
import java.io.FileInputStream;
import java.net.DatagramSocket;
import java.net.Socket;
import java.util.Arrays;
import java.util.Iterator;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.conscrypt.FileClientSessionCache;
import org.conscrypt.metrics.ConscryptStatsLog;

/* loaded from: classes.dex */
public final /* synthetic */ class Lan$$ExternalSyntheticLambda0 implements Function1 {
    public final /* synthetic */ int $r8$classId;

    public /* synthetic */ Lan$$ExternalSyntheticLambda0(int i) {
        this.$r8$classId = i;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object it) {
        Object obj;
        String str = "";
        Object obj2 = null;
        boolean z = false;
        switch (this.$r8$classId) {
            case 0:
                Intrinsics.checkNotNullParameter((Socket) it, "it");
                return Unit.INSTANCE;
            case 1:
                Intrinsics.checkNotNullParameter((DatagramSocket) it, "it");
                return Unit.INSTANCE;
            case 2:
                Throwable it2 = (Throwable) it;
                Intrinsics.checkNotNullParameter(it2, "it");
                return it2.getCause();
            case 3:
                Throwable it3 = (Throwable) it;
                Intrinsics.checkNotNullParameter(it3, "it");
                String simpleName = it3.getClass().getSimpleName();
                String message = it3.getMessage();
                if (message != null) {
                    str = message;
                }
                return Census$$ExternalSyntheticOutline0.m(simpleName, ": ", str);
            case 4:
                Throwable it4 = (Throwable) it;
                Intrinsics.checkNotNullParameter(it4, "it");
                return it4.getCause();
            case 5:
                Throwable it5 = (Throwable) it;
                Intrinsics.checkNotNullParameter(it5, "it");
                return it5.getCause();
            case 6:
                Integer num = (Integer) it;
                num.intValue();
                return Fleet.T("err.repeat", new Pair("n", num));
            case 7:
                String it6 = (String) it;
                Intrinsics.checkNotNullParameter(it6, "it");
                return StringsKt.trim(it6).toString();
            case 8:
                String it7 = (String) it;
                Intrinsics.checkNotNullParameter(it7, "it");
                if (StringsKt__StringsJVMKt.startsWith(it7, false, "at ") || StringsKt.contains$default(it7, '@')) {
                    z = true;
                }
                return Boolean.valueOf(z);
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                String it8 = (String) it;
                Intrinsics.checkNotNullParameter(it8, "it");
                return Report.LINES.replace(it8, "");
            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                MatcherMatchResult m = (MatcherMatchResult) it;
                Intrinsics.checkNotNullParameter(m, "m");
                if (((CharSequence) ((MatcherMatchResult$groupValues$1) m.getGroupValues()).get(3)).length() > 0) {
                    return ((MatcherMatchResult$groupValues$1) m.getGroupValues()).get(3) + "…";
                }
                return ((MatcherMatchResult$groupValues$1) m.getGroupValues()).get(1) + "…" + ((MatcherMatchResult$groupValues$1) m.getGroupValues()).get(2);
            case 11:
                MatcherMatchResult m2 = (MatcherMatchResult) it;
                Intrinsics.checkNotNullParameter(m2, "m");
                if (Scrub.KEEP.contains(((MatcherMatchResult$groupValues$1) m2.getGroupValues()).get(2))) {
                    return m2.getValue();
                }
                return ((MatcherMatchResult$groupValues$1) m2.getGroupValues()).get(1) + "…(" + ((String) ((MatcherMatchResult$groupValues$1) m2.getGroupValues()).get(2)).length() + ")" + ((MatcherMatchResult$groupValues$1) m2.getGroupValues()).get(3);
            case FileClientSessionCache.MAX_SIZE /* 12 */:
                MatcherMatchResult m3 = (MatcherMatchResult) it;
                Intrinsics.checkNotNullParameter(m3, "m");
                if (((CharSequence) ((MatcherMatchResult$groupValues$1) m3.getGroupValues()).get(1)).length() > 0) {
                    return ((MatcherMatchResult$groupValues$1) m3.getGroupValues()).get(1) + "…" + ((MatcherMatchResult$groupValues$1) m3.getGroupValues()).get(2);
                }
                return "WIFI:…";
            case 13:
                MatcherMatchResult m4 = (MatcherMatchResult) it;
                Intrinsics.checkNotNullParameter(m4, "m");
                return ((MatcherMatchResult$groupValues$1) m4.getGroupValues()).get(1) + "…";
            case 14:
                MatcherMatchResult m5 = (MatcherMatchResult) it;
                Intrinsics.checkNotNullParameter(m5, "m");
                return ((MatcherMatchResult$groupValues$1) m5.getGroupValues()).get(1) + "…";
            case 15:
                MatcherMatchResult m6 = (MatcherMatchResult) it;
                Intrinsics.checkNotNullParameter(m6, "m");
                return ((MatcherMatchResult$groupValues$1) m6.getGroupValues()).get(1) + "~";
            case 16:
                MatcherMatchResult m7 = (MatcherMatchResult) it;
                Intrinsics.checkNotNullParameter(m7, "m");
                return ((MatcherMatchResult$groupValues$1) m7.getGroupValues()).get(1) + "x.x.x.x";
            case 17:
                Byte b = (Byte) it;
                b.byteValue();
                return String.format("%02x", Arrays.copyOf(new Object[]{b}, 1));
            case 18:
                Intrinsics.checkNotNullParameter((String) it, "it");
                return Unit.INSTANCE;
            case 19:
                String name = (String) it;
                Intrinsics.checkNotNullParameter(name, "name");
                Iterator it9 = CollectionsKt__CollectionsKt.listOf((Object[]) new File[]{new File(name), new File("../shared", name)}).iterator();
                while (true) {
                    if (it9.hasNext()) {
                        obj = it9.next();
                        if (((File) obj).isFile()) {
                        }
                    } else {
                        obj = null;
                    }
                }
                File file = (File) obj;
                if (file == null) {
                    return null;
                }
                return new FileInputStream(file);
            case 20:
                Byte b2 = (Byte) it;
                b2.byteValue();
                return String.format("%02X", Arrays.copyOf(new Object[]{b2}, 1));
            case 21:
                Byte b3 = (Byte) it;
                b3.byteValue();
                return String.format("%02x", Arrays.copyOf(new Object[]{b3}, 1));
            case 22:
                MatcherMatchResult it10 = (MatcherMatchResult) it;
                Intrinsics.checkNotNullParameter(it10, "it");
                return Integer.valueOf(Integer.parseInt(it10.getValue()));
            case 23:
                AdbPrompt.Seen it11 = (AdbPrompt.Seen) it;
                Intrinsics.checkNotNullParameter(it11, "it");
                return it11.getCancel();
            case 24:
                AdbPrompt.Seen it12 = (AdbPrompt.Seen) it;
                Intrinsics.checkNotNullParameter(it12, "it");
                return it12.getAlways();
            case 25:
                AdbPrompt.Seen it13 = (AdbPrompt.Seen) it;
                Intrinsics.checkNotNullParameter(it13, "it");
                Iterator it14 = it13.nodes.iterator();
                while (true) {
                    if (it14.hasNext()) {
                        Object next = it14.next();
                        if (((AdbPrompt.Node) next).id.equals("android:id/button1")) {
                            obj2 = next;
                        }
                    }
                }
                return (AdbPrompt.Node) obj2;
            case 26:
                AdbPrompt.Seen it15 = (AdbPrompt.Seen) it;
                Intrinsics.checkNotNullParameter(it15, "it");
                return it15.getCancel();
            case 27:
                Intrinsics.checkNotNullParameter((DatagramSocket) it, "it");
                return Unit.INSTANCE;
            case 28:
                Intrinsics.checkNotNullParameter((DatagramSocket) it, "it");
                return Unit.INSTANCE;
            default:
                Intrinsics.checkNotNullParameter(it, "it");
                return Boolean.valueOf(!it.equals("a11y"));
        }
    }
}
