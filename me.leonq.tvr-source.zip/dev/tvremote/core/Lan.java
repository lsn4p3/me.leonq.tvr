package dev.tvremote.core;

import dev.tvremote.phone.picker.NetKt$reachAroundVpn$2$1;
import java.io.IOException;
import java.net.ConnectException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import kotlin.collections.ArraysKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.StringsKt;

/* loaded from: classes.dex */
public final class Lan {
    public static final Lan$dial$1 dial;
    public static final ConcurrentHashMap viaWifi;
    public static volatile Function0 wifi;

    /* JADX WARN: Type inference failed for: r0v2, types: [kotlin.jvm.internal.FunctionReferenceImpl, dev.tvremote.core.Lan$dial$1] */
    static {
        Object obj = new Object();
        wifi = Lan$wifi$1.INSTANCE;
        viaWifi = new ConcurrentHashMap();
        dial = new FunctionReferenceImpl(5, obj, Lan.class, "socket", "socket(Ljava/lang/String;IILdev/tvremote/core/Lan$Wifi;Lkotlin/jvm/functions/Function1;)Ljava/net/Socket;");
    }

    public static Socket connect(String host, int i, int i2, Function1 function1) {
        InetAddress home;
        boolean z;
        String str;
        Function1 function12;
        NetKt$reachAroundVpn$2$1 netKt$reachAroundVpn$2$1;
        Object invoke;
        Intrinsics.checkNotNullParameter(host, "host");
        NetKt$reachAroundVpn$2$1 netKt$reachAroundVpn$2$12 = (NetKt$reachAroundVpn$2$1) wifi.invoke();
        if (netKt$reachAroundVpn$2$12 == null) {
            home = null;
        } else {
            home = home(host);
        }
        if (netKt$reachAroundVpn$2$12 != null && home != null) {
            Boolean bool = (Boolean) viaWifi.get(host);
            if (bool != null) {
                z = bool.booleanValue();
            } else {
                try {
                    z = netKt$reachAroundVpn$2$12.onLink(home);
                } catch (Exception unused) {
                    z = false;
                }
            }
            IOException iOException = null;
            for (Boolean bool2 : ArraysKt.asList(new Boolean[]{Boolean.valueOf(z), Boolean.valueOf(!z)})) {
                boolean booleanValue = bool2.booleanValue();
                try {
                    Lan$dial$1 lan$dial$1 = dial;
                    Integer valueOf = Integer.valueOf(i);
                    Integer valueOf2 = Integer.valueOf(i2);
                    if (booleanValue) {
                        netKt$reachAroundVpn$2$1 = netKt$reachAroundVpn$2$12;
                    } else {
                        netKt$reachAroundVpn$2$1 = null;
                    }
                    String str2 = host;
                    Function1 function13 = function1;
                    try {
                        invoke = lan$dial$1.invoke(str2, valueOf, valueOf2, netKt$reachAroundVpn$2$1, function13);
                        str = str2;
                        function12 = function13;
                    } catch (IOException e) {
                        e = e;
                        str = str2;
                        function12 = function13;
                    }
                } catch (IOException e2) {
                    e = e2;
                    str = host;
                    function12 = function1;
                }
                try {
                    viaWifi.put(str, bool2);
                    return (Socket) invoke;
                } catch (IOException e3) {
                    e = e3;
                    IOException iOException2 = e;
                    if (iOException == null) {
                        iOException = iOException2;
                    }
                    host = str;
                    function1 = function12;
                }
            }
            String str3 = host;
            if (!netKt$reachAroundVpn$2$12.vpn) {
                Intrinsics.checkNotNull(iOException);
                throw iOException;
            }
            ConnectException connectException = new ConnectException("the home network is out of reach under the VPN (" + str3 + ":" + i + ": " + iOException + ")");
            connectException.initCause(iOException);
            throw connectException;
        }
        return (Socket) dial.invoke(host, Integer.valueOf(i), Integer.valueOf(i2), null, function1);
    }

    public static /* synthetic */ Socket connect$default(String str, int i, int i2) {
        return connect(str, i, i2, new Lan$$ExternalSyntheticLambda0(0));
    }

    public static InetAddress home(String host) {
        Intrinsics.checkNotNullParameter(host, "host");
        String removeSuffix = StringsKt.removeSuffix(StringsKt.removePrefix(host, "["), "]");
        if (!StringsKt.contains$default(removeSuffix, ':')) {
            Pattern compile = Pattern.compile("\\d{1,3}(\\.\\d{1,3}){3}");
            Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
            if (!compile.matcher(removeSuffix).matches()) {
                return null;
            }
        }
        try {
            InetAddress byName = InetAddress.getByName(removeSuffix);
            byte[] address = byName.getAddress();
            if (address.length == 4) {
                int i = address[0] & 255;
                int i2 = address[1] & 255;
                if (i != 10 && ((i != 172 || 16 > i2 || i2 >= 32) && ((i != 192 || i2 != 168) && (i != 169 || i2 != 254)))) {
                    return null;
                }
            } else {
                byte b = address[0];
                if ((b & 254) != 252 && ((b & 255) != 254 || (address[1] & 192) != 128)) {
                    return null;
                }
            }
            return byName;
        } catch (Exception unused) {
            return null;
        }
    }

    public static boolean inSubnet(InetAddress ip, InetAddress inetAddress, int i) {
        Intrinsics.checkNotNullParameter(ip, "ip");
        byte[] address = ip.getAddress();
        byte[] address2 = inetAddress.getAddress();
        if (address.length == address2.length && i >= 0 && i <= address.length * 8) {
            int length = address.length;
            for (int i2 = 0; i2 < length; i2++) {
                int coerceIn = (255 << (8 - MathKt.coerceIn(i - (i2 * 8), 0, 8))) & 255;
                if ((address[i2] & coerceIn) == (coerceIn & address2[i2])) {
                }
            }
            return true;
        }
        return false;
    }

    public static URLConnection open(URL url) {
        InetAddress home;
        boolean z;
        NetKt$reachAroundVpn$2$1 netKt$reachAroundVpn$2$1 = (NetKt$reachAroundVpn$2$1) wifi.invoke();
        if (netKt$reachAroundVpn$2$1 == null) {
            home = null;
        } else {
            String host = url.getHost();
            Intrinsics.checkNotNullExpressionValue(host, "getHost(...)");
            home = home(host);
        }
        if (netKt$reachAroundVpn$2$1 != null && home != null) {
            Boolean bool = (Boolean) viaWifi.get(url.getHost());
            if (bool != null) {
                z = bool.booleanValue();
            } else {
                try {
                    z = netKt$reachAroundVpn$2$1.onLink(home);
                } catch (Exception unused) {
                    z = false;
                }
            }
            if (z) {
                URLConnection openConnection = netKt$reachAroundVpn$2$1.$n.openConnection(url);
                Intrinsics.checkNotNullExpressionValue(openConnection, "openConnection(...)");
                return openConnection;
            }
            URLConnection openConnection2 = url.openConnection();
            Intrinsics.checkNotNullExpressionValue(openConnection2, "openConnection(...)");
            return openConnection2;
        }
        URLConnection openConnection3 = url.openConnection();
        Intrinsics.checkNotNullExpressionValue(openConnection3, "openConnection(...)");
        return openConnection3;
    }
}
