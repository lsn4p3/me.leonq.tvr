package dev.tvremote.core;

import java.util.HashSet;
import kotlin.text.Regex;
import kotlin.text.StringsKt;

/* loaded from: classes.dex */
public final class Report {
    public static final Report INSTANCE = new Object();
    public static final Regex LINES = new Regex("(:\\d+){1,2}(?=\\)|$)");

    /* loaded from: classes.dex */
    public final class Once {
        public final Census$$ExternalSyntheticLambda4 clock;
        public volatile long retryAt;
        public final HashSet sent = new HashSet();

        public Once(Census$$ExternalSyntheticLambda4 census$$ExternalSyntheticLambda4) {
            this.clock = census$$ExternalSyntheticLambda4;
        }
    }

    public static String clean(String str) {
        if (str == null) {
            str = "";
        }
        StringBuilder sb = new StringBuilder();
        int length = str.length();
        for (int i = 0; i < length; i++) {
            char charAt = str.charAt(i);
            if (!Character.isISOControl(charAt)) {
                sb.append(charAt);
            }
        }
        return StringsKt.take(StringsKt.trim(sb.toString()).toString(), 64);
    }
}
