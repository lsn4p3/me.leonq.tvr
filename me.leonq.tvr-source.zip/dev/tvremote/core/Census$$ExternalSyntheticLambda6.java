package dev.tvremote.core;

import dev.tvremote.core.remote.Remote;
import dev.tvremote.core.remote.Roku;
import dev.tvremote.core.scenes.Voice;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda14;
import dev.tvremote.phone.MainActivity$onCreate$2;
import dev.tvremote.phone.picker.AdbHelpKt;
import dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda47;
import dev.tvremote.phone.picker.ManyTvsKt$$ExternalSyntheticLambda6;
import dev.tvremote.phone.ui.Popup;
import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.math.MathKt;

/* loaded from: classes.dex */
public final /* synthetic */ class Census$$ExternalSyntheticLambda6 implements Function0 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;
    public final /* synthetic */ String f$2;
    public final /* synthetic */ Serializable f$3;
    public final /* synthetic */ Object f$4;

    public /* synthetic */ Census$$ExternalSyntheticLambda6(MainActivity mainActivity, String str, Remote remote, String str2) {
        this.$r8$classId = 2;
        this.f$0 = mainActivity;
        this.f$2 = str;
        this.f$4 = remote;
        this.f$3 = str2;
    }

    /* JADX WARN: Type inference failed for: r5v6, types: [java.util.List, java.lang.Object] */
    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        switch (this.$r8$classId) {
            case 0:
                Function1 function1 = (Function1) this.f$0;
                if (function1 != null) {
                    MainActivity$onCreate$2 mainActivity$onCreate$2 = Census.store;
                    function1.invoke(Boolean.valueOf(Census.crashNow("kotlin", this.f$2, (String) this.f$3, (String) this.f$4)));
                }
                return Unit.INSTANCE;
            case 1:
                Roku roku = (Roku) this.f$0;
                String str = this.f$2;
                String str2 = (String) this.f$3;
                String str3 = (String) this.f$4;
                roku.post(str);
                if (str2 == null) {
                    roku.app = str3;
                }
                return Unit.INSTANCE;
            case 2:
                MainActivity mainActivity = (MainActivity) this.f$0;
                Remote remote = (Remote) this.f$4;
                String str4 = (String) this.f$3;
                AdbHelpKt.tvJob(mainActivity, new AdbHelpKt$$ExternalSyntheticLambda47(mainActivity, remote, str4, 1));
                Popup.Builder builder = new Popup.Builder(mainActivity);
                builder.title = this.f$2;
                builder.message = Fleet.T("adb_help.look_at_the_tv", new Pair[0]);
                builder.setPositiveButton(Fleet.T("setup.adb_steps_btn", new Pair[0]), new MainActivity$$ExternalSyntheticLambda14(mainActivity, 4));
                builder.setNeutralButton(Fleet.T("adb_help.open_again", new Pair[0]), new ManyTvsKt$$ExternalSyntheticLambda6(mainActivity, remote, str4, 2));
                builder.setNegativeButton(Fleet.T("setup.choose_another", new Pair[0]), new MainActivity$$ExternalSyntheticLambda14(mainActivity, 5));
                builder.show();
                return Unit.INSTANCE;
            default:
                Voice voice = Voice.INSTANCE;
                MainActivity mainActivity2 = (MainActivity) this.f$0;
                Map map = mainActivity2.appNames;
                ?? r5 = mainActivity2.voicePins;
                LinkedHashMap linkedHashMap = (LinkedHashMap) this.f$3;
                LinkedHashMap linkedHashMap2 = (LinkedHashMap) this.f$4;
                String str5 = this.f$2;
                Voice.Command parse$default = Voice.parse$default(voice, str5, map, linkedHashMap, r5, linkedHashMap2);
                if (parse$default != null) {
                    MathKt.doVoice(mainActivity2, parse$default);
                } else {
                    mainActivity2.ask$android_release(str5);
                }
                return Unit.INSTANCE;
        }
    }

    public /* synthetic */ Census$$ExternalSyntheticLambda6(Object obj, String str, String str2, String str3, int i) {
        this.$r8$classId = i;
        this.f$0 = obj;
        this.f$2 = str;
        this.f$3 = str2;
        this.f$4 = str3;
    }

    public /* synthetic */ Census$$ExternalSyntheticLambda6(String str, MainActivity mainActivity, LinkedHashMap linkedHashMap, LinkedHashMap linkedHashMap2) {
        this.$r8$classId = 3;
        this.f$2 = str;
        this.f$0 = mainActivity;
        this.f$3 = linkedHashMap;
        this.f$4 = linkedHashMap2;
    }
}
