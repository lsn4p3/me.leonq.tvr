package dev.tvremote.core;

import android.graphics.Bitmap;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import dev.tvremote.ConscryptBackend;
import dev.tvremote.core.adb.AdbPrompt;
import dev.tvremote.core.adb.Mdns;
import dev.tvremote.core.adb.PmInstall;
import dev.tvremote.core.adb.Spake2;
import dev.tvremote.core.remote.Vidaa;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.ir.IrState;
import dev.tvremote.phone.picker.AdbHelpKt;
import dev.tvremote.phone.picture.DrawView;
import java.math.BigInteger;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;
import org.conscrypt.Conscrypt;
import org.conscrypt.FileClientSessionCache;
import org.conscrypt.metrics.ConscryptStatsLog;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class Census$$ExternalSyntheticLambda4 implements Function0 {
    public final /* synthetic */ int $r8$classId;

    public /* synthetic */ Census$$ExternalSyntheticLambda4(int i) {
        this.$r8$classId = i;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        switch (this.$r8$classId) {
            case 0:
                return new JSONObject().put("os", System.getProperty("os.name", "") + " " + System.getProperty("os.version", "")).put("arch", System.getProperty("os.arch", "")).put("java", System.getProperty("java.version", ""));
            case 1:
                return Conscrypt.newProvider();
            case 2:
                return Long.valueOf(((Number) Census.clock.invoke()).longValue());
            case 3:
                return new JSONObject().put("brand", Build.BRAND).put("model", Build.MODEL).put("device", Build.DEVICE).put("board", Build.BOARD).put("hw", Build.HARDWARE).put("android", Build.VERSION.RELEASE).put("sdk", Build.VERSION.SDK_INT);
            case 4:
                return Unit.INSTANCE;
            case 5:
                AdbPrompt adbPrompt = AdbPrompt.INSTANCE;
                return Unit.INSTANCE;
            case 6:
                try {
                    Object newInstance = ConscryptBackend.class.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
                    Intrinsics.checkNotNull(newInstance, "null cannot be cast to non-null type dev.tvremote.core.adb.TlsBackend");
                    return (ConscryptBackend) newInstance;
                } catch (Throwable unused) {
                    return null;
                }
            case 7:
                Regex regex = PmInstall.REFUSED;
                return Unit.INSTANCE;
            case 8:
                BigInteger bigInteger = Spake2.P;
                Spake2.Pt access$decode = Mdns.access$decode(Mdns.access$hex("932581b409222652499d92cdece394a3ae5e1cb85cb870ac3030bbe477112ed1"));
                Intrinsics.checkNotNull(access$decode);
                return access$decode;
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                BigInteger bigInteger2 = Spake2.P;
                Spake2.Pt access$decode2 = Mdns.access$decode(Mdns.access$hex("2d803ae3e80adc51cab57648e5becb4bef79f45fd130ca4f497ddb623b76ce84"));
                Intrinsics.checkNotNull(access$decode2);
                return access$decode2;
            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                BigInteger valueOf = BigInteger.valueOf(4L);
                BigInteger valueOf2 = BigInteger.valueOf(5L);
                BigInteger bigInteger3 = Spake2.P;
                BigInteger mod = valueOf.multiply(valueOf2.modInverse(bigInteger3)).mod(bigInteger3);
                BigInteger bigInteger4 = Spake2.P;
                Intrinsics.checkNotNull(mod);
                Spake2.Pt access$decode3 = Mdns.access$decode(Mdns.encodeY(mod, false));
                Intrinsics.checkNotNull(access$decode3);
                return access$decode3;
            case 11:
                Vidaa.Companion companion = Vidaa.Companion;
                return Unit.INSTANCE;
            case FileClientSessionCache.MAX_SIZE /* 12 */:
                ScheduledThreadPoolExecutor scheduledThreadPoolExecutor = new ScheduledThreadPoolExecutor(1, new Diagnose$$ExternalSyntheticLambda1(7));
                scheduledThreadPoolExecutor.setKeepAliveTime(10L, TimeUnit.SECONDS);
                scheduledThreadPoolExecutor.allowCoreThreadTimeOut(true);
                return scheduledThreadPoolExecutor;
            case 13:
                return new Handler(Looper.getMainLooper());
            case 14:
                int i = MainActivity.$r8$clinit;
                return Unit.INSTANCE;
            case 15:
                Object obj = IrState.catalog;
                return Boolean.valueOf(IrState.stop);
            case 16:
                return "adb: not connected";
            case 17:
                return Bitmap.createBitmap(32, 18, Bitmap.Config.ARGB_8888);
            case 18:
                Regex regex2 = AdbHelpKt.TV_HOME;
                return Boolean.FALSE;
            case 19:
                Regex regex3 = AdbHelpKt.TV_HOME;
                return Unit.INSTANCE;
            default:
                int i2 = DrawView.$r8$clinit;
                return Unit.INSTANCE;
        }
    }
}
