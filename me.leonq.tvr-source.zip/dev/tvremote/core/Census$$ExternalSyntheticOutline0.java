package dev.tvremote.core;

import dev.tvremote.phone.WorkService;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.jvm.internal.Intrinsics;
import org.conscrypt.OpenSSLProvider;
import org.json.JSONObject;

/* loaded from: classes.dex */
public abstract /* synthetic */ class Census$$ExternalSyntheticOutline0 {
    public static String m(String str, int i, String str2, int i2) {
        return str + i + str2 + i2;
    }

    public static String m(String str, String str2) {
        return str + str2;
    }

    public static String m(String str, String str2, String str3) {
        return str + str2 + str3;
    }

    public static String m(String str, String str2, String str3, String str4) {
        return str + str2 + str3 + str4;
    }

    public static String m(String str, String str2, String str3, String str4, String str5) {
        return str + str2 + str3 + str4 + str5;
    }

    public static String m(StringBuilder sb, String str, String str2) {
        sb.append(str);
        sb.append(str2);
        return sb.toString();
    }

    public static String m(OpenSSLProvider openSSLProvider, String str, String str2, String str3, String str4) {
        openSSLProvider.put(str, str2);
        return str3 + str4;
    }

    /* renamed from: m, reason: collision with other method in class */
    public static StringBuilder m5m(OpenSSLProvider openSSLProvider, String str, String str2, String str3, String str4) {
        openSSLProvider.put(str, str2);
        openSSLProvider.put(str3, str4);
        return new StringBuilder();
    }

    /* renamed from: m, reason: collision with other method in class */
    public static Matcher m6m(String str, String str2, String str3, String str4) {
        Pattern compile = Pattern.compile(str);
        Intrinsics.checkNotNullExpressionValue(compile, str2);
        Matcher matcher = compile.matcher(str3);
        Intrinsics.checkNotNullExpressionValue(matcher, str4);
        return matcher;
    }

    /* renamed from: m, reason: collision with other method in class */
    public static Matcher m7m(String str, String str2, String str3, String str4, String str5) {
        Pattern compile = Pattern.compile(str);
        Intrinsics.checkNotNullExpressionValue(compile, str2);
        Intrinsics.checkNotNullParameter(str3, str4);
        return compile.matcher(str5);
    }

    /* renamed from: m, reason: collision with other method in class */
    public static JSONObject m8m(String str, String str2) {
        return new JSONObject().put(str, str2);
    }

    /* renamed from: m, reason: collision with other method in class */
    public static JSONObject m9m(String str, String str2, String str3) {
        JSONObject put = new JSONObject().put(str, str2);
        Intrinsics.checkNotNullExpressionValue(put, str3);
        return put;
    }

    /* renamed from: m, reason: collision with other method in class */
    public static JSONObject m10m(String str, String str2, String str3, String str4) {
        return new JSONObject().put(str, str2).put(str3, str4);
    }

    public static void m(StringBuilder sb, String str, String str2, OpenSSLProvider openSSLProvider, String str3) {
        sb.append(str);
        sb.append(str2);
        openSSLProvider.put(str3, sb.toString());
    }

    public static byte[] m(String str, JSONObject jSONObject) {
        String jSONObject2 = jSONObject.toString();
        Intrinsics.checkNotNullExpressionValue(jSONObject2, str);
        return WorkService.Companion.bytes(jSONObject2);
    }
}
