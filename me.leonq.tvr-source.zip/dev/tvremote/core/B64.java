package dev.tvremote.core;

import java.io.ByteArrayOutputStream;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public abstract class B64 {
    public static final int[] INDEX;

    static {
        int[] iArr = new int[128];
        for (int i = 0; i < 128; i++) {
            iArr[i] = -1;
        }
        for (int i2 = 0; i2 < 64; i2++) {
            iArr["ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".charAt(i2)] = i2;
        }
        INDEX = iArr;
    }

    public static byte[] decode(String s) {
        int i;
        Intrinsics.checkNotNullParameter(s, "s");
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream((s.length() * 3) / 4);
        int length = s.length();
        int i2 = 0;
        int i3 = 0;
        for (int i4 = 0; i4 < length; i4++) {
            char charAt = s.charAt(i4);
            if (charAt == '=') {
                break;
            }
            if (charAt != '\t' && charAt != '\n' && charAt != '\r' && charAt != ' ') {
                if (charAt < 128) {
                    i = INDEX[charAt];
                } else {
                    i = -1;
                }
                if (i >= 0) {
                    i2 = (i2 << 6) | i;
                    int i5 = i3 + 6;
                    if (i5 >= 8) {
                        i3 -= 2;
                        byteArrayOutputStream.write((i2 >> i3) & 255);
                    } else {
                        i3 = i5;
                    }
                } else {
                    throw new IllegalArgumentException("bad base64");
                }
            }
        }
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        Intrinsics.checkNotNullExpressionValue(byteArray, "toByteArray(...)");
        return byteArray;
    }

    public static String encode(byte[] b) {
        int i;
        int i2;
        char c;
        Intrinsics.checkNotNullParameter(b, "b");
        StringBuilder sb = new StringBuilder(((b.length + 2) / 3) * 4);
        for (int i3 = 0; i3 < b.length; i3 += 3) {
            int i4 = (b[i3] & 255) << 16;
            int i5 = i3 + 1;
            if (i5 < b.length) {
                i = b[i5] & 255;
            } else {
                i = 0;
            }
            int i6 = i4 | (i << 8);
            int i7 = i3 + 2;
            if (i7 < b.length) {
                i2 = b[i7] & 255;
            } else {
                i2 = 0;
            }
            int i8 = i6 | i2;
            sb.append("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".charAt((i8 >> 18) & 63));
            sb.append("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".charAt((i8 >> 12) & 63));
            char c2 = '=';
            if (i5 < b.length) {
                c = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".charAt((i8 >> 6) & 63);
            } else {
                c = '=';
            }
            sb.append(c);
            if (i7 < b.length) {
                c2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".charAt(i8 & 63);
            }
            sb.append(c2);
        }
        String sb2 = sb.toString();
        Intrinsics.checkNotNullExpressionValue(sb2, "toString(...)");
        return sb2;
    }
}
