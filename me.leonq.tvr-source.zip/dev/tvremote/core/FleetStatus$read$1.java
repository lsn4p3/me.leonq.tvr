package dev.tvremote.core;

import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.FunctionReferenceImpl;

/* loaded from: classes.dex */
public final /* synthetic */ class FleetStatus$read$1 extends FunctionReferenceImpl implements Function0 {
    public static final FleetStatus$read$1 INSTANCE = new FunctionReferenceImpl(0, System.class, "currentTimeMillis", "currentTimeMillis()J");

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        return Long.valueOf(System.currentTimeMillis());
    }
}
