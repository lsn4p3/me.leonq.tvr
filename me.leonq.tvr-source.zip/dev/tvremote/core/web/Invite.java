package dev.tvremote.core.web;

import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.manage.Manage$$ExternalSyntheticLambda18;
import dev.tvremote.core.ontv.Games;
import dev.tvremote.core.ontv.SetupNeed;
import dev.tvremote.core.ontv.Tailscale;
import java.io.IOException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.collections.ArraysKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import org.json.JSONObject;

/* loaded from: classes.dex */
public abstract class Invite {
    public static final List SCOPES = ArraysKt.asList(new String[]{"full", "remote", "view"});

    public static JSONObject link(String lan, String invite, String host) {
        String str;
        Intrinsics.checkNotNullParameter(lan, "lan");
        Intrinsics.checkNotNullParameter(invite, "invite");
        Intrinsics.checkNotNullParameter(host, "host");
        if (lan.length() == 0) {
            lan = host;
        }
        Regex regex = Tailscale.LOGIN;
        if (Games.isAddress(lan)) {
            str = "tailscale_only";
        } else if (Games.isAddress(host)) {
            str = "tailscale";
        } else {
            str = "";
        }
        JSONObject put = new JSONObject().put("url", Census$$ExternalSyntheticOutline0.m("http://", lan, ":8765/#invite=", invite)).put("warn", str);
        Intrinsics.checkNotNullExpressionValue(put, "put(...)");
        return put;
    }

    public static JSONObject share(Manage$$ExternalSyntheticLambda18 manage$$ExternalSyntheticLambda18, String host, String str, boolean z) {
        String str2;
        Intrinsics.checkNotNullParameter(host, "host");
        if (!SCOPES.contains(str)) {
            str = "remote";
        }
        if (z) {
            Pattern compile = Pattern.compile("data=\"([0-9a-f]{32}) ?([0-9.]*)\"");
            Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
            CharSequence input = (CharSequence) manage$$ExternalSyntheticLambda18.invoke("am broadcast --include-stopped-packages -n dev.tvremote.setup/.TrustReceiver --es want invite --es scope " + str + " 2>&1");
            Intrinsics.checkNotNullParameter(input, "input");
            Matcher matcher = compile.matcher(input);
            Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
            MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, input);
            if (access$findNext != null) {
                return link((String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(2), (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1), host);
            }
        }
        String have = SetupNeed.have(manage$$ExternalSyntheticLambda18);
        if (!SetupNeed.ok(have, "invite")) {
            JSONObject jSONObject = new JSONObject();
            if (have.length() == 0) {
                str2 = "missing";
            } else {
                str2 = "old";
            }
            JSONObject put = jSONObject.put("setup", str2).put("have", have).put("min", SetupNeed.MIN.get("invite"));
            Intrinsics.checkNotNullExpressionValue(put, "put(...)");
            return put;
        }
        String str3 = (String) manage$$ExternalSyntheticLambda18.invoke("am broadcast --include-stopped-packages -n dev.tvremote.setup/.TrustReceiver --es want invite --es scope " + str + " 2>&1");
        Matcher m7m = Census$$ExternalSyntheticOutline0.m7m("data=\"([0-9a-f]{32}) ?([0-9.]*)\"", "compile(...)", str3, "input", str3);
        Intrinsics.checkNotNullExpressionValue(m7m, "matcher(...)");
        MatcherMatchResult access$findNext2 = MathKt.access$findNext(m7m, 0, str3);
        if (access$findNext2 != null) {
            manage$$ExternalSyntheticLambda18.invoke("for p in dev.tvremote.setup dev.tvremote.home; do pm path $p >/dev/null 2>&1 || continue; dumpsys deviceidle whitelist +$p >/dev/null 2>&1; am set-standby-bucket $p active >/dev/null 2>&1; cmd appops set $p RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1; done; cmd deviceidle whitelist +dev.tvremote.setup >/dev/null 2>&1; am startservice -n dev.tvremote.setup/.RemoteService 2>&1 | grep -q Error && am start-foreground-service -n dev.tvremote.setup/.RemoteService >/dev/null 2>&1");
            return link((String) ((MatcherMatchResult$groupValues$1) access$findNext2.getGroupValues()).get(2), (String) ((MatcherMatchResult$groupValues$1) access$findNext2.getGroupValues()).get(1), host);
        }
        throw new IOException("TV Setup did not answer");
    }
}
