package dev.tvremote.core.web;

import dev.tvremote.phone.manage.Managing$$ExternalSyntheticLambda4;
import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.zip.GZIPOutputStream;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;

/* loaded from: classes.dex */
public final class WebPage {
    public static final Regex FILE = new Regex("index\\.html|css/[a-z0-9_-]+\\.css|stats\\.js|jmuxer\\.min\\.js|js/[a-z0-9_-]+\\.js|manifest\\.json|remote\\.json|i18n/(?:[a-z]{2,3}|langs)\\.json|icon-[a-z0-9]+\\.png|voice/phrases\\.json");
    public static final Regex GZIP = new Regex("(?i)(^|[\\s,])gzip\\s*(,|;(?!\\s*q=0(\\.0*)?\\s*(,|$))|$)");
    public static final Regex LINK = new Regex("((?:src|href)=\"(?:css/[^\"?]+|stats\\.js|js/[^\"?]+))\"");
    public final HashMap cache;
    public final Managing$$ExternalSyntheticLambda4 open;
    public final String stamp;
    public final HashMap zipped;

    public WebPage(Managing$$ExternalSyntheticLambda4 managing$$ExternalSyntheticLambda4, String stamp) {
        Intrinsics.checkNotNullParameter(stamp, "stamp");
        this.open = managing$$ExternalSyntheticLambda4;
        this.stamp = stamp;
        this.cache = new HashMap();
        this.zipped = new HashMap();
    }

    public static boolean room(HashMap hashMap, int i) {
        if (hashMap.size() < 256) {
            Iterator it = hashMap.values().iterator();
            int i2 = 0;
            while (it.hasNext()) {
                i2 += ((byte[]) it.next()).length;
            }
            if (i2 + i <= 4194304) {
                return true;
            }
        }
        return false;
    }

    public final byte[] gzip(String str, byte[] bArr) {
        byte[] bArr2;
        synchronized (this.zipped) {
            bArr2 = (byte[]) this.zipped.get(str);
            if (bArr2 == null) {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(bArr.length / 3);
                GZIPOutputStream gZIPOutputStream = new GZIPOutputStream(byteArrayOutputStream);
                try {
                    gZIPOutputStream.write(bArr);
                    gZIPOutputStream.close();
                    bArr2 = byteArrayOutputStream.toByteArray();
                    if (bArr2.length >= bArr.length) {
                        bArr2 = null;
                    }
                    if (bArr2 != null && room(this.zipped, bArr2.length)) {
                        this.zipped.put(str, bArr2);
                    }
                } finally {
                }
            }
        }
        return bArr2;
    }
}
