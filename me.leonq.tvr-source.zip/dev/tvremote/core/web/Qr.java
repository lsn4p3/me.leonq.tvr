package dev.tvremote.core.web;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;
import org.conscrypt.metrics.ConscryptStatsLog;

/* loaded from: classes.dex */
public abstract class Qr {
    public static final int[] DATA = {19, 34, 55, 80, 108, 136, ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_AES_128_GCM_SHA256, 194, 232, 274};
    public static final int[] BLOCKS = {1, 1, 1, 1, 1, 2, 2, 2, 2, 4};
    public static final int[] EC = {7, 10, 15, 20, 26, 18, 20, 24, 30, 18};
    public static final int[][] ALIGN = {new int[0], new int[]{6, 18}, new int[]{6, 22}, new int[]{6, 26}, new int[]{6, 30}, new int[]{6, 34}, new int[]{6, 22, 38}, new int[]{6, 24, 42}, new int[]{6, 26, 46}, new int[]{6, 28, 50}};

    public static final boolean modules$bit(int i, int i2) {
        return ((i >>> i2) & 1) == 1;
    }

    public static final void modules$put(ArrayList arrayList, int i, int i2) {
        boolean z;
        for (int i3 = i2 - 1; -1 < i3; i3--) {
            if (((i >>> i3) & 1) == 1) {
                z = true;
            } else {
                z = false;
            }
            arrayList.add(Boolean.valueOf(z));
        }
    }

    public static final void modules$set(int i, boolean[][] zArr, boolean[][] zArr2, int i2, int i3, boolean z) {
        if (i2 >= 0 && i2 < i && i3 >= 0 && i3 < i) {
            zArr[i3][i2] = z;
            zArr2[i3][i2] = true;
        }
    }

    public static final int remainder$mul(int i, int i2) {
        int i3 = 0;
        for (int i4 = 7; -1 < i4; i4--) {
            i3 = (((i3 >>> 7) * 285) ^ (i3 << 1)) ^ (((i2 >>> i4) & 1) * i);
        }
        return i3;
    }

    public static String size(long j) {
        if (j > 1000000000) {
            return String.format(Locale.ROOT, "%.1f GB", Arrays.copyOf(new Object[]{Double.valueOf(j / 1.0E9d)}, 1));
        }
        if (j > 1000000) {
            return String.format(Locale.ROOT, "%.1f MB", Arrays.copyOf(new Object[]{Double.valueOf(j / 1000000.0d)}, 1));
        }
        if (j > 1000) {
            return Math.round(j / 1000.0d) + " KB";
        }
        return j + " B";
    }
}
