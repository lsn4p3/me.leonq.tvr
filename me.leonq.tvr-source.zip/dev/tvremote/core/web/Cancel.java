package dev.tvremote.core.web;

import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import kotlin.jvm.functions.Function0;

/* loaded from: classes.dex */
public final class Cancel {
    public final CopyOnWriteArrayList hooks = new CopyOnWriteArrayList();
    public volatile boolean stopped;

    public final void check() {
        if (!this.stopped) {
        } else {
            throw new Cancelled();
        }
    }

    public final void onStop(Function0 function0) {
        this.hooks.add(function0);
        if (this.stopped) {
            try {
                function0.invoke();
            } catch (Exception unused) {
            }
        }
    }

    public final void stop() {
        this.stopped = true;
        Iterator it = this.hooks.iterator();
        while (it.hasNext()) {
            try {
                ((Function0) it.next()).invoke();
            } catch (Exception unused) {
            }
        }
    }
}
