package dev.tvremote.core.web;

import java.io.IOException;

/* loaded from: classes.dex */
public final class Cancelled extends IOException {
    public Cancelled() {
        super("stopped");
    }
}
