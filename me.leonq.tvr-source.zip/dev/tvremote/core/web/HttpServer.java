package dev.tvremote.core.web;

import dev.tvremote.core.Census$$ExternalSyntheticLambda4;
import dev.tvremote.core.WireLog;
import dev.tvremote.core.ontv.Setup$$ExternalSyntheticLambda5;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda5;
import dev.tvremote.home.HomeQr$$ExternalSyntheticLambda0;
import dev.tvremote.phone.WorkService;
import dev.tvremote.phone.manage.Managing;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.SynchronizedLazyImpl;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class HttpServer {
    public static final AtomicBoolean armed;
    public static final Set live;
    public static final SynchronizedLazyImpl sweeper$delegate;
    public static volatile HomeQr$$ExternalSyntheticLambda0 trusted = new HomeQr$$ExternalSyntheticLambda0(17);
    public final Managing handler;
    public volatile ServerSocket server;
    public final ExecutorService pool = Executors.newCachedThreadPool();
    public final Semaphore slots = new Semaphore(48);
    public final ConcurrentHashMap perPeer = new ConcurrentHashMap();

    /* loaded from: classes.dex */
    public interface Body {
        void write(Stall stall);
    }

    /* loaded from: classes.dex */
    public final class Request {
        public long length;
        public byte[] small;
        public String method = "";
        public String path = "";
        public final HashMap query = new HashMap();
        public final HashMap headers = new HashMap();
        public InputStream body = new ByteArrayInputStream(new byte[0]);
        public final SynchronizedLazyImpl lang$delegate = new SynchronizedLazyImpl(new Setup$$ExternalSyntheticLambda5(5, this));

        public final String cookie(String str) {
            Iterator it = StringsKt.split$default(String.valueOf(this.headers.get("cookie")), new String[]{";"}, 0, 6).iterator();
            while (it.hasNext()) {
                List split$default = StringsKt.split$default(StringsKt.trim((String) it.next()).toString(), new String[]{"="}, 2, 2);
                if (split$default.size() == 2 && Intrinsics.areEqual(split$default.get(0), str)) {
                    return (String) split$default.get(1);
                }
            }
            return "";
        }

        public final String getLang() {
            return (String) this.lang$delegate.getValue();
        }

        public final String getMethod() {
            return this.method;
        }

        /* JADX WARN: Removed duplicated region for block: B:12:? A[RETURN, SYNTHETIC] */
        /* JADX WARN: Removed duplicated region for block: B:9:0x0045  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final JSONObject json(int i) {
            byte[] bArr;
            JSONObject jSONObject = null;
            try {
                bArr = this.small;
            } catch (Exception unused) {
            }
            if (bArr == null) {
                long j = this.length;
                if (j <= i) {
                    int i2 = (int) j;
                    bArr = new byte[i2];
                    long currentTimeMillis = System.currentTimeMillis();
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = HttpServer.trusted;
                    long j2 = currentTimeMillis + 10000;
                    int i3 = 0;
                    while (i3 < i2) {
                        int read = this.body.read(bArr, i3, i2 - i3);
                        if (read < 0) {
                            break;
                        }
                        i3 += read;
                        if (i3 < i2 && System.currentTimeMillis() > j2) {
                            break;
                        }
                    }
                    this.small = bArr;
                }
                if (jSONObject != null) {
                    return new JSONObject();
                }
                return jSONObject;
            }
            jSONObject = new JSONObject(new String(bArr, Charsets.UTF_8));
            if (jSONObject != null) {
            }
        }

        public final String q(String name) {
            Intrinsics.checkNotNullParameter(name, "name");
            String str = (String) this.query.get(name);
            if (str == null) {
                return "";
            }
            return str;
        }
    }

    /* loaded from: classes.dex */
    public final class Response {
        public boolean patient;
        public Body stream;
        public int status = 200;
        public String type = "application/json; charset=utf-8";
        public byte[] body = new byte[0];
        public long length = -1;
        public final HashMap headers = new HashMap();
    }

    static {
        Set newSetFromMap = Collections.newSetFromMap(new ConcurrentHashMap());
        Intrinsics.checkNotNullExpressionValue(newSetFromMap, "newSetFromMap(...)");
        live = newSetFromMap;
        armed = new AtomicBoolean(false);
        sweeper$delegate = new SynchronizedLazyImpl(new Census$$ExternalSyntheticLambda4(12));
    }

    public HttpServer(Managing managing) {
        this.handler = managing;
    }

    public static int start$default(HttpServer httpServer, int i) {
        ServerSocket serverSocket = new ServerSocket();
        Intrinsics.checkNotNullExpressionValue(System.getProperty("os.name", ""), "getProperty(...)");
        serverSocket.setReuseAddress(!StringsKt__StringsJVMKt.startsWith(r1, false, "Windows"));
        serverSocket.bind(new InetSocketAddress(InetAddress.getByAddress(new byte[]{Byte.MAX_VALUE, 0, 0, 1}), i));
        httpServer.server = serverSocket;
        Thread thread = new Thread(new Guard$$ExternalSyntheticLambda5(19, serverSocket, httpServer), "http-accept");
        thread.setDaemon(true);
        thread.start();
        return serverSocket.getLocalPort();
    }

    public final void serve(Socket socket) {
        Request request;
        Response response;
        long j;
        String str;
        InputStream inputStream;
        Left left;
        Set set = live;
        try {
            socket.setSoTimeout(10000);
            InputStream inputStream2 = socket.getInputStream();
            Intrinsics.checkNotNullExpressionValue(inputStream2, "getInputStream(...)");
            Request access$read = WorkService.Companion.access$read(inputStream2);
            if (access$read != null) {
                InetAddress inetAddress = socket.getInetAddress();
                if (inetAddress != null) {
                    inetAddress.getHostAddress();
                }
                request = access$read;
            } else {
                request = null;
            }
            socket.setSoTimeout(30000);
            if (request == null) {
                JSONObject put = new JSONObject().put("error", "bad request");
                Intrinsics.checkNotNullExpressionValue(put, "put(...)");
                response = new Response();
                response.status = 400;
                String jSONObject = put.toString();
                Intrinsics.checkNotNullExpressionValue(jSONObject, "toString(...)");
                response.body = WorkService.Companion.bytes(jSONObject);
            } else {
                try {
                    response = this.handler.handle(request);
                } catch (Exception e) {
                    if ((e instanceof RuntimeException) && !(e instanceof IllegalArgumentException) && !(e instanceof IllegalStateException)) {
                        WireLog wireLog = WireLog.all;
                        StackTraceElement[] stackTrace = ((RuntimeException) e).getStackTrace();
                        Intrinsics.checkNotNullExpressionValue(stackTrace, "getStackTrace(...)");
                        wireLog.add("·", "bug " + e + " at " + CollectionsKt.joinToString$default(ArraysKt.take(stackTrace, 4), " < ", null, null, new HomeQr$$ExternalSyntheticLambda0(18), 30));
                    }
                    String message = e.getMessage();
                    if (message == null) {
                        message = e.getClass().getSimpleName();
                    }
                    JSONObject put2 = new JSONObject().put("error", message);
                    Intrinsics.checkNotNullExpressionValue(put2, "put(...)");
                    response = new Response();
                    response.status = 500;
                    String jSONObject2 = put2.toString();
                    Intrinsics.checkNotNullExpressionValue(jSONObject2, "toString(...)");
                    response.body = WorkService.Companion.bytes(jSONObject2);
                }
            }
            int i = response.status;
            if (i >= 400 && request != null) {
                WireLog.all.add("·", "api " + request.method + " " + request.path + " " + i + " " + new String(CollectionsKt.toByteArray(ArraysKt.take(300, response.body)), Charsets.UTF_8));
            }
            Body body = response.stream;
            if (body == null) {
                j = response.body.length;
            } else {
                j = response.length;
            }
            StringBuilder sb = new StringBuilder("HTTP/1.1 ");
            sb.append(response.status);
            int i2 = response.status;
            if (i2 != 200) {
                if (i2 != 206) {
                    if (i2 != 302) {
                        str = " Error";
                    } else {
                        str = " Found";
                    }
                } else {
                    str = " Partial Content";
                }
            } else {
                str = " OK";
            }
            sb.append(str);
            sb.append("\r\n");
            sb.append("Content-Type: ");
            sb.append(response.type);
            sb.append("\r\nConnection: close\r\nX-Content-Type-Options: nosniff\r\n");
            if (j >= 0) {
                sb.append("Content-Length: ");
                sb.append(j);
                sb.append("\r\n");
            }
            for (Map.Entry entry : response.headers.entrySet()) {
                String str2 = (String) entry.getKey();
                String str3 = (String) entry.getValue();
                sb.append(str2);
                sb.append(": ");
                sb.append(str3);
                sb.append("\r\n");
            }
            Stall stall = new Stall(socket, response.patient);
            try {
                sb.append("\r\n");
                String sb2 = sb.toString();
                Intrinsics.checkNotNullExpressionValue(sb2, "toString(...)");
                stall.write(WorkService.Companion.bytes(sb2));
                if (body != null) {
                    body.write(stall);
                } else {
                    stall.write(response.body);
                }
                stall.flush();
                if (request != null) {
                    try {
                        inputStream = request.body;
                    } catch (IOException unused) {
                    }
                } else {
                    inputStream = null;
                }
                if (inputStream instanceof Left) {
                    left = (Left) inputStream;
                } else {
                    left = null;
                }
                if (left != null) {
                    socket.setSoTimeout(2000);
                    long currentTimeMillis = System.currentTimeMillis() + 30000;
                    byte[] bArr = new byte[65536];
                    while (System.currentTimeMillis() < currentTimeMillis && left.read(bArr, 0, 65536) > 0) {
                    }
                }
                socket.shutdownOutput();
                try {
                    socket.close();
                } catch (Throwable unused2) {
                }
            } finally {
                set.remove(stall);
            }
        } catch (Throwable th) {
            try {
                throw th;
            } catch (Throwable th2) {
                MathKt.closeFinally(socket, th);
                throw th2;
            }
        }
    }

    /* loaded from: classes.dex */
    public final class Left extends InputStream {
        public final InputStream input;
        public long left;

        public Left(InputStream inputStream, long j) {
            this.input = inputStream;
            this.left = j;
        }

        @Override // java.io.InputStream
        public final int available() {
            return (int) Math.min(this.input.available(), this.left);
        }

        @Override // java.io.InputStream
        public final int read() {
            if (this.left <= 0) {
                return -1;
            }
            int read = this.input.read();
            if (read >= 0) {
                this.left--;
                return read;
            }
            this.left = 0L;
            return read;
        }

        @Override // java.io.InputStream
        public final int read(byte[] b, int i, int i2) {
            Intrinsics.checkNotNullParameter(b, "b");
            long j = this.left;
            if (j <= 0) {
                return -1;
            }
            int read = this.input.read(b, i, (int) Math.min(i2, j));
            if (read > 0) {
                this.left -= read;
                return read;
            }
            this.left = 0L;
            return read;
        }
    }

    /* loaded from: classes.dex */
    public final class Stall extends OutputStream {
        public final OutputStream o;
        public final boolean patient;
        public volatile long since;
        public final Socket sock;

        public Stall(Socket socket, boolean z) {
            this.sock = socket;
            this.patient = z;
            this.o = socket.getOutputStream();
            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = HttpServer.trusted;
            HttpServer.live.add(this);
            if (HttpServer.armed.compareAndSet(false, true)) {
                WorkService.Companion.sweep();
            }
        }

        @Override // java.io.OutputStream, java.io.Flushable
        public final void flush() {
            long nanoTime = System.nanoTime();
            if (nanoTime < 1) {
                nanoTime = 1;
            }
            this.since = nanoTime;
            try {
                this.o.flush();
            } finally {
                this.since = 0L;
            }
        }

        @Override // java.io.OutputStream
        public final void write(byte[] b, int i, int i2) {
            Intrinsics.checkNotNullParameter(b, "b");
            int i3 = 0;
            while (i3 < i2) {
                int min = Math.min(16384, i2 - i3);
                long nanoTime = System.nanoTime();
                if (nanoTime < 1) {
                    nanoTime = 1;
                }
                this.since = nanoTime;
                try {
                    this.o.write(b, i + i3, min);
                    this.since = 0L;
                    i3 += min;
                } catch (Throwable th) {
                    this.since = 0L;
                    throw th;
                }
            }
        }

        @Override // java.io.OutputStream
        public final void write(int i) {
            long nanoTime = System.nanoTime();
            if (nanoTime < 1) {
                nanoTime = 1;
            }
            this.since = nanoTime;
            try {
                this.o.write(i);
            } finally {
                this.since = 0L;
            }
        }
    }
}
