package dev.tvremote.core.web;

import kotlin.text.Regex;

/* loaded from: classes.dex */
public final class NoRoom extends IllegalArgumentException {
    public static final Regex CODE = new Regex("storage full: file=(\\d+) free=(\\d+) need=(\\d+) apk=([01])");
    public final boolean apk;
    public final long free;
    public final long need;
    public final long size;

    public NoRoom(long j, long j2, long j3, boolean z) {
        super("storage full: file=" + j + " free=" + j2 + " need=" + j3 + " apk=" + (z ? 1 : 0));
        this.size = j;
        this.free = j2;
        this.need = j3;
        this.apk = z;
    }
}
