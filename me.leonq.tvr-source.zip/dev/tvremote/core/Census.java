package dev.tvremote.core;

import android.media.MediaCodec;
import android.os.HandlerThread;
import com.android.apksig.ApkSignerEngine$InspectJarEntryRequest;
import com.android.apksig.util.DataSink;
import dev.tvremote.core.Report;
import dev.tvremote.phone.MainActivity$onCreate$2;
import dev.tvremote.phone.manage.Managing$$ExternalSyntheticLambda2;
import dev.tvremote.phone.manage.Managing$$ExternalSyntheticLambda4;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.regex.Pattern;
import kotlin.collections.CollectionsKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.sequences.FilteringSequence;
import kotlin.sequences.GeneratorSequence;
import kotlin.sequences.SequencesKt;
import kotlin.text.Regex$$ExternalSyntheticLambda0;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public abstract class Census {
    public static final Set KEYS;
    public static volatile String app = "";
    public static volatile boolean background = false;
    public static volatile Census$clock$1 clock = null;
    public static volatile Function0 device = null;
    public static final Report.Once once;
    public static volatile Census$post$1 post = null;
    public static final HashMap retryAt;
    public static final Object sendLock;
    public static volatile MainActivity$onCreate$2 store = null;
    public static final HashMap tvs;
    public static volatile String url = null;
    public static volatile String version = "";

    /* loaded from: classes.dex */
    public final class Ok implements ApkSignerEngine$InspectJarEntryRequest {
        public final Object adb;
        public Object optimize;
        public Object video;

        public Ok(MediaCodec mediaCodec, HandlerThread handlerThread) {
            this.adb = mediaCodec;
            this.video = handlerThread;
            this.optimize = new LinkedBlockingQueue();
        }

        @Override // com.android.apksig.ApkSignerEngine$InspectJarEntryRequest
        public void done() {
            for (ApkSignerEngine$InspectJarEntryRequest apkSignerEngine$InspectJarEntryRequest : (ApkSignerEngine$InspectJarEntryRequest[]) this.adb) {
                apkSignerEngine$InspectJarEntryRequest.done();
            }
        }

        @Override // com.android.apksig.ApkSignerEngine$InspectJarEntryRequest
        public DataSink getDataSink() {
            SupportAndroid$store$1 supportAndroid$store$1;
            synchronized (this.video) {
                try {
                    if (((SupportAndroid$store$1) this.optimize) == null) {
                        DataSink[] dataSinkArr = new DataSink[2];
                        for (int i = 0; i < 2; i++) {
                            dataSinkArr[i] = ((ApkSignerEngine$InspectJarEntryRequest[]) this.adb)[i].getDataSink();
                        }
                        this.optimize = new SupportAndroid$store$1(5, dataSinkArr);
                    }
                    supportAndroid$store$1 = (SupportAndroid$store$1) this.optimize;
                } catch (Throwable th) {
                    throw th;
                }
            }
            return supportAndroid$store$1;
        }

        public int getMask() {
            int i;
            Boolean bool = Boolean.TRUE;
            boolean areEqual = Intrinsics.areEqual((Boolean) this.adb, bool);
            int i2 = 0;
            if (Intrinsics.areEqual((Boolean) this.video, bool)) {
                i = 2;
            } else {
                i = 0;
            }
            int i3 = (areEqual ? 1 : 0) | i;
            if (Intrinsics.areEqual((Boolean) this.optimize, bool)) {
                i2 = 4;
            }
            return i3 | i2;
        }

        public Ok(Boolean bool, Boolean bool2, Boolean bool3) {
            this.adb = bool;
            this.video = bool2;
            this.optimize = bool3;
        }

        public Ok(Managing$$ExternalSyntheticLambda2 managing$$ExternalSyntheticLambda2, Managing$$ExternalSyntheticLambda4 managing$$ExternalSyntheticLambda4, Census$$ExternalSyntheticLambda4 census$$ExternalSyntheticLambda4, Managing$$ExternalSyntheticLambda2 managing$$ExternalSyntheticLambda22) {
            this.adb = managing$$ExternalSyntheticLambda2;
        }

        public Ok(ApkSignerEngine$InspectJarEntryRequest[] apkSignerEngine$InspectJarEntryRequestArr) {
            this.video = new Object();
            this.adb = apkSignerEngine$InspectJarEntryRequestArr;
        }
    }

    /* loaded from: classes.dex */
    public final class Props {
        public final boolean leanback;
        public final Serializable map;

        public Props(boolean z, String str) {
            this.leanback = z;
            this.map = str;
        }

        public Props(HashMap hashMap, boolean z) {
            this.map = hashMap;
            this.leanback = z;
        }
    }

    /* loaded from: classes.dex */
    public final class State {
        public Boolean adb;
        public Boolean optimize;
        public Props props;
        public Boolean video;
    }

    /* JADX WARN: Code restructure failed: missing block: B:8:0x001a, code lost:
    
        if (r0 == null) goto L11;
     */
    static {
        String str;
        String str2 = System.getenv("TVR_CENSUS_URL");
        if (str2 != null && (str = StringsKt.trim(str2).toString()) != null) {
            if (str.length() <= 0) {
                str = null;
            }
        }
        str = "https://tvr-census.99-hoangtran.workers.dev";
        url = str;
        clock = Census$clock$1.INSTANCE;
        background = true;
        post = new Census$post$1(2, Report.INSTANCE, Report.class, "httpPost", "httpPost(Ljava/lang/String;Ljava/lang/String;)Z", 0);
        KEYS = SetsKt.setOf((Object[]) new String[]{"ro.product.brand", "ro.product.model", "ro.product.device", "ro.product.board", "ro.hardware", "ro.soc.model", "ro.board.platform", "ro.build.version.release", "ro.build.version.sdk"});
        tvs = new HashMap();
        sendLock = new Object();
        retryAt = new HashMap();
        device = new Census$$ExternalSyntheticLambda4(0);
        once = new Report.Once(new Census$$ExternalSyntheticLambda4(2));
    }

    public static void connected(String host, Fleet$$ExternalSyntheticLambda0 fleet$$ExternalSyntheticLambda0) {
        Intrinsics.checkNotNullParameter(host, "host");
        later(new Regex$$ExternalSyntheticLambda0(1, fleet$$ExternalSyntheticLambda0, host));
    }

    public static void crash(String kind, String msg, String stack, Function1 function1) {
        Intrinsics.checkNotNullParameter(kind, "kind");
        Intrinsics.checkNotNullParameter(msg, "msg");
        Intrinsics.checkNotNullParameter(stack, "stack");
        if (!live()) {
            if (function1 != null) {
                function1.invoke(Boolean.FALSE);
                return;
            }
            return;
        }
        later(new Census$$ExternalSyntheticLambda6(function1, kind, msg, stack, 0));
    }

    public static boolean crashNow(String str, String kind, String msg, String stack) {
        JSONObject dev2;
        boolean contains;
        Intrinsics.checkNotNullParameter(kind, "kind");
        Intrinsics.checkNotNullParameter(msg, "msg");
        Intrinsics.checkNotNullParameter(stack, "stack");
        if (!live()) {
            return false;
        }
        Report report = Report.INSTANCE;
        String id = id();
        String str2 = app;
        String str3 = version;
        try {
            dev2 = (JSONObject) device.invoke();
        } catch (Throwable unused) {
            dev2 = new JSONObject();
        }
        Intrinsics.checkNotNullParameter(dev2, "dev");
        String take = StringsKt.take(Scrub.text(kind), 120);
        if (StringsKt.isBlank(take)) {
            take = "Error";
        }
        String text = Scrub.text(msg);
        String replaceAll = Census$$ExternalSyntheticOutline0.m7m("\\s+", "compile(...)", text, "input", text).replaceAll(" ");
        Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
        JSONObject put = Census$$ExternalSyntheticOutline0.m10m("id", id, "app", str2).put("v", Report.clean(str3)).put("where", str).put("dev", dev2).put("kind", take).put("msg", StringsKt.take(StringsKt.trim(replaceAll).toString(), 300)).put("stack", StringsKt.take(StringsKt.trim(Scrub.text(stack)).toString(), 8192));
        Intrinsics.checkNotNullExpressionValue(put, "put(...)");
        Report.Once once2 = once;
        String to = Census$$ExternalSyntheticOutline0.m(StringsKt.trimEnd(url, '/'), "/v1/crash");
        String string = put.getString("kind");
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        String string2 = put.getString("stack");
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        String key = Census$$ExternalSyntheticOutline0.m(string, SequencesKt.joinToString$default(SequencesKt.take(new FilteringSequence(new GeneratorSequence(StringsKt.lineSequence(string2), new Lan$$ExternalSyntheticLambda0(7), 2), true, new Lan$$ExternalSyntheticLambda0(8)), 5), "\n", new Lan$$ExternalSyntheticLambda0(9), 28));
        Census$post$1 post2 = post;
        once2.getClass();
        Intrinsics.checkNotNullParameter(to, "to");
        Intrinsics.checkNotNullParameter(key, "key");
        Intrinsics.checkNotNullParameter(post2, "post");
        synchronized (once2.sent) {
            contains = once2.sent.contains(key);
        }
        if (!contains) {
            if (((Number) once2.clock.invoke()).longValue() >= once2.retryAt) {
                String jSONObject = put.toString();
                Intrinsics.checkNotNullExpressionValue(jSONObject, "toString(...)");
                if (((Boolean) post2.invoke(to, jSONObject)).booleanValue()) {
                    synchronized (once2.sent) {
                        once2.sent.add(key);
                    }
                } else {
                    once2.retryAt = ((Number) once2.clock.invoke()).longValue() + 60000;
                }
            }
            return false;
        }
        return true;
    }

    public static boolean getEnabled() {
        String str;
        MainActivity$onCreate$2 mainActivity$onCreate$2 = store;
        if (mainActivity$onCreate$2 != null) {
            str = mainActivity$onCreate$2.get("census.on");
        } else {
            str = null;
        }
        return !Intrinsics.areEqual(str, "0");
    }

    public static String id() {
        MainActivity$onCreate$2 mainActivity$onCreate$2 = store;
        if (mainActivity$onCreate$2 == null) {
            return "";
        }
        String str = mainActivity$onCreate$2.get("census.id");
        if (str != null) {
            if (str.length() != 36) {
                str = null;
            }
            if (str != null) {
                return str;
            }
        }
        String uuid = UUID.randomUUID().toString();
        Intrinsics.checkNotNullExpressionValue(uuid, "toString(...)");
        mainActivity$onCreate$2.put("census.id", uuid);
        return uuid;
    }

    public static void later(Function0 function0) {
        if (live()) {
            if (!background) {
                try {
                    function0.invoke();
                } catch (Throwable unused) {
                }
            } else {
                Thread thread = new Thread(new Census$$ExternalSyntheticLambda7(function0, 0), "census");
                thread.setDaemon(true);
                thread.start();
            }
        }
    }

    public static boolean live() {
        if (!getEnabled() || app.length() <= 0 || store == null || StringsKt.contains(url, "REPLACE", false)) {
            return false;
        }
        return true;
    }

    public static JSONObject payload(String str, String str2, String str3, Props p, Ok ok) {
        int i;
        String obj;
        Integer intOrNull;
        Intrinsics.checkNotNullParameter(p, "p");
        Report report = Report.INSTANCE;
        HashMap hashMap = (HashMap) p.map;
        JSONObject put = new JSONObject().put("brand", Report.clean((String) hashMap.get("ro.product.brand"))).put("model", Report.clean((String) hashMap.get("ro.product.model"))).put("device", Report.clean((String) hashMap.get("ro.product.device"))).put("board", Report.clean((String) hashMap.get("ro.product.board"))).put("hw", Report.clean((String) hashMap.get("ro.hardware")));
        String clean = Report.clean((String) hashMap.get("ro.soc.model"));
        if (clean.length() == 0) {
            clean = Report.clean((String) hashMap.get("ro.board.platform"));
        }
        JSONObject put2 = put.put("soc", clean).put("android", Report.clean((String) hashMap.get("ro.build.version.release")));
        String str4 = (String) hashMap.get("ro.build.version.sdk");
        if (str4 != null && (obj = StringsKt.trim(str4).toString()) != null && (intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull(obj)) != null) {
            i = intOrNull.intValue();
        } else {
            i = 0;
        }
        JSONObject put3 = Census$$ExternalSyntheticOutline0.m10m("id", str, "app", str2).put("v", Report.clean(str3)).put("tv", put2.put("sdk", i).put("leanback", p.leanback));
        JSONObject jSONObject = new JSONObject();
        Object obj2 = (Boolean) ok.adb;
        if (obj2 == null) {
            obj2 = JSONObject.NULL;
        }
        JSONObject put4 = jSONObject.put("adb", obj2);
        Object obj3 = (Boolean) ok.video;
        if (obj3 == null) {
            obj3 = JSONObject.NULL;
        }
        JSONObject put5 = put4.put("video", obj3);
        Object obj4 = (Boolean) ok.optimize;
        if (obj4 == null) {
            obj4 = JSONObject.NULL;
        }
        JSONObject put6 = put3.put("ok", put5.put("optimize", obj4));
        Intrinsics.checkNotNullExpressionValue(put6, "put(...)");
        return put6;
    }

    /* JADX WARN: Removed duplicated region for block: B:48:0x011f A[DONT_GENERATE] */
    /* JADX WARN: Removed duplicated region for block: B:50:0x0121 A[Catch: all -> 0x0130, TRY_ENTER, TryCatch #0 {all -> 0x0130, blocks: (B:43:0x00d0, B:50:0x0121, B:52:0x012b, B:53:0x0135, B:58:0x0147, B:60:0x0187, B:63:0x01b0, B:65:0x00dd, B:68:0x00ed, B:70:0x00f9, B:72:0x010b), top: B:42:0x00d0 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static void send(String str) {
        State state;
        Props props;
        MainActivity$onCreate$2 mainActivity$onCreate$2;
        int i;
        Integer intOrNull;
        boolean z;
        long j;
        String str2;
        Integer intOrNull2;
        HashMap hashMap = tvs;
        synchronized (hashMap) {
            state = (State) hashMap.get(str);
        }
        if (state != null && (props = state.props) != null) {
            String str3 = (String) ((HashMap) props.map).get("ro.product.model");
            Report report = Report.INSTANCE;
            String clean = Report.clean(str3);
            if (clean.length() == 0 || (mainActivity$onCreate$2 = store) == null) {
                return;
            }
            String str4 = app;
            String lowerCase = clean.toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
            Pattern compile = Pattern.compile("[^a-z0-9]+");
            Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
            String replaceAll = compile.matcher(lowerCase).replaceAll("_");
            Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
            String str5 = "census.sent." + str4 + "." + replaceAll;
            String str6 = mainActivity$onCreate$2.get(str5);
            if (str6 != null && (str2 = (String) CollectionsKt.getOrNull(2, StringsKt.split$default(str6, new char[]{'|'}))) != null && (intOrNull2 = StringsKt__StringNumberConversionsKt.toIntOrNull(str2)) != null) {
                i = intOrNull2.intValue();
            } else {
                i = 0;
            }
            Boolean bool = state.adb;
            Boolean bool2 = null;
            if (bool == null) {
                if ((i & 1) != 0) {
                    bool = Boolean.TRUE;
                } else {
                    bool = null;
                }
            }
            Boolean bool3 = state.video;
            if (bool3 == null) {
                if ((i & 2) != 0) {
                    bool3 = Boolean.TRUE;
                } else {
                    bool3 = null;
                }
            }
            Boolean bool4 = state.optimize;
            if (bool4 == null) {
                if ((i & 4) != 0) {
                    bool2 = Boolean.TRUE;
                }
                bool4 = bool2;
            }
            Ok ok = new Ok(bool, bool3, bool4);
            long longValue = ((Number) clock.invoke()).longValue() / 86400000;
            synchronized (sendLock) {
                try {
                    String str7 = mainActivity$onCreate$2.get(str5);
                    String str8 = version;
                    int mask = ok.getMask();
                    if (str7 != null) {
                        List split$default = StringsKt.split$default(str7, new char[]{'|'});
                        if (split$default.size() == 3 && (intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull((String) split$default.get(2))) != null) {
                            int intValue = intOrNull.intValue();
                            if (Intrinsics.areEqual(split$default.get(0), String.valueOf(longValue)) && Intrinsics.areEqual(split$default.get(1), str8) && ((~intValue) & mask) == 0) {
                                z = false;
                                if (z) {
                                    return;
                                }
                                HashMap hashMap2 = retryAt;
                                Long l = (Long) hashMap2.get(str5);
                                if (l != null) {
                                    j = l.longValue();
                                } else {
                                    j = 0;
                                }
                                if (j > ((Number) clock.invoke()).longValue()) {
                                    return;
                                }
                                Census$post$1 census$post$1 = post;
                                String str9 = StringsKt.trimEnd(url, '/') + "/v1/ping";
                                String jSONObject = payload(id(), app, version, props, ok).toString();
                                Intrinsics.checkNotNullExpressionValue(jSONObject, "toString(...)");
                                if (((Boolean) census$post$1.invoke(str9, jSONObject)).booleanValue()) {
                                    mainActivity$onCreate$2.put(str5, longValue + "|" + version + "|" + ok.getMask());
                                    hashMap2.remove(str5);
                                } else {
                                    hashMap2.put(str5, Long.valueOf(((Number) clock.invoke()).longValue() + 600000));
                                }
                                return;
                            }
                        }
                    }
                    z = true;
                    if (z) {
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
    }
}
