package dev.tvremote.core;

import java.util.Set;
import kotlin.collections.SetsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;

/* loaded from: classes.dex */
public abstract class Scrub {
    public static final Regex SECRET = new Regex("(\"(?:client-key|token)\"\\s*:\\s*\")[^\"]*(\")|([?&]token=)[^&\\s\"]*|(?<=/bot)\\d+:[A-Za-z0-9_-]+");
    public static final Regex TYPED = new Regex("(\"(?:text|Cmd)\"\\s*:\\s*\")([^\"]*)(\")");
    public static final Set KEEP = SetsKt.setOf((Object[]) new String[]{"Click", "Press", "Release"});
    public static final Regex MAC = new Regex("\\b[0-9A-Fa-f]{2}(?:[:-][0-9A-Fa-f]{2}){5}\\b");
    public static final Regex WIFI = new Regex("WIFI:.*?(?<!\\\\);;|(\"pass\"\\s*:\\s*\")(?:[^\"\\\\]|\\\\.)*(\")");
    public static final Regex KEYQ = new Regex("([?&](?:k|key|pass|password|pwd|token)=)[^&\\s\"')]*");
    public static final Regex BEARER = new Regex("(Bearer\\s+)[A-Za-z0-9._~+/=-]+");
    public static final Regex EMAIL = new Regex("[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(?:\\.[A-Za-z0-9-]+)*\\.[A-Za-z]{2,}");
    public static final Regex WINHOME = new Regex("\\b[A-Za-z]:[\\\\/]+Users[\\\\/]+[^\\\\/\\s:*?\"<>|)']+");
    public static final Regex UNIXHOME = new Regex("(^|[^\\w.-])/(?:Users|home)/[^/\\s:)'\"]+");
    public static final Regex IPV4 = new Regex("\\b(?:(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)\\.){3}(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)\\b");
    public static final Regex IPV6 = new Regex("(^|[^\\w:])((?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,6}:(?:[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,5})?|::(?:[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,6})?)(?![\\w:])");

    public static String blank(String text) {
        Intrinsics.checkNotNullParameter(text, "text");
        return WIFI.replace(MAC.replace(TYPED.replace(SECRET.replace(text, new Lan$$ExternalSyntheticLambda0(10)), new Lan$$ExternalSyntheticLambda0(11)), "xx:xx:xx:xx:xx:xx"), new Lan$$ExternalSyntheticLambda0(12));
    }

    public static String text(String s) {
        Intrinsics.checkNotNullParameter(s, "s");
        return IPV6.replace(IPV4.replace(UNIXHOME.replace(WINHOME.replace(EMAIL.replace(BEARER.replace(KEYQ.replace(blank(s), new Lan$$ExternalSyntheticLambda0(13)), new Lan$$ExternalSyntheticLambda0(14)), "email@x"), "~"), new Lan$$ExternalSyntheticLambda0(15)), "x.x.x.x"), new Lan$$ExternalSyntheticLambda0(16));
    }
}
