package dev.tvremote.core.manage;

import dev.tvremote.core.Fleet;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.picker.Part;
import java.io.File;
import java.io.FileInputStream;
import kotlin.Pair;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class FilesApi$$ExternalSyntheticLambda4 implements Function2 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;
    public final /* synthetic */ Object f$1;

    public /* synthetic */ FilesApi$$ExternalSyntheticLambda4(int i, Object obj, Object obj2) {
        this.$r8$classId = i;
        this.f$0 = obj;
        this.f$1 = obj2;
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(Object obj, Object obj2) {
        switch (this.$r8$classId) {
            case 0:
                String title = (String) obj;
                String msg = (String) obj2;
                Intrinsics.checkNotNullParameter(title, "title");
                Intrinsics.checkNotNullParameter(msg, "msg");
                return new JSONObject().put("id", "u" + ((Jobs) ((FilesApi) this.f$0).core.t).nextJob.getAndIncrement()).put("title", title).put("status", "done").put("pct", 100).put("msg", msg).put("kind", StringsKt.substringBefore(title, ' ', title)).put("name", (String) this.f$1);
            default:
                MainActivity mainActivity = (MainActivity) this.f$1;
                AdbLink link = (AdbLink) obj;
                Part p = (Part) obj2;
                Intrinsics.checkNotNullParameter(link, "link");
                Intrinsics.checkNotNullParameter(p, "p");
                File file = (File) this.f$0;
                FileInputStream fileInputStream = new FileInputStream(file);
                try {
                    new Manage(link, null, mainActivity.getCacheDir(), null).install(fileInputStream, file.length(), p.job, p.cancel);
                    fileInputStream.close();
                    return Fleet.T("many_tvs.installed", new Pair[0]);
                } finally {
                }
        }
    }
}
