package dev.tvremote.core.manage;

import java.util.Set;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class Procs$Keep {
    public final Set a11y;
    public final String home;
    public final String keyboard;
    public final Set people;

    public Procs$Keep(String home, String keyboard, Set set, Set set2) {
        Intrinsics.checkNotNullParameter(home, "home");
        Intrinsics.checkNotNullParameter(keyboard, "keyboard");
        this.home = home;
        this.keyboard = keyboard;
        this.people = set;
        this.a11y = set2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Procs$Keep)) {
            return false;
        }
        Procs$Keep procs$Keep = (Procs$Keep) obj;
        return Intrinsics.areEqual(this.home, procs$Keep.home) && Intrinsics.areEqual(this.keyboard, procs$Keep.keyboard) && Intrinsics.areEqual(this.people, procs$Keep.people) && Intrinsics.areEqual(this.a11y, procs$Keep.a11y);
    }

    public final int hashCode() {
        return this.a11y.hashCode() + ((this.people.hashCode() + ((this.keyboard.hashCode() + (this.home.hashCode() * 31)) * 31)) * 31);
    }

    public final String toString() {
        return "Keep(home=" + this.home + ", keyboard=" + this.keyboard + ", people=" + this.people + ", a11y=" + this.a11y + ")";
    }
}
