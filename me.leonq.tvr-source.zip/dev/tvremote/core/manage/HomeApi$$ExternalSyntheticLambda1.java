package dev.tvremote.core.manage;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Fleet$$ExternalSyntheticLambda0;
import dev.tvremote.core.Words$$ExternalSyntheticLambda1;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.adb.Mdns;
import dev.tvremote.core.adb.Pkg;
import dev.tvremote.core.ontv.Checkout;
import dev.tvremote.core.ontv.Games;
import dev.tvremote.core.ontv.Home;
import dev.tvremote.core.ontv.LauncherSwap;
import dev.tvremote.core.ontv.Rescue;
import dev.tvremote.core.ontv.RulesClient;
import dev.tvremote.core.ontv.Setup;
import dev.tvremote.core.ontv.SetupFiles;
import dev.tvremote.core.ontv.SetupNeed;
import dev.tvremote.core.scenes.Scenes;
import dev.tvremote.phone.picker.Part;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.IntProgression;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class HomeApi$$ExternalSyntheticLambda1 implements Function2 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;

    public /* synthetic */ HomeApi$$ExternalSyntheticLambda1(int i, Object obj) {
        this.$r8$classId = i;
        this.f$0 = obj;
    }

    /* JADX WARN: Failed to find 'out' block for switch in B:119:0x02cb. Please report as an issue. */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0104  */
    /* JADX WARN: Removed duplicated region for block: B:15:? A[RETURN, SYNTHETIC] */
    @Override // kotlin.jvm.functions.Function2
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object invoke(Object obj, Object obj2) {
        String str;
        Checkout.Step step;
        int i;
        String str2;
        String str3;
        Object obj3;
        Pair pair;
        int i2;
        Object obj4;
        Throwable th = null;
        int i3 = 0;
        Object obj5 = this.f$0;
        switch (this.$r8$classId) {
            case 0:
                String k = (String) obj;
                Function2 sink = (Function2) obj2;
                Intrinsics.checkNotNullParameter(k, "k");
                Intrinsics.checkNotNullParameter(sink, "sink");
                ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                String mediaPath = Home.mediaPath(k);
                Intrinsics.checkNotNull(mediaPath);
                Adb.Stream exec = ((Adb) obj5).exec(ApkSigner$$ExternalSyntheticOutline0.m("cat ", Mdns.q(mediaPath), " 2>/dev/null"));
                byte[] bArr = new byte[65536];
                while (true) {
                    try {
                        int read = exec.read(0L, bArr, 0, 65536);
                        if (read >= 0) {
                            sink.invoke(bArr, Integer.valueOf(read));
                        } else {
                            exec.close();
                            return Unit.INSTANCE;
                        }
                    } catch (Throwable th2) {
                        exec.close();
                        throw th2;
                    }
                }
            case 1:
                String name = (String) obj;
                int intValue = ((Integer) obj2).intValue();
                Intrinsics.checkNotNullParameter(name, "name");
                Regex regex = SetupFiles.NAME;
                return SetupFiles.read(intValue, "stats/".concat(name), new HealthApi$$ExternalSyntheticLambda0((HealthApi) obj5, 1));
            case 2:
                AdbLink link = (AdbLink) obj;
                Intrinsics.checkNotNullParameter(link, "link");
                Intrinsics.checkNotNullParameter((Part) obj2, "<unused var>");
                Adb adb = link.get();
                ArrayList arrayList = (ArrayList) obj5;
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    String pkg = (String) it.next();
                    Intrinsics.checkNotNullParameter(pkg, "pkg");
                    Regex regex2 = Pkg.RE;
                    if (!Pkg.RE.matches(pkg)) {
                        str = "bad package name";
                    } else {
                        String[] strArr = Setup.GOOGLE;
                        if (Rescue.mustKeep(pkg)) {
                            str = "protected: the TV needs this app";
                        } else {
                            str = null;
                        }
                    }
                    if (str != null) {
                        throw new IOException(str);
                    }
                }
                ConcurrentHashMap concurrentHashMap2 = Adb.ASKING;
                List lines = StringsKt.lines(adb.shell(120000L, "pm list packages 2>/dev/null"));
                ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(lines));
                Iterator it2 = lines.iterator();
                while (it2.hasNext()) {
                    arrayList2.add(StringsKt.trim(StringsKt.removePrefix((String) it2.next(), "package:")).toString());
                }
                Set set = CollectionsKt.toSet(arrayList2);
                ArrayList arrayList3 = new ArrayList();
                Iterator it3 = arrayList.iterator();
                int i4 = 0;
                while (it3.hasNext()) {
                    String str4 = (String) it3.next();
                    if (set.contains(str4)) {
                        try {
                            Fleet.uninstall(adb, str4);
                            i4++;
                        } catch (IOException e) {
                            arrayList3.add(str4 + ": " + e.getMessage());
                        }
                    }
                }
                if (arrayList3.isEmpty()) {
                    return Fleet.T("many_tvs.removed_apps", new Pair("n", Integer.valueOf(i4)));
                }
                throw new IOException(CollectionsKt.joinToString$default(arrayList3, "; ", null, null, null, 62));
            case 3:
                AdbLink link2 = (AdbLink) obj;
                Part p = (Part) obj2;
                Intrinsics.checkNotNullParameter(link2, "link");
                Intrinsics.checkNotNullParameter(p, "p");
                Adb adb2 = link2.get();
                LinkedHashMap linkedHashMap = Checkout.SUGGEST;
                Fleet$$ExternalSyntheticLambda0 fleet$$ExternalSyntheticLambda0 = new Fleet$$ExternalSyntheticLambda0(adb2, 19);
                Words$$ExternalSyntheticLambda1 words$$ExternalSyntheticLambda1 = new Words$$ExternalSyntheticLambda1(14, p);
                Checkout.Config config = (Checkout.Config) obj5;
                List lines2 = StringsKt.lines((CharSequence) fleet$$ExternalSyntheticLambda0.invoke("pm list packages 2>/dev/null"));
                ArrayList arrayList4 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(lines2));
                Iterator it4 = lines2.iterator();
                while (it4.hasNext()) {
                    arrayList4.add(StringsKt.trim(StringsKt.removePrefix((String) it4.next(), "package:")).toString());
                }
                ArrayList arrayList5 = new ArrayList();
                Iterator it5 = arrayList4.iterator();
                while (it5.hasNext()) {
                    Object next = it5.next();
                    if (((String) next).length() > 0) {
                        arrayList5.add(next);
                    }
                }
                Set set2 = CollectionsKt.toSet(arrayList5);
                String have = SetupNeed.have(fleet$$ExternalSyntheticLambda0);
                Regex regex3 = LauncherSwap.PKG;
                String last = Games.last((String) fleet$$ExternalSyntheticLambda0.invoke("p=$(cmd role get-role-holders android.app.role.HOME 2>/dev/null); c=$([ -n \"$p\" ] && cmd package query-activities --brief -a android.intent.action.MAIN -c android.intent.category.HOME 2>/dev/null | grep -m1 \"^ *$p/\"); if [ -n \"$c\" ]; then echo $c; else cmd package resolve-activity --brief -c android.intent.category.HOME -a android.intent.action.MAIN; fi"));
                List list = config.apps;
                if (list == null) {
                    list = Checkout.preselect(set2);
                }
                ArrayList arrayList6 = new ArrayList();
                Iterator it6 = Checkout.clean(list).iterator();
                while (true) {
                    String str5 = "clear";
                    if (it6.hasNext()) {
                        String str6 = (String) it6.next();
                        if (set2.contains(str6)) {
                            arrayList6.add(new Checkout.Step(4, "clear", str6, null));
                        }
                    } else {
                        arrayList6.add(new Checkout.Step(6, "volume", null, null));
                        if (have.length() == 0) {
                            step = new Checkout.Step(2, "web", null, "missing");
                        } else if (!SetupNeed.ok(have, "checkout")) {
                            step = new Checkout.Step(2, "web", null, "old");
                        } else {
                            step = new Checkout.Step(6, "web", null, null);
                        }
                        arrayList6.add(step);
                        arrayList6.add(new Checkout.Step(6, "home", null, null));
                        ArrayList arrayList7 = new ArrayList();
                        ArrayList arrayList8 = new ArrayList();
                        if (arrayList6.isEmpty()) {
                            i = 0;
                        } else {
                            Iterator it7 = arrayList6.iterator();
                            int i5 = 0;
                            while (it7.hasNext()) {
                                Throwable th3 = th;
                                if (!((Checkout.Step) it7.next()).kind.equals("clear") || (i5 = i5 + 1) >= 0) {
                                    th = th3;
                                } else {
                                    CollectionsKt__CollectionsKt.throwCountOverflow();
                                    throw th3;
                                }
                            }
                            i = i5;
                        }
                        Iterator it8 = arrayList6.iterator();
                        String web = "ok";
                        int i6 = 0;
                        int i7 = 0;
                        int i8 = 0;
                        while (true) {
                            boolean hasNext = it8.hasNext();
                            int i9 = i6;
                            int i10 = config.volume;
                            if (hasNext) {
                                Checkout.Config config2 = config;
                                Checkout.Step step2 = (Checkout.Step) it8.next();
                                int i11 = i8;
                                String str7 = step2.kind;
                                switch (str7.hashCode()) {
                                    case -810883302:
                                        str3 = str5;
                                        if (str7.equals("volume")) {
                                            words$$ExternalSyntheticLambda1.invoke("checkout volume");
                                            try {
                                                HashMap hashMap = Scenes.KEYS;
                                                Scenes.volume(fleet$$ExternalSyntheticLambda0, Checkout.index((String) fleet$$ExternalSyntheticLambda0.invoke("cmd media_session volume --stream 3 --get 2>&1"), i10), 3);
                                            } catch (Exception e2) {
                                                throw new IOException(ApkSigner$$ExternalSyntheticOutline0.m("volume: ", e2.getMessage()));
                                            }
                                        }
                                        str5 = str3;
                                        config = config2;
                                        i6 = i9;
                                        i8 = i11;
                                    case 117588:
                                        str3 = str5;
                                        if (str7.equals("web")) {
                                            String str8 = step2.skip;
                                            if (str8.length() <= 0) {
                                                words$$ExternalSyntheticLambda1.invoke("checkout web");
                                                Set set3 = RulesClient.SETUP_KEYS;
                                                JSONObject call = RulesClient.call(fleet$$ExternalSyntheticLambda0, new JSONObject().put("do", "forget_web"));
                                                if (call.has("forgot")) {
                                                    i8 = call.optInt("forgot");
                                                    str5 = str3;
                                                    config = config2;
                                                    i6 = i9;
                                                } else if (Intrinsics.areEqual(call.optString("setup"), "missing")) {
                                                    web = "missing";
                                                } else {
                                                    if (!call.has("setup")) {
                                                        String optString = call.optString("error");
                                                        Intrinsics.checkNotNullExpressionValue(optString, "optString(...)");
                                                        if (!StringsKt.contains(optString, "unknown", false)) {
                                                            str8 = "failed";
                                                        }
                                                    }
                                                    web = "old";
                                                }
                                            }
                                            web = str8;
                                        }
                                        str5 = str3;
                                        config = config2;
                                        i6 = i9;
                                        i8 = i11;
                                    case 3208415:
                                        str3 = str5;
                                        if (str7.equals("home")) {
                                            words$$ExternalSyntheticLambda1.invoke("checkout home");
                                            fleet$$ExternalSyntheticLambda0.invoke("am start -a android.intent.action.MAIN -c android.intent.category.HOME 2>&1");
                                            i6 = 1;
                                            str5 = str3;
                                            config = config2;
                                            i8 = i11;
                                        }
                                        str5 = str3;
                                        config = config2;
                                        i6 = i9;
                                        i8 = i11;
                                    case 94746189:
                                        if (!str7.equals(str5)) {
                                            str3 = str5;
                                        } else {
                                            str3 = str5;
                                            words$$ExternalSyntheticLambda1.invoke("checkout clear " + (arrayList7.size() + i7 + 1) + "/" + i);
                                            String str9 = step2.pkg;
                                            if (StringsKt__StringsJVMKt.startsWith(last, false, str9.concat("/"))) {
                                                arrayList7.add(str9);
                                            } else {
                                                if (StringsKt.contains((String) fleet$$ExternalSyntheticLambda0.invoke("pm clear " + str9 + " 2>&1"), "Success", false)) {
                                                    i7++;
                                                    arrayList8.add(str9);
                                                } else {
                                                    arrayList7.add(str9);
                                                }
                                            }
                                        }
                                        str5 = str3;
                                        config = config2;
                                        i6 = i9;
                                        i8 = i11;
                                    default:
                                        str3 = str5;
                                        i6 = i9;
                                        str5 = str3;
                                        config = config2;
                                        i8 = i11;
                                }
                            } else {
                                int i12 = i8;
                                Intrinsics.checkNotNullParameter(web, "web");
                                int size = arrayList7.size();
                                String str10 = "";
                                if (arrayList8.isEmpty()) {
                                    str2 = "";
                                } else {
                                    str2 = ApkSigner$$ExternalSyntheticOutline0.m(",a=", CollectionsKt.joinToString$default(arrayList8, "+", null, null, null, 62));
                                }
                                if (!arrayList7.isEmpty()) {
                                    if (!arrayList7.isEmpty()) {
                                        Iterator it9 = arrayList7.iterator();
                                        while (it9.hasNext()) {
                                            if (Intrinsics.areEqual((String) it9.next(), "?")) {
                                            }
                                        }
                                    }
                                    str10 = ApkSigner$$ExternalSyntheticOutline0.m(",x=", CollectionsKt.joinToString$default(arrayList7, "+", null, null, null, 62));
                                }
                                return "checkout:c=" + i7 + ",f=" + size + ",v=" + i10 + ",w=" + web + ",n=" + i12 + ",h=" + i9 + str2 + str10;
                            }
                        }
                    }
                }
                break;
            case 4:
                Scenes.Target tv = (Scenes.Target) obj;
                ((Boolean) obj2).getClass();
                Intrinsics.checkNotNullParameter(tv, "tv");
                HashMap hashMap2 = Scenes.KEYS;
                JSONArray optJSONArray = ((JSONObject) obj5).optJSONArray("steps");
                if (optJSONArray == null) {
                    optJSONArray = new JSONArray();
                }
                return Scenes.run$default(optJSONArray, tv);
            case 5:
                CharSequence DelimitedRangesSequence = (CharSequence) obj;
                int intValue2 = ((Integer) obj2).intValue();
                Intrinsics.checkNotNullParameter(DelimitedRangesSequence, "$this$DelimitedRangesSequence");
                int indexOfAny = StringsKt.indexOfAny(DelimitedRangesSequence, (char[]) obj5, intValue2, false);
                if (indexOfAny < 0) {
                    return null;
                }
                return new Pair(Integer.valueOf(indexOfAny), 1);
            default:
                CharSequence DelimitedRangesSequence2 = (CharSequence) obj;
                int intValue3 = ((Integer) obj2).intValue();
                Intrinsics.checkNotNullParameter(DelimitedRangesSequence2, "$this$DelimitedRangesSequence");
                List list2 = (List) obj5;
                if (list2.size() == 1) {
                    int size2 = list2.size();
                    if (size2 != 0) {
                        if (size2 == 1) {
                            String str11 = (String) list2.get(0);
                            int indexOf$default = StringsKt.indexOf$default(DelimitedRangesSequence2, str11, intValue3, false, 4);
                            if (indexOf$default >= 0) {
                                pair = new Pair(Integer.valueOf(indexOf$default), str11);
                                if (pair != null) {
                                    return null;
                                }
                                return new Pair(pair.first, Integer.valueOf(((String) pair.second).length()));
                            }
                            pair = null;
                            if (pair != null) {
                            }
                        } else {
                            throw new IllegalArgumentException("List has more than one element.");
                        }
                    } else {
                        throw new NoSuchElementException("List is empty.");
                    }
                } else {
                    if (intValue3 >= 0) {
                        i3 = intValue3;
                    }
                    IntProgression intProgression = new IntProgression(i3, DelimitedRangesSequence2.length(), 1);
                    boolean z = DelimitedRangesSequence2 instanceof String;
                    int i13 = intProgression.step;
                    int i14 = intProgression.last;
                    if (z) {
                        if ((i13 > 0 && i3 <= i14) || (i13 < 0 && i14 <= i3)) {
                            int i15 = i3;
                            while (true) {
                                Iterator it10 = list2.iterator();
                                while (true) {
                                    if (it10.hasNext()) {
                                        obj4 = it10.next();
                                        String str12 = (String) obj4;
                                        i2 = i15;
                                        if (!StringsKt__StringsJVMKt.regionMatches(str12, 0, (String) DelimitedRangesSequence2, i15, str12.length(), false)) {
                                            i15 = i2;
                                        }
                                    } else {
                                        i2 = i15;
                                        obj4 = null;
                                    }
                                }
                                String str13 = (String) obj4;
                                if (str13 != null) {
                                    pair = new Pair(Integer.valueOf(i2), str13);
                                } else if (i2 != i14) {
                                    i15 = i2 + i13;
                                }
                            }
                        }
                        pair = null;
                        if (pair != null) {
                        }
                    } else {
                        if ((i13 > 0 && i3 <= i14) || (i13 < 0 && i14 <= i3)) {
                            int i16 = i3;
                            while (true) {
                                Iterator it11 = list2.iterator();
                                while (true) {
                                    if (it11.hasNext()) {
                                        obj3 = it11.next();
                                        String str14 = (String) obj3;
                                        if (StringsKt.regionMatchesImpl(str14, 0, DelimitedRangesSequence2, i16, str14.length(), false)) {
                                        }
                                    } else {
                                        obj3 = null;
                                    }
                                }
                                String str15 = (String) obj3;
                                if (str15 != null) {
                                    pair = new Pair(Integer.valueOf(i16), str15);
                                } else if (i16 != i14) {
                                    i16 += i13;
                                }
                            }
                        }
                        pair = null;
                        if (pair != null) {
                        }
                    }
                }
        }
    }
}
