package dev.tvremote.core.manage;

import dev.tvremote.core.Fleet;
import dev.tvremote.core.web.Cancel;
import dev.tvremote.phone.manage.Managing$$ExternalSyntheticLambda4;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import kotlin.collections.CollectionsKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class Jobs {
    public final Map all;
    public final ThreadLocal current;
    public final AtomicInteger nextJob;
    public volatile Managing$$ExternalSyntheticLambda4 onWork;
    public final HashMap onceIds;
    public final ConcurrentHashMap stops;
    public final ConcurrentHashMap working;

    public Jobs() {
        Map synchronizedMap = Collections.synchronizedMap(new LinkedHashMap());
        Intrinsics.checkNotNullExpressionValue(synchronizedMap, "synchronizedMap(...)");
        this.all = synchronizedMap;
        this.nextJob = new AtomicInteger(1);
        this.stops = new ConcurrentHashMap();
        this.current = new ThreadLocal();
        this.working = new ConcurrentHashMap();
        this.onceIds = new HashMap();
    }

    public final JSONObject get(String str) {
        return (JSONObject) this.all.get(str);
    }

    public final ConcurrentHashMap getStops() {
        return this.stops;
    }

    public final JSONObject job(String title, String str, String str2, String str3, Function1 work) {
        JSONObject jSONObject;
        Object obj;
        String str4;
        Intrinsics.checkNotNullParameter(title, "title");
        Intrinsics.checkNotNullParameter(work, "work");
        JSONObject put = new JSONObject().put("id", String.valueOf(this.nextJob.getAndIncrement())).put("title", title).put("status", "running").put("pct", 0).put("msg", "");
        if (str != null) {
            JSONObject put2 = put.put("kind", str);
            if (str2 == null) {
                str2 = "";
            }
            put2.put("name", str2);
        }
        synchronized (this.all) {
            String str5 = null;
            if (str3 != null) {
                String str6 = (String) this.onceIds.get(str3);
                if (str6 != null && (jSONObject = (JSONObject) this.all.get(str6)) != null) {
                    if (!Intrinsics.areEqual(jSONObject.optString("status"), "running")) {
                        jSONObject = null;
                    }
                    if (jSONObject != null) {
                        return Fleet.snapshot(jSONObject);
                    }
                }
            }
            this.all.put(put.getString("id"), put);
            if (str3 != null) {
                this.onceIds.put(str3, put.getString("id"));
            }
            while (this.all.size() > 20) {
                Iterator it = this.all.entrySet().iterator();
                while (true) {
                    if (it.hasNext()) {
                        obj = it.next();
                        if (!Intrinsics.areEqual(((JSONObject) ((Map.Entry) obj).getValue()).optString("status"), "running")) {
                            break;
                        }
                    } else {
                        obj = null;
                        break;
                    }
                }
                Map.Entry entry = (Map.Entry) obj;
                if (entry == null || (str4 = (String) entry.getKey()) == null) {
                    str4 = (String) CollectionsKt.first(this.all.keySet());
                }
                this.all.remove(str4);
            }
            String substringBefore = StringsKt.substringBefore(title, ' ', title);
            if (SetsKt.setOf((Object[]) new String[]{"install", "update", "tailscale"}).contains(substringBefore)) {
                str5 = substringBefore;
            }
            if (str5 == null) {
                str5 = "work";
            }
            Cancel cancel = new Cancel();
            this.stops.put(put.getString("id"), cancel);
            Thread thread = new Thread(new Jobs$$ExternalSyntheticLambda0(this, cancel, str5, put, work, 0), "job");
            thread.setDaemon(true);
            thread.start();
            return Fleet.snapshot(put);
        }
    }

    public final String working() {
        Collection values = this.working.values();
        Intrinsics.checkNotNullExpressionValue(values, "<get-values>(...)");
        Object obj = null;
        if (values instanceof List) {
            List list = (List) values;
            if (!list.isEmpty()) {
                obj = list.get(0);
            }
        } else {
            Iterator it = values.iterator();
            if (it.hasNext()) {
                obj = it.next();
            }
        }
        String str = (String) obj;
        if (str == null) {
            return "";
        }
        return str;
    }
}
