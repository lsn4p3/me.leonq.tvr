package dev.tvremote.core.manage;

import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class Procs$Proc {
    public final String keep;
    public final int mb;
    public final String pkg;
    public final String state;

    public Procs$Proc(int i, String str, String str2, String str3) {
        this.pkg = str;
        this.mb = i;
        this.state = str2;
        this.keep = str3;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Procs$Proc)) {
            return false;
        }
        Procs$Proc procs$Proc = (Procs$Proc) obj;
        return Intrinsics.areEqual(this.pkg, procs$Proc.pkg) && this.mb == procs$Proc.mb && Intrinsics.areEqual(this.state, procs$Proc.state) && Intrinsics.areEqual(this.keep, procs$Proc.keep);
    }

    public final int hashCode() {
        int hashCode = (this.state.hashCode() + (((this.pkg.hashCode() * 31) + this.mb) * 31)) * 31;
        String str = this.keep;
        return hashCode + (str == null ? 0 : str.hashCode());
    }

    public final String toString() {
        return "Proc(pkg=" + this.pkg + ", mb=" + this.mb + ", state=" + this.state + ", keep=" + this.keep + ")";
    }
}
