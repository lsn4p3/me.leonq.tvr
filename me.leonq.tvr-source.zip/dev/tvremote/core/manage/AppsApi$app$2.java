package dev.tvremote.core.manage;

import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final /* synthetic */ class AppsApi$app$2 extends FunctionReferenceImpl implements Function1 {
    public final /* synthetic */ int $r8$classId;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ AppsApi$app$2(int i, Object obj, Class cls, String str, String str2, int i2) {
        super(i, obj, cls, str, str2);
        this.$r8$classId = i2;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        switch (this.$r8$classId) {
            case 0:
                String p0 = (String) obj;
                Intrinsics.checkNotNullParameter(p0, "p0");
                return ((AppsApi) this.receiver).sh(p0);
            case 1:
                String p02 = (String) obj;
                Intrinsics.checkNotNullParameter(p02, "p0");
                return ((AppsApi) this.receiver).sh(p02);
            case 2:
                String p03 = (String) obj;
                Intrinsics.checkNotNullParameter(p03, "p0");
                return ((AppsApi) this.receiver).sh(p03);
            default:
                String p04 = (String) obj;
                Intrinsics.checkNotNullParameter(p04, "p0");
                return ((Manage) this.receiver).sh(p04);
        }
    }
}
