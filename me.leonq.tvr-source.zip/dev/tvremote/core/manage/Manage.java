package dev.tvremote.core.manage;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Diagnose;
import dev.tvremote.core.Downloader;
import dev.tvremote.core.Errors;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.WireLog;
import dev.tvremote.core.Words;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.adb.AdbPrompt;
import dev.tvremote.core.adb.AdbTls;
import dev.tvremote.core.adb.Mdns;
import dev.tvremote.core.adb.TvKeyboard;
import dev.tvremote.core.adb.TvShell;
import dev.tvremote.core.ontv.Dim;
import dev.tvremote.core.ontv.Draw;
import dev.tvremote.core.ontv.Games;
import dev.tvremote.core.ontv.Notify;
import dev.tvremote.core.ontv.NowPlaying;
import dev.tvremote.core.ontv.RemoteLabels;
import dev.tvremote.core.ontv.SetupNeed;
import dev.tvremote.core.ontv.Tailscale;
import dev.tvremote.core.ontv.Video;
import dev.tvremote.core.ontv.Welcome;
import dev.tvremote.core.remote.Inputs;
import dev.tvremote.core.scenes.Scenes;
import dev.tvremote.core.web.Cancel;
import dev.tvremote.core.web.Cancelled;
import dev.tvremote.core.web.HttpServer;
import dev.tvremote.core.web.Invite;
import dev.tvremote.home.HomeQr$$ExternalSyntheticLambda0;
import dev.tvremote.phone.WorkService;
import dev.tvremote.phone.manage.Managing$$ExternalSyntheticLambda2;
import dev.tvremote.update.Ed25519;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.SynchronizedLazyImpl;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Charsets;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class Manage {
    public final SynchronizedLazyImpl apps$delegate;
    public boolean canPair;
    public final SynchronizedLazyImpl copy$delegate;
    public final Ed25519.Pt core;
    public final File dir;
    public final Draw draw;
    public final SynchronizedLazyImpl files$delegate;
    public final SynchronizedLazyImpl healthApi$delegate;
    public final Managing$$ExternalSyntheticLambda2 helper;
    public final Inputs.Cache inputCache;
    public final SynchronizedLazyImpl installs$delegate;
    public final Jobs jobs;
    public final TvKeyboard.Reader kbdReader;
    public final RemoteLabels labels;
    public final SynchronizedLazyImpl launcherApi$delegate;
    public final AdbLink link;
    public final SynchronizedLazyImpl parts$delegate;
    public final NowPlaying playing;
    public final Object promptLock;
    public final SynchronizedLazyImpl setupApi$delegate;
    public final SynchronizedLazyImpl tvAppsApi$delegate;
    public final Video video;

    public Manage(AdbLink link, RemoteLabels remoteLabels, File file, Managing$$ExternalSyntheticLambda2 managing$$ExternalSyntheticLambda2) {
        NowPlaying nowPlaying;
        Intrinsics.checkNotNullParameter(link, "link");
        this.link = link;
        this.labels = remoteLabels;
        this.dir = file;
        this.helper = managing$$ExternalSyntheticLambda2;
        this.promptLock = new Object();
        Ed25519.Pt pt = new Ed25519.Pt(link, remoteLabels, file);
        this.core = pt;
        this.jobs = (Jobs) pt.t;
        this.copy$delegate = new SynchronizedLazyImpl(new Manage$$ExternalSyntheticLambda0(this, 0));
        this.setupApi$delegate = new SynchronizedLazyImpl(new Manage$$ExternalSyntheticLambda0(this, 8));
        this.installs$delegate = new SynchronizedLazyImpl(new Manage$$ExternalSyntheticLambda0(this, 9));
        this.files$delegate = new SynchronizedLazyImpl(new Manage$$ExternalSyntheticLambda0(this, 10));
        this.apps$delegate = new SynchronizedLazyImpl(new Manage$$ExternalSyntheticLambda0(this, 11));
        this.healthApi$delegate = new SynchronizedLazyImpl(new Manage$$ExternalSyntheticLambda0(this, 12));
        this.parts$delegate = new SynchronizedLazyImpl(new Manage$$ExternalSyntheticLambda0(this, 13));
        if (managing$$ExternalSyntheticLambda2 != null) {
            nowPlaying = new NowPlaying(new Manage$$ExternalSyntheticLambda0(this, 14), managing$$ExternalSyntheticLambda2);
        } else {
            nowPlaying = null;
        }
        this.playing = nowPlaying;
        this.kbdReader = new TvKeyboard.Reader();
        this.draw = new Draw(new Manage$$ExternalSyntheticLambda0(this, 1));
        this.video = new Video(new Manage$$ExternalSyntheticLambda0(this, 2));
        this.launcherApi$delegate = new SynchronizedLazyImpl(new Manage$$ExternalSyntheticLambda0(this, 5));
        this.tvAppsApi$delegate = new SynchronizedLazyImpl(new Manage$$ExternalSyntheticLambda0(this, 7));
        this.inputCache = new Inputs.Cache();
    }

    public static final JSONArray discoverPairing$list(Manage manage, List list) {
        JSONArray jSONArray = new JSONArray();
        Iterator it = list.iterator();
        while (it.hasNext()) {
            Mdns.Service service = (Mdns.Service) it.next();
            JSONObject put = new JSONObject().put("ip", service.ip).put("port", service.port);
            AdbTls adbTls = AdbTls.INSTANCE;
            jSONArray.put(put.put("self", AdbTls.same(manage.link.host, service.ip)));
        }
        return jSONArray;
    }

    public final void cast(InputStream inputStream, long j, String name, JSONObject jSONObject, Cancel cancel) {
        Intrinsics.checkNotNullParameter(name, "name");
        FilesApi filesApi = (FilesApi) this.files$delegate.getValue();
        filesApi.getClass();
        String concat = "/sdcard/Download/".concat(TvPaths.safeName$shared_release(name));
        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
        filesApi.sh("mkdir -p " + Mdns.q("/sdcard/Download"));
        filesApi.getCurrent().set(cancel);
        try {
            TvCopy tvCopy = filesApi.copy;
            int i = TvCopy.$r8$clinit;
            tvCopy.push(inputStream, j, concat, jSONObject, 1);
            filesApi.getCurrent().remove();
            JSONObject put = new JSONObject().put("path", concat);
            Intrinsics.checkNotNullExpressionValue(put, "put(...)");
            filesApi.fileOp("open", put);
        } catch (Throwable th) {
            filesApi.getCurrent().remove();
            throw th;
        }
    }

    public final HttpServer.Response discoverPairing() {
        Pair discover$default = AdbTls.discover$default();
        JSONObject put = new JSONObject().put("host", this.link.host).put("pairing", discoverPairing$list(this, (List) discover$default.first)).put("connect", discoverPairing$list(this, (List) discover$default.second));
        Intrinsics.checkNotNullExpressionValue(put, "put(...)");
        HttpServer.Response response = new HttpServer.Response();
        response.status = 200;
        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = HttpServer.trusted;
        response.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put);
        return response;
    }

    public final LauncherApi getLauncherApi() {
        return (LauncherApi) this.launcherApi$delegate.getValue();
    }

    public final List getParts() {
        return (List) this.parts$delegate.getValue();
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Failed to find 'out' block for switch in B:23:0x06ec. Please report as an issue. */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:268:0x0efd A[Catch: IOException -> 0x0066, Missing -> 0x0069, IllegalArgumentException -> 0x006c, Cancelled -> 0x1012, TryCatch #8 {Missing -> 0x0069, Cancelled -> 0x1012, IOException -> 0x0066, IllegalArgumentException -> 0x006c, blocks: (B:8:0x002d, B:9:0x003a, B:11:0x06c1, B:12:0x06c9, B:14:0x06cf, B:22:0x06e5, B:23:0x06ec, B:26:0x06f3, B:29:0x06fc, B:31:0x072a, B:34:0x0733, B:36:0x0762, B:37:0x0764, B:40:0x0790, B:41:0x0791, B:45:0x07c0, B:46:0x07c1, B:47:0x07c2, B:48:0x07c9, B:49:0x07ca, B:52:0x07d4, B:54:0x07ec, B:56:0x07fa, B:58:0x080b, B:64:0x081a, B:67:0x0858, B:68:0x085f, B:69:0x0860, B:71:0x088c, B:74:0x0896, B:76:0x08a8, B:77:0x08c1, B:79:0x08bb, B:80:0x08da, B:83:0x08e4, B:85:0x08ee, B:87:0x0922, B:88:0x0929, B:89:0x092a, B:92:0x0934, B:94:0x0940, B:95:0x0979, B:97:0x0946, B:99:0x0950, B:100:0x09a2, B:101:0x09a9, B:102:0x09aa, B:105:0x09b4, B:107:0x09c8, B:110:0x09d2, B:112:0x0a14, B:115:0x0a1e, B:117:0x0a6c, B:120:0x0a76, B:122:0x0ac2, B:125:0x0acc, B:129:0x0ae4, B:130:0x0aed, B:132:0x0ae9, B:134:0x0b11, B:137:0x0b1b, B:139:0x0b25, B:141:0x0b59, B:142:0x0b60, B:143:0x0b61, B:146:0x0b6b, B:148:0x0ba6, B:151:0x0bb0, B:153:0x0bb8, B:155:0x0bf5, B:156:0x0bfc, B:157:0x0bfd, B:160:0x0c07, B:162:0x0c1c, B:165:0x0c38, B:167:0x0c5b, B:168:0x0c71, B:171:0x0c85, B:175:0x0ca7, B:177:0x0cd0, B:180:0x0cd9, B:181:0x0ce0, B:182:0x0ce1, B:185:0x0cf5, B:188:0x0d17, B:191:0x0d21, B:199:0x0d44, B:211:0x0d5d, B:214:0x0d67, B:216:0x0d8f, B:219:0x0d99, B:222:0x0d9f, B:224:0x0da8, B:226:0x0dd3, B:229:0x0ddd, B:230:0x0de6, B:233:0x0e02, B:234:0x0e03, B:238:0x0e26, B:239:0x0e27, B:240:0x0e28, B:243:0x0e32, B:245:0x0e4a, B:246:0x0e4d, B:248:0x0e76, B:251:0x0e80, B:253:0x0eb2, B:256:0x0ebd, B:260:0x0eca, B:262:0x0ed0, B:264:0x0eda, B:266:0x0edc, B:268:0x0efd, B:269:0x0f01, B:272:0x0f28, B:273:0x0f2f, B:274:0x003f, B:277:0x0049, B:279:0x006f, B:283:0x007b, B:285:0x00b8, B:289:0x00c4, B:291:0x00f8, B:295:0x0104, B:297:0x010d, B:301:0x0119, B:303:0x014d, B:307:0x0159, B:309:0x019e, B:311:0x01bb, B:315:0x01c7, B:317:0x01e8, B:320:0x01f2, B:327:0x0236, B:322:0x020d, B:329:0x0261, B:333:0x026d, B:335:0x028f, B:338:0x0299, B:340:0x029e, B:344:0x02aa, B:346:0x02d8, B:350:0x02e7, B:351:0x02f0, B:353:0x0302, B:354:0x0314, B:356:0x0310, B:357:0x02ec, B:358:0x0330, B:361:0x033a, B:363:0x0345, B:365:0x034d, B:368:0x036f, B:371:0x0379, B:373:0x0392, B:376:0x039c, B:378:0x03aa, B:380:0x03d5, B:382:0x03f2, B:385:0x03fc, B:387:0x0405, B:388:0x0409, B:390:0x0426, B:393:0x0430, B:395:0x047e, B:398:0x0488, B:400:0x048f, B:404:0x049b, B:406:0x049f, B:407:0x04b1, B:409:0x04a4, B:410:0x04cd, B:413:0x04d7, B:415:0x04db, B:417:0x04e0, B:420:0x04ea, B:422:0x050b, B:425:0x0515, B:427:0x0546, B:431:0x0552, B:433:0x055e, B:435:0x0585, B:436:0x058c, B:437:0x058d, B:440:0x0597, B:442:0x05a9, B:446:0x05b5, B:448:0x05e5, B:451:0x05ef, B:453:0x05fd, B:455:0x060b, B:458:0x061f, B:460:0x0628, B:461:0x062d, B:463:0x063b, B:465:0x0641, B:468:0x064f, B:474:0x0671, B:478:0x067c, B:480:0x06ab, B:483:0x06b4, B:485:0x06b9, B:487:0x0f30), top: B:7:0x002d }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final HttpServer.Response handle(HttpServer.Request request) {
        boolean startsWith;
        String message;
        String str;
        String str2;
        AdbPrompt.Node always;
        JSONObject json;
        JSONObject json2;
        JSONObject put;
        String str3;
        String lang;
        JSONObject json3;
        JSONObject json4;
        JSONObject json5;
        JSONObject json6;
        Long longOrNull;
        JSONObject json7;
        JSONObject json8;
        JSONObject json9;
        boolean deny;
        JSONObject json10;
        JSONObject json11;
        Adb.Stream open;
        JSONObject json12;
        JSONObject json13;
        String str4;
        String str5;
        String str6;
        JSONObject json14;
        JSONObject json15;
        String str7;
        String lang2;
        JSONObject job;
        JSONObject json16;
        JSONObject json17;
        JSONObject json18;
        JSONObject json19;
        JSONObject json20;
        JSONObject json21;
        JSONObject op;
        JSONObject json22;
        Integer num;
        JSONObject json23;
        String allow;
        boolean z = true;
        boolean z2 = false;
        Object[] objArr = 0;
        startsWith = StringsKt__StringsJVMKt.startsWith(request.path, false, "/api/");
        AdbPrompt.Seen seen = null;
        String str8 = null;
        JSONObject jSONObject = null;
        if (startsWith) {
            String substring = request.path.substring(5);
            Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
            boolean areEqual = Intrinsics.areEqual(request.getMethod(), "POST");
            try {
                switch (substring.hashCode()) {
                    case -1649697356:
                        if (substring.equals("tvapps/icon")) {
                            return ((TvAppsApi) this.tvAppsApi$delegate.getValue()).icon(request.q("id"));
                        }
                        break;
                    case -1364014459:
                        if (!substring.equals("census")) {
                            break;
                        } else {
                            return Fleet.census(request);
                        }
                    case -1183866391:
                        if (substring.equals("inputs") && !areEqual) {
                            Object obj = Inputs.TYPES;
                            JSONObject json24 = Inputs.json(inputs(Intrinsics.areEqual(request.q("fresh"), "1")));
                            HttpServer.Response response = new HttpServer.Response();
                            response.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = HttpServer.trusted;
                            String jSONObject2 = json24.toString();
                            Intrinsics.checkNotNullExpressionValue(jSONObject2, "toString(...)");
                            response.body = WorkService.Companion.bytes(jSONObject2);
                            return response;
                        }
                        break;
                    case -1163878188:
                        if (!substring.equals("adb/prompt")) {
                            break;
                        } else {
                            if (Intrinsics.areEqual(this.link.state(), "ready")) {
                                AdbPrompt adbPrompt = AdbPrompt.INSTANCE;
                                seen = AdbPrompt.read(this.link.get());
                            }
                            if (seen == null || !Intrinsics.areEqual(seen.fingerprint, this.link.get().fingerprint())) {
                                z = false;
                            }
                            JSONObject jSONObject3 = new JSONObject();
                            if (seen != null) {
                                str = seen.fingerprint;
                            } else {
                                str = "";
                            }
                            JSONObject put2 = jSONObject3.put("fingerprint", str).put("ours", z);
                            if (seen != null && (always = seen.getAlways()) != null) {
                                if (always.getChecked()) {
                                    str2 = "on";
                                } else {
                                    str2 = "off";
                                }
                            } else {
                                str2 = "";
                            }
                            JSONObject put3 = put2.put("always", str2);
                            Intrinsics.checkNotNullExpressionValue(put3, "put(...)");
                            HttpServer.Response response2 = new HttpServer.Response();
                            response2.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda02 = HttpServer.trusted;
                            String jSONObject4 = put3.toString();
                            Intrinsics.checkNotNullExpressionValue(jSONObject4, "toString(...)");
                            response2.body = WorkService.Companion.bytes(jSONObject4);
                            return response2;
                        }
                        break;
                    case -1144745917:
                        if (substring.equals("launcher/play") && areEqual) {
                            LauncherApi launcherApi = getLauncherApi();
                            json = request.json(65536);
                            String optString = json.optString("id");
                            Intrinsics.checkNotNullExpressionValue(optString, "optString(...)");
                            JSONObject play = launcherApi.play(optString);
                            HttpServer.Response response3 = new HttpServer.Response();
                            response3.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda03 = HttpServer.trusted;
                            String jSONObject5 = play.toString();
                            Intrinsics.checkNotNullExpressionValue(jSONObject5, "toString(...)");
                            response3.body = WorkService.Companion.bytes(jSONObject5);
                            return response3;
                        }
                        break;
                    case -1123791193:
                        if (!substring.equals("launcher/thumb")) {
                            break;
                        } else {
                            LauncherApi launcherApi2 = getLauncherApi();
                            String q = request.q("id");
                            launcherApi2.getClass();
                            return LauncherApi.thumb(q);
                        }
                    case -1016251123:
                        if (substring.equals("launcher/answer") && areEqual) {
                            json2 = request.json(65536);
                            if (json2.has("keep")) {
                                JSONObject answer = getLauncherApi().answer(json2.optBoolean("keep"));
                                HttpServer.Response response4 = new HttpServer.Response();
                                response4.status = 200;
                                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda04 = HttpServer.trusted;
                                String jSONObject6 = answer.toString();
                                Intrinsics.checkNotNullExpressionValue(jSONObject6, "toString(...)");
                                response4.body = WorkService.Companion.bytes(jSONObject6);
                                return response4;
                            }
                            throw new IllegalArgumentException("keep missing");
                        }
                        break;
                    case -862009356:
                        if (!substring.equals("tvapps")) {
                            break;
                        } else {
                            JSONObject list = ((TvAppsApi) this.tvAppsApi$delegate.getValue()).list(Intrinsics.areEqual(request.q("fresh"), "1"));
                            HttpServer.Response response5 = new HttpServer.Response();
                            response5.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda05 = HttpServer.trusted;
                            String jSONObject7 = list.toString();
                            Intrinsics.checkNotNullExpressionValue(jSONObject7, "toString(...)");
                            response5.body = WorkService.Companion.bytes(jSONObject7);
                            return response5;
                        }
                    case -675093293:
                        if (!substring.equals("launchers")) {
                            break;
                        } else {
                            JSONObject list2 = getLauncherApi().list();
                            HttpServer.Response response6 = new HttpServer.Response();
                            response6.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda06 = HttpServer.trusted;
                            String jSONObject8 = list2.toString();
                            Intrinsics.checkNotNullExpressionValue(jSONObject8, "toString(...)");
                            response6.body = WorkService.Companion.bytes(jSONObject8);
                            return response6;
                        }
                    case -526671015:
                        if (substring.equals("adb/discover") && this.canPair) {
                            return discoverPairing();
                        }
                        break;
                    case -493563858:
                        if (substring.equals("playing") && !areEqual) {
                            NowPlaying nowPlaying = this.playing;
                            if (nowPlaying != null) {
                                put = nowPlaying.state();
                            } else {
                                put = new JSONObject().put("state", "none");
                            }
                            Intrinsics.checkNotNull(put);
                            HttpServer.Response response7 = new HttpServer.Response();
                            response7.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda07 = HttpServer.trusted;
                            String jSONObject9 = put.toString();
                            Intrinsics.checkNotNullExpressionValue(jSONObject9, "toString(...)");
                            response7.body = WorkService.Companion.bytes(jSONObject9);
                            return response7;
                        }
                        break;
                    case -238481986:
                        if (!substring.equals("diagnose")) {
                            break;
                        } else {
                            return Fleet.diagnose(request, this.link);
                        }
                    case -57604358:
                        if (!substring.equals("tailscale")) {
                            break;
                        } else {
                            Adb adb = this.link.get();
                            Tailscale tailscale = new Tailscale(adb, this.dir);
                            JSONObject jSONObject10 = new JSONObject();
                            ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                            JSONObject put4 = jSONObject10.put("installed", StringsKt.contains(adb.shell(120000L, "pm path com.tailscale.ipn"), "package:", false)).put("ip", tailscale.ip());
                            Intrinsics.checkNotNullExpressionValue(put4, "put(...)");
                            HttpServer.Response response8 = new HttpServer.Response();
                            response8.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda08 = HttpServer.trusted;
                            String jSONObject11 = put4.toString();
                            Intrinsics.checkNotNullExpressionValue(jSONObject11, "toString(...)");
                            response8.body = WorkService.Companion.bytes(jSONObject11);
                            return response8;
                        }
                    case 99464:
                        if (!substring.equals("dim")) {
                            break;
                        } else {
                            LinkedHashMap linkedHashMap = Dim.COLORS;
                            Manage$$ExternalSyntheticLambda18 manage$$ExternalSyntheticLambda18 = new Manage$$ExternalSyntheticLambda18(this, 0);
                            if (areEqual) {
                                jSONObject = request.json(65536);
                            }
                            JSONObject call = Dim.call(manage$$ExternalSyntheticLambda18, jSONObject);
                            HttpServer.Response response9 = new HttpServer.Response();
                            response9.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda09 = HttpServer.trusted;
                            String jSONObject12 = call.toString();
                            Intrinsics.checkNotNullExpressionValue(jSONObject12, "toString(...)");
                            response9.body = WorkService.Companion.bytes(jSONObject12);
                            return response9;
                        }
                    case 105405:
                        if (!substring.equals("job")) {
                            break;
                        } else {
                            JSONObject jSONObject13 = this.jobs.get(request.q("id"));
                            if (jSONObject13 == null) {
                                JSONObject put5 = new JSONObject().put("error", "no such job");
                                Intrinsics.checkNotNullExpressionValue(put5, "put(...)");
                                HttpServer.Response response10 = new HttpServer.Response();
                                response10.status = 404;
                                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda010 = HttpServer.trusted;
                                String jSONObject14 = put5.toString();
                                Intrinsics.checkNotNullExpressionValue(jSONObject14, "toString(...)");
                                response10.body = WorkService.Companion.bytes(jSONObject14);
                                return response10;
                            }
                            JSONObject snapshot = Fleet.snapshot(jSONObject13);
                            HttpServer.Response response11 = new HttpServer.Response();
                            response11.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda011 = HttpServer.trusted;
                            String jSONObject15 = snapshot.toString();
                            Intrinsics.checkNotNullExpressionValue(jSONObject15, "toString(...)");
                            response11.body = WorkService.Companion.bytes(jSONObject15);
                            return response11;
                        }
                    case 107332:
                        if (!substring.equals("log")) {
                            break;
                        } else {
                            TvShell tvShell = TvShell.INSTANCE;
                            return this.core.text(20000L, TvShell.log(request.q("pkg"), request.q("since")));
                        }
                    case 3046113:
                        if (!substring.equals("caps")) {
                            break;
                        } else {
                            JSONObject jSONObject16 = new JSONObject();
                            RemoteLabels remoteLabels = this.labels;
                            if (remoteLabels == null || (str3 = remoteLabels.caps()) == null) {
                                str3 = "";
                            }
                            JSONObject put6 = jSONObject16.put("text", str3);
                            Intrinsics.checkNotNullExpressionValue(put6, "put(...)");
                            HttpServer.Response response12 = new HttpServer.Response();
                            response12.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda012 = HttpServer.trusted;
                            String jSONObject17 = put6.toString();
                            Intrinsics.checkNotNullExpressionValue(jSONObject17, "toString(...)");
                            response12.body = WorkService.Companion.bytes(jSONObject17);
                            return response12;
                        }
                        break;
                    case 27477740:
                        if (!substring.equals("diagnose/setup")) {
                            break;
                        } else {
                            if (areEqual) {
                                sh("settings put secure user_setup_complete 1");
                                JSONObject put7 = new JSONObject().put("ok", true);
                                Intrinsics.checkNotNullExpressionValue(put7, "put(...)");
                                HttpServer.Response response13 = new HttpServer.Response();
                                response13.status = 200;
                                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda013 = HttpServer.trusted;
                                String jSONObject18 = put7.toString();
                                Intrinsics.checkNotNullExpressionValue(jSONObject18, "toString(...)");
                                response13.body = WorkService.Companion.bytes(jSONObject18);
                                return response13;
                            }
                            String q2 = request.q("lang");
                            if (q2.length() > 0) {
                                str8 = q2;
                            }
                            if (str8 != null) {
                                lang = Words.pick(str8);
                            } else {
                                lang = request.getLang();
                            }
                            Regex regex = Diagnose.OTHER_BRANDS;
                            Diagnose.Result upVar = Diagnose.setup(sh("getprop ro.product.manufacturer; settings get secure user_setup_complete"), this.link.host, lang);
                            if (upVar == null) {
                                json3 = new JSONObject().put("code", "ok");
                            } else {
                                json3 = Diagnose.json(upVar, lang);
                            }
                            Intrinsics.checkNotNull(json3);
                            HttpServer.Response response14 = new HttpServer.Response();
                            response14.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda014 = HttpServer.trusted;
                            String jSONObject19 = json3.toString();
                            Intrinsics.checkNotNullExpressionValue(jSONObject19, "toString(...)");
                            response14.body = WorkService.Companion.bytes(jSONObject19);
                            return response14;
                        }
                    case 94921639:
                        if (!substring.equals("crash")) {
                            break;
                        } else {
                            return Fleet.crash(request);
                        }
                    case 109641799:
                        if (substring.equals("speed") && !areEqual) {
                            JSONObject read = Games.read(new Manage$$ExternalSyntheticLambda18(this, 1));
                            HttpServer.Response response15 = new HttpServer.Response();
                            response15.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda015 = HttpServer.trusted;
                            String jSONObject20 = read.toString();
                            Intrinsics.checkNotNullExpressionValue(jSONObject20, "toString(...)");
                            response15.body = WorkService.Companion.bytes(jSONObject20);
                            return response15;
                        }
                        break;
                    case 110749739:
                        if (!substring.equals("tvkbd")) {
                            break;
                        } else {
                            if (Intrinsics.areEqual(this.link.state(), "ready")) {
                                try {
                                    z2 = this.kbdReader.ask(new Manage$$ExternalSyntheticLambda18(this, 2));
                                } catch (Exception unused) {
                                    JSONObject put8 = new JSONObject().put("error", "no answer");
                                    Intrinsics.checkNotNullExpressionValue(put8, "put(...)");
                                    HttpServer.Response response16 = new HttpServer.Response();
                                    response16.status = 503;
                                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda016 = HttpServer.trusted;
                                    String jSONObject21 = put8.toString();
                                    Intrinsics.checkNotNullExpressionValue(jSONObject21, "toString(...)");
                                    response16.body = WorkService.Companion.bytes(jSONObject21);
                                    return response16;
                                }
                            }
                            JSONObject put9 = new JSONObject().put("shown", z2);
                            Intrinsics.checkNotNullExpressionValue(put9, "put(...)");
                            HttpServer.Response response17 = new HttpServer.Response();
                            response17.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda017 = HttpServer.trusted;
                            String jSONObject22 = put9.toString();
                            Intrinsics.checkNotNullExpressionValue(jSONObject22, "toString(...)");
                            response17.body = WorkService.Companion.bytes(jSONObject22);
                            return response17;
                        }
                    case 505904927:
                        if (substring.equals("launcher/restore") && areEqual) {
                            JSONObject restore = getLauncherApi().restore();
                            HttpServer.Response response18 = new HttpServer.Response();
                            response18.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda018 = HttpServer.trusted;
                            String jSONObject23 = restore.toString();
                            Intrinsics.checkNotNullExpressionValue(jSONObject23, "toString(...)");
                            response18.body = WorkService.Companion.bytes(jSONObject23);
                            return response18;
                        }
                        break;
                    case 1353214111:
                        if (!substring.equals("wirelog")) {
                            break;
                        } else {
                            if (areEqual) {
                                WireLog wireLog = WireLog.all;
                                json4 = request.json(65536);
                                String optString2 = json4.optString("said");
                                Intrinsics.checkNotNullExpressionValue(optString2, "optString(...)");
                                wireLog.add("page", StringsKt.take(optString2, 500));
                                JSONObject put10 = new JSONObject().put("ok", true);
                                Intrinsics.checkNotNullExpressionValue(put10, "put(...)");
                                HttpServer.Response response19 = new HttpServer.Response();
                                response19.status = 200;
                                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda019 = HttpServer.trusted;
                                String jSONObject24 = put10.toString();
                                Intrinsics.checkNotNullExpressionValue(jSONObject24, "toString(...)");
                                response19.body = WorkService.Companion.bytes(jSONObject24);
                                return response19;
                            }
                            byte[] bytes = WireLog.all.report(null).getBytes(Charsets.UTF_8);
                            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                            HttpServer.Response response20 = new HttpServer.Response();
                            response20.type = "text/plain; charset=utf-8";
                            response20.body = bytes;
                            return response20;
                        }
                    case 1365955116:
                        if (substring.equals("launcher/install") && areEqual) {
                            LauncherApi launcherApi3 = getLauncherApi();
                            json5 = request.json(65536);
                            String optString3 = json5.optString("id");
                            Intrinsics.checkNotNullExpressionValue(optString3, "optString(...)");
                            JSONObject install = launcherApi3.install(optString3, request.getLang());
                            HttpServer.Response response21 = new HttpServer.Response();
                            response21.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda020 = HttpServer.trusted;
                            String jSONObject25 = install.toString();
                            Intrinsics.checkNotNullExpressionValue(jSONObject25, "toString(...)");
                            response21.body = WorkService.Companion.bytes(jSONObject25);
                            return response21;
                        }
                        break;
                    case 1434631203:
                        if (substring.equals("settings") && !areEqual) {
                            return this.core.text(20000L, "for n in global secure system; do settings list $n 2>/dev/null | sed \"s/^/$n /\"; done; for s in 1 3; do echo \"vol $s $(cmd media_session volume --stream $s --get 2>/dev/null | grep 'volume is')\"; done");
                        }
                        break;
                    case 1495725696:
                        if (substring.equals("tvapps/install") && areEqual) {
                            TvAppsApi tvAppsApi = (TvAppsApi) this.tvAppsApi$delegate.getValue();
                            json6 = request.json(65536);
                            String optString4 = json6.optString("id");
                            Intrinsics.checkNotNullExpressionValue(optString4, "optString(...)");
                            JSONObject install2 = tvAppsApi.install(optString4);
                            HttpServer.Response response22 = new HttpServer.Response();
                            response22.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda021 = HttpServer.trusted;
                            String jSONObject26 = install2.toString();
                            Intrinsics.checkNotNullExpressionValue(jSONObject26, "toString(...)");
                            response22.body = WorkService.Companion.bytes(jSONObject26);
                            return response22;
                        }
                        break;
                    case 1584744750:
                        if (substring.equals("screen/state") && !areEqual) {
                            JSONObject put11 = new JSONObject().put("off", Intrinsics.areEqual(StringsKt.trim(sh("pgrep -f 'core[.]Screen off' >/dev/null && echo off")).toString(), "off"));
                            Intrinsics.checkNotNullExpressionValue(put11, "put(...)");
                            HttpServer.Response response23 = new HttpServer.Response();
                            response23.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda022 = HttpServer.trusted;
                            String jSONObject27 = put11.toString();
                            Intrinsics.checkNotNullExpressionValue(jSONObject27, "toString(...)");
                            response23.body = WorkService.Companion.bytes(jSONObject27);
                            return response23;
                        }
                        break;
                    case 2039141173:
                        if (!substring.equals("downloader")) {
                            break;
                        } else {
                            JSONObject json25 = Downloader.json();
                            HttpServer.Response response24 = new HttpServer.Response();
                            response24.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda023 = HttpServer.trusted;
                            String jSONObject28 = json25.toString();
                            Intrinsics.checkNotNullExpressionValue(jSONObject28, "toString(...)");
                            response24.body = WorkService.Companion.bytes(jSONObject28);
                            return response24;
                        }
                }
                Iterator it = getParts().iterator();
                while (it.hasNext()) {
                    HttpServer.Response route = ((ManagePart) it.next()).route(substring, areEqual, request);
                    if (route != null) {
                        return route;
                    }
                }
                if (areEqual) {
                    long j = 0;
                    switch (substring.hashCode()) {
                        case -1976111602:
                            if (!substring.equals("videobox/frame")) {
                                return null;
                            }
                            long j2 = request.length;
                            if (j2 > 0 && j2 <= 4000000) {
                                int i = (int) j2;
                                byte[] bArr = new byte[i];
                                int i2 = 0;
                                while (i2 < i) {
                                    int read2 = request.body.read(bArr, i2, i - i2);
                                    if (read2 >= 0) {
                                        i2 += read2;
                                    } else {
                                        JSONObject jSONObject29 = new JSONObject();
                                        Video video = this.video;
                                        boolean areEqual2 = Intrinsics.areEqual(request.q("k"), "1");
                                        longOrNull = StringsKt__StringNumberConversionsKt.toLongOrNull(request.q("t"));
                                        if (longOrNull != null) {
                                            j = longOrNull.longValue();
                                        }
                                        JSONObject put12 = jSONObject29.put("ok", video.frame(bArr, i2, areEqual2, j));
                                        Intrinsics.checkNotNullExpressionValue(put12, "put(...)");
                                        HttpServer.Response response25 = new HttpServer.Response();
                                        response25.status = 200;
                                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda024 = HttpServer.trusted;
                                        String jSONObject30 = put12.toString();
                                        Intrinsics.checkNotNullExpressionValue(jSONObject30, "toString(...)");
                                        response25.body = WorkService.Companion.bytes(jSONObject30);
                                        return response25;
                                    }
                                }
                                JSONObject jSONObject292 = new JSONObject();
                                Video video2 = this.video;
                                boolean areEqual22 = Intrinsics.areEqual(request.q("k"), "1");
                                longOrNull = StringsKt__StringNumberConversionsKt.toLongOrNull(request.q("t"));
                                if (longOrNull != null) {
                                }
                                JSONObject put122 = jSONObject292.put("ok", video2.frame(bArr, i2, areEqual22, j));
                                Intrinsics.checkNotNullExpressionValue(put122, "put(...)");
                                HttpServer.Response response252 = new HttpServer.Response();
                                response252.status = 200;
                                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0242 = HttpServer.trusted;
                                String jSONObject302 = put122.toString();
                                Intrinsics.checkNotNullExpressionValue(jSONObject302, "toString(...)");
                                response252.body = WorkService.Companion.bytes(jSONObject302);
                                return response252;
                            }
                            throw new IllegalArgumentException("bad frame");
                        case -1964046077:
                            if (!substring.equals("videobox/start")) {
                                return null;
                            }
                            Video video3 = this.video;
                            json7 = request.json(65536);
                            video3.start(json7);
                            JSONObject put13 = new JSONObject().put("ok", true);
                            Intrinsics.checkNotNullExpressionValue(put13, "put(...)");
                            HttpServer.Response response26 = new HttpServer.Response();
                            response26.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda025 = HttpServer.trusted;
                            String jSONObject31 = put13.toString();
                            Intrinsics.checkNotNullExpressionValue(jSONObject31, "toString(...)");
                            response26.body = WorkService.Companion.bytes(jSONObject31);
                            return response26;
                        case -1367724422:
                            if (!substring.equals("cancel")) {
                                return null;
                            }
                            ConcurrentHashMap stops = this.jobs.getStops();
                            json8 = request.json(65536);
                            Cancel cancel = (Cancel) stops.get(json8.optString("id"));
                            if (cancel != null) {
                                cancel.stop();
                            }
                            JSONObject put14 = new JSONObject().put("ok", true);
                            Intrinsics.checkNotNullExpressionValue(put14, "put(...)");
                            HttpServer.Response response27 = new HttpServer.Response();
                            response27.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda026 = HttpServer.trusted;
                            String jSONObject32 = put14.toString();
                            Intrinsics.checkNotNullExpressionValue(jSONObject32, "toString(...)");
                            response27.body = WorkService.Companion.bytes(jSONObject32);
                            return response27;
                        case -1337892484:
                            if (!substring.equals("adb/deny")) {
                                return null;
                            }
                            JSONObject jSONObject33 = new JSONObject();
                            synchronized (this.promptLock) {
                                AdbPrompt adbPrompt2 = AdbPrompt.INSTANCE;
                                Adb adb2 = this.link.get();
                                json9 = request.json(65536);
                                String optString5 = json9.optString("fingerprint");
                                Intrinsics.checkNotNullExpressionValue(optString5, "optString(...)");
                                deny = AdbPrompt.deny(adb2, optString5);
                            }
                            JSONObject put15 = jSONObject33.put("ok", deny);
                            Intrinsics.checkNotNullExpressionValue(put15, "put(...)");
                            HttpServer.Response response28 = new HttpServer.Response();
                            response28.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda027 = HttpServer.trusted;
                            String jSONObject34 = put15.toString();
                            Intrinsics.checkNotNullExpressionValue(jSONObject34, "toString(...)");
                            response28.body = WorkService.Companion.bytes(jSONObject34);
                            return response28;
                        case -1337538998:
                            if (!substring.equals("adb/pair")) {
                                return null;
                            }
                            if (this.canPair && areEqual) {
                                json10 = request.json(65536);
                                return pairing(json10);
                            }
                            JSONObject put16 = new JSONObject().put("error", "not here");
                            Intrinsics.checkNotNullExpressionValue(put16, "put(...)");
                            HttpServer.Response response29 = new HttpServer.Response();
                            response29.status = 404;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda028 = HttpServer.trusted;
                            String jSONObject35 = put16.toString();
                            Intrinsics.checkNotNullExpressionValue(jSONObject35, "toString(...)");
                            response29.body = WorkService.Companion.bytes(jSONObject35);
                            return response29;
                        case -1039689911:
                            if (!substring.equals("notify")) {
                                return null;
                            }
                            List list3 = Notify.CORNERS;
                            Manage$$ExternalSyntheticLambda18 manage$$ExternalSyntheticLambda182 = new Manage$$ExternalSyntheticLambda18(this, 5);
                            json11 = request.json(65536);
                            JSONObject send = Notify.send(manage$$ExternalSyntheticLambda182, json11);
                            HttpServer.Response response30 = new HttpServer.Response();
                            response30.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda029 = HttpServer.trusted;
                            String jSONObject36 = send.toString();
                            Intrinsics.checkNotNullExpressionValue(jSONObject36, "toString(...)");
                            response30.body = WorkService.Companion.bytes(jSONObject36);
                            return response30;
                        case -934938715:
                            if (!substring.equals("reboot")) {
                                return null;
                            }
                            sh("case \"$(settings get secure always_on_vpn_app)\" in com.tailscale.ipn) ;; *) pm path com.tailscale.ipn >/dev/null 2>&1 && ip addr | grep -qE 'inet 100\\.(6[4-9]|[7-9][0-9]|1[01][0-9]|12[0-7])\\.' && { settings put secure always_on_vpn_app com.tailscale.ipn; settings put secure always_on_vpn_lockdown 0; };; esac; echo ok");
                            try {
                                open = this.link.get().open(10000L, "reboot:");
                                try {
                                    open.readAll(3000L);
                                    MathKt.closeFinally(open, null);
                                } finally {
                                }
                            } catch (Exception unused2) {
                            }
                            this.link.close();
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda030 = HttpServer.trusted;
                            byte[] bytes2 = WorkService.Companion.bytes("{\"ok\":true}");
                            HttpServer.Response response31 = new HttpServer.Response();
                            response31.type = "application/json; charset=utf-8";
                            response31.body = bytes2;
                            return response31;
                        case -906336856:
                            if (substring.equals("search")) {
                                json12 = request.json(65536);
                                String optString6 = json12.optString("pkg");
                                Intrinsics.checkNotNullExpressionValue(optString6, "optString(...)");
                                if (optString6.length() > 0) {
                                    TvShell tvShell2 = TvShell.INSTANCE;
                                    String optString7 = json12.optString("pkg");
                                    Intrinsics.checkNotNullExpressionValue(optString7, "optString(...)");
                                    String optString8 = json12.optString("url");
                                    if (optString8.length() == 0) {
                                        str5 = null;
                                    } else {
                                        str5 = optString8;
                                    }
                                    String optString9 = json12.optString("query");
                                    Intrinsics.checkNotNullExpressionValue(optString9, "optString(...)");
                                    String obj2 = StringsKt.trim(sh(TvShell.searchIn(optString7, str5, optString9))).toString();
                                    if (Intrinsics.areEqual(obj2, "none")) {
                                        HashMap hashMap = Scenes.KEYS;
                                        Manage$$ExternalSyntheticLambda18 manage$$ExternalSyntheticLambda183 = new Manage$$ExternalSyntheticLambda18(this, 7);
                                        String optString10 = json12.optString("pkg");
                                        Intrinsics.checkNotNullExpressionValue(optString10, "optString(...)");
                                        Scenes.launch(optString10, manage$$ExternalSyntheticLambda183);
                                    }
                                    JSONObject jSONObject37 = new JSONObject();
                                    if (Intrinsics.areEqual(obj2, "none")) {
                                        str6 = "open";
                                    } else {
                                        str6 = "app";
                                    }
                                    JSONObject put17 = jSONObject37.put("to", str6);
                                    Intrinsics.checkNotNullExpressionValue(put17, "put(...)");
                                    HttpServer.Response response32 = new HttpServer.Response();
                                    response32.status = 200;
                                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda031 = HttpServer.trusted;
                                    String jSONObject38 = put17.toString();
                                    Intrinsics.checkNotNullExpressionValue(jSONObject38, "toString(...)");
                                    response32.body = WorkService.Companion.bytes(jSONObject38);
                                    return response32;
                                }
                                TvShell tvShell3 = TvShell.INSTANCE;
                                json13 = request.json(65536);
                                String optString11 = json13.optString("query");
                                Intrinsics.checkNotNullExpressionValue(optString11, "optString(...)");
                                String obj3 = StringsKt.trim(sh(TvShell.search(optString11))).toString();
                                if (!Intrinsics.areEqual(obj3, "yt") && !Intrinsics.areEqual(obj3, "gs")) {
                                    throw new IllegalArgumentException("this TV has no YouTube and no Google search");
                                }
                                JSONObject jSONObject39 = new JSONObject();
                                if (Intrinsics.areEqual(obj3, "yt")) {
                                    str4 = "youtube";
                                } else {
                                    str4 = "assistant";
                                }
                                JSONObject put18 = jSONObject39.put("to", str4);
                                Intrinsics.checkNotNullExpressionValue(put18, "put(...)");
                                HttpServer.Response response33 = new HttpServer.Response();
                                response33.status = 200;
                                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda032 = HttpServer.trusted;
                                String jSONObject40 = put18.toString();
                                Intrinsics.checkNotNullExpressionValue(jSONObject40, "toString(...)");
                                response33.body = WorkService.Companion.bytes(jSONObject40);
                                return response33;
                            }
                            return null;
                        case -493563858:
                            if (substring.equals("playing")) {
                                json14 = request.json(65536);
                                NowPlaying nowPlaying2 = this.playing;
                                if (nowPlaying2 != null) {
                                    String optString12 = json14.optString("do");
                                    Intrinsics.checkNotNullExpressionValue(optString12, "optString(...)");
                                    nowPlaying2.command(json14.optLong("ms"), optString12);
                                    JSONObject put19 = new JSONObject().put("ok", true);
                                    Intrinsics.checkNotNullExpressionValue(put19, "put(...)");
                                    HttpServer.Response response34 = new HttpServer.Response();
                                    response34.status = 200;
                                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda033 = HttpServer.trusted;
                                    String jSONObject41 = put19.toString();
                                    Intrinsics.checkNotNullExpressionValue(jSONObject41, "toString(...)");
                                    response34.body = WorkService.Companion.bytes(jSONObject41);
                                    return response34;
                                }
                                throw new IllegalStateException("not here");
                            }
                            return null;
                        case -459923590:
                            if (!substring.equals("adb/connect")) {
                                return null;
                            }
                            JSONObject jSONObject42 = new JSONObject();
                            AdbLink adbLink = this.link;
                            adbLink.gen++;
                            adbLink.close();
                            adbLink.failed = false;
                            adbLink.lastTry = 0L;
                            JSONObject put20 = jSONObject42.put("state", adbLink.state());
                            Intrinsics.checkNotNullExpressionValue(put20, "put(...)");
                            HttpServer.Response response35 = new HttpServer.Response();
                            response35.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda034 = HttpServer.trusted;
                            String jSONObject43 = put20.toString();
                            Intrinsics.checkNotNullExpressionValue(jSONObject43, "toString(...)");
                            response35.body = WorkService.Companion.bytes(jSONObject43);
                            return response35;
                        case -418466484:
                            if (!substring.equals("screen/off")) {
                                return null;
                            }
                            Adb adb3 = this.link.get();
                            Managing$$ExternalSyntheticLambda2 managing$$ExternalSyntheticLambda2 = this.helper;
                            if (managing$$ExternalSyntheticLambda2 != null) {
                                Games.run(adb3, "off", (byte[]) managing$$ExternalSyntheticLambda2.invoke());
                                JSONObject put21 = new JSONObject().put("ok", true);
                                Intrinsics.checkNotNullExpressionValue(put21, "put(...)");
                                HttpServer.Response response36 = new HttpServer.Response();
                                response36.status = 200;
                                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda035 = HttpServer.trusted;
                                String jSONObject44 = put21.toString();
                                Intrinsics.checkNotNullExpressionValue(jSONObject44, "toString(...)");
                                response36.body = WorkService.Companion.bytes(jSONObject44);
                                return response36;
                            }
                            throw new IllegalStateException("not here");
                        case -255267571:
                            if (substring.equals("tailscale/start")) {
                                json15 = request.json(65536);
                                String optString13 = json15.optString("lang");
                                Intrinsics.checkNotNull(optString13);
                                if (optString13.length() > 0) {
                                    str7 = optString13;
                                } else {
                                    str7 = null;
                                }
                                if (str7 != null) {
                                    lang2 = Words.pick(str7);
                                } else {
                                    lang2 = request.getLang();
                                }
                                job = this.jobs.job("tailscale", null, null, null, new Manage$$ExternalSyntheticLambda17(this, lang2, objArr == true ? 1 : 0));
                                HttpServer.Response response37 = new HttpServer.Response();
                                response37.status = 200;
                                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda036 = HttpServer.trusted;
                                String jSONObject45 = job.toString();
                                Intrinsics.checkNotNullExpressionValue(jSONObject45, "toString(...)");
                                response37.body = WorkService.Companion.bytes(jSONObject45);
                                return response37;
                            }
                            return null;
                        case 3091780:
                            if (!substring.equals("draw")) {
                                return null;
                            }
                            Draw draw = this.draw;
                            JSONArray jSONArray = request.json(6000000).getJSONArray("ops");
                            Intrinsics.checkNotNullExpressionValue(jSONArray, "getJSONArray(...)");
                            draw.send(jSONArray);
                            JSONObject put22 = new JSONObject().put("ok", true).put("pic", this.draw.getPics());
                            Intrinsics.checkNotNullExpressionValue(put22, "put(...)");
                            HttpServer.Response response38 = new HttpServer.Response();
                            response38.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda037 = HttpServer.trusted;
                            String jSONObject46 = put22.toString();
                            Intrinsics.checkNotNullExpressionValue(jSONObject46, "toString(...)");
                            response38.body = WorkService.Companion.bytes(jSONObject46);
                            return response38;
                        case 100358090:
                            if (substring.equals("input")) {
                                json16 = request.json(65536);
                                String optString14 = json16.optString("id");
                                Object obj4 = Inputs.TYPES;
                                Manage$$ExternalSyntheticLambda18 manage$$ExternalSyntheticLambda184 = new Manage$$ExternalSyntheticLambda18(this, 4);
                                Intrinsics.checkNotNull(optString14);
                                JSONObject put23 = new JSONObject().put("ok", true).put("via", Inputs.m14switch(manage$$ExternalSyntheticLambda184, optString14, this.inputCache.peek()));
                                Intrinsics.checkNotNullExpressionValue(put23, "put(...)");
                                HttpServer.Response response39 = new HttpServer.Response();
                                response39.status = 200;
                                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda038 = HttpServer.trusted;
                                String jSONObject47 = put23.toString();
                                Intrinsics.checkNotNullExpressionValue(jSONObject47, "toString(...)");
                                response39.body = WorkService.Companion.bytes(jSONObject47);
                                return response39;
                            }
                            return null;
                        case 109400031:
                            if (!substring.equals("share")) {
                                return null;
                            }
                            List list4 = Invite.SCOPES;
                            Manage$$ExternalSyntheticLambda18 manage$$ExternalSyntheticLambda185 = new Manage$$ExternalSyntheticLambda18(this, 6);
                            String str9 = this.link.host;
                            json17 = request.json(65536);
                            String optString15 = json17.optString("scope");
                            Intrinsics.checkNotNullExpressionValue(optString15, "optString(...)");
                            json18 = request.json(65536);
                            JSONObject share = Invite.share(manage$$ExternalSyntheticLambda185, str9, optString15, json18.optBoolean("again"));
                            HttpServer.Response response40 = new HttpServer.Response();
                            response40.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda039 = HttpServer.trusted;
                            String jSONObject48 = share.toString();
                            Intrinsics.checkNotNullExpressionValue(jSONObject48, "toString(...)");
                            response40.body = WorkService.Companion.bytes(jSONObject48);
                            return response40;
                        case 109403696:
                            if (substring.equals("shell")) {
                                json19 = request.json(65536);
                                String optString16 = json19.optString("cmd");
                                Intrinsics.checkNotNullExpressionValue(optString16, "optString(...)");
                                return shell(optString16);
                            }
                            return null;
                        case 109641799:
                            if (substring.equals("speed")) {
                                json20 = request.json(65536);
                                if (json20.optBoolean("stop")) {
                                    sh("pkill -f 'core[.]Speed'; rm -f /data/local/tmp/tvr-speed.txt");
                                } else {
                                    Adb adb4 = this.link.get();
                                    Managing$$ExternalSyntheticLambda2 managing$$ExternalSyntheticLambda22 = this.helper;
                                    if (managing$$ExternalSyntheticLambda22 != null) {
                                        String install3 = RemoteLabels.Companion.install(adb4, (byte[]) managing$$ExternalSyntheticLambda22.invoke());
                                        ConcurrentHashMap concurrentHashMap2 = Adb.ASKING;
                                        adb4.shell(120000L, "pkill -f 'core[.]Speed'");
                                        adb4.shell(120000L, "rm -f /data/local/tmp/tvr-speed.txt; (CLASSPATH=" + install3 + " nohup setsid app_process / dev.tvremote.core.Speed 8 >/data/local/tmp/tvr-speed.txt 2>&1 </dev/null &); for i in 1 2 3 4 5 6 7 8 9 10; do [ -s /data/local/tmp/tvr-speed.txt ] && break; sleep 0.3; done");
                                    } else {
                                        throw new IllegalStateException("not here");
                                    }
                                }
                                JSONObject put24 = new JSONObject().put("ok", true);
                                Intrinsics.checkNotNullExpressionValue(put24, "put(...)");
                                HttpServer.Response response41 = new HttpServer.Response();
                                response41.status = 200;
                                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda040 = HttpServer.trusted;
                                String jSONObject49 = put24.toString();
                                Intrinsics.checkNotNullExpressionValue(jSONObject49, "toString(...)");
                                response41.body = WorkService.Companion.bytes(jSONObject49);
                                return response41;
                            }
                            return null;
                        case 125048418:
                            if (!substring.equals("screen/on")) {
                                return null;
                            }
                            Adb adb5 = this.link.get();
                            Managing$$ExternalSyntheticLambda2 managing$$ExternalSyntheticLambda23 = this.helper;
                            if (managing$$ExternalSyntheticLambda23 != null) {
                                Games.run(adb5, "on", (byte[]) managing$$ExternalSyntheticLambda23.invoke());
                                JSONObject put25 = new JSONObject().put("ok", true);
                                Intrinsics.checkNotNullExpressionValue(put25, "put(...)");
                                HttpServer.Response response42 = new HttpServer.Response();
                                response42.status = 200;
                                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda041 = HttpServer.trusted;
                                String jSONObject50 = put25.toString();
                                Intrinsics.checkNotNullExpressionValue(jSONObject50, "toString(...)");
                                response42.body = WorkService.Companion.bytes(jSONObject50);
                                return response42;
                            }
                            throw new IllegalStateException("not here");
                        case 1151390576:
                            if (substring.equals("videobox")) {
                                json21 = request.json(65536);
                                if (Intrinsics.areEqual(json21.optString("o"), "file")) {
                                    Video video4 = this.video;
                                    AtomicLong atomicLong = TvPaths.tmpN;
                                    op = video4.file(TvPaths.safePath$shared_release(json21.optString("path")), json21);
                                } else {
                                    op = this.video.op(json21);
                                }
                                HttpServer.Response response43 = new HttpServer.Response();
                                response43.status = 200;
                                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda042 = HttpServer.trusted;
                                String jSONObject51 = op.toString();
                                Intrinsics.checkNotNullExpressionValue(jSONObject51, "toString(...)");
                                response43.body = WorkService.Companion.bytes(jSONObject51);
                                return response43;
                            }
                            return null;
                        case 1434631203:
                            if (substring.equals("settings")) {
                                json22 = request.json(65536);
                                TvShell tvShell4 = TvShell.INSTANCE;
                                Integer num2 = (Integer) TvShell.getVOLUME().get(json22.optString("name"));
                                if (num2 != null && Intrinsics.areEqual(json22.optString("table"), "system")) {
                                    String optString17 = json22.optString("value");
                                    Intrinsics.checkNotNullExpressionValue(optString17, "optString(...)");
                                    Integer intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull(optString17);
                                    if (intOrNull != null) {
                                        int intValue = intOrNull.intValue();
                                        if (intValue >= 0 && intValue < 101) {
                                            num = intOrNull;
                                        } else {
                                            num = null;
                                        }
                                        if (num != null) {
                                            int intValue2 = num.intValue();
                                            HashMap hashMap2 = Scenes.KEYS;
                                            Scenes.volume(new Manage$$ExternalSyntheticLambda18(this, 3), intValue2, num2.intValue());
                                            JSONObject put26 = new JSONObject().put("text", "ok");
                                            Intrinsics.checkNotNullExpressionValue(put26, "put(...)");
                                            HttpServer.Response response44 = new HttpServer.Response();
                                            response44.status = 200;
                                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda043 = HttpServer.trusted;
                                            String jSONObject52 = put26.toString();
                                            Intrinsics.checkNotNullExpressionValue(jSONObject52, "toString(...)");
                                            response44.body = WorkService.Companion.bytes(jSONObject52);
                                            return response44;
                                        }
                                    }
                                    throw new IllegalArgumentException("bad value");
                                }
                                String optString18 = json22.optString("table");
                                Intrinsics.checkNotNullExpressionValue(optString18, "optString(...)");
                                String optString19 = json22.optString("name");
                                Intrinsics.checkNotNullExpressionValue(optString19, "optString(...)");
                                String optString20 = json22.optString("value");
                                Intrinsics.checkNotNullExpressionValue(optString20, "optString(...)");
                                return this.core.text(20000L, TvShell.setting(optString18, optString19, optString20));
                            }
                            return null;
                        case 1472441817:
                            if (substring.equals("adb/allow")) {
                                json23 = request.json(65536);
                                String optString21 = json23.optString("fingerprint");
                                Intrinsics.checkNotNullExpressionValue(optString21, "optString(...)");
                                String upperCase = optString21.toUpperCase(Locale.ROOT);
                                Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
                                Pattern compile = Pattern.compile("(?:[0-9A-F]{2}:){15}[0-9A-F]{2}");
                                Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                                if (compile.matcher(upperCase).matches()) {
                                    synchronized (this.promptLock) {
                                        allow = AdbPrompt.INSTANCE.allow(this.link.get(), upperCase, MathKt.coerceIn(json23.optLong("wait", 0L), 0L, 40L) * 1000, json23.optBoolean("others"), json23.optBoolean("always", true));
                                    }
                                    Intrinsics.areEqual(allow, "allowed");
                                    JSONObject put27 = new JSONObject().put("result", allow);
                                    Intrinsics.checkNotNullExpressionValue(put27, "put(...)");
                                    HttpServer.Response response45 = new HttpServer.Response();
                                    response45.status = 200;
                                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda044 = HttpServer.trusted;
                                    String jSONObject53 = put27.toString();
                                    Intrinsics.checkNotNullExpressionValue(jSONObject53, "toString(...)");
                                    response45.body = WorkService.Companion.bytes(jSONObject53);
                                    return response45;
                                }
                                throw new IllegalArgumentException("bad fingerprint");
                            }
                            return null;
                        case 1876306753:
                            if (substring.equals("videobox/stop")) {
                                this.video.stop();
                                JSONObject put28 = new JSONObject().put("ok", true);
                                Intrinsics.checkNotNullExpressionValue(put28, "put(...)");
                                HttpServer.Response response46 = new HttpServer.Response();
                                response46.status = 200;
                                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda045 = HttpServer.trusted;
                                String jSONObject54 = put28.toString();
                                Intrinsics.checkNotNullExpressionValue(jSONObject54, "toString(...)");
                                response46.body = WorkService.Companion.bytes(jSONObject54);
                                return response46;
                            }
                            return null;
                        default:
                            return null;
                    }
                }
            } catch (SetupNeed.Missing e) {
                JSONObject m9m = Census$$ExternalSyntheticOutline0.m9m("error", String.valueOf(e.getMessage()), "put(...)");
                HttpServer.Response response47 = new HttpServer.Response();
                response47.status = 409;
                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda046 = HttpServer.trusted;
                response47.body = Census$$ExternalSyntheticOutline0.m("toString(...)", m9m);
                return response47;
            } catch (Cancelled unused3) {
                JSONObject m9m2 = Census$$ExternalSyntheticOutline0.m9m("error", "stopped", "put(...)");
                HttpServer.Response response48 = new HttpServer.Response();
                response48.status = 410;
                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda047 = HttpServer.trusted;
                response48.body = Census$$ExternalSyntheticOutline0.m("toString(...)", m9m2);
                return response48;
            } catch (IOException e2) {
                if (Errors.fromInternet(e2)) {
                    String message2 = "net: " + e2.getClass().getSimpleName() + ": " + e2.getMessage();
                    Intrinsics.checkNotNullParameter(message2, "message");
                    JSONObject m9m3 = Census$$ExternalSyntheticOutline0.m9m("error", message2, "put(...)");
                    HttpServer.Response response49 = new HttpServer.Response();
                    response49.status = 502;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda048 = HttpServer.trusted;
                    response49.body = Census$$ExternalSyntheticOutline0.m("toString(...)", m9m3);
                    return response49;
                }
                if (this.link.waitingForUser()) {
                    message = "adb:allow";
                } else {
                    message = ApkSigner$$ExternalSyntheticOutline0.m("adb: ", e2.getMessage());
                }
                Intrinsics.checkNotNullParameter(message, "message");
                JSONObject put29 = new JSONObject().put("error", message);
                Intrinsics.checkNotNullExpressionValue(put29, "put(...)");
                HttpServer.Response response50 = new HttpServer.Response();
                response50.status = 503;
                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda049 = HttpServer.trusted;
                response50.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put29);
                return response50;
            } catch (IllegalArgumentException e3) {
                JSONObject m9m4 = Census$$ExternalSyntheticOutline0.m9m("error", String.valueOf(e3.getMessage()), "put(...)");
                HttpServer.Response response51 = new HttpServer.Response();
                response51.status = 400;
                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda050 = HttpServer.trusted;
                response51.body = Census$$ExternalSyntheticOutline0.m("toString(...)", m9m4);
                return response51;
            }
        }
        return null;
    }

    public final List inputs(boolean z) {
        return this.inputCache.get(z, new Manage$$ExternalSyntheticLambda0(this, 6));
    }

    public final String install(FileInputStream fileInputStream, long j, JSONObject jSONObject, Cancel cancel) {
        InstallApi installApi = (InstallApi) this.installs$delegate.getValue();
        installApi.getClass();
        installApi.getCurrent().set(cancel);
        try {
            String tmpApk = TvPaths.tmpApk();
            installApi.copy.push(fileInputStream, j, tmpApk, jSONObject, 2);
            try {
                String pmInstall = installApi.pmInstall(tmpApk);
                try {
                    installApi.sh("rm -f ".concat(tmpApk));
                } catch (IOException unused) {
                }
                return pmInstall;
            } finally {
            }
        } finally {
            installApi.getCurrent().remove();
        }
    }

    public final HttpServer.Response pairing(JSONObject jSONObject) {
        String optString = jSONObject.optString("host");
        Intrinsics.checkNotNullExpressionValue(optString, "optString(...)");
        String obj = StringsKt.trim(optString).toString();
        int length = obj.length();
        AdbLink adbLink = this.link;
        if (length == 0) {
            obj = adbLink.host;
        }
        int optInt = jSONObject.optInt("connectPort", 0);
        String optString2 = jSONObject.optString("code");
        Intrinsics.checkNotNullExpressionValue(optString2, "optString(...)");
        if (!StringsKt.isBlank(optString2) || optInt <= 0) {
            int optInt2 = jSONObject.optInt("port", 0);
            AdbTls adbTls = AdbTls.INSTANCE;
            String cleanCode = AdbTls.cleanCode(jSONObject.optString("code"));
            if (cleanCode != null) {
                if (1 <= optInt2 && optInt2 < 65536) {
                    AdbTls.pair(new Adb(adbLink.keyDir), obj, optInt2, cleanCode);
                } else {
                    throw new IllegalArgumentException("the pairing port is a number");
                }
            } else {
                throw new IllegalArgumentException("the pairing code is 6 digits");
            }
        }
        int i = 0;
        while (optInt <= 0) {
            int i2 = i + 1;
            if (i >= 3) {
                break;
            }
            optInt = AdbTls.discoverConnect$default(obj);
            i = i2;
        }
        JSONObject put = new JSONObject().put("ok", true).put("paired", true);
        if (optInt <= 0) {
            JSONObject put2 = put.put("needPort", true);
            Intrinsics.checkNotNullExpressionValue(put2, "put(...)");
            HttpServer.Response response = new HttpServer.Response();
            response.status = 200;
            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = HttpServer.trusted;
            response.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put2);
            return response;
        }
        AdbTls adbTls2 = AdbTls.INSTANCE;
        adbTls2.save(adbLink.keyDir, obj, optInt);
        if (!Intrinsics.areEqual(adbLink.host, obj) && AdbTls.same(adbLink.host, obj)) {
            adbTls2.save(adbLink.keyDir, adbLink.host, optInt);
        }
        JSONObject put3 = put.put("port", optInt);
        adbLink.gen++;
        adbLink.close();
        adbLink.failed = false;
        adbLink.lastTry = 0L;
        JSONObject put4 = put3.put("state", adbLink.state());
        Intrinsics.checkNotNullExpressionValue(put4, "put(...)");
        HttpServer.Response response2 = new HttpServer.Response();
        response2.status = 200;
        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda02 = HttpServer.trusted;
        response2.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put4);
        return response2;
    }

    public final String sh(String str) {
        Adb adb = this.link.get();
        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
        return adb.shell(120000L, str);
    }

    /* JADX WARN: Finally extract failed */
    public final HttpServer.Response shell(String str) {
        boolean z;
        if (StringsKt.trim(str).toString().length() != 0) {
            Adb adb = this.link.get();
            String m = ApkSigner$$ExternalSyntheticOutline0.m("shell:", str, " 2>&1");
            ConcurrentHashMap concurrentHashMap = Adb.ASKING;
            Adb.Stream open = adb.open(10000L, m);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            byte[] bArr = new byte[16384];
            long j = 1000000;
            long nanoTime = (System.nanoTime() / j) + 30000;
            while (true) {
                try {
                    long nanoTime2 = nanoTime - (System.nanoTime() / j);
                    if (nanoTime2 <= 0 || byteArrayOutputStream.size() > 200000) {
                        break;
                    }
                    int read = open.read(nanoTime2, bArr, 0, 16384);
                    z = false;
                    if (read < 0) {
                        break;
                    }
                    byteArrayOutputStream.write(bArr, 0, read);
                } catch (Throwable th) {
                    open.close();
                    throw th;
                }
            }
            z = true;
            open.close();
            JSONObject jSONObject = new JSONObject();
            String byteArrayOutputStream2 = byteArrayOutputStream.toString("UTF-8");
            Intrinsics.checkNotNullExpressionValue(byteArrayOutputStream2, "toString(...)");
            JSONObject put = jSONObject.put("out", StringsKt__StringsJVMKt.replace$default(byteArrayOutputStream2, "\r\n", "\n")).put("cut", z);
            Intrinsics.checkNotNullExpressionValue(put, "put(...)");
            HttpServer.Response response = new HttpServer.Response();
            response.status = 200;
            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = HttpServer.trusted;
            response.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put);
            return response;
        }
        throw new IllegalArgumentException("empty command");
    }

    public final void welcomeBulk(FileInputStream fileInputStream, long j, String name, JSONObject cfg, JSONObject jSONObject, Cancel cancel) {
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(cfg, "cfg");
        SetupApi setupApi = (SetupApi) this.setupApi$delegate.getValue();
        setupApi.getClass();
        setupApi.getCurrent().set(cancel);
        try {
            if (fileInputStream != null) {
                setupApi.welcomeStore(fileInputStream, j, name, jSONObject);
            } else {
                LinkedHashMap linkedHashMap = SetupNeed.MIN;
                SetupNeed.check(setupApi.link.get(), "welcome");
            }
            if (cfg.length() > 0) {
                Set set = Welcome.VIDEO;
                Welcome.call(new SetupApi$$ExternalSyntheticLambda0(setupApi, 2), new JSONObject(cfg.toString()).put("do", "config"));
            }
            setupApi.getCurrent().remove();
        } catch (Throwable th) {
            setupApi.getCurrent().remove();
            throw th;
        }
    }
}
