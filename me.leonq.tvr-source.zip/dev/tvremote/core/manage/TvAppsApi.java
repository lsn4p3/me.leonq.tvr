package dev.tvremote.core.manage;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.adb.AdbLink$$ExternalSyntheticLambda2;
import dev.tvremote.core.ontv.Axml$$ExternalSyntheticLambda2;
import dev.tvremote.core.ontv.Video;
import dev.tvremote.core.web.HttpServer;
import dev.tvremote.home.HomeQr$$ExternalSyntheticLambda0;
import dev.tvremote.tvapps.ApkCert;
import dev.tvremote.tvapps.AppList;
import dev.tvremote.update.SignedList;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyList;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class TvAppsApi {
    public final Manage$$ExternalSyntheticLambda0 cancel;
    public final File dir;
    public final AdbLink$$ExternalSyntheticLambda2 install;
    public final Manage$$ExternalSyntheticLambda12 job;
    public final AdbLink link;

    public TvAppsApi(AdbLink link, File file, Manage$$ExternalSyntheticLambda12 manage$$ExternalSyntheticLambda12, Manage$$ExternalSyntheticLambda0 manage$$ExternalSyntheticLambda0, AdbLink$$ExternalSyntheticLambda2 adbLink$$ExternalSyntheticLambda2) {
        Intrinsics.checkNotNullParameter(link, "link");
        this.link = link;
        this.dir = file;
        this.job = manage$$ExternalSyntheticLambda12;
        this.cancel = manage$$ExternalSyntheticLambda0;
        this.install = adbLink$$ExternalSyntheticLambda2;
    }

    /* JADX WARN: Code restructure failed: missing block: B:23:0x0085, code lost:
    
        if (r4 == null) goto L27;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final HttpServer.Response icon(String str) {
        File file;
        byte[] bArr;
        File file2;
        List list = AppList.bases;
        File file3 = this.dir;
        AppList.List_ fetch = AppList.fetch(file3, false);
        AppList.App app = fetch.get(str);
        if (app == null) {
            JSONObject m9m = Census$$ExternalSyntheticOutline0.m9m("error", "not found", "put(...)");
            HttpServer.Response response = new HttpServer.Response();
            response.status = 404;
            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = HttpServer.trusted;
            response.body = Census$$ExternalSyntheticOutline0.m("toString(...)", m9m);
            return response;
        }
        String str2 = app.icon;
        if (str2.length() != 0) {
            Pattern compile = Pattern.compile("[0-9a-f]{64}");
            Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
            String str3 = app.iconSha;
            if (compile.matcher(str3).matches()) {
                ConcurrentHashMap concurrentHashMap = AppList.icons;
                byte[] bArr2 = (byte[]) concurrentHashMap.get(str3);
                if (bArr2 == null) {
                    bArr2 = null;
                    if (file3 != null) {
                        file = new File(file3, ApkSigner$$ExternalSyntheticOutline0.m("icons/", str3, ".png"));
                    } else {
                        file = null;
                    }
                    if (file != null) {
                        if (file.isFile()) {
                            file2 = file;
                        } else {
                            file2 = null;
                        }
                        if (file2 != null) {
                            byte[] readBytes = MathKt.readBytes(file2);
                            if (Intrinsics.areEqual(ApkCert.sha256(readBytes), str3)) {
                                bArr2 = readBytes;
                            }
                        }
                    }
                    List list2 = SignedList.KEYS;
                    bArr = SignedList.get(fetch.base + str2, 524288, 10000, 30000);
                    if (Intrinsics.areEqual(ApkCert.sha256(bArr), str3)) {
                        if (file != null) {
                            try {
                                File parentFile = file.getParentFile();
                                if (parentFile != null) {
                                    parentFile.mkdirs();
                                }
                                MathKt.writeBytes(file, bArr);
                            } catch (IOException unused) {
                            }
                        }
                        bArr2 = bArr;
                        concurrentHashMap.put(str3, bArr2);
                    } else {
                        throw new IOException("icon does not match the list");
                    }
                }
                HttpServer.Response response2 = new HttpServer.Response();
                response2.type = "image/png";
                response2.body = bArr2;
                return response2;
            }
        }
        throw new IOException("no icon");
    }

    public final JSONObject install(String str) {
        List list = AppList.bases;
        AppList.App app = AppList.fetch(this.dir, false).get(str);
        if (app != null) {
            if (app.setup.length() <= 0) {
                return (JSONObject) this.job.invoke("app ".concat(app.name), new Axml$$ExternalSyntheticLambda2(5, this, app));
            }
            throw new IllegalArgumentException("installed by TV Setup");
        }
        throw new IllegalArgumentException("no such app");
    }

    /* JADX WARN: Type inference failed for: r3v5, types: [java.util.Map, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r3v9, types: [java.lang.Object, java.lang.Iterable] */
    /* JADX WARN: Type inference failed for: r6v14, types: [java.util.List, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r8v6, types: [java.util.Map, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r8v8, types: [java.util.Map, java.lang.Object] */
    public final JSONObject list(boolean z) {
        Set set;
        String str;
        List list = AppList.bases;
        AppList.List_ fetch = AppList.fetch(this.dir, z);
        Video.Way tv = tv();
        JSONArray jSONArray = new JSONArray();
        Iterator it = fetch.apps.iterator();
        while (true) {
            boolean hasNext = it.hasNext();
            set = (Set) tv.dir;
            if (!hasNext) {
                break;
            }
            AppList.App app = (AppList.App) it.next();
            JSONObject put = new JSONObject().put("id", app.id);
            String str2 = app.pkg;
            JSONObject put2 = put.put("pkg", str2).put("name", app.name).put("cat", app.cat).put("desc", new JSONObject((Map) app.desc)).put("notes", new JSONObject((Map) app.notes)).put("source", app.source).put("license", app.license);
            String str3 = "";
            if (app.icon.length() <= 0) {
                str = "";
            } else {
                str = "/api/tvapps/icon?id=".concat(app.id);
            }
            JSONObject put3 = put2.put("icon", str);
            int i = app.minSdk;
            JSONObject put4 = put3.put("min_sdk", i);
            List list2 = AppList.bases;
            ?? r6 = tv.token;
            String str4 = app.setup;
            boolean z2 = true;
            int i2 = tv.port;
            if (1 <= i2 && i2 < i) {
                str3 = "sdk";
            } else if (str4.length() == 0 && AppList.pick(app, r6) == null) {
                str3 = "abi";
            }
            JSONObject put5 = put4.put("why", str3);
            ArrayList plus = CollectionsKt.plus(MathKt.listOf(str2), (Iterable) app.also);
            if (!plus.isEmpty()) {
                Iterator it2 = plus.iterator();
                while (it2.hasNext()) {
                    if (set.contains((String) it2.next())) {
                        break;
                    }
                }
            }
            z2 = false;
            jSONArray.put(put5.put("installed", z2).put("setup", str4));
        }
        JSONArray jSONArray2 = new JSONArray();
        Iterator it3 = fetch.cats.iterator();
        while (it3.hasNext()) {
            AppList.Cat cat = (AppList.Cat) it3.next();
            jSONArray2.put(new JSONObject().put("id", cat.id).put("name", new JSONObject((Map) cat.name)));
        }
        JSONObject put6 = new JSONObject().put("updated", fetch.updated).put("cats", jSONArray2).put("apps", jSONArray).put("has_setup", set.contains("dev.tvremote.setup"));
        Intrinsics.checkNotNullExpressionValue(put6, "put(...)");
        return put6;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v11, types: [kotlin.collections.EmptyList] */
    /* JADX WARN: Type inference failed for: r1v15, types: [java.util.ArrayList] */
    public final Video.Way tv() {
        int i;
        Object obj;
        Object obj2;
        String obj3;
        Integer intOrNull;
        Adb adb = this.link.get();
        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
        List split$default = StringsKt.split$default(adb.shell(120000L, "getprop ro.build.version.sdk; getprop ro.product.cpu.abilist; echo @@; pm list packages"), new String[]{"@@"}, 0, 6);
        List lines = StringsKt.lines(StringsKt.trim((String) split$default.get(0)).toString());
        String str = (String) CollectionsKt.getOrNull(0, lines);
        if (str != null && (obj3 = StringsKt.trim(str).toString()) != null && (intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull(obj3)) != null) {
            i = intOrNull.intValue();
        } else {
            i = 0;
        }
        String str2 = (String) CollectionsKt.getOrNull(1, lines);
        if (str2 != null) {
            List split$default2 = StringsKt.split$default(str2, new String[]{","}, 0, 6);
            ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(split$default2));
            Iterator it = split$default2.iterator();
            while (it.hasNext()) {
                arrayList.add(StringsKt.trim((String) it.next()).toString());
            }
            obj = new ArrayList();
            Iterator it2 = arrayList.iterator();
            while (it2.hasNext()) {
                Object next = it2.next();
                if (((String) next).length() > 0) {
                    obj.add(next);
                }
            }
        } else {
            obj = EmptyList.INSTANCE;
        }
        if (1 < split$default.size()) {
            obj2 = split$default.get(1);
        } else {
            obj2 = "";
        }
        List lines2 = StringsKt.lines((CharSequence) obj2);
        ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(lines2));
        Iterator it3 = lines2.iterator();
        while (it3.hasNext()) {
            arrayList2.add(StringsKt.trim(StringsKt.removePrefix((String) it3.next(), "package:")).toString());
        }
        ArrayList arrayList3 = new ArrayList();
        Iterator it4 = arrayList2.iterator();
        while (it4.hasNext()) {
            Object next2 = it4.next();
            if (((String) next2).length() > 0) {
                arrayList3.add(next2);
            }
        }
        return new Video.Way(i, obj, CollectionsKt.toSet(arrayList3));
    }
}
