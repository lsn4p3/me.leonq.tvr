package dev.tvremote.core.manage;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.B64;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Diagnose;
import dev.tvremote.core.Fleet$$ExternalSyntheticLambda0;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.Mdns;
import dev.tvremote.core.adb.PmInstall;
import dev.tvremote.core.adb.TvShell;
import dev.tvremote.core.manage.Splits;
import dev.tvremote.core.ontv.Axml$$ExternalSyntheticLambda2;
import dev.tvremote.core.ontv.Rescue;
import dev.tvremote.core.ontv.Setup$$ExternalSyntheticLambda5;
import dev.tvremote.core.web.Cancel;
import dev.tvremote.core.web.Cancelled;
import dev.tvremote.core.web.HttpServer;
import dev.tvremote.home.HomeQr$$ExternalSyntheticLambda0;
import dev.tvremote.update.Ed25519;
import dev.tvremote.update.Release;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyList;
import kotlin.collections.EmptyMap;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.sequences.SequencesKt;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class InstallApi extends ManagePart {
    public final TvCopy copy;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public InstallApi(Ed25519.Pt core, TvCopy copy) {
        super(core);
        Intrinsics.checkNotNullParameter(core, "core");
        Intrinsics.checkNotNullParameter(copy, "copy");
        this.copy = copy;
    }

    public final JSONObject fetch(final boolean z, final String str) {
        String str2;
        String str3;
        String str4;
        Pattern compile = Pattern.compile("(?i)https?://\\S+");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        if (compile.matcher(str).matches()) {
            if (str.length() > 60) {
                String substring = str.substring(0, 60);
                Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
                str2 = substring;
            } else {
                str2 = str;
            }
            if (z) {
                str3 = "install ";
            } else {
                str3 = "download ";
            }
            String concat = str3.concat(str2);
            if (z) {
                str4 = "install";
            } else {
                str4 = "download";
            }
            return ManagePart.job$default(this, concat, str4, str2, new Function1() { // from class: dev.tvremote.core.manage.InstallApi$$ExternalSyntheticLambda8
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    Release release;
                    String str5;
                    long j;
                    Matcher matcher;
                    String str6;
                    int i;
                    String pmInstall;
                    String str7;
                    JSONObject j2 = (JSONObject) obj;
                    Intrinsics.checkNotNullParameter(j2, "j");
                    String str8 = str;
                    int i2 = 0;
                    boolean z2 = z;
                    String str9 = null;
                    if (z2 && StringsKt__StringsJVMKt.endsWith(str8, false, "/releases/latest/download/tv-setup.apk")) {
                        List list = Release.KEYS;
                        Release newer = MathKt.newer("0", "tv", "tv-setup.apk");
                        if (newer != null) {
                            release = newer;
                        } else {
                            throw new IOException("update list not signed by this project");
                        }
                    } else {
                        release = null;
                    }
                    if (release != null && (str7 = release.url) != null) {
                        str8 = str7;
                    }
                    InstallApi installApi = this;
                    installApi.getClass();
                    URL url = new URL(str8);
                    while (i2 < 6) {
                        URLConnection openConnection = url.openConnection();
                        Intrinsics.checkNotNull(openConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
                        HttpURLConnection httpURLConnection = (HttpURLConnection) openConnection;
                        httpURLConnection.setConnectTimeout(15000);
                        httpURLConnection.setReadTimeout(30000);
                        httpURLConnection.setRequestProperty("User-Agent", "tv-remote");
                        Cancel cancel = (Cancel) installApi.getCurrent().get();
                        if (cancel != null) {
                            cancel.onStop(new Setup$$ExternalSyntheticLambda5(2, httpURLConnection));
                        }
                        int responseCode = httpURLConnection.getResponseCode();
                        if (301 <= responseCode && responseCode < 309 && httpURLConnection.getResponseCode() != 304) {
                            str5 = httpURLConnection.getHeaderField("Location");
                        } else {
                            str5 = null;
                        }
                        if (str5 == null) {
                            try {
                                if (httpURLConnection.getResponseCode() == 200) {
                                    if (httpURLConnection.getContentLength() >= 0) {
                                        j = httpURLConnection.getContentLength();
                                    } else {
                                        j = -1;
                                    }
                                    String headerField = httpURLConnection.getHeaderField("Content-Disposition");
                                    if (headerField == null) {
                                        matcher = null;
                                    } else {
                                        matcher = Pattern.compile("filename\\*?=(?:UTF-8'')?\"?([^\";]+)").matcher(headerField);
                                    }
                                    if (matcher != null && matcher.find()) {
                                        str9 = URLDecoder.decode(matcher.group(1), "UTF-8");
                                    }
                                    if (str9 == null) {
                                        String path = httpURLConnection.getURL().getPath();
                                        Intrinsics.checkNotNull(path);
                                        String substring2 = path.substring(StringsKt.lastIndexOf$default(path, '/', 6) + 1);
                                        Intrinsics.checkNotNullExpressionValue(substring2, "substring(...)");
                                        str9 = URLDecoder.decode(substring2, "UTF-8");
                                    }
                                    String safeName$shared_release = TvPaths.safeName$shared_release(str9);
                                    String tmpApk = TvPaths.tmpApk();
                                    if (z2) {
                                        str6 = tmpApk;
                                    } else {
                                        str6 = "/sdcard/Download/" + safeName$shared_release;
                                    }
                                    j2.put("msg", safeName$shared_release);
                                    MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
                                    DigestInputStream digestInputStream = new DigestInputStream(httpURLConnection.getInputStream(), messageDigest);
                                    try {
                                        TvCopy tvCopy = installApi.copy;
                                        if (z2) {
                                            i = 2;
                                        } else {
                                            i = 1;
                                        }
                                        tvCopy.push(digestInputStream, j, str6, j2, i);
                                        digestInputStream.close();
                                        if (release != null) {
                                            try {
                                                Intrinsics.checkNotNull(messageDigest);
                                                release.check(messageDigest);
                                            } catch (IOException e) {
                                                throw e;
                                            }
                                        }
                                        if (!z2) {
                                            j2.put("dest", str6);
                                            pmInstall = "saved " + str6;
                                        } else {
                                            try {
                                                pmInstall = installApi.pmInstall(str6);
                                                installApi.sh("rm -f " + tmpApk);
                                            } finally {
                                                installApi.sh("rm -f " + tmpApk);
                                            }
                                        }
                                        httpURLConnection.disconnect();
                                        return pmInstall;
                                    } finally {
                                    }
                                } else {
                                    throw new IOException("HTTP " + httpURLConnection.getResponseCode());
                                }
                            } catch (Throwable th) {
                                httpURLConnection.disconnect();
                                throw th;
                            }
                        } else {
                            httpURLConnection.disconnect();
                            URL url2 = new URL(url, str5);
                            if (!Intrinsics.areEqual(url2.getProtocol(), "http") && !Intrinsics.areEqual(url2.getProtocol(), "https")) {
                                throw new IOException("only http/https links");
                            }
                            i2++;
                            url = url2;
                        }
                    }
                    throw new IOException("too many redirects");
                }
            }, 8);
        }
        throw new IllegalArgumentException("only http/https links");
    }

    /* JADX WARN: Finally extract failed */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r5v2, types: [dev.tvremote.core.manage.TvAppsApi$$ExternalSyntheticLambda1] */
    /* JADX WARN: Type inference failed for: r5v4 */
    public final String installCopy(HttpServer.Request request) {
        int i;
        String tmpApk;
        long j = 0;
        if (request.length > 0) {
            Cancel cancel = (Cancel) getCurrent().get();
            File createTempFile = File.createTempFile("tvr-copy-", ".apk");
            File createTempFile2 = File.createTempFile("tvr-copy-", ".out.apk");
            try {
                Intrinsics.checkNotNull(createTempFile);
                FileOutputStream fileOutputStream = new FileOutputStream(createTempFile);
                try {
                    byte[] bArr = new byte[65536];
                    long j2 = request.length;
                    while (true) {
                        if (j2 <= j) {
                            break;
                        }
                        if (cancel != null) {
                            cancel.check();
                        }
                        int read = request.body.read(bArr, 0, (int) Math.min(65536, j2));
                        if (read < 0) {
                            break;
                        }
                        fileOutputStream.write(bArr, 0, read);
                        j2 -= read;
                        j = 0;
                    }
                    fileOutputStream.close();
                    try {
                        Intrinsics.checkNotNull(createTempFile2);
                        File file = this.dir;
                        String tvAppsApi$$ExternalSyntheticLambda1 = new TvAppsApi$$ExternalSyntheticLambda1(cancel, 1);
                        String make = Rescue.make(createTempFile, createTempFile2, file, tvAppsApi$$ExternalSyntheticLambda1);
                        try {
                            tmpApk = TvPaths.tmpApk();
                        } catch (Throwable th) {
                            th = th;
                        }
                        try {
                            try {
                                FileInputStream fileInputStream = new FileInputStream(createTempFile2);
                                try {
                                    this.copy.push(fileInputStream, createTempFile2.length(), tmpApk, null, 2);
                                    fileInputStream.close();
                                    pmInstall(tmpApk);
                                    sh("rm -f " + tmpApk);
                                    Adb adb = this.link.get();
                                    if (StringsKt.contains(adb.shell(30000L, "monkey -p " + make + " -c android.intent.category.LEANBACK_LAUNCHER 1 2>&1; monkey -p " + make + " -c android.intent.category.LAUNCHER 1 2>&1"), "Events injected: 1", false)) {
                                        for (i = 0; i < 5; i++) {
                                            if (cancel != null) {
                                                cancel.check();
                                            }
                                            Thread.sleep(1000L);
                                        }
                                        if (Intrinsics.areEqual(StringsKt.trim(adb.shell(120000L, "pidof " + make + " 2>/dev/null; echo .")).toString(), ".")) {
                                            throw new IllegalArgumentException("copy closed: " + make);
                                        }
                                    }
                                    return make;
                                } catch (Throwable th2) {
                                    try {
                                        throw th2;
                                    } catch (Throwable th3) {
                                        MathKt.closeFinally(fileInputStream, th2);
                                        throw th3;
                                    }
                                }
                            } catch (Cancelled e) {
                                throw e;
                            } catch (IOException e2) {
                                e = e2;
                                throw new IllegalArgumentException(e.getMessage());
                            }
                        } catch (Cancelled e3) {
                            throw e3;
                        } catch (IOException e4) {
                            e = e4;
                            throw new IllegalArgumentException(e.getMessage());
                        } catch (Throwable th4) {
                            th = th4;
                            tvAppsApi$$ExternalSyntheticLambda1 = tmpApk;
                            sh("rm -f " + tvAppsApi$$ExternalSyntheticLambda1);
                            throw th;
                        }
                    } catch (Cancelled e5) {
                        throw e5;
                    } catch (IOException e6) {
                        throw new IllegalArgumentException(e6.getMessage());
                    }
                } catch (Throwable th5) {
                    try {
                        throw th5;
                    } catch (Throwable th6) {
                        MathKt.closeFinally(fileOutputStream, th5);
                        throw th6;
                    }
                }
            } finally {
                createTempFile.delete();
                createTempFile2.delete();
            }
        }
        throw new IllegalArgumentException("empty upload");
    }

    public final String installUpload(HttpServer.Request request) {
        if (request.length > 0) {
            String tmpApk = TvPaths.tmpApk();
            this.copy.push(request.body, request.length, tmpApk, null, 2);
            try {
                try {
                    String pmInstall = pmInstall(tmpApk);
                    sh("rm -f ".concat(tmpApk));
                    return pmInstall;
                } catch (Cancelled e) {
                    throw e;
                } catch (IOException e2) {
                    throw new IllegalArgumentException(e2.getMessage());
                }
            } catch (Throwable th) {
                sh("rm -f ".concat(tmpApk));
                throw th;
            }
        }
        throw new IllegalArgumentException("empty upload");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:205:0x0bb5  */
    /* JADX WARN: Removed duplicated region for block: B:209:0x0865  */
    /* JADX WARN: Removed duplicated region for block: B:213:0x0872  */
    /* JADX WARN: Removed duplicated region for block: B:224:0x0778  */
    /* JADX WARN: Removed duplicated region for block: B:267:0x0756  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x0671  */
    /* JADX WARN: Removed duplicated region for block: B:71:0x076a  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x0844  */
    /* JADX WARN: Removed duplicated region for block: B:79:0x0852  */
    /* JADX WARN: Removed duplicated region for block: B:83:0x08b0  */
    /* JADX WARN: Type inference failed for: r2v79, types: [java.util.Map, java.lang.Object] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final String pmInstall(String str) {
        Map map;
        int i;
        String str2;
        String str3;
        int i2;
        String str4;
        String str5;
        String str6;
        Adb adb;
        String str7;
        String str8;
        String str9;
        Diagnose.Real real;
        ArrayList arrayList;
        String str10;
        String str11;
        Adb adb2;
        String str12;
        Map map2;
        String str13;
        String str14;
        String str15;
        String str16;
        Collection list;
        String str17;
        Collection collection;
        String str18;
        int i3;
        String str19;
        String str20;
        Long longOrNull;
        Long longOrNull2;
        Adb adb3;
        long j;
        String fallback;
        boolean z;
        String obj;
        boolean z2;
        String str21;
        String str22;
        String m;
        int i4;
        Integer intOrNull;
        String str23;
        Map map3;
        int i5;
        Object obj2;
        int i6;
        Object obj3;
        String str24;
        String str25;
        String str26;
        Integer intOrNull2;
        String str27;
        Adb adb4;
        String str28;
        Splits.Entry entry;
        long j2;
        String str29 = "rm -f ";
        EmptyMap emptyMap = EmptyMap.INSTANCE;
        String str30 = " AndroidManifest.xml 2>/dev/null | base64";
        String str31 = "unzip -p ";
        Adb adb5 = this.link.get();
        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
        String q = Mdns.q(str);
        String str32 = "head -c 2 ";
        String str33 = " 2>/dev/null";
        String str34 = "PK";
        if (StringsKt__StringsJVMKt.startsWith(adb5.shell(120000L, ApkSigner$$ExternalSyntheticOutline0.m("head -c 2 ", q, " 2>/dev/null")), false, "PK")) {
            String obj4 = StringsKt.trim(adb5.shell(120000L, "stat -c %s " + q)).toString();
            try {
                Object obj5 = Apk.ATTR_IDS;
                int[] iArr = B64.INDEX;
                map = Apk.info(B64.decode(adb5.shell(120000L, "unzip -p " + q + " AndroidManifest.xml 2>/dev/null | base64")));
            } catch (IllegalArgumentException unused) {
                map = emptyMap;
            }
            Map map4 = map;
            ArrayList plus = CollectionsKt.plus(StringsKt.split$default(adb5.shell(120000L, "getprop ro.build.version.sdk; getprop ro.product.cpu.abilist; getprop persist.sys.locale; getprop ro.product.locale; wm density 2>/dev/null"), new String[]{"\n"}, 0, 6), (Iterable) ArraysKt.asList(new String[]{"", "", "", ""}));
            Integer intOrNull3 = StringsKt__StringNumberConversionsKt.toIntOrNull(StringsKt.trim((String) plus.get(0)).toString());
            if (intOrNull3 != null) {
                i = intOrNull3.intValue();
            } else {
                i = 0;
            }
            List split$default = StringsKt.split$default(StringsKt.trim((String) plus.get(1)).toString(), new String[]{","}, 0, 6);
            ArrayList arrayList2 = new ArrayList();
            for (Object obj6 : split$default) {
                if (((String) obj6).length() > 0) {
                    arrayList2.add(obj6);
                }
            }
            long j3 = 0;
            String str35 = "unzip -l ";
            ArrayList arrayList3 = arrayList2;
            String str36 = ".apk";
            if (!map4.isEmpty()) {
                str2 = "PK";
                str3 = "stat -c %s ";
                i2 = i;
                str4 = "rm -f ";
                str5 = "unzip -l ";
                str6 = " AndroidManifest.xml 2>/dev/null | base64";
                adb = adb5;
                str7 = "head -c 2 ";
                str8 = " 2>/dev/null";
                str9 = obj4;
            } else {
                Regex regex = Splits.LINE;
                str9 = obj4;
                str3 = "stat -c %s ";
                i2 = i;
                String listing = adb5.shell(60000L, ApkSigner$$ExternalSyntheticOutline0.m("unzip -l ", q, " 2>/dev/null | grep -E '\\.(apk|obb)$' || true"));
                Intrinsics.checkNotNullParameter(listing, "listing");
                List lines = StringsKt.lines(listing);
                ArrayList arrayList4 = new ArrayList();
                Iterator it = lines.iterator();
                while (it.hasNext()) {
                    Iterator it2 = it;
                    String str37 = str35;
                    MatcherMatchResult find = Splits.LINE.find((String) it.next(), 0);
                    if (find != null) {
                        String str38 = (String) ((MatcherMatchResult$groupValues$1) find.getGroupValues()).get(2);
                        str27 = str29;
                        Long longOrNull3 = StringsKt__StringNumberConversionsKt.toLongOrNull((String) ((MatcherMatchResult$groupValues$1) find.getGroupValues()).get(1));
                        if (longOrNull3 != null) {
                            long longValue = longOrNull3.longValue();
                            adb4 = adb5;
                            str28 = str32;
                            j2 = longValue;
                        } else {
                            adb4 = adb5;
                            str28 = str32;
                            j2 = 0;
                        }
                        entry = new Splits.Entry(j2, str38);
                    } else {
                        str27 = str29;
                        adb4 = adb5;
                        str28 = str32;
                        entry = null;
                    }
                    if (entry != null) {
                        arrayList4.add(entry);
                    }
                    adb5 = adb4;
                    str32 = str28;
                    it = it2;
                    str35 = str37;
                    str29 = str27;
                }
                str4 = str29;
                str5 = str35;
                Adb adb6 = adb5;
                String str39 = str32;
                Regex regex2 = Splits.LINE;
                if (!arrayList4.isEmpty()) {
                    Iterator it3 = arrayList4.iterator();
                    while (it3.hasNext()) {
                        Splits.Entry entry2 = (Splits.Entry) it3.next();
                        if (StringsKt__StringsJVMKt.endsWith(entry2.name, true, ".apk")) {
                            Regex regex3 = Splits.LINE;
                            if (!Splits.skipped(entry2.name)) {
                                String wm = CollectionsKt.joinToString$default(CollectionsKt.drop(4, plus), "\n", null, null, null, 62);
                                Intrinsics.checkNotNullParameter(wm, "wm");
                                MatcherMatchResult matcherMatchResult = (MatcherMatchResult) SequencesKt.lastOrNull(Regex.findAll$default(new Regex("density:\\s*(\\d+)"), wm));
                                if (matcherMatchResult != null && (str26 = (String) ((MatcherMatchResult$groupValues$1) matcherMatchResult.getGroupValues()).get(1)) != null && (intOrNull2 = StringsKt__StringNumberConversionsKt.toIntOrNull(str26)) != null) {
                                    i5 = intOrNull2.intValue();
                                } else {
                                    i5 = 0;
                                }
                                String[] strArr = {plus.get(2), plus.get(3)};
                                ArrayList arrayList5 = new ArrayList(2);
                                int i7 = 0;
                                while (true) {
                                    adb = adb6;
                                    if (i7 >= 2) {
                                        break;
                                    }
                                    String obj7 = StringsKt.trim(strArr[i7]).toString();
                                    String substringBefore = StringsKt.substringBefore(obj7, '-', obj7);
                                    String lowerCase = StringsKt.substringBefore(substringBefore, '_', substringBefore).toLowerCase(Locale.ROOT);
                                    Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                                    arrayList5.add(lowerCase);
                                    i7++;
                                    adb6 = adb;
                                    arrayList4 = arrayList4;
                                }
                                ArrayList arrayList6 = arrayList4;
                                ArrayList arrayList7 = new ArrayList();
                                Iterator it4 = arrayList5.iterator();
                                while (it4.hasNext()) {
                                    Object next = it4.next();
                                    int length = ((String) next).length();
                                    if (2 <= length && length < 4) {
                                        arrayList7.add(next);
                                    }
                                }
                                List distinct = CollectionsKt.distinct(arrayList7);
                                ArrayList arrayList8 = new ArrayList();
                                Iterator it5 = arrayList6.iterator();
                                while (true) {
                                    boolean hasNext = it5.hasNext();
                                    Regex regex4 = Splits.LINE;
                                    if (!hasNext) {
                                        break;
                                    }
                                    Object next2 = it5.next();
                                    Splits.Entry entry3 = (Splits.Entry) next2;
                                    Iterator it6 = it5;
                                    String str40 = str39;
                                    if (StringsKt__StringsJVMKt.endsWith(entry3.name, true, ".apk") && !Splits.skipped(entry3.name)) {
                                        arrayList8.add(next2);
                                    }
                                    it5 = it6;
                                    str39 = str40;
                                }
                                str7 = str39;
                                ArrayList arrayList9 = new ArrayList();
                                ArrayList arrayList10 = new ArrayList();
                                ArrayList arrayList11 = new ArrayList();
                                Iterator it7 = arrayList8.iterator();
                                while (true) {
                                    Iterator it8 = it7;
                                    if (!it7.hasNext()) {
                                        break;
                                    }
                                    Splits.Entry entry4 = (Splits.Entry) it8.next();
                                    int i8 = i5;
                                    String qualifier = Splits.qualifier(entry4.name);
                                    String str41 = str30;
                                    if (qualifier == null || StringsKt__StringsJVMKt.startsWith(qualifier, false, "master")) {
                                        str24 = str34;
                                        str25 = str33;
                                        arrayList9.add(entry4);
                                    } else if (StringsKt__StringsJVMKt.startsWith(qualifier, false, "arm") || StringsKt__StringsJVMKt.startsWith(qualifier, false, "x86") || StringsKt__StringsJVMKt.startsWith(qualifier, false, "mips") || StringsKt__StringsJVMKt.startsWith(qualifier, false, "riscv")) {
                                        str24 = str34;
                                        str25 = str33;
                                        arrayList10.add(new Pair(qualifier, entry4));
                                    } else {
                                        ?? r2 = Splits.DENSITY;
                                        boolean containsKey = r2.containsKey(qualifier);
                                        Set set = Splits.ANY;
                                        if (containsKey || set.contains(qualifier)) {
                                            str24 = str34;
                                            str25 = str33;
                                            if (set.contains(qualifier)) {
                                                arrayList9.add(entry4);
                                            } else {
                                                arrayList11.add(new Pair(MapsKt__MapsKt.getValue(r2, qualifier), entry4));
                                            }
                                        } else {
                                            str24 = str34;
                                            str25 = str33;
                                            if (Splits.LANG.matches(StringsKt__StringsJVMKt.replace$default(qualifier, '_', '-'))) {
                                                ArrayList plus2 = CollectionsKt.plus(distinct, "en");
                                                String lowerCase2 = StringsKt.substringBefore(qualifier, '_', qualifier).toLowerCase(Locale.ROOT);
                                                Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
                                                if (plus2.contains(lowerCase2)) {
                                                    arrayList9.add(entry4);
                                                }
                                            } else {
                                                arrayList9.add(entry4);
                                            }
                                        }
                                    }
                                    it7 = it8;
                                    i5 = i8;
                                    str30 = str41;
                                    str34 = str24;
                                    str33 = str25;
                                }
                                str2 = str34;
                                int i9 = i5;
                                str6 = str30;
                                str8 = str33;
                                if (!arrayList9.isEmpty()) {
                                    Iterator it9 = arrayList9.iterator();
                                    while (it9.hasNext()) {
                                        String qualifier2 = Splits.qualifier(((Splits.Entry) it9.next()).name);
                                        if (qualifier2 == null || StringsKt__StringsJVMKt.startsWith(qualifier2, false, "master")) {
                                            if (!arrayList10.isEmpty()) {
                                                ArrayList arrayList12 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList10));
                                                Iterator it10 = arrayList10.iterator();
                                                while (it10.hasNext()) {
                                                    arrayList12.add((String) ((Pair) it10.next()).first);
                                                }
                                                ArrayList arrayList13 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList3));
                                                Iterator it11 = arrayList3.iterator();
                                                while (it11.hasNext()) {
                                                    arrayList13.add(StringsKt__StringsJVMKt.replace$default((String) it11.next(), '-', '_'));
                                                }
                                                Iterator it12 = arrayList13.iterator();
                                                while (true) {
                                                    if (it12.hasNext()) {
                                                        obj3 = it12.next();
                                                        if (arrayList12.contains((String) obj3)) {
                                                            break;
                                                        }
                                                    } else {
                                                        obj3 = null;
                                                        break;
                                                    }
                                                }
                                                String str42 = (String) obj3;
                                                if (str42 != null) {
                                                    ArrayList arrayList14 = new ArrayList();
                                                    Iterator it13 = arrayList10.iterator();
                                                    while (it13.hasNext()) {
                                                        Object next3 = it13.next();
                                                        if (Intrinsics.areEqual(((Pair) next3).first, str42)) {
                                                            arrayList14.add(next3);
                                                        }
                                                    }
                                                    ArrayList arrayList15 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList14));
                                                    Iterator it14 = arrayList14.iterator();
                                                    while (it14.hasNext()) {
                                                        arrayList15.add((Splits.Entry) ((Pair) it14.next()).second);
                                                    }
                                                    arrayList9.addAll(arrayList15);
                                                } else {
                                                    throw new IOException(Census$$ExternalSyntheticOutline0.m("apk is built for ", StringsKt__StringsJVMKt.replace$default(CollectionsKt.joinToString$default(arrayList12, ",", null, null, null, 62), '_', '-'), ", the tv runs ", CollectionsKt.joinToString$default(arrayList3, ",", null, null, null, 62)));
                                                }
                                            }
                                            arrayList = arrayList3;
                                            if (!arrayList11.isEmpty()) {
                                                if (i9 > 0) {
                                                    i6 = i9;
                                                } else {
                                                    i6 = 320;
                                                }
                                                ArrayList arrayList16 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList11));
                                                Iterator it15 = arrayList11.iterator();
                                                while (it15.hasNext()) {
                                                    arrayList16.add(Integer.valueOf(((Number) ((Pair) it15.next()).first).intValue()));
                                                }
                                                Iterator it16 = CollectionsKt.distinct(arrayList16).iterator();
                                                if (it16.hasNext()) {
                                                    Object next4 = it16.next();
                                                    while (it16.hasNext()) {
                                                        Object next5 = it16.next();
                                                        Number number = (Number) next4;
                                                        Number number2 = (Number) next5;
                                                        Iterator it17 = it16;
                                                        int compareValues = MathKt.compareValues(Integer.valueOf(Math.abs(number.intValue() - i6)), Integer.valueOf(Math.abs(number2.intValue() - i6)));
                                                        if (compareValues == 0) {
                                                            compareValues = MathKt.compareValues(Integer.valueOf(number2.intValue()), Integer.valueOf(number.intValue()));
                                                        }
                                                        if (compareValues > 0) {
                                                            next4 = next5;
                                                        }
                                                        it16 = it17;
                                                    }
                                                    int intValue = ((Number) next4).intValue();
                                                    ArrayList arrayList17 = new ArrayList();
                                                    Iterator it18 = arrayList11.iterator();
                                                    while (it18.hasNext()) {
                                                        Object next6 = it18.next();
                                                        if (((Number) ((Pair) next6).first).intValue() == intValue) {
                                                            arrayList17.add(next6);
                                                        }
                                                    }
                                                    ArrayList arrayList18 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList17));
                                                    Iterator it19 = arrayList17.iterator();
                                                    while (it19.hasNext()) {
                                                        arrayList18.add((Splits.Entry) ((Pair) it19.next()).second);
                                                    }
                                                    arrayList9.addAll(arrayList18);
                                                } else {
                                                    throw new NoSuchElementException();
                                                }
                                            }
                                            Iterator it20 = arrayList9.iterator();
                                            while (true) {
                                                if (it20.hasNext()) {
                                                    obj2 = it20.next();
                                                    if (Splits.qualifier(((Splits.Entry) obj2).name) == null) {
                                                        break;
                                                    }
                                                } else {
                                                    obj2 = null;
                                                    break;
                                                }
                                            }
                                            Splits.Entry entry5 = (Splits.Entry) obj2;
                                            if (entry5 == null) {
                                                Iterator it21 = arrayList9.iterator();
                                                while (it21.hasNext()) {
                                                    entry5 = (Splits.Entry) it21.next();
                                                    String qualifier3 = Splits.qualifier(entry5.name);
                                                    Intrinsics.checkNotNull(qualifier3);
                                                    if (StringsKt__StringsJVMKt.startsWith(qualifier3, false, "master")) {
                                                    }
                                                }
                                                throw new NoSuchElementException("Collection contains no element matching the predicate.");
                                            }
                                            List listOf = MathKt.listOf(entry5);
                                            ArrayList arrayList19 = new ArrayList();
                                            Iterator it22 = arrayList9.iterator();
                                            while (it22.hasNext()) {
                                                Object next7 = it22.next();
                                                if (((Splits.Entry) next7) != entry5) {
                                                    arrayList19.add(next7);
                                                }
                                            }
                                            ArrayList plus3 = CollectionsKt.plus(listOf, (Iterable) arrayList19);
                                            ArrayList arrayList20 = new ArrayList();
                                            Iterator it23 = arrayList6.iterator();
                                            while (it23.hasNext()) {
                                                Object next8 = it23.next();
                                                if (Splits.OBB.matches(((Splits.Entry) next8).name)) {
                                                    arrayList20.add(next8);
                                                }
                                            }
                                            real = new Diagnose.Real(plus3, arrayList20);
                                            if (real != null) {
                                                str10 = " > ";
                                                str11 = " ";
                                                adb2 = adb;
                                                str12 = str8;
                                                map2 = map4;
                                            } else {
                                                Regex regex5 = Splits.LINE;
                                                String pattern = Splits.pattern(((Splits.Entry) ((ArrayList) real.link).get(0)).name);
                                                String str43 = "/data/local/tmp/tvremote-base-" + TvPaths.tmpN.incrementAndGet() + ".apk";
                                                try {
                                                    ConcurrentHashMap concurrentHashMap2 = Adb.ASKING;
                                                    String q2 = Mdns.q(pattern);
                                                    StringBuilder sb = new StringBuilder();
                                                    sb.append("unzip -p ");
                                                    sb.append(q);
                                                    sb.append(" ");
                                                    sb.append(q2);
                                                    sb.append(" > ");
                                                    sb.append(str43);
                                                    str12 = str8;
                                                    sb.append(str12);
                                                    adb2 = adb;
                                                    try {
                                                        adb2.shell(600000L, sb.toString());
                                                        if (StringsKt__StringsJVMKt.startsWith(adb2.shell(120000L, str7 + str43 + str12), false, str2)) {
                                                            try {
                                                                Object obj8 = Apk.ATTR_IDS;
                                                                int[] iArr2 = B64.INDEX;
                                                                str10 = " > ";
                                                                str11 = " ";
                                                                try {
                                                                    map3 = Apk.info(B64.decode(adb2.shell(120000L, "unzip -p " + str43 + str6)));
                                                                } catch (IllegalArgumentException unused2) {
                                                                    map3 = emptyMap;
                                                                    map2 = map3;
                                                                    adb2.shell(120000L, str4 + str43);
                                                                    String str44 = (String) map2.get("package");
                                                                    String str45 = "/";
                                                                    if (real != null) {
                                                                    }
                                                                    collection = list;
                                                                    Object obj9 = Apk.ATTR_IDS;
                                                                    str18 = (String) map2.get("minSdkVersion");
                                                                    if (str18 == null) {
                                                                    }
                                                                    i3 = 0;
                                                                    if (i2 <= 0) {
                                                                    }
                                                                    if (!collection.isEmpty()) {
                                                                    }
                                                                    str19 = null;
                                                                    if (str19 != null) {
                                                                    }
                                                                }
                                                            } catch (IllegalArgumentException unused3) {
                                                                str10 = " > ";
                                                                str11 = " ";
                                                            }
                                                            map2 = map3;
                                                            adb2.shell(120000L, str4 + str43);
                                                        } else {
                                                            str23 = str4;
                                                            try {
                                                                throw new IOException("bundle:locked");
                                                            } catch (Throwable th) {
                                                                th = th;
                                                                adb2.shell(120000L, str23 + str43);
                                                                throw th;
                                                            }
                                                        }
                                                    } catch (Throwable th2) {
                                                        th = th2;
                                                        str23 = str4;
                                                    }
                                                } catch (Throwable th3) {
                                                    th = th3;
                                                    str23 = str4;
                                                    adb2 = adb;
                                                }
                                            }
                                            String str442 = (String) map2.get("package");
                                            String str452 = "/";
                                            if (real != null) {
                                                list = EmptyList.INSTANCE;
                                                str14 = str10;
                                                str15 = "/";
                                                str16 = str12;
                                                str13 = str11;
                                            } else {
                                                Object obj10 = Apk.ATTR_IDS;
                                                str13 = str11;
                                                List split = new Regex("\\s+").split(adb2.shell(120000L, ApkSigner$$ExternalSyntheticOutline0.m(str5, q, " 2>/dev/null | grep -o 'lib/[^ ]*\\.so' || true")), 0);
                                                ArrayList arrayList21 = new ArrayList();
                                                Iterator it24 = split.iterator();
                                                while (it24.hasNext()) {
                                                    Object next9 = it24.next();
                                                    String str46 = str10;
                                                    String str47 = (String) next9;
                                                    Iterator it25 = it24;
                                                    String str48 = str12;
                                                    if (StringsKt__StringsJVMKt.startsWith(str47, false, "lib/") && StringsKt__StringsJVMKt.endsWith(str47, false, ".so")) {
                                                        str17 = str452;
                                                        int i10 = 0;
                                                        int i11 = 0;
                                                        while (i10 < str47.length()) {
                                                            String str49 = str47;
                                                            if (str47.charAt(i10) == '/') {
                                                                i11++;
                                                            }
                                                            i10++;
                                                            str47 = str49;
                                                        }
                                                        if (i11 >= 2) {
                                                            arrayList21.add(next9);
                                                        }
                                                    } else {
                                                        str17 = str452;
                                                    }
                                                    it24 = it25;
                                                    str10 = str46;
                                                    str452 = str17;
                                                    str12 = str48;
                                                }
                                                str14 = str10;
                                                str15 = str452;
                                                str16 = str12;
                                                ArrayList arrayList22 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList21));
                                                Iterator it26 = arrayList21.iterator();
                                                while (it26.hasNext()) {
                                                    arrayList22.add((String) StringsKt.split$default((String) it26.next(), new String[]{str15}, 0, 6).get(1));
                                                }
                                                TreeSet treeSet = new TreeSet();
                                                CollectionsKt.toCollection(arrayList22, treeSet);
                                                list = CollectionsKt.toList(treeSet);
                                            }
                                            collection = list;
                                            Object obj92 = Apk.ATTR_IDS;
                                            str18 = (String) map2.get("minSdkVersion");
                                            if (str18 == null && (intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull(str18)) != null) {
                                                i3 = intOrNull.intValue();
                                            } else {
                                                i3 = 0;
                                            }
                                            if (i2 <= 0 && i3 > (i4 = i2)) {
                                                str19 = Census$$ExternalSyntheticOutline0.m("apk needs sdk ", i3, ", the tv has sdk ", i4);
                                            } else {
                                                if (!collection.isEmpty() && !arrayList.isEmpty()) {
                                                    if (!collection.isEmpty()) {
                                                        Iterator it27 = collection.iterator();
                                                        while (it27.hasNext()) {
                                                            if (arrayList.contains((String) it27.next())) {
                                                            }
                                                        }
                                                    }
                                                    str19 = Census$$ExternalSyntheticOutline0.m("apk is built for ", CollectionsKt.joinToString$default(collection, ",", null, null, null, 62), ", the tv runs ", CollectionsKt.joinToString$default(arrayList, ",", null, null, null, 62));
                                                }
                                                str19 = null;
                                                break;
                                            }
                                            if (str19 != null) {
                                                if (str442 == null) {
                                                    str20 = null;
                                                } else {
                                                    Regex regex6 = Splits.LINE;
                                                    String have = adb2.shell(120000L, ApkSigner$$ExternalSyntheticOutline0.m("dumpsys package ", str442, " 2>/dev/null | grep -m1 versionCode=; echo ."));
                                                    String str50 = (String) map2.get("versionCode");
                                                    Intrinsics.checkNotNullParameter(have, "have");
                                                    Pattern compile = Pattern.compile("versionCode=(\\d+)");
                                                    Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                                                    Matcher matcher = compile.matcher(have);
                                                    Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
                                                    MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, have);
                                                    if (access$findNext != null && (longOrNull = StringsKt__StringNumberConversionsKt.toLongOrNull((String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1))) != null) {
                                                        long longValue2 = longOrNull.longValue();
                                                        if (str50 != null && (longOrNull2 = StringsKt__StringNumberConversionsKt.toLongOrNull(str50)) != null) {
                                                            long longValue3 = longOrNull2.longValue();
                                                            if (longValue3 <= longValue2) {
                                                                if (longValue3 == longValue2) {
                                                                    str20 = "same";
                                                                } else {
                                                                    str20 = "older";
                                                                }
                                                            }
                                                        }
                                                        str20 = "update";
                                                    } else {
                                                        str20 = "new";
                                                    }
                                                }
                                                Cancel cancel = (Cancel) getCurrent().get();
                                                if (cancel != null) {
                                                    cancel.check();
                                                }
                                                if (real != null) {
                                                    ArrayList arrayList23 = (ArrayList) real.link;
                                                    ArrayList arrayList24 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList23));
                                                    Iterator it28 = arrayList23.iterator();
                                                    int i12 = 0;
                                                    while (it28.hasNext()) {
                                                        Object next10 = it28.next();
                                                        int i13 = i12 + 1;
                                                        if (i12 >= 0) {
                                                            Splits.Entry entry6 = (Splits.Entry) next10;
                                                            ConcurrentHashMap concurrentHashMap3 = Adb.ASKING;
                                                            Regex regex7 = Splits.LINE;
                                                            Iterator it29 = it28;
                                                            String str51 = str13;
                                                            String m2 = Census$$ExternalSyntheticOutline0.m(str31, q, str51, Mdns.q(Splits.pattern(entry6.name)));
                                                            if (i12 == 0) {
                                                                m = "base.apk";
                                                                str22 = str31;
                                                            } else {
                                                                str22 = str31;
                                                                m = ApkSigner$$ExternalSyntheticOutline0.m("split", i12, str36);
                                                            }
                                                            String str52 = str36;
                                                            arrayList24.add(new PmInstall.Part(entry6.size, m2, m));
                                                            it28 = it29;
                                                            i12 = i13;
                                                            str31 = str22;
                                                            str36 = str52;
                                                            str13 = str51;
                                                        } else {
                                                            CollectionsKt__CollectionsKt.throwIndexOverflow();
                                                            throw null;
                                                        }
                                                    }
                                                    String str53 = str13;
                                                    String bundle = PmInstall.bundle(new Fleet$$ExternalSyntheticLambda0(adb2, 4), arrayList24, new TvAppsApi$$ExternalSyntheticLambda1(cancel, 2));
                                                    if (cancel != null) {
                                                        cancel.check();
                                                    }
                                                    if (StringsKt.contains(bundle, "Success", false)) {
                                                        Iterator it30 = ((ArrayList) real.bindUdp).iterator();
                                                        while (it30.hasNext()) {
                                                            Splits.Entry e = (Splits.Entry) it30.next();
                                                            Regex regex8 = Splits.LINE;
                                                            Intrinsics.checkNotNullParameter(e, "e");
                                                            Regex regex9 = Splits.OBB;
                                                            String str54 = e.name;
                                                            MatcherMatchResult find2 = regex9.find(str54, 0);
                                                            if (find2 != null) {
                                                                str21 = (String) ((MatcherMatchResult$groupValues$1) find2.getGroupValues()).get(1);
                                                            } else {
                                                                str21 = null;
                                                            }
                                                            String m3 = ApkSigner$$ExternalSyntheticOutline0.m("/sdcard/Android/obb/", str21);
                                                            String str55 = str15;
                                                            String m4 = Census$$ExternalSyntheticOutline0.m(m3, str55, StringsKt.substringAfterLast(str54, '/', str54));
                                                            ConcurrentHashMap concurrentHashMap4 = Adb.ASKING;
                                                            String q3 = Mdns.q(m3);
                                                            String q4 = Mdns.q(Splits.pattern(str54));
                                                            String q5 = Mdns.q(m4);
                                                            Iterator it31 = it30;
                                                            String str56 = bundle;
                                                            StringBuilder sb2 = new StringBuilder("mkdir -p ");
                                                            sb2.append(q3);
                                                            sb2.append(" && unzip -p ");
                                                            sb2.append(q);
                                                            sb2.append(str53);
                                                            sb2.append(q4);
                                                            String str57 = str14;
                                                            sb2.append(str57);
                                                            sb2.append(q5);
                                                            adb2.shell(1800000L, sb2.toString());
                                                            Long longOrNull4 = StringsKt__StringNumberConversionsKt.toLongOrNull(StringsKt.trim(adb2.shell(120000L, ApkSigner$$ExternalSyntheticOutline0.m(str3, Mdns.q(m4), str16))).toString());
                                                            if (longOrNull4 != null && longOrNull4.longValue() == e.size) {
                                                                str14 = str57;
                                                                str15 = str55;
                                                                it30 = it31;
                                                                bundle = str56;
                                                            } else {
                                                                throw new IOException("copy to the TV incomplete");
                                                            }
                                                        }
                                                    }
                                                    adb3 = adb2;
                                                    fallback = bundle;
                                                    j = 120000;
                                                } else {
                                                    String str58 = str9;
                                                    Adb.Stream exec = adb2.exec(Census$$ExternalSyntheticOutline0.m("cat ", q, " | pm install -r -S ", str58, " 2>&1"));
                                                    if (cancel != null) {
                                                        cancel.onStop(new TvCopy$$ExternalSyntheticLambda1(exec, 1));
                                                    }
                                                    try {
                                                        String readAll = exec.readAll(600000L);
                                                        if (cancel != null) {
                                                            cancel.check();
                                                        }
                                                        Regex regex10 = PmInstall.REFUSED;
                                                        Fleet$$ExternalSyntheticLambda0 fleet$$ExternalSyntheticLambda0 = new Fleet$$ExternalSyntheticLambda0(adb2, 5);
                                                        Long longOrNull5 = StringsKt__StringNumberConversionsKt.toLongOrNull(str58);
                                                        if (longOrNull5 != null) {
                                                            j3 = longOrNull5.longValue();
                                                        }
                                                        adb3 = adb2;
                                                        j = 120000;
                                                        fallback = PmInstall.fallback(readAll, fleet$$ExternalSyntheticLambda0, q, j3, new TvAppsApi$$ExternalSyntheticLambda1(cancel, 3));
                                                    } finally {
                                                        exec.close();
                                                    }
                                                }
                                                if (cancel != null) {
                                                    cancel.check();
                                                }
                                                if (!StringsKt.contains(fallback, "Success", false) && str442 != null) {
                                                    Pattern compile2 = Pattern.compile("INSTALL_FAILED_VERSION_DOWNGRADE|INSTALL_FAILED_UPDATE_INCOMPATIBLE|signatures do not match");
                                                    Intrinsics.checkNotNullExpressionValue(compile2, "compile(...)");
                                                    if (compile2.matcher(fallback).find()) {
                                                        List lines2 = StringsKt.lines(adb3.shell(j, ApkSigner$$ExternalSyntheticOutline0.m("pm list packages -s ", str442, " 2>/dev/null; echo .")));
                                                        if (!lines2.isEmpty()) {
                                                            Iterator it32 = lines2.iterator();
                                                            while (it32.hasNext()) {
                                                                if (Intrinsics.areEqual(StringsKt.trim((String) it32.next()).toString(), "package:".concat(str442))) {
                                                                    z2 = true;
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                        z2 = false;
                                                        if (z2) {
                                                            throw new IOException("builtin app: ".concat(str442));
                                                        }
                                                    }
                                                }
                                                if (!StringsKt.contains(fallback, "Success", false)) {
                                                    if (StringsKt.trim(fallback).toString().length() == 0) {
                                                        z = true;
                                                    } else {
                                                        z = false;
                                                    }
                                                    if (z) {
                                                        obj = "install failed";
                                                    } else {
                                                        obj = StringsKt.trim(fallback).toString();
                                                    }
                                                    throw new IOException(obj);
                                                }
                                                if (str442 != null) {
                                                    Thread.sleep(3000L);
                                                    if (!StringsKt.contains(adb3.shell(j, "pm path " + str442 + " 2>/dev/null; echo ."), "package:", false)) {
                                                        throw new IOException("removed by the TV right after install: ".concat(str442));
                                                    }
                                                }
                                                if (str20 == null) {
                                                    return "installed";
                                                }
                                                return "installed ".concat(str20);
                                            }
                                            throw new IOException(str19);
                                        }
                                    }
                                }
                                throw new IOException("bundle:missing");
                            }
                        }
                        arrayList3 = arrayList3;
                        adb6 = adb6;
                        arrayList4 = arrayList4;
                        str39 = str39;
                        str30 = str30;
                        str34 = str34;
                        str33 = str33;
                    }
                }
                str2 = str34;
                adb = adb6;
                str7 = str39;
                str6 = str30;
                str8 = str33;
            }
            arrayList = arrayList3;
            real = null;
            if (real != null) {
            }
            String str4422 = (String) map2.get("package");
            String str4522 = "/";
            if (real != null) {
            }
            collection = list;
            Object obj922 = Apk.ATTR_IDS;
            str18 = (String) map2.get("minSdkVersion");
            if (str18 == null) {
            }
            i3 = 0;
            if (i2 <= 0) {
            }
            if (!collection.isEmpty()) {
                if (!collection.isEmpty()) {
                }
                str19 = Census$$ExternalSyntheticOutline0.m("apk is built for ", CollectionsKt.joinToString$default(collection, ",", null, null, null, 62), ", the tv runs ", CollectionsKt.joinToString$default(arrayList, ",", null, null, null, 62));
                if (str19 != null) {
                }
            }
            str19 = null;
            if (str19 != null) {
            }
        } else {
            throw new IOException("not an APK file");
        }
    }

    public final void restore(HttpServer.Request request) {
        if (request.length > 0) {
            String format = String.format("/data/local/tmp/tvr-rs-%08x.tar", Arrays.copyOf(new Object[]{Integer.valueOf(new Random().nextInt())}, 1));
            this.copy.push(request.body, request.length, format, null, 2);
            Adb adb = this.link.get();
            try {
                TvShell tvShell = TvShell.INSTANCE;
                Pattern compile = Pattern.compile("/data/local/tmp/tvr-rs-[0-9a-f]{8}\\.tar");
                Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                if (compile.matcher(format).matches()) {
                    String shell = adb.shell(600000L, ApkSigner$$ExternalSyntheticOutline0.m("t=", format, "; d=${t%.tar}; rm -rf $d; mkdir -p $d && cd $d && tar -xf $t 2>/dev/null; ls apk/*.apk >/dev/null 2>&1 || { echo 'not a backup'; cd /; rm -rf $d $t; exit; }; p=$(cat package.txt 2>/dev/null); echo \"$p\" | grep -qE '^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z_][A-Za-z0-9_]*)+$' || p=; s=$(pm install-create -r | tr -dc 0-9); for f in apk/*.apk; do cat $f | pm install-write -S $(stat -c %s $f) $s ${f##*/} - >/dev/null; done; pm install-commit $s 2>&1; [ -n \"$p\" ] && for k in obb data; do [ -d $k ] && mkdir -p /sdcard/Android/$k/$p && cp -R $k/. /sdcard/Android/$k/$p/; done; cd /; rm -rf $d $t; echo package $p"));
                    adb.shell(120000L, "rm -f ".concat(format));
                    if (!StringsKt.contains(shell, "Success", false)) {
                        String takeLast = StringsKt.takeLast(StringsKt.trim(shell).toString(), 300);
                        if (takeLast.length() == 0) {
                            takeLast = "restore failed";
                        }
                        throw new IllegalArgumentException(takeLast);
                    }
                    String obj = StringsKt.trim(shell).toString();
                    String obj2 = StringsKt.trim(StringsKt.removePrefix(StringsKt.substringAfterLast(obj, '\n', obj), "package")).toString();
                    if (ManagePart.PKG.matcher(obj2).matches()) {
                        Thread.sleep(3000L);
                        if (!StringsKt.contains(adb.shell(120000L, "pm path " + obj2 + " 2>/dev/null; echo ."), "package:", false)) {
                            throw new IllegalArgumentException(ApkSigner$$ExternalSyntheticOutline0.m("removed by the TV right after install: ", obj2));
                        }
                        return;
                    }
                    return;
                }
                throw new IllegalArgumentException("bad restore path");
            } catch (Throwable th) {
                String concat = "rm -f ".concat(format);
                ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                adb.shell(120000L, concat);
                throw th;
            }
        }
        throw new IllegalArgumentException("empty upload");
    }

    @Override // dev.tvremote.core.manage.ManagePart
    public final HttpServer.Response route(String str, boolean z, HttpServer.Request request) {
        if (z) {
            int hashCode = str.hashCode();
            if (hashCode != 97322682) {
                if (hashCode != 932584456) {
                    if (hashCode == 1957569947 && str.equals("install")) {
                        String optString = request.json(65536).optString("url");
                        Intrinsics.checkNotNullExpressionValue(optString, "optString(...)");
                        JSONObject fetch = fetch(true, optString);
                        HttpServer.Response response = new HttpServer.Response();
                        response.status = 200;
                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = HttpServer.trusted;
                        response.body = Census$$ExternalSyntheticOutline0.m("toString(...)", fetch);
                        return response;
                    }
                    return null;
                }
                if (str.equals("file/install")) {
                    AtomicLong atomicLong = TvPaths.tmpN;
                    String optString2 = request.json(65536).optString("path");
                    if (optString2 != null && !StringsKt.isBlank(optString2)) {
                        String safePath$shared_release = TvPaths.safePath$shared_release(optString2);
                        String substring = safePath$shared_release.substring(StringsKt.lastIndexOf$default(safePath$shared_release, '/', 6) + 1);
                        Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
                        String concat = "install ".concat(substring);
                        String substring2 = safePath$shared_release.substring(StringsKt.lastIndexOf$default(safePath$shared_release, '/', 6) + 1);
                        Intrinsics.checkNotNullExpressionValue(substring2, "substring(...)");
                        JSONObject job$default = ManagePart.job$default(this, concat, "install", substring2, new Axml$$ExternalSyntheticLambda2(this, safePath$shared_release), 8);
                        HttpServer.Response response2 = new HttpServer.Response();
                        response2.status = 200;
                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda02 = HttpServer.trusted;
                        response2.body = Census$$ExternalSyntheticOutline0.m("toString(...)", job$default);
                        return response2;
                    }
                    throw new IllegalArgumentException("path missing");
                }
                return null;
            }
            if (!str.equals("fetch")) {
                return null;
            }
            String optString3 = request.json(65536).optString("url");
            Intrinsics.checkNotNullExpressionValue(optString3, "optString(...)");
            JSONObject fetch2 = fetch(false, optString3);
            HttpServer.Response response3 = new HttpServer.Response();
            response3.status = 200;
            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda03 = HttpServer.trusted;
            response3.body = Census$$ExternalSyntheticOutline0.m("toString(...)", fetch2);
            return response3;
        }
        return null;
    }
}
