package dev.tvremote.core.manage;

import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Fleet$$ExternalSyntheticLambda0;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.ontv.Bloat$$ExternalSyntheticLambda1;
import dev.tvremote.core.ontv.Games;
import dev.tvremote.core.ontv.Power;
import dev.tvremote.core.ontv.Power$$ExternalSyntheticLambda2;
import dev.tvremote.core.ontv.Power$deaths$$inlined$sortBy$1;
import dev.tvremote.core.ontv.Power$deaths$D;
import dev.tvremote.core.ontv.RemoteLabels;
import dev.tvremote.core.ontv.Sensors;
import dev.tvremote.core.ontv.SetupFiles;
import dev.tvremote.core.ontv.SetupNeed;
import dev.tvremote.core.web.HttpServer;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda4;
import dev.tvremote.home.HomeQr$$ExternalSyntheticLambda0;
import dev.tvremote.phone.WorkService;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.CollectionsKt__MutableCollectionsJVMKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgression;
import kotlin.sequences.GeneratorSequence;
import kotlin.sequences.GeneratorSequence$iterator$1;
import kotlin.sequences.SequencesKt;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsJVMKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class HealthApi extends ManagePart {
    public static final String HEALTH_LIVE_NOW = StringsKt__StringsJVMKt.replaceFirst$default("head -1 /proc/stat; sleep 0.6; head -1 /proc/stat; printf '\\043~\\043\\n'; grep -E '^(MemTotal|MemAvailable):' /proc/meminfo; printf '\\043~\\043\\n'; df -k /data | tail -1; printf '\\043~\\043\\n'; cat /proc/uptime; printf '\\043~\\043\\n'; top -n 1 -b -m 7 -o %CPU,%MEM,ARGS -s 1 | tail -7; printf '\\043~\\043\\n'; dumpsys power | grep -m1 -o 'mWakefulness=[A-Za-z]*'; dumpsys activity activities | grep -m1 -E 'mResumedActivity|topResumedActivity'; printf '\\043~\\043\\n'; dumpsys thermalservice 2>/dev/null | sed -n '/^Thermal Status/p;/^Current temperatures from HAL/,/^Current cooling/p'; printf '\\043~\\043\\n'; for z in /sys/class/thermal/thermal_zone*; do echo \"$(cat $z/type 2>/dev/null) $(cat $z/temp 2>/dev/null)\"; done 2>/dev/null; printf '\\043~\\043\\n'; for f in /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage /sys/class/kgsl/kgsl-3d0/gpubusy /sys/kernel/gpu/gpu_busy /sys/module/ged/parameters/gpu_loading /sys/kernel/ged/hal/gpu_utilization; do [ -r $f ] && echo \"$f:$(cat $f 2>/dev/null)\"; done 2>/dev/null; printf '\\043~\\043\\n'; cat /proc/net/dev", "head -1 /proc/stat; sleep 0.6; ", "");
    public volatile Triple cpuWas;
    public Triple netLast;
    public long nightlyAt;
    public JSONObject nightlyIs;
    public Adb nightlyOf;
    public long slowAt;
    public Adb slowFor;
    public List slowParts;

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:219:0x0889 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:349:0x07fd A[SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r11v15 */
    /* JADX WARN: Type inference failed for: r11v16 */
    /* JADX WARN: Type inference failed for: r11v17, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r8v2, types: [java.lang.Object[], java.lang.String[]] */
    /* JADX WARN: Type inference failed for: r9v22, types: [java.util.Map, java.lang.Object] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final JSONObject health() {
        int i;
        char c;
        List list;
        String str;
        Object valueOf;
        Object valueOf2;
        boolean z;
        Integer num;
        JSONObject jSONObject;
        Integer num2;
        long[] jArr;
        Adb adb;
        JSONObject jSONObject2;
        String str2;
        String str3;
        String str4;
        String str5;
        JSONObject jSONObject3;
        String str6;
        Long longOrNull;
        long j;
        int i2;
        Long l;
        Integer num3;
        int intValue;
        Long longOrNull2;
        Integer num4;
        String str7;
        String label;
        int i3;
        String str8;
        Adb adb2 = this.link.get();
        Triple triple = this.cpuWas;
        if (triple == null || triple.first != adb2 || System.currentTimeMillis() - ((Number) triple.second).longValue() >= 30000) {
            triple = null;
        }
        long currentTimeMillis = System.currentTimeMillis();
        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
        adb2.shell(120000L, ":");
        long currentTimeMillis2 = System.currentTimeMillis() - currentTimeMillis;
        synchronized (this) {
            try {
                long currentTimeMillis3 = System.currentTimeMillis();
                if (this.slowFor == adb2) {
                    i = 2;
                    c = 1;
                    if (currentTimeMillis3 - this.slowAt <= 60000) {
                        if (this.slowParts.isEmpty()) {
                        }
                        list = this.slowParts;
                    }
                } else {
                    i = 2;
                    c = 1;
                }
                this.slowParts = ArraysKt.take(Fleet.jsplit(adb2.shell(120000L, "getprop ro.product.manufacturer; getprop ro.product.model; getprop ro.build.version.release; getprop ro.build.version.sdk; getprop ro.build.version.security_patch; getprop ro.board.platform; getprop ro.product.cpu.abi; cat /sys/devices/system/cpu/present; printf '\\043~\\043\\n'; wm size; wm density; dumpsys display | grep -m1 -o 'fps=[0-9.]*'; printf '\\043~\\043\\n'; dumpsys wifi | grep -m1 mWifiInfo; printf '\\043~\\043\\n'; ip -o -4 addr show; printf '\\043~\\043\\n'; dumpsys bluetooth_manager 2>/dev/null | grep -m1 -E '^ *enabled:'; dumpsys bluetooth_manager 2>/dev/null | sed -n '/Bonded devices:/,/^ *$/p'; echo '#in'; dumpsys input 2>/dev/null | awk '/^    [0-9]+: /{sub(/^    [0-9]+: /,\"\");n=$0} /Identifier: bus=0x0005/{print n\"|\"$0}'") + "#~##~##~##~#", -1, "#~#"), 5);
                this.slowFor = adb2;
                this.slowAt = currentTimeMillis3;
                list = this.slowParts;
            } catch (Throwable th) {
                th = th;
                while (true) {
                    try {
                        break;
                    } catch (Throwable th2) {
                        th = th2;
                    }
                }
                throw th;
            }
        }
        if (triple != null) {
            str = HEALTH_LIVE_NOW;
        } else {
            str = "head -1 /proc/stat; sleep 0.6; head -1 /proc/stat; printf '\\043~\\043\\n'; grep -E '^(MemTotal|MemAvailable):' /proc/meminfo; printf '\\043~\\043\\n'; df -k /data | tail -1; printf '\\043~\\043\\n'; cat /proc/uptime; printf '\\043~\\043\\n'; top -n 1 -b -m 7 -o %CPU,%MEM,ARGS -s 1 | tail -7; printf '\\043~\\043\\n'; dumpsys power | grep -m1 -o 'mWakefulness=[A-Za-z]*'; dumpsys activity activities | grep -m1 -E 'mResumedActivity|topResumedActivity'; printf '\\043~\\043\\n'; dumpsys thermalservice 2>/dev/null | sed -n '/^Thermal Status/p;/^Current temperatures from HAL/,/^Current cooling/p'; printf '\\043~\\043\\n'; for z in /sys/class/thermal/thermal_zone*; do echo \"$(cat $z/type 2>/dev/null) $(cat $z/temp 2>/dev/null)\"; done 2>/dev/null; printf '\\043~\\043\\n'; for f in /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage /sys/class/kgsl/kgsl-3d0/gpubusy /sys/kernel/gpu/gpu_busy /sys/module/ged/parameters/gpu_loading /sys/kernel/ged/hal/gpu_utilization; do [ -r $f ] && echo \"$f:$(cat $f 2>/dev/null)\"; done 2>/dev/null; printf '\\043~\\043\\n'; cat /proc/net/dev";
        }
        String[] jsplit = Fleet.jsplit(adb2.shell(120000L, str) + StringsKt__StringsJVMKt.repeat(10), -1, "#~#");
        ?? r8 = new String[10];
        r8[0] = list.get(0);
        r8[c] = jsplit[0];
        r8[i] = jsplit[c];
        int i4 = 3;
        r8[3] = jsplit[i];
        r8[4] = jsplit[3];
        r8[5] = list.get(1);
        Object obj = list.get(i);
        int i5 = 6;
        r8[6] = obj;
        r8[7] = list.get(3);
        r8[8] = jsplit[4];
        r8[9] = jsplit[5];
        List asList = ArraysKt.asList(r8);
        String[] jsplit2 = Fleet.jsplit(StringsKt.trim((String) asList.get(0)).toString() + "\n\n\n\n\n\n\n\n", -1, "\n");
        JSONObject put = new JSONObject().put("ping_ms", currentTimeMillis2).put("maker", StringsKt.trim(jsplit2[0]).toString()).put("model", StringsKt.trim(jsplit2[1]).toString()).put("android", StringsKt.trim(jsplit2[2]).toString()).put("sdk", StringsKt.trim(jsplit2[3]).toString()).put("patch", StringsKt.trim(jsplit2[4]).toString()).put("chip", StringsKt.trim(jsplit2[5]).toString()).put("abi", StringsKt.trim(jsplit2[6]).toString());
        String access$find = WorkService.Companion.access$find("(\\d+)\\s*$", StringsKt.trim(jsplit2[7]).toString());
        if (access$find == null) {
            valueOf = JSONObject.NULL;
        } else {
            valueOf = Integer.valueOf(Integer.parseInt(access$find) + 1);
        }
        put.put("cores", valueOf);
        ArrayList arrayList = new ArrayList();
        if (triple != null) {
            arrayList.add(triple.third);
        }
        String[] jsplit3 = Fleet.jsplit(StringsKt.trim((String) asList.get(1)).toString(), 0, "\n");
        int length = jsplit3.length;
        int i6 = 0;
        while (true) {
            long j2 = 0;
            if (i6 >= length) {
                break;
            }
            String[] jsplit4 = Fleet.jsplit(StringsKt.trim(jsplit3[i6]).toString(), 0, "\\s+");
            if (Intrinsics.areEqual(jsplit4[0], "cpu") && jsplit4.length >= i5) {
                int length2 = jsplit4.length;
                for (int i7 = 1; i7 < length2; i7++) {
                    j2 = Long.parseLong(jsplit4[i7]) + j2;
                }
                arrayList.add(new long[]{j2, Long.parseLong(jsplit4[5]) + Long.parseLong(jsplit4[4])});
            }
            i6++;
            i5 = 6;
        }
        long[] jArr2 = (long[]) CollectionsKt.lastOrNull(arrayList);
        if (jArr2 != null) {
            this.cpuWas = new Triple(adb2, Long.valueOf(System.currentTimeMillis()), jArr2);
        }
        if (arrayList.size() == 2 && ((long[]) arrayList.get(1))[0] > ((long[]) arrayList.get(0))[0]) {
            put.put("cpu", Math.round(((r12 - (((long[]) arrayList.get(1))[1] - ((long[]) arrayList.get(0))[1])) * 100.0d) / (((long[]) arrayList.get(1))[0] - ((long[]) arrayList.get(0))[0])));
        }
        Long kb = Games.kb((String) asList.get(2), "MemTotal");
        Long kb2 = Games.kb((String) asList.get(2), "MemAvailable");
        if (kb != null) {
            put.put("mem_total", kb.longValue() * 1024);
        }
        if (kb2 != null) {
            put.put("mem_free", kb2.longValue() * 1024);
        }
        String[] jsplit5 = Fleet.jsplit(StringsKt.trim((String) asList.get(3)).toString(), 0, "\\s+");
        if (jsplit5.length > 3) {
            String str9 = jsplit5[1];
            Regex regex = ManagePart.DIGITS;
            if (regex.matches(str9) && regex.matches(jsplit5[3])) {
                long j3 = 1024;
                put.put("disk_total", Long.parseLong(jsplit5[1]) * j3).put("disk_free", Long.parseLong(jsplit5[3]) * j3);
            }
        }
        String access$find2 = WorkService.Companion.access$find("^\\s*([\\d.]+)", (String) asList.get(4));
        if (access$find2 != null) {
            put.put("uptime", Double.parseDouble(access$find2));
        }
        String access$find3 = WorkService.Companion.access$find("(\\d+x\\d+)", (String) asList.get(5));
        if (access$find3 == null) {
            access$find3 = "";
        }
        put.put("screen", access$find3).put("density", WorkService.Companion.access$num(WorkService.Companion.access$find("density: (\\d+)", (String) asList.get(5))));
        String access$find4 = WorkService.Companion.access$find("fps=([\\d.]+)", (String) asList.get(5));
        if (access$find4 != null) {
            put.put("fps", Math.round(Double.parseDouble(access$find4)));
        }
        String access$find5 = WorkService.Companion.access$find("SSID: ([^,]*),", (String) asList.get(6));
        if (access$find5 != null && StringsKt.trim(access$find5).toString().length() > 0 && !StringsKt.contains(access$find5, "unknown ssid", false)) {
            JSONObject jSONObject4 = new JSONObject();
            String obj2 = StringsKt.trim(access$find5).toString();
            String replaceAll = Census$$ExternalSyntheticOutline0.m7m("^\"|\"$", "compile(...)", obj2, "input", obj2).replaceAll("");
            Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
            put.put("wifi", jSONObject4.put("ssid", replaceAll).put("rssi", WorkService.Companion.access$num(WorkService.Companion.access$find("RSSI: (-?\\d+)", (String) asList.get(6)))).put("speed", WorkService.Companion.access$num(WorkService.Companion.access$find("Link speed: (\\d+)", (String) asList.get(6)))).put("freq", WorkService.Companion.access$num(WorkService.Companion.access$find("Frequency: (\\d+)", (String) asList.get(6)))));
        }
        JSONArray jSONArray = new JSONArray();
        Matcher matcher = Pattern.compile("(?m)^\\d+: (\\S+)\\s+inet ([\\d.]+)").matcher((CharSequence) asList.get(7));
        while (matcher.find()) {
            if (!Intrinsics.areEqual(matcher.group(1), "lo")) {
                jSONArray.put(new JSONObject().put("if", matcher.group(1)).put("ip", matcher.group(2)));
            }
        }
        put.put("ips", jSONArray);
        JSONArray jSONArray2 = new JSONArray();
        String[] jsplit6 = Fleet.jsplit((String) asList.get(8), 0, "\n");
        int length3 = jsplit6.length;
        int i8 = 0;
        while (i8 < length3) {
            Matcher matcher2 = Pattern.compile("\\s*([\\d.]+)\\s+([\\d.]+)\\s+(.+)").matcher(jsplit6[i8]);
            if (matcher2.matches()) {
                String group = matcher2.group(i4);
                Intrinsics.checkNotNull(group);
                Pattern compile = Pattern.compile("(top -n|tail |sh -c).*");
                Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                if (!compile.matcher(group).matches()) {
                    if (jSONArray2.length() >= 5) {
                        i3 = length3;
                        i8++;
                        length3 = i3;
                        i4 = 3;
                    } else {
                        String group2 = matcher2.group(i4);
                        Intrinsics.checkNotNull(group2);
                        String str10 = Fleet.jsplit(StringsKt.trim(group2).toString(), 0, "\\s+")[0];
                        String replaceAll2 = Census$$ExternalSyntheticOutline0.m7m("^\\[|\\]$", "compile(...)", str10, "input", str10).replaceAll("");
                        Intrinsics.checkNotNullExpressionValue(replaceAll2, "replaceAll(...)");
                        Pattern compile2 = Pattern.compile("^(android|vendor\\.\\w+)\\.hardware\\.");
                        Intrinsics.checkNotNullExpressionValue(compile2, "compile(...)");
                        String replaceAll3 = compile2.matcher(replaceAll2).replaceAll("");
                        Intrinsics.checkNotNullExpressionValue(replaceAll3, "replaceAll(...)");
                        Pattern compile3 = Pattern.compile("@[\\d.]+-service.*$");
                        Intrinsics.checkNotNullExpressionValue(compile3, "compile(...)");
                        String replaceAll4 = compile3.matcher(replaceAll3).replaceAll("");
                        Intrinsics.checkNotNullExpressionValue(replaceAll4, "replaceAll(...)");
                        if (this.labels != null && ManagePart.PKG.matcher(replaceAll4).matches()) {
                            str8 = this.labels.label(replaceAll4);
                        } else {
                            str8 = null;
                        }
                        JSONObject jSONObject5 = new JSONObject();
                        String group3 = matcher2.group(1);
                        Intrinsics.checkNotNull(group3);
                        i3 = length3;
                        JSONObject put2 = jSONObject5.put("cpu", Double.parseDouble(group3));
                        String group4 = matcher2.group(2);
                        Intrinsics.checkNotNull(group4);
                        JSONObject put3 = put2.put("mem", Double.parseDouble(group4));
                        if (str8 == null) {
                            str8 = replaceAll4;
                        }
                        jSONArray2.put(put3.put("name", str8));
                        i8++;
                        length3 = i3;
                        i4 = 3;
                    }
                }
            }
            i3 = length3;
            i8++;
            length3 = i3;
            i4 = 3;
        }
        put.put("top", jSONArray2);
        String access$find6 = WorkService.Companion.access$find("mWakefulness=(\\w+)", (String) asList.get(9));
        String access$find7 = WorkService.Companion.access$find("u\\d+ ([\\w.]+)/", (String) asList.get(9));
        if (access$find6 == null) {
            valueOf2 = JSONObject.NULL;
        } else {
            valueOf2 = Boolean.valueOf(access$find6.equals("Awake"));
        }
        put.put("on", valueOf2);
        if (access$find7 != null) {
            RemoteLabels remoteLabels = this.labels;
            if (remoteLabels != null && (label = remoteLabels.label(access$find7)) != null) {
                access$find7 = label;
            }
            put.put("app", access$find7);
        }
        JSONObject jSONObject6 = new JSONObject();
        if (access$find6 != null) {
            z = true;
        } else {
            z = false;
        }
        put.put("remote", jSONObject6.put("connected", z).put("is_on", Intrinsics.areEqual(access$find6, "Awake")).put("app", put.optString("app")));
        Object obj3 = Sensors.HAL_TYPES;
        String hal = jsplit[6];
        String zones = jsplit[7];
        Intrinsics.checkNotNullParameter(hal, "hal");
        Intrinsics.checkNotNullParameter(zones, "zones");
        Pattern compile4 = Pattern.compile("Thermal Status: (\\d)");
        Intrinsics.checkNotNullExpressionValue(compile4, "compile(...)");
        Matcher matcher3 = compile4.matcher(hal);
        Intrinsics.checkNotNullExpressionValue(matcher3, "matcher(...)");
        MatcherMatchResult access$findNext = MathKt.access$findNext(matcher3, 0, hal);
        if (access$findNext != null && (str7 = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)) != null) {
            num = Integer.valueOf(Integer.parseInt(str7));
        } else {
            num = null;
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        GeneratorSequence$iterator$1 generatorSequence$iterator$1 = new GeneratorSequence$iterator$1(Regex.findAll$default(new Regex("Temperature\\{mValue=(-?[\\d.]+), mType=(-?\\d+), mName=([^,}]*)"), hal));
        while (generatorSequence$iterator$1.hasNext()) {
            MatcherMatchResult matcherMatchResult = (MatcherMatchResult) generatorSequence$iterator$1.next();
            Double doubleOrNull = StringsKt__StringNumberConversionsJVMKt.toDoubleOrNull((String) ((MatcherMatchResult$groupValues$1) matcherMatchResult.getGroupValues()).get(1));
            if (doubleOrNull != null) {
                double doubleValue = doubleOrNull.doubleValue();
                String str11 = (String) Sensors.HAL_TYPES.get(Integer.valueOf(Integer.parseInt((String) ((MatcherMatchResult$groupValues$1) matcherMatchResult.getGroupValues()).get(2))));
                if (str11 != null) {
                    String obj4 = StringsKt.trim((String) ((MatcherMatchResult$groupValues$1) matcherMatchResult.getGroupValues()).get(3)).toString();
                    if (obj4.length() != 0) {
                        str11 = obj4;
                    }
                    if (doubleValue > -30.0d && doubleValue < 150.0d && linkedHashMap.get(str11) == null) {
                        linkedHashMap.put(str11, doubleOrNull);
                    }
                }
            }
        }
        if (linkedHashMap.isEmpty()) {
            Iterator it = StringsKt.lines(zones).iterator();
            while (it.hasNext()) {
                List split = new Regex("\\s+").split(StringsKt.trim((String) it.next()).toString(), 0);
                if (split.size() == 2 && (longOrNull2 = StringsKt__StringNumberConversionsKt.toLongOrNull((String) split.get(1))) != null) {
                    long longValue = longOrNull2.longValue();
                    double d = (longValue <= 1000 && longValue >= -1000) ? longValue : longValue / 1000.0d;
                    if (d > -30.0d && d < 150.0d && d != 0.0d) {
                        Object obj5 = split.get(0);
                        if (linkedHashMap.get(obj5) == null) {
                            num4 = num;
                            linkedHashMap.put(obj5, Double.valueOf(Math.round(d * 10) / 10.0d));
                        } else {
                            num4 = num;
                        }
                        num = num4;
                    }
                }
            }
        }
        Integer num5 = num;
        if (num5 == null && linkedHashMap.isEmpty()) {
            jSONObject = null;
        } else {
            jSONObject = new JSONObject();
            if (num5 != null) {
                jSONObject.put("status", num5.intValue());
            }
            Set entrySet = linkedHashMap.entrySet();
            Intrinsics.checkNotNullExpressionValue(entrySet, "<get-entries>(...)");
            List<Map.Entry> take = CollectionsKt.take(CollectionsKt.sortedWith(entrySet, new Power$deaths$$inlined$sortBy$1(2)), 8);
            ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(take));
            for (Map.Entry entry : take) {
                JSONObject put4 = new JSONObject().put("name", entry.getKey());
                Object value = entry.getValue();
                Intrinsics.checkNotNullExpressionValue(value, "<get-value>(...)");
                arrayList2.add(put4.put("c", ((Number) value).doubleValue()));
            }
            jSONObject.put("temps", new JSONArray((Collection) arrayList2));
        }
        if (jSONObject != null) {
            put.put("thermal", jSONObject);
        }
        Object obj6 = Sensors.HAL_TYPES;
        String files = jsplit[8];
        Intrinsics.checkNotNullParameter(files, "files");
        Iterator it2 = StringsKt.lines(files).iterator();
        while (true) {
            if (it2.hasNext()) {
                String str12 = (String) it2.next();
                String substringBefore = StringsKt.substringBefore(str12, ':', str12);
                List list2 = SequencesKt.toList(new GeneratorSequence(Regex.findAll$default(new Regex("\\d+"), StringsKt.trim(StringsKt.substringAfter(str12, ':', "")).toString()), new Bloat$$ExternalSyntheticLambda1(15), 2));
                if (!list2.isEmpty()) {
                    if (StringsKt__StringsJVMKt.endsWith(substringBefore, false, "/gpubusy")) {
                        if (list2.size() >= 2 && ((Number) list2.get(1)).longValue() > 0) {
                            l = Long.valueOf((((Number) list2.get(0)).longValue() * 100) / ((Number) list2.get(1)).longValue());
                            i2 = 0;
                            if (l != null) {
                                IntProgression intProgression = new IntProgression(i2, 100, 1);
                                long longValue2 = l.longValue();
                                if (-2147483648L <= longValue2 && longValue2 < 2147483648L) {
                                    num3 = Integer.valueOf((int) longValue2);
                                } else {
                                    num3 = null;
                                }
                                if (num3 != null && (intValue = num3.intValue()) >= 0 && intValue <= intProgression.last) {
                                    num2 = Integer.valueOf((int) l.longValue());
                                    break;
                                }
                            }
                        }
                    } else {
                        i2 = 0;
                        l = (Long) list2.get(0);
                        if (l != null) {
                        }
                    }
                }
                l = null;
                i2 = 0;
                if (l != null) {
                }
            } else {
                num2 = null;
                break;
            }
        }
        if (num2 != null) {
            put.put("gpu", num2.intValue());
        }
        Object obj7 = Sensors.HAL_TYPES;
        String dev2 = jsplit[9];
        Intrinsics.checkNotNullParameter(dev2, "dev");
        long j4 = 0;
        long j5 = 0;
        boolean z2 = false;
        for (String str13 : StringsKt.lines(dev2)) {
            String obj8 = StringsKt.trim(StringsKt.substringBefore(str13, ':', "")).toString();
            if (obj8.length() != 0 && !obj8.equals("lo") && !StringsKt__StringsJVMKt.startsWith(obj8, false, "tun") && !StringsKt__StringsJVMKt.startsWith(obj8, false, "dummy")) {
                List split2 = new Regex("\\s+").split(StringsKt.trim(StringsKt.substringAfter(str13, ':', str13)).toString(), 0);
                if (split2.size() >= 9 && (longOrNull = StringsKt__StringNumberConversionsKt.toLongOrNull((String) split2.get(0))) != null) {
                    j4 = longOrNull.longValue() + j4;
                    Long longOrNull3 = StringsKt__StringNumberConversionsKt.toLongOrNull((String) split2.get(8));
                    if (longOrNull3 != null) {
                        j = longOrNull3.longValue();
                    } else {
                        j = 0;
                    }
                    j5 += j;
                    z2 = true;
                }
            }
        }
        if (z2) {
            jArr = new long[]{j4, j5};
        } else {
            jArr = null;
        }
        if (jArr != null) {
            put.put("net", netRate(adb2, jArr));
        }
        Object obj9 = Sensors.HAL_TYPES;
        String out = (String) list.get(4);
        Intrinsics.checkNotNullParameter(out, "out");
        List split$default = StringsKt.split$default(out.concat("\n#in\n"), new String[]{"#in\n"}, 2, 2);
        String str14 = (String) split$default.get(0);
        String str15 = (String) split$default.get(1);
        String str16 = "compile(...)";
        String str17 = "input";
        Matcher m7m = Census$$ExternalSyntheticOutline0.m7m("enabled:\\s*(\\w+)", "compile(...)", str14, "input", str14);
        Intrinsics.checkNotNullExpressionValue(m7m, "matcher(...)");
        MatcherMatchResult access$findNext2 = MathKt.access$findNext(m7m, 0, str14);
        if (access$findNext2 == null || (str2 = (String) ((MatcherMatchResult$groupValues$1) access$findNext2.getGroupValues()).get(1)) == null) {
            adb = adb2;
            jSONObject2 = null;
        } else {
            Pattern compile5 = Pattern.compile("([0-9A-FX]{2}(?::[0-9A-FX]{2}){5})", 66);
            Intrinsics.checkNotNullExpressionValue(compile5, "compile(...)");
            LinkedHashMap linkedHashMap2 = new LinkedHashMap();
            Iterator it3 = StringsKt.lines(StringsKt.substringAfter(str14, "Bonded devices:", "")).iterator();
            while (true) {
                str3 = str15;
                Iterator it4 = it3;
                if (!it3.hasNext()) {
                    break;
                }
                String str18 = (String) it4.next();
                Intrinsics.checkNotNullParameter(str18, str17);
                String str19 = str17;
                Matcher matcher4 = compile5.matcher(str18);
                Intrinsics.checkNotNullExpressionValue(matcher4, "matcher(...)");
                Pattern pattern = compile5;
                MatcherMatchResult access$findNext3 = MathKt.access$findNext(matcher4, 0, str18);
                if (access$findNext3 != null) {
                    Matcher matcher5 = access$findNext3.matcher;
                    String substring = str18.substring(MathKt.until(matcher5.start(), matcher5.end()).last + 1);
                    Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
                    Pattern compile6 = Pattern.compile("\\[[^\\]]*\\]");
                    Intrinsics.checkNotNullExpressionValue(compile6, "compile(...)");
                    String replaceAll5 = compile6.matcher(substring).replaceAll("");
                    Intrinsics.checkNotNullExpressionValue(replaceAll5, "replaceAll(...)");
                    String obj10 = StringsKt.trim(replaceAll5).toString();
                    String value2 = access$findNext3.getValue();
                    Locale locale = Locale.ROOT;
                    String upperCase = value2.toUpperCase(locale);
                    Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
                    JSONObject jSONObject7 = new JSONObject();
                    if (obj10.length() == 0) {
                        obj10 = access$findNext3.getValue();
                    }
                    JSONObject put5 = jSONObject7.put("name", obj10);
                    String upperCase2 = access$findNext3.getValue().toUpperCase(locale);
                    Intrinsics.checkNotNullExpressionValue(upperCase2, "toUpperCase(...)");
                    linkedHashMap2.put(upperCase, put5.put("addr", upperCase2).put("connected", false));
                }
                str15 = str3;
                it3 = it4;
                str17 = str19;
                compile5 = pattern;
            }
            Iterator it5 = StringsKt.lines(str3).iterator();
            while (it5.hasNext()) {
                String str20 = (String) it5.next();
                Iterator it6 = it5;
                if (StringsKt.contains$default(str20, '|')) {
                    String substringBefore2 = StringsKt.substringBefore(str20, '|', str20);
                    Adb adb3 = adb2;
                    Pattern compile7 = Pattern.compile("\\s*\\(aka .*\\)$");
                    Intrinsics.checkNotNullExpressionValue(compile7, str16);
                    String replaceAll6 = compile7.matcher(substringBefore2).replaceAll("");
                    Intrinsics.checkNotNullExpressionValue(replaceAll6, "replaceAll(...)");
                    String obj11 = StringsKt.trim(replaceAll6).toString();
                    String str21 = str16;
                    MatcherMatchResult access$findNext4 = MathKt.access$findNext(Census$$ExternalSyntheticOutline0.m6m("bluetoothAddress=([0-9A-Fa-f:]{17})", str16, str20, "matcher(...)"), 0, str20);
                    if (access$findNext4 != null && (str6 = (String) ((MatcherMatchResult$groupValues$1) access$findNext4.getGroupValues()).get(1)) != null) {
                        str4 = str6.toUpperCase(Locale.ROOT);
                        Intrinsics.checkNotNullExpressionValue(str4, "toUpperCase(...)");
                    } else {
                        str4 = null;
                    }
                    JSONObject jSONObject8 = (JSONObject) linkedHashMap2.get(str4);
                    if (jSONObject8 == null) {
                        Collection values = linkedHashMap2.values();
                        Intrinsics.checkNotNullExpressionValue(values, "<get-values>(...)");
                        Iterator it7 = values.iterator();
                        while (true) {
                            if (it7.hasNext()) {
                                jSONObject3 = it7.next();
                                if (Intrinsics.areEqual(((JSONObject) jSONObject3).optString("name"), obj11)) {
                                    break;
                                }
                            } else {
                                jSONObject3 = 0;
                                break;
                            }
                        }
                        jSONObject8 = jSONObject3;
                    }
                    if (jSONObject8 != null) {
                        jSONObject8.put("connected", true);
                    } else {
                        if (str4 == null) {
                            str5 = obj11;
                        } else {
                            str5 = str4;
                        }
                        JSONObject m8m = Census$$ExternalSyntheticOutline0.m8m("name", obj11);
                        if (str4 == null) {
                            str4 = "";
                        }
                        linkedHashMap2.put(str5, m8m.put("addr", str4).put("connected", true));
                    }
                    it5 = it6;
                    str16 = str21;
                    adb2 = adb3;
                } else {
                    it5 = it6;
                }
            }
            adb = adb2;
            JSONObject put6 = new JSONObject().put("on", str2.equalsIgnoreCase("true"));
            Collection values2 = linkedHashMap2.values();
            Intrinsics.checkNotNullExpressionValue(values2, "<get-values>(...)");
            jSONObject2 = put6.put("devices", new JSONArray((Collection) CollectionsKt.sortedWith(values2, new Power$deaths$$inlined$sortBy$1(1))));
        }
        if (jSONObject2 != null) {
            put.put("bt", jSONObject2);
        }
        JSONObject nightly = nightly(adb);
        if (nightly != null) {
            put.put("nightly", nightly);
        }
        return put;
    }

    public final synchronized JSONObject netRate(Adb adb, long[] jArr) {
        long currentTimeMillis = System.currentTimeMillis();
        Triple triple = this.netLast;
        this.netLast = new Triple(adb, Long.valueOf(currentTimeMillis), jArr);
        JSONObject jSONObject = new JSONObject();
        if (triple != null && triple.first == adb && currentTimeMillis - ((Number) triple.second).longValue() >= 1000) {
            long j = jArr[0];
            Object obj = triple.third;
            if (j >= ((long[]) obj)[0] && jArr[1] >= ((long[]) obj)[1]) {
                double longValue = (currentTimeMillis - ((Number) triple.second).longValue()) / 1000.0d;
                JSONObject put = jSONObject.put("rx", Math.round((jArr[0] - ((long[]) triple.third)[0]) / longValue)).put("tx", Math.round((jArr[1] - ((long[]) triple.third)[1]) / longValue));
                Intrinsics.checkNotNullExpressionValue(put, "put(...)");
                return put;
            }
        }
        return jSONObject;
    }

    public final synchronized JSONObject nightly(Adb adb) {
        long currentTimeMillis = System.currentTimeMillis();
        if (this.nightlyOf != adb || currentTimeMillis - this.nightlyAt > 600000) {
            JSONObject jSONObject = null;
            try {
                String obj = StringsKt.trim(SetupFiles.read(1, "stats/nightly.json", new Fleet$$ExternalSyntheticLambda0(adb, 3))).toString();
                if (!StringsKt__StringsJVMKt.startsWith(obj, false, "{")) {
                    obj = null;
                }
                if (obj != null) {
                    jSONObject = new JSONObject(obj);
                }
            } catch (Exception unused) {
            }
            this.nightlyIs = jSONObject;
            this.nightlyOf = adb;
            this.nightlyAt = currentTimeMillis;
        }
        return this.nightlyIs;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    @Override // dev.tvremote.core.manage.ManagePart
    public final HttpServer.Response route(String str, boolean z, HttpServer.Request request) {
        String str2;
        Long l;
        Long l2;
        boolean z2;
        boolean z3;
        boolean z4;
        Iterator it;
        Double doubleOrNull;
        String concat;
        Object obj;
        Long longOrNull;
        boolean z5;
        Long longOrNull2;
        Double doubleOrNull2;
        int i;
        JSONObject jSONObject;
        boolean z6;
        RemoteLabels remoteLabels;
        int i2 = 1;
        switch (str.hashCode()) {
            case -1221262756:
                if (!str.equals("health")) {
                    return null;
                }
                JSONObject health = health();
                HttpServer.Response response = new HttpServer.Response();
                response.status = 200;
                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = HttpServer.trusted;
                response.body = Census$$ExternalSyntheticOutline0.m("toString(...)", health);
                return response;
            case 106858757:
                if (str.equals("power")) {
                    List list = Power.DEEP;
                    String out = this.link.get().shell(20000L, Power.CMD);
                    Intrinsics.checkNotNullParameter(out, "out");
                    ArrayList mutableList = CollectionsKt.toMutableList((Collection) StringsKt.split$default(out.concat(StringsKt__StringsJVMKt.repeat(6)), new String[]{"#~#"}, 0, 6));
                    if (StringsKt.isBlank((CharSequence) mutableList.get(5))) {
                        try {
                            str2 = SetupFiles.read(3000, "stats/power.jsonl", new HealthApi$$ExternalSyntheticLambda0(this, 0));
                        } catch (SetupNeed.Missing unused) {
                            str2 = "";
                        }
                        mutableList.set(5, str2);
                    }
                    JSONObject jSONObject2 = new JSONObject();
                    String str3 = (String) mutableList.get(0);
                    JSONObject jSONObject3 = new JSONObject();
                    String find = Power.find("^\\s*([\\d.]+)", str3);
                    if (find != null && (doubleOrNull2 = StringsKt__StringNumberConversionsJVMKt.toDoubleOrNull(find)) != null) {
                        jSONObject3.put("up", Math.round(doubleOrNull2.doubleValue()));
                    }
                    String find2 = Power.find("Runtime uptime \\(elapsed\\): (\\S+)", str3);
                    if (find2 != null) {
                        l = Power.duration$shared_release(find2);
                    } else {
                        l = null;
                    }
                    String find3 = Power.find("Runtime uptime \\(uptime\\): (\\S+)", str3);
                    if (find3 != null) {
                        l2 = Power.duration$shared_release(find3);
                    } else {
                        l2 = null;
                    }
                    if (l != null && l2 != null && l.longValue() >= l2.longValue()) {
                        jSONObject3.put("deep", (l.longValue() - l2.longValue()) / 1000);
                    }
                    jSONObject2.put("boot", jSONObject3);
                    String find4 = Power.find("^now=(\\d+)", (String) mutableList.get(0));
                    if (find4 != null && (longOrNull2 = StringsKt__StringNumberConversionsKt.toLongOrNull(find4)) != null) {
                        jSONObject2.put("now", longOrNull2.longValue());
                    }
                    String str4 = (String) mutableList.get(1);
                    if (jSONObject2.getJSONObject("boot").optLong("deep") > 60) {
                        z2 = true;
                    } else {
                        z2 = false;
                    }
                    String find5 = Power.find("mWakefulness=(\\w+)", str4);
                    if (find5 != null) {
                        jSONObject2.put("state", find5);
                    }
                    Guard$$ExternalSyntheticLambda4 guard$$ExternalSyntheticLambda4 = new Guard$$ExternalSyntheticLambda4(str4, 1);
                    Guard$$ExternalSyntheticLambda4 guard$$ExternalSyntheticLambda42 = new Guard$$ExternalSyntheticLambda4(str4, 2);
                    JSONObject jSONObject4 = new JSONObject();
                    Long l3 = (Long) guard$$ExternalSyntheticLambda4.invoke("mLastGlobalSleepTimeRealtime");
                    if (l3 == null) {
                        if (z2) {
                            l3 = null;
                        } else {
                            l3 = (Long) guard$$ExternalSyntheticLambda4.invoke("mLastSleepTime");
                        }
                    }
                    JSONObject putOpt = jSONObject4.putOpt("ago", l3);
                    String str5 = (String) guard$$ExternalSyntheticLambda42.invoke("mLastGlobalSleepReason");
                    if (str5 == null) {
                        str5 = (String) guard$$ExternalSyntheticLambda42.invoke("mLastSleepReason");
                    }
                    JSONObject putOpt2 = putOpt.putOpt("why", str5);
                    JSONObject jSONObject5 = new JSONObject();
                    Long l4 = (Long) guard$$ExternalSyntheticLambda4.invoke("mLastGlobalWakeTimeRealtime");
                    if (l4 == null) {
                        if (z2) {
                            l4 = null;
                        } else {
                            l4 = (Long) guard$$ExternalSyntheticLambda4.invoke("mLastWakeTime");
                        }
                    }
                    JSONObject putOpt3 = jSONObject5.putOpt("ago", l4);
                    String str6 = (String) guard$$ExternalSyntheticLambda42.invoke("mLastGlobalWakeReason");
                    if (str6 == null) {
                        str6 = (String) guard$$ExternalSyntheticLambda42.invoke("mLastWakeReason");
                    }
                    JSONObject putOpt4 = putOpt3.putOpt("why", str6);
                    if (putOpt2.length() > 0) {
                        jSONObject2.put("last_sleep", putOpt2);
                    }
                    if (putOpt4.length() > 0) {
                        jSONObject2.put("last_wake", putOpt4);
                    }
                    String find6 = Power.find("Low Power Standby[^\\n]*\\n(?:[^\\n]*\\n){0,3}?\\s*mIsEnabled=(true|false)", str4);
                    if (find6 != null) {
                        jSONObject2.put("low_power_standby", find6.equals("true"));
                    }
                    JSONArray jSONArray = new JSONArray();
                    GeneratorSequence$iterator$1 generatorSequence$iterator$1 = new GeneratorSequence$iterator$1(Regex.findAll$default(new Regex("(?m)^\\s*(PARTIAL_WAKE_LOCK|FULL_WAKE_LOCK|SCREEN_\\w+_WAKE_LOCK|DOZE_WAKE_LOCK|DRAW_WAKE_LOCK)\\s+'([^']*)'.*?(?:ws=WorkSource\\{(\\d+)[^}]*\\}|uid=(\\d+))?"), str4));
                    while (generatorSequence$iterator$1.hasNext()) {
                        MatcherMatchResult matcherMatchResult = (MatcherMatchResult) generatorSequence$iterator$1.next();
                        JSONObject jSONObject6 = new JSONObject();
                        String lowerCase = StringsKt.removeSuffix((String) ((MatcherMatchResult$groupValues$1) matcherMatchResult.getGroupValues()).get(1), "_WAKE_LOCK").toLowerCase(Locale.ROOT);
                        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                        jSONArray.put(jSONObject6.put("kind", lowerCase).put("tag", ((MatcherMatchResult$groupValues$1) matcherMatchResult.getGroupValues()).get(2)));
                    }
                    jSONObject2.put("locks", jSONArray);
                    HashMap hashMap = new HashMap();
                    for (String str7 : StringsKt.lines((CharSequence) mutableList.get(2))) {
                        int indexOf$default = StringsKt.indexOf$default(str7, '=', 6);
                        if (indexOf$default > 0) {
                            String substring = str7.substring(0, indexOf$default);
                            Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
                            String obj2 = StringsKt.trim(substring).toString();
                            String substringAfterLast = StringsKt.substringAfterLast(obj2, ' ', obj2);
                            String substring2 = str7.substring(indexOf$default + 1);
                            Intrinsics.checkNotNullExpressionValue(substring2, "substring(...)");
                            hashMap.put(substringAfterLast, StringsKt.trim(substring2).toString());
                        }
                    }
                    Power$$ExternalSyntheticLambda2 power$$ExternalSyntheticLambda2 = new Power$$ExternalSyntheticLambda2(hashMap, 0);
                    jSONObject2.put("timeouts", new JSONObject().putOpt("sleep", power$$ExternalSyntheticLambda2.invoke("sleep_timeout")).putOpt("attentive", power$$ExternalSyntheticLambda2.invoke("attentive_timeout")).putOpt("screen_off", power$$ExternalSyntheticLambda2.invoke("screen_off_timeout")).putOpt("stay_on", power$$ExternalSyntheticLambda2.invoke("stay_on_while_plugged_in")));
                    Long l5 = (Long) power$$ExternalSyntheticLambda2.invoke("hdmi_control_auto_device_off_enabled");
                    if (l5 != null) {
                        if (l5.longValue() != 0) {
                            z5 = true;
                        } else {
                            z5 = false;
                        }
                        jSONObject2.put("hdmi_off", z5);
                    }
                    Long l6 = (Long) power$$ExternalSyntheticLambda2.invoke("wifi_sleep_policy");
                    if (l6 != null) {
                        jSONObject2.put("wifi_sleep", l6.longValue());
                    }
                    String str8 = (String) hashMap.get("sys.boot.reason");
                    if (str8 != null) {
                        if (str8.length() <= 0) {
                            str8 = null;
                        }
                        if (str8 != null) {
                            jSONObject2.getJSONObject("boot").put("reason", str8);
                        }
                    }
                    Long l7 = (Long) power$$ExternalSyntheticLambda2.invoke("boot_count");
                    if (l7 != null) {
                        jSONObject2.getJSONObject("boot").put("count", l7.longValue());
                    }
                    for (Pair pair : Power.DEEP) {
                        String str9 = (String) pair.first;
                        String str10 = (String) pair.second;
                        String str11 = (String) hashMap.get(str9);
                        if (str11 != null && (longOrNull = StringsKt__StringNumberConversionsKt.toLongOrNull(str11)) != null) {
                            jSONObject2.put("deep", new JSONObject().put("count", longOrNull.longValue()).put("by", str10));
                        }
                    }
                    JSONObject put = new JSONObject().put("installed", StringsKt.contains((CharSequence) mutableList.get(3), "package:", false));
                    if (Power.find("ts=(\\d+)", (String) mutableList.get(3)) != null) {
                        z3 = true;
                    } else {
                        z3 = false;
                    }
                    JSONObject put2 = put.put("running", z3).put("always_on", Intrinsics.areEqual(hashMap.get("always_on_vpn_app"), "com.tailscale.ipn"));
                    String find7 = Power.find(" inet (100\\.[\\d.]+)", (String) mutableList.get(3));
                    if (find7 != null) {
                        put2.put("ip", find7);
                    }
                    JSONObject put3 = jSONObject2.put("tailscale", put2);
                    if (Power.find("setup=(\\d+)", (String) mutableList.get(3)) != null) {
                        z4 = true;
                    } else {
                        z4 = false;
                    }
                    put3.put("setup_running", z4);
                    String log = (String) mutableList.get(4);
                    Intrinsics.checkNotNullParameter(log, "log");
                    ArrayList arrayList = new ArrayList();
                    Iterator it2 = StringsKt.lines(log).iterator();
                    while (it2.hasNext()) {
                        String str12 = (String) it2.next();
                        String find8 = Power.find("^\\s*(\\d{9,}\\.\\d+)", str12);
                        if (find8 != null && (doubleOrNull = StringsKt__StringNumberConversionsJVMKt.toDoubleOrNull(find8)) != null) {
                            double doubleValue = doubleOrNull.doubleValue();
                            String find9 = Power.find("(com.tailscale.ipn|dev.tvremote.setup)", str12);
                            if (find9 != null) {
                                if (StringsKt.contains(str12, "tguard-kill", false)) {
                                    String find10 = Power.find("tguard-kill-(\\w+)", str12);
                                    if (find10 == null) {
                                        find10 = "";
                                    }
                                    concat = "tguard:".concat(find10);
                                } else {
                                    Pattern compile = Pattern.compile("installPackage|force.?stop|stop .* due to|deletePackage", 66);
                                    Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                                    if (!compile.matcher(str12).find()) {
                                        if (StringsKt.contains(str12, "am_kill", false)) {
                                            String find11 = Power.find("am_kill\\s*:\\s*\\[[^,]*,[^,]*,[^,]*,[^,]*,([^\\]]*)\\]", str12);
                                            if (find11 == null || (concat = StringsKt.trim(find11).toString()) == null) {
                                                concat = "";
                                            }
                                        } else if (!StringsKt.contains(str12, "lowmemorykiller", false) && !StringsKt.contains(str12, "lmkd", false)) {
                                            if (StringsKt.contains(str12, "has died", false)) {
                                                concat = "died";
                                            }
                                        } else {
                                            concat = "lmk";
                                        }
                                    }
                                }
                                ListIterator listIterator = arrayList.listIterator(arrayList.size());
                                while (true) {
                                    if (listIterator.hasPrevious()) {
                                        Object previous = listIterator.previous();
                                        Power$deaths$D power$deaths$D = (Power$deaths$D) previous;
                                        it = it2;
                                        if (power$deaths$D.pkg.equals(find9) && Math.abs(power$deaths$D.t - doubleValue) < 3.0d) {
                                            obj = previous;
                                        } else {
                                            it2 = it;
                                        }
                                    } else {
                                        it = it2;
                                        obj = null;
                                    }
                                }
                                Power$deaths$D power$deaths$D2 = (Power$deaths$D) obj;
                                if (power$deaths$D2 == null) {
                                    arrayList.add(new Power$deaths$D(doubleValue, find9, concat));
                                } else if (Intrinsics.areEqual(power$deaths$D2.why, "died") || (StringsKt__StringsJVMKt.startsWith(concat, false, "tguard") && !StringsKt__StringsJVMKt.startsWith(power$deaths$D2.why, false, "tguard"))) {
                                    Intrinsics.checkNotNullParameter(concat, "<set-?>");
                                    power$deaths$D2.why = concat;
                                }
                            }
                        } else {
                            it = it2;
                        }
                        it2 = it;
                    }
                    if (arrayList.size() > 1) {
                        CollectionsKt__MutableCollectionsJVMKt.sortWith(arrayList, new Power$deaths$$inlined$sortBy$1(0));
                    }
                    JSONArray jSONArray2 = new JSONArray();
                    for (Power$deaths$D power$deaths$D3 : CollectionsKt.takeLast(20, arrayList)) {
                        jSONArray2.put(new JSONObject().put("t", Math.round(power$deaths$D3.t)).put("pkg", power$deaths$D3.pkg).put("why", power$deaths$D3.why));
                    }
                    jSONObject2.put("deaths", jSONArray2);
                    JSONArray jSONArray3 = new JSONArray();
                    Iterator it3 = StringsKt.lines((CharSequence) mutableList.get(5)).iterator();
                    while (it3.hasNext()) {
                        try {
                            JSONArray jSONArray4 = new JSONArray(StringsKt.trim((String) it3.next()).toString());
                            if (jSONArray4.length() >= 2) {
                                try {
                                    jSONArray3.put(new JSONArray().put(jSONArray4.getLong(0)).put(jSONArray4.getString(1)));
                                } catch (Exception unused2) {
                                }
                            }
                        } catch (Exception unused3) {
                        }
                    }
                    jSONObject2.put("events", jSONArray3).put("logged", !StringsKt.isBlank((CharSequence) mutableList.get(5)));
                    if (!jSONObject2.has("now")) {
                        jSONObject2 = jSONObject2.put("now", System.currentTimeMillis() / 1000);
                    }
                    Intrinsics.checkNotNullExpressionValue(jSONObject2, "let(...)");
                    HttpServer.Response response2 = new HttpServer.Response();
                    response2.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda02 = HttpServer.trusted;
                    response2.body = Census$$ExternalSyntheticOutline0.m("toString(...)", jSONObject2);
                    return response2;
                }
                return null;
            case 109757599:
                if (str.equals("stats")) {
                    Integer intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull(request.q("days"));
                    if (intOrNull != null) {
                        i = intOrNull.intValue();
                    } else {
                        i = 7;
                    }
                    int coerceIn = MathKt.coerceIn(i, 1, 90);
                    long currentTimeMillis = (System.currentTimeMillis() / 1000) - (coerceIn * 86400);
                    HomeApi$$ExternalSyntheticLambda1 homeApi$$ExternalSyntheticLambda1 = new HomeApi$$ExternalSyntheticLambda1(i2, this);
                    try {
                        jSONObject = new JSONObject((String) homeApi$$ExternalSyntheticLambda1.invoke("usage.json", 1000));
                    } catch (Exception unused4) {
                        jSONObject = null;
                    }
                    JSONArray jSONArray5 = new JSONArray();
                    for (String str13 : Fleet.jsplit((String) homeApi$$ExternalSyntheticLambda1.invoke("samples.jsonl", Integer.valueOf(coerceIn * 300)), 0, "\n")) {
                        try {
                            JSONArray jSONArray6 = new JSONArray(str13);
                            if (jSONArray6.getLong(0) >= currentTimeMillis) {
                                jSONArray5.put(jSONArray6);
                            }
                        } catch (Exception unused5) {
                        }
                    }
                    JSONArray jSONArray7 = new JSONArray();
                    int i3 = 0;
                    String[] jsplit = Fleet.jsplit((String) homeApi$$ExternalSyntheticLambda1.invoke("net.jsonl", 400), 0, "\n");
                    int length = jsplit.length;
                    int i4 = 0;
                    while (i4 < length) {
                        try {
                            JSONArray jSONArray8 = new JSONArray(jsplit[i4]);
                            if (jSONArray8.getLong(i3) >= currentTimeMillis) {
                                jSONArray7.put(jSONArray8);
                            }
                        } catch (Exception unused6) {
                        }
                        i4++;
                        i3 = 0;
                    }
                    JSONObject jSONObject7 = new JSONObject();
                    if (jSONObject != null && (remoteLabels = this.labels) != null) {
                        Iterator<String> keys = jSONObject.keys();
                        Intrinsics.checkNotNullExpressionValue(keys, "keys(...)");
                        while (keys.hasNext()) {
                            Iterator<String> keys2 = jSONObject.getJSONObject(keys.next()).keys();
                            Intrinsics.checkNotNullExpressionValue(keys2, "keys(...)");
                            while (keys2.hasNext()) {
                                String next = keys2.next();
                                if (!jSONObject7.has(next)) {
                                    Intrinsics.checkNotNull(next);
                                    String label = remoteLabels.label(next);
                                    if (label != null) {
                                        jSONObject7.put(next, label);
                                    }
                                }
                            }
                        }
                    }
                    JSONObject put4 = new JSONObject().put("days", coerceIn);
                    if (jSONObject == null && jSONArray5.length() <= 0) {
                        z6 = false;
                    } else {
                        z6 = true;
                    }
                    JSONObject put5 = put4.put("collector", z6);
                    if (jSONObject == null) {
                        jSONObject = new JSONObject();
                    }
                    JSONObject put6 = put5.put("usage", jSONObject).put("samples", jSONArray5).put("net", jSONArray7).put("labels", jSONObject7);
                    Intrinsics.checkNotNullExpressionValue(put6, "put(...)");
                    HttpServer.Response response3 = new HttpServer.Response();
                    response3.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda03 = HttpServer.trusted;
                    response3.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put6);
                    return response3;
                }
                return null;
            case 1025385109:
                if (str.equals("crashes")) {
                    JSONObject put7 = new JSONObject().put("text", StringsKt.takeLast(StringsKt__StringsJVMKt.replace$default(sh("for t in data_app_crash system_app_crash system_server_crash data_app_anr system_app_anr system_server_anr data_app_native_crash system_app_native_crash; do dumpsys dropbox --print $t; done | grep -E '^(=====|[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9:]{8} |Process: |Subject: |signal [0-9]|Abort message|Caused by: |[A-Za-z_$][A-Za-z0-9_.$]*(Exception|Error)(: |$)|\tat )'"), "\r\n", "\n"), 500000));
                    Intrinsics.checkNotNullExpressionValue(put7, "put(...)");
                    HttpServer.Response response4 = new HttpServer.Response();
                    response4.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda04 = HttpServer.trusted;
                    response4.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put7);
                    return response4;
                }
                return null;
            default:
                return null;
        }
    }
}
