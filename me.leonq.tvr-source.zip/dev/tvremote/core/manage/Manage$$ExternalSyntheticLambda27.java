package dev.tvremote.core.manage;

import dev.tvremote.core.ontv.LauncherInstall;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class Manage$$ExternalSyntheticLambda27 implements LauncherInstall.Progress {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ JSONObject f$0;

    public /* synthetic */ Manage$$ExternalSyntheticLambda27(JSONObject jSONObject, int i) {
        this.$r8$classId = i;
        this.f$0 = jSONObject;
    }

    @Override // dev.tvremote.core.ontv.LauncherInstall.Progress
    public final void at(String str, int i) {
        switch (this.$r8$classId) {
            case 0:
                this.f$0.put("msg", str).put("pct", i);
                return;
            default:
                this.f$0.put("step", str).put("pct", i);
                return;
        }
    }
}
