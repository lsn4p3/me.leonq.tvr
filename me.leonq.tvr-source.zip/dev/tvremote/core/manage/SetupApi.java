package dev.tvremote.core.manage;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import com.android.apksig.internal.apk.ApkSigningBlockUtils$$ExternalSyntheticLambda0;
import dev.tvremote.core.B64;
import dev.tvremote.core.Census;
import dev.tvremote.core.Census$$ExternalSyntheticLambda3;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Words;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.adb.Mdns;
import dev.tvremote.core.adb.TvShell;
import dev.tvremote.core.ontv.Axml$$ExternalSyntheticLambda2;
import dev.tvremote.core.ontv.Bloat;
import dev.tvremote.core.ontv.Bloat$$ExternalSyntheticLambda0;
import dev.tvremote.core.ontv.Games;
import dev.tvremote.core.ontv.LauncherSwap;
import dev.tvremote.core.ontv.Launchers;
import dev.tvremote.core.ontv.RemoteLabels;
import dev.tvremote.core.ontv.Rescue;
import dev.tvremote.core.ontv.RulesClient;
import dev.tvremote.core.ontv.Setup;
import dev.tvremote.core.ontv.Setup$$ExternalSyntheticLambda4;
import dev.tvremote.core.ontv.Setup$$ExternalSyntheticLambda5;
import dev.tvremote.core.ontv.Setup$plan$$inlined$sortedBy$1;
import dev.tvremote.core.ontv.SetupNeed;
import dev.tvremote.core.ontv.SetupUpdate;
import dev.tvremote.core.ontv.Tailscale;
import dev.tvremote.core.ontv.Welcome;
import dev.tvremote.core.web.HttpServer;
import dev.tvremote.home.HomeQr$$ExternalSyntheticLambda0;
import dev.tvremote.phone.MainActivity$onCreate$2;
import dev.tvremote.phone.WorkService;
import dev.tvremote.update.Ed25519;
import dev.tvremote.update.Release;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyMap;
import kotlin.collections.EmptySet;
import kotlin.collections.SetsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgressionIterator;
import kotlin.ranges.IntRange;
import kotlin.text.Charsets;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class SetupApi extends ManagePart {
    public final TvCopy copy;
    public volatile Release latest;
    public volatile long latestAt;
    public volatile String latestFor;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public SetupApi(Ed25519.Pt core, TvCopy copy) {
        super(core);
        Intrinsics.checkNotNullParameter(core, "core");
        Intrinsics.checkNotNullParameter(copy, "copy");
        this.copy = copy;
        this.latestFor = "";
    }

    public final Release latestSetup(String str) {
        if (!str.equals(this.latestFor) || System.currentTimeMillis() - this.latestAt > 1800000) {
            List list = Release.KEYS;
            this.latest = MathKt.newer(str, "tv", "tv-setup.apk");
            this.latestAt = System.currentTimeMillis();
            this.latestFor = str;
        }
        return this.latest;
    }

    /* JADX WARN: Code restructure failed: missing block: B:145:0x0c9f, code lost:
    
        if (r4 < 600001) goto L393;
     */
    /* JADX WARN: Failed to find 'out' block for switch in B:2:0x0046. Please report as an issue. */
    /* JADX WARN: Removed duplicated region for block: B:184:0x01a4  */
    /* JADX WARN: Removed duplicated region for block: B:187:0x01a8 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:413:0x07b6  */
    /* JADX WARN: Removed duplicated region for block: B:424:0x07de  */
    /* JADX WARN: Removed duplicated region for block: B:431:0x07ef A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:6:0x08fd A[ORIG_RETURN, RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0901  */
    /* JADX WARN: Type inference failed for: r3v56, types: [java.util.List, java.lang.Object] */
    @Override // dev.tvremote.core.manage.ManagePart
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final HttpServer.Response route(String str, boolean z, HttpServer.Request request) {
        String str2;
        String str3;
        Object obj;
        Object obj2;
        String str4;
        String str5;
        String str6;
        String str7;
        String str8;
        String str9;
        Iterator it;
        boolean hasNext;
        String str10;
        String str11;
        String str12;
        LauncherSwap.Rec rec;
        String str13;
        String str14;
        String str15;
        boolean z2;
        Release release;
        String str16;
        String str17;
        final String lang;
        final Setup.Choice choice;
        boolean z3;
        String str18;
        final SetupApi setupApi = this;
        Object obj3 = "rules";
        String str19 = "";
        String str20 = "/";
        switch (str.hashCode()) {
            case -2076488569:
                str2 = "\n";
                str3 = str20;
                obj = "support/tv";
                obj2 = "telegram";
                str4 = "state";
                str5 = "text";
                str6 = "anim";
                str7 = "key";
                str8 = "put(...)";
                if (str.equals("setup/restore.sh") && !z) {
                    Setup setup = new Setup(setupApi.link.get(), setupApi.dir, request.getLang(), new Bloat$$ExternalSyntheticLambda0(3));
                    if (setup.optimized()) {
                        String model = StringsKt.trim(setupApi.sh("getprop ro.product.model")).toString();
                        String format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date());
                        Intrinsics.checkNotNullExpressionValue(format, "format(...)");
                        String host = setupApi.link.host;
                        Intrinsics.checkNotNullParameter(model, "model");
                        Intrinsics.checkNotNullParameter(host, "host");
                        LauncherSwap.Rec state = new LauncherSwap(setup.sh).state();
                        if (state != null) {
                            String str21 = state.prev;
                            if (!StringsKt.substringBefore(str21, '/', str21).equals(state.pkg)) {
                                str10 = str21;
                            } else {
                                str10 = null;
                            }
                            if (str10 != null) {
                                str9 = str10;
                                String[] strArr = Setup.GOOGLE;
                                List undoable = setup.undoable();
                                ArrayList arrayList = new ArrayList();
                                for (Object obj4 : undoable) {
                                    String str22 = (String) obj4;
                                    if (setup.has(StringsKt.substringBefore(str22, '/', str22))) {
                                        arrayList.add(obj4);
                                    }
                                }
                                ArrayList arrayList2 = new ArrayList();
                                it = arrayList.iterator();
                                while (true) {
                                    hasNext = it.hasNext();
                                    Regex regex = Setup.SAFE;
                                    if (!hasNext) {
                                        Object next = it.next();
                                        if (regex.matches((String) next)) {
                                            arrayList2.add(next);
                                        }
                                    } else {
                                        List<String> distinct = CollectionsKt.distinct(arrayList2);
                                        StringBuilder sb = new StringBuilder("#!/bin/sh\n# Restore for the TV ");
                                        Pattern compile = Pattern.compile("[^\\w .-]");
                                        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                                        String replaceAll = compile.matcher(model).replaceAll("");
                                        Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
                                        String obj5 = StringsKt.trim(replaceAll).toString();
                                        if (obj5.length() == 0) {
                                            obj5 = "?";
                                        }
                                        sb.append(obj5);
                                        sb.append(", saved ");
                                        Pattern compile2 = Pattern.compile("[^\\w :+-]");
                                        Intrinsics.checkNotNullExpressionValue(compile2, "compile(...)");
                                        String replaceAll2 = compile2.matcher(format).replaceAll("");
                                        Intrinsics.checkNotNullExpressionValue(replaceAll2, "replaceAll(...)");
                                        sb.append(replaceAll2);
                                        sb.append(" by TV Remote (Optimize TV, Undo).\n# Needs only adb on this computer. With the TV on the network:  adb connect ");
                                        Pattern compile3 = Pattern.compile("[^\\w.:-]");
                                        Intrinsics.checkNotNullExpressionValue(compile3, "compile(...)");
                                        String replaceAll3 = compile3.matcher(host).replaceAll("");
                                        Intrinsics.checkNotNullExpressionValue(replaceAll3, "replaceAll(...)");
                                        sb.append(replaceAll3);
                                        sb.append(":5555\n#   then  sh ");
                                        String restoreName = Rescue.restoreName(model);
                                        sb.append(restoreName);
                                        sb.append("      (several devices: ADB_SERIAL=<ip>:5555 sh ");
                                        sb.append(restoreName);
                                        sb.append(")\nA=\"adb\"; [ -n \"$ADB_SERIAL\" ] && A=\"adb -s $ADB_SERIAL\"\n");
                                        for (String str23 : distinct) {
                                            sb.append("$A shell 'pm enable --user 0 ");
                                            sb.append(str23);
                                            sb.append("'\n");
                                        }
                                        if (str9.length() > 0 && regex.matches(str9) && StringsKt.contains$default(str9, '/')) {
                                            sb.append("$A shell 'cmd package set-home-activity ");
                                            sb.append(str9);
                                            sb.append("'\n");
                                        }
                                        sb.append("$A shell 'rm -f /data/local/tmp/tvr-disabled.txt /data/local/tmp/tvr-launcher.json'\n$A shell 'for k in window_animation_scale transition_animation_scale animator_duration_scale; do settings put global $k 1.0; done'\necho \"Done: ");
                                        sb.append(distinct.size());
                                        sb.append(" apps on again.\"\n");
                                        String sb2 = sb.toString();
                                        Intrinsics.checkNotNullExpressionValue(sb2, "toString(...)");
                                        byte[] bytes = sb2.getBytes(Charsets.UTF_8);
                                        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                                        HttpServer.Response response = new HttpServer.Response();
                                        response.type = "text/x-shellscript; charset=utf-8";
                                        response.body = bytes;
                                        String[] strArr2 = Setup.GOOGLE;
                                        String restoreName2 = Rescue.restoreName(model);
                                        response.headers.put("Content-Disposition", Census$$ExternalSyntheticOutline0.m("attachment; filename=\"", restoreName2, "\"; filename*=UTF-8''", restoreName2));
                                        return response;
                                    }
                                }
                            }
                        }
                        str9 = "";
                        String[] strArr3 = Setup.GOOGLE;
                        List undoable2 = setup.undoable();
                        ArrayList arrayList3 = new ArrayList();
                        while (r6.hasNext()) {
                        }
                        ArrayList arrayList22 = new ArrayList();
                        it = arrayList3.iterator();
                        while (true) {
                            hasNext = it.hasNext();
                            Regex regex2 = Setup.SAFE;
                            if (!hasNext) {
                            }
                        }
                    } else {
                        throw new IOException("setup:nothing_to_restore");
                    }
                }
                if (z) {
                    return null;
                }
                switch (str.hashCode()) {
                    case -1637971813:
                        if (!str.equals("setup/update")) {
                            return null;
                        }
                        Adb adb = setupApi.link.get();
                        Regex regex3 = SetupUpdate.VERSION;
                        String installed = SetupUpdate.installed(adb);
                        if (installed.length() != 0) {
                            setupApi.latestAt = 0L;
                            Release latestSetup = setupApi.latestSetup(installed);
                            if (latestSetup != null) {
                                JSONObject state2 = SetupUpdate.state(adb);
                                long currentTimeMillis = System.currentTimeMillis();
                                String str24 = str4;
                                if (Intrinsics.areEqual(state2.optString(str24), "installing") || Intrinsics.areEqual(state2.optString(str24), "checking")) {
                                    long optLong = currentTimeMillis - state2.optLong("at");
                                    if (-60000 <= optLong) {
                                        break;
                                    }
                                }
                                ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                                if (StringsKt.contains(adb.shell(120000L, "mkdir -p /data/local/tmp/tvr-update; if mkdir /data/local/tmp/tvr-update/lock 2>/dev/null || [ $(( $(date +%s) - $(stat -c %Y /data/local/tmp/tvr-update/lock 2>/dev/null || date +%s) )) -gt 600 ]; then touch /data/local/tmp/tvr-update/lock; echo got; fi"), "got", false)) {
                                    JSONObject job$default = ManagePart.job$default(setupApi, "update TV Setup ".concat(latestSetup.version), null, null, new Axml$$ExternalSyntheticLambda2(4, latestSetup, setupApi), 14);
                                    HttpServer.Response response2 = new HttpServer.Response();
                                    response2.status = 200;
                                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = HttpServer.trusted;
                                    response2.body = Census$$ExternalSyntheticOutline0.m("toString(...)", job$default);
                                    return response2;
                                }
                                throw new IllegalArgumentException("an update of TV Setup is already running");
                            }
                            throw new IllegalArgumentException("TV Setup is up to date");
                        }
                        throw new IllegalArgumentException("TV Setup is not installed");
                    case -1360467711:
                        if (!str.equals(obj2)) {
                            return null;
                        }
                        JSONObject telegram = setupApi.telegram(request);
                        HttpServer.Response response3 = new HttpServer.Response();
                        response3.status = 200;
                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda02 = HttpServer.trusted;
                        response3.body = Census$$ExternalSyntheticOutline0.m("toString(...)", telegram);
                        return response3;
                    case -613943102:
                        if (!str.equals(obj)) {
                            return null;
                        }
                        String optString = request.json(65536).optString("act");
                        Intrinsics.checkNotNullExpressionValue(optString, "optString(...)");
                        JSONObject supportTv = setupApi.supportTv(optString);
                        HttpServer.Response response4 = new HttpServer.Response();
                        response4.status = 200;
                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda03 = HttpServer.trusted;
                        response4.body = Census$$ExternalSyntheticOutline0.m("toString(...)", supportTv);
                        return response4;
                    case 108873975:
                        if (!str.equals(obj3)) {
                            return null;
                        }
                        JSONObject rules = setupApi.rules(request.json(65536));
                        HttpServer.Response response5 = new HttpServer.Response();
                        response5.status = 200;
                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda04 = HttpServer.trusted;
                        response5.body = Census$$ExternalSyntheticOutline0.m("toString(...)", rules);
                        return response5;
                    case 109329021:
                        if (!str.equals("setup")) {
                            return null;
                        }
                        JSONObject json = request.json(65536);
                        String str25 = "undo";
                        final boolean areEqual = Intrinsics.areEqual(json.optString("mode"), "undo");
                        String optString2 = json.optString("lang");
                        Intrinsics.checkNotNull(optString2);
                        if (optString2.length() <= 0) {
                            optString2 = null;
                        }
                        if (optString2 != null) {
                            lang = Words.pick(optString2);
                        } else {
                            lang = request.getLang();
                        }
                        JSONArray optJSONArray = json.optJSONArray("disable");
                        if (optJSONArray == null) {
                            choice = new Setup.Choice(json.optBoolean(str6, true), json.optBoolean("home", true), null);
                        } else {
                            boolean optBoolean = json.optBoolean(str6, true);
                            boolean optBoolean2 = json.optBoolean("home", true);
                            IntRange until = MathKt.until(0, optJSONArray.length());
                            ArrayList arrayList4 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until));
                            Iterator it2 = until.iterator();
                            while (((IntProgressionIterator) it2).hasNext) {
                                arrayList4.add(optJSONArray.optString(((IntProgressionIterator) it2).nextInt()));
                            }
                            choice = new Setup.Choice(optBoolean, optBoolean2, arrayList4);
                        }
                        if (!areEqual) {
                            str25 = "optimize";
                        }
                        JSONObject job$default2 = ManagePart.job$default(setupApi, str25, null, null, new Function1() { // from class: dev.tvremote.core.manage.SetupApi$$ExternalSyntheticLambda9
                            /* JADX WARN: Can't wrap try/catch for region: R(24:208|(2:210|(1:299)(1:214))(1:300)|215|(11:291|292|(1:294)(1:297)|295|(9:258|259|(1:261)(1:288)|262|263|264|265|266|(3:270|271|(9:273|274|275|276|221|(4:248|(2:250|(3:252|(1:254)(1:257)|(1:256)))|224|(5:226|(1:228)|229|(1:231)|232)(7:233|(1:235)|236|(1:240)|241|(3:243|(1:245)|246)|247))|223|224|(0)(0)))(1:269))|220|221|(0)|223|224|(0)(0))|217|(0)|258|259|(0)(0)|262|263|264|265|266|(0)|270|271|(0)|220|221|(0)|223|224|(0)(0)) */
                            /* JADX WARN: Code restructure failed: missing block: B:282:0x0577, code lost:
                            
                                r0 = e;
                             */
                            /* JADX WARN: Code restructure failed: missing block: B:283:0x0578, code lost:
                            
                                r0 = r0.getMessage();
                             */
                            /* JADX WARN: Code restructure failed: missing block: B:284:0x057c, code lost:
                            
                                if (r0 == null) goto L203;
                             */
                            /* JADX WARN: Code restructure failed: missing block: B:285:0x057e, code lost:
                            
                                r3 = "";
                             */
                            /* JADX WARN: Code restructure failed: missing block: B:286:0x0580, code lost:
                            
                                r3 = r0;
                             */
                            /* JADX WARN: Code restructure failed: missing block: B:289:0x054f, code lost:
                            
                                r0 = e;
                             */
                            /* JADX WARN: Multi-variable type inference failed */
                            /* JADX WARN: Removed duplicated region for block: B:226:0x0600  */
                            /* JADX WARN: Removed duplicated region for block: B:233:0x065f  */
                            /* JADX WARN: Removed duplicated region for block: B:248:0x05d0  */
                            /* JADX WARN: Removed duplicated region for block: B:261:0x0543 A[Catch: IOException -> 0x054f, TRY_ENTER, TryCatch #7 {IOException -> 0x054f, blocks: (B:261:0x0543, B:262:0x0559, B:288:0x0553), top: B:259:0x0541 }] */
                            /* JADX WARN: Removed duplicated region for block: B:268:0x058a A[ADDED_TO_REGION] */
                            /* JADX WARN: Removed duplicated region for block: B:273:0x05b6  */
                            /* JADX WARN: Removed duplicated region for block: B:288:0x0553 A[Catch: IOException -> 0x054f, TryCatch #7 {IOException -> 0x054f, blocks: (B:261:0x0543, B:262:0x0559, B:288:0x0553), top: B:259:0x0541 }] */
                            /* JADX WARN: Type inference failed for: r31v1 */
                            /* JADX WARN: Type inference failed for: r31v2, types: [java.lang.Throwable] */
                            /* JADX WARN: Type inference failed for: r31v6 */
                            @Override // kotlin.jvm.functions.Function1
                            /*
                                Code decompiled incorrectly, please refer to instructions dump.
                            */
                            public final Object invoke(Object obj6) {
                                String str26;
                                Axml$$ExternalSyntheticLambda2 axml$$ExternalSyntheticLambda2;
                                String str27;
                                Set off;
                                int i;
                                String str28;
                                String str29;
                                Release newer;
                                String str30;
                                Adb adb2;
                                String str31;
                                Launchers.Apk self;
                                boolean take;
                                String str32;
                                LauncherSwap.Rec rec2;
                                String str33;
                                int i2;
                                Object obj7;
                                String str34;
                                int i3;
                                int i4;
                                String str35;
                                int i5;
                                String str36;
                                JSONObject j = (JSONObject) obj6;
                                Intrinsics.checkNotNullParameter(j, "j");
                                StringBuilder sb3 = new StringBuilder();
                                SetupApi setupApi2 = SetupApi.this;
                                AdbLink link = setupApi2.link;
                                ApkSigningBlockUtils$$ExternalSyntheticLambda0 apkSigningBlockUtils$$ExternalSyntheticLambda0 = new ApkSigningBlockUtils$$ExternalSyntheticLambda0(sb3, j);
                                Intrinsics.checkNotNullParameter(link, "link");
                                String lang2 = lang;
                                Intrinsics.checkNotNullParameter(lang2, "lang");
                                Setup$$ExternalSyntheticLambda4 setup$$ExternalSyntheticLambda4 = new Setup$$ExternalSyntheticLambda4(link, 0);
                                Setup setup2 = new Setup(null, setupApi2.dir, lang2, setup$$ExternalSyntheticLambda4, new Setup$$ExternalSyntheticLambda5(0, link), apkSigningBlockUtils$$ExternalSyntheticLambda0);
                                Function1 function1 = setup2.sh;
                                if (areEqual) {
                                    int i6 = 0;
                                    for (String str37 : setup2.undoable()) {
                                        if (setup2.has(StringsKt.substringBefore(str37, '/', str37))) {
                                            function1.invoke("pm enable --user 0 ".concat(str37));
                                            i6++;
                                        }
                                    }
                                    function1.invoke("rm -f /data/local/tmp/tvr-disabled.txt");
                                    LauncherSwap launcherSwap = new LauncherSwap(function1);
                                    LauncherSwap.Rec state3 = launcherSwap.state();
                                    if (state3 != null) {
                                        str36 = state3.why;
                                    } else {
                                        str36 = null;
                                    }
                                    if (Intrinsics.areEqual(str36, "key")) {
                                        launcherSwap.rollback("user", null);
                                    } else {
                                        launcherSwap.dropKey();
                                    }
                                    function1.invoke("rm -f /data/local/tmp/tvr-launcher.json");
                                    function1.invoke("for k in window_animation_scale transition_animation_scale animator_duration_scale; do settings put global $k 1.0; done");
                                    apkSigningBlockUtils$$ExternalSyntheticLambda0.line(setup2.t("optimize.re_enabled_apps_google", new Pair("n", Integer.valueOf(i6))));
                                    apkSigningBlockUtils$$ExternalSyntheticLambda0.line(setup2.t("optimize.tvhome_tailscale_settings_left", new Pair[0]));
                                    return "ok";
                                }
                                Setup.Choice choice2 = choice;
                                setup2.tvOnly();
                                if (Census.getEnabled()) {
                                    try {
                                        str26 = (String) setup$$ExternalSyntheticLambda4.invoke("getprop ro.product.manufacturer; getprop ro.product.model; getprop ro.product.device; getprop ro.build.version.release");
                                    } catch (IOException unused) {
                                        str26 = "";
                                    }
                                    setup2.about = str26;
                                }
                                setup$$ExternalSyntheticLambda4.invoke("for p in dev.tvremote.setup dev.tvremote.home; do pm path $p >/dev/null 2>&1 || continue; dumpsys deviceidle whitelist +$p >/dev/null 2>&1; am set-standby-bucket $p active >/dev/null 2>&1; cmd appops set $p RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1; done; ");
                                if (setup2.has("com.tailscale.ipn")) {
                                    Adb adb3 = setup2.getAdb();
                                    Intrinsics.checkNotNull(adb3);
                                    axml$$ExternalSyntheticLambda2 = 0;
                                    new Tailscale(adb3, setup2.dir).keepAlive();
                                    apkSigningBlockUtils$$ExternalSyntheticLambda0.line(setup2.t("optimize.tailscale_starts_again_by", new Pair[0]));
                                } else {
                                    axml$$ExternalSyntheticLambda2 = 0;
                                }
                                if (choice2.anim) {
                                    setup$$ExternalSyntheticLambda4.invoke("settings put global window_animation_scale 0; settings put global transition_animation_scale 0; settings put global animator_duration_scale 1");
                                    apkSigningBlockUtils$$ExternalSyntheticLambda0.line(setup2.t("optimize.transition_animations_off", new Pair[0]));
                                }
                                Bloat.fresh();
                                ArrayList arrayList5 = choice2.disable;
                                if (arrayList5 == null) {
                                    arrayList5 = Setup.suggested();
                                }
                                String homeNow = setup2.homeNow();
                                String obj8 = StringsKt.trim((String) function1.invoke("settings get secure default_input_method")).toString();
                                String substringBefore = StringsKt.substringBefore(obj8, '/', obj8);
                                boolean z4 = choice2.home;
                                if (!z4) {
                                    str27 = "";
                                } else {
                                    str27 = "dev.tvremote.home";
                                }
                                char c = 0;
                                LinkedHashSet plus = SetsKt.plus(SetsKt.setOf((Object[]) new String[]{homeNow, substringBefore, str27}), setup2.handlers());
                                LinkedHashMap linkedHashMap = new LinkedHashMap();
                                String systemPid = setup2.systemPid();
                                Iterator it3 = CollectionsKt.distinct(arrayList5).iterator();
                                while (true) {
                                    boolean hasNext2 = it3.hasNext();
                                    String[] strArr4 = Setup.GOOGLE;
                                    Iterator it4 = it3;
                                    if (hasNext2) {
                                        boolean z5 = z4;
                                        String input = (String) it4.next();
                                        SetupApi setupApi3 = setupApi2;
                                        Pattern compile4 = Pattern.compile("[A-Za-z][\\w]*(\\.[\\w]+)+");
                                        Intrinsics.checkNotNullExpressionValue(compile4, "compile(...)");
                                        Intrinsics.checkNotNullParameter(input, "input");
                                        if (compile4.matcher(input).matches() && !Rescue.mustKeep(input) && !plus.contains(input) && setup2.has(input)) {
                                            if (!Rescue.inUse(input, setup$$ExternalSyntheticLambda4)) {
                                                try {
                                                    str34 = setup2.turnOff(input);
                                                } catch (IOException unused2) {
                                                    str34 = axml$$ExternalSyntheticLambda2;
                                                }
                                                if (str34 != null && !Setup.DEAD.containsMatchIn(str34)) {
                                                    linkedHashMap.put(input, Rescue.access$last(StringsKt.trim(str34).toString()));
                                                } else {
                                                    Pair[] pairArr = new Pair[1];
                                                    pairArr[c] = new Pair("pkg", input);
                                                    apkSigningBlockUtils$$ExternalSyntheticLambda0.line(setup2.t("optimize.waiting_tv", pairArr));
                                                    int i7 = 0;
                                                    while (i7 < 12) {
                                                        LinkedHashSet linkedHashSet = plus;
                                                        setup2.pause.invoke(8000L);
                                                        try {
                                                            i4 = i7;
                                                            try {
                                                                if (StringsKt.contains((CharSequence) setup$$ExternalSyntheticLambda4.invoke("pm path android"), "package:", false)) {
                                                                    if (setup2.off().contains(input)) {
                                                                        linkedHashMap.put(input, "");
                                                                    } else {
                                                                        try {
                                                                            str35 = Rescue.access$last(StringsKt.trim(setup2.turnOff(input)).toString());
                                                                        } catch (IOException unused3) {
                                                                            str35 = "";
                                                                        }
                                                                        linkedHashMap.put(input, str35);
                                                                    }
                                                                    String systemPid2 = setup2.systemPid();
                                                                    if (systemPid != null && systemPid2 != null && !systemPid2.equals(systemPid)) {
                                                                        Rescue.report("restarted", setup2.about, input, linkedHashMap);
                                                                        Pair pair = new Pair("pkg", input);
                                                                        Set keySet = linkedHashMap.keySet();
                                                                        Intrinsics.checkNotNullExpressionValue(keySet, "<get-keys>(...)");
                                                                        if (!keySet.isEmpty()) {
                                                                            Iterator it5 = keySet.iterator();
                                                                            i5 = 0;
                                                                            while (it5.hasNext()) {
                                                                                if (!Intrinsics.areEqual((String) it5.next(), input) && (i5 = i5 + 1) < 0) {
                                                                                    CollectionsKt__CollectionsKt.throwCountOverflow();
                                                                                    throw axml$$ExternalSyntheticLambda2;
                                                                                }
                                                                            }
                                                                        } else {
                                                                            i5 = 0;
                                                                        }
                                                                        throw new Setup.Stopped(setup2.t("errors.optimize_restarted", pair, new Pair("n", Integer.valueOf(i5))), input);
                                                                    }
                                                                    plus = linkedHashSet;
                                                                }
                                                            } catch (IOException unused4) {
                                                            }
                                                        } catch (IOException unused5) {
                                                            i4 = i7;
                                                        }
                                                        i7 = i4 + 1;
                                                        plus = linkedHashSet;
                                                    }
                                                    Rescue.report("lost", setup2.about, input, linkedHashMap);
                                                    Pair pair2 = new Pair("pkg", input);
                                                    Set keySet2 = linkedHashMap.keySet();
                                                    Intrinsics.checkNotNullExpressionValue(keySet2, "<get-keys>(...)");
                                                    if (!keySet2.isEmpty()) {
                                                        Iterator it6 = keySet2.iterator();
                                                        i3 = 0;
                                                        while (it6.hasNext()) {
                                                            if (!Intrinsics.areEqual((String) it6.next(), input) && (i3 = i3 + 1) < 0) {
                                                                CollectionsKt__CollectionsKt.throwCountOverflow();
                                                                throw axml$$ExternalSyntheticLambda2;
                                                            }
                                                        }
                                                    } else {
                                                        i3 = 0;
                                                    }
                                                    throw new Setup.Stopped(setup2.t("errors.optimize_lost", pair2, new Pair("n", Integer.valueOf(i3))), input);
                                                }
                                            }
                                            it3 = it4;
                                            z4 = z5;
                                            setupApi2 = setupApi3;
                                        }
                                        it3 = it4;
                                        z4 = z5;
                                        setupApi2 = setupApi3;
                                        c = 0;
                                    } else {
                                        boolean z6 = z4;
                                        SetupApi setupApi4 = setupApi2;
                                        if (linkedHashMap.isEmpty()) {
                                            off = EmptySet.INSTANCE;
                                        } else {
                                            off = setup2.off();
                                        }
                                        LinkedHashMap linkedHashMap2 = new LinkedHashMap();
                                        for (Map.Entry entry : linkedHashMap.entrySet()) {
                                            LinkedHashMap linkedHashMap3 = linkedHashMap;
                                            if (!off.contains((String) entry.getKey())) {
                                                linkedHashMap2.put(entry.getKey(), entry.getValue());
                                            }
                                            linkedHashMap = linkedHashMap3;
                                        }
                                        LinkedHashMap linkedHashMap4 = linkedHashMap;
                                        if (linkedHashMap4.size() > linkedHashMap2.size()) {
                                            apkSigningBlockUtils$$ExternalSyntheticLambda0.line(setup2.t("optimize.turned_off_apps", new Pair("n", Integer.valueOf(linkedHashMap4.size() - linkedHashMap2.size()))));
                                        }
                                        if (!linkedHashMap2.isEmpty()) {
                                            apkSigningBlockUtils$$ExternalSyntheticLambda0.line(setup2.t("optimize.not_off", new Pair("apps", CollectionsKt.joinToString$default(linkedHashMap2.keySet(), ", ", null, null, null, 62))));
                                            Rescue.report("failed", setup2.about, "", linkedHashMap2);
                                        }
                                        String keyboard$whole = Setup.keyboard$whole(StringsKt.trim((String) function1.invoke("settings get secure default_input_method")).toString());
                                        List split$default = StringsKt.split$default((CharSequence) setup$$ExternalSyntheticLambda4.invoke("ime list -s"), new String[]{"\n"}, 0, 6);
                                        ArrayList arrayList6 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(split$default));
                                        Iterator it7 = split$default.iterator();
                                        while (it7.hasNext()) {
                                            arrayList6.add(StringsKt.trim((String) it7.next()).toString());
                                        }
                                        ArrayList arrayList7 = new ArrayList();
                                        Iterator it8 = arrayList6.iterator();
                                        while (it8.hasNext()) {
                                            Object next2 = it8.next();
                                            if (StringsKt.contains$default((String) next2, '/')) {
                                                arrayList7.add(next2);
                                            }
                                        }
                                        ArrayList arrayList8 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList7));
                                        Iterator it9 = arrayList7.iterator();
                                        while (it9.hasNext()) {
                                            arrayList8.add(Setup.keyboard$whole((String) it9.next()));
                                        }
                                        if (arrayList8.isEmpty() || arrayList8.contains(keyboard$whole)) {
                                            i = 0;
                                        } else {
                                            Iterator it10 = arrayList8.iterator();
                                            while (true) {
                                                if (it10.hasNext()) {
                                                    obj7 = it10.next();
                                                    i2 = 0;
                                                    if (StringsKt__StringsJVMKt.startsWith((String) obj7, false, "com.google.android.inputmethod.latin/")) {
                                                        break;
                                                    }
                                                } else {
                                                    i2 = 0;
                                                    obj7 = axml$$ExternalSyntheticLambda2;
                                                    break;
                                                }
                                            }
                                            String str38 = (String) obj7;
                                            if (str38 == null) {
                                                str38 = (String) arrayList8.get(i2);
                                            }
                                            setup$$ExternalSyntheticLambda4.invoke("ime set " + str38);
                                            i = 0;
                                            apkSigningBlockUtils$$ExternalSyntheticLambda0.line(setup2.t("optimize.keyboard_set", new Pair("ime", StringsKt.substringBefore(str38, '/', str38))));
                                        }
                                        if (!z6) {
                                            apkSigningBlockUtils$$ExternalSyntheticLambda0.line(setup2.t("optimize.done", new Pair[i]));
                                        } else {
                                            if (setup2.has("dev.tvremote.home")) {
                                                Pattern compile5 = Pattern.compile("versionName=(\\S+)");
                                                Intrinsics.checkNotNullExpressionValue(compile5, "compile(...)");
                                                CharSequence input2 = (CharSequence) setup$$ExternalSyntheticLambda4.invoke("dumpsys package dev.tvremote.home | grep -m1 versionName");
                                                Intrinsics.checkNotNullParameter(input2, "input");
                                                Matcher matcher = compile5.matcher(input2);
                                                Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
                                                MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, input2);
                                                if (access$findNext == null || (str33 = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)) == null) {
                                                    str28 = "";
                                                } else {
                                                    str28 = str33;
                                                }
                                            } else {
                                                str28 = axml$$ExternalSyntheticLambda2;
                                            }
                                            if (!Intrinsics.areEqual(str28, "")) {
                                                try {
                                                    List list = Release.KEYS;
                                                    if (str28 == null) {
                                                        str29 = "0";
                                                    } else {
                                                        str29 = str28;
                                                    }
                                                    newer = MathKt.newer(str29, "home", "tv-home.apk");
                                                } catch (Exception unused6) {
                                                }
                                                if (str28 != null || newer != null) {
                                                    apkSigningBlockUtils$$ExternalSyntheticLambda0.line(setup2.t("optimize.downloading_tvhome", new Pair[0]));
                                                    if (newer == null) {
                                                        self = new Launchers.Apk("any", newer.url, newer.sha256);
                                                    } else {
                                                        List list2 = Launchers.KEYS;
                                                        self = Launchers.self();
                                                    }
                                                    File download = setup2.download(self.url, "tv-home.apk", self.sha256, axml$$ExternalSyntheticLambda2);
                                                    apkSigningBlockUtils$$ExternalSyntheticLambda0.line(setup2.t("optimize.installing_tvhome", new Pair[0]));
                                                    str30 = setup2.install(download);
                                                    download.delete();
                                                    if (StringsKt.contains(str30, "Success", false) && str28 == null) {
                                                        apkSigningBlockUtils$$ExternalSyntheticLambda0.line(setup2.t("optimize.tvhome_could_not_be", new Pair("why", Rescue.access$last(str30))));
                                                        apkSigningBlockUtils$$ExternalSyntheticLambda0.line(setup2.t("optimize.done", new Pair[0]));
                                                    } else {
                                                        adb2 = setup2.getAdb();
                                                        if (adb2 != null) {
                                                            str31 = "dev.tvremote.home";
                                                            try {
                                                                adb2.shell(120000L, "pm grant dev.tvremote.home android.permission.ACCESS_FINE_LOCATION >/dev/null 2>&1; pm grant dev.tvremote.home android.permission.BLUETOOTH_CONNECT >/dev/null 2>&1; pm grant dev.tvremote.home android.permission.READ_TV_LISTINGS >/dev/null 2>&1; pm grant dev.tvremote.home android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1; cmd package compile -m speed -f dev.tvremote.home >/dev/null 2>&1");
                                                            } catch (IOException unused7) {
                                                            }
                                                            LauncherSwap launcherSwap2 = new LauncherSwap(setup$$ExternalSyntheticLambda4);
                                                            take = launcherSwap2.take(str31, 0, "");
                                                            if (!take) {
                                                                str32 = launcherSwap2.refused;
                                                                if (str32.length() == 0) {
                                                                    LauncherSwap.Rec state4 = launcherSwap2.state();
                                                                    if (state4 != null) {
                                                                        if (state4.state.equals("rolledback")) {
                                                                            rec2 = state4;
                                                                        } else {
                                                                            rec2 = null;
                                                                        }
                                                                        if (rec2 != null) {
                                                                            str32 = rec2.why;
                                                                        }
                                                                    }
                                                                }
                                                                setup2.refused = str32;
                                                                setup2.opened = launcherSwap2.opened;
                                                                setup2.via = launcherSwap2.via;
                                                                EmptyMap emptyMap = EmptyMap.INSTANCE;
                                                                if (take) {
                                                                    apkSigningBlockUtils$$ExternalSyntheticLambda0.line(setup2.t("optimize.home_screen", new Pair("home", new LauncherSwap(setup$$ExternalSyntheticLambda4).homeOpens())));
                                                                    if (Intrinsics.areEqual(setup2.via, "wifi")) {
                                                                        apkSigningBlockUtils$$ExternalSyntheticLambda0.line(setup2.t("launcher.key_wifi", new Pair[0]));
                                                                    }
                                                                    if (SetsKt.setOf((Object[]) new String[]{"home", "wifi_unknown"}).contains(setup2.via)) {
                                                                        Rescue.report(ApkSigner$$ExternalSyntheticOutline0.m("home:key:", setup2.via), setup2.about, setup2.opened, emptyMap);
                                                                    }
                                                                    apkSigningBlockUtils$$ExternalSyntheticLambda0.line(setup2.t("optimize.done_press_home_see", new Pair[0]));
                                                                } else {
                                                                    apkSigningBlockUtils$$ExternalSyntheticLambda0.line(setup2.t("optimize.home_kept", new Pair("home", setup2.homeNow())));
                                                                    if (setup2.refused.length() > 0) {
                                                                        apkSigningBlockUtils$$ExternalSyntheticLambda0.line(setup2.t(Games.whyId(setup2.refused), new Pair[0]));
                                                                    }
                                                                    if (Intrinsics.areEqual(setup2.refused, "home") && setup2.opened.length() > 0) {
                                                                        apkSigningBlockUtils$$ExternalSyntheticLambda0.line(setup2.t("launcher.home_opens", new Pair("pkg", setup2.opened)));
                                                                    }
                                                                    if (SetsKt.setOf((Object[]) new String[]{"home", "interrupted", "wifi_unknown", "keys", ""}).contains(setup2.refused)) {
                                                                        String str39 = setup2.refused;
                                                                        if (str39.length() == 0) {
                                                                            str39 = "?";
                                                                        }
                                                                        Rescue.report("home:" + ((Object) str39), setup2.about, setup2.opened, emptyMap);
                                                                    }
                                                                    apkSigningBlockUtils$$ExternalSyntheticLambda0.line(setup2.t("optimize.done", new Pair[0]));
                                                                }
                                                            }
                                                            str32 = "";
                                                            setup2.refused = str32;
                                                            setup2.opened = launcherSwap2.opened;
                                                            setup2.via = launcherSwap2.via;
                                                            EmptyMap emptyMap2 = EmptyMap.INSTANCE;
                                                            if (take) {
                                                            }
                                                        }
                                                    }
                                                }
                                                str31 = "dev.tvremote.home";
                                                LauncherSwap launcherSwap22 = new LauncherSwap(setup$$ExternalSyntheticLambda4);
                                                take = launcherSwap22.take(str31, 0, "");
                                                if (!take) {
                                                }
                                                str32 = "";
                                                setup2.refused = str32;
                                                setup2.opened = launcherSwap22.opened;
                                                setup2.via = launcherSwap22.via;
                                                EmptyMap emptyMap22 = EmptyMap.INSTANCE;
                                                if (take) {
                                                }
                                            }
                                            newer = axml$$ExternalSyntheticLambda2;
                                            if (str28 != null) {
                                            }
                                            apkSigningBlockUtils$$ExternalSyntheticLambda0.line(setup2.t("optimize.downloading_tvhome", new Pair[0]));
                                            if (newer == null) {
                                            }
                                            File download2 = setup2.download(self.url, "tv-home.apk", self.sha256, axml$$ExternalSyntheticLambda2);
                                            apkSigningBlockUtils$$ExternalSyntheticLambda0.line(setup2.t("optimize.installing_tvhome", new Pair[0]));
                                            str30 = setup2.install(download2);
                                            download2.delete();
                                            if (StringsKt.contains(str30, "Success", false)) {
                                            }
                                            adb2 = setup2.getAdb();
                                            if (adb2 != null) {
                                            }
                                            str31 = "dev.tvremote.home";
                                            LauncherSwap launcherSwap222 = new LauncherSwap(setup$$ExternalSyntheticLambda4);
                                            take = launcherSwap222.take(str31, 0, "");
                                            if (!take) {
                                            }
                                            str32 = "";
                                            setup2.refused = str32;
                                            setup2.opened = launcherSwap222.opened;
                                            setup2.via = launcherSwap222.via;
                                            EmptyMap emptyMap222 = EmptyMap.INSTANCE;
                                            if (take) {
                                            }
                                        }
                                        MainActivity$onCreate$2 mainActivity$onCreate$2 = Census.store;
                                        String host2 = setupApi4.link.host;
                                        Intrinsics.checkNotNullParameter(host2, "host");
                                        Census.later(new Census$$ExternalSyntheticLambda3(host2, 0));
                                        return "ok";
                                    }
                                }
                            }
                        }, 6);
                        HttpServer.Response response6 = new HttpServer.Response();
                        response6.status = 200;
                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda05 = HttpServer.trusted;
                        response6.body = Census$$ExternalSyntheticOutline0.m("toString(...)", job$default2);
                        return response6;
                    case 110757536:
                        if (!str.equals("tvset")) {
                            return null;
                        }
                        JSONObject json2 = request.json(65536);
                        String optString3 = json2.optString(str7);
                        String optString4 = json2.optString("value");
                        if (Intrinsics.areEqual(optString3, "home")) {
                            Intrinsics.checkNotNull(optString4);
                            String lang2 = request.getLang();
                            String substringBefore = StringsKt.substringBefore(optString4, '/', optString4);
                            LauncherSwap launcherSwap = new LauncherSwap(new SetupApi$$ExternalSyntheticLambda0(setupApi, 1));
                            LauncherSwap.Rec state3 = launcherSwap.state();
                            if (state3 != null && state3.getActive()) {
                                z3 = true;
                            } else {
                                z3 = false;
                            }
                            String[] strArr4 = Setup.LAUNCHER;
                            if (ArraysKt.contains(substringBefore, strArr4)) {
                                launcherSwap.dropKey();
                            }
                            if (!optString4.equals(substringBefore.concat(str3)) || !ArraysKt.contains(substringBefore, strArr4)) {
                                TvShell.INSTANCE.tvset("home", optString4);
                            }
                            if (ArraysKt.contains(substringBefore, strArr4) && z3) {
                                launcherSwap.rollback("user", null);
                                String homeNow = launcherSwap.homeNow();
                                if (!StringsKt.substringBefore(homeNow, '/', homeNow).equals(substringBefore)) {
                                    setupApi.sh("c=$(cmd package query-activities --brief -a android.intent.action.MAIN -c android.intent.category.HOME | grep -m1 '" + substringBefore + "/'); [ -n \"$c\" ] && cmd package set-home-activity $c >/dev/null 2>&1");
                                }
                            } else {
                                if (!ArraysKt.contains(substringBefore, strArr4)) {
                                    if (!z3) {
                                        List split$default = StringsKt.split$default(setupApi.sh("pm list packages -e"), new String[]{str2}, 0, 6);
                                        ArrayList arrayList5 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(split$default));
                                        Iterator it3 = split$default.iterator();
                                        while (it3.hasNext()) {
                                            arrayList5.add(StringsKt.trim(StringsKt.removePrefix((String) it3.next(), "package:")).toString());
                                        }
                                        String[] strArr5 = Setup.LAUNCHER;
                                        for (int i = 0; i < 5; i++) {
                                            if (!arrayList5.contains(strArr5[i])) {
                                            }
                                        }
                                    }
                                    if (!launcherSwap.take(substringBefore, 0, "")) {
                                        String str26 = launcherSwap.refused;
                                        if (str26.length() == 0) {
                                            LauncherSwap.Rec state4 = launcherSwap.state();
                                            if (state4 != null) {
                                                str19 = state4.why;
                                            }
                                            str26 = str19;
                                        }
                                        if (LauncherSwap.REFUSED.contains(str26)) {
                                            ConcurrentHashMap concurrentHashMap2 = Words.books;
                                            str18 = Words.get(lang2, Games.whyId(str26), new Pair[0]);
                                        } else {
                                            str18 = Words.get(lang2, "tvset.home_refused", new Pair[0]);
                                        }
                                        JSONObject put = new JSONObject().put(str5, "home " + str18);
                                        Intrinsics.checkNotNullExpressionValue(put, str8);
                                        HttpServer.Response response7 = new HttpServer.Response();
                                        response7.status = 200;
                                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda06 = HttpServer.trusted;
                                        response7.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put);
                                        return response7;
                                    }
                                }
                                return setupApi.text(60000L, TvShell.INSTANCE.tvset("home", optString4));
                            }
                            String str27 = str8;
                            String homeOpens = launcherSwap.homeOpens();
                            JSONObject jSONObject = new JSONObject();
                            if (!StringsKt.substringBefore(homeOpens, '/', homeOpens).equals(substringBefore)) {
                                optString4 = homeOpens;
                            }
                            JSONObject put2 = jSONObject.put(str5, "home ".concat(optString4));
                            Intrinsics.checkNotNullExpressionValue(put2, str27);
                            HttpServer.Response response8 = new HttpServer.Response();
                            response8.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda07 = HttpServer.trusted;
                            response8.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put2);
                            return response8;
                        }
                        TvShell tvShell = TvShell.INSTANCE;
                        Intrinsics.checkNotNull(optString3);
                        Intrinsics.checkNotNull(optString4);
                        return setupApi.text(60000L, tvShell.tvset(optString3, optString4));
                    case 590567976:
                        if (!str.equals("keytest/open")) {
                            return null;
                        }
                        LinkedHashMap linkedHashMap = SetupNeed.MIN;
                        SetupNeed.check(setupApi.link.get(), "keytest");
                        if (!StringsKt.contains(setupApi.sh("am start -n dev.tvremote.setup/.KeyTestActivity 2>&1"), "Error", false)) {
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda08 = HttpServer.trusted;
                            byte[] bytes2 = WorkService.Companion.bytes("{\"ok\":true}");
                            HttpServer.Response response9 = new HttpServer.Response();
                            response9.type = "application/json; charset=utf-8";
                            response9.body = bytes2;
                            return response9;
                        }
                        throw new IllegalArgumentException("the TV did not open the key tester");
                    case 1233099618:
                        if (!str.equals("welcome")) {
                            return null;
                        }
                        Set set = Welcome.VIDEO;
                        JSONObject call = Welcome.call(new SetupApi$$ExternalSyntheticLambda0(setupApi, 7), request.json(65536));
                        HttpServer.Response response10 = new HttpServer.Response();
                        response10.status = 200;
                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda09 = HttpServer.trusted;
                        response10.body = Census$$ExternalSyntheticOutline0.m("toString(...)", call);
                        return response10;
                    default:
                        return null;
                }
            case -1360467711:
                str2 = "\n";
                str11 = "text";
                str3 = str20;
                str6 = "anim";
                str7 = "key";
                if (!str.equals("telegram")) {
                    obj = "support/tv";
                    str4 = "state";
                    obj2 = "telegram";
                    str8 = "put(...)";
                    str5 = str11;
                    if (z) {
                    }
                } else {
                    JSONObject telegram2 = setupApi.telegram(request);
                    HttpServer.Response response11 = new HttpServer.Response();
                    response11.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda010 = HttpServer.trusted;
                    response11.body = Census$$ExternalSyntheticOutline0.m("toString(...)", telegram2);
                    return response11;
                }
                break;
            case -613943102:
                str2 = "\n";
                str11 = "text";
                str3 = str20;
                str6 = "anim";
                str7 = "key";
                if (!str.equals("support/tv") || z) {
                    obj = "support/tv";
                    str8 = "put(...)";
                    obj2 = "telegram";
                    str4 = "state";
                    str5 = str11;
                    if (z) {
                    }
                } else {
                    JSONObject supportTv2 = setupApi.supportTv("state");
                    HttpServer.Response response12 = new HttpServer.Response();
                    response12.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda011 = HttpServer.trusted;
                    response12.body = Census$$ExternalSyntheticOutline0.m("toString(...)", supportTv2);
                    return response12;
                }
                break;
            case -351698711:
                str2 = "\n";
                str11 = "text";
                str3 = str20;
                str6 = "anim";
                str7 = "key";
                if (!str.equals("welcome/thumb")) {
                    str8 = "put(...)";
                    obj = "support/tv";
                    obj2 = "telegram";
                    str4 = "state";
                    str5 = str11;
                    if (z) {
                    }
                } else {
                    Set set2 = Welcome.VIDEO;
                    String optString5 = Welcome.call(new SetupApi$$ExternalSyntheticLambda0(setupApi, 5), new JSONObject().put("do", "thumb")).optString("thumb");
                    Intrinsics.checkNotNull(optString5);
                    if (optString5.length() == 0) {
                        JSONObject m9m = Census$$ExternalSyntheticOutline0.m9m("error", "no picture", "put(...)");
                        HttpServer.Response response13 = new HttpServer.Response();
                        response13.status = 404;
                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda012 = HttpServer.trusted;
                        response13.body = Census$$ExternalSyntheticOutline0.m("toString(...)", m9m);
                        return response13;
                    }
                    byte[] decode = B64.decode(optString5);
                    HttpServer.Response response14 = new HttpServer.Response();
                    response14.type = "image/jpeg";
                    response14.body = decode;
                    return response14;
                }
                break;
            case 108873975:
                str2 = "\n";
                str12 = "text";
                str6 = "anim";
                str7 = "key";
                if (!str.equals(obj3) || z) {
                    obj3 = obj3;
                    str3 = str20;
                    str8 = "put(...)";
                    obj = "support/tv";
                    obj2 = "telegram";
                    str4 = "state";
                    str5 = str12;
                    if (z) {
                    }
                } else {
                    JSONObject rules2 = setupApi.rules(null);
                    HttpServer.Response response15 = new HttpServer.Response();
                    response15.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda013 = HttpServer.trusted;
                    response15.body = Census$$ExternalSyntheticOutline0.m("toString(...)", rules2);
                    return response15;
                }
                break;
            case 110757536:
                str2 = "\n";
                if (str.equals("tvset")) {
                    if (z) {
                        str12 = "text";
                        str6 = "anim";
                        str7 = "key";
                        str8 = "put(...)";
                        obj = "support/tv";
                        str3 = str20;
                        obj2 = "telegram";
                        str4 = "state";
                        str5 = str12;
                        if (z) {
                        }
                    } else {
                        String replace$default = StringsKt__StringsJVMKt.replace$default(setupApi.link.get().shell(60000L, "echo sdk $(getprop ro.build.version.sdk); echo dns_mode $(settings get global private_dns_mode); echo dns_host $(settings get global private_dns_specifier); echo dns_off $(settings get global tvr_dns_off); echo sleep $(settings get secure sleep_timeout); echo saver $(settings get secure screensaver_enabled); echo saver_after $(settings get system screen_off_timeout); wm density; echo home $({ p=$(cmd role get-role-holders android.app.role.HOME 2>/dev/null); c=$([ -n \"$p\" ] && cmd package query-activities --brief -a android.intent.action.MAIN -c android.intent.category.HOME 2>/dev/null | grep -m1 \"^ *$p/\"); if [ -n \"$c\" ]; then echo $c; else cmd package resolve-activity --brief -c android.intent.category.HOME -a android.intent.action.MAIN; fi; } | tail -n 1); cmd package query-activities --brief -a android.intent.action.MAIN -c android.intent.category.HOME | grep / | sed 's/^ */launcher /'"), "\r\n", str2);
                        try {
                            rec = new LauncherSwap(new SetupApi$$ExternalSyntheticLambda0(setupApi, 11)).state();
                        } catch (IOException unused) {
                            rec = null;
                        }
                        if (rec != null && rec.getActive()) {
                            for (String str28 : rec.off) {
                                if (ArraysKt.contains(str28, Setup.LAUNCHER)) {
                                    StringBuilder sb3 = new StringBuilder();
                                    sb3.append(str28);
                                    str14 = str20;
                                    sb3.append(str14);
                                    if (!StringsKt.contains(replace$default, sb3.toString(), false)) {
                                        replace$default = replace$default + "\nlauncher " + str28 + str14;
                                    }
                                } else {
                                    str14 = str20;
                                }
                                str20 = str14;
                            }
                        }
                        if (rec != null) {
                            str13 = rec.why;
                        } else {
                            str13 = null;
                        }
                        if (Intrinsics.areEqual(str13, "key") && rec.state.equals("kept")) {
                            List lines = StringsKt.lines(replace$default);
                            if (!lines.isEmpty()) {
                                Iterator it4 = lines.iterator();
                                while (true) {
                                    if (it4.hasNext()) {
                                        String obj6 = StringsKt.trim((String) it4.next()).toString();
                                        String str29 = rec.comp;
                                        if (Intrinsics.areEqual(obj6, "launcher ".concat(str29))) {
                                            Pattern compile4 = Pattern.compile("(?m)^home .*$");
                                            Intrinsics.checkNotNullExpressionValue(compile4, "compile(...)");
                                            String replacement = "home ".concat(str29);
                                            Intrinsics.checkNotNullParameter(replacement, "replacement");
                                            replace$default = compile4.matcher(replace$default).replaceAll(replacement);
                                            Intrinsics.checkNotNullExpressionValue(replace$default, "replaceAll(...)");
                                        }
                                    }
                                }
                            }
                        }
                        JSONObject m9m2 = Census$$ExternalSyntheticOutline0.m9m("text", replace$default, "put(...)");
                        HttpServer.Response response16 = new HttpServer.Response();
                        response16.status = 200;
                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda014 = HttpServer.trusted;
                        response16.body = Census$$ExternalSyntheticOutline0.m("toString(...)", m9m2);
                        return response16;
                    }
                }
                obj = "support/tv";
                str3 = str20;
                obj2 = "telegram";
                str4 = "state";
                str5 = "text";
                str6 = "anim";
                str7 = "key";
                str8 = "put(...)";
                if (z) {
                }
                break;
            case 1026008296:
                str2 = "\n";
                if (!str.equals("setup/need")) {
                    setupApi = this;
                    obj = "support/tv";
                    str3 = str20;
                    obj2 = "telegram";
                    str4 = "state";
                    str5 = "text";
                    str6 = "anim";
                    str7 = "key";
                    str8 = "put(...)";
                    if (z) {
                    }
                } else {
                    LinkedHashMap linkedHashMap2 = SetupNeed.MIN;
                    SetupNeed.check(this.link.get(), request.q("f"));
                    JSONObject put3 = new JSONObject().put("ok", true);
                    Intrinsics.checkNotNullExpressionValue(put3, "put(...)");
                    HttpServer.Response response17 = new HttpServer.Response();
                    response17.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda015 = HttpServer.trusted;
                    response17.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put3);
                    return response17;
                }
                break;
            case 1026074491:
                str2 = "\n";
                if (str.equals("setup/plan")) {
                    Setup setup2 = new Setup(setupApi.link.get(), setupApi.dir, request.getLang(), new Bloat$$ExternalSyntheticLambda0(3));
                    SetupApi$$ExternalSyntheticLambda0 setupApi$$ExternalSyntheticLambda0 = new SetupApi$$ExternalSyntheticLambda0(setupApi, 6);
                    setup2.tvOnly();
                    Bloat.fresh();
                    Function1 function1 = setup2.sh;
                    boolean z4 = false;
                    List split$default2 = StringsKt.split$default((CharSequence) function1.invoke("pm list packages -e"), new String[]{str2}, 0, 6);
                    ArrayList arrayList6 = new ArrayList();
                    for (Object obj7 : split$default2) {
                        if (StringsKt__StringsJVMKt.startsWith((String) obj7, z4, "package:")) {
                            arrayList6.add(obj7);
                        }
                        z4 = false;
                    }
                    ArrayList arrayList7 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList6));
                    Iterator it5 = arrayList6.iterator();
                    while (it5.hasNext()) {
                        String substring = ((String) it5.next()).substring(8);
                        Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
                        arrayList7.add(StringsKt.trim(substring).toString());
                    }
                    Set set3 = CollectionsKt.toSet(arrayList7);
                    Set handlers = setup2.handlers();
                    List split$default3 = StringsKt.split$default((CharSequence) function1.invoke("dumpsys package packages 2>/dev/null | awk '/^  Package \\[/{p=$2} / pkgFlags=\\[.*PERSISTENT/{print substr(p,2,length(p)-2)}'"), new String[]{str2}, 0, 6);
                    ArrayList arrayList8 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(split$default3));
                    Iterator it6 = split$default3.iterator();
                    while (it6.hasNext()) {
                        arrayList8.add(StringsKt.trim((String) it6.next()).toString());
                    }
                    ArrayList arrayList9 = new ArrayList();
                    Iterator it7 = arrayList8.iterator();
                    while (it7.hasNext()) {
                        Object next2 = it7.next();
                        if (((String) next2).length() > 0) {
                            arrayList9.add(next2);
                        }
                    }
                    LinkedHashSet plus = SetsKt.plus(handlers, CollectionsKt.toSet(arrayList9));
                    ArrayList suggested = Setup.suggested();
                    ArrayList arrayList10 = new ArrayList();
                    Iterator it8 = suggested.iterator();
                    while (it8.hasNext()) {
                        Object next3 = it8.next();
                        String str30 = (String) next3;
                        if (set3.contains(str30) && !plus.contains(str30)) {
                            arrayList10.add(next3);
                        }
                    }
                    String homeNow2 = setup2.homeNow();
                    HashSet hashSet = new HashSet();
                    String[] strArr6 = {"LEANBACK_LAUNCHER", "LAUNCHER"};
                    int i2 = 0;
                    while (i2 < 2) {
                        String[] strArr7 = strArr6;
                        int i3 = i2;
                        for (String str31 : StringsKt.split$default((CharSequence) function1.invoke("cmd package query-activities --brief -a android.intent.action.MAIN -c android.intent.category." + strArr6[i2] + " 2>/dev/null"), new String[]{str2}, 0, 6)) {
                            if (StringsKt.contains$default(str31, '/')) {
                                String obj8 = StringsKt.trim(str31).toString();
                                hashSet.add(StringsKt.substringBefore(obj8, '/', obj8));
                            }
                        }
                        i2 = i3 + 1;
                        strArr6 = strArr7;
                    }
                    ArrayList arrayList11 = new ArrayList();
                    Iterator it9 = hashSet.iterator();
                    while (it9.hasNext()) {
                        Object next4 = it9.next();
                        String str32 = (String) next4;
                        if (set3.contains(str32) && !arrayList10.contains(str32) && !Intrinsics.areEqual(str32, homeNow2)) {
                            String[] strArr8 = Setup.GOOGLE;
                            if (!Rescue.mustKeep(str32) && !plus.contains(str32)) {
                                arrayList11.add(next4);
                            }
                        }
                    }
                    List sortedWith = CollectionsKt.sortedWith(arrayList11, new Setup$plan$$inlined$sortedBy$1(0, setupApi$$ExternalSyntheticLambda0));
                    JSONObject put4 = new JSONObject().put("anim", !Intrinsics.areEqual(StringsKt.trim((String) function1.invoke("settings get global window_animation_scale")).toString(), "0.0")).put("tvhome", setup2.has("dev.tvremote.home")).put("home", homeNow2);
                    ArrayList arrayList12 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList10));
                    Iterator it10 = arrayList10.iterator();
                    while (it10.hasNext()) {
                        arrayList12.add(Setup.plan$item(setupApi$$ExternalSyntheticLambda0, (String) it10.next()));
                    }
                    JSONObject put5 = put4.put("suggest", new JSONArray((Collection) arrayList12));
                    ArrayList arrayList13 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(sortedWith));
                    Iterator it11 = sortedWith.iterator();
                    while (it11.hasNext()) {
                        arrayList13.add(Setup.plan$item(setupApi$$ExternalSyntheticLambda0, (String) it11.next()));
                    }
                    JSONObject put6 = put5.put("apps", new JSONArray((Collection) arrayList13));
                    Intrinsics.checkNotNullExpressionValue(put6, "put(...)");
                    HttpServer.Response response18 = new HttpServer.Response();
                    response18.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda016 = HttpServer.trusted;
                    response18.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put6);
                    return response18;
                }
                obj = "support/tv";
                str3 = str20;
                obj2 = "telegram";
                str4 = "state";
                str5 = "text";
                str6 = "anim";
                str7 = "key";
                str8 = "put(...)";
                if (z) {
                }
                break;
            case 1233099618:
                str2 = "\n";
                if (str.equals("welcome") && !z) {
                    JSONObject call2 = Welcome.call(new SetupApi$$ExternalSyntheticLambda0(setupApi, 4), null);
                    HttpServer.Response response19 = new HttpServer.Response();
                    response19.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda017 = HttpServer.trusted;
                    response19.body = Census$$ExternalSyntheticOutline0.m("toString(...)", call2);
                    return response19;
                }
                obj = "support/tv";
                str3 = str20;
                obj2 = "telegram";
                str4 = "state";
                str5 = "text";
                str6 = "anim";
                str7 = "key";
                str8 = "put(...)";
                if (z) {
                }
                break;
            case 1348519750:
                str2 = "\n";
                if (str.equals("setup/version")) {
                    Adb adb2 = setupApi.link.get();
                    Regex regex4 = SetupUpdate.VERSION;
                    String installed2 = SetupUpdate.installed(adb2);
                    JSONObject put7 = SetupUpdate.state(adb2).put("installed", installed2).put("latest", "");
                    if (!Census.getEnabled() || (!Intrinsics.areEqual(put7.optString("detail"), "noadb") && !SetsKt.setOf((Object[]) new String[]{"rolledback", "broken"}).contains(put7.optString("state")))) {
                        str15 = "toString(...)";
                    } else {
                        try {
                            ConcurrentHashMap concurrentHashMap3 = Adb.ASKING;
                            str15 = "toString(...)";
                        } catch (Exception unused2) {
                            str15 = "toString(...)";
                        }
                        try {
                            String shell = adb2.shell(120000L, "mv /data/local/tmp/tvr-update/report /data/local/tmp/tvr-update/report.sent 2>/dev/null && cat /data/local/tmp/tvr-update/report.sent");
                            if (!StringsKt.isBlank(shell)) {
                                String optString6 = put7.optString("state");
                                Pattern compile5 = Pattern.compile("ro.product.model=(.*)");
                                Intrinsics.checkNotNullExpressionValue(compile5, "compile(...)");
                                Matcher matcher = compile5.matcher(shell);
                                Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
                                MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, shell);
                                if (access$findNext != null && (str17 = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)) != null) {
                                    str16 = StringsKt.trim(str17).toString();
                                } else {
                                    str16 = null;
                                }
                                if (str16 != null) {
                                    str19 = str16;
                                }
                                Census.crash("TV Setup update " + optString6 + " " + str19, "TV Setup " + put7.optString("from") + " -> " + put7.optString("version") + ": " + put7.optString("state") + " " + put7.optString("detail"), shell, null);
                            }
                        } catch (Exception unused3) {
                            if (installed2.length() != 0) {
                            }
                            HttpServer.Response response20 = new HttpServer.Response();
                            response20.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda018 = HttpServer.trusted;
                            response20.body = Census$$ExternalSyntheticOutline0.m(str15, put7);
                            return response20;
                        }
                    }
                    if (installed2.length() != 0) {
                        Intrinsics.checkNotNull(put7);
                    } else {
                        try {
                            z2 = StringsKt.contains(adb2.shell(120000L, "content call --uri content://dev.tvremote.setup.home --method updates 2>/dev/null"), "\"silent\":true", false);
                        } catch (IOException unused4) {
                            z2 = false;
                        }
                        put7.put("silent", z2);
                        try {
                            release = setupApi.latestSetup(installed2);
                        } catch (Exception e) {
                            String message = e.getMessage();
                            if (message == null) {
                                message = e.getClass().getSimpleName();
                            }
                            put7.put("error", message);
                            release = null;
                        }
                        if (release != null) {
                            Regex regex5 = SetupUpdate.VERSION;
                            String str33 = release.version;
                            if (!SetupUpdate.bad(str33, put7)) {
                                put7.put("latest", str33).put("notes", release.notes);
                            }
                        }
                    }
                    HttpServer.Response response202 = new HttpServer.Response();
                    response202.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0182 = HttpServer.trusted;
                    response202.body = Census$$ExternalSyntheticOutline0.m(str15, put7);
                    return response202;
                }
                obj = "support/tv";
                str3 = str20;
                obj2 = "telegram";
                str4 = "state";
                str5 = "text";
                str6 = "anim";
                str7 = "key";
                str8 = "put(...)";
                if (z) {
                }
                break;
            case 2094431484:
                if (str.equals("setup/restore") && !z) {
                    JSONObject put8 = new JSONObject().put("has", new Setup(setupApi.link.get(), setupApi.dir, request.getLang(), new Bloat$$ExternalSyntheticLambda0(3)).optimized());
                    Intrinsics.checkNotNullExpressionValue(put8, "put(...)");
                    HttpServer.Response response21 = new HttpServer.Response();
                    response21.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda019 = HttpServer.trusted;
                    response21.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put8);
                    return response21;
                }
            default:
                str2 = "\n";
                obj = "support/tv";
                str3 = str20;
                obj2 = "telegram";
                str4 = "state";
                str5 = "text";
                str6 = "anim";
                str7 = "key";
                str8 = "put(...)";
                if (z) {
                }
                break;
        }
    }

    public final JSONObject rules(JSONObject jSONObject) {
        RemoteLabels remoteLabels;
        JSONObject call = RulesClient.call(new SetupApi$$ExternalSyntheticLambda0(this, 10), jSONObject);
        JSONArray optJSONArray = call.optJSONArray("limits");
        if (optJSONArray != null && (remoteLabels = this.labels) != null) {
            int length = optJSONArray.length();
            for (int i = 0; i < length; i++) {
                JSONObject optJSONObject = optJSONArray.optJSONObject(i);
                if (optJSONObject != null && !optJSONObject.has("label")) {
                    String optString = optJSONObject.optString("pkg");
                    Intrinsics.checkNotNullExpressionValue(optString, "optString(...)");
                    String label = remoteLabels.label(optString);
                    if (label != null) {
                        optJSONObject.put("label", label);
                    }
                }
            }
        }
        return call;
    }

    public final JSONObject supportTv(String str) {
        JSONObject m10m = Census$$ExternalSyntheticOutline0.m10m("do", "support", "act", str);
        JSONObject call = RulesClient.call(new SetupApi$$ExternalSyntheticLambda0(this, 12), m10m);
        if (Intrinsics.areEqual(call.optString("setup"), "busy")) {
            sh("for p in dev.tvremote.setup dev.tvremote.home; do pm path $p >/dev/null 2>&1 || continue; dumpsys deviceidle whitelist +$p >/dev/null 2>&1; am set-standby-bucket $p active >/dev/null 2>&1; cmd appops set $p RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1; done; cmd deviceidle whitelist +dev.tvremote.setup >/dev/null 2>&1; am startservice -n dev.tvremote.setup/.RemoteService 2>&1 | grep -q Error && am start-foreground-service -n dev.tvremote.setup/.RemoteService >/dev/null 2>&1");
            Thread.sleep(2500L);
            call = RulesClient.call(new SetupApi$$ExternalSyntheticLambda0(this, 13), m10m);
        }
        String optString = call.optString("setup");
        if (!Intrinsics.areEqual(optString, "missing") && !Intrinsics.areEqual(optString, "old") && !Intrinsics.areEqual(call.optString("error"), "unknown action")) {
            if (!Intrinsics.areEqual(optString, "busy")) {
                return call;
            }
            throw new IOException("adb: TV Setup is starting");
        }
        throw new SetupNeed.Missing("support", SetupNeed.have(new SetupApi$$ExternalSyntheticLambda0(this, 14)));
    }

    public final JSONObject telegram(HttpServer.Request request) {
        JSONObject jSONObject = new JSONObject();
        if (request.method.equals("POST")) {
            jSONObject.put("body", request.json(65536));
        } else {
            JSONObject jSONObject2 = new JSONObject();
            for (String str : ArraysKt.asList(new String[]{"history", "chat", "offset"})) {
                if (request.q(str).length() > 0) {
                    jSONObject2.put(str, request.q(str));
                }
            }
            jSONObject.put("query", jSONObject2);
        }
        Set set = RulesClient.SETUP_KEYS;
        JSONObject call = RulesClient.call(new SetupApi$$ExternalSyntheticLambda0(this, 0), new JSONObject().put("do", "telegram").put("req", jSONObject));
        if (Intrinsics.areEqual(call.optString("failed"), "not running")) {
            sh("for p in dev.tvremote.setup dev.tvremote.home; do pm path $p >/dev/null 2>&1 || continue; dumpsys deviceidle whitelist +$p >/dev/null 2>&1; am set-standby-bucket $p active >/dev/null 2>&1; cmd appops set $p RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1; done; cmd deviceidle whitelist +dev.tvremote.setup >/dev/null 2>&1; am startservice -n dev.tvremote.setup/.RemoteService 2>&1 | grep -q Error && am start-foreground-service -n dev.tvremote.setup/.RemoteService >/dev/null 2>&1");
            Thread.sleep(2500L);
            call = RulesClient.call(new SetupApi$$ExternalSyntheticLambda0(this, 8), new JSONObject().put("do", "telegram").put("req", jSONObject));
        }
        String optString = call.optString("setup");
        if (!Intrinsics.areEqual(optString, "missing") && !Intrinsics.areEqual(optString, "old") && !Intrinsics.areEqual(call.optString("error"), "unknown action")) {
            if (!Intrinsics.areEqual(optString, "busy")) {
                if (!call.has("failed")) {
                    return call;
                }
                throw new IllegalArgumentException(call.optString("failed"));
            }
            throw new IOException("adb: TV Setup is starting");
        }
        throw new SetupNeed.Missing("telegram", SetupNeed.have(new SetupApi$$ExternalSyntheticLambda0(this, 9)));
    }

    public final void welcomeStore(InputStream inputStream, long j, String str, JSONObject jSONObject) {
        String str2;
        String ext = Welcome.ext(str);
        String ext2 = Welcome.ext(str);
        if (Welcome.VIDEO.contains(ext2)) {
            str2 = "video";
        } else if (Welcome.IMAGE.contains(ext2)) {
            str2 = "image";
        } else {
            str2 = null;
        }
        if (str2 != null) {
            if (j <= 209715200) {
                LinkedHashMap linkedHashMap = SetupNeed.MIN;
                SetupNeed.check(this.link.get(), "welcome");
                ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                sh("mkdir -p " + Mdns.q("/sdcard/Android/data/dev.tvremote.setup/files/welcome"));
                String concat = "/sdcard/Android/data/dev.tvremote.setup/files/welcome/incoming.".concat(ext);
                this.copy.push(inputStream, j, concat, jSONObject, 1);
                try {
                    Welcome.call(new SetupApi$$ExternalSyntheticLambda0(this, 3), new JSONObject().put("do", "adopt").put("ext", ext).put("original", str));
                    return;
                } catch (Exception e) {
                    try {
                        ConcurrentHashMap concurrentHashMap2 = Adb.ASKING;
                        sh("rm -f " + Mdns.q(concat));
                        throw e;
                    } catch (Exception unused) {
                        throw e;
                    }
                }
            }
            throw new IllegalArgumentException("welcome:toobig");
        }
        throw new IllegalArgumentException("welcome:kind");
    }
}
