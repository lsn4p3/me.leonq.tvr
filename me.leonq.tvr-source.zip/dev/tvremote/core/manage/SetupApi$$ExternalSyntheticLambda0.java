package dev.tvremote.core.manage;

import dev.tvremote.core.ontv.RemoteLabels;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.conscrypt.FileClientSessionCache;
import org.conscrypt.metrics.ConscryptStatsLog;

/* loaded from: classes.dex */
public final /* synthetic */ class SetupApi$$ExternalSyntheticLambda0 implements Function1 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ SetupApi f$0;

    public /* synthetic */ SetupApi$$ExternalSyntheticLambda0(SetupApi setupApi, int i) {
        this.$r8$classId = i;
        this.f$0 = setupApi;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        String it = (String) obj;
        switch (this.$r8$classId) {
            case 0:
                Intrinsics.checkNotNullParameter(it, "it");
                return this.f$0.sh(it);
            case 1:
                Intrinsics.checkNotNullParameter(it, "it");
                return this.f$0.sh(it);
            case 2:
                Intrinsics.checkNotNullParameter(it, "it");
                return this.f$0.sh(it);
            case 3:
                Intrinsics.checkNotNullParameter(it, "it");
                return this.f$0.sh(it);
            case 4:
                Intrinsics.checkNotNullParameter(it, "it");
                return this.f$0.sh(it);
            case 5:
                Intrinsics.checkNotNullParameter(it, "it");
                return this.f$0.sh(it);
            case 6:
                Intrinsics.checkNotNullParameter(it, "it");
                RemoteLabels remoteLabels = this.f$0.labels;
                if (remoteLabels != null) {
                    return remoteLabels.label(it);
                }
                return null;
            case 7:
                Intrinsics.checkNotNullParameter(it, "it");
                return this.f$0.sh(it);
            case 8:
                Intrinsics.checkNotNullParameter(it, "it");
                return this.f$0.sh(it);
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                Intrinsics.checkNotNullParameter(it, "it");
                return this.f$0.sh(it);
            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                Intrinsics.checkNotNullParameter(it, "it");
                return this.f$0.sh(it);
            case 11:
                Intrinsics.checkNotNullParameter(it, "it");
                return this.f$0.sh(it);
            case FileClientSessionCache.MAX_SIZE /* 12 */:
                Intrinsics.checkNotNullParameter(it, "it");
                return this.f$0.sh(it);
            case 13:
                Intrinsics.checkNotNullParameter(it, "it");
                return this.f$0.sh(it);
            default:
                Intrinsics.checkNotNullParameter(it, "it");
                return this.f$0.sh(it);
        }
    }
}
