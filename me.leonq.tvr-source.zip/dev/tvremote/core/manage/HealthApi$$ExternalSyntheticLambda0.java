package dev.tvremote.core.manage;

import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final /* synthetic */ class HealthApi$$ExternalSyntheticLambda0 implements Function1 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ HealthApi f$0;

    public /* synthetic */ HealthApi$$ExternalSyntheticLambda0(HealthApi healthApi, int i) {
        this.$r8$classId = i;
        this.f$0 = healthApi;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        String it = (String) obj;
        switch (this.$r8$classId) {
            case 0:
                Intrinsics.checkNotNullParameter(it, "it");
                return this.f$0.sh(it);
            default:
                Intrinsics.checkNotNullParameter(it, "it");
                return this.f$0.sh(it);
        }
    }
}
