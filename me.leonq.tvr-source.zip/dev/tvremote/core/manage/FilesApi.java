package dev.tvremote.core.manage;

import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Words;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.Mdns;
import dev.tvremote.core.ontv.Axml$$ExternalSyntheticLambda1;
import dev.tvremote.core.ontv.Bloat$$ExternalSyntheticLambda1;
import dev.tvremote.core.remote.Vidaa$$ExternalSyntheticLambda0;
import dev.tvremote.core.web.Cancel;
import dev.tvremote.core.web.HttpServer;
import dev.tvremote.home.HomeQr$$ExternalSyntheticLambda0;
import dev.tvremote.phone.WorkService;
import dev.tvremote.update.Ed25519;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__MutableCollectionsJVMKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class FilesApi extends ManagePart {
    public final Pattern LS;
    public final TvCopy copy;
    public final InstallApi installs;
    public final SetupApi setupApi;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public FilesApi(Ed25519.Pt core, TvCopy copy, InstallApi installs, SetupApi setupApi) {
        super(core);
        Intrinsics.checkNotNullParameter(core, "core");
        Intrinsics.checkNotNullParameter(copy, "copy");
        Intrinsics.checkNotNullParameter(installs, "installs");
        Intrinsics.checkNotNullParameter(setupApi, "setupApi");
        this.copy = copy;
        this.installs = installs;
        this.setupApi = setupApi;
        this.LS = Pattern.compile("^([dl-])\\S+\\s+\\d+\\s+\\S+\\s+\\S+\\s+(\\d+)\\s+(\\d{4}-\\d\\d-\\d\\d \\d\\d:\\d\\d)\\s+(.+)$");
    }

    /* JADX WARN: Removed duplicated region for block: B:29:0x010e  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x016b  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x0225  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0242  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x0227  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x0187  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x01e8  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x011d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final HttpServer.Response fileOp(String str, JSONObject jSONObject) {
        String sh;
        String str2;
        String m;
        String mime$shared_release;
        int length;
        int i;
        String sh2;
        String sh3;
        AtomicLong atomicLong = TvPaths.tmpN;
        String optString = jSONObject.optString("path");
        if (optString != null && !StringsKt.isBlank(optString)) {
            String safePath$shared_release = TvPaths.safePath$shared_release(optString);
            int hashCode = str.hashCode();
            if (hashCode != -1335458389) {
                if (hashCode != -934594754) {
                    if (hashCode == 103950895 && str.equals("mkdir")) {
                        String substring = safePath$shared_release.substring(StringsKt.lastIndexOf$default(safePath$shared_release, '/', 6) + 1);
                        Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
                        if (!TvPaths.root$shared_release(safePath$shared_release) && substring.equals(TvPaths.safeName$shared_release(substring))) {
                            ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                            sh = sh("mkdir " + Mdns.q(safePath$shared_release) + " 2>&1");
                        } else {
                            throw new IllegalArgumentException("bad name");
                        }
                    }
                    if (StringsKt__StringsJVMKt.startsWith(safePath$shared_release, false, "/sdcard")) {
                        String substring2 = safePath$shared_release.substring(7);
                        Intrinsics.checkNotNullExpressionValue(substring2, "substring(...)");
                        str2 = "/storage/emulated/0".concat(substring2);
                    } else {
                        str2 = safePath$shared_release;
                    }
                    ConcurrentHashMap concurrentHashMap2 = Adb.ASKING;
                    m = Census$$ExternalSyntheticOutline0.m("-a android.intent.action.VIEW -d ", Mdns.q("file://" + CollectionsKt.joinToString$default(StringsKt.split$default(str2, new char[]{'/'}), "/", null, null, new Bloat$$ExternalSyntheticLambda1(3), 30)), " -t ", Mdns.q(TvPaths.mime$shared_release(safePath$shared_release)));
                    mime$shared_release = TvPaths.mime$shared_release(safePath$shared_release);
                    if (!StringsKt__StringsJVMKt.startsWith(mime$shared_release, false, "video/") || StringsKt__StringsJVMKt.startsWith(mime$shared_release, false, "audio/")) {
                        String substringAfterLast = StringsKt.substringAfterLast(str2, '.', "mp4");
                        StringBuilder sb = new StringBuilder();
                        length = substringAfterLast.length();
                        for (i = 0; i < length; i++) {
                            char charAt = substringAfterLast.charAt(i);
                            if (Character.isLetterOrDigit(charAt)) {
                                sb.append(charAt);
                            }
                        }
                        String concat = "play.".concat(StringsKt.take(sb.toString(), 5));
                        ConcurrentHashMap concurrentHashMap3 = Adb.ASKING;
                        sh2 = sh("cmd package resolve-activity --brief -n dev.tvremote.setup/.PlayActivity 2>&1 | grep -q PlayActivity || exit 3; mkdir -p /sdcard/Android/data/dev.tvremote.setup/files/play && rm -f /sdcard/Android/data/dev.tvremote.setup/files/play/* && cp " + Mdns.q(str2) + " /sdcard/Android/data/dev.tvremote.setup/files/play/" + concat + " && chmod 644 /sdcard/Android/data/dev.tvremote.setup/files/play/" + concat + " || exit 4; am start -n dev.tvremote.setup/.PlayActivity -d file:///sdcard/Android/data/dev.tvremote.setup/files/play/" + concat + " -t " + Mdns.q(mime$shared_release) + " 2>&1");
                        if (!StringsKt.contains(sh2, "Error", false) && !StringsKt.contains(sh2, "Exception", false) && StringsKt.contains(sh2, "Starting", false)) {
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = HttpServer.trusted;
                            byte[] bytes = WorkService.Companion.bytes("{\"ok\":true}");
                            HttpServer.Response response = new HttpServer.Response();
                            response.type = "application/json; charset=utf-8";
                            response.body = bytes;
                            return response;
                        }
                    }
                    if (StringsKt.contains(sh("cmd package resolve-activity --brief " + m + " 2>&1"), "frameworkpackagestubs", false)) {
                        sh3 = "Error";
                    } else {
                        sh3 = sh("am start " + m + " 2>&1");
                    }
                    if (!StringsKt.contains(sh3, "Error", false)) {
                        Locale ROOT = Locale.ROOT;
                        Intrinsics.checkNotNullExpressionValue(ROOT, "ROOT");
                        String lowerCase = sh3.toLowerCase(ROOT);
                        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                        if (!StringsKt.contains(lowerCase, "unable to resolve", false)) {
                            sh = "";
                        }
                    }
                    sh = "the TV has no app that can open this";
                } else {
                    if (str.equals("rename")) {
                        String optString2 = jSONObject.optString("name");
                        if (!TvPaths.root$shared_release(safePath$shared_release) && Intrinsics.areEqual(optString2, TvPaths.safeName$shared_release(optString2))) {
                            ConcurrentHashMap concurrentHashMap4 = Adb.ASKING;
                            String substring3 = safePath$shared_release.substring(0, StringsKt.lastIndexOf$default(safePath$shared_release, '/', 6));
                            Intrinsics.checkNotNullExpressionValue(substring3, "substring(...)");
                            String q = Mdns.q(substring3 + "/" + optString2);
                            sh = sh("if [ -e " + q + " ]; then echo 'a file with that name already exists'; else mv " + Mdns.q(safePath$shared_release) + " " + q + " 2>&1; fi");
                        } else {
                            throw new IllegalArgumentException("bad name");
                        }
                    }
                    if (StringsKt__StringsJVMKt.startsWith(safePath$shared_release, false, "/sdcard")) {
                    }
                    ConcurrentHashMap concurrentHashMap22 = Adb.ASKING;
                    m = Census$$ExternalSyntheticOutline0.m("-a android.intent.action.VIEW -d ", Mdns.q("file://" + CollectionsKt.joinToString$default(StringsKt.split$default(str2, new char[]{'/'}), "/", null, null, new Bloat$$ExternalSyntheticLambda1(3), 30)), " -t ", Mdns.q(TvPaths.mime$shared_release(safePath$shared_release)));
                    mime$shared_release = TvPaths.mime$shared_release(safePath$shared_release);
                    if (!StringsKt__StringsJVMKt.startsWith(mime$shared_release, false, "video/")) {
                    }
                    String substringAfterLast2 = StringsKt.substringAfterLast(str2, '.', "mp4");
                    StringBuilder sb2 = new StringBuilder();
                    length = substringAfterLast2.length();
                    while (i < length) {
                    }
                    String concat2 = "play.".concat(StringsKt.take(sb2.toString(), 5));
                    ConcurrentHashMap concurrentHashMap32 = Adb.ASKING;
                    sh2 = sh("cmd package resolve-activity --brief -n dev.tvremote.setup/.PlayActivity 2>&1 | grep -q PlayActivity || exit 3; mkdir -p /sdcard/Android/data/dev.tvremote.setup/files/play && rm -f /sdcard/Android/data/dev.tvremote.setup/files/play/* && cp " + Mdns.q(str2) + " /sdcard/Android/data/dev.tvremote.setup/files/play/" + concat2 + " && chmod 644 /sdcard/Android/data/dev.tvremote.setup/files/play/" + concat2 + " || exit 4; am start -n dev.tvremote.setup/.PlayActivity -d file:///sdcard/Android/data/dev.tvremote.setup/files/play/" + concat2 + " -t " + Mdns.q(mime$shared_release) + " 2>&1");
                    if (!StringsKt.contains(sh2, "Error", false)) {
                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda02 = HttpServer.trusted;
                        byte[] bytes2 = WorkService.Companion.bytes("{\"ok\":true}");
                        HttpServer.Response response2 = new HttpServer.Response();
                        response2.type = "application/json; charset=utf-8";
                        response2.body = bytes2;
                        return response2;
                    }
                    if (StringsKt.contains(sh("cmd package resolve-activity --brief " + m + " 2>&1"), "frameworkpackagestubs", false)) {
                    }
                    if (!StringsKt.contains(sh3, "Error", false)) {
                    }
                    sh = "the TV has no app that can open this";
                }
            } else {
                if (str.equals("delete")) {
                    if (!TvPaths.root$shared_release(safePath$shared_release)) {
                        ConcurrentHashMap concurrentHashMap5 = Adb.ASKING;
                        sh = sh("rm -rf " + Mdns.q(safePath$shared_release) + " 2>&1");
                    } else {
                        throw new IllegalArgumentException("refusing to delete a storage root");
                    }
                }
                if (StringsKt__StringsJVMKt.startsWith(safePath$shared_release, false, "/sdcard")) {
                }
                ConcurrentHashMap concurrentHashMap222 = Adb.ASKING;
                m = Census$$ExternalSyntheticOutline0.m("-a android.intent.action.VIEW -d ", Mdns.q("file://" + CollectionsKt.joinToString$default(StringsKt.split$default(str2, new char[]{'/'}), "/", null, null, new Bloat$$ExternalSyntheticLambda1(3), 30)), " -t ", Mdns.q(TvPaths.mime$shared_release(safePath$shared_release)));
                mime$shared_release = TvPaths.mime$shared_release(safePath$shared_release);
                if (!StringsKt__StringsJVMKt.startsWith(mime$shared_release, false, "video/")) {
                }
                String substringAfterLast22 = StringsKt.substringAfterLast(str2, '.', "mp4");
                StringBuilder sb22 = new StringBuilder();
                length = substringAfterLast22.length();
                while (i < length) {
                }
                String concat22 = "play.".concat(StringsKt.take(sb22.toString(), 5));
                ConcurrentHashMap concurrentHashMap322 = Adb.ASKING;
                sh2 = sh("cmd package resolve-activity --brief -n dev.tvremote.setup/.PlayActivity 2>&1 | grep -q PlayActivity || exit 3; mkdir -p /sdcard/Android/data/dev.tvremote.setup/files/play && rm -f /sdcard/Android/data/dev.tvremote.setup/files/play/* && cp " + Mdns.q(str2) + " /sdcard/Android/data/dev.tvremote.setup/files/play/" + concat22 + " && chmod 644 /sdcard/Android/data/dev.tvremote.setup/files/play/" + concat22 + " || exit 4; am start -n dev.tvremote.setup/.PlayActivity -d file:///sdcard/Android/data/dev.tvremote.setup/files/play/" + concat22 + " -t " + Mdns.q(mime$shared_release) + " 2>&1");
                if (!StringsKt.contains(sh2, "Error", false)) {
                }
                if (StringsKt.contains(sh("cmd package resolve-activity --brief " + m + " 2>&1"), "frameworkpackagestubs", false)) {
                }
                if (!StringsKt.contains(sh3, "Error", false)) {
                }
                sh = "the TV has no app that can open this";
            }
            if (StringsKt.trim(sh).toString().length() <= 0) {
                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda03 = HttpServer.trusted;
                byte[] bytes3 = WorkService.Companion.bytes("{\"ok\":true}");
                HttpServer.Response response3 = new HttpServer.Response();
                response3.type = "application/json; charset=utf-8";
                response3.body = bytes3;
                return response3;
            }
            throw new IllegalArgumentException(StringsKt.trim(sh).toString());
        }
        throw new IllegalArgumentException("path missing");
    }

    /* JADX WARN: Code restructure failed: missing block: B:103:0x0390, code lost:
    
        if (r13.length() > 0) goto L83;
     */
    /* JADX WARN: Code restructure failed: missing block: B:110:0x03e4, code lost:
    
        if (r13.length() > 0) goto L83;
     */
    /* JADX WARN: Code restructure failed: missing block: B:115:0x0446, code lost:
    
        if (r13.length() > 0) goto L83;
     */
    /* JADX WARN: Code restructure failed: missing block: B:91:0x044a, code lost:
    
        r2 = new dev.tvremote.core.web.HttpServer.Response();
        r2.status = 200;
        r3 = dev.tvremote.core.web.HttpServer.trusted;
        r2.body = dev.tvremote.core.Census$$ExternalSyntheticOutline0.m(r16, r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:92:0x045d, code lost:
    
        return r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:98:0x0364, code lost:
    
        if (r13.length() > 0) goto L83;
     */
    @Override // dev.tvremote.core.manage.ManagePart
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final HttpServer.Response route(String str, boolean z, HttpServer.Request request) {
        String str2;
        JSONObject put;
        String[] strArr;
        String[] strArr2;
        int i;
        int i2 = 0;
        boolean equals = str.equals("files");
        Regex regex = ManagePart.DIGITS;
        if (equals) {
            String safePath$shared_release = TvPaths.safePath$shared_release(request.q("path"));
            ConcurrentHashMap concurrentHashMap = Adb.ASKING;
            String q = Mdns.q(safePath$shared_release.concat("/"));
            String[] jsplit = Fleet.jsplit(sh(Census$$ExternalSyntheticOutline0.m("ls -lA ", q, " 2>&1 | cat; echo '#--'; df -k ", q, " 2>/dev/null | tail -1; echo '#--'; ls /storage 2>/dev/null")), -1, "#--");
            ArrayList arrayList = new ArrayList();
            String[] jsplit2 = Fleet.jsplit(jsplit[0], 0, "\n");
            int length = jsplit2.length;
            int i3 = 0;
            while (i3 < length) {
                String str3 = jsplit2[i3];
                Matcher matcher = this.LS.matcher(StringsKt.trim(str3).toString());
                if (matcher.matches()) {
                    String group = matcher.group(4);
                    Intrinsics.checkNotNull(group);
                    JSONObject put2 = Census$$ExternalSyntheticOutline0.m8m("name", Fleet.jsplit(group, i2, " -> ")[i2]).put("dir", !Intrinsics.areEqual(matcher.group(1), "-"));
                    String group2 = matcher.group(2);
                    Intrinsics.checkNotNull(group2);
                    strArr2 = jsplit2;
                    i = length;
                    arrayList.add(put2.put("size", Long.parseLong(group2)).put("mtime", matcher.group(3)));
                } else {
                    strArr2 = jsplit2;
                    i = length;
                    if (StringsKt.contains(str3, "No such file", false) || StringsKt.contains(str3, "Permission denied", false)) {
                        throw new IllegalArgumentException(StringsKt.trim(str3).toString());
                    }
                }
                i3++;
                jsplit2 = strArr2;
                length = i;
                i2 = 0;
            }
            CollectionsKt__MutableCollectionsJVMKt.sortWith(arrayList, new FilesApi$$ExternalSyntheticLambda3(0, new Vidaa$$ExternalSyntheticLambda0(1)));
            JSONObject put3 = new JSONObject().put("path", safePath$shared_release).put("items", new JSONArray((Collection) arrayList));
            if (jsplit.length > 1) {
                strArr = Fleet.jsplit(StringsKt.trim(jsplit[1]).toString(), 0, "\\s+");
            } else {
                strArr = new String[0];
            }
            if (strArr.length > 3 && regex.matches(strArr[1]) && regex.matches(strArr[3])) {
                long j = 1024;
                put3.put("space", new JSONObject().put("total", Long.parseLong(strArr[1]) * j).put("free", Long.parseLong(strArr[3]) * j));
            }
            JSONArray jSONArray = new JSONArray();
            if (jsplit.length > 2) {
                for (String str4 : Fleet.jsplit(StringsKt.trim(jsplit[2]).toString(), 0, "\\s+")) {
                    if (str4.length() > 0 && !str4.equals("emulated") && !str4.equals("self") && !StringsKt__StringsJVMKt.startsWith(str4, false, "sdcard")) {
                        jSONArray.put(str4);
                    }
                }
            }
            JSONObject put4 = put3.put("volumes", jSONArray);
            Intrinsics.checkNotNullExpressionValue(put4, "put(...)");
            HttpServer.Response response = new HttpServer.Response();
            response.status = 200;
            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = HttpServer.trusted;
            response.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put4);
            return response;
        }
        if (str.equals("file")) {
            AtomicLong atomicLong = TvPaths.tmpN;
            String safePath$shared_release2 = TvPaths.safePath$shared_release(request.q("path"));
            Adb adb = this.link.get();
            ConcurrentHashMap concurrentHashMap2 = Adb.ASKING;
            String q2 = Mdns.q(safePath$shared_release2);
            String q3 = Mdns.q(safePath$shared_release2);
            String q4 = Mdns.q(safePath$shared_release2);
            StringBuilder sb = new StringBuilder("[ -f ");
            sb.append(q2);
            sb.append(" ] && [ -r ");
            sb.append(q3);
            sb.append(" ] && stat -c %s ");
            String obj = StringsKt.trim(adb.shell(120000L, Census$$ExternalSyntheticOutline0.m(sb, q4, " 2>/dev/null"))).toString();
            if (regex.matches(obj)) {
                boolean equals2 = request.q("inline").equals("1");
                String str5 = "application/octet-stream";
                if (equals2) {
                    str5 = StringsKt__StringsJVMKt.replace$default(TvPaths.mime$shared_release(safePath$shared_release2), "*/*", "application/octet-stream");
                }
                long parseLong = Long.parseLong(obj);
                Axml$$ExternalSyntheticLambda1 axml$$ExternalSyntheticLambda1 = new Axml$$ExternalSyntheticLambda1(this, adb, safePath$shared_release2, 2);
                HttpServer.Response response2 = new HttpServer.Response();
                response2.type = str5;
                response2.length = parseLong;
                response2.stream = axml$$ExternalSyntheticLambda1;
                response2.patient = true;
                if (!equals2) {
                    HashMap hashMap = response2.headers;
                    String substring = safePath$shared_release2.substring(StringsKt.lastIndexOf$default(safePath$shared_release2, '/', 6) + 1);
                    Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
                    String encode = URLEncoder.encode(substring, "UTF-8");
                    Intrinsics.checkNotNullExpressionValue(encode, "encode(...)");
                    hashMap.put("Content-Disposition", "attachment; filename*=UTF-8''".concat(StringsKt__StringsJVMKt.replace$default(encode, "+", "%20")));
                }
                return response2;
            }
            throw new IllegalArgumentException("cannot read this file");
        }
        if (z) {
            switch (str.hashCode()) {
                case -1937490127:
                    if (!str.equals("file/rename")) {
                        return null;
                    }
                    break;
                case -1360752899:
                    if (!str.equals("file/open")) {
                        return null;
                    }
                    break;
                case -838595071:
                    if (str.equals("upload")) {
                        AtomicLong atomicLong2 = TvPaths.tmpN;
                        String safeName$shared_release = TvPaths.safeName$shared_release(request.q("name"));
                        FilesApi$$ExternalSyntheticLambda4 filesApi$$ExternalSyntheticLambda4 = new FilesApi$$ExternalSyntheticLambda4(0, this, safeName$shared_release);
                        String take = StringsKt.take(request.q("uid"), 64);
                        Cancel cancel = new Cancel();
                        if (take.length() > 0) {
                            str2 = "toString(...)";
                            getStops().put(take, cancel);
                        } else {
                            str2 = "toString(...)";
                        }
                        getCurrent().set(cancel);
                        try {
                            boolean equals3 = request.q("kind").equals("install");
                            InstallApi installApi = this.installs;
                            if (equals3) {
                                Object invoke = filesApi$$ExternalSyntheticLambda4.invoke("install ".concat(safeName$shared_release), installApi.installUpload(request));
                                Intrinsics.checkNotNullExpressionValue(invoke, "invoke(...)");
                                put = (JSONObject) invoke;
                                break;
                            } else if (request.q("kind").equals("installcopy")) {
                                Object invoke2 = filesApi$$ExternalSyntheticLambda4.invoke("install ".concat(safeName$shared_release), "installed ".concat(installApi.installCopy(request)));
                                Intrinsics.checkNotNullExpressionValue(invoke2, "invoke(...)");
                                put = (JSONObject) invoke2;
                                getCurrent().remove();
                                break;
                            } else if (request.q("kind").equals("restore")) {
                                installApi.restore(request);
                                Object invoke3 = filesApi$$ExternalSyntheticLambda4.invoke("restore ".concat(safeName$shared_release), "restored");
                                Intrinsics.checkNotNullExpressionValue(invoke3, "invoke(...)");
                                put = (JSONObject) invoke3;
                                getCurrent().remove();
                                break;
                            } else if (request.q("kind").equals("welcome")) {
                                SetupApi setupApi = this.setupApi;
                                setupApi.getClass();
                                long j2 = request.length;
                                if (j2 > 0) {
                                    setupApi.welcomeStore(request.body, j2, safeName$shared_release, null);
                                    String concat = "welcome ".concat(safeName$shared_release);
                                    ConcurrentHashMap concurrentHashMap3 = Words.books;
                                    Object invoke4 = filesApi$$ExternalSyntheticLambda4.invoke(concat, Words.get(request.getLang(), "welcome.saved", new Pair[0]));
                                    Intrinsics.checkNotNullExpressionValue(invoke4, "invoke(...)");
                                    put = (JSONObject) invoke4;
                                    getCurrent().remove();
                                    break;
                                } else {
                                    throw new IllegalArgumentException("empty upload");
                                }
                            } else {
                                String str6 = TvPaths.safePath$shared_release(request.q("dest")) + "/" + safeName$shared_release;
                                this.copy.push(request.body, request.length, str6, null, 1);
                                put = ((JSONObject) filesApi$$ExternalSyntheticLambda4.invoke("upload ".concat(safeName$shared_release), "saved ".concat(str6))).put("dest", str6);
                                Intrinsics.checkNotNullExpressionValue(put, "put(...)");
                                getCurrent().remove();
                                break;
                            }
                        } finally {
                            getCurrent().remove();
                            if (take.length() > 0) {
                                getStops().remove(take);
                            }
                        }
                    } else {
                        return null;
                    }
                case 764336092:
                    if (!str.equals("file/mkdir")) {
                        return null;
                    }
                    break;
                case 1956613534:
                    if (!str.equals("file/delete")) {
                        return null;
                    }
                    break;
                default:
                    return null;
            }
            String substring2 = str.substring(5);
            Intrinsics.checkNotNullExpressionValue(substring2, "substring(...)");
            return fileOp(substring2, request.json(65536));
        }
        return null;
    }
}
