package dev.tvremote.core.manage;

import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.ontv.Bloat$$ExternalSyntheticLambda1;
import java.util.Set;
import kotlin.Pair;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;

/* loaded from: classes.dex */
public abstract class Splits {
    public static final Regex LINE = new Regex("^\\s*(\\d+)\\s+\\S+\\s+\\S+\\s+(.+?)\\s*$");
    public static final Object DENSITY = MapsKt__MapsKt.mapOf(new Pair("ldpi", 120), new Pair("mdpi", 160), new Pair("tvdpi", 213), new Pair("hdpi", 240), new Pair("xhdpi", 320), new Pair("xxhdpi", 480), new Pair("xxxhdpi", 640));
    public static final Set ANY = SetsKt.setOf((Object[]) new String[]{"nodpi", "anydpi"});
    public static final Regex LANG = new Regex("^[a-z]{2,3}([_-]r?[A-Za-z]{2,4})?$");
    public static final Regex OBB = new Regex("^Android/obb/([A-Za-z]\\w*(?:\\.\\w+)+)/[\\w.-]+\\.obb$");

    /* loaded from: classes.dex */
    public final class Entry {
        public final String name;
        public final long size;

        public Entry(long j, String name) {
            Intrinsics.checkNotNullParameter(name, "name");
            this.name = name;
            this.size = j;
        }
    }

    public static String pattern(String name) {
        Intrinsics.checkNotNullParameter(name, "name");
        return new Regex("[\\\\*?\\[]").replace(name, new Bloat$$ExternalSyntheticLambda1(4));
    }

    public static String qualifier(String entry) {
        Intrinsics.checkNotNullParameter(entry, "entry");
        String removeSuffix = StringsKt.removeSuffix(StringsKt.removeSuffix(StringsKt.substringAfterLast(entry, '/', entry), ".apk"), ".APK");
        MatcherMatchResult access$findNext = MathKt.access$findNext(Census$$ExternalSyntheticOutline0.m6m("^(?:split_)?config\\.(.+)$", "compile(...)", removeSuffix, "matcher(...)"), 0, removeSuffix);
        if (access$findNext != null) {
            return StringsKt__StringsJVMKt.replace$default((String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1), '-', '_');
        }
        if (StringsKt.contains$default(removeSuffix, '-')) {
            return StringsKt__StringsJVMKt.replace$default(StringsKt.substringAfterLast(removeSuffix, '-', removeSuffix), '-', '_');
        }
        return null;
    }

    public static boolean skipped(String str) {
        if (!StringsKt__StringsJVMKt.startsWith(str, false, "standalones/") && !StringsKt__StringsJVMKt.startsWith(str, false, "instant/") && !StringsKt__StringsJVMKt.startsWith(str, false, "archive/")) {
            return false;
        }
        return true;
    }
}
