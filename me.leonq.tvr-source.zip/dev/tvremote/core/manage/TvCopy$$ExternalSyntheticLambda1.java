package dev.tvremote.core.manage;

import dev.tvremote.core.adb.Adb;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;

/* loaded from: classes.dex */
public final /* synthetic */ class TvCopy$$ExternalSyntheticLambda1 implements Function0 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Adb.Stream f$0;

    public /* synthetic */ TvCopy$$ExternalSyntheticLambda1(Adb.Stream stream, int i) {
        this.$r8$classId = i;
        this.f$0 = stream;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        switch (this.$r8$classId) {
            case 0:
                this.f$0.close();
                return Unit.INSTANCE;
            default:
                this.f$0.close();
                return Unit.INSTANCE;
        }
    }
}
