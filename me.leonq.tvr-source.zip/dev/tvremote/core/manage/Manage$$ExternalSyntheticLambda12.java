package dev.tvremote.core.manage;

import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final /* synthetic */ class Manage$$ExternalSyntheticLambda12 implements Function2 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Manage f$0;

    public /* synthetic */ Manage$$ExternalSyntheticLambda12(Manage manage, int i) {
        this.$r8$classId = i;
        this.f$0 = manage;
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(Object obj, Object obj2) {
        switch (this.$r8$classId) {
            case 0:
                String t = (String) obj;
                Function1 w = (Function1) obj2;
                Intrinsics.checkNotNullParameter(t, "t");
                Intrinsics.checkNotNullParameter(w, "w");
                return this.f$0.jobs.job(t, null, null, t, w);
            default:
                String t2 = (String) obj;
                Function1 w2 = (Function1) obj2;
                Intrinsics.checkNotNullParameter(t2, "t");
                Intrinsics.checkNotNullParameter(w2, "w");
                return this.f$0.jobs.job(t2, null, null, t2, w2);
        }
    }
}
