package dev.tvremote.core.manage;

import dev.tvremote.core.Fleet;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Pattern;
import kotlin.collections.CollectionsKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;

/* loaded from: classes.dex */
public abstract class TvPaths {
    public static final AtomicLong tmpN = new AtomicLong(System.currentTimeMillis() % 1000000000);
    public static final Regex DIGITS = new Regex("\\d+");

    public static String mime$shared_release(String str) {
        String substring = str.substring(StringsKt.lastIndexOf$default(str, '.', 6) + 1);
        Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
        Locale ROOT = Locale.ROOT;
        Intrinsics.checkNotNullExpressionValue(ROOT, "ROOT");
        String lowerCase = substring.toLowerCase(ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        switch (lowerCase.hashCode()) {
            case 96796:
                if (!lowerCase.equals("apk")) {
                    return "*/*";
                }
                return "application/vnd.android.package-archive";
            case 96980:
                if (lowerCase.equals("avi")) {
                    return "video/x-msvideo";
                }
                return "*/*";
            case 102340:
                if (lowerCase.equals("gif")) {
                    return "image/gif";
                }
                return "*/*";
            case 105441:
                if (lowerCase.equals("jpg")) {
                    return "image/jpeg";
                }
                return "*/*";
            case 106458:
                if (lowerCase.equals("m4a")) {
                    return "audio/mp4";
                }
                return "*/*";
            case 106479:
                if (lowerCase.equals("m4v")) {
                    return "video/mp4";
                }
                return "*/*";
            case 108184:
                if (lowerCase.equals("mkv")) {
                    return "video/x-matroska";
                }
                return "*/*";
            case 108272:
                if (lowerCase.equals("mp3")) {
                    return "audio/mpeg";
                }
                return "*/*";
            case 108273:
                if (lowerCase.equals("mp4")) {
                    return "video/mp4";
                }
                return "*/*";
            case 108308:
                if (lowerCase.equals("mov")) {
                    return "video/quicktime";
                }
                return "*/*";
            case 109967:
                if (lowerCase.equals("ogg")) {
                    return "audio/ogg";
                }
                return "*/*";
            case 110834:
                if (lowerCase.equals("pdf")) {
                    return "application/pdf";
                }
                return "*/*";
            case 111145:
                if (lowerCase.equals("png")) {
                    return "image/png";
                }
                return "*/*";
            case 115312:
                if (lowerCase.equals("txt")) {
                    return "text/plain";
                }
                return "*/*";
            case 117484:
                if (lowerCase.equals("wav")) {
                    return "audio/wav";
                }
                return "*/*";
            case 3145576:
                if (lowerCase.equals("flac")) {
                    return "audio/flac";
                }
                return "*/*";
            case 3268712:
                if (lowerCase.equals("jpeg")) {
                    return "image/jpeg";
                }
                return "*/*";
            case 3645337:
                if (lowerCase.equals("webm")) {
                    return "video/webm";
                }
                return "*/*";
            case 3645340:
                if (lowerCase.equals("webp")) {
                    return "image/webp";
                }
                return "*/*";
            default:
                return "*/*";
        }
    }

    public static Long parseDfFree$shared_release(String out) {
        Object obj;
        String obj2;
        int i;
        Intrinsics.checkNotNullParameter(out, "out");
        List lines = StringsKt.lines(StringsKt.trim(out).toString());
        ListIterator listIterator = lines.listIterator(lines.size());
        while (true) {
            if (listIterator.hasPrevious()) {
                obj = listIterator.previous();
                if (!StringsKt.isBlank((String) obj)) {
                    break;
                }
            } else {
                obj = null;
                break;
            }
        }
        String str = (String) obj;
        if (str != null && (obj2 = StringsKt.trim(str).toString()) != null) {
            List split = new Regex("\\s+").split(obj2, 0);
            int size = split.size();
            Regex regex = DIGITS;
            if (size >= 6 && regex.matches((CharSequence) split.get(1))) {
                i = 3;
            } else if (split.size() == 5 && regex.matches((CharSequence) split.get(0))) {
                i = 2;
            }
            Object obj3 = split.get(i);
            if (!regex.matches((String) obj3)) {
                obj3 = null;
            }
            String str2 = (String) obj3;
            if (str2 != null) {
                return Long.valueOf(Long.parseLong(str2) * 1024);
            }
        }
        return null;
    }

    public static boolean root$shared_release(String str) {
        List split$default = StringsKt.split$default(str, new String[]{"/"}, 0, 6);
        ArrayList arrayList = new ArrayList();
        for (Object obj : split$default) {
            if (((String) obj).length() > 0) {
                arrayList.add(obj);
            }
        }
        if (!str.equals("/sdcard") && (!Intrinsics.areEqual(CollectionsKt.firstOrNull(arrayList), "storage") || (arrayList.size() > 2 && (arrayList.size() != 3 || !SetsKt.setOf((Object[]) new String[]{"emulated", "self"}).contains(arrayList.get(1)))))) {
            return false;
        }
        return true;
    }

    public static String safeName$shared_release(String str) {
        if (str == null) {
            str = "";
        }
        Pattern compile = Pattern.compile(".*[/\\\\]");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        String replaceAll = compile.matcher(str).replaceAll("");
        Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
        Pattern compile2 = Pattern.compile("[^\\p{L}\\p{N}_.\\- ()\\[\\]]");
        Intrinsics.checkNotNullExpressionValue(compile2, "compile(...)");
        String replaceAll2 = compile2.matcher(replaceAll).replaceAll("_");
        Intrinsics.checkNotNullExpressionValue(replaceAll2, "replaceAll(...)");
        Pattern compile3 = Pattern.compile("^[. ]+|[. ]+$");
        Intrinsics.checkNotNullExpressionValue(compile3, "compile(...)");
        String replaceAll3 = compile3.matcher(replaceAll2).replaceAll("");
        Intrinsics.checkNotNullExpressionValue(replaceAll3, "replaceAll(...)");
        if (replaceAll3.length() == 0) {
            return "file";
        }
        if (replaceAll3.length() > 120) {
            String substring = replaceAll3.substring(0, 120);
            Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
            return substring;
        }
        return replaceAll3;
    }

    public static String safePath$shared_release(String str) {
        StringBuilder sb = new StringBuilder();
        if (str == null || str.length() == 0) {
            str = "/sdcard/Download";
        }
        for (String str2 : Fleet.jsplit(str, 0, "/")) {
            if (str2.length() != 0 && !str2.equals(".")) {
                if (!str2.equals("..")) {
                    sb.append('/');
                    sb.append(str2);
                } else {
                    throw new IllegalArgumentException("bad path");
                }
            }
        }
        String sb2 = sb.toString();
        Intrinsics.checkNotNullExpressionValue(sb2, "toString(...)");
        if (!sb2.equals("/sdcard") && !sb2.equals("/storage") && !StringsKt__StringsJVMKt.startsWith(sb2, false, "/sdcard/") && !StringsKt__StringsJVMKt.startsWith(sb2, false, "/storage/")) {
            throw new IllegalArgumentException("path must be under /sdcard or /storage");
        }
        return sb2;
    }

    public static String tmpApk() {
        return "/data/local/tmp/tvremote-install-" + tmpN.incrementAndGet() + ".apk";
    }
}
