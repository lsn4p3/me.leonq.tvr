package dev.tvremote.core.manage;

import dev.tvremote.core.adb.Adb;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final /* synthetic */ class Manage$$ExternalSyntheticLambda18 implements Function1 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Manage f$0;

    public /* synthetic */ Manage$$ExternalSyntheticLambda18(Manage manage, int i) {
        this.$r8$classId = i;
        this.f$0 = manage;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        Manage manage = this.f$0;
        String it = (String) obj;
        switch (this.$r8$classId) {
            case 0:
                Intrinsics.checkNotNullParameter(it, "it");
                return manage.sh(it);
            case 1:
                Intrinsics.checkNotNullParameter(it, "it");
                return manage.sh(it);
            case 2:
                Intrinsics.checkNotNullParameter(it, "it");
                Adb adb = manage.link.get();
                ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                return adb.shell(120000L, it);
            case 3:
                Intrinsics.checkNotNullParameter(it, "it");
                return manage.sh(it);
            case 4:
                Intrinsics.checkNotNullParameter(it, "it");
                return manage.sh(it);
            case 5:
                Intrinsics.checkNotNullParameter(it, "it");
                return manage.sh(it);
            case 6:
                Intrinsics.checkNotNullParameter(it, "it");
                return manage.sh(it);
            default:
                Intrinsics.checkNotNullParameter(it, "it");
                return manage.sh(it);
        }
    }
}
