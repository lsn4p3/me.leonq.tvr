package dev.tvremote.core.manage;

import android.R;
import dev.tvremote.core.adb.Pkg;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.HashMap;
import kotlin.Pair;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;
import org.conscrypt.PSKKeyManager;

/* loaded from: classes.dex */
public abstract class Apk {
    public static final Object ATTR_IDS = MapsKt__MapsKt.mapOf(new Pair(Integer.valueOf(R.attr.minSdkVersion), "minSdkVersion"), new Pair(Integer.valueOf(R.attr.versionCode), "versionCode"), new Pair(Integer.valueOf(R.attr.versionName), "versionName"));

    /* JADX WARN: Removed duplicated region for block: B:15:0x01fc  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x01ff A[Catch: RuntimeException -> 0x0063, TRY_LEAVE, TryCatch #0 {RuntimeException -> 0x0063, blocks: (B:3:0x000b, B:4:0x0026, B:6:0x002b, B:18:0x01ff, B:20:0x004e, B:22:0x0057, B:25:0x0072, B:30:0x00ad, B:32:0x00b5, B:34:0x00ba, B:36:0x00d5, B:37:0x00df, B:39:0x0102, B:42:0x011c, B:44:0x0122, B:46:0x0142, B:49:0x0134, B:51:0x013a, B:48:0x0145, B:60:0x0115, B:65:0x0153, B:67:0x015f, B:78:0x0167, B:81:0x017f, B:83:0x018d, B:85:0x01a0, B:88:0x01a9, B:90:0x01b2, B:91:0x01bb, B:93:0x01f5, B:95:0x01c9, B:97:0x01d5, B:98:0x01e7), top: B:2:0x000b }] */
    /* JADX WARN: Removed duplicated region for block: B:36:0x00d5 A[Catch: RuntimeException -> 0x0063, TryCatch #0 {RuntimeException -> 0x0063, blocks: (B:3:0x000b, B:4:0x0026, B:6:0x002b, B:18:0x01ff, B:20:0x004e, B:22:0x0057, B:25:0x0072, B:30:0x00ad, B:32:0x00b5, B:34:0x00ba, B:36:0x00d5, B:37:0x00df, B:39:0x0102, B:42:0x011c, B:44:0x0122, B:46:0x0142, B:49:0x0134, B:51:0x013a, B:48:0x0145, B:60:0x0115, B:65:0x0153, B:67:0x015f, B:78:0x0167, B:81:0x017f, B:83:0x018d, B:85:0x01a0, B:88:0x01a9, B:90:0x01b2, B:91:0x01bb, B:93:0x01f5, B:95:0x01c9, B:97:0x01d5, B:98:0x01e7), top: B:2:0x000b }] */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0102 A[Catch: RuntimeException -> 0x0063, TryCatch #0 {RuntimeException -> 0x0063, blocks: (B:3:0x000b, B:4:0x0026, B:6:0x002b, B:18:0x01ff, B:20:0x004e, B:22:0x0057, B:25:0x0072, B:30:0x00ad, B:32:0x00b5, B:34:0x00ba, B:36:0x00d5, B:37:0x00df, B:39:0x0102, B:42:0x011c, B:44:0x0122, B:46:0x0142, B:49:0x0134, B:51:0x013a, B:48:0x0145, B:60:0x0115, B:65:0x0153, B:67:0x015f, B:78:0x0167, B:81:0x017f, B:83:0x018d, B:85:0x01a0, B:88:0x01a9, B:90:0x01b2, B:91:0x01bb, B:93:0x01f5, B:95:0x01c9, B:97:0x01d5, B:98:0x01e7), top: B:2:0x000b }] */
    /* JADX WARN: Removed duplicated region for block: B:56:0x010d  */
    /* JADX WARN: Type inference failed for: r8v13, types: [java.util.Map, java.lang.Object] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static HashMap info(byte[] bArr) {
        String str;
        int[] iArr;
        int i;
        boolean z;
        int i2;
        int length;
        int i3;
        int[] iArr2;
        String str2;
        int i4;
        String str3;
        String str4 = "get(...)";
        HashMap hashMap = new HashMap();
        try {
            ByteBuffer order = ByteBuffer.wrap(bArr).order(ByteOrder.LITTLE_ENDIAN);
            ArrayList arrayList = new ArrayList();
            int[] iArr3 = new int[0];
            short s = 65535;
            int i5 = order.getShort(2) & 65535;
            while (true) {
                int i6 = i5 + 8;
                if (i6 > bArr.length) {
                    break;
                }
                int i7 = order.getShort(i5) & s;
                int i8 = order.getInt(i5 + 4);
                if (i7 != 1) {
                    if (i7 != 258) {
                        if (i7 != 384) {
                            str = str4;
                            iArr = iArr3;
                            i = i8;
                        } else {
                            int i9 = (i8 - 8) / 4;
                            int[] iArr4 = new int[i9];
                            for (int i10 = 0; i10 < i9; i10++) {
                                iArr4[i10] = order.getInt((i10 * 4) + i6);
                            }
                            str = str4;
                            iArr3 = iArr4;
                            i = i8;
                            if (i <= 0) {
                                length = i;
                            } else {
                                length = bArr.length;
                            }
                            i5 += length;
                            str4 = str;
                            s = 65535;
                        }
                    } else {
                        Object obj = arrayList.get(order.getInt(i5 + 20));
                        Intrinsics.checkNotNullExpressionValue(obj, str4);
                        String str5 = (String) obj;
                        int i11 = i5 + 16 + (order.getShort(i5 + 24) & s);
                        int i12 = order.getShort(i5 + 26) & s;
                        int i13 = order.getShort(i5 + 28) & s;
                        int i14 = 0;
                        while (i14 < i13) {
                            int i15 = (i14 * i12) + i11;
                            int i16 = i13;
                            int i17 = order.getInt(i15 + 4);
                            String str6 = null;
                            if (i17 >= 0) {
                                i3 = i14;
                                if (i17 < iArr3.length) {
                                    iArr2 = iArr3;
                                    str2 = (String) ATTR_IDS.get(Integer.valueOf(iArr3[i17]));
                                    if (str2 == null) {
                                        Object obj2 = arrayList.get(i17);
                                        Intrinsics.checkNotNullExpressionValue(obj2, str4);
                                        str2 = (String) obj2;
                                    }
                                    i4 = order.getInt(i15 + 8);
                                    int i18 = bArr[i15 + 15] & 255;
                                    String str7 = str4;
                                    int i19 = order.getInt(i15 + 16);
                                    int i20 = i11;
                                    int i21 = i8;
                                    long j = i19 & 4294967295L;
                                    if (i4 == -1) {
                                        str6 = (String) arrayList.get(i4);
                                    } else if (i18 == 16 || i18 == 17) {
                                        str6 = String.valueOf(j);
                                    }
                                    str3 = str6;
                                    if (str3 != null && ((str5.equals("manifest") && SetsKt.setOf((Object[]) new String[]{"package", "versionName", "versionCode"}).contains(str2)) || (str5.equals("uses-sdk") && str2.equals("minSdkVersion")))) {
                                        hashMap.put(str2, str3);
                                    }
                                    i14 = i3 + 1;
                                    i8 = i21;
                                    i13 = i16;
                                    str4 = str7;
                                    iArr3 = iArr2;
                                    i11 = i20;
                                }
                            } else {
                                i3 = i14;
                            }
                            iArr2 = iArr3;
                            str2 = null;
                            if (str2 == null) {
                            }
                            i4 = order.getInt(i15 + 8);
                            int i182 = bArr[i15 + 15] & 255;
                            String str72 = str4;
                            int i192 = order.getInt(i15 + 16);
                            int i202 = i11;
                            int i212 = i8;
                            long j2 = i192 & 4294967295L;
                            if (i4 == -1) {
                            }
                            str3 = str6;
                            if (str3 != null) {
                                hashMap.put(str2, str3);
                            }
                            i14 = i3 + 1;
                            i8 = i212;
                            i13 = i16;
                            str4 = str72;
                            iArr3 = iArr2;
                            i11 = i202;
                        }
                        str = str4;
                        iArr = iArr3;
                        i = i8;
                        if (!str5.equals("manifest") && !str5.equals("uses-sdk")) {
                            break;
                        }
                    }
                } else {
                    str = str4;
                    iArr = iArr3;
                    i = i8;
                    if ((order.getInt(i5 + 16) & PSKKeyManager.MAX_KEY_LENGTH_BYTES) != 0) {
                        z = true;
                    } else {
                        z = false;
                    }
                    int i22 = order.getInt(i5 + 20) + i5;
                    int i23 = order.getInt(i6);
                    for (int i24 = 0; i24 < i23; i24++) {
                        int i25 = order.getInt((i24 * 4) + (order.getShort(i5 + 2) & 65535) + i5) + i22;
                        if (z) {
                            if ((bArr[i25] & 128) != 0) {
                                i2 = 2;
                            } else {
                                i2 = 1;
                            }
                            int i26 = i25 + i2;
                            byte b = bArr[i26];
                            int i27 = b & Byte.MAX_VALUE;
                            if ((b & 128) != 0) {
                                i26++;
                                i27 = (bArr[i26] & 255) | (i27 << 8);
                            }
                            arrayList.add(new String(bArr, i26 + 1, i27, Charsets.UTF_8));
                        } else {
                            short s2 = order.getShort(i25);
                            int i28 = s2 & 65535;
                            if ((32768 & s2) != 0) {
                                i25 += 2;
                                i28 = (order.getShort(i25) & 65535) | ((s2 & Short.MAX_VALUE) << 16);
                            }
                            arrayList.add(new String(bArr, i25 + 2, i28 * 2, Charsets.UTF_16LE));
                        }
                    }
                }
                iArr3 = iArr;
                if (i <= 0) {
                }
                i5 += length;
                str4 = str;
                s = 65535;
            }
        } catch (RuntimeException unused) {
        }
        String str8 = (String) hashMap.get("package");
        if (str8 != null && !Pkg.RE.matches(str8)) {
            hashMap.remove("package");
        }
        return hashMap;
    }
}
