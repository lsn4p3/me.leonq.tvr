package dev.tvremote.core.manage;

import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.Mdns;
import dev.tvremote.core.web.Cancel;
import dev.tvremote.core.web.Cancelled;
import dev.tvremote.core.web.HttpServer;
import dev.tvremote.core.web.NoRoom;
import dev.tvremote.home.HomeQr$$ExternalSyntheticLambda0;
import dev.tvremote.phone.manage.Managing$$ExternalSyntheticLambda4;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class TvCopy extends ManagePart {
    public static final /* synthetic */ int $r8$clinit = 0;

    public final void ensureRoom(long j, String str, int i) {
        boolean z;
        Long freeOn = freeOn(str);
        if (freeOn != null) {
            long longValue = freeOn.longValue();
            AtomicLong atomicLong = TvPaths.tmpN;
            long j2 = 16777216 + (i * j);
            if (longValue >= j2) {
                return;
            }
            if (i > 1) {
                z = true;
            } else {
                z = false;
            }
            throw new NoRoom(j, longValue, j2, z);
        }
    }

    public final Long freeOn(String str) {
        try {
            AtomicLong atomicLong = TvPaths.tmpN;
            Adb adb = this.link.get();
            ConcurrentHashMap concurrentHashMap = Adb.ASKING;
            return TvPaths.parseDfFree$shared_release(adb.shell(120000L, "df -k " + Mdns.q(str) + " 2>/dev/null | tail -2"));
        } catch (IOException unused) {
            return null;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:50:0x021e A[Catch: all -> 0x0060, TRY_ENTER, TryCatch #0 {all -> 0x0060, blocks: (B:5:0x0034, B:7:0x004b, B:10:0x005c, B:14:0x0068, B:17:0x0077, B:22:0x0095, B:25:0x00a1, B:26:0x00aa, B:29:0x00e8, B:33:0x00ee, B:34:0x00f3, B:48:0x01eb, B:50:0x021e, B:52:0x0223, B:54:0x0227, B:55:0x022c, B:58:0x022d, B:63:0x0100, B:66:0x010b, B:69:0x0113, B:70:0x011a, B:81:0x015c, B:88:0x01ba, B:89:0x01c1, B:74:0x01c3, B:78:0x01cc, B:79:0x01d1, B:98:0x01d6, B:99:0x01d9), top: B:4:0x0034 }] */
    /* JADX WARN: Removed duplicated region for block: B:58:0x022d A[Catch: all -> 0x0060, TRY_LEAVE, TryCatch #0 {all -> 0x0060, blocks: (B:5:0x0034, B:7:0x004b, B:10:0x005c, B:14:0x0068, B:17:0x0077, B:22:0x0095, B:25:0x00a1, B:26:0x00aa, B:29:0x00e8, B:33:0x00ee, B:34:0x00f3, B:48:0x01eb, B:50:0x021e, B:52:0x0223, B:54:0x0227, B:55:0x022c, B:58:0x022d, B:63:0x0100, B:66:0x010b, B:69:0x0113, B:70:0x011a, B:81:0x015c, B:88:0x01ba, B:89:0x01c1, B:74:0x01c3, B:78:0x01cc, B:79:0x01d1, B:98:0x01d6, B:99:0x01d9), top: B:4:0x0034 }] */
    /* JADX WARN: Type inference failed for: r7v2, types: [java.lang.Object, kotlin.jvm.internal.Ref$LongRef] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void push(final InputStream input, final long j, String dest, final JSONObject jSONObject, int i) {
        Managing$$ExternalSyntheticLambda4 managing$$ExternalSyntheticLambda4;
        Cancel cancel;
        String str;
        String str2;
        Adb adb;
        String str3 = "/";
        Intrinsics.checkNotNullParameter(input, "input");
        Intrinsics.checkNotNullParameter(dest, "dest");
        Jobs jobs = (Jobs) this.core.t;
        Object obj = new Object();
        jobs.working.put(obj, "upload");
        Managing$$ExternalSyntheticLambda4 managing$$ExternalSyntheticLambda42 = jobs.onWork;
        if (managing$$ExternalSyntheticLambda42 != null) {
            managing$$ExternalSyntheticLambda42.invoke(jobs.working());
        }
        try {
            Adb adb2 = this.link.get();
            final Cancel cancel2 = (Cancel) getCurrent().get();
            if (j > 0) {
                String substringBeforeLast = StringsKt.substringBeforeLast(dest, '/', "/");
                if (substringBeforeLast.length() != 0) {
                    str3 = substringBeforeLast;
                }
                ensureRoom(j, str3, i);
            }
            try {
                final ?? obj2 = new Object();
                try {
                    Function1 function1 = new Function1() { // from class: dev.tvremote.core.manage.TvCopy$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj3) {
                            long j2;
                            int min;
                            Adb.Stream s = (Adb.Stream) obj3;
                            Intrinsics.checkNotNullParameter(s, "s");
                            Cancel cancel3 = Cancel.this;
                            if (cancel3 != null) {
                                cancel3.onStop(new TvCopy$$ExternalSyntheticLambda1(s, 0));
                            }
                            byte[] bArr = new byte[65536];
                            long j3 = 0;
                            while (true) {
                                j2 = j;
                                if (j2 >= 0 && j3 >= j2) {
                                    break;
                                }
                                if (cancel3 != null) {
                                    cancel3.check();
                                }
                                if (j2 < 0) {
                                    min = 65536;
                                } else {
                                    min = (int) Math.min(65536, j2 - j3);
                                }
                                int read = input.read(bArr, 0, min);
                                if (read < 0) {
                                    break;
                                }
                                s.write(read, bArr);
                                j3 += read;
                                obj2.element = j3;
                                JSONObject jSONObject2 = jSONObject;
                                if (jSONObject2 != null && j2 > 0) {
                                    try {
                                        jSONObject2.put("pct", (int) ((90 * j3) / j2));
                                    } catch (Exception unused) {
                                    }
                                }
                            }
                            if (j2 >= 0 && j3 < j2) {
                                throw new IOException("upload cut short");
                            }
                            return Unit.INSTANCE;
                        }
                    };
                    if (j >= 0) {
                        cancel = cancel2;
                        str = dest;
                        adb = adb2;
                        try {
                            adb.put(str, j, true, null, function1);
                            String valueOf = String.valueOf(j);
                            for (int i2 = 0; i2 < 40; i2++) {
                                if (cancel != null) {
                                    cancel.check();
                                }
                                ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                                if (Intrinsics.areEqual(StringsKt.trim(adb.shell(120000L, "stat -c %s " + Mdns.q(str) + " 2>/dev/null")).toString(), valueOf)) {
                                    if (managing$$ExternalSyntheticLambda4 != null) {
                                        return;
                                    } else {
                                        return;
                                    }
                                }
                                try {
                                    Thread.sleep(150L);
                                } catch (InterruptedException unused) {
                                }
                            }
                            throw new IOException("the TV did not store the whole file (is its storage full?)");
                        } catch (Exception e) {
                            e = e;
                            str2 = ".part";
                            try {
                                Thread.sleep(200L);
                                ConcurrentHashMap concurrentHashMap2 = Adb.ASKING;
                                adb.shell(120000L, "rm -f " + Mdns.q(str + str2));
                            } catch (Exception unused2) {
                            }
                            if (cancel == null) {
                            }
                        }
                    } else {
                        cancel = cancel2;
                        str = dest;
                        adb = adb2;
                        str2 = ".part";
                        try {
                            Adb.Stream writeTo = adb.writeTo(str.concat(str2));
                            try {
                                function1.invoke(writeTo);
                                writeTo.close();
                                int i3 = 0;
                                for (int i4 = 40; i3 < i4; i4 = 40) {
                                    if (cancel != null) {
                                        cancel.check();
                                    }
                                    ConcurrentHashMap concurrentHashMap3 = Adb.ASKING;
                                    if (Intrinsics.areEqual(StringsKt.trim(adb.shell(120000L, "stat -c %s " + Mdns.q(str + str2) + " 2>/dev/null")).toString(), String.valueOf(obj2.element))) {
                                        if (StringsKt__StringsJVMKt.endsWith(StringsKt.trim(adb.shell(120000L, "mv -f " + Mdns.q(str + str2) + " " + Mdns.q(str) + " && echo ok")).toString(), false, "ok")) {
                                            jobs.working.remove(obj);
                                            Managing$$ExternalSyntheticLambda4 managing$$ExternalSyntheticLambda43 = jobs.onWork;
                                            if (managing$$ExternalSyntheticLambda43 != null) {
                                                managing$$ExternalSyntheticLambda43.invoke(jobs.working());
                                                return;
                                            }
                                            return;
                                        }
                                        throw new IOException("the TV could not store the file");
                                    }
                                    try {
                                        Thread.sleep(150L);
                                        i3++;
                                    } catch (InterruptedException unused3) {
                                    }
                                }
                                throw new IOException("the TV did not store the whole file (is its storage full?)");
                            } catch (Throwable th) {
                                try {
                                    throw th;
                                } catch (Throwable th2) {
                                    MathKt.closeFinally(writeTo, th);
                                    throw th2;
                                }
                            }
                        } catch (Exception e2) {
                            e = e2;
                            Thread.sleep(200L);
                            ConcurrentHashMap concurrentHashMap22 = Adb.ASKING;
                            adb.shell(120000L, "rm -f " + Mdns.q(str + str2));
                            if (cancel == null) {
                                if (cancel.stopped) {
                                    if (!(e instanceof Cancelled)) {
                                        throw new Cancelled();
                                    }
                                    throw e;
                                }
                                throw e;
                            }
                            throw e;
                        }
                    }
                } catch (Exception e3) {
                    e = e3;
                    cancel = cancel2;
                    str = dest;
                    adb = adb2;
                }
            } catch (Exception e4) {
                e = e4;
                cancel = cancel2;
                str = dest;
                str2 = ".part";
                adb = adb2;
            }
        } finally {
            jobs.working.remove(obj);
            managing$$ExternalSyntheticLambda4 = jobs.onWork;
            if (managing$$ExternalSyntheticLambda4 != null) {
                managing$$ExternalSyntheticLambda4.invoke(jobs.working());
            }
        }
    }

    @Override // dev.tvremote.core.manage.ManagePart
    public final HttpServer.Response route(String str, boolean z, HttpServer.Request request) {
        long j;
        String safePath$shared_release;
        int i;
        if (str.equals("space")) {
            String q = request.q("path");
            Long longOrNull = StringsKt__StringNumberConversionsKt.toLongOrNull(request.q("size"));
            if (longOrNull != null) {
                j = longOrNull.longValue();
            } else {
                j = 0;
            }
            long j2 = j;
            boolean equals = request.q("apk").equals("1");
            if (equals) {
                safePath$shared_release = "/data/local/tmp";
            } else {
                safePath$shared_release = TvPaths.safePath$shared_release(q);
            }
            boolean z2 = true;
            if (equals) {
                i = 2;
            } else {
                i = 1;
            }
            Long freeOn = freeOn(safePath$shared_release);
            JSONObject jSONObject = new JSONObject();
            AtomicLong atomicLong = TvPaths.tmpN;
            long j3 = (i * j2) + 16777216;
            JSONObject put = jSONObject.put("need", j3);
            if (freeOn == null) {
                put = put.put("ok", true);
                Intrinsics.checkNotNullExpressionValue(put, "put(...)");
            } else {
                JSONObject put2 = put.put("free", freeOn.longValue());
                if (freeOn.longValue() < j3) {
                    z2 = false;
                }
                put2.put("ok", z2);
                if (!put.getBoolean("ok")) {
                    put = put.put("error", new NoRoom(j2, freeOn.longValue(), j3, equals).getMessage());
                    Intrinsics.checkNotNullExpressionValue(put, "put(...)");
                }
            }
            HttpServer.Response response = new HttpServer.Response();
            response.status = 200;
            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = HttpServer.trusted;
            response.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put);
            return response;
        }
        return null;
    }
}
