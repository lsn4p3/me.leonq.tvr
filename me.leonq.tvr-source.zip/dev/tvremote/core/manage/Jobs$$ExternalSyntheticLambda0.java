package dev.tvremote.core.manage;

import android.os.Handler;
import android.util.Log;
import dev.tvremote.core.Census$$ExternalSyntheticLambda4;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Fleet$$ExternalSyntheticLambda0;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.Adb$$ExternalSyntheticLambda5;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.ontv.Checkout;
import dev.tvremote.core.ontv.Games;
import dev.tvremote.core.ontv.RemoteLabels;
import dev.tvremote.core.ontv.Setup$$ExternalSyntheticLambda4;
import dev.tvremote.core.ontv.ThemeShare$Cancelled;
import dev.tvremote.core.ontv.ThemeShare$Fail;
import dev.tvremote.core.ontv.ThemeShare$Job;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.core.scenes.Scenes;
import dev.tvremote.core.web.Cancel;
import dev.tvremote.home.HomeConfig;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda10;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda14;
import dev.tvremote.phone.ir.IrHear;
import dev.tvremote.phone.ir.IrProfile;
import dev.tvremote.phone.ir.IrRemoteKt;
import dev.tvremote.phone.ir.IrRemoteKt$$ExternalSyntheticLambda49;
import dev.tvremote.phone.ir.IrState;
import dev.tvremote.phone.manage.Managing$$ExternalSyntheticLambda4;
import dev.tvremote.phone.media.MediaKt$$ExternalSyntheticLambda4;
import dev.tvremote.phone.media.TalkKt$$ExternalSyntheticLambda1;
import dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda3;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.tvapps.ApkCert$$ExternalSyntheticLambda0;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.EmptyMap;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$BooleanRef;
import kotlin.jvm.internal.Ref$ObjectRef;
import kotlin.text.Regex$$ExternalSyntheticLambda0;
import kotlin.text.StringsKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class Jobs$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;
    public final /* synthetic */ Object f$1;
    public final /* synthetic */ Object f$2;
    public final /* synthetic */ Object f$3;
    public final /* synthetic */ Object f$4;

    public /* synthetic */ Jobs$$ExternalSyntheticLambda0(MainActivity mainActivity, String str, HashMap hashMap, HashMap hashMap2, HashSet hashSet) {
        this.$r8$classId = 5;
        this.f$0 = mainActivity;
        this.f$2 = str;
        this.f$1 = hashMap;
        this.f$3 = hashMap2;
        this.f$4 = hashSet;
    }

    /* JADX WARN: Code restructure failed: missing block: B:110:0x03a6, code lost:
    
        if (r0 != null) goto L120;
     */
    /* JADX WARN: Code restructure failed: missing block: B:113:0x0325, code lost:
    
        r0.close();
     */
    /* JADX WARN: Code restructure failed: missing block: B:139:0x02c5, code lost:
    
        if (r0 != null) goto L94;
     */
    /* JADX WARN: Code restructure failed: missing block: B:142:0x029b, code lost:
    
        r0.close();
     */
    /* JADX WARN: Code restructure failed: missing block: B:146:0x02d5, code lost:
    
        if (r0 != null) goto L94;
     */
    /* JADX WARN: Code restructure failed: missing block: B:157:0x0323, code lost:
    
        if (r0 != null) goto L120;
     */
    /* JADX WARN: Code restructure failed: missing block: B:161:0x033d, code lost:
    
        if (r0 != null) goto L120;
     */
    /* JADX WARN: Code restructure failed: missing block: B:170:0x0374, code lost:
    
        if (r0 != null) goto L120;
     */
    /* JADX WARN: Code restructure failed: missing block: B:184:0x0299, code lost:
    
        if (r0 != null) goto L94;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:106:0x0397 A[Catch: all -> 0x0340, TRY_LEAVE, TryCatch #0 {all -> 0x0340, blocks: (B:154:0x0300, B:159:0x032e, B:162:0x0345, B:166:0x0358, B:168:0x0365, B:104:0x038a, B:106:0x0397), top: B:90:0x0228 }] */
    /* JADX WARN: Removed duplicated region for block: B:108:0x03a1  */
    /* JADX WARN: Removed duplicated region for block: B:117:0x03ad  */
    /* JADX WARN: Removed duplicated region for block: B:120:0x03b6  */
    /* JADX WARN: Removed duplicated region for block: B:138:0x02c3  */
    /* JADX WARN: Removed duplicated region for block: B:143:0x02c8  */
    /* JADX WARN: Type inference failed for: r12v8, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    /* JADX WARN: Type inference failed for: r14v0, types: [java.lang.StringBuilder] */
    /* JADX WARN: Type inference failed for: r14v1, types: [java.lang.StringBuilder] */
    /* JADX WARN: Type inference failed for: r7v10, types: [dev.tvremote.phone.ir.IrHear] */
    /* JADX WARN: Type inference failed for: r7v18, types: [dev.tvremote.phone.ir.IrHear, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r7v19 */
    /* JADX WARN: Type inference failed for: r7v20 */
    /* JADX WARN: Type inference failed for: r7v6, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r7v7 */
    /* JADX WARN: Type inference failed for: r7v8 */
    /* JADX WARN: Type inference failed for: r7v9, types: [dev.tvremote.phone.ir.IrHear] */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void run() {
        String str;
        String str2;
        AdbLink adbLink;
        AdbLink adbLink2;
        AdbLink adbLink3;
        AdbLink adbLink4;
        Adb adb;
        AdbLink adbLink5;
        AdbLink adbLink6;
        Map map;
        int i;
        String concat;
        int i2 = 5;
        int i3 = 3;
        int i4 = 6;
        int i5 = 2;
        switch (this.$r8$classId) {
            case 0:
                Jobs jobs = (Jobs) this.f$0;
                Cancel cancel = (Cancel) this.f$1;
                String str3 = (String) this.f$2;
                JSONObject jSONObject = (JSONObject) this.f$3;
                Function1 function1 = (Function1) this.f$4;
                jobs.current.set(cancel);
                try {
                    Object obj = new Object();
                    jobs.working.put(obj, str3);
                    Managing$$ExternalSyntheticLambda4 managing$$ExternalSyntheticLambda4 = jobs.onWork;
                    if (managing$$ExternalSyntheticLambda4 != null) {
                        managing$$ExternalSyntheticLambda4.invoke(jobs.working());
                    }
                    try {
                        jSONObject.put("status", "done").put("pct", 100).put("msg", (String) function1.invoke(jSONObject));
                    } finally {
                        jobs.working.remove(obj);
                        Managing$$ExternalSyntheticLambda4 managing$$ExternalSyntheticLambda42 = jobs.onWork;
                        if (managing$$ExternalSyntheticLambda42 != null) {
                            managing$$ExternalSyntheticLambda42.invoke(jobs.working());
                        }
                    }
                } catch (Throwable th) {
                    try {
                        if (cancel.stopped) {
                            str = "cancelled";
                        } else {
                            str = "error";
                        }
                        JSONObject put = jSONObject.put("status", str);
                        if (cancel.stopped) {
                            str2 = "stopped";
                        } else {
                            String message = th.getMessage();
                            if (message == null) {
                                str2 = th.getClass().getSimpleName();
                            } else {
                                str2 = message;
                            }
                        }
                        put.put("msg", str2);
                    } catch (Exception unused) {
                    } catch (Throwable th2) {
                        jobs.current.remove();
                        jobs.stops.remove(jSONObject.getString("id"));
                        throw th2;
                    }
                }
                jobs.current.remove();
                jobs.stops.remove(jSONObject.getString("id"));
                return;
            case 1:
                ThemeShare$Job themeShare$Job = (ThemeShare$Job) this.f$0;
                Adb adb2 = (Adb) this.f$1;
                String str4 = (String) this.f$2;
                String str5 = (String) this.f$3;
                String str6 = (String) this.f$4;
                String str7 = "tv";
                String str8 = "vi";
                String str9 = "cancelled";
                try {
                    String themeName = HomeConfig.themeName(str5);
                    if (!str6.equals("vi")) {
                        str8 = "en";
                    }
                    Games.run(themeShare$Job, adb2, str4, themeName, str8);
                    if (themeShare$Job.state.equals("run")) {
                        themeShare$Job.state = "done";
                        return;
                    }
                    return;
                } catch (ThemeShare$Cancelled unused2) {
                    themeShare$Job.state = "cancelled";
                    return;
                } catch (ThemeShare$Fail e) {
                    String str10 = e.code;
                    Intrinsics.checkNotNullParameter(str10, "<set-?>");
                    themeShare$Job.error = str10;
                    themeShare$Job.state = "error";
                    return;
                } catch (IOException unused3) {
                    if (themeShare$Job.cancel) {
                        str7 = "cancelled";
                    }
                    themeShare$Job.error = str7;
                    if (!themeShare$Job.cancel) {
                        str9 = "error";
                    }
                    themeShare$Job.state = str9;
                    return;
                } catch (Exception unused4) {
                    themeShare$Job.error = "tv";
                    themeShare$Job.state = "error";
                    return;
                }
            case 2:
                ?? r7 = (String) this.f$2;
                MainActivity mainActivity = (MainActivity) this.f$0;
                MainActivity$$ExternalSyntheticLambda10 mainActivity$$ExternalSyntheticLambda10 = (MainActivity$$ExternalSyntheticLambda10) this.f$1;
                ArrayList arrayList = (ArrayList) this.f$3;
                String str11 = (String) this.f$4;
                try {
                    try {
                        List asList = ArraysKt.asList(new String[]{r7, mainActivity.pref$android_release("ts:" + r7), mainActivity.pref$android_release("lan:" + r7)});
                        ArrayList arrayList2 = new ArrayList();
                        for (Object obj2 : asList) {
                            try {
                                try {
                                    if (((String) obj2).length() > 0) {
                                        arrayList2.add(obj2);
                                    }
                                } catch (Exception e2) {
                                    e = e2;
                                    r7 = 0;
                                    adbLink2 = null;
                                    Log.w("TvrIr", "auto find", e);
                                    Object obj3 = IrState.catalog;
                                    if (!IrState.stop) {
                                        mainActivity$$ExternalSyntheticLambda10.invoke(new MediaKt$$ExternalSyntheticLambda4(mainActivity, str11, i2));
                                    }
                                    if (r7 != 0) {
                                        r7.close();
                                    }
                                    adbLink4 = IrState.link;
                                    break;
                                }
                            } catch (Throwable th3) {
                                th = th3;
                                r7 = 0;
                                adbLink = null;
                                if (r7 != 0) {
                                    r7.close();
                                }
                                Object obj4 = IrState.catalog;
                                adbLink3 = IrState.link;
                                if (adbLink3 != null) {
                                    adbLink3.close();
                                }
                                IrState.link = adbLink;
                                throw th;
                            }
                        }
                        adb = null;
                    } catch (Throwable th4) {
                        th = th4;
                    }
                } catch (Exception e3) {
                    e = e3;
                    adbLink2 = null;
                    r7 = 0;
                } catch (Throwable th5) {
                    th = th5;
                    adbLink = null;
                    r7 = 0;
                }
                for (String str12 : CollectionsKt.distinct(arrayList2)) {
                    Object obj5 = IrState.catalog;
                    if (IrState.stop) {
                        adbLink5 = IrState.link;
                        break;
                    } else {
                        File filesDir = mainActivity.getFilesDir();
                        Intrinsics.checkNotNullExpressionValue(filesDir, "getFilesDir(...)");
                        adbLink6 = new AdbLink(filesDir, str12);
                        IrState.link = adbLink6;
                        try {
                            adb = adbLink6.get();
                        } catch (Exception unused5) {
                            adb = null;
                        }
                        if (adb != null) {
                            Object obj6 = IrState.catalog;
                            if (!IrState.stop) {
                                adbLink5 = IrState.link;
                                break;
                            } else if (adb == null) {
                                mainActivity$$ExternalSyntheticLambda10.invoke(new MediaKt$$ExternalSyntheticLambda4(mainActivity, str11, 4));
                                adbLink5 = IrState.link;
                                break;
                            } else {
                                r7 = new IrHear(adb);
                                try {
                                    Thread.sleep(600L);
                                    ?? obj7 = new Object();
                                    obj7.element = "";
                                    adbLink2 = null;
                                    try {
                                        Pair pair = (Pair) Fleet.irScan$default(arrayList, new ApkCert$$ExternalSyntheticLambda0(i5), new IrRemoteKt$$ExternalSyntheticLambda49((Ref$ObjectRef) obj7, mainActivity), new Regex$$ExternalSyntheticLambda0(5, r7, obj7), new Census$$ExternalSyntheticLambda4(15), new Adb$$ExternalSyntheticLambda5(mainActivity$$ExternalSyntheticLambda10, mainActivity, arrayList, i3));
                                        if (IrState.stop) {
                                            r7.close();
                                            adbLink4 = IrState.link;
                                            break;
                                        } else if (pair == null) {
                                            mainActivity$$ExternalSyntheticLambda10.invoke(new TalkKt$$ExternalSyntheticLambda1(mainActivity, 10));
                                            r7.close();
                                            adbLink4 = IrState.link;
                                            break;
                                        } else {
                                            String str13 = (String) ((IrProfile) pair.first).keys.get("VOL_DOWN");
                                            if (str13 != null) {
                                                for (int i6 = 0; i6 < 2; i6++) {
                                                    Thread.sleep(250L);
                                                    IrRemoteKt.irSend(mainActivity, str13, false);
                                                }
                                            }
                                            mainActivity$$ExternalSyntheticLambda10.invoke(new Regex$$ExternalSyntheticLambda0(6, mainActivity, pair));
                                            r7.close();
                                            Object obj8 = IrState.catalog;
                                            adbLink4 = IrState.link;
                                            break;
                                        }
                                    } catch (Exception e4) {
                                        e = e4;
                                        Log.w("TvrIr", "auto find", e);
                                        Object obj32 = IrState.catalog;
                                        if (!IrState.stop) {
                                        }
                                        if (r7 != 0) {
                                        }
                                        adbLink4 = IrState.link;
                                    }
                                } catch (Exception e5) {
                                    e = e5;
                                    adbLink2 = null;
                                } catch (Throwable th6) {
                                    th = th6;
                                    adbLink = null;
                                    if (r7 != 0) {
                                    }
                                    Object obj42 = IrState.catalog;
                                    adbLink3 = IrState.link;
                                    if (adbLink3 != null) {
                                    }
                                    IrState.link = adbLink;
                                    throw th;
                                }
                                IrState.link = adbLink2;
                                return;
                            }
                            IrState.link = null;
                            return;
                        }
                    }
                }
                Object obj62 = IrState.catalog;
                if (!IrState.stop) {
                }
                IrState.link = null;
                return;
            case 3:
                Popup popup = (Popup) this.f$0;
                MainActivity mainActivity2 = (MainActivity) this.f$3;
                Cancel cancel2 = (Cancel) this.f$1;
                String str14 = (String) this.f$2;
                Ref$ObjectRef ref$ObjectRef = (Ref$ObjectRef) this.f$4;
                try {
                    popup.dismiss();
                } catch (Exception unused6) {
                }
                if (!mainActivity2.isFinishing()) {
                    if (cancel2.stopped) {
                        Fleet.say(mainActivity2, Fleet.T("media.stopped_the_half_sent", new Pair[0]), false);
                        return;
                    } else if (str14 == null) {
                        Fleet.say(mainActivity2, Fleet.T("media.playing_on_the_tv", new Pair("name", ref$ObjectRef.element)), false);
                        return;
                    } else {
                        Fleet.say(mainActivity2, Fleet.T("media.could_not_play_it", new Pair("error", str14)), true);
                        return;
                    }
                }
                return;
            case 4:
                if (!((Ref$BooleanRef) this.f$0).element) {
                    Popup popup2 = (Popup) this.f$1;
                    if (popup2.isShowing()) {
                        MainActivity mainActivity3 = (MainActivity) this.f$2;
                        if (!mainActivity3.isFinishing()) {
                            Remote remote = mainActivity3.basic;
                            Remote remote2 = (Remote) this.f$3;
                            if (remote == remote2 && StringsKt.contains(remote2.getApp(), "installer", false)) {
                                Handler handler = mainActivity3.ui;
                                Object obj9 = ((Ref$ObjectRef) this.f$4).element;
                                if (obj9 != null) {
                                    handler.postDelayed((Runnable) obj9, 30000L);
                                    return;
                                } else {
                                    Intrinsics.throwUninitializedPropertyAccessException("later");
                                    throw null;
                                }
                            }
                            popup2.dismiss();
                            Popup.Builder builder = new Popup.Builder(mainActivity3);
                            builder.title = Fleet.T("adb_help.not_installed_yet", new Pair[0]);
                            builder.message = Fleet.T("adb_help.many_tvs_do_not", new Pair[0]);
                            builder.setPositiveButton(Fleet.T("adb_help.install_through_downloader", new Pair[0]), new MainActivity$$ExternalSyntheticLambda14(mainActivity3, i5));
                            builder.setNeutralButton(Fleet.T("adb_help.step_by_step", new Pair[0]), new MainActivity$$ExternalSyntheticLambda14(mainActivity3, i3));
                            builder.setNegativeButton(Fleet.T("common.close", new Pair[0]), null);
                            builder.show();
                            return;
                        }
                        return;
                    }
                    return;
                }
                return;
            case 5:
                MainActivity mainActivity4 = (MainActivity) this.f$0;
                String input = (String) this.f$2;
                HashMap hashMap = (HashMap) this.f$1;
                HashMap hashMap2 = (HashMap) this.f$3;
                HashSet hashSet = (HashSet) this.f$4;
                File filesDir2 = mainActivity4.getFilesDir();
                Intrinsics.checkNotNullExpressionValue(filesDir2, "getFilesDir(...)");
                String str15 = (String) mainActivity4.route.get(input);
                if (str15 == null) {
                    str15 = input;
                }
                adbLink6 = new AdbLink(filesDir2, str15);
                try {
                    try {
                        Adb adb3 = adbLink6.get();
                        List<String> distinct = CollectionsKt.distinct(CollectionsKt.plus(Fleet.info(adb3).apps, (Iterable) Checkout.here(new Fleet$$ExternalSyntheticLambda0(adb3, 18))));
                        AdbHelpKt$$ExternalSyntheticLambda3 adbHelpKt$$ExternalSyntheticLambda3 = new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity4, 14);
                        File cacheDir = mainActivity4.getCacheDir();
                        Pattern compile = Pattern.compile("[^\\w.-]");
                        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                        Intrinsics.checkNotNullParameter(input, "input");
                        String replaceAll = compile.matcher(input).replaceAll("_");
                        Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
                        try {
                            map = new RemoteLabels(adbLink6, adbHelpKt$$ExternalSyntheticLambda3, new File(cacheDir, "meta/".concat(replaceAll))).names();
                        } catch (Exception unused7) {
                            map = EmptyMap.INSTANCE;
                        }
                        synchronized (hashMap) {
                            try {
                                for (String str16 : distinct) {
                                    Integer num = (Integer) hashMap.get(str16);
                                    if (num != null) {
                                        i = num.intValue();
                                    } else {
                                        i = 0;
                                    }
                                    hashMap.put(str16, Integer.valueOf(i + 1));
                                }
                                hashMap2.putAll(map);
                                hashSet.add(input);
                            } finally {
                            }
                        }
                    } catch (Exception unused8) {
                    }
                    return;
                } finally {
                    adbLink6.close();
                }
            default:
                AdbLink adbLink7 = (AdbLink) this.f$1;
                Ref$BooleanRef ref$BooleanRef = (Ref$BooleanRef) this.f$2;
                Function2 function2 = (Function2) this.f$3;
                try {
                    adbLink7.get();
                    ref$BooleanRef.element = true;
                    concat = (String) function2.invoke(new Scenes.Shell(new Setup$$ExternalSyntheticLambda4(adbLink7, i4)), Boolean.TRUE);
                } catch (Exception e6) {
                    String message2 = e6.getMessage();
                    if (message2 == null) {
                        message2 = "";
                    }
                    concat = "adb:".concat(message2);
                }
                ((Ref$ObjectRef) this.f$0).element = concat;
                ((Ref$BooleanRef) this.f$4).element = true;
                return;
        }
    }

    public /* synthetic */ Jobs$$ExternalSyntheticLambda0(Popup popup, MainActivity mainActivity, Cancel cancel, String str, Ref$ObjectRef ref$ObjectRef) {
        this.$r8$classId = 3;
        this.f$0 = popup;
        this.f$3 = mainActivity;
        this.f$1 = cancel;
        this.f$2 = str;
        this.f$4 = ref$ObjectRef;
    }

    public /* synthetic */ Jobs$$ExternalSyntheticLambda0(Object obj, Object obj2, Object obj3, Object obj4, Object obj5, int i) {
        this.$r8$classId = i;
        this.f$0 = obj;
        this.f$1 = obj2;
        this.f$2 = obj3;
        this.f$3 = obj4;
        this.f$4 = obj5;
    }

    public /* synthetic */ Jobs$$ExternalSyntheticLambda0(String str, MainActivity mainActivity, MainActivity$$ExternalSyntheticLambda10 mainActivity$$ExternalSyntheticLambda10, ArrayList arrayList, String str2) {
        this.$r8$classId = 2;
        this.f$2 = str;
        this.f$0 = mainActivity;
        this.f$1 = mainActivity$$ExternalSyntheticLambda10;
        this.f$3 = arrayList;
        this.f$4 = str2;
    }
}
