package dev.tvremote.core.manage;

import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.ontv.AdbAccess;
import dev.tvremote.core.web.HttpServer;
import dev.tvremote.home.HomeQr$$ExternalSyntheticLambda0;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.ranges.IntRange;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class AdbApi extends ManagePart {
    /* JADX WARN: Code restructure failed: missing block: B:130:0x02de, code lost:
    
        if (r4.matcher(r3).find() != false) goto L116;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:91:0x013d  */
    /* JADX WARN: Removed duplicated region for block: B:94:0x0140 A[SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v15, types: [org.json.JSONArray] */
    /* JADX WARN: Type inference failed for: r2v15, types: [org.json.JSONArray] */
    /* JADX WARN: Type inference failed for: r2v9, types: [java.lang.Object] */
    @Override // dev.tvremote.core.manage.ManagePart
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final HttpServer.Response route(String str, boolean z, HttpServer.Request request) {
        Integer intOrNull;
        ArrayList keys;
        ArrayList<AdbAccess.Key> arrayList;
        ArrayList<AdbAccess.Client> arrayList2;
        int i;
        boolean z2;
        Object obj;
        Object obj2;
        boolean z3;
        String obj3;
        Integer intOrNull2;
        AdbAccess.Client client;
        boolean equals = str.equals("adb/access");
        AdbLink adbLink = this.link;
        if (equals && !z) {
            IntRange intRange = AdbAccess.CLEAR_KEYS;
            Adb adb = adbLink.get();
            String out = adb.shell(20000L, AdbAccess.READ);
            String ours = adb.fingerprint();
            Intrinsics.checkNotNullParameter(out, "out");
            Intrinsics.checkNotNullParameter(ours, "ours");
            List split$default = StringsKt.split$default(out, new String[]{"=====TVR====="}, 0, 6);
            String str2 = (String) CollectionsKt.getOrNull(0, split$default);
            if (str2 != null) {
                arrayList = AdbAccess.keys(str2);
            } else {
                arrayList = null;
            }
            String str3 = (String) CollectionsKt.getOrNull(1, split$default);
            if (str3 == null) {
                str3 = "";
            }
            List lines = StringsKt.lines(str3);
            ArrayList arrayList3 = new ArrayList();
            Iterator it = lines.iterator();
            while (it.hasNext()) {
                Integer intOrNull3 = StringsKt__StringNumberConversionsKt.toIntOrNull(StringsKt.trim((String) it.next()).toString());
                if (intOrNull3 == null || intOrNull3.intValue() <= 0) {
                    intOrNull3 = null;
                }
                if (intOrNull3 != null) {
                    arrayList3.add(intOrNull3);
                }
            }
            String str4 = (String) CollectionsKt.getOrNull(2, split$default);
            if (str4 != null) {
                LinkedHashSet plus = SetsKt.plus(MathKt.setOf(5555), arrayList3);
                if (!StringsKt.contains(str4, "local_address", false)) {
                    arrayList2 = null;
                } else {
                    List lines2 = StringsKt.lines(str4);
                    ArrayList arrayList4 = new ArrayList();
                    Iterator it2 = lines2.iterator();
                    while (it2.hasNext()) {
                        List split = new Regex("\\s+").split(StringsKt.trim((String) it2.next()).toString(), 0);
                        if (split.size() >= 4 && StringsKt__StringsJVMKt.endsWith((String) split.get(0), false, ":") && Intrinsics.areEqual(split.get(3), "01")) {
                            IntRange intRange2 = AdbAccess.CLEAR_KEYS;
                            Pair endpoint = AdbAccess.endpoint((String) split.get(1));
                            if (endpoint == null) {
                                client = null;
                            } else {
                                Pair endpoint2 = AdbAccess.endpoint((String) split.get(2));
                                if (endpoint2 != null && plus.contains(endpoint.second)) {
                                    client = new AdbAccess.Client((String) endpoint2.first, ((Number) endpoint2.second).intValue());
                                }
                            }
                            if (client == null) {
                                arrayList4.add(client);
                            }
                        }
                        client = null;
                        if (client == null) {
                        }
                    }
                    HashSet hashSet = new HashSet();
                    ArrayList arrayList5 = new ArrayList();
                    Iterator it3 = arrayList4.iterator();
                    while (it3.hasNext()) {
                        Object next = it3.next();
                        AdbAccess.Client client2 = (AdbAccess.Client) next;
                        if (hashSet.add(client2.address + ":" + client2.port)) {
                            arrayList5.add(next);
                        }
                    }
                    arrayList2 = arrayList5;
                }
            } else {
                arrayList2 = null;
            }
            String str5 = (String) CollectionsKt.getOrNull(3, split$default);
            if (str5 != null && (obj3 = StringsKt.trim(str5).toString()) != null && (intOrNull2 = StringsKt__StringNumberConversionsKt.toIntOrNull(obj3)) != null) {
                i = intOrNull2.intValue();
            } else {
                i = 0;
            }
            JSONObject put = new JSONObject().put("ours", ours).put("sdk", i);
            IntRange intRange3 = AdbAccess.CLEAR_KEYS;
            int i2 = intRange3.first;
            if (i <= intRange3.last && i2 <= i) {
                z2 = true;
            } else {
                z2 = false;
            }
            JSONObject put2 = put.put("canRevoke", z2);
            if (arrayList != null) {
                obj = new JSONArray();
                for (AdbAccess.Key key : arrayList) {
                    JSONObject put3 = new JSONObject().put("fp", key.fingerprint);
                    Object obj4 = key.name;
                    if (obj4 == null) {
                        obj4 = JSONObject.NULL;
                    }
                    JSONObject put4 = put3.put("name", obj4);
                    Object obj5 = key.lastSeen;
                    if (obj5 == null) {
                        obj5 = JSONObject.NULL;
                    }
                    obj.put(put4.put("seen", obj5).put("ours", key.fingerprint.equals(ours)));
                }
            } else {
                obj = JSONObject.NULL;
            }
            put2.put("keys", obj);
            if (arrayList2 != null) {
                obj2 = new JSONArray();
                for (AdbAccess.Client client3 : arrayList2) {
                    JSONObject put5 = new JSONObject().put("address", client3.address).put("port", client3.port);
                    String str6 = client3.address;
                    if (!Intrinsics.areEqual(str6, "127.0.0.1") && !Intrinsics.areEqual(str6, "::1")) {
                        z3 = false;
                    } else {
                        z3 = true;
                    }
                    obj2.put(put5.put("loopback", z3));
                }
            } else {
                obj2 = JSONObject.NULL;
            }
            put2.put("clients", obj2);
            HttpServer.Response response = new HttpServer.Response();
            response.status = 200;
            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = HttpServer.trusted;
            response.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put2);
            return response;
        }
        String str7 = "failed";
        if (str.equals("adb/revoke") && z) {
            JSONObject jSONObject = new JSONObject();
            IntRange intRange4 = AdbAccess.CLEAR_KEYS;
            Adb adb2 = adbLink.get();
            Integer intOrNull4 = StringsKt__StringNumberConversionsKt.toIntOrNull(StringsKt.trim(adb2.shell(15000L, "getprop ro.build.version.sdk")).toString());
            if (intOrNull4 != null) {
                IntRange intRange5 = AdbAccess.CLEAR_KEYS;
                int intValue = intOrNull4.intValue();
                if (intRange5.first <= intValue && intValue <= intRange5.last) {
                    try {
                        String out2 = adb2.shell(15000L, "service call adb 3 2>&1");
                        Intrinsics.checkNotNullParameter(out2, "out");
                        if (!StringsKt.isBlank(out2)) {
                            Pattern compile = Pattern.compile("Parcel\\(\\s*(?:0x0+:\\s*)?0{8}");
                            Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                        }
                    } catch (IOException unused) {
                    }
                    str7 = "revoked";
                    JSONObject put6 = jSONObject.put("result", str7);
                    Intrinsics.checkNotNullExpressionValue(put6, "put(...)");
                    HttpServer.Response response2 = new HttpServer.Response();
                    response2.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda02 = HttpServer.trusted;
                    response2.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put6);
                    return response2;
                }
            }
            if (!StringsKt.contains(adb2.shell(15000L, "am start -a android.settings.APPLICATION_DEVELOPMENT_SETTINGS 2>&1"), "Error", false)) {
                str7 = "settings";
            }
            JSONObject put62 = jSONObject.put("result", str7);
            Intrinsics.checkNotNullExpressionValue(put62, "put(...)");
            HttpServer.Response response22 = new HttpServer.Response();
            response22.status = 200;
            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda022 = HttpServer.trusted;
            response22.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put62);
            return response22;
        }
        if (!str.equals("adb/revoke-one") || !z) {
            return null;
        }
        JSONObject jSONObject2 = new JSONObject();
        IntRange intRange6 = AdbAccess.CLEAR_KEYS;
        Adb adb3 = adbLink.get();
        String optString = request.json(65536).optString("fp");
        Intrinsics.checkNotNullExpressionValue(optString, "optString(...)");
        if (AdbAccess.FP.matches(optString) && (intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull(StringsKt.trim(adb3.shell(15000L, "getprop ro.build.version.sdk")).toString())) != null) {
            IntRange intRange7 = AdbAccess.CLEAR_KEYS;
            int intValue2 = intOrNull.intValue();
            if (intRange7.first <= intValue2 && intValue2 <= intRange7.last) {
                try {
                    adb3.shell(15000L, "service call adb 7 s16 '" + optString + "' 2>&1");
                    keys = AdbAccess.keys(adb3.shell(15000L, "dumpsys adb 2>&1"));
                } catch (IOException unused2) {
                }
                if (keys != null) {
                    if (!keys.isEmpty()) {
                        Iterator it4 = keys.iterator();
                        while (it4.hasNext()) {
                            if (((AdbAccess.Key) it4.next()).fingerprint.equals(optString)) {
                                break;
                            }
                        }
                    }
                    str7 = "revoked";
                }
            }
        }
        JSONObject put7 = jSONObject2.put("result", str7);
        Intrinsics.checkNotNullExpressionValue(put7, "put(...)");
        HttpServer.Response response3 = new HttpServer.Response();
        response3.status = 200;
        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda03 = HttpServer.trusted;
        response3.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put7);
        return response3;
    }
}
