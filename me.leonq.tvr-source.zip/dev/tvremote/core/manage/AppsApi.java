package dev.tvremote.core.manage;

import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Words$$ExternalSyntheticLambda1;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.Mdns;
import dev.tvremote.core.adb.TvShell;
import dev.tvremote.core.ontv.Axml$$ExternalSyntheticLambda1;
import dev.tvremote.core.ontv.Bloat$$ExternalSyntheticLambda1;
import dev.tvremote.core.ontv.Games;
import dev.tvremote.core.ontv.Home;
import dev.tvremote.core.ontv.LauncherSwap;
import dev.tvremote.core.ontv.Privacy;
import dev.tvremote.core.ontv.Recents;
import dev.tvremote.core.ontv.RemoteLabels;
import dev.tvremote.core.ontv.Rescue;
import dev.tvremote.core.ontv.Setup;
import dev.tvremote.core.scenes.Phrases;
import dev.tvremote.core.scenes.Phrases$alt$$inlined$sortedByDescending$1;
import dev.tvremote.core.scenes.Scenes;
import dev.tvremote.core.scenes.Voice;
import dev.tvremote.core.web.HttpServer;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda4;
import dev.tvremote.home.HomeQr$$ExternalSyntheticLambda0;
import dev.tvremote.phone.WorkService;
import dev.tvremote.update.Ed25519;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.CollectionsKt__MutableCollectionsJVMKt;
import kotlin.collections.EmptyList;
import kotlin.collections.SetsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgressionIterator;
import kotlin.ranges.IntRange;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class AppsApi extends ManagePart {
    public final Privacy.Job privacy;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AppsApi(Ed25519.Pt core) {
        super(core);
        Intrinsics.checkNotNullParameter(core, "core");
        this.privacy = new Privacy.Job(this.link);
    }

    public static final void privacyA11yOff$lambda$49$drop(String str, Function1 function1, JSONObject jSONObject) {
        JSONArray optJSONArray = jSONObject.optJSONArray(str);
        if (optJSONArray == null) {
            return;
        }
        IntRange until = MathKt.until(0, optJSONArray.length());
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until));
        Iterator it = until.iterator();
        while (((IntProgressionIterator) it).hasNext) {
            arrayList.add(optJSONArray.get(((IntProgressionIterator) it).nextInt()));
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator it2 = arrayList.iterator();
        while (it2.hasNext()) {
            Object next = it2.next();
            if (((Boolean) function1.invoke(next)).booleanValue()) {
                arrayList2.add(next);
            }
        }
        jSONObject.put(str, new JSONArray((Collection) arrayList2));
    }

    public static final ArrayList privacyPerms$names(JSONArray jSONArray) {
        int i;
        if (jSONArray != null) {
            i = jSONArray.length();
        } else {
            i = 0;
        }
        IntRange until = MathKt.until(0, i);
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until));
        Iterator it = until.iterator();
        while (((IntProgressionIterator) it).hasNext) {
            int nextInt = ((IntProgressionIterator) it).nextInt();
            Intrinsics.checkNotNull(jSONArray);
            arrayList.add(jSONArray.getString(nextInt));
        }
        return arrayList;
    }

    public final HttpServer.Response app(String str, String str2) {
        if (ManagePart.PKG.matcher(str).matches()) {
            switch (str2.hashCode()) {
                case -1298848381:
                    if (str2.equals("enable")) {
                        String sh = sh("pm enable " + str + " 2>&1");
                        if (!StringsKt.contains(sh, "enabled", false)) {
                            String obj = StringsKt.trim(sh).toString();
                            if (obj.length() == 0) {
                                obj = "enable failed";
                            }
                            throw new IllegalArgumentException(obj);
                        }
                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = HttpServer.trusted;
                        byte[] bytes = WorkService.Companion.bytes("{\"ok\":true}");
                        HttpServer.Response response = new HttpServer.Response();
                        response.type = "application/json; charset=utf-8";
                        response.body = bytes;
                        return response;
                    }
                    break;
                case -1109843021:
                    if (str2.equals("launch")) {
                        HashMap hashMap = Scenes.KEYS;
                        Scenes.launch(str, new AppsApi$$ExternalSyntheticLambda2(this, 0));
                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda02 = HttpServer.trusted;
                        byte[] bytes2 = WorkService.Companion.bytes("{\"ok\":true}");
                        HttpServer.Response response2 = new HttpServer.Response();
                        response2.type = "application/json; charset=utf-8";
                        response2.body = bytes2;
                        return response2;
                    }
                    break;
                case -625596190:
                    if (str2.equals("uninstall")) {
                        String[] strArr = Setup.GOOGLE;
                        if (!Rescue.mustKeep(str) && !str.equals(homeNow()) && !Rescue.inUse(str, new AppsApi$app$2(1, this, AppsApi.class, "sh", "sh(Ljava/lang/String;)Ljava/lang/String;", 0))) {
                            String obj2 = StringsKt.trim(sh("pm uninstall " + str + " 2>&1")).toString();
                            if (!StringsKt.contains(obj2, "Success", false)) {
                                if (obj2.length() == 0) {
                                    obj2 = "uninstall failed";
                                }
                                throw new IllegalArgumentException(obj2);
                            }
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda03 = HttpServer.trusted;
                            byte[] bytes3 = WorkService.Companion.bytes("{\"ok\":true}");
                            HttpServer.Response response3 = new HttpServer.Response();
                            response3.type = "application/json; charset=utf-8";
                            response3.body = bytes3;
                            return response3;
                        }
                        throw new IllegalArgumentException("protected: the TV needs this app");
                    }
                    break;
                case 3540994:
                    if (str2.equals("stop")) {
                        String[] strArr2 = Setup.GOOGLE;
                        if (!Rescue.mustKeep(str)) {
                            keepCheck(str);
                            sh("am force-stop ".concat(str));
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda04 = HttpServer.trusted;
                            byte[] bytes4 = WorkService.Companion.bytes("{\"ok\":true}");
                            HttpServer.Response response4 = new HttpServer.Response();
                            response4.type = "application/json; charset=utf-8";
                            response4.body = bytes4;
                            return response4;
                        }
                        throw new IllegalArgumentException("protected: the TV needs this app");
                    }
                    break;
                case 94746189:
                    if (str2.equals("clear")) {
                        String[] strArr3 = Setup.GOOGLE;
                        if (!Rescue.mustKeep(str) && !str.equals(homeNow()) && !Rescue.inUse(str, new AppsApi$app$2(1, this, AppsApi.class, "sh", "sh(Ljava/lang/String;)Ljava/lang/String;", 2))) {
                            String sh2 = sh("pm clear " + str + " 2>&1");
                            if (!StringsKt.contains(sh2, "Success", false)) {
                                String obj3 = StringsKt.trim(sh2).toString();
                                if (obj3.length() == 0) {
                                    obj3 = "clear failed";
                                }
                                throw new IllegalArgumentException(obj3);
                            }
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda05 = HttpServer.trusted;
                            byte[] bytes5 = WorkService.Companion.bytes("{\"ok\":true}");
                            HttpServer.Response response5 = new HttpServer.Response();
                            response5.type = "application/json; charset=utf-8";
                            response5.body = bytes5;
                            return response5;
                        }
                        throw new IllegalArgumentException("protected: the TV needs this app");
                    }
                    break;
                case 1671308008:
                    if (str2.equals("disable")) {
                        String[] strArr4 = Setup.GOOGLE;
                        if (!Rescue.mustKeep(str) && !str.equals(homeNow()) && !Rescue.inUse(str, new AppsApi$app$2(1, this, AppsApi.class, "sh", "sh(Ljava/lang/String;)Ljava/lang/String;", 1))) {
                            String sh3 = sh("pm disable-user --user 0 " + str + " 2>&1");
                            if (!StringsKt.contains(sh3, "disabled", false)) {
                                String obj4 = StringsKt.trim(sh3).toString();
                                if (obj4.length() == 0) {
                                    obj4 = "disable failed";
                                }
                                throw new IllegalArgumentException(obj4);
                            }
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda06 = HttpServer.trusted;
                            byte[] bytes6 = WorkService.Companion.bytes("{\"ok\":true}");
                            HttpServer.Response response6 = new HttpServer.Response();
                            response6.type = "application/json; charset=utf-8";
                            response6.body = bytes6;
                            return response6;
                        }
                        throw new IllegalArgumentException("protected: the TV needs this app");
                    }
                    break;
            }
            throw new IllegalArgumentException("unknown action");
        }
        throw new IllegalArgumentException("bad package name");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r8v2, types: [java.util.ArrayList] */
    /* JADX WARN: Type inference failed for: r8v3, types: [java.util.Collection] */
    /* JADX WARN: Type inference failed for: r8v7, types: [kotlin.collections.EmptyList] */
    public final JSONObject apps(boolean z) {
        String str;
        String str2;
        Object obj;
        Object obj2;
        Object obj3;
        ?? arrayList;
        JSONObject jSONObject;
        boolean z2;
        RemoteLabels remoteLabels;
        boolean z3 = true;
        ArrayList arrayList2 = new ArrayList();
        if (z) {
            str = "";
        } else {
            str = " -3";
        }
        if (z) {
            str2 = "";
        } else {
            str2 = "; echo '#~#'; for c in LEANBACK_LAUNCHER LAUNCHER; do cmd package query-activities --brief -a android.intent.action.MAIN -c android.intent.category.$c 2>/dev/null; done";
        }
        List split$default = StringsKt.split$default(sh("pm list packages" + str + "; echo '#~#'; pm list packages -d; echo '#~#'; dumpsys package packages | grep -E '^  Package \\[|^    versionName='" + str2), new String[]{"#~#"}, 0, 6);
        if (3 >= split$default.size()) {
            obj = "";
        } else {
            obj = split$default.get(3);
        }
        for (String str3 : Fleet.jsplit((String) obj, 0, "\n")) {
            if (StringsKt.contains$default(str3, '/')) {
                String obj4 = StringsKt.trim(str3).toString();
                String substringBefore = StringsKt.substringBefore(obj4, '/', obj4);
                if (!arrayList2.contains(substringBefore)) {
                    arrayList2.add(substringBefore);
                }
            }
        }
        HashMap hashMap = new HashMap();
        if (2 >= split$default.size()) {
            obj2 = "";
        } else {
            obj2 = split$default.get(2);
        }
        String str4 = null;
        for (String str5 : Fleet.jsplit((String) obj2, 0, "\n")) {
            String obj5 = StringsKt.trim(str5).toString();
            if (StringsKt__StringsJVMKt.startsWith(obj5, false, "Package [")) {
                int indexOf$default = StringsKt.indexOf$default(obj5, ']', 6);
                if (indexOf$default < 9) {
                    indexOf$default = 9;
                }
                str4 = obj5.substring(9, indexOf$default);
                Intrinsics.checkNotNullExpressionValue(str4, "substring(...)");
            } else if (StringsKt__StringsJVMKt.startsWith(obj5, false, "versionName=") && str4 != null) {
                if (!obj5.equals("versionName=null") && hashMap.get(str4) == null) {
                    String substring = obj5.substring(12);
                    Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
                    hashMap.put(str4, substring);
                }
                str4 = null;
            }
        }
        if (1 >= split$default.size()) {
            obj3 = "";
        } else {
            obj3 = split$default.get(1);
        }
        String[] jsplit = Fleet.jsplit((String) obj3, 0, "\n");
        ArrayList arrayList3 = new ArrayList();
        for (String str6 : jsplit) {
            if (StringsKt__StringsJVMKt.startsWith(str6, false, "package:")) {
                arrayList3.add(str6);
            }
        }
        ArrayList arrayList4 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList3));
        Iterator it = arrayList3.iterator();
        while (it.hasNext()) {
            String substring2 = ((String) it.next()).substring(8);
            Intrinsics.checkNotNullExpressionValue(substring2, "substring(...)");
            arrayList4.add(StringsKt.trim(substring2).toString());
        }
        Set set = CollectionsKt.toSet(arrayList4);
        String[] jsplit2 = Fleet.jsplit((String) split$default.get(0), 0, "\n");
        if (z) {
            arrayList = EmptyList.INSTANCE;
        } else {
            arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(set));
            Iterator it2 = set.iterator();
            while (it2.hasNext()) {
                arrayList.add("package:" + ((String) it2.next()));
            }
        }
        int length = jsplit2.length;
        Object[] copyOf = Arrays.copyOf(jsplit2, arrayList.size() + length);
        Iterator it3 = arrayList.iterator();
        while (it3.hasNext()) {
            copyOf[length] = it3.next();
            length++;
        }
        Intrinsics.checkNotNull(copyOf);
        for (String str7 : (String[]) copyOf) {
            if (StringsKt__StringsJVMKt.startsWith(str7, false, "package:")) {
                String substring3 = str7.substring(8);
                Intrinsics.checkNotNullExpressionValue(substring3, "substring(...)");
                if (!arrayList2.contains(StringsKt.trim(substring3).toString())) {
                    String substring4 = str7.substring(8);
                    Intrinsics.checkNotNullExpressionValue(substring4, "substring(...)");
                    arrayList2.add(StringsKt.trim(substring4).toString());
                }
            }
        }
        CollectionsKt__MutableCollectionsJVMKt.sort(arrayList2);
        JSONArray jSONArray = new JSONArray();
        String homeNow = homeNow();
        try {
            jSONObject = Home.ownConfig(new AppsApi$$ExternalSyntheticLambda2(this, 4));
        } catch (Exception unused) {
            jSONObject = null;
        }
        if (jSONObject != null && (remoteLabels = this.labels) != null) {
            remoteLabels.own = Home.names(jSONObject);
        }
        Iterator it4 = arrayList2.iterator();
        Intrinsics.checkNotNullExpressionValue(it4, "iterator(...)");
        while (it4.hasNext()) {
            Object next = it4.next();
            Intrinsics.checkNotNullExpressionValue(next, "next(...)");
            String str8 = (String) next;
            JSONObject put = Census$$ExternalSyntheticOutline0.m8m("pkg", str8).put("off", set.contains(str8));
            String[] strArr = Setup.GOOGLE;
            if (!Rescue.mustKeep(str8) && !str8.equals(homeNow)) {
                z2 = false;
            } else {
                z2 = true;
            }
            JSONObject put2 = put.put("keep", z2);
            String str9 = (String) hashMap.get(str8);
            if (str9 == null) {
                str9 = "";
            }
            jSONArray.put(put2.put("version", str9).put("meta", Fleet.meta(this.labels, str8)));
        }
        JSONObject put3 = new JSONObject().put("apps", jSONArray);
        if (jSONObject == null) {
            z3 = false;
        }
        JSONObject put4 = put3.put("home", z3);
        Intrinsics.checkNotNullExpressionValue(put4, "put(...)");
        return put4;
    }

    public final String homeNow() {
        Regex regex = LauncherSwap.PKG;
        String last = Games.last(sh("p=$(cmd role get-role-holders android.app.role.HOME 2>/dev/null); c=$([ -n \"$p\" ] && cmd package query-activities --brief -a android.intent.action.MAIN -c android.intent.category.HOME 2>/dev/null | grep -m1 \"^ *$p/\"); if [ -n \"$c\" ]; then echo $c; else cmd package resolve-activity --brief -c android.intent.category.HOME -a android.intent.action.MAIN; fi"));
        return StringsKt.substringBefore(last, '/', last);
    }

    public final void keepCheck(String str) {
        if (ManagePart.PKG.matcher(str).matches()) {
            if (Fleet.keepWhy$shared_release(str, Fleet.keepNow$shared_release(sh("{ p=$(cmd role get-role-holders android.app.role.HOME 2>/dev/null); c=$([ -n \"$p\" ] && cmd package query-activities --brief -a android.intent.action.MAIN -c android.intent.category.HOME 2>/dev/null | grep -m1 \"^ *$p/\"); if [ -n \"$c\" ]; then echo $c; else cmd package resolve-activity --brief -c android.intent.category.HOME -a android.intent.action.MAIN; fi; } | tail -1; settings get secure default_input_method; settings get secure enabled_accessibility_services; pm list packages -3; for c in LEANBACK_LAUNCHER LAUNCHER; do cmd package query-activities --brief -a android.intent.action.MAIN -c android.intent.category.$c 2>/dev/null; done"))) == null) {
                return;
            } else {
                throw new IllegalArgumentException("protected: the TV needs this app");
            }
        }
        throw new IllegalArgumentException("bad package name");
    }

    public final JSONObject privacyPerms(final boolean z, String str) {
        String str2;
        String joinToString$default;
        String m;
        LinkedHashMap linkedHashMap = Privacy.PERM_TAG;
        if (ManagePart.PKG.matcher(str).matches()) {
            String[] strArr = Setup.GOOGLE;
            if (!Rescue.mustKeep(str)) {
                Privacy.Job job = this.privacy;
                job.getClass();
                JSONObject change = job.change(str, new Bloat$$ExternalSyntheticLambda1(13));
                if (change != null) {
                    if (z) {
                        str2 = "perms";
                    } else {
                        str2 = "revoked";
                    }
                    JSONArray optJSONArray = change.optJSONArray(str2);
                    if (optJSONArray == null) {
                        optJSONArray = new JSONArray();
                    }
                    IntRange until = MathKt.until(0, optJSONArray.length());
                    ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until));
                    Iterator it = until.iterator();
                    while (((IntProgressionIterator) it).hasNext) {
                        arrayList.add(optJSONArray.getString(((IntProgressionIterator) it).nextInt()));
                    }
                    if (z) {
                        ArrayList arrayList2 = new ArrayList();
                        Iterator it2 = arrayList.iterator();
                        while (it2.hasNext()) {
                            Object next = it2.next();
                            String input = (String) next;
                            Pattern compile = Pattern.compile("\\w+");
                            Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                            Intrinsics.checkNotNullParameter(input, "input");
                            if (compile.matcher(input).matches()) {
                                arrayList2.add(next);
                            }
                        }
                        joinToString$default = CollectionsKt.joinToString$default(arrayList2, "; ", null, null, new Guard$$ExternalSyntheticLambda4(str, 4), 30);
                    } else {
                        ArrayList arrayList3 = new ArrayList();
                        Iterator it3 = arrayList.iterator();
                        while (it3.hasNext()) {
                            Object next2 = it3.next();
                            String input2 = (String) next2;
                            Pattern compile2 = Pattern.compile("\\w+");
                            Intrinsics.checkNotNullExpressionValue(compile2, "compile(...)");
                            Intrinsics.checkNotNullParameter(input2, "input");
                            if (compile2.matcher(input2).matches()) {
                                arrayList3.add(next2);
                            }
                        }
                        joinToString$default = CollectionsKt.joinToString$default(arrayList3, "; ", null, null, new Guard$$ExternalSyntheticLambda4(str, 3), 30);
                    }
                    List lines = StringsKt.lines(sh(joinToString$default));
                    final ArrayList arrayList4 = new ArrayList();
                    Iterator it4 = lines.iterator();
                    while (it4.hasNext()) {
                        String obj = StringsKt.trim((String) it4.next()).toString();
                        String str3 = null;
                        if (!StringsKt__StringsJVMKt.startsWith(obj, false, "ok:")) {
                            obj = null;
                        }
                        if (obj != null) {
                            str3 = obj.substring(3);
                            Intrinsics.checkNotNullExpressionValue(str3, "substring(...)");
                        }
                        if (str3 != null) {
                            arrayList4.add(str3);
                        }
                    }
                    if (arrayList4.isEmpty() && !arrayList.isEmpty()) {
                        throw new IllegalArgumentException("locked: the system holds these permissions");
                    }
                    Iterator it5 = arrayList4.iterator();
                    while (it5.hasNext()) {
                        String str4 = (String) it5.next();
                        if (z) {
                            m = "grep -qx '" + str + " " + str4 + "' /data/local/tmp/tvr-privacy-revoked.txt 2>/dev/null || echo '" + str + " " + str4 + "' >> /data/local/tmp/tvr-privacy-revoked.txt";
                        } else {
                            m = Census$$ExternalSyntheticOutline0.m("grep -vx '", str, " ", str4, "' /data/local/tmp/tvr-privacy-revoked.txt > /data/local/tmp/tvr-privacy-revoked.txt.new 2>/dev/null; mv /data/local/tmp/tvr-privacy-revoked.txt.new /data/local/tmp/tvr-privacy-revoked.txt");
                        }
                        sh(m);
                    }
                    Object change2 = job.change(str, new Function1() { // from class: dev.tvremote.core.manage.AppsApi$$ExternalSyntheticLambda10
                        {
                            LinkedHashMap linkedHashMap2 = Privacy.PERM_TAG;
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj2) {
                            Collection plus;
                            Collection minus;
                            JSONObject o = (JSONObject) obj2;
                            Intrinsics.checkNotNullParameter(o, "o");
                            ArrayList arrayList5 = arrayList4;
                            boolean z2 = z;
                            ArrayList privacyPerms$names = AppsApi.privacyPerms$names(o.optJSONArray("perms"));
                            if (z2) {
                                plus = CollectionsKt.minus(privacyPerms$names, CollectionsKt.toSet(arrayList5));
                            } else {
                                plus = CollectionsKt.plus((List) privacyPerms$names, (Iterable) arrayList5);
                            }
                            if (z2) {
                                minus = CollectionsKt.plus((List) AppsApi.privacyPerms$names(o.optJSONArray("revoked")), (Iterable) arrayList5);
                            } else {
                                minus = CollectionsKt.minus(AppsApi.privacyPerms$names(o.optJSONArray("revoked")), CollectionsKt.toSet(arrayList5));
                            }
                            o.put("perms", new JSONArray(plus)).put("revoked", new JSONArray(minus));
                            ArrayList arrayList6 = new ArrayList();
                            Iterator it6 = plus.iterator();
                            while (true) {
                                boolean hasNext = it6.hasNext();
                                LinkedHashMap linkedHashMap2 = Privacy.PERM_TAG;
                                if (!hasNext) {
                                    break;
                                }
                                String str5 = (String) Privacy.PERM_TAG.get((String) it6.next());
                                if (str5 != null) {
                                    arrayList6.add(str5);
                                }
                            }
                            Set set = CollectionsKt.toSet(arrayList6);
                            ArrayList arrayList7 = new ArrayList();
                            Iterator it7 = minus.iterator();
                            while (it7.hasNext()) {
                                String str6 = (String) Privacy.PERM_TAG.get((String) it7.next());
                                if (str6 != null) {
                                    arrayList7.add(str6);
                                }
                            }
                            Set set2 = CollectionsKt.toSet(arrayList7);
                            ArrayList privacyPerms$names2 = AppsApi.privacyPerms$names(o.optJSONArray("tags"));
                            ArrayList arrayList8 = new ArrayList();
                            Iterator it8 = privacyPerms$names2.iterator();
                            while (it8.hasNext()) {
                                Object next3 = it8.next();
                                String str7 = (String) next3;
                                if (!set2.contains(str7) || set.contains(str7)) {
                                    arrayList8.add(next3);
                                }
                            }
                            ArrayList arrayList9 = new ArrayList();
                            for (Object obj3 : set) {
                                String str8 = (String) obj3;
                                ArrayList privacyPerms$names3 = AppsApi.privacyPerms$names(o.optJSONArray("tags"));
                                if (!privacyPerms$names3.isEmpty()) {
                                    Iterator it9 = privacyPerms$names3.iterator();
                                    while (it9.hasNext()) {
                                        if (Intrinsics.areEqual((String) it9.next(), str8)) {
                                            break;
                                        }
                                    }
                                }
                                arrayList9.add(obj3);
                            }
                            ArrayList plus2 = CollectionsKt.plus((List) arrayList8, (Iterable) arrayList9);
                            List list = Privacy.ORDER;
                            ArrayList arrayList10 = new ArrayList();
                            for (Object obj4 : list) {
                                if (plus2.contains((String) obj4)) {
                                    arrayList10.add(obj4);
                                }
                            }
                            JSONObject put = o.put("tags", new JSONArray((Collection) arrayList10));
                            List list2 = Privacy.ORDER;
                            ArrayList arrayList11 = new ArrayList();
                            for (Object obj5 : list2) {
                                if (SetsKt.minus(set2, set).contains((String) obj5)) {
                                    arrayList11.add(obj5);
                                }
                            }
                            put.put("gone", new JSONArray((Collection) arrayList11));
                            return Unit.INSTANCE;
                        }
                    });
                    JSONObject put = new JSONObject().put("ok", true).put("done", arrayList4.size()).put("failed", arrayList.size() - arrayList4.size());
                    if (change2 == null) {
                        change2 = JSONObject.NULL;
                    }
                    JSONObject put2 = put.put("row", change2);
                    Intrinsics.checkNotNullExpressionValue(put2, "put(...)");
                    return put2;
                }
                throw new IllegalArgumentException("scan again");
            }
            throw new IllegalArgumentException("protected: the TV needs this app");
        }
        throw new IllegalArgumentException("bad package name");
    }

    public final JSONObject recents() {
        Object obj;
        List split$default = StringsKt.split$default(sh("dumpsys activity recents; printf '\\043~\\043\\n'; { p=$(cmd role get-role-holders android.app.role.HOME 2>/dev/null); c=$([ -n \"$p\" ] && cmd package query-activities --brief -a android.intent.action.MAIN -c android.intent.category.HOME 2>/dev/null | grep -m1 \"^ *$p/\"); if [ -n \"$c\" ]; then echo $c; else cmd package resolve-activity --brief -c android.intent.category.HOME -a android.intent.action.MAIN; fi; } | tail -1; settings get secure default_input_method; settings get secure enabled_accessibility_services; pm list packages -3; for c in LEANBACK_LAUNCHER LAUNCHER; do cmd package query-activities --brief -a android.intent.action.MAIN -c android.intent.category.$c 2>/dev/null; done"), new String[]{"#~#\n"}, 0, 6);
        Regex regex = Recents.HEAD;
        String out = (String) split$default.get(0);
        Intrinsics.checkNotNullParameter(out, "out");
        ArrayList parse = Recents.parse(out);
        Recents.Task task = (Recents.Task) CollectionsKt.firstOrNull(parse);
        String str = null;
        if (task != null) {
            if (task.home) {
                task = null;
            }
            if (task != null) {
                str = task.pkg;
            }
        }
        HashSet hashSet = new HashSet();
        JSONArray jSONArray = new JSONArray();
        Iterator it = parse.iterator();
        while (it.hasNext()) {
            Recents.Task task2 = (Recents.Task) it.next();
            if (!task2.home) {
                String str2 = task2.pkg;
                if (hashSet.add(str2)) {
                    JSONObject put = new JSONObject().put("task", task2.id).put("pkg", str2).put("ago", task2.ago).put("top", str2.equals(str));
                    Boolean bool = task2.running;
                    if (bool != null) {
                        put.put("running", bool.booleanValue());
                    }
                    jSONArray.put(put);
                }
            }
        }
        JSONObject put2 = new JSONObject().put("apps", jSONArray);
        Intrinsics.checkNotNullExpressionValue(put2, "put(...)");
        if (1 < split$default.size()) {
            obj = split$default.get(1);
        } else {
            obj = "";
        }
        Procs$Keep keepNow$shared_release = Fleet.keepNow$shared_release((String) obj);
        JSONArray jSONArray2 = put2.getJSONArray("apps");
        int length = jSONArray2.length();
        for (int i = 0; i < length; i++) {
            JSONObject jSONObject = jSONArray2.getJSONObject(i);
            String string = jSONObject.getString("pkg");
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            Object keepWhy$shared_release = Fleet.keepWhy$shared_release(string, keepNow$shared_release);
            if (keepWhy$shared_release == null) {
                keepWhy$shared_release = JSONObject.NULL;
            }
            jSONObject.put("keep", keepWhy$shared_release);
        }
        return put2;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:112:0x0afd, code lost:
    
        if (r43.equals("app/enable") == false) goto L1103;
     */
    /* JADX WARN: Code restructure failed: missing block: B:114:0x0b07, code lost:
    
        if (r43.equals("app/stop") == false) goto L1103;
     */
    /* JADX WARN: Code restructure failed: missing block: B:191:0x0d11, code lost:
    
        if (r43.equals("privacy/grant") == false) goto L1103;
     */
    /* JADX WARN: Code restructure failed: missing block: B:193:0x0d43, code lost:
    
        if (r43.equals("app/clear") == false) goto L1103;
     */
    /* JADX WARN: Code restructure failed: missing block: B:233:0x0e97, code lost:
    
        if (kotlin.text.StringsKt.contains(r0, "unable to resolve", false) == false) goto L1051;
     */
    /* JADX WARN: Code restructure failed: missing block: B:276:0x0f75, code lost:
    
        if (r43.equals("app/disable") == false) goto L1103;
     */
    /* JADX WARN: Code restructure failed: missing block: B:278:0x0f7e, code lost:
    
        if (r43.equals("app/uninstall") == false) goto L1103;
     */
    /* JADX WARN: Code restructure failed: missing block: B:280:0x0f9f, code lost:
    
        if (r43.equals("privacy/on") == false) goto L1103;
     */
    /* JADX WARN: Code restructure failed: missing block: B:481:0x0631, code lost:
    
        if (kotlin.text.StringsKt.contains((java.lang.CharSequence) ((kotlin.text.MatcherMatchResult$groupValues$1) r3.getGroupValues()).get(2), "sandboxed", false) == false) goto L758;
     */
    /* JADX WARN: Code restructure failed: missing block: B:56:0x09f6, code lost:
    
        if (r43.equals("privacy/off") == false) goto L1103;
     */
    /* JADX WARN: Code restructure failed: missing block: B:58:0x0fa2, code lost:
    
        r1 = r10.json(65536).optString(r9);
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, "optString(...)");
        r0 = kotlin.text.StringsKt__StringsJVMKt.endsWith(r43, false, "off");
     */
    /* JADX WARN: Code restructure failed: missing block: B:59:0x0fb4, code lost:
    
        if (r0 == false) goto L1107;
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x0fb6, code lost:
    
        r2 = "disable";
     */
    /* JADX WARN: Code restructure failed: missing block: B:61:0x0fbb, code lost:
    
        r4.app(r1, r2);
     */
    /* JADX WARN: Code restructure failed: missing block: B:62:0x0fbe, code lost:
    
        if (r0 == false) goto L1111;
     */
    /* JADX WARN: Code restructure failed: missing block: B:63:0x0fc0, code lost:
    
        r4.sh(dev.tvremote.core.Census$$ExternalSyntheticOutline0.m("grep -qx '", r1, "' /data/local/tmp/tvr-disabled.txt 2>/dev/null || echo '", r1, "' >> /data/local/tmp/tvr-disabled.txt"));
     */
    /* JADX WARN: Code restructure failed: missing block: B:64:0x0fcd, code lost:
    
        r2 = new org.json.JSONObject().put("ok", true);
        r0 = r4.privacy.change(r1, new dev.tvremote.core.manage.AppsApi$$ExternalSyntheticLambda9());
     */
    /* JADX WARN: Code restructure failed: missing block: B:65:0x0fe4, code lost:
    
        if (r0 != null) goto L1114;
     */
    /* JADX WARN: Code restructure failed: missing block: B:66:0x0fe6, code lost:
    
        r0 = org.json.JSONObject.NULL;
     */
    /* JADX WARN: Code restructure failed: missing block: B:67:0x0fe8, code lost:
    
        r0 = r2.put("row", r0);
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, "put(...)");
        r1 = new dev.tvremote.core.web.HttpServer.Response();
        r1.status = 200;
        r2 = dev.tvremote.core.web.HttpServer.trusted;
        r1.body = dev.tvremote.core.Census$$ExternalSyntheticOutline0.m(r11, r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:68:0x1004, code lost:
    
        return r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:69:0x0fb9, code lost:
    
        r2 = "enable";
     */
    /* JADX WARN: Code restructure failed: missing block: B:71:0x0a04, code lost:
    
        if (r43.equals("app/launch") == false) goto L1103;
     */
    /* JADX WARN: Code restructure failed: missing block: B:73:0x0f81, code lost:
    
        r1 = r10.json(65536).optString(r9);
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, "optString(...)");
        r0 = r43.substring(4);
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, "substring(...)");
     */
    /* JADX WARN: Code restructure failed: missing block: B:74:0x0f98, code lost:
    
        return r4.app(r1, r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:76:0x0a12, code lost:
    
        if (r43.equals("privacy/revoke") == false) goto L1103;
     */
    /* JADX WARN: Code restructure failed: missing block: B:78:0x0d15, code lost:
    
        r1 = r10.json(65536).optString(r9);
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, "optString(...)");
        r0 = r4.privacyPerms(kotlin.text.StringsKt__StringsJVMKt.endsWith(r43, false, "revoke"), r1);
        r1 = new dev.tvremote.core.web.HttpServer.Response();
        r1.status = 200;
        r2 = dev.tvremote.core.web.HttpServer.trusted;
        r1.body = dev.tvremote.core.Census$$ExternalSyntheticOutline0.m(r11, r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:79:0x0d3c, code lost:
    
        return r1;
     */
    /* JADX WARN: Failed to find 'out' block for switch in B:2:0x004a. Please report as an issue. */
    /* JADX WARN: Failed to find 'out' block for switch in B:7:0x0893. Please report as an issue. */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:354:0x0287  */
    /* JADX WARN: Removed duplicated region for block: B:365:0x02c2 A[LOOP:10: B:363:0x02bc->B:365:0x02c2, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:499:0x0695  */
    /* JADX WARN: Removed duplicated region for block: B:510:0x06c0  */
    /* JADX WARN: Removed duplicated region for block: B:6:0x0887  */
    /* JADX WARN: Type inference failed for: r0v174, types: [org.json.JSONObject] */
    /* JADX WARN: Type inference failed for: r0v176, types: [org.json.JSONObject] */
    /* JADX WARN: Type inference failed for: r0v187, types: [java.util.Map, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v48, types: [org.json.JSONObject] */
    /* JADX WARN: Type inference failed for: r10v9, types: [java.util.HashMap] */
    /* JADX WARN: Type inference failed for: r11v14, types: [java.util.HashMap] */
    /* JADX WARN: Type inference failed for: r12v5, types: [java.util.ArrayList] */
    /* JADX WARN: Type inference failed for: r12v6, types: [java.lang.Iterable] */
    /* JADX WARN: Type inference failed for: r12v7 */
    /* JADX WARN: Type inference failed for: r14v24 */
    /* JADX WARN: Type inference failed for: r14v3 */
    /* JADX WARN: Type inference failed for: r14v4, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r2v24, types: [org.json.JSONObject] */
    /* JADX WARN: Type inference failed for: r6v42, types: [org.json.JSONObject, java.lang.Object] */
    @Override // dev.tvremote.core.manage.ManagePart
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final HttpServer.Response route(String str, boolean z, HttpServer.Request request) {
        HttpServer.Request request2;
        String str2;
        String str3;
        String str4;
        Object obj;
        String str5;
        AppsApi appsApi;
        String str6;
        String str7;
        String str8;
        String str9;
        String str10;
        int i;
        int i2;
        Object obj2;
        Object obj3;
        List list;
        String str11;
        Iterator it;
        List<Procs$Proc> sortedWith;
        String keepWhy$shared_release;
        MatcherMatchResult access$findNext;
        MatcherMatchResult matcherMatchResult;
        int i3;
        long j;
        long j2;
        String label;
        String str12;
        HttpServer.Request request3;
        Object obj4;
        Object obj5;
        Object obj6;
        long j3;
        int indexOf$default;
        ?? arrayList;
        int i4;
        String label2;
        String str13;
        Long longOrNull;
        Adb.Stream stream;
        long j4;
        long j5;
        List<String> listOf;
        String str14;
        String str15;
        String str16;
        ?? r0;
        List list2;
        int hashCode = str.hashCode();
        EmptyList emptyList = EmptyList.INSTANCE;
        String str17 = "matcher(...)";
        String str18 = "keep";
        String str19 = "label";
        Integer num = null;
        r34 = null;
        Map names = null;
        String str20 = null;
        switch (hashCode) {
            case -1943177105:
                request2 = request;
                str2 = "put(...)";
                str3 = "pkg";
                str4 = "id";
                obj = "recents";
                str5 = "toString(...)";
                appsApi = this;
                str6 = " ";
                str7 = "";
                str8 = "apps";
                str9 = str18;
                str10 = str19;
                if (str.equals("apps/boot")) {
                    return appsApi.text(20000L, "cmd package query-receivers --brief -a android.intent.action.BOOT_COMPLETED 2>/dev/null | grep / | sed 's/^ *//'");
                }
                if (z) {
                    switch (str.hashCode()) {
                        case -1891201594:
                            break;
                        case -1784810892:
                            break;
                        case -1632687878:
                            break;
                        case -934443629:
                            if (str.equals("rescue")) {
                                JSONObject run$default = Rescue.run$default(new AppsApi$$ExternalSyntheticLambda2(appsApi, 2));
                                String optString = run$default.optString("stopped");
                                Intrinsics.checkNotNull(optString);
                                if (optString.length() > 0) {
                                    try {
                                        RemoteLabels remoteLabels = appsApi.labels;
                                        if (remoteLabels != null) {
                                            str20 = remoteLabels.label(optString);
                                        }
                                    } catch (Exception unused) {
                                    }
                                    if (str20 != null) {
                                        optString = str20;
                                    }
                                    run$default.put(str10, optString);
                                }
                                HttpServer.Response response = new HttpServer.Response();
                                response.status = 200;
                                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = HttpServer.trusted;
                                response.body = Census$$ExternalSyntheticOutline0.m(str5, run$default);
                                return response;
                            }
                            break;
                        case -673453916:
                            if (str.equals("privacy/scan")) {
                                JSONObject start = appsApi.privacy.start();
                                HttpServer.Response response2 = new HttpServer.Response();
                                response2.status = 200;
                                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda02 = HttpServer.trusted;
                                response2.body = Census$$ExternalSyntheticOutline0.m(str5, start);
                                return response2;
                            }
                            break;
                        case -673437143:
                            if (str.equals("privacy/stop")) {
                                Privacy.Job job = appsApi.privacy;
                                synchronized (job.lock) {
                                    job.stopped = true;
                                    stream = job.stream;
                                }
                                if (stream != null) {
                                    try {
                                        stream.close();
                                    } catch (Exception unused2) {
                                    }
                                }
                                JSONObject snapshot = job.snapshot(0, job.id);
                                HttpServer.Response response3 = new HttpServer.Response();
                                response3.status = 200;
                                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda03 = HttpServer.trusted;
                                response3.body = Census$$ExternalSyntheticOutline0.m(str5, snapshot);
                                return response3;
                            }
                            break;
                        case 96801:
                            if (str.equals("app")) {
                                String optString2 = request2.json(65536).optString("link");
                                Intrinsics.checkNotNullExpressionValue(optString2, "optString(...)");
                                String obj7 = StringsKt.trim(optString2).toString();
                                if (Intrinsics.areEqual(obj7, "settings")) {
                                    if (StringsKt.contains(appsApi.sh("am start -a android.settings.SETTINGS 2>&1"), "Error", false)) {
                                        throw new IllegalArgumentException("the TV did not open its settings");
                                    }
                                } else if (StringsKt__StringsJVMKt.startsWith(obj7, false, "pin:")) {
                                    Home.openPin(obj7, new AppsApi$$ExternalSyntheticLambda2(appsApi, 5));
                                } else if (ManagePart.PKG.matcher(obj7).matches()) {
                                    appsApi.app(obj7, "launch");
                                } else {
                                    String input = StringsKt.trim(obj7).toString();
                                    Pattern compile = Pattern.compile("^[a-zA-Z][a-zA-Z0-9+.-]*:\\S+$");
                                    Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                                    Intrinsics.checkNotNullParameter(input, "input");
                                    if (compile.matcher(input).matches()) {
                                        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                                        String sh = appsApi.sh("am start -a android.intent.action.VIEW -d " + Mdns.q(input) + " 2>&1");
                                        if (!StringsKt.contains(sh, "Error", false)) {
                                            Locale ROOT = Locale.ROOT;
                                            Intrinsics.checkNotNullExpressionValue(ROOT, "ROOT");
                                            String lowerCase = sh.toLowerCase(ROOT);
                                            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                                            break;
                                        }
                                        throw new IllegalArgumentException("the TV has no app that can open this");
                                    }
                                    throw new IllegalArgumentException("not a link");
                                }
                                JSONObject put = new JSONObject().put("ok", true).put("via", "adb");
                                Intrinsics.checkNotNullExpressionValue(put, str2);
                                HttpServer.Response response4 = new HttpServer.Response();
                                response4.status = 200;
                                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda04 = HttpServer.trusted;
                                response4.body = Census$$ExternalSyntheticOutline0.m(str5, put);
                                return response4;
                            }
                            break;
                        case 3151468:
                            if (str.equals("free")) {
                                Long kb = Games.kb(appsApi.sh("cat /proc/meminfo"), "MemAvailable");
                                if (kb != null) {
                                    j4 = kb.longValue();
                                } else {
                                    j4 = 0;
                                }
                                long j6 = j4 / 1024;
                                appsApi.sh("am kill-all");
                                Thread.sleep(1500L);
                                Long kb2 = Games.kb(appsApi.sh("cat /proc/meminfo"), "MemAvailable");
                                if (kb2 != null) {
                                    j5 = kb2.longValue();
                                } else {
                                    j5 = 0;
                                }
                                long j7 = j5 / 1024;
                                JSONObject put2 = new JSONObject().put("before", j6).put("after", j7).put("freed", Math.max(0L, j7 - j6));
                                Intrinsics.checkNotNullExpressionValue(put2, "put(...)");
                                HttpServer.Response response5 = new HttpServer.Response();
                                response5.status = 200;
                                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda05 = HttpServer.trusted;
                                response5.body = Census$$ExternalSyntheticOutline0.m(str5, put2);
                                return response5;
                            }
                            break;
                        case 94746185:
                            if (str.equals("clean")) {
                                return appsApi.text(90000L, "a=$(stat -f -c '%a %S' /data); pm trim-caches 999G >/dev/null 2>&1; sleep 2; echo $a $(stat -f -c '%a %S' /data)");
                            }
                            break;
                        case 453318879:
                            break;
                        case 587129813:
                            break;
                        case 759965264:
                            if (str.equals("procs/kill")) {
                                String optString3 = request2.json(65536).optString(str3);
                                Intrinsics.checkNotNull(optString3);
                                appsApi.keepCheck(optString3);
                                ConcurrentHashMap concurrentHashMap2 = Adb.ASKING;
                                appsApi.sh("am force-stop " + Mdns.q(optString3));
                                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda06 = HttpServer.trusted;
                                byte[] bytes = WorkService.Companion.bytes("{\"ok\":true}");
                                HttpServer.Response response6 = new HttpServer.Response();
                                response6.type = "application/json; charset=utf-8";
                                response6.body = bytes;
                                return response6;
                            }
                            break;
                        case 1082295672:
                            if (str.equals(obj)) {
                                JSONObject json = request2.json(65536);
                                JSONArray optJSONArray = json.optJSONArray("pkgs");
                                if (optJSONArray != null) {
                                    IntRange until = MathKt.until(0, optJSONArray.length());
                                    ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until));
                                    Iterator it2 = until.iterator();
                                    while (((IntProgressionIterator) it2).hasNext) {
                                        arrayList2.add(optJSONArray.getString(((IntProgressionIterator) it2).nextInt()));
                                    }
                                    listOf = CollectionsKt.distinct(arrayList2);
                                } else if (json.optBoolean("all")) {
                                    JSONArray jSONArray = appsApi.recents().getJSONArray(str8);
                                    IntRange until2 = MathKt.until(0, jSONArray.length());
                                    ArrayList arrayList3 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until2));
                                    Iterator it3 = until2.iterator();
                                    while (((IntProgressionIterator) it3).hasNext) {
                                        arrayList3.add(jSONArray.getJSONObject(((IntProgressionIterator) it3).nextInt()));
                                    }
                                    ArrayList arrayList4 = new ArrayList();
                                    Iterator it4 = arrayList3.iterator();
                                    while (it4.hasNext()) {
                                        Object next = it4.next();
                                        JSONObject jSONObject = (JSONObject) next;
                                        if (!jSONObject.optBoolean("top") && jSONObject.isNull(str9)) {
                                            arrayList4.add(next);
                                        }
                                    }
                                    ArrayList arrayList5 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList4));
                                    Iterator it5 = arrayList4.iterator();
                                    while (it5.hasNext()) {
                                        arrayList5.add(((JSONObject) it5.next()).getString(str3));
                                    }
                                    listOf = arrayList5;
                                } else {
                                    listOf = MathKt.listOf(json.optString(str3));
                                }
                                Procs$Keep keepNow$shared_release = Fleet.keepNow$shared_release(appsApi.sh("{ p=$(cmd role get-role-holders android.app.role.HOME 2>/dev/null); c=$([ -n \"$p\" ] && cmd package query-activities --brief -a android.intent.action.MAIN -c android.intent.category.HOME 2>/dev/null | grep -m1 \"^ *$p/\"); if [ -n \"$c\" ]; then echo $c; else cmd package resolve-activity --brief -c android.intent.category.HOME -a android.intent.action.MAIN; fi; } | tail -1; settings get secure default_input_method; settings get secure enabled_accessibility_services; pm list packages -3; for c in LEANBACK_LAUNCHER LAUNCHER; do cmd package query-activities --brief -a android.intent.action.MAIN -c android.intent.category.$c 2>/dev/null; done"));
                                for (String str21 : listOf) {
                                    if (ManagePart.PKG.matcher(str21).matches()) {
                                        Intrinsics.checkNotNull(str21);
                                        if (Fleet.keepWhy$shared_release(str21, keepNow$shared_release) == null) {
                                            Recents.close(new AppsApi$$ExternalSyntheticLambda2(appsApi, 3), str21);
                                        } else {
                                            throw new IllegalArgumentException("protected: the TV needs this app");
                                        }
                                    } else {
                                        throw new IllegalArgumentException("bad package name");
                                    }
                                }
                                JSONObject put3 = new JSONObject().put("ok", true).put("closed", listOf.size());
                                Intrinsics.checkNotNullExpressionValue(put3, str2);
                                HttpServer.Response response7 = new HttpServer.Response();
                                response7.status = 200;
                                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda07 = HttpServer.trusted;
                                response7.body = Census$$ExternalSyntheticOutline0.m(str5, put3);
                                return response7;
                            }
                            break;
                        case 1123382814:
                            String str22 = str6;
                            if (str.equals("app/perm")) {
                                JSONObject json2 = request2.json(65536);
                                String optString4 = json2.optString(str3);
                                Regex regex = Setup.PERMS_FIXED;
                                Intrinsics.checkNotNull(optString4);
                                if (!regex.matches(optString4)) {
                                    TvShell tvShell = TvShell.INSTANCE;
                                    String optString5 = json2.optString("perm");
                                    Intrinsics.checkNotNullExpressionValue(optString5, "optString(...)");
                                    boolean optBoolean = json2.optBoolean("on");
                                    TvShell.pkg(optString4);
                                    if (TvShell.PERM.matches(optString5)) {
                                        if (optBoolean) {
                                            str14 = "grant";
                                        } else {
                                            str14 = "revoke";
                                        }
                                        StringBuilder sb = new StringBuilder("pm ");
                                        sb.append(str14);
                                        sb.append(str22);
                                        sb.append(optString4);
                                        sb.append(str22);
                                        return appsApi.text(20000L, Census$$ExternalSyntheticOutline0.m(sb, optString5, " 2>&1 && echo ok"));
                                    }
                                    throw new IllegalArgumentException("bad permission");
                                }
                                throw new IllegalArgumentException("protected: the TV needs this app");
                            }
                            break;
                        case 1123486512:
                            break;
                        case 1226970417:
                            break;
                        case 1286259489:
                            if (str.equals("privacy/a11y-off")) {
                                String optString6 = request2.json(65536).optString(str3);
                                Intrinsics.checkNotNullExpressionValue(optString6, "optString(...)");
                                if (ManagePart.PKG.matcher(optString6).matches()) {
                                    String[] strArr = Setup.GOOGLE;
                                    if (!Rescue.mustKeep(optString6)) {
                                        if (Privacy.PKG.matches(optString6)) {
                                            List split$default = StringsKt.split$default(appsApi.sh("L=$(settings get secure enabled_accessibility_services | tr ':' '\\n' | grep -v '^" + StringsKt__StringsJVMKt.replace$default(optString6, ".", "\\.") + "/' | grep -v '^null$' | tr '\\n' ':' | sed 's/:$//'); if [ -z \"$L\" ]; then settings delete secure enabled_accessibility_services >/dev/null; settings put secure accessibility_enabled 0; else settings put secure enabled_accessibility_services \"$L\"; fi; settings get secure enabled_accessibility_services"), new char[]{':'});
                                            if (!split$default.isEmpty()) {
                                                Iterator it6 = split$default.iterator();
                                                while (it6.hasNext()) {
                                                    if (StringsKt__StringsJVMKt.startsWith(StringsKt.trim((String) it6.next()).toString(), false, optString6.concat("/"))) {
                                                        throw new IllegalArgumentException("locked: the system holds these permissions");
                                                    }
                                                }
                                            }
                                            JSONObject put4 = new JSONObject().put("ok", true);
                                            Object change = appsApi.privacy.change(optString6, new Bloat$$ExternalSyntheticLambda1(2));
                                            if (change == null) {
                                                change = JSONObject.NULL;
                                            }
                                            JSONObject put5 = put4.put("row", change);
                                            Intrinsics.checkNotNullExpressionValue(put5, str2);
                                            HttpServer.Response response8 = new HttpServer.Response();
                                            response8.status = 200;
                                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda08 = HttpServer.trusted;
                                            response8.body = Census$$ExternalSyntheticOutline0.m(str5, put5);
                                            return response8;
                                        }
                                        throw new IllegalArgumentException("bad package name");
                                    }
                                    throw new IllegalArgumentException("protected: the TV needs this app");
                                }
                                throw new IllegalArgumentException("bad package name");
                            }
                            break;
                        case 1324696301:
                            break;
                        case 1415975777:
                            break;
                        case 1502292584:
                            break;
                        case 1591224044:
                            if (str.equals("app/rename")) {
                                JSONObject json3 = request2.json(65536);
                                String optString7 = json3.optString(str3);
                                if (ManagePart.PKG.matcher(optString7).matches()) {
                                    Regex regex2 = Home.PIN_KEY;
                                    AppsApi$$ExternalSyntheticLambda2 appsApi$$ExternalSyntheticLambda2 = new AppsApi$$ExternalSyntheticLambda2(appsApi, 1);
                                    Intrinsics.checkNotNull(optString7);
                                    String optString8 = json3.optString("name");
                                    Intrinsics.checkNotNullExpressionValue(optString8, "optString(...)");
                                    JSONObject ownConfig = Home.ownConfig(appsApi$$ExternalSyntheticLambda2);
                                    if (ownConfig != null) {
                                        JSONObject optJSONObject = ownConfig.optJSONObject("names");
                                        if (optJSONObject == null || (str15 = optJSONObject.toString()) == null) {
                                            str15 = "{}";
                                        }
                                        ?? jSONObject2 = new JSONObject(str15);
                                        Pattern compile2 = Pattern.compile("\\s+");
                                        Intrinsics.checkNotNullExpressionValue(compile2, "compile(...)");
                                        String replaceAll = compile2.matcher(optString8).replaceAll(str6);
                                        Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
                                        String take = StringsKt.take(StringsKt.trim(replaceAll).toString(), 30);
                                        if (take.length() == 0) {
                                            jSONObject2.remove(optString7);
                                        } else {
                                            jSONObject2.put(optString7, take);
                                        }
                                        Home.call(str7, appsApi$$ExternalSyntheticLambda2, new JSONObject().put("names", jSONObject2));
                                        names = Home.names(new JSONObject().put("names", jSONObject2));
                                    }
                                    Map map = names;
                                    if (map != null) {
                                        RemoteLabels remoteLabels2 = appsApi.labels;
                                        if (remoteLabels2 != null) {
                                            remoteLabels2.own = map;
                                        }
                                        JSONObject put6 = new JSONObject().put("ok", true);
                                        RemoteLabels remoteLabels3 = appsApi.labels;
                                        if ((remoteLabels3 == null || (str16 = remoteLabels3.label(optString7)) == null) && (str16 = (String) map.get(optString7)) == null) {
                                            str16 = StringsKt.substringAfterLast(optString7, '.', optString7);
                                        }
                                        JSONObject put7 = put6.put(str10, str16);
                                        Intrinsics.checkNotNullExpressionValue(put7, str2);
                                        HttpServer.Response response9 = new HttpServer.Response();
                                        response9.status = 200;
                                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda09 = HttpServer.trusted;
                                        response9.body = Census$$ExternalSyntheticOutline0.m(str5, put7);
                                        return response9;
                                    }
                                    throw new IOException("home:missing");
                                }
                                throw new IllegalArgumentException("bad package");
                            }
                            break;
                        case 1985941072:
                            if (str.equals("setting")) {
                                Voice voice = Voice.INSTANCE;
                                Phrases phrases = Voice.phrases;
                                if (phrases != null && (r0 = phrases.settings) != 0 && (list2 = (List) r0.get(request2.json(65536).optString(str4))) != null) {
                                    JSONObject put8 = new JSONObject().put("ok", true);
                                    TvShell tvShell2 = TvShell.INSTANCE;
                                    JSONObject put9 = put8.put("via", StringsKt.trim(appsApi.sh(TvShell.setting(list2))).toString());
                                    Intrinsics.checkNotNullExpressionValue(put9, str2);
                                    HttpServer.Response response10 = new HttpServer.Response();
                                    response10.status = 200;
                                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda010 = HttpServer.trusted;
                                    response10.body = Census$$ExternalSyntheticOutline0.m(str5, put9);
                                    return response10;
                                }
                                throw new IllegalArgumentException("unknown settings page");
                            }
                            break;
                    }
                }
                return null;
            case -314498168:
                request2 = request;
                str2 = "put(...)";
                str3 = "pkg";
                obj = "recents";
                str5 = "toString(...)";
                appsApi = this;
                str6 = " ";
                str7 = "";
                str8 = "apps";
                str9 = str18;
                str10 = str19;
                if (str.equals("privacy") && !z) {
                    Privacy.Job job2 = appsApi.privacy;
                    Integer intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull(request2.q("since"));
                    if (intOrNull != null) {
                        i = intOrNull.intValue();
                    } else {
                        i = 0;
                    }
                    Integer intOrNull2 = StringsKt__StringNumberConversionsKt.toIntOrNull(request2.q("id"));
                    if (intOrNull2 != null) {
                        i2 = intOrNull2.intValue();
                    } else {
                        i2 = -1;
                    }
                    JSONObject snapshot2 = job2.snapshot(i, i2);
                    HttpServer.Response response11 = new HttpServer.Response();
                    response11.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda011 = HttpServer.trusted;
                    response11.body = Census$$ExternalSyntheticOutline0.m(str5, snapshot2);
                    return response11;
                }
                str4 = "id";
                if (z) {
                }
                return null;
            case 3000946:
                str2 = "put(...)";
                str3 = "pkg";
                obj = "recents";
                str5 = "toString(...)";
                appsApi = this;
                str6 = " ";
                str7 = "";
                str8 = "apps";
                str9 = str18;
                str10 = str19;
                if (str.equals(str8)) {
                    JSONObject apps = appsApi.apps(request.q("system").equals("1"));
                    HttpServer.Response response12 = new HttpServer.Response();
                    response12.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda012 = HttpServer.trusted;
                    response12.body = Census$$ExternalSyntheticOutline0.m(str5, apps);
                    return response12;
                }
                request2 = request;
                str4 = "id";
                if (z) {
                }
                return null;
            case 106940381:
                appsApi = this;
                obj = "recents";
                str6 = " ";
                str3 = "pkg";
                str7 = "";
                str5 = "toString(...)";
                if (!str.equals("procs")) {
                    request2 = request;
                    str2 = "put(...)";
                    str4 = "id";
                    str8 = "apps";
                    str9 = str18;
                    str10 = str19;
                    if (z) {
                    }
                    return null;
                }
                List split$default2 = StringsKt.split$default(appsApi.sh("grep -E '^(MemTotal|MemAvailable):' /proc/meminfo; printf '\\043~\\043\\n'; dumpsys meminfo --oom; printf '\\043~\\043\\n'; { p=$(cmd role get-role-holders android.app.role.HOME 2>/dev/null); c=$([ -n \"$p\" ] && cmd package query-activities --brief -a android.intent.action.MAIN -c android.intent.category.HOME 2>/dev/null | grep -m1 \"^ *$p/\"); if [ -n \"$c\" ]; then echo $c; else cmd package resolve-activity --brief -c android.intent.category.HOME -a android.intent.action.MAIN; fi; } | tail -1; settings get secure default_input_method; settings get secure enabled_accessibility_services; pm list packages -3; for c in LEANBACK_LAUNCHER LAUNCHER; do cmd package query-activities --brief -a android.intent.action.MAIN -c android.intent.category.$c 2>/dev/null; done"), new String[]{"#~#\n"}, 0, 6);
                JSONArray jSONArray2 = new JSONArray();
                if (1 < split$default2.size()) {
                    obj2 = split$default2.get(1);
                } else {
                    obj2 = str7;
                }
                String meminfo = (String) obj2;
                if (2 < split$default2.size()) {
                    obj3 = split$default2.get(2);
                } else {
                    obj3 = str7;
                }
                Procs$Keep keepNow$shared_release2 = Fleet.keepNow$shared_release((String) obj3);
                Intrinsics.checkNotNullParameter(meminfo, "meminfo");
                int indexOf$default2 = StringsKt.indexOf$default(meminfo, "Total PSS by OOM adjustment:", 0, false, 6);
                if (indexOf$default2 < 0) {
                    list = split$default2;
                    str11 = "mb";
                    sortedWith = emptyList;
                } else {
                    list = split$default2;
                    str11 = "mb";
                    List asList = ArraysKt.asList(new String[]{"system", "front", "home", "bg", "cached"});
                    ?? hashMap = new HashMap();
                    ?? hashMap2 = new HashMap();
                    String substring = meminfo.substring(indexOf$default2);
                    Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
                    ?? r14 = 0;
                    Iterator it7 = CollectionsKt.drop(1, StringsKt.split$default(substring, new String[]{"\n"}, 0, 6)).iterator();
                    Object obj8 = "cached";
                    while (it7.hasNext()) {
                        String str23 = (String) it7.next();
                        if (!StringsKt.isBlank(str23)) {
                            Iterator it8 = it7;
                            if (StringsKt.contains(str23, "(pid ", r14)) {
                                access$findNext = null;
                            } else {
                                access$findNext = MathKt.access$findNext(Census$$ExternalSyntheticOutline0.m6m("^\\s*[\\d,]+K: (.+)$", "compile(...)", str23, str17), r14, str23);
                            }
                            if (access$findNext != null) {
                                String obj9 = StringsKt.trim((String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)).toString();
                                if (Intrinsics.areEqual(obj9, "Native")) {
                                    obj8 = "native";
                                } else if (Intrinsics.areEqual(obj9, "System") || StringsKt__StringsJVMKt.startsWith(obj9, false, "Persistent")) {
                                    obj8 = "system";
                                } else if (obj9.equals("Foreground") || obj9.equals("Visible")) {
                                    obj8 = "front";
                                } else if (obj9.equals("Home")) {
                                    obj8 = "home";
                                } else if (!obj9.equals("Previous") && !StringsKt__StringsJVMKt.startsWith(obj9, false, "Cached")) {
                                    obj8 = "bg";
                                } else {
                                    obj8 = "cached";
                                }
                                it7 = it8;
                            } else {
                                String str24 = str17;
                                MatcherMatchResult access$findNext2 = MathKt.access$findNext(Census$$ExternalSyntheticOutline0.m6m("^\\s+([\\d,]+)K: ([^\\s(]+)", "compile(...)", str23, str17), 0, str23);
                                if (access$findNext2 != null) {
                                    String str25 = (String) ((MatcherMatchResult$groupValues$1) access$findNext2.getGroupValues()).get(2);
                                    String substringBefore = StringsKt.substringBefore(str25, ':', str25);
                                    if (!obj8.equals("native") && StringsKt.contains$default(substringBefore, '.')) {
                                        if (substringBefore.equals("com.google.android.webview")) {
                                            matcherMatchResult = access$findNext2;
                                            break;
                                        } else {
                                            matcherMatchResult = access$findNext2;
                                        }
                                        Integer num2 = (Integer) hashMap.get(substringBefore);
                                        if (num2 != null) {
                                            i3 = num2.intValue();
                                        } else {
                                            i3 = 0;
                                        }
                                        hashMap.put(substringBefore, Integer.valueOf((Integer.parseInt(StringsKt__StringsJVMKt.replace$default((String) ((MatcherMatchResult$groupValues$1) matcherMatchResult.getGroupValues()).get(1), ",", str7)) / 1024) + i3));
                                        String str26 = (String) hashMap2.get(substringBefore);
                                        if (str26 == null || asList.indexOf(obj8) < asList.indexOf(str26)) {
                                            hashMap2.put(substringBefore, obj8);
                                        }
                                    }
                                }
                                it7 = it8;
                                str17 = str24;
                            }
                            r14 = 0;
                        } else {
                            Set entrySet = hashMap.entrySet();
                            Intrinsics.checkNotNullExpressionValue(entrySet, "<get-entries>(...)");
                            ArrayList arrayList6 = new ArrayList();
                            for (Object obj10 : entrySet) {
                                if (((Number) ((Map.Entry) obj10).getValue()).intValue() >= 1) {
                                    arrayList6.add(obj10);
                                }
                            }
                            ArrayList arrayList7 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList6));
                            it = arrayList6.iterator();
                            while (it.hasNext()) {
                                Map.Entry entry = (Map.Entry) it.next();
                                Intrinsics.checkNotNull(entry);
                                Object key = entry.getKey();
                                Intrinsics.checkNotNullExpressionValue(key, "component1(...)");
                                String str27 = (String) key;
                                Object value = entry.getValue();
                                Intrinsics.checkNotNullExpressionValue(value, "component2(...)");
                                Integer num3 = (Integer) value;
                                String str28 = (String) hashMap2.get(str27);
                                if (str28 == null) {
                                    str28 = "cached";
                                }
                                int intValue = num3.intValue();
                                if (str28.equals("system")) {
                                    keepWhy$shared_release = "system";
                                } else {
                                    keepWhy$shared_release = Fleet.keepWhy$shared_release(str27, keepNow$shared_release2);
                                }
                                arrayList7.add(new Procs$Proc(intValue, str27, str28, keepWhy$shared_release));
                            }
                            sortedWith = CollectionsKt.sortedWith(arrayList7, new Phrases$alt$$inlined$sortedByDescending$1(5));
                        }
                    }
                    Set entrySet2 = hashMap.entrySet();
                    Intrinsics.checkNotNullExpressionValue(entrySet2, "<get-entries>(...)");
                    ArrayList arrayList62 = new ArrayList();
                    while (r0.hasNext()) {
                    }
                    ArrayList arrayList72 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList62));
                    it = arrayList62.iterator();
                    while (it.hasNext()) {
                    }
                    sortedWith = CollectionsKt.sortedWith(arrayList72, new Phrases$alt$$inlined$sortedByDescending$1(5));
                }
                for (Procs$Proc procs$Proc : sortedWith) {
                    ?? put10 = new JSONObject().put(str3, procs$Proc.pkg);
                    String str29 = procs$Proc.pkg;
                    RemoteLabels remoteLabels4 = appsApi.labels;
                    if (remoteLabels4 != null && (label = remoteLabels4.label(str29)) != null) {
                        str29 = label;
                    }
                    String str30 = str19;
                    String str31 = str11;
                    JSONObject put11 = put10.put(str30, str29).put(str31, procs$Proc.mb).put("state", procs$Proc.state);
                    Object obj11 = procs$Proc.keep;
                    if (obj11 == null) {
                        obj11 = JSONObject.NULL;
                    }
                    String str32 = str18;
                    jSONArray2.put(put11.put(str32, obj11));
                    str18 = str32;
                    str19 = str30;
                    str11 = str31;
                }
                JSONObject put12 = new JSONObject().put("apps", jSONArray2);
                List list3 = list;
                Long kb3 = Games.kb((String) list3.get(0), "MemTotal");
                if (kb3 != null) {
                    j = kb3.longValue();
                } else {
                    j = 0;
                }
                JSONObject put13 = put12.put("mem_total", j * 1024);
                Long kb4 = Games.kb((String) list3.get(0), "MemAvailable");
                if (kb4 != null) {
                    j2 = kb4.longValue();
                } else {
                    j2 = 0;
                }
                JSONObject put14 = put13.put("mem_free", j2 * 1024);
                Intrinsics.checkNotNullExpressionValue(put14, "put(...)");
                HttpServer.Response response13 = new HttpServer.Response();
                response13.status = 200;
                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda013 = HttpServer.trusted;
                response13.body = Census$$ExternalSyntheticOutline0.m(str5, put14);
                return response13;
            case 1082295672:
                appsApi = this;
                str3 = "pkg";
                str5 = "toString(...)";
                str7 = "";
                if (!str.equals("recents") || z) {
                    request2 = request;
                    str6 = " ";
                    obj = "recents";
                    str4 = "id";
                    str9 = str18;
                    str10 = str19;
                    str2 = "put(...)";
                    str8 = "apps";
                    if (z) {
                    }
                    return null;
                }
                JSONObject recents = appsApi.recents();
                HttpServer.Response response14 = new HttpServer.Response();
                response14.status = 200;
                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda014 = HttpServer.trusted;
                response14.body = Census$$ExternalSyntheticOutline0.m(str5, recents);
                return response14;
            case 1123182556:
                appsApi = this;
                str12 = "put(...)";
                request3 = request;
                str3 = "pkg";
                str5 = "toString(...)";
                str7 = "";
                if (str.equals("app/info")) {
                    TvShell tvShell3 = TvShell.INSTANCE;
                    String q = request3.q(str3);
                    TvShell.pkg(q);
                    return appsApi.text(20000L, "p=" + q + "; dumpsys package $p | sed -n '/^Packages:/,$p'; printf '\\043~\\043\\n'; pidof $p; printf '\\043~\\043\\n'; dumpsys meminfo $p 2>/dev/null | grep -m1 -E '^ *TOTAL'; printf '\\043~\\043\\n'; cmd package query-receivers --brief -a android.intent.action.BOOT_COMPLETED 2>/dev/null | grep / | sed 's/^ *//' | grep \"^$p/\"");
                }
                request2 = request3;
                str4 = "id";
                str10 = str19;
                obj = "recents";
                str2 = str12;
                str6 = " ";
                str8 = "apps";
                str9 = str18;
                if (z) {
                }
                return null;
            case 1123293491:
                appsApi = this;
                str12 = "put(...)";
                request3 = request;
                str3 = "pkg";
                str5 = "toString(...)";
                str7 = "";
                if (str.equals("app/meta")) {
                    String q2 = request3.q(str3);
                    if (!ManagePart.PKG.matcher(q2).matches()) {
                        JSONObject m9m = Census$$ExternalSyntheticOutline0.m9m("error", "not found", str12);
                        HttpServer.Response response15 = new HttpServer.Response();
                        response15.status = 404;
                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda015 = HttpServer.trusted;
                        response15.body = Census$$ExternalSyntheticOutline0.m(str5, m9m);
                        return response15;
                    }
                    JSONObject meta = Fleet.meta(appsApi.labels, q2);
                    HttpServer.Response response16 = new HttpServer.Response();
                    response16.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda016 = HttpServer.trusted;
                    response16.body = Census$$ExternalSyntheticOutline0.m(str5, meta);
                    return response16;
                }
                request2 = request3;
                str4 = "id";
                str10 = str19;
                obj = "recents";
                str2 = str12;
                str6 = " ";
                str8 = "apps";
                str9 = str18;
                if (z) {
                }
                return null;
            case 1129145712:
                appsApi = this;
                str3 = "pkg";
                str5 = "toString(...)";
                str7 = "";
                if (!str.equals("app/backup")) {
                    request2 = request;
                    str2 = "put(...)";
                    str4 = "id";
                    str8 = "apps";
                    str10 = str19;
                    obj = "recents";
                    str6 = " ";
                    str9 = str18;
                    if (z) {
                    }
                    return null;
                }
                String q3 = request.q(str3);
                TvShell tvShell4 = TvShell.INSTANCE;
                TvShell.pkg(q3);
                Axml$$ExternalSyntheticLambda1 axml$$ExternalSyntheticLambda1 = new Axml$$ExternalSyntheticLambda1(appsApi, appsApi.link.get(), q3, 1);
                HttpServer.Response response17 = new HttpServer.Response();
                response17.type = "application/x-tar";
                response17.length = -1L;
                response17.stream = axml$$ExternalSyntheticLambda1;
                response17.patient = true;
                response17.headers.put("Content-Disposition", "attachment; filename*=UTF-8''" + q3 + "-backup.tar");
                return response17;
            case 1366435697:
                if (str.equals("apps/report")) {
                    Words$$ExternalSyntheticLambda1 words$$ExternalSyntheticLambda1 = new Words$$ExternalSyntheticLambda1(2, StringsKt.split$default(sh("getprop ro.product.manufacturer; getprop ro.product.model; getprop ro.build.version.release; grep MemTotal /proc/meminfo; printf '\\043~\\043\\n'; pm list packages -3 -e; printf '\\043~\\043\\n'; pm list packages -s -e; printf '\\043~\\043\\n'; pm list packages -d; printf '\\043~\\043\\n'; dumpsys meminfo --oom"), new String[]{"#~#\n"}, 0, 6));
                    Words$$ExternalSyntheticLambda1 words$$ExternalSyntheticLambda12 = new Words$$ExternalSyntheticLambda1(3, words$$ExternalSyntheticLambda1);
                    String str33 = "pkg";
                    List split$default3 = StringsKt.split$default((CharSequence) words$$ExternalSyntheticLambda1.invoke(0), new String[]{"\n"}, 0, 6);
                    List<String> list4 = (List) words$$ExternalSyntheticLambda12.invoke(1);
                    JSONObject jSONObject3 = new JSONObject();
                    if (split$default3.size() <= 0) {
                        obj4 = "";
                    } else {
                        obj4 = split$default3.get(0);
                    }
                    String obj12 = StringsKt.trim((String) obj4).toString();
                    if (1 >= split$default3.size()) {
                        obj5 = "";
                    } else {
                        obj5 = split$default3.get(1);
                    }
                    JSONObject put15 = jSONObject3.put("device", StringsKt.trim(obj12 + " " + StringsKt.trim((String) obj5).toString()).toString());
                    if (2 >= split$default3.size()) {
                        obj6 = "";
                    } else {
                        obj6 = split$default3.get(2);
                    }
                    JSONObject put16 = put15.put("android", StringsKt.trim((String) obj6).toString());
                    Pattern compile3 = Pattern.compile("MemTotal:\\s+(\\d+)");
                    Intrinsics.checkNotNullExpressionValue(compile3, "compile(...)");
                    CharSequence input2 = (CharSequence) words$$ExternalSyntheticLambda1.invoke(0);
                    Intrinsics.checkNotNullParameter(input2, "input");
                    Matcher matcher = compile3.matcher(input2);
                    Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
                    MatcherMatchResult access$findNext3 = MathKt.access$findNext(matcher, 0, input2);
                    if (access$findNext3 != null && (str13 = (String) ((MatcherMatchResult$groupValues$1) access$findNext3.getGroupValues()).get(1)) != null && (longOrNull = StringsKt__StringNumberConversionsKt.toLongOrNull(str13)) != null) {
                        j3 = longOrNull.longValue();
                    } else {
                        j3 = 0;
                    }
                    JSONObject put17 = put16.put("ram_mb", j3 / 1024).put("user", new JSONArray((Collection) list4)).put("system", new JSONArray((Collection) words$$ExternalSyntheticLambda12.invoke(2))).put("disabled", new JSONArray((Collection) words$$ExternalSyntheticLambda12.invoke(3)));
                    String meminfo2 = (String) words$$ExternalSyntheticLambda1.invoke(4);
                    Intrinsics.checkNotNullParameter(meminfo2, "meminfo");
                    int indexOf$default3 = StringsKt.indexOf$default(meminfo2, "Total PSS by process:", 0, false, 6);
                    Integer valueOf = Integer.valueOf(indexOf$default3);
                    if (indexOf$default3 >= 0) {
                        num = valueOf;
                    }
                    if (num != null) {
                        indexOf$default = num.intValue();
                    } else {
                        indexOf$default = StringsKt.indexOf$default(meminfo2, "Total PSS by OOM adjustment:", 0, false, 6);
                    }
                    if (indexOf$default < 0) {
                        arrayList = emptyList;
                    } else {
                        HashMap hashMap3 = new HashMap();
                        String substring2 = meminfo2.substring(indexOf$default);
                        Intrinsics.checkNotNullExpressionValue(substring2, "substring(...)");
                        for (String str34 : CollectionsKt.drop(1, StringsKt.split$default(substring2, new String[]{"\n"}, 0, 6))) {
                            if (!StringsKt.isBlank(str34)) {
                                MatcherMatchResult access$findNext4 = MathKt.access$findNext(Census$$ExternalSyntheticOutline0.m6m("^\\s*([\\d,]+)K: ([^\\s(]+)", "compile(...)", str34, "matcher(...)"), 0, str34);
                                if (access$findNext4 != null && StringsKt.contains$default((CharSequence) ((MatcherMatchResult$groupValues$1) access$findNext4.getGroupValues()).get(2), '.')) {
                                    String str35 = (String) ((MatcherMatchResult$groupValues$1) access$findNext4.getGroupValues()).get(2);
                                    String substringBefore2 = StringsKt.substringBefore(str35, ':', str35);
                                    Integer num4 = (Integer) hashMap3.get(substringBefore2);
                                    if (num4 != null) {
                                        i4 = num4.intValue();
                                    } else {
                                        i4 = 0;
                                    }
                                    hashMap3.put(substringBefore2, Integer.valueOf((Integer.parseInt(StringsKt__StringsJVMKt.replace$default((String) ((MatcherMatchResult$groupValues$1) access$findNext4.getGroupValues()).get(1), ",", "")) / 1024) + i4));
                                }
                            } else {
                                Set entrySet3 = hashMap3.entrySet();
                                Intrinsics.checkNotNullExpressionValue(entrySet3, "<get-entries>(...)");
                                ArrayList arrayList8 = new ArrayList();
                                for (Object obj13 : entrySet3) {
                                    if (((Number) ((Map.Entry) obj13).getValue()).intValue() >= 5) {
                                        arrayList8.add(obj13);
                                    }
                                }
                                List<Map.Entry> take2 = CollectionsKt.take(CollectionsKt.sortedWith(arrayList8, new Phrases$alt$$inlined$sortedByDescending$1(4)), 25);
                                arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(take2));
                                for (Map.Entry entry2 : take2) {
                                    arrayList.add(new Pair(entry2.getKey(), entry2.getValue()));
                                }
                            }
                        }
                        Set entrySet32 = hashMap3.entrySet();
                        Intrinsics.checkNotNullExpressionValue(entrySet32, "<get-entries>(...)");
                        ArrayList arrayList82 = new ArrayList();
                        while (r1.hasNext()) {
                        }
                        List<Map.Entry> take22 = CollectionsKt.take(CollectionsKt.sortedWith(arrayList82, new Phrases$alt$$inlined$sortedByDescending$1(4)), 25);
                        arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(take22));
                        while (r1.hasNext()) {
                        }
                    }
                    ArrayList arrayList9 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList));
                    for (Pair pair : arrayList) {
                        String str36 = str33;
                        arrayList9.add(new JSONObject().put(str36, pair.first).put("mb", ((Number) pair.second).intValue()));
                        str33 = str36;
                    }
                    ?? put18 = put17.put("memory", new JSONArray((Collection) arrayList9));
                    JSONObject jSONObject4 = new JSONObject();
                    for (String str37 : list4) {
                        RemoteLabels remoteLabels5 = this.labels;
                        if (remoteLabels5 != null && (label2 = remoteLabels5.label(str37)) != null) {
                            jSONObject4.put(str37, label2);
                        }
                    }
                    JSONObject put19 = put18.put("labels", jSONObject4);
                    Intrinsics.checkNotNullExpressionValue(put19, "put(...)");
                    HttpServer.Response response18 = new HttpServer.Response();
                    response18.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda017 = HttpServer.trusted;
                    response18.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put19);
                    return response18;
                }
                break;
            default:
                request2 = request;
                str2 = "put(...)";
                str3 = "pkg";
                str4 = "id";
                obj = "recents";
                str5 = "toString(...)";
                appsApi = this;
                str6 = " ";
                str7 = "";
                str8 = "apps";
                str9 = str18;
                str10 = str19;
                if (z) {
                }
                return null;
        }
    }
}
