package dev.tvremote.core.manage;

import dev.tvremote.core.remote.Vidaa$$ExternalSyntheticLambda0;
import java.util.Comparator;
import kotlin.jvm.functions.Function1;
import kotlin.math.MathKt;

/* loaded from: classes.dex */
public final /* synthetic */ class FilesApi$$ExternalSyntheticLambda3 implements Comparator {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;

    public /* synthetic */ FilesApi$$ExternalSyntheticLambda3(int i, Object obj) {
        this.$r8$classId = i;
        this.f$0 = obj;
    }

    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        switch (this.$r8$classId) {
            case 0:
                return ((Number) ((Vidaa$$ExternalSyntheticLambda0) this.f$0).invoke(obj, obj2)).intValue();
            default:
                for (Function1 function1 : (Function1[]) this.f$0) {
                    int compareValues = MathKt.compareValues((Comparable) function1.invoke(obj), (Comparable) function1.invoke(obj2));
                    if (compareValues != 0) {
                        return compareValues;
                    }
                }
                return 0;
        }
    }
}
