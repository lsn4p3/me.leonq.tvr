package dev.tvremote.core.manage;

import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.ontv.RemoteLabels;
import dev.tvremote.core.web.HttpServer;
import dev.tvremote.update.Ed25519;
import java.io.File;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;
import org.json.JSONObject;

/* loaded from: classes.dex */
public abstract class ManagePart {
    public static final Regex DIGITS;
    public static final Pattern PKG;
    public final Ed25519.Pt core;
    public final File dir;
    public final RemoteLabels labels;
    public final AdbLink link;

    static {
        Pattern compile = Pattern.compile("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z_][A-Za-z0-9_]*)+");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        PKG = compile;
        DIGITS = new Regex("\\d+");
    }

    public ManagePart(Ed25519.Pt core) {
        Intrinsics.checkNotNullParameter(core, "core");
        this.core = core;
        this.link = (AdbLink) core.x;
        this.labels = (RemoteLabels) core.y;
        this.dir = (File) core.z;
    }

    public static JSONObject job$default(ManagePart managePart, String title, String str, String str2, Function1 function1, int i) {
        String str3 = null;
        if ((i & 2) != 0) {
            str = null;
        }
        if ((i & 4) != 0) {
            str2 = null;
        }
        if ((i & 8) == 0) {
            str3 = "setup";
        }
        Intrinsics.checkNotNullParameter(title, "title");
        return ((Jobs) managePart.core.t).job(title, str, str2, str3, function1);
    }

    public final ThreadLocal getCurrent() {
        return ((Jobs) this.core.t).current;
    }

    public final ConcurrentHashMap getStops() {
        return ((Jobs) this.core.t).stops;
    }

    public final void pipe(Adb.Stream stream, HttpServer.Stall stall) {
        Adb.Stream stream2;
        this.core.getClass();
        try {
            byte[] bArr = new byte[65536];
            while (true) {
                stream2 = stream;
                try {
                    int read = stream2.read(0L, bArr, 0, 65536);
                    if (read >= 0) {
                        stall.write(bArr, 0, read);
                        stream = stream2;
                    } else {
                        stream2.close();
                        return;
                    }
                } catch (Throwable th) {
                    th = th;
                    Throwable th2 = th;
                    stream2.close();
                    throw th2;
                }
            }
        } catch (Throwable th3) {
            th = th3;
            stream2 = stream;
        }
    }

    public abstract HttpServer.Response route(String str, boolean z, HttpServer.Request request);

    public final String sh(String cmd) {
        Intrinsics.checkNotNullParameter(cmd, "cmd");
        Ed25519.Pt pt = this.core;
        pt.getClass();
        Adb adb = ((AdbLink) pt.x).get();
        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
        return adb.shell(120000L, cmd);
    }

    public final HttpServer.Response text(long j, String cmd) {
        Intrinsics.checkNotNullParameter(cmd, "cmd");
        return this.core.text(j, cmd);
    }
}
