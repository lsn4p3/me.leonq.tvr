package dev.tvremote.core.manage;

import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final /* synthetic */ class AppsApi$$ExternalSyntheticLambda2 implements Function1 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ AppsApi f$0;

    public /* synthetic */ AppsApi$$ExternalSyntheticLambda2(AppsApi appsApi, int i) {
        this.$r8$classId = i;
        this.f$0 = appsApi;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        String it = (String) obj;
        switch (this.$r8$classId) {
            case 0:
                Intrinsics.checkNotNullParameter(it, "it");
                return this.f$0.sh(it);
            case 1:
                Intrinsics.checkNotNullParameter(it, "it");
                return this.f$0.sh(it);
            case 2:
                Intrinsics.checkNotNullParameter(it, "it");
                return this.f$0.sh(it);
            case 3:
                Intrinsics.checkNotNullParameter(it, "it");
                return this.f$0.sh(it);
            case 4:
                Intrinsics.checkNotNullParameter(it, "it");
                return this.f$0.sh(it);
            default:
                Intrinsics.checkNotNullParameter(it, "it");
                return this.f$0.sh(it);
        }
    }
}
