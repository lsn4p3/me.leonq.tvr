package dev.tvremote.core.manage;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.B64;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet$$ExternalSyntheticLambda0;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.Mdns;
import dev.tvremote.core.ontv.Axml$$ExternalSyntheticLambda1;
import dev.tvremote.core.ontv.Axml$$ExternalSyntheticLambda2;
import dev.tvremote.core.ontv.Bloat$$ExternalSyntheticLambda0;
import dev.tvremote.core.ontv.Channels;
import dev.tvremote.core.ontv.Games;
import dev.tvremote.core.ontv.Home;
import dev.tvremote.core.ontv.Home$$ExternalSyntheticLambda3;
import dev.tvremote.core.ontv.Launchers;
import dev.tvremote.core.ontv.OwnApp;
import dev.tvremote.core.ontv.RemoteLabels;
import dev.tvremote.core.ontv.Rescue;
import dev.tvremote.core.ontv.Setup;
import dev.tvremote.core.ontv.ThemeShare$Job;
import dev.tvremote.core.ontv.Wallpapers;
import dev.tvremote.core.web.HttpServer;
import dev.tvremote.home.HomeConfig;
import dev.tvremote.home.HomeQr$$ExternalSyntheticLambda0;
import dev.tvremote.home.LinkUrl;
import dev.tvremote.home.WebCheck;
import dev.tvremote.phone.WorkService;
import dev.tvremote.update.Release;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyMap;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$BooleanRef;
import kotlin.jvm.internal.Ref$IntRef;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgressionIterator;
import kotlin.ranges.IntRange;
import kotlin.text.Charsets;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.conscrypt.metrics.ConscryptStatsLog;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class HomeApi extends ManagePart {
    public volatile ThemeShare$Job shareJob;

    public static final JSONObject route$find(String str, JSONArray jSONArray) {
        int i;
        Object obj;
        if (jSONArray != null) {
            i = jSONArray.length();
        } else {
            i = 0;
        }
        IntRange until = MathKt.until(0, i);
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until));
        Iterator it = until.iterator();
        while (((IntProgressionIterator) it).hasNext) {
            int nextInt = ((IntProgressionIterator) it).nextInt();
            Intrinsics.checkNotNull(jSONArray);
            arrayList.add(jSONArray.getJSONObject(nextInt));
        }
        Iterator it2 = arrayList.iterator();
        while (true) {
            if (it2.hasNext()) {
                obj = it2.next();
                if (Intrinsics.areEqual(((JSONObject) obj).optString("id"), str)) {
                    break;
                }
            } else {
                obj = null;
                break;
            }
        }
        return (JSONObject) obj;
    }

    public final HttpServer.Response ownJob(String str, HttpServer.Request request, Function2 function2) {
        request.getLang();
        String title = "install ".concat(str);
        String concat = "own:".concat(str);
        Axml$$ExternalSyntheticLambda2 axml$$ExternalSyntheticLambda2 = new Axml$$ExternalSyntheticLambda2(1, this, function2);
        Intrinsics.checkNotNullParameter(title, "title");
        JSONObject job = ((Jobs) this.core.t).job(title, "install", str, concat, axml$$ExternalSyntheticLambda2);
        HttpServer.Response response = new HttpServer.Response();
        response.status = 200;
        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = HttpServer.trusted;
        response.body = Census$$ExternalSyntheticOutline0.m("toString(...)", job);
        return response;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:121:0x036a, code lost:
    
        if ((java.lang.System.currentTimeMillis() - r4) < 86400000) goto L145;
     */
    /* JADX WARN: Failed to find 'out' block for switch in B:2:0x0081. Please report as an issue. */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:342:0x09ef  */
    /* JADX WARN: Removed duplicated region for block: B:344:0x0a0d  */
    /* JADX WARN: Removed duplicated region for block: B:414:0x0bdd  */
    /* JADX WARN: Removed duplicated region for block: B:416:0x0c01  */
    /* JADX WARN: Type inference failed for: r0v144, types: [java.lang.Object, java.lang.Iterable] */
    /* JADX WARN: Type inference failed for: r0v55, types: [dev.tvremote.core.manage.HomeApi$$ExternalSyntheticLambda4] */
    /* JADX WARN: Type inference failed for: r5v19, types: [dev.tvremote.core.manage.HomeApi$$ExternalSyntheticLambda16] */
    @Override // dev.tvremote.core.manage.ManagePart
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final HttpServer.Response route(String str, boolean z, final HttpServer.Request request) {
        JSONObject json;
        JSONObject json2;
        JSONObject json3;
        String str2;
        final HomeApi homeApi;
        JSONObject json4;
        JSONObject json5;
        String str3;
        String concat;
        JSONObject jSONObject;
        String str4;
        JSONObject o;
        String str5;
        Object obj;
        String str6 = "stat -c %s ";
        String str7 = " 2>/dev/null";
        String str8 = ".json";
        String str9 = "name";
        String str10 = "";
        JSONObject jSONObject2 = null;
        switch (str.hashCode()) {
            case -2007513344:
                if (!str.equals("home/walls/thumb")) {
                    return null;
                }
                List list = Wallpapers.bases;
                byte[] thumb = Wallpapers.thumb(request.q("id"));
                if (thumb == null) {
                    JSONObject m9m = Census$$ExternalSyntheticOutline0.m9m("error", "not found", "put(...)");
                    HttpServer.Response response = new HttpServer.Response();
                    response.status = 404;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = HttpServer.trusted;
                    response.body = Census$$ExternalSyntheticOutline0.m("toString(...)", m9m);
                    return response;
                }
                HttpServer.Response response2 = new HttpServer.Response();
                response2.type = "image/jpeg";
                response2.body = thumb;
                return response2;
            case -2005650135:
                if (!str.equals("channels/open") || !z) {
                    return null;
                }
                OwnApp ownApp = Channels.app;
                final int i = 1;
                Function1 function1 = new Function1(this) { // from class: dev.tvremote.core.manage.HomeApi$$ExternalSyntheticLambda4
                    public final /* synthetic */ HomeApi f$0;

                    {
                        this.f$0 = this;
                    }

                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj2) {
                        String it = (String) obj2;
                        switch (i) {
                            case 0:
                                Intrinsics.checkNotNullParameter(it, "it");
                                return this.f$0.sh(it);
                            case 1:
                                Intrinsics.checkNotNullParameter(it, "it");
                                return this.f$0.sh(it);
                            case 2:
                                Intrinsics.checkNotNullParameter(it, "it");
                                return this.f$0.sh(it);
                            case 3:
                                Intrinsics.checkNotNullParameter(it, "it");
                                return this.f$0.sh(it);
                            case 4:
                                Intrinsics.checkNotNullParameter(it, "it");
                                return this.f$0.sh(it);
                            case 5:
                                Intrinsics.checkNotNullParameter(it, "it");
                                return this.f$0.sh(it);
                            case 6:
                                Intrinsics.checkNotNullParameter(it, "it");
                                return this.f$0.sh(it);
                            case 7:
                                Intrinsics.checkNotNullParameter(it, "it");
                                return this.f$0.sh(it);
                            case 8:
                                Intrinsics.checkNotNullParameter(it, "it");
                                return this.f$0.sh(it);
                            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                                Intrinsics.checkNotNullParameter(it, "it");
                                return this.f$0.sh(it);
                            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                                Intrinsics.checkNotNullParameter(it, "it");
                                return this.f$0.sh(it);
                            case 11:
                                Intrinsics.checkNotNullParameter(it, "it");
                                return this.f$0.sh(it);
                            default:
                                Intrinsics.checkNotNullParameter(it, "it");
                                return this.f$0.sh(it);
                        }
                    }
                };
                json = request.json(65536);
                String optString = json.optString("q");
                Intrinsics.checkNotNullExpressionValue(optString, "optString(...)");
                if (Channels.open(optString, function1)) {
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda02 = HttpServer.trusted;
                    byte[] bytes = WorkService.Companion.bytes("{\"ok\":true}");
                    HttpServer.Response response3 = new HttpServer.Response();
                    response3.type = "application/json; charset=utf-8";
                    response3.body = bytes;
                    return response3;
                }
                throw new IOException("channels:missing");
            case -2005624301:
                if (!str.equals("channels/play") || !z) {
                    return null;
                }
                OwnApp ownApp2 = Channels.app;
                final int i2 = 2;
                Function1 function12 = new Function1(this) { // from class: dev.tvremote.core.manage.HomeApi$$ExternalSyntheticLambda4
                    public final /* synthetic */ HomeApi f$0;

                    {
                        this.f$0 = this;
                    }

                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj2) {
                        String it = (String) obj2;
                        switch (i2) {
                            case 0:
                                Intrinsics.checkNotNullParameter(it, "it");
                                return this.f$0.sh(it);
                            case 1:
                                Intrinsics.checkNotNullParameter(it, "it");
                                return this.f$0.sh(it);
                            case 2:
                                Intrinsics.checkNotNullParameter(it, "it");
                                return this.f$0.sh(it);
                            case 3:
                                Intrinsics.checkNotNullParameter(it, "it");
                                return this.f$0.sh(it);
                            case 4:
                                Intrinsics.checkNotNullParameter(it, "it");
                                return this.f$0.sh(it);
                            case 5:
                                Intrinsics.checkNotNullParameter(it, "it");
                                return this.f$0.sh(it);
                            case 6:
                                Intrinsics.checkNotNullParameter(it, "it");
                                return this.f$0.sh(it);
                            case 7:
                                Intrinsics.checkNotNullParameter(it, "it");
                                return this.f$0.sh(it);
                            case 8:
                                Intrinsics.checkNotNullParameter(it, "it");
                                return this.f$0.sh(it);
                            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                                Intrinsics.checkNotNullParameter(it, "it");
                                return this.f$0.sh(it);
                            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                                Intrinsics.checkNotNullParameter(it, "it");
                                return this.f$0.sh(it);
                            case 11:
                                Intrinsics.checkNotNullParameter(it, "it");
                                return this.f$0.sh(it);
                            default:
                                Intrinsics.checkNotNullParameter(it, "it");
                                return this.f$0.sh(it);
                        }
                    }
                };
                json2 = request.json(65536);
                String optString2 = json2.optString("url");
                Intrinsics.checkNotNullExpressionValue(optString2, "optString(...)");
                int ordinal = Channels.playResult(optString2, function12).ordinal();
                if (ordinal != 1) {
                    if (ordinal != 2) {
                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda03 = HttpServer.trusted;
                        byte[] bytes2 = WorkService.Companion.bytes("{\"ok\":true}");
                        HttpServer.Response response4 = new HttpServer.Response();
                        response4.type = "application/json; charset=utf-8";
                        response4.body = bytes2;
                        return response4;
                    }
                    throw new IOException("channels:missing");
                }
                throw new IOException("channels:old");
            case -1998318243:
                if (!str.equals("home/web/check") || z) {
                    return null;
                }
                Regex regex = WebCheck.TITLE;
                JSONObject check$default = WebCheck.check$default(request.q("u"));
                HttpServer.Response response5 = new HttpServer.Response();
                response5.status = 200;
                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda04 = HttpServer.trusted;
                response5.body = Census$$ExternalSyntheticOutline0.m("toString(...)", check$default);
                return response5;
            case -1479794161:
                if (str.equals("home/link/open") && z) {
                    json3 = request.json(65536);
                    Regex regex2 = Home.PIN_KEY;
                    final int i3 = 8;
                    Function1 function13 = new Function1(this) { // from class: dev.tvremote.core.manage.HomeApi$$ExternalSyntheticLambda4
                        public final /* synthetic */ HomeApi f$0;

                        {
                            this.f$0 = this;
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj2) {
                            String it = (String) obj2;
                            switch (i3) {
                                case 0:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case 1:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case 2:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case 3:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case 4:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case 5:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case 6:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case 7:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case 8:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case 11:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                default:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                            }
                        }
                    };
                    String optString3 = json3.optString("url");
                    Intrinsics.checkNotNullExpressionValue(optString3, "optString(...)");
                    String optString4 = json3.optString("pkg");
                    if (StringsKt.isBlank(optString4)) {
                        optString4 = null;
                    }
                    String clean = LinkUrl.clean(optString3);
                    if (clean != null) {
                        if (optString4 == null || !Home.PKG.matches(optString4)) {
                            optString4 = null;
                        }
                        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                        String q = Mdns.q(clean);
                        if (optString4 == null) {
                            str2 = "";
                        } else {
                            str2 = " -p ".concat(optString4);
                        }
                        String str11 = (String) function13.invoke("am start -a android.intent.action.VIEW -c android.intent.category.BROWSABLE -d " + q + str2 + " 2>&1");
                        if (!StringsKt.contains(str11, "Error", false)) {
                            String lowerCase = str11.toLowerCase(Locale.ROOT);
                            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                            if (!StringsKt.contains(lowerCase, "unable to resolve", false)) {
                                JSONObject put = new JSONObject().put("ok", true);
                                Intrinsics.checkNotNullExpressionValue(put, "put(...)");
                                HttpServer.Response response6 = new HttpServer.Response();
                                response6.status = 200;
                                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda05 = HttpServer.trusted;
                                response6.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put);
                                return response6;
                            }
                        }
                        throw new IOException("pin_no_app");
                    }
                    throw new IOException("pin_bad_link");
                }
                return null;
            case -920370099:
                homeApi = this;
                if (str.equals("games/install") && z) {
                    final int i4 = 1;
                    return homeApi.ownJob("TV Games", request, new Function2(homeApi) { // from class: dev.tvremote.core.manage.HomeApi$$ExternalSyntheticLambda9
                        public final /* synthetic */ HomeApi f$0;

                        {
                            this.f$0 = homeApi;
                        }

                        @Override // kotlin.jvm.functions.Function2
                        public final Object invoke(Object obj2, Object obj3) {
                            File file;
                            switch (i4) {
                                case 0:
                                    Function0 go = (Function0) obj2;
                                    Function1 pct = (Function1) obj3;
                                    Intrinsics.checkNotNullParameter(go, "go");
                                    Intrinsics.checkNotNullParameter(pct, "pct");
                                    OwnApp ownApp3 = Channels.app;
                                    HomeApi homeApi2 = this.f$0;
                                    Adb adb = homeApi2.link.get();
                                    String lang = request.getLang();
                                    Intrinsics.checkNotNullParameter(lang, "lang");
                                    return Channels.app.install(adb, homeApi2.dir, lang, go, pct);
                                case 1:
                                    Function0 go2 = (Function0) obj2;
                                    Function1 pct2 = (Function1) obj3;
                                    Intrinsics.checkNotNullParameter(go2, "go");
                                    Intrinsics.checkNotNullParameter(pct2, "pct");
                                    HomeApi homeApi3 = this.f$0;
                                    Adb adb2 = homeApi3.link.get();
                                    String lang2 = request.getLang();
                                    Intrinsics.checkNotNullParameter(lang2, "lang");
                                    return Games.app.install(adb2, homeApi3.dir, lang2, go2, pct2);
                                default:
                                    HomeApi homeApi4 = this.f$0;
                                    HttpServer.Request request2 = request;
                                    Function0 go3 = (Function0) obj2;
                                    Function1 pct3 = (Function1) obj3;
                                    Intrinsics.checkNotNullParameter(go3, "go");
                                    Intrinsics.checkNotNullParameter(pct3, "pct");
                                    Regex regex3 = Home.PIN_KEY;
                                    Adb adb3 = homeApi4.link.get();
                                    File file2 = homeApi4.dir;
                                    String lang3 = request2.getLang();
                                    Intrinsics.checkNotNullParameter(lang3, "lang");
                                    Fleet$$ExternalSyntheticLambda0 fleet$$ExternalSyntheticLambda0 = new Fleet$$ExternalSyntheticLambda0(adb3, 8);
                                    String str12 = "";
                                    JSONObject call = Home.call("", fleet$$ExternalSyntheticLambda0, null);
                                    if (call.optBoolean("installed")) {
                                        Home.checked = null;
                                        String optString5 = call.optString("version");
                                        Intrinsics.checkNotNullExpressionValue(optString5, "optString(...)");
                                        Release latest = Home.latest(optString5);
                                        if (latest != null) {
                                            if (file2 == null) {
                                                file = new File(System.getProperty("java.io.tmpdir"));
                                            } else {
                                                file = file2;
                                            }
                                            File file3 = new File(file, ApkSigner$$ExternalSyntheticOutline0.m("tv-home-", latest.version, ".apk"));
                                            Rescue.check(file2, latest.sha256, null);
                                            try {
                                                latest.download(file3, new Home$$ExternalSyntheticLambda3(0, pct3));
                                                if (!((Boolean) go3.invoke()).booleanValue()) {
                                                    file3.delete();
                                                    return call;
                                                }
                                                boolean contains = StringsKt.contains((CharSequence) fleet$$ExternalSyntheticLambda0.invoke("dumpsys activity activities | grep -m1 -E 'topResumedActivity|mResumedActivity'"), "dev.tvremote.home/", false);
                                                String install = new Setup(adb3, file2, lang3, new Bloat$$ExternalSyntheticLambda0(3)).install(file3);
                                                Rescue.check(file2, latest.sha256, install);
                                                if (!StringsKt.contains(install, "Success", false)) {
                                                    String str13 = (String) CollectionsKt.lastOrNull(StringsKt.lines(StringsKt.trim(install).toString()));
                                                    if (str13 != null) {
                                                        str12 = str13;
                                                    }
                                                    throw new IOException("launcher:install:".concat(StringsKt.take(str12, 200)));
                                                }
                                                if (contains) {
                                                    fleet$$ExternalSyntheticLambda0.invoke("am start -a android.intent.action.MAIN -c android.intent.category.HOME >/dev/null 2>&1");
                                                }
                                                file3.delete();
                                                try {
                                                    adb3.shell(120000L, "pm grant dev.tvremote.home android.permission.ACCESS_FINE_LOCATION >/dev/null 2>&1; pm grant dev.tvremote.home android.permission.BLUETOOTH_CONNECT >/dev/null 2>&1; pm grant dev.tvremote.home android.permission.READ_TV_LISTINGS >/dev/null 2>&1; pm grant dev.tvremote.home android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1; cmd package compile -m speed -f dev.tvremote.home >/dev/null 2>&1");
                                                } catch (IOException unused) {
                                                }
                                                Home.checked = null;
                                                return Home.call("", fleet$$ExternalSyntheticLambda0, null);
                                            } catch (Throwable th) {
                                                file3.delete();
                                                throw th;
                                            }
                                        }
                                        return call;
                                    }
                                    throw new IOException("home:missing");
                            }
                        }
                    });
                }
                return null;
            case -487293851:
                homeApi = this;
                if (str.equals("home/pin") && z) {
                    Regex regex3 = Home.PIN_KEY;
                    final int i5 = 6;
                    ?? r0 = new Function1(homeApi) { // from class: dev.tvremote.core.manage.HomeApi$$ExternalSyntheticLambda4
                        public final /* synthetic */ HomeApi f$0;

                        {
                            this.f$0 = homeApi;
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj2) {
                            String it = (String) obj2;
                            switch (i5) {
                                case 0:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case 1:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case 2:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case 3:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case 4:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case 5:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case 6:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case 7:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case 8:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case 11:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                default:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                            }
                        }
                    };
                    json4 = request.json(65536);
                    JSONObject pin = Home.pin(r0, json4);
                    HttpServer.Response response7 = new HttpServer.Response();
                    response7.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda06 = HttpServer.trusted;
                    response7.body = Census$$ExternalSyntheticOutline0.m("toString(...)", pin);
                    return response7;
                }
                return null;
            case -404456711:
                homeApi = this;
                if (str.equals("home/apppic") && z) {
                    long j = request.length;
                    if (1 <= j && j < 300001) {
                        int i6 = (int) j;
                        byte[] bArr = new byte[i6];
                        int i7 = 0;
                        while (i7 < i6) {
                            int read = request.body.read(bArr, i7, i6 - i7);
                            if (read >= 0) {
                                i7 += read;
                            } else {
                                if (i7 < i6) {
                                    Regex regex4 = Home.PIN_KEY;
                                    JSONObject appPic = Home.appPic(homeApi.link.get(), request.q("pkg"), bArr);
                                    HttpServer.Response response8 = new HttpServer.Response();
                                    response8.status = 200;
                                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda07 = HttpServer.trusted;
                                    response8.body = Census$$ExternalSyntheticOutline0.m("toString(...)", appPic);
                                    return response8;
                                }
                                throw new IOException("cut");
                            }
                        }
                        if (i7 < i6) {
                        }
                    } else {
                        throw new IllegalArgumentException("photo too large");
                    }
                }
                return null;
            case -318223639:
                homeApi = this;
                if (str.equals("home/theme/share")) {
                    ThemeShare$Job themeShare$Job = homeApi.shareJob;
                    if (z) {
                        json5 = request.json(65536);
                        if (json5.optBoolean("cancel")) {
                            if (themeShare$Job != null) {
                                themeShare$Job.cancel = true;
                                HttpURLConnection httpURLConnection = themeShare$Job.conn;
                                if (httpURLConnection != null) {
                                    httpURLConnection.disconnect();
                                }
                            }
                            if (themeShare$Job == null) {
                                themeShare$Job = new ThemeShare$Job();
                            }
                            JSONObject json6 = themeShare$Job.json();
                            HttpServer.Response response9 = new HttpServer.Response();
                            response9.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda08 = HttpServer.trusted;
                            response9.body = Census$$ExternalSyntheticOutline0.m("toString(...)", json6);
                            return response9;
                        }
                        if (themeShare$Job != null && Intrinsics.areEqual(themeShare$Job.state, "run")) {
                            throw new IOException("themeshare:busy");
                        }
                        Adb adb = homeApi.link.get();
                        String optString5 = json5.optString("id");
                        Intrinsics.checkNotNullExpressionValue(optString5, "optString(...)");
                        String optString6 = json5.optString("by");
                        Intrinsics.checkNotNullExpressionValue(optString6, "optString(...)");
                        String lang = request.getLang();
                        Intrinsics.checkNotNullParameter(lang, "lang");
                        ThemeShare$Job themeShare$Job2 = new ThemeShare$Job();
                        Thread thread = new Thread(new Jobs$$ExternalSyntheticLambda0(themeShare$Job2, adb, optString5, optString6, lang, 1), "themeshare");
                        thread.setDaemon(true);
                        thread.start();
                        homeApi.shareJob = themeShare$Job2;
                        JSONObject json7 = themeShare$Job2.json();
                        HttpServer.Response response10 = new HttpServer.Response();
                        response10.status = 200;
                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda09 = HttpServer.trusted;
                        response10.body = Census$$ExternalSyntheticOutline0.m("toString(...)", json7);
                        return response10;
                    }
                    if (themeShare$Job == null) {
                        themeShare$Job = new ThemeShare$Job();
                        themeShare$Job.state = "none";
                    }
                    JSONObject json8 = themeShare$Job.json();
                    HttpServer.Response response11 = new HttpServer.Response();
                    response11.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda010 = HttpServer.trusted;
                    response11.body = Census$$ExternalSyntheticOutline0.m("toString(...)", json8);
                    return response11;
                }
                return null;
            case -298388914:
                homeApi = this;
                if (str.equals("home/photo/qr") && z) {
                    Regex regex5 = Home.PIN_KEY;
                    if (StringsKt.contains(homeApi.sh("am start -a dev.tvremote.home.PHOTO -n dev.tvremote.home/.HomeActivity 2>&1"), "Starting", false)) {
                        JSONObject put2 = new JSONObject().put("ok", true);
                        Intrinsics.checkNotNullExpressionValue(put2, "put(...)");
                        HttpServer.Response response12 = new HttpServer.Response();
                        response12.status = 200;
                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda011 = HttpServer.trusted;
                        response12.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put2);
                        return response12;
                    }
                    throw new IOException("home:photo");
                }
                return null;
            case -140851532:
                homeApi = this;
                if (str.equals("home/media") && !z) {
                    Regex regex6 = Home.PIN_KEY;
                    String mediaPath = Home.mediaPath(request.q("id"));
                    if (mediaPath != null) {
                        Adb adb2 = homeApi.link.get();
                        ConcurrentHashMap concurrentHashMap2 = Adb.ASKING;
                        String obj2 = StringsKt.trim(adb2.shell(120000L, ApkSigner$$ExternalSyntheticOutline0.m(str6, Mdns.q(mediaPath), str7))).toString();
                        if (ManagePart.DIGITS.matches(obj2)) {
                            if (!StringsKt__StringsJVMKt.endsWith(mediaPath, false, ".mp4")) {
                                str3 = "image/jpeg";
                            } else {
                                str3 = "video/mp4";
                            }
                            long parseLong = Long.parseLong(obj2);
                            Axml$$ExternalSyntheticLambda1 axml$$ExternalSyntheticLambda1 = new Axml$$ExternalSyntheticLambda1(homeApi, adb2, mediaPath, 3);
                            HttpServer.Response response13 = new HttpServer.Response();
                            response13.type = str3;
                            response13.length = parseLong;
                            response13.stream = axml$$ExternalSyntheticLambda1;
                            response13.patient = true;
                            return response13;
                        }
                        throw new IOException("home:media_missing");
                    }
                    throw new IllegalArgumentException("photo id");
                }
                return null;
            case -137980670:
                homeApi = this;
                if (str.equals("home/photo") && z) {
                    long j2 = request.length;
                    if (1 <= j2 && j2 < 6000001) {
                        int i8 = (int) j2;
                        byte[] bArr2 = new byte[i8];
                        int i9 = 0;
                        while (i9 < i8) {
                            int read2 = request.body.read(bArr2, i9, i8 - i9);
                            if (read2 >= 0) {
                                i9 += read2;
                            } else {
                                if (i9 < i8) {
                                    Regex regex7 = Home.PIN_KEY;
                                    JSONObject photo = Home.photo(homeApi.link.get(), bArr2);
                                    HttpServer.Response response14 = new HttpServer.Response();
                                    response14.status = 200;
                                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda012 = HttpServer.trusted;
                                    response14.body = Census$$ExternalSyntheticOutline0.m("toString(...)", photo);
                                    return response14;
                                }
                                throw new IOException("cut");
                            }
                        }
                        if (i9 < i8) {
                        }
                    } else {
                        throw new IllegalArgumentException("photo too large");
                    }
                }
                return null;
            case -134296423:
                homeApi = this;
                if (str.equals("home/theme") && !z) {
                    final int i10 = 5;
                    JSONObject optJSONObject = Home.call("", new Function1(homeApi) { // from class: dev.tvremote.core.manage.HomeApi$$ExternalSyntheticLambda4
                        public final /* synthetic */ HomeApi f$0;

                        {
                            this.f$0 = homeApi;
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj22) {
                            String it = (String) obj22;
                            switch (i10) {
                                case 0:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case 1:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case 2:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case 3:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case 4:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case 5:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case 6:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case 7:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case 8:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                case 11:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                                default:
                                    Intrinsics.checkNotNullParameter(it, "it");
                                    return this.f$0.sh(it);
                            }
                        }
                    }, null).optJSONObject("config");
                    if (optJSONObject != null) {
                        final String q2 = request.q("id");
                        JSONObject route$find = route$find(q2, optJSONObject.optJSONArray("themes"));
                        if (route$find == null && (route$find = route$find(q2, optJSONObject.optJSONArray("themesBuiltin"))) == null) {
                            throw new IOException("home:theme_missing");
                        }
                        List list2 = HomeConfig.PLAIN;
                        String q3 = request.q(str9);
                        if (q3.length() == 0) {
                            q3 = route$find.optString(str9);
                        }
                        Intrinsics.checkNotNullExpressionValue(q3, "ifEmpty(...)");
                        String themeName = HomeConfig.themeName(q3);
                        if (themeName.length() != 0) {
                            q2 = themeName;
                        }
                        JSONObject optJSONObject2 = route$find.optJSONObject("conf");
                        if (optJSONObject2 == null) {
                            optJSONObject2 = new JSONObject();
                        }
                        final JSONObject pickTheme = HomeConfig.pickTheme(optJSONObject2);
                        Pattern compile = Pattern.compile("[^\\p{L}\\p{N}_.\\- ()]");
                        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                        String replaceAll = compile.matcher(q2).replaceAll("_");
                        Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
                        String encode = URLEncoder.encode(replaceAll.concat(".tvtheme.json"), "UTF-8");
                        Intrinsics.checkNotNullExpressionValue(encode, "encode(...)");
                        String concat2 = "attachment; filename*=UTF-8''".concat(StringsKt__StringsJVMKt.replace$default(encode, "+", "%20"));
                        if (request.q("media").equals("1") && !Games.mediaKeys(pickTheme).isEmpty()) {
                            final Adb adb3 = homeApi.link.get();
                            final List<String> mediaKeys = Games.mediaKeys(pickTheme);
                            for (String str12 : mediaKeys) {
                                ConcurrentHashMap concurrentHashMap3 = Adb.ASKING;
                                String mediaPath2 = Home.mediaPath(str12);
                                Intrinsics.checkNotNull(mediaPath2);
                                String str13 = str6;
                                String str14 = str7;
                                String obj3 = StringsKt.trim(adb3.shell(120000L, ApkSigner$$ExternalSyntheticOutline0.m(str13, Mdns.q(mediaPath2), str14))).toString();
                                if (ManagePart.DIGITS.matches(obj3)) {
                                    if (Long.parseLong(obj3) <= 62914560) {
                                        str7 = str14;
                                        str6 = str13;
                                    } else {
                                        throw new IOException("home:media_big");
                                    }
                                } else {
                                    throw new IOException("home:media_missing");
                                }
                            }
                            HttpServer.Body body = new HttpServer.Body() { // from class: dev.tvremote.core.manage.HomeApi$$ExternalSyntheticLambda17
                                /* JADX WARN: Type inference failed for: r2v1, types: [kotlin.jvm.internal.Ref$IntRef, java.lang.Object] */
                                /* JADX WARN: Type inference failed for: r4v3, types: [kotlin.jvm.internal.Ref$BooleanRef, java.lang.Object] */
                                @Override // dev.tvremote.core.web.HttpServer.Body
                                public final void write(final HttpServer.Stall stall) {
                                    String str15;
                                    HomeApi$$ExternalSyntheticLambda1 homeApi$$ExternalSyntheticLambda1 = new HomeApi$$ExternalSyntheticLambda1(0, adb3);
                                    String str16 = q2;
                                    JSONObject jSONObject3 = pickTheme;
                                    List list3 = mediaKeys;
                                    String jSONObject4 = new JSONObject().put("tvtheme", 1).put("name", str16).put("conf", jSONObject3).toString();
                                    Intrinsics.checkNotNullExpressionValue(jSONObject4, "toString(...)");
                                    String substring = jSONObject4.substring(0, jSONObject4.length() - 1);
                                    Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
                                    Charset charset = Charsets.UTF_8;
                                    byte[] bytes3 = substring.getBytes(charset);
                                    Intrinsics.checkNotNullExpressionValue(bytes3, "getBytes(...)");
                                    stall.write(bytes3);
                                    if (!list3.isEmpty()) {
                                        byte[] bytes4 = ",\"media\":{".getBytes(charset);
                                        Intrinsics.checkNotNullExpressionValue(bytes4, "getBytes(...)");
                                        stall.write(bytes4);
                                        int i11 = 0;
                                        for (Object obj4 : list3) {
                                            int i12 = i11 + 1;
                                            if (i11 >= 0) {
                                                final String str17 = (String) obj4;
                                                if (i11 > 0) {
                                                    str15 = ",";
                                                } else {
                                                    str15 = "";
                                                }
                                                Charset charset2 = Charsets.UTF_8;
                                                byte[] bytes5 = str15.getBytes(charset2);
                                                Intrinsics.checkNotNullExpressionValue(bytes5, "getBytes(...)");
                                                stall.write(bytes5);
                                                byte[] bytes6 = (JSONObject.quote(str17) + ":\"data:").getBytes(charset2);
                                                Intrinsics.checkNotNullExpressionValue(bytes6, "getBytes(...)");
                                                stall.write(bytes6);
                                                final byte[] bArr3 = new byte[49152];
                                                final ?? obj5 = new Object();
                                                final ?? obj6 = new Object();
                                                homeApi$$ExternalSyntheticLambda1.invoke(str17, new Function2() { // from class: dev.tvremote.core.ontv.ThemeFile$$ExternalSyntheticLambda0
                                                    @Override // kotlin.jvm.functions.Function2
                                                    public final Object invoke(Object obj7, Object obj8) {
                                                        byte[] b = (byte[]) obj7;
                                                        int intValue = ((Integer) obj8).intValue();
                                                        Intrinsics.checkNotNullParameter(b, "b");
                                                        Ref$BooleanRef ref$BooleanRef = obj6;
                                                        HttpServer.Stall stall2 = stall;
                                                        Games.write$lambda$4$type(ref$BooleanRef, stall2, str17, b, intValue);
                                                        int i13 = 0;
                                                        while (i13 < intValue) {
                                                            byte[] bArr4 = bArr3;
                                                            Ref$IntRef ref$IntRef = obj5;
                                                            int min = Math.min(intValue - i13, 49152 - ref$IntRef.element);
                                                            System.arraycopy(b, i13, bArr4, ref$IntRef.element, min);
                                                            int i14 = ref$IntRef.element + min;
                                                            ref$IntRef.element = i14;
                                                            i13 += min;
                                                            if (i14 == 49152) {
                                                                byte[] bytes7 = B64.encode(bArr4).getBytes(Charsets.UTF_8);
                                                                Intrinsics.checkNotNullExpressionValue(bytes7, "getBytes(...)");
                                                                stall2.write(bytes7);
                                                                ref$IntRef.element = 0;
                                                            }
                                                        }
                                                        return Unit.INSTANCE;
                                                    }
                                                });
                                                Games.write$lambda$4$type(obj6, stall, str17, bArr3, 0);
                                                int i13 = obj5.element;
                                                if (i13 > 0) {
                                                    int[] iArr = B64.INDEX;
                                                    byte[] copyOf = Arrays.copyOf(bArr3, i13);
                                                    Intrinsics.checkNotNullExpressionValue(copyOf, "copyOf(...)");
                                                    byte[] bytes7 = B64.encode(copyOf).getBytes(charset2);
                                                    Intrinsics.checkNotNullExpressionValue(bytes7, "getBytes(...)");
                                                    stall.write(bytes7);
                                                }
                                                stall.write(34);
                                                i11 = i12;
                                            } else {
                                                CollectionsKt__CollectionsKt.throwIndexOverflow();
                                                throw null;
                                            }
                                        }
                                        stall.write(125);
                                    }
                                    stall.write(125);
                                }
                            };
                            HttpServer.Response response15 = new HttpServer.Response();
                            response15.type = "application/json; charset=utf-8";
                            response15.length = -1L;
                            response15.stream = body;
                            response15.headers.put("Content-Disposition", concat2);
                            return response15;
                        }
                        String jSONObject3 = new JSONObject().put("tvtheme", 1).put(str9, q2).put("conf", pickTheme).toString(2);
                        Intrinsics.checkNotNullExpressionValue(jSONObject3, "toString(...)");
                        byte[] bytes3 = jSONObject3.getBytes(Charsets.UTF_8);
                        Intrinsics.checkNotNullExpressionValue(bytes3, "getBytes(...)");
                        HttpServer.Response response16 = new HttpServer.Response();
                        response16.type = "application/json; charset=utf-8";
                        response16.body = bytes3;
                        response16.headers.put("Content-Disposition", concat2);
                        return response16;
                    }
                    throw new IOException("home:missing");
                }
                return null;
            case -132420789:
                if (str.equals("home/video") && z) {
                    final long j3 = request.length;
                    if (1 <= j3 && j3 < 209715201) {
                        Regex regex8 = Home.PIN_KEY;
                        JSONObject video = Home.video(this.link.get(), request.q(str9), j3, new Function1() { // from class: dev.tvremote.core.manage.HomeApi$$ExternalSyntheticLambda16
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj4) {
                                Adb.Stream s = (Adb.Stream) obj4;
                                Intrinsics.checkNotNullParameter(s, "s");
                                byte[] bArr3 = new byte[65536];
                                long j4 = j3;
                                while (j4 > 0) {
                                    int read3 = request.body.read(bArr3, 0, (int) Math.min(65536, j4));
                                    if (read3 >= 0) {
                                        s.write(read3, bArr3);
                                        j4 -= read3;
                                    } else {
                                        throw new IOException("cut");
                                    }
                                }
                                return Unit.INSTANCE;
                            }
                        });
                        HttpServer.Response response17 = new HttpServer.Response();
                        response17.status = 200;
                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda013 = HttpServer.trusted;
                        response17.body = Census$$ExternalSyntheticOutline0.m("toString(...)", video);
                        return response17;
                    }
                    throw new IllegalArgumentException("video size");
                }
                return null;
            case -131727687:
                if (str.equals("home/walls")) {
                    if (!z) {
                        Wallpapers.Gallery g = Wallpapers.fetch();
                        Intrinsics.checkNotNullParameter(g, "g");
                        JSONObject jSONObject4 = new JSONObject();
                        ArrayList arrayList = g.walls;
                        ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList));
                        Iterator it = arrayList.iterator();
                        while (it.hasNext()) {
                            Wallpapers.Wall wall = (Wallpapers.Wall) it.next();
                            String str15 = str9;
                            arrayList2.add(new JSONObject().put("id", wall.id).put(str15, new JSONObject(wall.name)).put("credit", wall.credit).put("source", wall.source).put("license", wall.license).put("kb", (wall.bytes + 512) / 1024).put("thumb", "/api/home/walls/thumb?id=".concat(wall.id)));
                            it = it;
                            str9 = str15;
                            str10 = str10;
                        }
                        String str16 = str10;
                        String str17 = str9;
                        JSONObject put3 = jSONObject4.put("walls", new JSONArray((Collection) arrayList2));
                        ?? r02 = g.links;
                        ArrayList arrayList3 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(r02));
                        Iterator it2 = r02.iterator();
                        while (it2.hasNext()) {
                            Wallpapers.Link link = (Wallpapers.Link) it2.next();
                            Iterator it3 = it2;
                            JSONObject put4 = new JSONObject().put("id", link.id).put("kind", link.kind).put(str17, new JSONObject(link.name)).put("url", link.url).put("credit", link.credit).put("source", link.source).put("license", link.license).put("fade", link.fade);
                            if (link.thumb.length() == 0) {
                                concat = str16;
                            } else {
                                concat = "/api/home/walls/thumb?id=".concat(link.id);
                            }
                            arrayList3.add(put4.put("thumb", concat));
                            it2 = it3;
                        }
                        JSONObject put5 = put3.put("links", new JSONArray((Collection) arrayList3));
                        Intrinsics.checkNotNullExpressionValue(put5, "put(...)");
                        HttpServer.Response response18 = new HttpServer.Response();
                        response18.status = 200;
                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda014 = HttpServer.trusted;
                        response18.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put5);
                        return response18;
                    }
                    return null;
                }
                return null;
            case 3208415:
                if (str.equals("home")) {
                    Regex regex9 = Home.PIN_KEY;
                    final int i11 = 0;
                    Function1 function14 = new Function1(this) { // from class: dev.tvremote.core.manage.HomeApi$$ExternalSyntheticLambda4
                        public final /* synthetic */ HomeApi f$0;

                        {
                            this.f$0 = this;
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj22) {
                            String it4 = (String) obj22;
                            switch (i11) {
                                case 0:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 1:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 2:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 3:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 4:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 5:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 6:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 7:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 8:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 11:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                default:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                            }
                        }
                    };
                    if (z) {
                        jSONObject2 = request.json(65536);
                    }
                    if (!z && request.q("thumbs").equals("1")) {
                        str10 = "--ez thumbs true";
                    }
                    JSONObject call = Home.call(str10, function14, jSONObject2);
                    RemoteLabels remoteLabels = this.labels;
                    if (remoteLabels != null) {
                        remoteLabels.own = Home.names(call.optJSONObject("config"));
                    }
                    HttpServer.Response response19 = new HttpServer.Response();
                    response19.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda015 = HttpServer.trusted;
                    response19.body = Census$$ExternalSyntheticOutline0.m("toString(...)", call);
                    return response19;
                }
                return null;
            case 98120385:
                if (str.equals("games") && !z) {
                    final int i12 = 3;
                    JSONObject state = Games.app.state(new Function1(this) { // from class: dev.tvremote.core.manage.HomeApi$$ExternalSyntheticLambda4
                        public final /* synthetic */ HomeApi f$0;

                        {
                            this.f$0 = this;
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj22) {
                            String it4 = (String) obj22;
                            switch (i12) {
                                case 0:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 1:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 2:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 3:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 4:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 5:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 6:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 7:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 8:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 11:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                default:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                            }
                        }
                    });
                    HttpServer.Response response20 = new HttpServer.Response();
                    response20.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda016 = HttpServer.trusted;
                    response20.body = Census$$ExternalSyntheticOutline0.m("toString(...)", state);
                    return response20;
                }
                return null;
            case 167754745:
                if (str.equals("home/update") && z) {
                    final int i13 = 2;
                    return ownJob("TV Home", request, new Function2(this) { // from class: dev.tvremote.core.manage.HomeApi$$ExternalSyntheticLambda9
                        public final /* synthetic */ HomeApi f$0;

                        {
                            this.f$0 = this;
                        }

                        @Override // kotlin.jvm.functions.Function2
                        public final Object invoke(Object obj22, Object obj32) {
                            File file;
                            switch (i13) {
                                case 0:
                                    Function0 go = (Function0) obj22;
                                    Function1 pct = (Function1) obj32;
                                    Intrinsics.checkNotNullParameter(go, "go");
                                    Intrinsics.checkNotNullParameter(pct, "pct");
                                    OwnApp ownApp3 = Channels.app;
                                    HomeApi homeApi2 = this.f$0;
                                    Adb adb4 = homeApi2.link.get();
                                    String lang2 = request.getLang();
                                    Intrinsics.checkNotNullParameter(lang2, "lang");
                                    return Channels.app.install(adb4, homeApi2.dir, lang2, go, pct);
                                case 1:
                                    Function0 go2 = (Function0) obj22;
                                    Function1 pct2 = (Function1) obj32;
                                    Intrinsics.checkNotNullParameter(go2, "go");
                                    Intrinsics.checkNotNullParameter(pct2, "pct");
                                    HomeApi homeApi3 = this.f$0;
                                    Adb adb22 = homeApi3.link.get();
                                    String lang22 = request.getLang();
                                    Intrinsics.checkNotNullParameter(lang22, "lang");
                                    return Games.app.install(adb22, homeApi3.dir, lang22, go2, pct2);
                                default:
                                    HomeApi homeApi4 = this.f$0;
                                    HttpServer.Request request2 = request;
                                    Function0 go3 = (Function0) obj22;
                                    Function1 pct3 = (Function1) obj32;
                                    Intrinsics.checkNotNullParameter(go3, "go");
                                    Intrinsics.checkNotNullParameter(pct3, "pct");
                                    Regex regex32 = Home.PIN_KEY;
                                    Adb adb32 = homeApi4.link.get();
                                    File file2 = homeApi4.dir;
                                    String lang3 = request2.getLang();
                                    Intrinsics.checkNotNullParameter(lang3, "lang");
                                    Fleet$$ExternalSyntheticLambda0 fleet$$ExternalSyntheticLambda0 = new Fleet$$ExternalSyntheticLambda0(adb32, 8);
                                    String str122 = "";
                                    JSONObject call2 = Home.call("", fleet$$ExternalSyntheticLambda0, null);
                                    if (call2.optBoolean("installed")) {
                                        Home.checked = null;
                                        String optString52 = call2.optString("version");
                                        Intrinsics.checkNotNullExpressionValue(optString52, "optString(...)");
                                        Release latest = Home.latest(optString52);
                                        if (latest != null) {
                                            if (file2 == null) {
                                                file = new File(System.getProperty("java.io.tmpdir"));
                                            } else {
                                                file = file2;
                                            }
                                            File file3 = new File(file, ApkSigner$$ExternalSyntheticOutline0.m("tv-home-", latest.version, ".apk"));
                                            Rescue.check(file2, latest.sha256, null);
                                            try {
                                                latest.download(file3, new Home$$ExternalSyntheticLambda3(0, pct3));
                                                if (!((Boolean) go3.invoke()).booleanValue()) {
                                                    file3.delete();
                                                    return call2;
                                                }
                                                boolean contains = StringsKt.contains((CharSequence) fleet$$ExternalSyntheticLambda0.invoke("dumpsys activity activities | grep -m1 -E 'topResumedActivity|mResumedActivity'"), "dev.tvremote.home/", false);
                                                String install = new Setup(adb32, file2, lang3, new Bloat$$ExternalSyntheticLambda0(3)).install(file3);
                                                Rescue.check(file2, latest.sha256, install);
                                                if (!StringsKt.contains(install, "Success", false)) {
                                                    String str132 = (String) CollectionsKt.lastOrNull(StringsKt.lines(StringsKt.trim(install).toString()));
                                                    if (str132 != null) {
                                                        str122 = str132;
                                                    }
                                                    throw new IOException("launcher:install:".concat(StringsKt.take(str122, 200)));
                                                }
                                                if (contains) {
                                                    fleet$$ExternalSyntheticLambda0.invoke("am start -a android.intent.action.MAIN -c android.intent.category.HOME >/dev/null 2>&1");
                                                }
                                                file3.delete();
                                                try {
                                                    adb32.shell(120000L, "pm grant dev.tvremote.home android.permission.ACCESS_FINE_LOCATION >/dev/null 2>&1; pm grant dev.tvremote.home android.permission.BLUETOOTH_CONNECT >/dev/null 2>&1; pm grant dev.tvremote.home android.permission.READ_TV_LISTINGS >/dev/null 2>&1; pm grant dev.tvremote.home android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1; cmd package compile -m speed -f dev.tvremote.home >/dev/null 2>&1");
                                                } catch (IOException unused) {
                                                }
                                                Home.checked = null;
                                                return Home.call("", fleet$$ExternalSyntheticLambda0, null);
                                            } catch (Throwable th) {
                                                file3.delete();
                                                throw th;
                                            }
                                        }
                                        return call2;
                                    }
                                    throw new IOException("home:missing");
                            }
                        }
                    });
                }
                return null;
            case 187741788:
                if (str.equals("channels/install") && z) {
                    final int i14 = 0;
                    return ownJob("TV Channels", request, new Function2(this) { // from class: dev.tvremote.core.manage.HomeApi$$ExternalSyntheticLambda9
                        public final /* synthetic */ HomeApi f$0;

                        {
                            this.f$0 = this;
                        }

                        @Override // kotlin.jvm.functions.Function2
                        public final Object invoke(Object obj22, Object obj32) {
                            File file;
                            switch (i14) {
                                case 0:
                                    Function0 go = (Function0) obj22;
                                    Function1 pct = (Function1) obj32;
                                    Intrinsics.checkNotNullParameter(go, "go");
                                    Intrinsics.checkNotNullParameter(pct, "pct");
                                    OwnApp ownApp3 = Channels.app;
                                    HomeApi homeApi2 = this.f$0;
                                    Adb adb4 = homeApi2.link.get();
                                    String lang2 = request.getLang();
                                    Intrinsics.checkNotNullParameter(lang2, "lang");
                                    return Channels.app.install(adb4, homeApi2.dir, lang2, go, pct);
                                case 1:
                                    Function0 go2 = (Function0) obj22;
                                    Function1 pct2 = (Function1) obj32;
                                    Intrinsics.checkNotNullParameter(go2, "go");
                                    Intrinsics.checkNotNullParameter(pct2, "pct");
                                    HomeApi homeApi3 = this.f$0;
                                    Adb adb22 = homeApi3.link.get();
                                    String lang22 = request.getLang();
                                    Intrinsics.checkNotNullParameter(lang22, "lang");
                                    return Games.app.install(adb22, homeApi3.dir, lang22, go2, pct2);
                                default:
                                    HomeApi homeApi4 = this.f$0;
                                    HttpServer.Request request2 = request;
                                    Function0 go3 = (Function0) obj22;
                                    Function1 pct3 = (Function1) obj32;
                                    Intrinsics.checkNotNullParameter(go3, "go");
                                    Intrinsics.checkNotNullParameter(pct3, "pct");
                                    Regex regex32 = Home.PIN_KEY;
                                    Adb adb32 = homeApi4.link.get();
                                    File file2 = homeApi4.dir;
                                    String lang3 = request2.getLang();
                                    Intrinsics.checkNotNullParameter(lang3, "lang");
                                    Fleet$$ExternalSyntheticLambda0 fleet$$ExternalSyntheticLambda0 = new Fleet$$ExternalSyntheticLambda0(adb32, 8);
                                    String str122 = "";
                                    JSONObject call2 = Home.call("", fleet$$ExternalSyntheticLambda0, null);
                                    if (call2.optBoolean("installed")) {
                                        Home.checked = null;
                                        String optString52 = call2.optString("version");
                                        Intrinsics.checkNotNullExpressionValue(optString52, "optString(...)");
                                        Release latest = Home.latest(optString52);
                                        if (latest != null) {
                                            if (file2 == null) {
                                                file = new File(System.getProperty("java.io.tmpdir"));
                                            } else {
                                                file = file2;
                                            }
                                            File file3 = new File(file, ApkSigner$$ExternalSyntheticOutline0.m("tv-home-", latest.version, ".apk"));
                                            Rescue.check(file2, latest.sha256, null);
                                            try {
                                                latest.download(file3, new Home$$ExternalSyntheticLambda3(0, pct3));
                                                if (!((Boolean) go3.invoke()).booleanValue()) {
                                                    file3.delete();
                                                    return call2;
                                                }
                                                boolean contains = StringsKt.contains((CharSequence) fleet$$ExternalSyntheticLambda0.invoke("dumpsys activity activities | grep -m1 -E 'topResumedActivity|mResumedActivity'"), "dev.tvremote.home/", false);
                                                String install = new Setup(adb32, file2, lang3, new Bloat$$ExternalSyntheticLambda0(3)).install(file3);
                                                Rescue.check(file2, latest.sha256, install);
                                                if (!StringsKt.contains(install, "Success", false)) {
                                                    String str132 = (String) CollectionsKt.lastOrNull(StringsKt.lines(StringsKt.trim(install).toString()));
                                                    if (str132 != null) {
                                                        str122 = str132;
                                                    }
                                                    throw new IOException("launcher:install:".concat(StringsKt.take(str122, 200)));
                                                }
                                                if (contains) {
                                                    fleet$$ExternalSyntheticLambda0.invoke("am start -a android.intent.action.MAIN -c android.intent.category.HOME >/dev/null 2>&1");
                                                }
                                                file3.delete();
                                                try {
                                                    adb32.shell(120000L, "pm grant dev.tvremote.home android.permission.ACCESS_FINE_LOCATION >/dev/null 2>&1; pm grant dev.tvremote.home android.permission.BLUETOOTH_CONNECT >/dev/null 2>&1; pm grant dev.tvremote.home android.permission.READ_TV_LISTINGS >/dev/null 2>&1; pm grant dev.tvremote.home android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1; cmd package compile -m speed -f dev.tvremote.home >/dev/null 2>&1");
                                                } catch (IOException unused) {
                                                }
                                                Home.checked = null;
                                                return Home.call("", fleet$$ExternalSyntheticLambda0, null);
                                            } catch (Throwable th) {
                                                file3.delete();
                                                throw th;
                                            }
                                        }
                                        return call2;
                                    }
                                    throw new IOException("home:missing");
                            }
                        }
                    });
                }
                return null;
            case 666543203:
                if (str.equals("channels/counts") && !z) {
                    JSONObject jSONObject5 = new JSONObject();
                    OwnApp ownApp3 = Channels.app;
                    Map counts = Channels.counts();
                    if (counts == null) {
                        counts = EmptyMap.INSTANCE;
                    }
                    JSONObject put6 = jSONObject5.put("counts", new JSONObject(counts));
                    Intrinsics.checkNotNullExpressionValue(put6, "put(...)");
                    HttpServer.Response response21 = new HttpServer.Response();
                    response21.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda017 = HttpServer.trusted;
                    response21.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put6);
                    return response21;
                }
                return null;
            case 731965139:
                if (str.equals("channels/export") && !z) {
                    final int i15 = 11;
                    JSONObject optJSONObject3 = Channels.manage$default(new Function1(this) { // from class: dev.tvremote.core.manage.HomeApi$$ExternalSyntheticLambda4
                        public final /* synthetic */ HomeApi f$0;

                        {
                            this.f$0 = this;
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj22) {
                            String it4 = (String) obj22;
                            switch (i15) {
                                case 0:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 1:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 2:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 3:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 4:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 5:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 6:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 7:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 8:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 11:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                default:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                            }
                        }
                    }, null, null, false, false, null, 60).optJSONObject("export");
                    if (optJSONObject3 != null) {
                        String jSONObject6 = optJSONObject3.toString(2);
                        Intrinsics.checkNotNullExpressionValue(jSONObject6, "toString(...)");
                        byte[] bytes4 = jSONObject6.getBytes(Charsets.UTF_8);
                        Intrinsics.checkNotNullExpressionValue(bytes4, "getBytes(...)");
                        HttpServer.Response response22 = new HttpServer.Response();
                        response22.type = "application/json; charset=utf-8";
                        response22.body = bytes4;
                        String m = ApkSigner$$ExternalSyntheticOutline0.m("tvchannels-groups-", optJSONObject3.optString("date"), str8);
                        response22.headers.put("Content-Disposition", Census$$ExternalSyntheticOutline0.m("attachment; filename=\"", m, "\"; filename*=UTF-8''", m));
                        return response22;
                    }
                    throw new IOException("channels:missing");
                }
                return null;
            case 836323012:
                if (str.equals("channels/import") && z) {
                    OwnApp ownApp4 = Channels.app;
                    final int i16 = 12;
                    JSONObject manage$default = Channels.manage$default(new Function1(this) { // from class: dev.tvremote.core.manage.HomeApi$$ExternalSyntheticLambda4
                        public final /* synthetic */ HomeApi f$0;

                        {
                            this.f$0 = this;
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj22) {
                            String it4 = (String) obj22;
                            switch (i16) {
                                case 0:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 1:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 2:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 3:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 4:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 5:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 6:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 7:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 8:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 11:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                default:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                            }
                        }
                    }, null, null, false, false, request.json(65536), 92);
                    HttpServer.Response response23 = new HttpServer.Response();
                    response23.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda018 = HttpServer.trusted;
                    response23.body = Census$$ExternalSyntheticOutline0.m("toString(...)", manage$default);
                    return response23;
                }
                return null;
            case 939683972:
                if (str.equals("channels/manage")) {
                    OwnApp ownApp5 = Channels.app;
                    final int i17 = 10;
                    Function1 function15 = new Function1(this) { // from class: dev.tvremote.core.manage.HomeApi$$ExternalSyntheticLambda4
                        public final /* synthetic */ HomeApi f$0;

                        {
                            this.f$0 = this;
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj22) {
                            String it4 = (String) obj22;
                            switch (i17) {
                                case 0:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 1:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 2:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 3:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 4:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 5:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 6:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 7:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 8:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 11:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                default:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                            }
                        }
                    };
                    if (z) {
                        jSONObject = request.json(65536);
                    } else {
                        jSONObject = null;
                    }
                    String q4 = request.q("cc");
                    if (q4.length() == 0) {
                        str4 = null;
                    } else {
                        str4 = q4;
                    }
                    JSONObject manage$default2 = Channels.manage$default(function15, jSONObject, str4, request.q("fresh").equals("1"), request.q("countries").equals("1"), null, 96);
                    HttpServer.Response response24 = new HttpServer.Response();
                    response24.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda019 = HttpServer.trusted;
                    response24.body = Census$$ExternalSyntheticOutline0.m("toString(...)", manage$default2);
                    return response24;
                }
                return null;
            case 1010678748:
                if (str.equals("home/photo/drop") && z) {
                    Regex regex10 = Home.PIN_KEY;
                    Adb adb4 = this.link.get();
                    String optString7 = request.json(65536).optString("id");
                    Intrinsics.checkNotNullExpressionValue(optString7, "optString(...)");
                    if (!HomeConfig.isPhoto(optString7) && !HomeConfig.isVideo(optString7)) {
                        throw new IllegalArgumentException("photo id");
                    }
                    JSONObject call2 = Home.call("--es drop ".concat(optString7), new Fleet$$ExternalSyntheticLambda0(adb4, 10), null);
                    HttpServer.Response response25 = new HttpServer.Response();
                    response25.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda020 = HttpServer.trusted;
                    response25.body = Census$$ExternalSyntheticOutline0.m("toString(...)", call2);
                    return response25;
                }
                return null;
            case 1017575493:
                if (str.equals("games/pad") && !z) {
                    JSONObject jSONObject7 = new JSONObject();
                    final int i18 = 4;
                    String pad = Games.pad(this.link.host, new Function1(this) { // from class: dev.tvremote.core.manage.HomeApi$$ExternalSyntheticLambda4
                        public final /* synthetic */ HomeApi f$0;

                        {
                            this.f$0 = this;
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj22) {
                            String it4 = (String) obj22;
                            switch (i18) {
                                case 0:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 1:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 2:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 3:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 4:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 5:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 6:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 7:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 8:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                case 11:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                                default:
                                    Intrinsics.checkNotNullParameter(it4, "it");
                                    return this.f$0.sh(it4);
                            }
                        }
                    });
                    if (pad != null) {
                        str10 = pad;
                    }
                    JSONObject put7 = jSONObject7.put("url", str10);
                    Intrinsics.checkNotNullExpressionValue(put7, "put(...)");
                    HttpServer.Response response26 = new HttpServer.Response();
                    response26.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda021 = HttpServer.trusted;
                    response26.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put7);
                    return response26;
                }
                return null;
            case 1364357563:
                if (str.equals("channels/categories") && !z) {
                    OwnApp ownApp6 = Channels.app;
                    String q5 = request.q("cc");
                    Pattern compile2 = Pattern.compile("[a-z]{2}");
                    Intrinsics.checkNotNullExpressionValue(compile2, "compile(...)");
                    if (!compile2.matcher(q5).matches()) {
                        o = new JSONObject();
                    } else {
                        ConcurrentHashMap concurrentHashMap4 = Channels.cats;
                        Pair pair = (Pair) concurrentHashMap4.get(q5);
                        if (pair != null) {
                            long longValue = ((Number) pair.first).longValue();
                            o = (JSONObject) pair.second;
                            break;
                        }
                        Iterator it4 = Channels.CATS.iterator();
                        while (true) {
                            if (it4.hasNext()) {
                                String str18 = (String) it4.next();
                                try {
                                    StringBuilder sb = new StringBuilder();
                                    sb.append(str18);
                                    sb.append(q5);
                                    str5 = str8;
                                    try {
                                        sb.append(str5);
                                        InputStream fetch = Channels.fetch(sb.toString());
                                        try {
                                            byte[] readBytes = MathKt.readBytes(fetch);
                                            fetch.close();
                                            o = new JSONObject(new String(readBytes, Charsets.UTF_8));
                                            concurrentHashMap4.put(q5, new Pair(Long.valueOf(System.currentTimeMillis()), o));
                                        } finally {
                                            try {
                                                break;
                                            } catch (Throwable th) {
                                            }
                                        }
                                    } catch (IOException e) {
                                        e = e;
                                        if (!Intrinsics.areEqual(e.getMessage(), "HTTP 404")) {
                                            str8 = str5;
                                        } else {
                                            concurrentHashMap4.put(q5, new Pair(Long.valueOf(System.currentTimeMillis()), new JSONObject()));
                                            o = new JSONObject();
                                            Intrinsics.checkNotNullParameter(o, "o");
                                            HttpServer.Response response27 = new HttpServer.Response();
                                            response27.status = 200;
                                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda022 = HttpServer.trusted;
                                            response27.body = Census$$ExternalSyntheticOutline0.m("toString(...)", o);
                                            return response27;
                                        }
                                    } catch (Exception unused) {
                                        str8 = str5;
                                    }
                                } catch (IOException e2) {
                                    e = e2;
                                    str5 = str8;
                                } catch (Exception unused2) {
                                    str5 = str8;
                                }
                            } else {
                                Pair pair2 = (Pair) concurrentHashMap4.get(q5);
                                if (pair2 == null || (o = (JSONObject) pair2.second) == null) {
                                    o = new JSONObject();
                                }
                            }
                            str8 = str5;
                        }
                    }
                    Intrinsics.checkNotNullParameter(o, "o");
                    HttpServer.Response response272 = new HttpServer.Response();
                    response272.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0222 = HttpServer.trusted;
                    response272.body = Census$$ExternalSyntheticOutline0.m("toString(...)", o);
                    return response272;
                }
                return null;
            case 1432626128:
                if (str.equals("channels") && !z) {
                    OwnApp ownApp7 = Channels.app;
                    final int i19 = 9;
                    JSONObject state2 = Channels.app.state(new Function1(this) { // from class: dev.tvremote.core.manage.HomeApi$$ExternalSyntheticLambda4
                        public final /* synthetic */ HomeApi f$0;

                        {
                            this.f$0 = this;
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj22) {
                            String it42 = (String) obj22;
                            switch (i19) {
                                case 0:
                                    Intrinsics.checkNotNullParameter(it42, "it");
                                    return this.f$0.sh(it42);
                                case 1:
                                    Intrinsics.checkNotNullParameter(it42, "it");
                                    return this.f$0.sh(it42);
                                case 2:
                                    Intrinsics.checkNotNullParameter(it42, "it");
                                    return this.f$0.sh(it42);
                                case 3:
                                    Intrinsics.checkNotNullParameter(it42, "it");
                                    return this.f$0.sh(it42);
                                case 4:
                                    Intrinsics.checkNotNullParameter(it42, "it");
                                    return this.f$0.sh(it42);
                                case 5:
                                    Intrinsics.checkNotNullParameter(it42, "it");
                                    return this.f$0.sh(it42);
                                case 6:
                                    Intrinsics.checkNotNullParameter(it42, "it");
                                    return this.f$0.sh(it42);
                                case 7:
                                    Intrinsics.checkNotNullParameter(it42, "it");
                                    return this.f$0.sh(it42);
                                case 8:
                                    Intrinsics.checkNotNullParameter(it42, "it");
                                    return this.f$0.sh(it42);
                                case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                                    Intrinsics.checkNotNullParameter(it42, "it");
                                    return this.f$0.sh(it42);
                                case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                                    Intrinsics.checkNotNullParameter(it42, "it");
                                    return this.f$0.sh(it42);
                                case 11:
                                    Intrinsics.checkNotNullParameter(it42, "it");
                                    return this.f$0.sh(it42);
                                default:
                                    Intrinsics.checkNotNullParameter(it42, "it");
                                    return this.f$0.sh(it42);
                            }
                        }
                    });
                    HttpServer.Response response28 = new HttpServer.Response();
                    response28.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda023 = HttpServer.trusted;
                    response28.body = Census$$ExternalSyntheticOutline0.m("toString(...)", state2);
                    return response28;
                }
                return null;
            case 1480053976:
                if (str.equals("games/open") && z) {
                    String sh = sh("appops set dev.tvremote.games SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1; am start -n dev.tvremote.games/.LibraryActivity 2>&1");
                    if (!StringsKt.contains(sh, "Error", false) && !StringsKt.contains(sh, "does not exist", true) && !StringsKt.contains(sh, "unable to resolve", true)) {
                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda024 = HttpServer.trusted;
                        byte[] bytes5 = WorkService.Companion.bytes("{\"ok\":true}");
                        HttpServer.Response response29 = new HttpServer.Response();
                        response29.type = "application/json; charset=utf-8";
                        response29.body = bytes5;
                        return response29;
                    }
                    throw new IOException("games:missing");
                }
                return null;
            case 1877199286:
                if (str.equals("youtube/open") && z) {
                    Regex regex11 = Home.PIN_KEY;
                    String optString8 = request.json(65536).optString("url");
                    Intrinsics.checkNotNullExpressionValue(optString8, "optString(...)");
                    String youtubeUrl = Home.youtubeUrl(optString8);
                    if (youtubeUrl != null) {
                        ConcurrentHashMap concurrentHashMap5 = Adb.ASKING;
                        String it5 = "cmd package query-activities --brief -a android.intent.action.VIEW -c android.intent.category.BROWSABLE -d " + Mdns.q(youtubeUrl) + " 2>&1; echo '#~#'; cmd package query-activities --brief -a android.intent.action.VIEW -c android.intent.category.BROWSABLE -d https://example.com/ 2>&1";
                        Intrinsics.checkNotNullParameter(it5, "it");
                        String sh2 = sh(it5);
                        if (!StringsKt.isBlank(sh2)) {
                            List queryPackages$shared_release = Home.queryPackages$shared_release(StringsKt.substringBefore(sh2, "#~#", sh2));
                            List queryPackages$shared_release2 = Home.queryPackages$shared_release(StringsKt.substringAfter(sh2, "#~#", ""));
                            ArrayList arrayList4 = new ArrayList();
                            for (Object obj4 : queryPackages$shared_release) {
                                String str19 = (String) obj4;
                                if (!queryPackages$shared_release2.contains(str19) && !Home.NOT_YT.containsMatchIn(str19)) {
                                    arrayList4.add(obj4);
                                }
                            }
                            Iterator it6 = arrayList4.iterator();
                            while (true) {
                                if (it6.hasNext()) {
                                    obj = it6.next();
                                    if (Intrinsics.areEqual((String) obj, null)) {
                                    }
                                } else {
                                    obj = null;
                                }
                            }
                            String str20 = (String) obj;
                            if (str20 == null) {
                                Iterator it7 = arrayList4.iterator();
                                while (true) {
                                    if (it7.hasNext()) {
                                        Object next = it7.next();
                                        if (Intrinsics.areEqual((String) next, "com.google.android.youtube.tv")) {
                                            jSONObject2 = next;
                                        }
                                    }
                                }
                                str20 = (String) jSONObject2;
                                if (str20 == null) {
                                    str20 = (String) CollectionsKt.firstOrNull(arrayList4);
                                }
                            }
                            if (str20 != null) {
                                ConcurrentHashMap concurrentHashMap6 = Adb.ASKING;
                                String it8 = Census$$ExternalSyntheticOutline0.m("am start -a android.intent.action.VIEW -d ", Mdns.q(youtubeUrl), " -p ", str20, " 2>&1");
                                Intrinsics.checkNotNullParameter(it8, "it");
                                String sh3 = sh(it8);
                                if (!StringsKt.contains(sh3, "Error", false)) {
                                    String lowerCase2 = sh3.toLowerCase(Locale.ROOT);
                                    Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
                                    if (!StringsKt.contains(lowerCase2, "unable to resolve", false)) {
                                        JSONObject put8 = new JSONObject().put("ok", true);
                                        Intrinsics.checkNotNullExpressionValue(put8, "put(...)");
                                        HttpServer.Response response30 = new HttpServer.Response();
                                        response30.status = 200;
                                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda025 = HttpServer.trusted;
                                        response30.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put8);
                                        return response30;
                                    }
                                }
                                throw new IOException("pin_no_app");
                            }
                            throw new IOException("pin_no_app");
                        }
                        throw new IOException("not connected");
                    }
                    throw new IOException("pin_bad_link");
                }
                return null;
            case 2073640746:
                if (str.equals("home/link") && z) {
                    Regex regex12 = Home.PIN_KEY;
                    final int i20 = 7;
                    Function1 function16 = new Function1(this) { // from class: dev.tvremote.core.manage.HomeApi$$ExternalSyntheticLambda4
                        public final /* synthetic */ HomeApi f$0;

                        {
                            this.f$0 = this;
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj22) {
                            String it42 = (String) obj22;
                            switch (i20) {
                                case 0:
                                    Intrinsics.checkNotNullParameter(it42, "it");
                                    return this.f$0.sh(it42);
                                case 1:
                                    Intrinsics.checkNotNullParameter(it42, "it");
                                    return this.f$0.sh(it42);
                                case 2:
                                    Intrinsics.checkNotNullParameter(it42, "it");
                                    return this.f$0.sh(it42);
                                case 3:
                                    Intrinsics.checkNotNullParameter(it42, "it");
                                    return this.f$0.sh(it42);
                                case 4:
                                    Intrinsics.checkNotNullParameter(it42, "it");
                                    return this.f$0.sh(it42);
                                case 5:
                                    Intrinsics.checkNotNullParameter(it42, "it");
                                    return this.f$0.sh(it42);
                                case 6:
                                    Intrinsics.checkNotNullParameter(it42, "it");
                                    return this.f$0.sh(it42);
                                case 7:
                                    Intrinsics.checkNotNullParameter(it42, "it");
                                    return this.f$0.sh(it42);
                                case 8:
                                    Intrinsics.checkNotNullParameter(it42, "it");
                                    return this.f$0.sh(it42);
                                case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                                    Intrinsics.checkNotNullParameter(it42, "it");
                                    return this.f$0.sh(it42);
                                case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                                    Intrinsics.checkNotNullParameter(it42, "it");
                                    return this.f$0.sh(it42);
                                case 11:
                                    Intrinsics.checkNotNullParameter(it42, "it");
                                    return this.f$0.sh(it42);
                                default:
                                    Intrinsics.checkNotNullParameter(it42, "it");
                                    return this.f$0.sh(it42);
                            }
                        }
                    };
                    JSONObject json9 = request.json(65536);
                    Set set = LinkUrl.BANNED;
                    String clean2 = LinkUrl.clean(json9.optString("url"));
                    if (clean2 != null) {
                        int[] iArr = B64.INDEX;
                        String jSONObject8 = new JSONObject().put("url", clean2).toString();
                        Intrinsics.checkNotNullExpressionValue(jSONObject8, "toString(...)");
                        byte[] bytes6 = jSONObject8.getBytes(Charsets.UTF_8);
                        Intrinsics.checkNotNullExpressionValue(bytes6, "getBytes(...)");
                        JSONObject call3 = Home.call("--es link ".concat(B64.encode(bytes6)), function16, null);
                        if (call3.optBoolean("installed")) {
                            if (call3.optBoolean("linkOk")) {
                                HttpServer.Response response31 = new HttpServer.Response();
                                response31.status = 200;
                                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda026 = HttpServer.trusted;
                                response31.body = Census$$ExternalSyntheticOutline0.m("toString(...)", call3);
                                return response31;
                            }
                            throw new IOException("home:pin_old");
                        }
                        throw new IOException("home:missing");
                    }
                    throw new IOException("pin_bad_link");
                }
                return null;
            case 2073960698:
                if (str.equals("home/wall") && z) {
                    List list3 = Wallpapers.bases;
                    Adb adb5 = this.link.get();
                    String optString9 = request.json(65536).optString("id");
                    Intrinsics.checkNotNullExpressionValue(optString9, "optString(...)");
                    Wallpapers.Gallery fetch2 = Wallpapers.fetch();
                    Wallpapers.Wall wall2 = fetch2.get(optString9);
                    if (wall2 != null) {
                        Regex regex13 = Home.PIN_KEY;
                        List list4 = Launchers.KEYS;
                        byte[] bArr3 = Launchers.get$shared_release(fetch2.base + wall2.file);
                        Wallpapers.checked(wall2.sha, bArr3);
                        JSONObject photo2 = Home.photo(adb5, bArr3);
                        HttpServer.Response response32 = new HttpServer.Response();
                        response32.status = 200;
                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda027 = HttpServer.trusted;
                        response32.body = Census$$ExternalSyntheticOutline0.m("toString(...)", photo2);
                        return response32;
                    }
                    throw new IllegalArgumentException("no such wallpaper");
                }
                return null;
            default:
                return null;
        }
    }
}
