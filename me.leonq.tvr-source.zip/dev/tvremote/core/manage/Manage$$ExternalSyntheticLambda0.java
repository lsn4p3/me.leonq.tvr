package dev.tvremote.core.manage;

import dev.tvremote.core.adb.AdbLink$$ExternalSyntheticLambda2;
import dev.tvremote.core.remote.Inputs;
import dev.tvremote.core.web.Cancel;
import dev.tvremote.update.Ed25519;
import kotlin.collections.ArraysKt;
import kotlin.collections.EmptyList;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import org.conscrypt.FileClientSessionCache;
import org.conscrypt.metrics.ConscryptStatsLog;

/* loaded from: classes.dex */
public final /* synthetic */ class Manage$$ExternalSyntheticLambda0 implements Function0 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Manage f$0;

    public /* synthetic */ Manage$$ExternalSyntheticLambda0(Manage manage, int i) {
        this.$r8$classId = i;
        this.f$0 = manage;
    }

    /* JADX WARN: Type inference failed for: r1v16, types: [dev.tvremote.core.manage.ManagePart, dev.tvremote.core.manage.HealthApi, java.lang.Object] */
    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        EmptyList emptyList = EmptyList.INSTANCE;
        int i = 4;
        int i2 = 3;
        int i3 = 0;
        Manage manage = this.f$0;
        switch (this.$r8$classId) {
            case 0:
                Ed25519.Pt core = manage.core;
                Intrinsics.checkNotNullParameter(core, "core");
                return new ManagePart(core);
            case 1:
                return manage.link.get();
            case 2:
                return manage.link.get();
            case 3:
                return (Cancel) manage.jobs.current.get();
            case 4:
                return (Cancel) manage.jobs.current.get();
            case 5:
                return new LauncherApi(manage.link, manage.dir, new Manage$$ExternalSyntheticLambda12(manage, i3), new Manage$$ExternalSyntheticLambda0(manage, i2));
            case 6:
                Object obj = Inputs.TYPES;
                String out = manage.sh("dumpsys tv_input 2>/dev/null; echo '#--tvr-inputs--'; dumpsys hdmi_control 2>/dev/null");
                Intrinsics.checkNotNullParameter(out, "out");
                try {
                    return Inputs.parseUnsafe(out);
                } catch (Exception unused) {
                    return emptyList;
                }
            case 7:
                int i4 = 1;
                return new TvAppsApi(manage.link, manage.dir, new Manage$$ExternalSyntheticLambda12(manage, i4), new Manage$$ExternalSyntheticLambda0(manage, i), new AdbLink$$ExternalSyntheticLambda2(i4, manage));
            case 8:
                return new SetupApi(manage.core, (TvCopy) manage.copy$delegate.getValue());
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                return new InstallApi(manage.core, (TvCopy) manage.copy$delegate.getValue());
            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                return new FilesApi(manage.core, (TvCopy) manage.copy$delegate.getValue(), (InstallApi) manage.installs$delegate.getValue(), (SetupApi) manage.setupApi$delegate.getValue());
            case 11:
                return new AppsApi(manage.core);
            case FileClientSessionCache.MAX_SIZE /* 12 */:
                Ed25519.Pt core2 = manage.core;
                Intrinsics.checkNotNullParameter(core2, "core");
                ?? managePart = new ManagePart(core2);
                managePart.slowParts = emptyList;
                return managePart;
            case 13:
                AppsApi appsApi = (AppsApi) manage.apps$delegate.getValue();
                FilesApi filesApi = (FilesApi) manage.files$delegate.getValue();
                InstallApi installApi = (InstallApi) manage.installs$delegate.getValue();
                HealthApi healthApi = (HealthApi) manage.healthApi$delegate.getValue();
                SetupApi setupApi = (SetupApi) manage.setupApi$delegate.getValue();
                Ed25519.Pt core3 = manage.core;
                Intrinsics.checkNotNullParameter(core3, "core");
                return ArraysKt.asList(new ManagePart[]{appsApi, filesApi, installApi, healthApi, setupApi, new ManagePart(core3), (TvCopy) manage.copy$delegate.getValue(), new ManagePart(core3)});
            default:
                return manage.link.get();
        }
    }
}
