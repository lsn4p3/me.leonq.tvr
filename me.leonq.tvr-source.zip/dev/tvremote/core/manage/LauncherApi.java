package dev.tvremote.core.manage;

import dev.tvremote.core.Census;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.Adb$$ExternalSyntheticLambda5;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.adb.Mdns;
import dev.tvremote.core.ontv.LauncherSwap;
import dev.tvremote.core.ontv.Launchers;
import dev.tvremote.core.ontv.Setup;
import dev.tvremote.core.ontv.SetupNeed;
import dev.tvremote.core.web.HttpServer;
import dev.tvremote.home.HomeQr$$ExternalSyntheticLambda0;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class LauncherApi {
    public final Manage$$ExternalSyntheticLambda0 cancel;
    public final File dir;
    public final Manage$$ExternalSyntheticLambda12 job;
    public final AdbLink link;

    public LauncherApi(AdbLink link, File file, Manage$$ExternalSyntheticLambda12 manage$$ExternalSyntheticLambda12, Manage$$ExternalSyntheticLambda0 manage$$ExternalSyntheticLambda0) {
        Intrinsics.checkNotNullParameter(link, "link");
        this.link = link;
        this.dir = file;
        this.job = manage$$ExternalSyntheticLambda12;
        this.cancel = manage$$ExternalSyntheticLambda0;
    }

    public static HttpServer.Response thumb(String str) {
        List list = Launchers.KEYS;
        Launchers.Gallery fetch$default = Launchers.fetch$default();
        Launchers.Entry entry = fetch$default.get(str);
        if (entry == null) {
            JSONObject m9m = Census$$ExternalSyntheticOutline0.m9m("error", "not found", "put(...)");
            HttpServer.Response response = new HttpServer.Response();
            response.status = 404;
            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = HttpServer.trusted;
            response.body = Census$$ExternalSyntheticOutline0.m("toString(...)", m9m);
            return response;
        }
        byte[] thumb = Launchers.thumb(fetch$default, entry);
        HttpServer.Response response2 = new HttpServer.Response();
        response2.type = "image/jpeg";
        response2.body = thumb;
        return response2;
    }

    /* JADX WARN: Type inference failed for: r6v0, types: [java.util.List, java.lang.Object] */
    public final JSONObject answer(boolean z) {
        LauncherSwap launcherSwap = new LauncherSwap(new LauncherApi$$ExternalSyntheticLambda2(this, 0));
        LauncherSwap.Rec rec = null;
        if (z) {
            LauncherSwap.Rec state = launcherSwap.state();
            if (state != null) {
                if (state.state.equals("pending")) {
                    rec = state;
                }
                if (rec != null) {
                    String str = rec.why;
                    launcherSwap.save(new LauncherSwap.Rec(rec.pkg, rec.comp, rec.prev, rec.off, rec.at, "kept", rec.until, str));
                }
            }
        } else {
            launcherSwap.rollback("user", null);
        }
        try {
            sh("am broadcast -a dev.tvremote.setup.LAUNCHER_ANSWERED -p dev.tvremote.setup >/dev/null 2>&1");
        } catch (IOException unused) {
        }
        JSONObject put = new JSONObject().put("ok", true);
        Intrinsics.checkNotNullExpressionValue(put, "put(...)");
        return put;
    }

    public final JSONObject install(String str, String lang) {
        Intrinsics.checkNotNullParameter(lang, "lang");
        Launchers.Entry entry = Launchers.fetch$default().get(str);
        if (entry != null) {
            return (JSONObject) this.job.invoke("launcher ".concat(entry.name), new Adb$$ExternalSyntheticLambda5(this, lang, entry));
        }
        throw new IllegalArgumentException("no such launcher");
    }

    /* JADX WARN: Code restructure failed: missing block: B:44:0x01b7, code lost:
    
        if (r6.contains("com.google.android.apps.tv.launcherx") != false) goto L35;
     */
    /* JADX WARN: Removed duplicated region for block: B:35:0x01c4  */
    /* JADX WARN: Type inference failed for: r11v4, types: [java.util.Map, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r11v6, types: [java.util.Map, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r6v20, types: [java.util.List, java.lang.Object] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final JSONObject list() {
        String str;
        boolean z;
        List list = Launchers.KEYS;
        Launchers.Gallery fetch$default = Launchers.fetch$default();
        Launchers.Facts facts = Launchers.facts(new LauncherApi$$ExternalSyntheticLambda2(this, 3));
        List split$default = StringsKt.split$default(sh("pm list packages"), new String[]{"\n"}, 0, 6);
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(split$default));
        Iterator it = split$default.iterator();
        while (it.hasNext()) {
            arrayList.add(StringsKt.trim(StringsKt.removePrefix((String) it.next(), "package:")).toString());
        }
        Set set = CollectionsKt.toSet(arrayList);
        LauncherSwap launcherSwap = new LauncherSwap(new LauncherApi$$ExternalSyntheticLambda2(this, 4));
        String homeNow = launcherSwap.homeNow();
        String substringBefore = StringsKt.substringBefore(homeNow, '/', homeNow);
        LauncherSwap.Rec state = launcherSwap.state();
        List list2 = Launchers.KEYS;
        String tvLang = Launchers.tvLang(new LauncherApi$$ExternalSyntheticLambda2(this, 5));
        JSONArray jSONArray = new JSONArray();
        Iterator it2 = fetch$default.entries.iterator();
        while (true) {
            str = "";
            if (!it2.hasNext()) {
                break;
            }
            Launchers.Entry entry = (Launchers.Entry) it2.next();
            List list3 = Launchers.KEYS;
            Census.Props fits = Launchers.fits(entry, facts);
            JSONObject jSONObject = new JSONObject();
            String str2 = entry.id;
            JSONObject put = jSONObject.put("id", str2);
            String str3 = entry.pkg;
            Iterator it3 = it2;
            JSONObject put2 = put.put("pkg", str3).put("name", entry.name).put("desc", new JSONObject((Map) entry.desc)).put("notes", new JSONObject((Map) entry.notes)).put("thumb", "/api/launcher/thumb?id=".concat(str2)).put("source", entry.source).put("license", entry.license).put("kind", entry.kind).put("version", entry.version).put("fit", fits.leanback).put("why", (String) fits.map).put("min_sdk", entry.minSdk).put("installed", set.contains(str3)).put("in_use", str3.equals(substringBefore));
            ?? r6 = entry.langs;
            if (!r6.isEmpty() && tvLang.length() != 0 && !r6.contains(tvLang)) {
                str = (facts.sdk < 33 || !Launchers.english(entry, tvLang)) ? entry.fallback : "en";
            }
            jSONArray.put(put2.put("shows", str));
            it2 = it3;
        }
        JSONObject put3 = new JSONObject().put("updated", fetch$default.updated).put("launchers", jSONArray).put("home", substringBefore);
        if (state == null || !state.getActive()) {
            String[] strArr = Setup.LAUNCHER;
            if (!ArraysKt.contains(substringBefore, strArr) && !substringBefore.equals("android")) {
                LinkedHashSet linkedHashSet = new LinkedHashSet(MapsKt__MapsKt.mapCapacity(set.size() + 5));
                linkedHashSet.addAll(set);
                linkedHashSet.addAll(ArraysKt.asList(strArr));
            }
            z = false;
            JSONObject put4 = put3.put("back", z);
            if (state != null) {
                str = state.state;
            }
            JSONObject put5 = put4.put("record", str).put("tv_setup", SetupNeed.ok(SetupNeed.have(new LauncherApi$$ExternalSyntheticLambda2(this, 6)), "launcher"));
            Intrinsics.checkNotNullExpressionValue(put5, "put(...)");
            return put5;
        }
        z = true;
        JSONObject put42 = put3.put("back", z);
        if (state != null) {
        }
        JSONObject put52 = put42.put("record", str).put("tv_setup", SetupNeed.ok(SetupNeed.have(new LauncherApi$$ExternalSyntheticLambda2(this, 6)), "launcher"));
        Intrinsics.checkNotNullExpressionValue(put52, "put(...)");
        return put52;
    }

    public final JSONObject play(String str) {
        Launchers.Entry entry = Launchers.fetch$default().get(str);
        if (entry != null) {
            if (entry.kind.equals("play")) {
                String concat = "market://details?id=".concat(entry.pkg);
                String str2 = entry.playUrl;
                if (StringsKt__StringsJVMKt.startsWith(str2, false, concat)) {
                    ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                    if (!StringsKt.contains(sh("am start -a android.intent.action.VIEW -d " + Mdns.q(str2) + " 2>&1"), "Error", false)) {
                        JSONObject put = new JSONObject().put("ok", true);
                        Intrinsics.checkNotNullExpressionValue(put, "put(...)");
                        return put;
                    }
                    throw new IOException("launcher:noplay");
                }
            }
            throw new IllegalArgumentException("not a Play Store launcher");
        }
        throw new IllegalArgumentException("no such launcher");
    }

    public final JSONObject restore() {
        new LauncherSwap(new LauncherApi$$ExternalSyntheticLambda2(this, 1)).rollback("user", null);
        JSONObject put = new JSONObject().put("ok", true);
        String homeNow = new LauncherSwap(new LauncherApi$$ExternalSyntheticLambda2(this, 2)).homeNow();
        JSONObject put2 = put.put("home", StringsKt.substringBefore(homeNow, '/', homeNow));
        Intrinsics.checkNotNullExpressionValue(put2, "put(...)");
        return put2;
    }

    public final String sh(String str) {
        Adb adb = this.link.get();
        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
        return adb.shell(120000L, str);
    }
}
