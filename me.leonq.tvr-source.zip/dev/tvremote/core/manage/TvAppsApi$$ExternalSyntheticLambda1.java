package dev.tvremote.core.manage;

import dev.tvremote.core.web.Cancel;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;

/* loaded from: classes.dex */
public final /* synthetic */ class TvAppsApi$$ExternalSyntheticLambda1 implements Function0 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Cancel f$0;

    public /* synthetic */ TvAppsApi$$ExternalSyntheticLambda1(Cancel cancel, int i) {
        this.$r8$classId = i;
        this.f$0 = cancel;
    }

    /* JADX WARN: Code restructure failed: missing block: B:29:0x003a, code lost:
    
        if (r0.stopped == true) goto L33;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x000c, code lost:
    
        if (r0.stopped == true) goto L10;
     */
    @Override // kotlin.jvm.functions.Function0
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object invoke() {
        boolean z;
        boolean z2;
        switch (this.$r8$classId) {
            case 0:
                Cancel cancel = this.f$0;
                if (cancel != null) {
                    z = true;
                    break;
                }
                z = false;
                return Boolean.valueOf(z);
            case 1:
                Cancel cancel2 = this.f$0;
                if (cancel2 != null) {
                    cancel2.check();
                }
                return Unit.INSTANCE;
            case 2:
                Cancel cancel3 = this.f$0;
                if (cancel3 != null) {
                    cancel3.check();
                }
                return Unit.INSTANCE;
            case 3:
                Cancel cancel4 = this.f$0;
                if (cancel4 != null) {
                    cancel4.check();
                }
                return Unit.INSTANCE;
            default:
                Cancel cancel5 = this.f$0;
                if (cancel5 != null) {
                    z2 = true;
                    break;
                }
                z2 = false;
                return Boolean.valueOf(z2);
        }
    }
}
