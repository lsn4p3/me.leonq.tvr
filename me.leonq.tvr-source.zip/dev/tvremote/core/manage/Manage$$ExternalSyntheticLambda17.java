package dev.tvremote.core.manage;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Words;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.ontv.Axml$$ExternalSyntheticLambda2;
import dev.tvremote.core.ontv.Bloat$$ExternalSyntheticLambda0;
import dev.tvremote.core.ontv.Notify;
import dev.tvremote.core.ontv.Setup;
import dev.tvremote.core.ontv.Tailscale;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class Manage$$ExternalSyntheticLambda17 implements Function1 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Manage f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ Manage$$ExternalSyntheticLambda17(Manage manage, String str, int i) {
        this.$r8$classId = i;
        this.f$0 = manage;
        this.f$1 = str;
    }

    /* JADX WARN: Type inference failed for: r2v13, types: [kotlin.jvm.internal.Ref$IntRef, java.lang.Object] */
    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        String str;
        JSONObject put;
        int i = 1;
        int i2 = 0;
        switch (this.$r8$classId) {
            case 0:
                Manage manage = this.f$0;
                String str2 = this.f$1;
                JSONObject j = (JSONObject) obj;
                Intrinsics.checkNotNullParameter(j, "j");
                Adb adb = manage.link.get();
                File file = manage.dir;
                Tailscale tailscale = new Tailscale(adb, file);
                Manage$$ExternalSyntheticLambda17 manage$$ExternalSyntheticLambda17 = new Manage$$ExternalSyntheticLambda17(manage, str2, i);
                Manage$$ExternalSyntheticLambda27 manage$$ExternalSyntheticLambda27 = new Manage$$ExternalSyntheticLambda27(j, 0);
                ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                if (!StringsKt.contains(adb.shell(120000L, "pm path com.tailscale.ipn"), "package:", false)) {
                    String string = new JSONObject(Tailscale.get("https://pkgs.tailscale.com/stable/?mode=json")).getJSONObject("APKs").getString("universal");
                    String str3 = (String) new Regex("\\s+").split(StringsKt.trim(Tailscale.get("https://pkgs.tailscale.com/stable/" + string + ".sha256")).toString(), 0).get(0);
                    manage$$ExternalSyntheticLambda27.at("download", 5);
                    ConcurrentHashMap concurrentHashMap2 = Words.books;
                    Setup setup = new Setup(adb, file, Words.lang, new Bloat$$ExternalSyntheticLambda0(3));
                    ?? obj2 = new Object();
                    obj2.element = -1;
                    File download = setup.download(ApkSigner$$ExternalSyntheticOutline0.m("https://pkgs.tailscale.com/stable/", string), "tailscale.apk", str3, new Axml$$ExternalSyntheticLambda2(6, obj2, manage$$ExternalSyntheticLambda27));
                    try {
                        manage$$ExternalSyntheticLambda27.at("install", 60);
                        String install = setup.install(download);
                        i2 = 0;
                        if (!StringsKt.contains(install, "Success", false)) {
                            throw new IOException("install failed: " + CollectionsKt.lastOrNull(StringsKt.lines(StringsKt.trim(install).toString())));
                        }
                    } finally {
                        download.delete();
                    }
                }
                manage$$ExternalSyntheticLambda27.at("start", 80);
                tailscale.keepAlive();
                adb.shell(120000L, "cmd appops set com.tailscale.ipn ACTIVATE_VPN allow");
                adb.shell(120000L, "pm grant com.tailscale.ipn android.permission.POST_NOTIFICATIONS 2>/dev/null");
                String str4 = "";
                if (tailscale.ip().length() <= 0) {
                    adb.shell(120000L, "am broadcast -a com.tailscale.ipn.CONNECT_VPN -n com.tailscale.ipn/.IPNReceiver");
                    while (true) {
                        if (i2 < 6) {
                            Thread.sleep(1000L);
                            if (tailscale.ip().length() <= 0) {
                                i2++;
                            }
                        } else {
                            tailscale.adb.shell(120000L, "am start -n com.tailscale.ipn/.MainActivity");
                            manage$$ExternalSyntheticLambda17.invoke(Boolean.TRUE);
                            try {
                                str4 = tailscale.signIn();
                            } finally {
                                manage$$ExternalSyntheticLambda17.invoke(Boolean.FALSE);
                            }
                        }
                    }
                }
                if (str4.length() == 0) {
                    j.put("ip", tailscale.ip());
                    return "in";
                }
                j.put("url", str4);
                return "sign in";
            default:
                boolean booleanValue = ((Boolean) obj).booleanValue();
                List list = Notify.CORNERS;
                AppsApi$app$2 appsApi$app$2 = new AppsApi$app$2(1, this.f$0, Manage.class, "sh", "sh(Ljava/lang/String;)Ljava/lang/String;", 3);
                String lang = this.f$1;
                if (booleanValue) {
                    str = Words.get(lang, "server.turning_tailscale_on", new Pair[0]);
                } else {
                    str = null;
                }
                Intrinsics.checkNotNullParameter(lang, "lang");
                if (str != null) {
                    JSONObject jSONObject = new JSONObject();
                    ConcurrentHashMap concurrentHashMap3 = Words.books;
                    put = jSONObject.put("title", Words.get(lang, "notify_kt.tv_remote_working_tv", (Pair[]) Arrays.copyOf(new Pair[0], 0))).put("text", Words.get(lang, "notify_kt.leave_tv_s_remote", (Pair[]) Arrays.copyOf(new Pair[]{new Pair("what", str)}, 1))).put("seconds", 60);
                } else {
                    JSONObject jSONObject2 = new JSONObject();
                    ConcurrentHashMap concurrentHashMap4 = Words.books;
                    put = jSONObject2.put("title", Words.get(lang, "notify_kt.tv_remote_done", (Pair[]) Arrays.copyOf(new Pair[0], 0))).put("seconds", 3);
                }
                try {
                    Intrinsics.checkNotNull(put);
                    Notify.send(appsApi$app$2, put);
                } catch (Exception unused) {
                }
                return Unit.INSTANCE;
        }
    }
}
