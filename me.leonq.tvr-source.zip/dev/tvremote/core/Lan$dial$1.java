package dev.tvremote.core;

import dev.tvremote.phone.picker.NetKt$reachAroundVpn$2$1;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function5;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final /* synthetic */ class Lan$dial$1 extends FunctionReferenceImpl implements Function5 {
    public final Object invoke(String p0, Object obj, Integer num, Object obj2, Object obj3) {
        int intValue = ((Number) obj).intValue();
        int intValue2 = num.intValue();
        NetKt$reachAroundVpn$2$1 netKt$reachAroundVpn$2$1 = (NetKt$reachAroundVpn$2$1) obj2;
        Function1 function1 = (Function1) obj3;
        Intrinsics.checkNotNullParameter(p0, "p0");
        ((Lan) this.receiver).getClass();
        Socket socket = new Socket();
        if (netKt$reachAroundVpn$2$1 != null) {
            try {
                try {
                    netKt$reachAroundVpn$2$1.$n.bindSocket(socket);
                } catch (Exception e) {
                    throw new IOException("the VPN forbids the Wi-Fi: " + e, e);
                }
            } catch (IOException e2) {
                try {
                    socket.close();
                } catch (IOException unused) {
                }
                throw e2;
            }
        }
        function1.invoke(socket);
        socket.connect(new InetSocketAddress(p0, intValue), intValue2);
        return socket;
    }
}
