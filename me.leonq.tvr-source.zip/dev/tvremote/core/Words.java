package dev.tvremote.core;

import dev.tvremote.i18n.Langs;
import java.io.InputStream;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyMap;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.sequences.SequencesKt;
import kotlin.text.Charsets;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsJVMKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public abstract class Words {
    public static final ConcurrentHashMap books = new ConcurrentHashMap();
    public static volatile Function1 open = new Lan$$ExternalSyntheticLambda0(19);
    public static volatile String lang = pick(Locale.getDefault().getLanguage());

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r10v0, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r10v1, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r10v2, types: [java.util.LinkedHashMap, java.util.Map] */
    /* JADX WARN: Type inference failed for: r5v2, types: [java.util.LinkedHashMap, java.util.Map] */
    public static Map book(String str) {
        ?? obj;
        EmptyMap emptyMap = EmptyMap.INSTANCE;
        ConcurrentHashMap concurrentHashMap = books;
        Object obj2 = concurrentHashMap.get(str);
        if (obj2 == null) {
            try {
                InputStream inputStream = (InputStream) open.invoke("i18n/" + str + ".json");
                if (inputStream != null) {
                    try {
                        JSONObject jSONObject = new JSONObject(new String(MathKt.readBytes(inputStream), Charsets.UTF_8));
                        inputStream.close();
                        Iterator<String> keys = jSONObject.keys();
                        Intrinsics.checkNotNullExpressionValue(keys, "keys(...)");
                        List list = SequencesKt.toList(SequencesKt.asSequence(keys));
                        int mapCapacity = MapsKt__MapsKt.mapCapacity(CollectionsKt__IterablesKt.collectionSizeOrDefault(list));
                        if (mapCapacity < 16) {
                            mapCapacity = 16;
                        }
                        ?? linkedHashMap = new LinkedHashMap(mapCapacity);
                        for (Object obj3 : list) {
                            Object obj4 = jSONObject.get((String) obj3);
                            if (obj4 instanceof JSONObject) {
                                Iterator<String> keys2 = ((JSONObject) obj4).keys();
                                Intrinsics.checkNotNullExpressionValue(keys2, "keys(...)");
                                List list2 = SequencesKt.toList(SequencesKt.asSequence(keys2));
                                int mapCapacity2 = MapsKt__MapsKt.mapCapacity(CollectionsKt__IterablesKt.collectionSizeOrDefault(list2));
                                if (mapCapacity2 < 16) {
                                    mapCapacity2 = 16;
                                }
                                obj = new LinkedHashMap(mapCapacity2);
                                for (Object obj5 : list2) {
                                    obj.put(obj5, ((JSONObject) obj4).getString((String) obj5));
                                }
                            } else {
                                obj = obj4.toString();
                            }
                            linkedHashMap.put(obj3, obj);
                        }
                        emptyMap = linkedHashMap;
                    } finally {
                    }
                }
            } catch (Exception unused) {
            }
            Object putIfAbsent = concurrentHashMap.putIfAbsent(str, emptyMap);
            if (putIfAbsent == null) {
                obj2 = emptyMap;
            } else {
                obj2 = putIfAbsent;
            }
        }
        return (Map) obj2;
    }

    public static String get(String lang2, String id, Pair... args) {
        Pair pair;
        String obj;
        Object obj2;
        String str;
        Object obj3;
        String obj4;
        Intrinsics.checkNotNullParameter(lang2, "lang");
        Intrinsics.checkNotNullParameter(id, "id");
        Intrinsics.checkNotNullParameter(args, "args");
        LinkedHashSet linkedHashSet = new LinkedHashSet(MapsKt__MapsKt.mapCapacity(3));
        ArraysKt.toCollection(new String[]{lang2, "en", "vi"}, linkedHashSet);
        Iterator it = linkedHashSet.iterator();
        Intrinsics.checkNotNullExpressionValue(it, "iterator(...)");
        Double d = null;
        Object obj5 = null;
        while (it.hasNext()) {
            Object next = it.next();
            Intrinsics.checkNotNullExpressionValue(next, "next(...)");
            obj5 = book((String) next).get(id);
            if (obj5 != null) {
                break;
            }
        }
        if (obj5 == null) {
            return id;
        }
        int length = args.length;
        int i = 0;
        while (true) {
            if (i < length) {
                pair = args[i];
                if (Intrinsics.areEqual(pair.first, "n")) {
                    break;
                }
                i++;
            } else {
                pair = null;
                break;
            }
        }
        if (pair != null && (obj3 = pair.second) != null && (obj4 = obj3.toString()) != null) {
            d = StringsKt__StringNumberConversionsJVMKt.toDoubleOrNull(obj4);
        }
        if (obj5 instanceof Map) {
            Map map = (Map) obj5;
            if (d == null || d.doubleValue() != 1.0d) {
                str = "other";
            } else {
                str = "one";
            }
            Object obj6 = map.get(str);
            if (obj6 == null) {
                obj6 = map.get("other");
            }
            obj = String.valueOf(obj6);
        } else {
            obj = obj5.toString();
        }
        if (args.length == 0) {
            return obj;
        }
        int length2 = args.length;
        if (length2 != 0) {
            if (length2 != 1) {
                LinkedHashMap linkedHashMap = new LinkedHashMap(MapsKt__MapsKt.mapCapacity(args.length));
                MapsKt__MapsKt.toMap(args, linkedHashMap);
                obj2 = linkedHashMap;
            } else {
                obj2 = MapsKt__MapsKt.mapOf(args[0]);
            }
        } else {
            obj2 = EmptyMap.INSTANCE;
        }
        return new Regex("\\{(\\w+)\\}").replace(obj, new Words$$ExternalSyntheticLambda1(0, obj2));
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [java.util.Map, java.lang.Object] */
    public static boolean getRtl() {
        Character ch;
        char c;
        String str = (String) Langs.NAMES.get(lang);
        if (str == null) {
            str = "";
        }
        int i = 0;
        while (true) {
            if (i < str.length()) {
                char charAt = str.charAt(i);
                if (Character.isLetter(charAt)) {
                    ch = Character.valueOf(charAt);
                    break;
                }
                i++;
            } else {
                ch = null;
                break;
            }
        }
        if (ch != null) {
            c = ch.charValue();
        } else {
            c = 'a';
        }
        byte directionality = Character.getDirectionality(c);
        if (directionality != 1 && directionality != 2) {
            return false;
        }
        return true;
    }

    public static String pick(String str) {
        if (str == null) {
            str = "";
        }
        String lowerCase = str.toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        String substringBefore = StringsKt.substringBefore(lowerCase, '-', lowerCase);
        String substringBefore2 = StringsKt.substringBefore(substringBefore, '_', substringBefore);
        if (!substringBefore2.equals("vi") && !substringBefore2.equals("en")) {
            Pattern compile = Pattern.compile("[a-z]{2,3}");
            Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
            if (!compile.matcher(substringBefore2).matches() || book(substringBefore2).isEmpty()) {
                return "en";
            }
        }
        return substringBefore2;
    }
}
