package dev.tvremote.core.scenes;

import dev.tvremote.core.Fleet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class RemoteSpec$Entry {
    public final String action;
    public final String arg;
    public final String expand;
    public final String icon;
    public final String id;
    public final String key;
    public final Object kinds;
    public final Object needs;
    public final String style;
    public final String sub;
    public final String t;
    public final String tint;
    public final String whenCond;

    public RemoteSpec$Entry(String str, String icon, String t, String str2, String str3, String str4, String str5, String str6, String str7, String str8, List list, String str9, Map map) {
        Intrinsics.checkNotNullParameter(icon, "icon");
        Intrinsics.checkNotNullParameter(t, "t");
        this.id = str;
        this.icon = icon;
        this.t = t;
        this.sub = str2;
        this.key = str3;
        this.action = str4;
        this.arg = str5;
        this.whenCond = str6;
        this.expand = str7;
        this.style = str8;
        this.needs = list;
        this.tint = str9;
        this.kinds = map;
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [java.util.Collection, java.lang.Object, java.lang.Iterable] */
    public final boolean can(Set set) {
        ?? r0 = this.needs;
        if (!r0.isEmpty()) {
            Iterator it = r0.iterator();
            while (it.hasNext()) {
                if (!set.contains((String) it.next())) {
                    return false;
                }
            }
            return true;
        }
        return true;
    }

    public final String words() {
        String str = this.t;
        if (str.length() == 0) {
            return "";
        }
        return Fleet.T(str, new Pair[0]);
    }
}
