package dev.tvremote.core.scenes;

import com.android.apksig.internal.apk.v1.DigestAlgorithm;
import com.android.apksig.internal.util.Pair;
import com.android.apksig.internal.zip.CentralDirectoryRecord;
import dev.tvremote.core.manage.Procs$Proc;
import dev.tvremote.core.remote.Remote;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;

/* loaded from: classes.dex */
public final class Phrases$alt$$inlined$sortedByDescending$1 implements Comparator {
    public final /* synthetic */ int $r8$classId;

    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        switch (this.$r8$classId) {
            case 0:
                return MathKt.compareValues(Integer.valueOf(((String) obj2).length()), Integer.valueOf(((String) obj).length()));
            case 1:
                return ((Character) ((Pair) obj).mFirst).charValue() - ((Character) ((Pair) obj2).mFirst).charValue();
            case 2:
                DigestAlgorithm digestAlgorithm = (DigestAlgorithm) obj;
                DigestAlgorithm digestAlgorithm2 = (DigestAlgorithm) obj2;
                int ordinal = digestAlgorithm.ordinal();
                if (ordinal != 0) {
                    if (ordinal == 1) {
                        int ordinal2 = digestAlgorithm2.ordinal();
                        if (ordinal2 == 0) {
                            return 1;
                        }
                        if (ordinal2 != 1) {
                            throw new RuntimeException("Unsupported algorithm: " + digestAlgorithm2);
                        }
                    } else {
                        throw new RuntimeException("Unsupported algorithm: " + digestAlgorithm);
                    }
                } else {
                    int ordinal3 = digestAlgorithm2.ordinal();
                    if (ordinal3 != 0) {
                        if (ordinal3 == 1) {
                            return -1;
                        }
                        throw new RuntimeException("Unsupported algorithm: " + digestAlgorithm2);
                    }
                }
                return 0;
            case 3:
                long j = ((CentralDirectoryRecord) obj).mLocalFileHeaderOffset;
                long j2 = ((CentralDirectoryRecord) obj2).mLocalFileHeaderOffset;
                if (j > j2) {
                    return 1;
                }
                if (j < j2) {
                    return -1;
                }
                return 0;
            case 4:
                return MathKt.compareValues((Integer) ((Map.Entry) obj2).getValue(), (Integer) ((Map.Entry) obj).getValue());
            case 5:
                return MathKt.compareValues(Integer.valueOf(((Procs$Proc) obj2).mb), Integer.valueOf(((Procs$Proc) obj).mb));
            case 6:
                return MathKt.compareValues(Integer.valueOf(((String) obj2).length()), Integer.valueOf(((String) obj).length()));
            case 7:
                return MathKt.compareValues(Integer.valueOf(((List) obj2).size()), Integer.valueOf(((List) obj).size()));
            default:
                String str = ((Remote.App) obj).label;
                Locale locale = Locale.ROOT;
                String lowerCase = str.toLowerCase(locale);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                String lowerCase2 = ((Remote.App) obj2).label.toLowerCase(locale);
                Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
                return MathKt.compareValues(lowerCase, lowerCase2);
        }
    }
}
