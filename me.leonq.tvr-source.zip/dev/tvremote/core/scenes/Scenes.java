package dev.tvremote.core.scenes;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.Mdns;
import dev.tvremote.core.ontv.Bloat;
import dev.tvremote.core.ontv.Notify;
import dev.tvremote.core.ontv.RulesClient;
import dev.tvremote.core.ontv.SetupNeed;
import dev.tvremote.core.remote.Inputs;
import dev.tvremote.home.HomeQr$$ExternalSyntheticLambda0;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgression;
import kotlin.ranges.IntProgressionIterator;
import kotlin.ranges.IntRange;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class Scenes {
    public static final Pattern APP_ID;
    public static final HashMap KEYS;
    public static final Pattern PKG;
    public static final Set STEPS;

    /* loaded from: classes.dex */
    public final class Shell implements Target {
        public final Function1 sh;

        public Shell(Function1 function1) {
            this.sh = function1;
        }

        @Override // dev.tvremote.core.scenes.Scenes.Target
        public final void app(String str) {
            HashMap hashMap = Scenes.KEYS;
            Scenes.launch(str, this.sh);
        }

        @Override // dev.tvremote.core.scenes.Scenes.Target
        public final void input(String str) {
            Object obj = Inputs.TYPES;
            Inputs.m14switch(this.sh, str, null);
        }

        @Override // dev.tvremote.core.scenes.Scenes.Target
        public final void key(int i) {
            this.sh.invoke("input keyevent " + i);
        }

        @Override // dev.tvremote.core.scenes.Scenes.Target
        public final void link(String str) {
            ConcurrentHashMap concurrentHashMap = Adb.ASKING;
            String str2 = (String) this.sh.invoke(ApkSigner$$ExternalSyntheticOutline0.m("am start -a android.intent.action.VIEW -d ", Mdns.q(str), " 2>&1"));
            if (!StringsKt.contains(str2, "Error", false)) {
                String lowerCase = str2.toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                if (!StringsKt.contains(lowerCase, "unable to resolve", false)) {
                    return;
                }
            }
            throw new IllegalArgumentException("the TV has no app that can open this");
        }

        @Override // dev.tvremote.core.scenes.Scenes.Target
        public final void notify(JSONObject jSONObject) {
            List list = Notify.CORNERS;
            Notify.send(this.sh, jSONObject);
        }

        @Override // dev.tvremote.core.scenes.Scenes.Target
        public final void timer(int i) {
            Set set = RulesClient.SETUP_KEYS;
            JSONObject call = RulesClient.call(this.sh, new JSONObject().put("do", "sleep").put("minutes", i));
            if (!call.has("setup")) {
                if (!call.has("error")) {
                } else {
                    throw new IllegalArgumentException(call.optString("error"));
                }
            } else {
                String optString = call.optString("have");
                Intrinsics.checkNotNullExpressionValue(optString, "optString(...)");
                throw new SetupNeed.Missing("rules", optString);
            }
        }

        @Override // dev.tvremote.core.scenes.Scenes.Target
        public final void volume(int i) {
            HashMap hashMap = Scenes.KEYS;
            Scenes.volume(this.sh, i, 3);
        }
    }

    /* loaded from: classes.dex */
    public interface Target {
        void app(String str);

        void input(String str);

        void key(int i);

        void link(String str);

        void notify(JSONObject jSONObject);

        void timer(int i);

        void volume(int i);
    }

    static {
        HashMap hashMap = new HashMap();
        hashMap.putAll(MapsKt__MapsKt.mapOf(new Pair("UP", 19), new Pair("DOWN", 20), new Pair("LEFT", 21), new Pair("RIGHT", 22), new Pair("OK", 23), new Pair("BACK", 4), new Pair("HOME", 3), new Pair("MENU", 82), new Pair("POWER", 26), new Pair("WAKE", 224), new Pair("SLEEP", 223), new Pair("VOL_UP", 24), new Pair("VOL_DOWN", 25), new Pair("MUTE", 164), new Pair("PLAY_PAUSE", 85), new Pair("NEXT", 87), new Pair("PREV", 88), new Pair("SETTINGS", 176), new Pair("INPUT", 178), new Pair("DEL", 67), new Pair("ENTER", 66), new Pair("ASSIST", 219), new Pair("CH_UP", 166), new Pair("CH_DOWN", 167), new Pair("PAD_A", 96), new Pair("PAD_B", 97), new Pair("PAD_X", 99), new Pair("PAD_Y", 100), new Pair("PAD_L1", 102), new Pair("PAD_R1", 103), new Pair("PAD_START", 108), new Pair("PAD_SELECT", 109), new Pair("RED", 183), new Pair("GREEN", 184), new Pair("YELLOW", 185), new Pair("BLUE", 186), new Pair("YOUTUBE", 190), new Pair("NETFLIX", 191), new Pair("PRIME", 195), new Pair("ALL_APPS", 284), new Pair("INFO", 165), new Pair("GUIDE", 172), new Pair("LIVE", 170), new Pair("SUBTITLE", 175), new Pair("REWIND", 89), new Pair("STOP", 86), new Pair("FFWD", 90)));
        for (int i = 0; i < 10; i++) {
            hashMap.put(String.valueOf(i), Integer.valueOf(i + 7));
        }
        KEYS = hashMap;
        PKG = Pattern.compile("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z_][A-Za-z0-9_]*)+");
        APP_ID = Pattern.compile("[A-Za-z0-9][A-Za-z0-9_.-]{0,127}");
        STEPS = SetsKt.setOf((Object[]) new String[]{"wake", "sleep", "key", "app", "link", "volume", "wait", "timer", "input", "notify"});
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Failed to find 'out' block for switch in B:25:0x0075. Please report as an issue. */
    public static JSONArray clean(JSONArray jSONArray) {
        int i;
        int i2;
        JSONArray list = jSONArray;
        Intrinsics.checkNotNullParameter(list, "list");
        JSONArray jSONArray2 = new JSONArray();
        int min = Math.min(list.length(), 24);
        int i3 = 0;
        while (i3 < min) {
            JSONObject optJSONObject = list.optJSONObject(i3);
            if (optJSONObject == null) {
                i = min;
            } else {
                JSONArray jSONArray3 = new JSONArray();
                JSONArray optJSONArray = optJSONObject.optJSONArray("steps");
                if (optJSONArray == null) {
                    optJSONArray = new JSONArray();
                }
                int min2 = Math.min(optJSONArray.length(), 30);
                int i4 = 0;
                while (i4 < min2) {
                    JSONObject optJSONObject2 = optJSONArray.optJSONObject(i4);
                    if (optJSONObject2 == null) {
                        i2 = min;
                    } else {
                        String optString = optJSONObject2.optString("do");
                        i2 = min;
                        if (STEPS.contains(optString)) {
                            JSONObject m8m = Census$$ExternalSyntheticOutline0.m8m("do", optString);
                            if (optString != null) {
                                switch (optString.hashCode()) {
                                    case -1039689911:
                                        if (optString.equals("notify")) {
                                            try {
                                                JSONObject clean = Notify.clean(optJSONObject2);
                                                Iterator<String> keys = clean.keys();
                                                Intrinsics.checkNotNullExpressionValue(keys, "keys(...)");
                                                while (keys.hasNext()) {
                                                    String next = keys.next();
                                                    m8m.put(next, clean.get(next));
                                                }
                                            } catch (IllegalArgumentException unused) {
                                                break;
                                            }
                                        }
                                        jSONArray3.put(m8m);
                                        break;
                                    case -810883302:
                                        if (optString.equals("volume")) {
                                            m8m.put("level", MathKt.coerceIn(optJSONObject2.optInt("level"), 0, 100));
                                            jSONArray3.put(m8m);
                                            break;
                                        }
                                        break;
                                    case 96801:
                                        if (optString.equals("app")) {
                                            String optString2 = optJSONObject2.optString("pkg");
                                            if (APP_ID.matcher(optString2).matches()) {
                                                m8m.put("pkg", optString2);
                                                break;
                                            }
                                        }
                                        break;
                                    case 106079:
                                        if (optString.equals("key")) {
                                            String optString3 = optJSONObject2.optString("key");
                                            Intrinsics.checkNotNullExpressionValue(optString3, "optString(...)");
                                            String upperCase = optString3.toUpperCase(Locale.ROOT);
                                            Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
                                            if (KEYS.containsKey(upperCase)) {
                                                m8m.put("key", upperCase);
                                                break;
                                            }
                                        }
                                        break;
                                    case 3321850:
                                        if (optString.equals("link")) {
                                            String optString4 = optJSONObject2.optString("url");
                                            Intrinsics.checkNotNullExpressionValue(optString4, "optString(...)");
                                            String input = StringsKt.trim(optString4).toString();
                                            Pattern compile = Pattern.compile("^[a-zA-Z][a-zA-Z0-9+.-]*:\\S+$");
                                            Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                                            Intrinsics.checkNotNullParameter(input, "input");
                                            if (compile.matcher(input).matches() && input.length() <= 2000) {
                                                m8m.put("url", input);
                                                break;
                                            }
                                        }
                                        break;
                                    case 3641717:
                                        if (optString.equals("wait")) {
                                            m8m.put("s", MathKt.coerceIn(optJSONObject2.optDouble("s", 1.0d), 0.0d, 30.0d));
                                            break;
                                        }
                                        break;
                                    case 100358090:
                                        if (optString.equals("input")) {
                                            String optString5 = optJSONObject2.optString("id");
                                            Object obj = Inputs.TYPES;
                                            Intrinsics.checkNotNull(optString5);
                                            if (Inputs.SAFE_ID.matches(optString5)) {
                                                JSONObject put = m8m.put("id", optString5);
                                                String optString6 = optJSONObject2.optString("label");
                                                Intrinsics.checkNotNullExpressionValue(optString6, "optString(...)");
                                                put.put("label", StringsKt.take(optString6, 60));
                                                break;
                                            }
                                        }
                                        break;
                                    case 110364485:
                                        if (optString.equals("timer")) {
                                            m8m.put("min", MathKt.coerceIn(optJSONObject2.optInt("min"), 0, 720));
                                            break;
                                        }
                                        break;
                                }
                                i4++;
                                min = i2;
                            }
                            jSONArray3.put(m8m);
                            i4++;
                            min = i2;
                        }
                    }
                    i4++;
                    min = i2;
                }
                i = min;
                String optString7 = optJSONObject.optString("name");
                Intrinsics.checkNotNullExpressionValue(optString7, "optString(...)");
                String take = StringsKt.take(StringsKt.trim(optString7).toString(), 40);
                if (take.length() != 0 && jSONArray3.length() != 0) {
                    String optString8 = optJSONObject.optString("id");
                    Intrinsics.checkNotNull(optString8);
                    Pattern compile2 = Pattern.compile("[A-Za-z0-9_-]{1,24}");
                    Intrinsics.checkNotNullExpressionValue(compile2, "compile(...)");
                    if (!compile2.matcher(optString8).matches()) {
                        long nanoTime = System.nanoTime();
                        MathKt.checkRadix(36);
                        String l = Long.toString(nanoTime, 36);
                        Intrinsics.checkNotNullExpressionValue(l, "toString(...)");
                        optString8 = "s".concat(l);
                    }
                    JSONObject m10m = Census$$ExternalSyntheticOutline0.m10m("id", optString8, "name", take);
                    String optString9 = optJSONObject.optString("icon");
                    Intrinsics.checkNotNullExpressionValue(optString9, "optString(...)");
                    JSONObject put2 = m10m.put("icon", StringsKt.take(optString9, 8)).put("steps", jSONArray3);
                    ArrayList phrases = phrases(optJSONObject.optJSONArray("say"));
                    if (!phrases.isEmpty()) {
                        put2.put("say", new JSONArray((Collection) phrases));
                    }
                    jSONArray2.put(put2);
                }
            }
            i3++;
            list = jSONArray;
            min = i;
        }
        return jSONArray2;
    }

    public static void launch(String pkg, Function1 function1) {
        Intrinsics.checkNotNullParameter(pkg, "pkg");
        if (PKG.matcher(pkg).matches()) {
            if (!Bloat.factory(pkg)) {
                String[] strArr = {"LEANBACK_LAUNCHER", "LAUNCHER"};
                for (int i = 0; i < 2; i++) {
                    String input = StringsKt.trim((String) StringsKt.split$default(StringsKt.trim((String) function1.invoke(Census$$ExternalSyntheticOutline0.m("cmd package resolve-activity --brief -a android.intent.action.MAIN -c android.intent.category.", strArr[i], " ", pkg, " 2>/dev/null"))).toString(), new String[]{"\n"}, 0, 6).get(r3.size() - 1)).toString();
                    Pattern compile = Pattern.compile("[\\w.]+/[\\w.$]+");
                    Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                    Intrinsics.checkNotNullParameter(input, "input");
                    if (compile.matcher(input).matches() && StringsKt__StringsJVMKt.startsWith(input, false, pkg.concat("/"))) {
                        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                        if (!StringsKt.contains((CharSequence) function1.invoke("am start -n " + Mdns.q(input) + " 2>&1"), "Error", false)) {
                            return;
                        }
                    }
                }
                throw new IllegalArgumentException("this app cannot be opened (no launcher screen)");
            }
            throw new IllegalArgumentException("factory app: not opened");
        }
        throw new IllegalArgumentException("bad package name");
    }

    public static ArrayList phrases(JSONArray jSONArray) {
        int i;
        HashSet hashSet = new HashSet();
        ArrayList arrayList = new ArrayList();
        if (jSONArray != null) {
            i = jSONArray.length();
        } else {
            i = 0;
        }
        for (int i2 = 0; i2 < i; i2++) {
            Intrinsics.checkNotNull(jSONArray);
            String optString = jSONArray.optString(i2);
            Intrinsics.checkNotNullExpressionValue(optString, "optString(...)");
            String obj = StringsKt.trim(optString).toString();
            String replaceAll = Census$$ExternalSyntheticOutline0.m7m("\\s+", "compile(...)", obj, "input", obj).replaceAll(" ");
            Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
            String take = StringsKt.take(replaceAll, 40);
            Voice voice = Voice.INSTANCE;
            if (Voice.norm(take).length() > 0 && hashSet.add(Voice.norm(take))) {
                arrayList.add(take);
            }
            if (arrayList.size() == 5) {
                break;
            }
        }
        return arrayList;
    }

    /* JADX WARN: Code restructure failed: missing block: B:81:0x0175, code lost:
    
        continue;
     */
    /* JADX WARN: Failed to find 'out' block for switch in B:12:0x003c. Please report as an issue. */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static String run$default(JSONArray jSONArray, Target tv) {
        Intrinsics.checkNotNullParameter(tv, "tv");
        ArrayList arrayList = new ArrayList();
        int min = Math.min(jSONArray.length(), 30);
        for (int i = 0; i < min && !Boolean.FALSE.booleanValue(); i++) {
            JSONObject optJSONObject = jSONArray.optJSONObject(i);
            if (optJSONObject != null) {
                try {
                    String optString = optJSONObject.optString("do");
                    if (optString != null) {
                        switch (optString.hashCode()) {
                            case -1039689911:
                                if (optString.equals("notify")) {
                                    tv.notify(Notify.clean(optJSONObject));
                                    break;
                                } else {
                                    break;
                                }
                            case -810883302:
                                if (optString.equals("volume")) {
                                    tv.volume(MathKt.coerceIn(optJSONObject.optInt("level"), 0, 100));
                                    break;
                                } else {
                                    break;
                                }
                            case 96801:
                                if (optString.equals("app")) {
                                    String optString2 = optJSONObject.optString("pkg");
                                    Intrinsics.checkNotNullExpressionValue(optString2, "optString(...)");
                                    tv.app(optString2);
                                    break;
                                } else {
                                    break;
                                }
                            case 106079:
                                if (optString.equals("key")) {
                                    HashMap hashMap = KEYS;
                                    String optString3 = optJSONObject.optString("key");
                                    Intrinsics.checkNotNullExpressionValue(optString3, "optString(...)");
                                    String upperCase = optString3.toUpperCase(Locale.ROOT);
                                    Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
                                    Integer num = (Integer) hashMap.get(upperCase);
                                    if (num != null) {
                                        tv.key(num.intValue());
                                        break;
                                    } else {
                                        throw new IllegalArgumentException("unknown key");
                                        break;
                                    }
                                } else {
                                    break;
                                }
                            case 3321850:
                                if (optString.equals("link")) {
                                    String optString4 = optJSONObject.optString("url");
                                    Intrinsics.checkNotNullExpressionValue(optString4, "optString(...)");
                                    tv.link(optString4);
                                    break;
                                } else {
                                    break;
                                }
                            case 3641717:
                                if (optString.equals("wait")) {
                                    Thread.sleep((long) (MathKt.coerceIn(optJSONObject.optDouble("s", 1.0d), 0.0d, 30.0d) * 1000));
                                    break;
                                } else {
                                    break;
                                }
                            case 3641764:
                                if (optString.equals("wake")) {
                                    tv.key(224);
                                    break;
                                } else {
                                    break;
                                }
                            case 100358090:
                                if (optString.equals("input")) {
                                    String optString5 = optJSONObject.optString("id");
                                    Intrinsics.checkNotNullExpressionValue(optString5, "optString(...)");
                                    tv.input(optString5);
                                    break;
                                } else {
                                    break;
                                }
                            case 109522647:
                                if (optString.equals("sleep")) {
                                    tv.key(223);
                                    break;
                                } else {
                                    break;
                                }
                            case 110364485:
                                if (optString.equals("timer")) {
                                    tv.timer(MathKt.coerceIn(optJSONObject.optInt("min"), 0, 720));
                                    break;
                                } else {
                                    break;
                                }
                        }
                    } else {
                        continue;
                    }
                } catch (InterruptedException unused) {
                } catch (Exception e) {
                    int i2 = i + 1;
                    String message = e.getMessage();
                    if (message == null) {
                        message = e.getClass().getSimpleName();
                    }
                    arrayList.add(i2 + ": " + message);
                }
            }
        }
        if (arrayList.isEmpty()) {
            return null;
        }
        return CollectionsKt.joinToString$default(arrayList, "; ", null, null, null, 62);
    }

    public static LinkedHashMap sayings(JSONArray jSONArray) {
        IntRange until = MathKt.until(0, jSONArray.length());
        ArrayList arrayList = new ArrayList();
        Iterator it = until.iterator();
        while (((IntProgressionIterator) it).hasNext) {
            JSONObject optJSONObject = jSONArray.optJSONObject(((IntProgressionIterator) it).nextInt());
            if (optJSONObject != null) {
                arrayList.add(optJSONObject);
            }
        }
        int mapCapacity = MapsKt__MapsKt.mapCapacity(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList));
        if (mapCapacity < 16) {
            mapCapacity = 16;
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap(mapCapacity);
        Iterator it2 = arrayList.iterator();
        while (it2.hasNext()) {
            JSONObject jSONObject = (JSONObject) it2.next();
            linkedHashMap.put(jSONObject.optString("id"), phrases(jSONObject.optJSONArray("say")));
        }
        LinkedHashMap linkedHashMap2 = new LinkedHashMap();
        for (Map.Entry entry : linkedHashMap.entrySet()) {
            if (!((List) entry.getValue()).isEmpty()) {
                linkedHashMap2.put(entry.getKey(), entry.getValue());
            }
        }
        return linkedHashMap2;
    }

    public static void volume(Function1 function1, int i, int i2) {
        int intValue;
        final int i3;
        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = new HomeQr$$ExternalSyntheticLambda0(11);
        Scenes$$ExternalSyntheticLambda1 scenes$$ExternalSyntheticLambda1 = new Scenes$$ExternalSyntheticLambda1(function1, i2, 0);
        if (((Boolean) homeQr$$ExternalSyntheticLambda0.invoke(function1.invoke("cmd media_session volume --stream " + i2 + " --set " + i + " 2>&1"))).booleanValue()) {
            if (((Boolean) homeQr$$ExternalSyntheticLambda0.invoke(function1.invoke("media volume --stream " + i2 + " --set " + i + " 2>&1"))).booleanValue()) {
                throw new IllegalArgumentException("volume command failed");
            }
        }
        Integer num = (Integer) scenes$$ExternalSyntheticLambda1.invoke();
        if (num != null && (intValue = num.intValue()) != i) {
            if (i2 == 3) {
                if (i > intValue) {
                    i3 = 24;
                } else {
                    i3 = 25;
                }
                function1.invoke(CollectionsKt.joinToString$default(new IntProgression(1, Math.min(Math.abs(i - intValue), 30), 1), "; ", null, null, new Function1() { // from class: dev.tvremote.core.scenes.Scenes$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj) {
                        ((Integer) obj).intValue();
                        return "input keyevent " + i3;
                    }
                }, 30));
                return;
            }
            throw new IllegalArgumentException("this TV keeps that volume itself");
        }
    }
}
