package dev.tvremote.core.scenes;

import java.io.File;
import java.util.List;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.text.Charsets;

/* loaded from: classes.dex */
public final class VoicePhrases {
    public static volatile byte[] bytes;
    public static File kept;
    public static volatile boolean started;
    public static final VoicePhrases INSTANCE = new Object();
    public static final List BASES = CollectionsKt__CollectionsKt.listOf((Object[]) new String[]{"https://tvremote.pages.dev/voice/", "https://raw.githubusercontent.com/HoangTran0410/tv-remote/main/docs/voice/"});

    /* JADX WARN: Removed duplicated region for block: B:7:0x0028  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static Pair choose(byte[] bArr, byte[] bArr2, byte[] bArr3) {
        Phrases phrases;
        Phrases phrases2;
        if (bArr3 != null) {
            try {
                phrases = new Phrases(new String(bArr3, Charsets.UTF_8));
            } catch (Exception unused) {
            }
            for (byte[] bArr4 : ArraysKt.asList(new byte[][]{bArr, bArr2})) {
                if (bArr4 != null) {
                    try {
                        phrases2 = new Phrases(new String(bArr4, Charsets.UTF_8));
                    } catch (Exception unused2) {
                    }
                    if (phrases2 != null && bArr4 != null && (phrases == null || phrases2.rev >= phrases.rev)) {
                        return new Pair(bArr4, phrases2);
                    }
                }
                phrases2 = null;
                if (phrases2 != null) {
                    return new Pair(bArr4, phrases2);
                }
            }
            if (bArr3 != null || phrases == null) {
                return null;
            }
            return new Pair(bArr3, phrases);
        }
        phrases = null;
        while (r5.hasNext()) {
        }
        if (bArr3 != null) {
        }
        return null;
    }
}
