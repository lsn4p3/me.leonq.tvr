package dev.tvremote.core.scenes;

import dev.tvremote.phone.MainActivity;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.StringsKt__StringNumberConversionsKt;

/* loaded from: classes.dex */
public final /* synthetic */ class Scenes$$ExternalSyntheticLambda1 implements Function0 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;
    public final /* synthetic */ int f$1;

    public /* synthetic */ Scenes$$ExternalSyntheticLambda1(Object obj, int i, int i2) {
        this.$r8$classId = i2;
        this.f$0 = obj;
        this.f$1 = i;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        String str;
        switch (this.$r8$classId) {
            case 0:
                Pattern compile = Pattern.compile("volume is (\\d+)");
                Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                CharSequence input = (CharSequence) ((Function1) this.f$0).invoke("cmd media_session volume --stream " + this.f$1 + " --get 2>&1");
                Intrinsics.checkNotNullParameter(input, "input");
                Matcher matcher = compile.matcher(input);
                Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
                MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, input);
                if (access$findNext != null && (str = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)) != null) {
                    return StringsKt__StringNumberConversionsKt.toIntOrNull(str);
                }
                return null;
            default:
                MathKt.setTimer(this.f$1, (MainActivity) this.f$0);
                return Unit.INSTANCE;
        }
    }
}
