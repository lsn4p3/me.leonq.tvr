package dev.tvremote.core.scenes;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Words$$ExternalSyntheticLambda1;
import dev.tvremote.core.ontv.Home$$ExternalSyntheticLambda6;
import dev.tvremote.home.HomeQr$$ExternalSyntheticLambda0;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.regex.Pattern;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyList;
import kotlin.collections.EmptyMap;
import kotlin.collections.EmptySet;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgressionIterator;
import kotlin.ranges.IntRange;
import kotlin.sequences.ConstrainedOnceSequence;
import kotlin.sequences.GeneratorSequence;
import kotlin.sequences.Sequence;
import kotlin.sequences.SequencesKt;
import kotlin.text.Regex;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class Phrases {
    public final Regex appWord;
    public final ArrayList apps;
    public final Regex channel;
    public final Regex channelNames;
    public final Regex close;
    public final Regex connect;
    public final List fillers;
    public final Set hours;
    public final HashMap keys;
    public final List langs;
    public final Set neverClose;
    public final JSONObject o;
    public final Regex open;
    public final int rev;
    public final Regex searchBare;
    public final HashMap settingWords;
    public final Object settings;
    public final Set timerCancel;
    public final Regex timerSet;
    public final Regex tuneRe;
    public final Regex volDown;
    public final Regex volUp;

    /* loaded from: classes.dex */
    public final class Alias {
        public final String label;
        public final Set names;
        public final Object pkgs;
        public final String search;
        public final String tube;

        public Alias(String str, List list, Set set, String str2, String str3) {
            this.label = str;
            this.pkgs = list;
            this.names = set;
            this.search = str2;
            this.tube = str3;
        }
    }

    /* JADX WARN: Type inference failed for: r9v15, types: [java.util.Map, java.lang.Object] */
    public Phrases(String str) {
        Regex regex;
        Regex regex2;
        int i;
        Map map;
        Set set;
        List list;
        String str2;
        String str3;
        JSONObject jSONObject = new JSONObject(str);
        this.o = jSONObject;
        this.rev = jSONObject.getInt("rev");
        JSONObject jSONObject2 = jSONObject.getJSONObject("lang");
        Iterator<String> keys = jSONObject2.keys();
        Intrinsics.checkNotNullExpressionValue(keys, "keys(...)");
        List list2 = SequencesKt.toList(new GeneratorSequence(SequencesKt.asSequence(keys), new Home$$ExternalSyntheticLambda6(jSONObject2, 3), 2));
        this.langs = list2;
        this.fillers = CollectionsKt.sortedWith(all("fillers"), new Phrases$alt$$inlined$sortedByDescending$1(6));
        HashMap hashMap = new HashMap();
        Iterator it = list2.iterator();
        while (it.hasNext()) {
            JSONObject optJSONObject = ((JSONObject) it.next()).optJSONObject("keys");
            if (optJSONObject != null) {
                Iterator<String> keys2 = optJSONObject.keys();
                Intrinsics.checkNotNullExpressionValue(keys2, "keys(...)");
                while (keys2.hasNext()) {
                    String next = keys2.next();
                    Iterator it2 = words(optJSONObject.getJSONArray(next)).iterator();
                    while (it2.hasNext()) {
                        hashMap.put((String) it2.next(), next);
                    }
                }
            }
        }
        this.keys = hashMap;
        this.volUp = new Regex(ApkSigner$$ExternalSyntheticOutline0.m("^(?:", alt(all("volume", "up")), ")(?: (?:(?:len|xuong|them|by|to) )?(\\d+))?$"));
        this.volDown = new Regex(ApkSigner$$ExternalSyntheticOutline0.m("^(?:", alt(all("volume", "down")), ")(?: (?:(?:len|xuong|them|by|to) )?(\\d+))?$"));
        this.timerCancel = CollectionsKt.toSet(all("timer", "cancel"));
        this.timerSet = new Regex(Census$$ExternalSyntheticOutline0.m("^(?:", alt(all("timer", "set")), ") (\\d+) ?(", alt(CollectionsKt.plus(all("timer", "hours"), (Iterable) all("timer", "minutes"))), ")?$"));
        this.hours = CollectionsKt.toSet(all("timer", "hours"));
        List all = all("channel", "tune");
        String alt = alt(all("open", "noise"));
        this.open = new Regex(Census$$ExternalSyntheticOutline0.m("^(?:", alt(CollectionsKt.plus(all("open", "verbs"), (Iterable) all)), ")(?: (?:", alt, "))? (.+)$"));
        this.close = new Regex(Census$$ExternalSyntheticOutline0.m("^(?:", alt(all("close", "verbs")), ") (?:(?:", alt, ") )?(.+)$"));
        this.appWord = new Regex(Census$$ExternalSyntheticOutline0.m("^(?:(?:", alt(all("open", "verbs")), ") )?(?:", alt, ") (.+)$"));
        List all2 = all("connect");
        all2 = all2.isEmpty() ? null : all2;
        if (all2 != null) {
            regex = new Regex(ApkSigner$$ExternalSyntheticOutline0.m("^(.+) (?:", alt(all2), ") (.+)$"));
        } else {
            regex = null;
        }
        this.connect = regex;
        List all3 = all("search", "verbs");
        all3 = all3.isEmpty() ? null : all3;
        if (all3 != null) {
            regex2 = new Regex(ApkSigner$$ExternalSyntheticOutline0.m("^(?:", alt(all3), ") (.+)$"));
        } else {
            regex2 = null;
        }
        this.searchBare = regex2;
        this.tuneRe = new Regex(ApkSigner$$ExternalSyntheticOutline0.m("^(?:", alt(all), ") (.+)$"));
        this.channel = new Regex(Census$$ExternalSyntheticOutline0.m("^(?:(?:", alt(all("channel", "verbs")), ") )?(?:", alt(all("channel", "words")), ") (.+)$"));
        JSONArray optJSONArray = this.o.optJSONArray("channel_names");
        if (optJSONArray != null) {
            i = optJSONArray.length();
        } else {
            i = 0;
        }
        this.channelNames = new Regex(ApkSigner$$ExternalSyntheticOutline0.m("^(?:", CollectionsKt.joinToString$default(MathKt.until(0, i), "|", null, null, new Words$$ExternalSyntheticLambda1(9, this), 30), ")$"));
        JSONObject optJSONObject2 = this.o.optJSONObject("settings");
        if (optJSONObject2 != null) {
            Iterator<String> keys3 = optJSONObject2.keys();
            Intrinsics.checkNotNullExpressionValue(keys3, "keys(...)");
            Sequence asSequence = SequencesKt.asSequence(keys3);
            map = new LinkedHashMap();
            Iterator it3 = ((ConstrainedOnceSequence) asSequence).iterator();
            while (it3.hasNext()) {
                Object next2 = it3.next();
                JSONArray jSONArray = optJSONObject2.getJSONArray((String) next2);
                IntRange until = MathKt.until(0, jSONArray.length());
                ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until));
                Iterator it4 = until.iterator();
                while (((IntProgressionIterator) it4).hasNext) {
                    arrayList.add(jSONArray.getString(((IntProgressionIterator) it4).nextInt()));
                }
                map.put(next2, arrayList);
            }
        } else {
            map = EmptyMap.INSTANCE;
        }
        this.settings = map;
        HashMap hashMap2 = new HashMap();
        Iterator it5 = this.langs.iterator();
        while (it5.hasNext()) {
            JSONObject optJSONObject3 = ((JSONObject) it5.next()).optJSONObject("settings");
            if (optJSONObject3 != null) {
                Iterator<String> keys4 = optJSONObject3.keys();
                Intrinsics.checkNotNullExpressionValue(keys4, "keys(...)");
                while (keys4.hasNext()) {
                    String next3 = keys4.next();
                    if (this.settings.containsKey(next3)) {
                        Iterator it6 = words(optJSONObject3.getJSONArray(next3)).iterator();
                        while (it6.hasNext()) {
                            hashMap2.put((String) it6.next(), next3);
                        }
                    }
                }
            }
        }
        this.settingWords = hashMap2;
        JSONArray optJSONArray2 = this.o.optJSONArray("never_close");
        if (optJSONArray2 != null) {
            IntRange until2 = MathKt.until(0, optJSONArray2.length());
            ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until2));
            Iterator it7 = until2.iterator();
            while (((IntProgressionIterator) it7).hasNext) {
                arrayList2.add(optJSONArray2.getString(((IntProgressionIterator) it7).nextInt()));
            }
            set = CollectionsKt.toSet(arrayList2);
        } else {
            set = EmptySet.INSTANCE;
        }
        this.neverClose = set;
        JSONArray jSONArray2 = this.o.getJSONArray("apps");
        IntRange until3 = MathKt.until(0, jSONArray2.length());
        ArrayList arrayList3 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until3));
        Iterator it8 = until3.iterator();
        while (((IntProgressionIterator) it8).hasNext) {
            arrayList3.add(jSONArray2.getJSONObject(((IntProgressionIterator) it8).nextInt()));
        }
        ArrayList arrayList4 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList3));
        Iterator it9 = arrayList3.iterator();
        while (it9.hasNext()) {
            JSONObject jSONObject3 = (JSONObject) it9.next();
            JSONArray optJSONArray3 = jSONObject3.optJSONArray("pkgs");
            String string = jSONObject3.getString("label");
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            if (optJSONArray3 == null) {
                list = EmptyList.INSTANCE;
            } else {
                IntRange until4 = MathKt.until(0, optJSONArray3.length());
                ArrayList arrayList5 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until4));
                Iterator it10 = until4.iterator();
                while (((IntProgressionIterator) it10).hasNext) {
                    arrayList5.add(optJSONArray3.getString(((IntProgressionIterator) it10).nextInt()));
                }
                list = arrayList5;
            }
            Set set2 = CollectionsKt.toSet(words(jSONObject3.getJSONArray("names")));
            String optString = jSONObject3.optString("search");
            if (optString.length() == 0) {
                str2 = null;
            } else {
                str2 = optString;
            }
            String optString2 = jSONObject3.optString("tube");
            if (optString2.length() == 0) {
                str3 = null;
            } else {
                str3 = optString2;
            }
            arrayList4.add(new Alias(string, list, set2, str2, str3));
        }
        this.apps = arrayList4;
        Intrinsics.checkNotNullExpressionValue(Pattern.compile("[^\\p{L}\\p{N}]+"), "compile(...)");
    }

    public static String alt(List list) {
        return CollectionsKt.joinToString$default(CollectionsKt.sortedWith(list, new Phrases$alt$$inlined$sortedByDescending$1(0)), "|", null, null, new HomeQr$$ExternalSyntheticLambda0(10), 30);
    }

    public static List words(JSONArray jSONArray) {
        if (jSONArray == null) {
            return EmptyList.INSTANCE;
        }
        IntRange until = MathKt.until(0, jSONArray.length());
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until));
        Iterator it = until.iterator();
        while (((IntProgressionIterator) it).hasNext) {
            int nextInt = ((IntProgressionIterator) it).nextInt();
            Voice voice = Voice.INSTANCE;
            String string = jSONArray.getString(nextInt);
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            arrayList.add(Voice.norm(string));
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator it2 = arrayList.iterator();
        while (it2.hasNext()) {
            Object next = it2.next();
            if (((String) next).length() > 0) {
                arrayList2.add(next);
            }
        }
        return arrayList2;
    }

    /* JADX WARN: Code restructure failed: missing block: B:12:0x0039, code lost:
    
        kotlin.collections.CollectionsKt__MutableCollectionsKt.addAll(words(r2), r0);
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final List all(String... strArr) {
        JSONArray optJSONArray;
        ArrayList arrayList = new ArrayList();
        for (JSONObject jSONObject : this.langs) {
            Intrinsics.checkNotNull(jSONObject);
            int length = strArr.length - 1;
            int i = 0;
            while (true) {
                if (i < length) {
                    jSONObject = jSONObject.optJSONObject(strArr[i]);
                    if (jSONObject == null) {
                        optJSONArray = null;
                        break;
                    }
                    i++;
                } else if (strArr.length != 0) {
                    optJSONArray = jSONObject.optJSONArray(strArr[strArr.length - 1]);
                } else {
                    throw new NoSuchElementException("Array is empty.");
                }
            }
        }
        return CollectionsKt.distinct(arrayList);
    }
}
