package dev.tvremote.core.scenes;

import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.scenes.Phrases;
import dev.tvremote.home.HomeQr$$ExternalSyntheticLambda0;
import java.net.URLEncoder;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyList;
import kotlin.collections.EmptyMap;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;

/* loaded from: classes.dex */
public final class Voice {
    public static volatile Phrases phrases;
    public static final Voice INSTANCE = new Object();
    public static volatile Prefs prefs = new Prefs();
    public static final Regex MARKS = new Regex("\\p{M}+");
    public static final Regex SIGNS = new Regex("[^\\p{L}\\p{N} ]");
    public static final Regex SPACES = new Regex("\\s+");
    public static final Regex TIVI = new Regex("\\bti ?vi\\b");
    public static final Regex NOT_ALNUM = new Regex("[^a-z0-9]");
    public static final Object KEY_SAY = MapsKt__MapsKt.mapOf(new Pair("MUTE", "talk.k_mute"), new Pair("PLAY_PAUSE", "talk.k_play_pause"), new Pair("HOME", "talk.k_home"), new Pair("BACK", "talk.k_back"), new Pair("NEXT", "talk.k_next"), new Pair("PREV", "talk.k_prev"), new Pair("CH_UP", "talk.k_ch_up"), new Pair("CH_DOWN", "talk.k_ch_down"), new Pair("SLEEP", "talk.k_sleep"), new Pair("WAKE", "talk.k_wake"), new Pair("SETTINGS", "talk.k_settings"), new Pair("OK", "talk.k_ok"), new Pair("UP", "talk.k_up"), new Pair("DOWN", "talk.k_down"), new Pair("LEFT", "talk.k_left"), new Pair("RIGHT", "talk.k_right"), new Pair("MENU", "talk.k_menu"), new Pair("VOL_UP", "talk.k_vol_up"), new Pair("VOL_DOWN", "talk.k_vol_down"));
    public static final Object KEY_N = MapsKt__MapsKt.mapOf(new Pair("VOL_UP", "talk.k_vol_up_n"), new Pair("VOL_DOWN", "talk.k_vol_down_n"));
    public static final Object SETTING_SAY = MapsKt__MapsKt.mapOf(new Pair("main", "talk.s_settings"), new Pair("wifi", "talk.s_wifi"), new Pair("bluetooth", "talk.s_bluetooth"), new Pair("sound", "talk.s_sound"), new Pair("date", "talk.s_date"), new Pair("apps", "talk.s_apps"), new Pair("storage", "talk.s_storage"), new Pair("language", "talk.s_language"), new Pair("keyboard", "talk.s_keyboard"), new Pair("captions", "talk.s_captions"), new Pair("developer", "talk.s_developer"), new Pair("accessibility", "talk.s_accessibility"));

    /* loaded from: classes.dex */
    public abstract class Command {

        /* loaded from: classes.dex */
        public final class App extends Command {
            public final String name;
            public final String pkg;

            public App(String pkg, String name) {
                Intrinsics.checkNotNullParameter(pkg, "pkg");
                Intrinsics.checkNotNullParameter(name, "name");
                this.pkg = pkg;
                this.name = name;
            }

            public final boolean equals(Object obj) {
                if (this == obj) {
                    return true;
                }
                if (!(obj instanceof App)) {
                    return false;
                }
                App app = (App) obj;
                return Intrinsics.areEqual(this.pkg, app.pkg) && Intrinsics.areEqual(this.name, app.name);
            }

            public final int hashCode() {
                return this.name.hashCode() + (this.pkg.hashCode() * 31);
            }

            public final String toString() {
                StringBuilder sb = new StringBuilder("App(pkg=");
                sb.append(this.pkg);
                sb.append(", name=");
                return Census$$ExternalSyntheticOutline0.m(sb, this.name, ")");
            }
        }

        /* loaded from: classes.dex */
        public final class Channel extends Command {
            public final String name;

            public Channel(String name) {
                Intrinsics.checkNotNullParameter(name, "name");
                this.name = name;
            }

            public final boolean equals(Object obj) {
                if (this == obj) {
                    return true;
                }
                return (obj instanceof Channel) && Intrinsics.areEqual(this.name, ((Channel) obj).name);
            }

            public final int hashCode() {
                return this.name.hashCode();
            }

            public final String toString() {
                return Census$$ExternalSyntheticOutline0.m(new StringBuilder("Channel(name="), this.name, ")");
            }
        }

        /* loaded from: classes.dex */
        public final class Choice extends Command {
            public final List options;

            public Choice(List list) {
                this.options = list;
            }

            public final boolean equals(Object obj) {
                if (this == obj) {
                    return true;
                }
                return (obj instanceof Choice) && Intrinsics.areEqual(this.options, ((Choice) obj).options);
            }

            public final int hashCode() {
                return this.options.hashCode();
            }

            public final String toString() {
                return "Choice(options=" + this.options + ")";
            }
        }

        /* loaded from: classes.dex */
        public final class Close extends Command {
            public final String name;
            public final String pkg;

            public Close(String pkg, String name) {
                Intrinsics.checkNotNullParameter(pkg, "pkg");
                Intrinsics.checkNotNullParameter(name, "name");
                this.pkg = pkg;
                this.name = name;
            }

            public final boolean equals(Object obj) {
                if (this == obj) {
                    return true;
                }
                if (!(obj instanceof Close)) {
                    return false;
                }
                Close close = (Close) obj;
                return Intrinsics.areEqual(this.pkg, close.pkg) && Intrinsics.areEqual(this.name, close.name);
            }

            public final int hashCode() {
                return this.name.hashCode() + (this.pkg.hashCode() * 31);
            }

            public final String toString() {
                StringBuilder sb = new StringBuilder("Close(pkg=");
                sb.append(this.pkg);
                sb.append(", name=");
                return Census$$ExternalSyntheticOutline0.m(sb, this.name, ")");
            }
        }

        /* loaded from: classes.dex */
        public final class Key extends Command {
            public final String key;
            public final int times;

            public Key(String str, int i) {
                this.key = str;
                this.times = i;
            }

            public final boolean equals(Object obj) {
                if (this == obj) {
                    return true;
                }
                if (!(obj instanceof Key)) {
                    return false;
                }
                Key key = (Key) obj;
                return Intrinsics.areEqual(this.key, key.key) && this.times == key.times;
            }

            public final int hashCode() {
                return (this.key.hashCode() * 31) + this.times;
            }

            public final String toString() {
                return "Key(key=" + this.key + ", times=" + this.times + ")";
            }
        }

        /* loaded from: classes.dex */
        public final class Pin extends Command {
            public final String app;
            public final String key;
            public final String link;
            public final String name;

            public Pin(String str, String str2, String str3, String str4) {
                this.key = str;
                this.name = str2;
                this.app = str3;
                this.link = str4;
            }

            public final boolean equals(Object obj) {
                if (this == obj) {
                    return true;
                }
                if (!(obj instanceof Pin)) {
                    return false;
                }
                Pin pin = (Pin) obj;
                return Intrinsics.areEqual(this.key, pin.key) && Intrinsics.areEqual(this.name, pin.name) && Intrinsics.areEqual(this.app, pin.app) && Intrinsics.areEqual(this.link, pin.link);
            }

            public final int hashCode() {
                int hashCode = (this.app.hashCode() + ((this.name.hashCode() + (this.key.hashCode() * 31)) * 31)) * 31;
                String str = this.link;
                return hashCode + (str == null ? 0 : str.hashCode());
            }

            public final String toString() {
                StringBuilder sb = new StringBuilder("Pin(key=");
                sb.append(this.key);
                sb.append(", name=");
                sb.append(this.name);
                sb.append(", app=");
                sb.append(this.app);
                sb.append(", link=");
                return Census$$ExternalSyntheticOutline0.m(sb, this.link, ")");
            }
        }

        /* loaded from: classes.dex */
        public final class Scene extends Command {
            public final String id;

            public Scene(String id) {
                Intrinsics.checkNotNullParameter(id, "id");
                this.id = id;
            }

            public final boolean equals(Object obj) {
                if (this == obj) {
                    return true;
                }
                return (obj instanceof Scene) && Intrinsics.areEqual(this.id, ((Scene) obj).id);
            }

            public final int hashCode() {
                return this.id.hashCode();
            }

            public final String toString() {
                return Census$$ExternalSyntheticOutline0.m(new StringBuilder("Scene(id="), this.id, ")");
            }
        }

        /* loaded from: classes.dex */
        public final class Search extends Command {
            public final String name;
            public final String pkg;
            public final String query;
            public final String url;

            public Search(String pkg, String name, String query, String str) {
                Intrinsics.checkNotNullParameter(pkg, "pkg");
                Intrinsics.checkNotNullParameter(name, "name");
                Intrinsics.checkNotNullParameter(query, "query");
                this.pkg = pkg;
                this.name = name;
                this.query = query;
                this.url = str;
            }

            public final boolean equals(Object obj) {
                if (this == obj) {
                    return true;
                }
                if (!(obj instanceof Search)) {
                    return false;
                }
                Search search = (Search) obj;
                return Intrinsics.areEqual(this.pkg, search.pkg) && Intrinsics.areEqual(this.name, search.name) && Intrinsics.areEqual(this.query, search.query) && Intrinsics.areEqual(this.url, search.url);
            }

            public final int hashCode() {
                int hashCode = (this.query.hashCode() + ((this.name.hashCode() + (this.pkg.hashCode() * 31)) * 31)) * 31;
                String str = this.url;
                return hashCode + (str == null ? 0 : str.hashCode());
            }

            public final String toString() {
                StringBuilder sb = new StringBuilder("Search(pkg=");
                sb.append(this.pkg);
                sb.append(", name=");
                sb.append(this.name);
                sb.append(", query=");
                sb.append(this.query);
                sb.append(", url=");
                return Census$$ExternalSyntheticOutline0.m(sb, this.url, ")");
            }
        }

        /* loaded from: classes.dex */
        public final class Setting extends Command {
            public final List actions;
            public final String id;

            public Setting(String str, List list) {
                this.id = str;
                this.actions = list;
            }

            public final boolean equals(Object obj) {
                if (this == obj) {
                    return true;
                }
                if (!(obj instanceof Setting)) {
                    return false;
                }
                Setting setting = (Setting) obj;
                return Intrinsics.areEqual(this.id, setting.id) && Intrinsics.areEqual(this.actions, setting.actions);
            }

            public final int hashCode() {
                return this.actions.hashCode() + (this.id.hashCode() * 31);
            }

            public final String toString() {
                return "Setting(id=" + this.id + ", actions=" + this.actions + ")";
            }
        }

        /* loaded from: classes.dex */
        public final class Timer extends Command {
            public final int minutes;

            public Timer(int i) {
                this.minutes = i;
            }

            public final boolean equals(Object obj) {
                if (this == obj) {
                    return true;
                }
                return (obj instanceof Timer) && this.minutes == ((Timer) obj).minutes;
            }

            public final int hashCode() {
                return this.minutes;
            }

            public final String toString() {
                return "Timer(minutes=" + this.minutes + ")";
            }
        }
    }

    /* loaded from: classes.dex */
    public final class PinRef {
        public final String app;
        public final String key;
        public final String link;
        public final String title;

        public PinRef(String str, String str2, String str3, String str4) {
            this.key = str;
            this.title = str2;
            this.app = str3;
            this.link = str4;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof PinRef)) {
                return false;
            }
            PinRef pinRef = (PinRef) obj;
            return Intrinsics.areEqual(this.key, pinRef.key) && Intrinsics.areEqual(this.title, pinRef.title) && Intrinsics.areEqual(this.app, pinRef.app) && Intrinsics.areEqual(this.link, pinRef.link);
        }

        public final int hashCode() {
            int hashCode = (this.app.hashCode() + ((this.title.hashCode() + (this.key.hashCode() * 31)) * 31)) * 31;
            String str = this.link;
            return hashCode + (str == null ? 0 : str.hashCode());
        }

        public final String toString() {
            StringBuilder sb = new StringBuilder("PinRef(key=");
            sb.append(this.key);
            sb.append(", title=");
            sb.append(this.title);
            sb.append(", app=");
            sb.append(this.app);
            sb.append(", link=");
            return Census$$ExternalSyntheticOutline0.m(sb, this.link, ")");
        }
    }

    /* loaded from: classes.dex */
    public final class Plan {
        public final Command command;
        public final Say say;

        public Plan(Command command, Say say) {
            this.command = command;
            this.say = say;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof Plan)) {
                return false;
            }
            Plan plan = (Plan) obj;
            return Intrinsics.areEqual(this.command, plan.command) && Intrinsics.areEqual(this.say, plan.say);
        }

        public final int hashCode() {
            Command command = this.command;
            return this.say.hashCode() + ((command == null ? 0 : command.hashCode()) * 31);
        }

        public final String toString() {
            return "Plan(command=" + this.command + ", say=" + this.say + ")";
        }
    }

    /* loaded from: classes.dex */
    public final class Prefs {
        public final String search;
        public final String youtube;

        public /* synthetic */ Prefs() {
            this("", "");
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof Prefs)) {
                return false;
            }
            Prefs prefs = (Prefs) obj;
            return Intrinsics.areEqual(this.search, prefs.search) && Intrinsics.areEqual(this.youtube, prefs.youtube);
        }

        public final int hashCode() {
            return this.youtube.hashCode() + (this.search.hashCode() * 31);
        }

        public final String toString() {
            StringBuilder sb = new StringBuilder("Prefs(search=");
            sb.append(this.search);
            sb.append(", youtube=");
            return Census$$ExternalSyntheticOutline0.m(sb, this.youtube, ")");
        }

        public Prefs(String str, String str2) {
            this.search = str;
            this.youtube = str2;
        }
    }

    /* JADX WARN: Type inference failed for: r5v2, types: [java.lang.Object, java.lang.Iterable] */
    public static Pair app(String str, Map map, Phrases phrases2, boolean z, Prefs prefs2) {
        Object obj;
        String str2;
        Object obj2;
        Iterator it = phrases2.apps.iterator();
        while (true) {
            if (it.hasNext()) {
                obj = it.next();
                if (((Phrases.Alias) obj).names.contains(str)) {
                    break;
                }
            } else {
                obj = null;
                break;
            }
        }
        Phrases.Alias alias = (Phrases.Alias) obj;
        if (alias != null) {
            str2 = alias.tube;
        } else {
            str2 = null;
        }
        if (Intrinsics.areEqual(str2, "main")) {
            String str3 = prefs2.youtube;
            if (str3.length() > 0 && map.containsKey(str3)) {
                return new Pair(str3, MapsKt__MapsKt.getValue(map, str3));
            }
        }
        Set<Map.Entry> entrySet = map.entrySet();
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(entrySet));
        for (Map.Entry entry : entrySet) {
            arrayList.add(new Pair(entry, fold((String) entry.getValue())));
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator it2 = arrayList.iterator();
        while (it2.hasNext()) {
            Object next = it2.next();
            if (((CharSequence) ((Pair) next).second).length() > 0) {
                arrayList2.add(next);
            }
        }
        if (alias != null) {
            Iterator it3 = alias.pkgs.iterator();
            while (true) {
                if (it3.hasNext()) {
                    obj2 = it3.next();
                    Object obj3 = (String) obj2;
                    if (map.isEmpty() || map.containsKey(obj3)) {
                        break;
                    }
                } else {
                    obj2 = null;
                    break;
                }
            }
            Object obj4 = (String) obj2;
            String str4 = alias.label;
            if (obj4 != null) {
                String str5 = (String) map.get(obj4);
                if (str5 != null) {
                    str4 = str5;
                }
                return new Pair(obj4, str4);
            }
            if (!map.isEmpty()) {
                return app$fuzzy(fold(str4), arrayList2);
            }
        } else if (z) {
            return app$fuzzy(str, arrayList2);
        }
        return null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.lang.Object] */
    public static final Pair app$fuzzy(String str, ArrayList arrayList) {
        Object obj;
        Object obj2;
        Object obj3;
        Pair pair;
        Iterator it = arrayList.iterator();
        while (true) {
            if (it.hasNext()) {
                obj = it.next();
                if (Intrinsics.areEqual(((Pair) obj).second, str)) {
                    break;
                }
            } else {
                obj = null;
                break;
            }
        }
        Pair pair2 = (Pair) obj;
        if (pair2 == null) {
            Iterator it2 = arrayList.iterator();
            while (true) {
                if (it2.hasNext()) {
                    obj2 = it2.next();
                    Pair pair3 = (Pair) obj2;
                    if (StringsKt__StringsJVMKt.startsWith((String) pair3.second, false, str)) {
                        break;
                    }
                    if (StringsKt__StringsJVMKt.startsWith(str, false, pair3.second + " ")) {
                        break;
                    }
                } else {
                    obj2 = null;
                    break;
                }
            }
            pair2 = (Pair) obj2;
            if (pair2 == null) {
                Iterator it3 = arrayList.iterator();
                while (true) {
                    if (it3.hasNext()) {
                        obj3 = it3.next();
                        Pair pair4 = (Pair) obj3;
                        if (str.length() >= 3 && StringsKt.contains((CharSequence) pair4.second, str, false)) {
                            break;
                        }
                    } else {
                        obj3 = null;
                        break;
                    }
                }
                pair2 = (Pair) obj3;
                if (pair2 == null) {
                    Iterator it4 = arrayList.iterator();
                    while (true) {
                        if (it4.hasNext()) {
                            pair = it4.next();
                            Pair pair5 = (Pair) pair;
                            if (((String) pair5.second).length() >= 3 && StringsKt.contains(str, (CharSequence) pair5.second, false)) {
                                break;
                            }
                        } else {
                            pair = 0;
                            break;
                        }
                    }
                    pair2 = pair;
                }
            }
        }
        if (pair2 == null) {
            return null;
        }
        Map.Entry entry = (Map.Entry) pair2.first;
        return new Pair(entry.getKey(), entry.getValue());
    }

    public static Command best(String str, Map map, List list, boolean z, boolean z2) {
        Integer valueOf;
        String str2;
        String sound = sound(str);
        ArrayList arrayList = new ArrayList();
        if (z2) {
            for (Map.Entry entry : map.entrySet()) {
                String str3 = (String) entry.getKey();
                String str4 = (String) entry.getValue();
                Integer best$quality = best$quality(str, sound, z, fold(str4));
                if (best$quality != null) {
                    arrayList.add(new Pair(Integer.valueOf(best$quality.intValue()), new Command.App(str3, str4)));
                }
            }
        }
        Iterator it = list.iterator();
        while (it.hasNext()) {
            PinRef pinRef = (PinRef) it.next();
            Integer best$quality2 = best$quality(str, sound, z, fold(pinRef.title));
            if (best$quality2 != null) {
                arrayList.add(new Pair(Integer.valueOf(best$quality2.intValue()), new Command.Pin(pinRef.key, pinRef.title, pinRef.app, pinRef.link)));
            }
        }
        Iterator it2 = arrayList.iterator();
        if (!it2.hasNext()) {
            valueOf = null;
        } else {
            valueOf = Integer.valueOf(((Number) ((Pair) it2.next()).first).intValue());
            while (it2.hasNext()) {
                Integer valueOf2 = Integer.valueOf(((Number) ((Pair) it2.next()).first).intValue());
                if (valueOf.compareTo(valueOf2) > 0) {
                    valueOf = valueOf2;
                }
            }
        }
        if (valueOf == null) {
            return null;
        }
        int intValue = valueOf.intValue();
        ArrayList arrayList2 = new ArrayList();
        Iterator it3 = arrayList.iterator();
        while (it3.hasNext()) {
            Object next = it3.next();
            if (((Number) ((Pair) next).first).intValue() == intValue) {
                arrayList2.add(next);
            }
        }
        ArrayList arrayList3 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList2));
        Iterator it4 = arrayList2.iterator();
        while (it4.hasNext()) {
            arrayList3.add((Command) ((Pair) it4.next()).second);
        }
        ArrayList arrayList4 = new ArrayList();
        Iterator it5 = arrayList3.iterator();
        while (it5.hasNext()) {
            Object next2 = it5.next();
            if (next2 instanceof Command.App) {
                arrayList4.add(next2);
            }
        }
        ArrayList arrayList5 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList4));
        Iterator it6 = arrayList4.iterator();
        while (it6.hasNext()) {
            arrayList5.add(fold(((Command.App) it6.next()).name));
        }
        Set set = CollectionsKt.toSet(arrayList5);
        ArrayList arrayList6 = new ArrayList();
        Iterator it7 = arrayList3.iterator();
        while (it7.hasNext()) {
            Object next3 = it7.next();
            Command command = (Command) next3;
            if (!(command instanceof Command.Pin) || !set.contains(fold(((Command.Pin) command).name))) {
                arrayList6.add(next3);
            }
        }
        HashSet hashSet = new HashSet();
        ArrayList arrayList7 = new ArrayList();
        Iterator it8 = arrayList6.iterator();
        while (it8.hasNext()) {
            Object next4 = it8.next();
            Command command2 = (Command) next4;
            if (command2 instanceof Command.App) {
                str2 = ((Command.App) command2).pkg;
            } else {
                Intrinsics.checkNotNull(command2, "null cannot be cast to non-null type dev.tvremote.core.scenes.Voice.Command.Pin");
                str2 = ((Command.Pin) command2).key;
            }
            if (hashSet.add(str2)) {
                arrayList7.add(next4);
            }
        }
        List sortedWith = CollectionsKt.sortedWith(arrayList7, MathKt.compareBy(new HomeQr$$ExternalSyntheticLambda0(12), new HomeQr$$ExternalSyntheticLambda0(13)));
        if (sortedWith.size() == 1) {
            return (Command) sortedWith.get(0);
        }
        return new Command.Choice(CollectionsKt.take(sortedWith, 3));
    }

    public static final Integer best$quality(String str, String str2, boolean z, String str3) {
        if (str3.length() != 0) {
            if (!str3.equals(str) && (str2.length() < 4 || !sound(str3).equals(str2))) {
                if (!z) {
                    if (!StringsKt__StringsJVMKt.startsWith(str3, false, str) && !StringsKt__StringsJVMKt.startsWith(str, false, str3.concat(" "))) {
                        if (str.length() >= 3 && StringsKt.contains(str3, str, false)) {
                            return 2;
                        }
                        if (str3.length() >= 3 && StringsKt.contains(str, str3, false)) {
                            return 3;
                        }
                        return null;
                    }
                    return 1;
                }
                return null;
            }
            return 0;
        }
        return null;
    }

    public static String channelName(String str) {
        String replaceAll = Census$$ExternalSyntheticOutline0.m7m("([a-z]) (\\d)", "compile(...)", str, "input", str).replaceAll("$1$2");
        Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
        return replaceAll;
    }

    public static String fold(String s) {
        Intrinsics.checkNotNullParameter(s, "s");
        String normalize = Normalizer.normalize(s, Normalizer.Form.NFD);
        Intrinsics.checkNotNullExpressionValue(normalize, "normalize(...)");
        String lowerCase = StringsKt__StringsJVMKt.replace$default(StringsKt__StringsJVMKt.replace$default(MARKS.replace(normalize, ""), (char) 273, 'd'), (char) 272, 'd').toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        return StringsKt.trim(SPACES.replace(SIGNS.replace(lowerCase, " "), " ")).toString();
    }

    public static String names1(Command command) {
        if (command instanceof Command.App) {
            return ((Command.App) command).name;
        }
        if (command instanceof Command.Pin) {
            return ((Command.Pin) command).name;
        }
        return "";
    }

    public static String norm(String s) {
        Intrinsics.checkNotNullParameter(s, "s");
        return TIVI.replace(fold(s), "tv");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:105:0x02e2 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:106:0x02e3  */
    /* JADX WARN: Removed duplicated region for block: B:198:0x0573 A[RETURN] */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.util.HashMap] */
    /* JADX WARN: Type inference failed for: r0v6, types: [kotlin.text.Regex] */
    /* JADX WARN: Type inference failed for: r2v28, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v32, types: [java.util.Map, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r2v34, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r2v43, types: [java.lang.Integer] */
    /* JADX WARN: Type inference failed for: r2v44, types: [java.lang.Integer] */
    /* JADX WARN: Type inference failed for: r2v45 */
    /* JADX WARN: Type inference failed for: r2v46 */
    /* JADX WARN: Type inference failed for: r2v47, types: [java.lang.Integer] */
    /* JADX WARN: Type inference failed for: r2v55 */
    /* JADX WARN: Type inference failed for: r4v13 */
    /* JADX WARN: Type inference failed for: r4v3, types: [java.util.List, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r4v5 */
    /* JADX WARN: Type inference failed for: r4v6, types: [java.lang.CharSequence, java.lang.Object, java.lang.String] */
    /* JADX WARN: Type inference failed for: r6v14, types: [java.util.List, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r6v3 */
    /* JADX WARN: Type inference failed for: r6v4 */
    /* JADX WARN: Type inference failed for: r6v5, types: [java.lang.Object] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static Command parse$default(Voice voice, String text, Map apps, Map scenes, List pins, Map sayings) {
        Command.Search search;
        Object obj;
        String str;
        String str2;
        Object obj2;
        Command.Search searchCommand;
        Phrases.Alias alias;
        MatcherMatchResult matchEntire;
        Object obj3;
        EmptyList emptyList;
        Prefs prefs2;
        String str3;
        Regex regex;
        MatcherMatchResult matchEntire2;
        String str4;
        String str5;
        Object obj4;
        Command.Search searchCommand2;
        Command best;
        String str6;
        ?? valueOf;
        EmptyList emptyList2;
        Iterator it;
        Object obj5;
        Prefs prefs3;
        String str7;
        int[] iArr;
        int i;
        int[] iArr2;
        Pair app;
        Object obj6;
        EmptyList emptyList3 = EmptyList.INSTANCE;
        Prefs prefs4 = prefs;
        voice.getClass();
        Intrinsics.checkNotNullParameter(text, "text");
        Intrinsics.checkNotNullParameter(apps, "apps");
        Intrinsics.checkNotNullParameter(scenes, "scenes");
        Intrinsics.checkNotNullParameter(pins, "pins");
        Intrinsics.checkNotNullParameter(sayings, "sayings");
        Intrinsics.checkNotNullParameter(prefs4, "prefs");
        String fold = fold(text);
        if (fold.length() == 0) {
            return null;
        }
        Iterator it2 = scenes.entrySet().iterator();
        while (true) {
            if (!it2.hasNext()) {
                search = null;
                obj = null;
                break;
            }
            obj = it2.next();
            String str8 = (String) ((Map.Entry) obj).getValue();
            search = null;
            if (Intrinsics.areEqual(fold(str8), fold) || Intrinsics.areEqual(fold("canh ".concat(str8)), fold) || Intrinsics.areEqual(fold("scene ".concat(str8)), fold)) {
                break;
            }
        }
        Map.Entry entry = (Map.Entry) obj;
        if (entry != null) {
            return new Command.Scene((String) entry.getKey());
        }
        Phrases phrases2 = phrases;
        if (phrases2 == null) {
            return search;
        }
        String strip = strip(norm(text), phrases2);
        if (!sayings.isEmpty()) {
            String norm = norm(text);
            Iterator it3 = sayings.entrySet().iterator();
            loop1: while (true) {
                if (!it3.hasNext()) {
                    obj6 = search;
                    break;
                }
                obj6 = it3.next();
                Map.Entry entry2 = (Map.Entry) obj6;
                String str9 = (String) entry2.getKey();
                List list = (List) entry2.getValue();
                if (scenes.containsKey(str9) && (list == null || !list.isEmpty())) {
                    Iterator it4 = list.iterator();
                    while (it4.hasNext()) {
                        String norm2 = norm((String) it4.next());
                        if (norm2.length() > 0 && (norm2.equals(norm) || norm2.equals(strip))) {
                            break loop1;
                        }
                    }
                }
            }
            Map.Entry entry3 = (Map.Entry) obj6;
            if (entry3 != null) {
                return new Command.Scene((String) entry3.getKey());
            }
        }
        String str10 = (String) phrases2.keys.get(strip);
        if (str10 != null) {
            return new Command.Key(str10, 1);
        }
        MatcherMatchResult matchEntire3 = phrases2.volUp.matchEntire(strip);
        if (matchEntire3 != null) {
            Integer intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull((String) ((MatcherMatchResult$groupValues$1) matchEntire3.getGroupValues()).get(1));
            return new Command.Key("VOL_UP", Math.min(intOrNull != null ? intOrNull.intValue() : 3, 15));
        }
        MatcherMatchResult matchEntire4 = phrases2.volDown.matchEntire(strip);
        if (matchEntire4 != null) {
            Integer intOrNull2 = StringsKt__StringNumberConversionsKt.toIntOrNull((String) ((MatcherMatchResult$groupValues$1) matchEntire4.getGroupValues()).get(1));
            return new Command.Key("VOL_DOWN", Math.min(intOrNull2 != null ? intOrNull2.intValue() : 3, 15));
        }
        if (phrases2.timerCancel.contains(strip)) {
            return new Command.Timer(0);
        }
        MatcherMatchResult matchEntire5 = phrases2.timerSet.matchEntire(strip);
        if (matchEntire5 != null) {
            boolean contains = phrases2.hours.contains(((MatcherMatchResult$groupValues$1) matchEntire5.getGroupValues()).get(2));
            Integer intOrNull3 = StringsKt__StringNumberConversionsKt.toIntOrNull((String) ((MatcherMatchResult$groupValues$1) matchEntire5.getGroupValues()).get(1));
            return new Command.Timer(Math.min((intOrNull3 != null ? intOrNull3.intValue() : 720) * (contains ? 60 : 1), 720));
        }
        MatcherMatchResult matchEntire6 = phrases2.close.matchEntire(strip);
        if (matchEntire6 != null && (app = app((String) ((MatcherMatchResult$groupValues$1) matchEntire6.getGroupValues()).get(1), apps, phrases2, true, prefs4)) != null && !phrases2.neverClose.contains(app.first)) {
            return new Command.Close((String) app.first, (String) app.second);
        }
        Regex regex2 = phrases2.connect;
        if (regex2 != null) {
            MatcherMatchResult matchEntire7 = phrases2.open.matchEntire(strip);
            if (matchEntire7 == null || (str = (String) ((MatcherMatchResult$groupValues$1) matchEntire7.getGroupValues()).get(1)) == null) {
                str = strip;
            }
            MatcherMatchResult matchEntire8 = regex2.matchEntire(str);
            if (matchEntire8 != null) {
                Regex regex3 = phrases2.searchBare;
                if (regex3 == null || (matchEntire = regex3.matchEntire((CharSequence) ((MatcherMatchResult$groupValues$1) matchEntire8.getGroupValues()).get(1))) == null || (str2 = (String) ((MatcherMatchResult$groupValues$1) matchEntire.getGroupValues()).get(1)) == null) {
                    str2 = (String) ((MatcherMatchResult$groupValues$1) matchEntire8.getGroupValues()).get(1);
                }
                String str11 = (String) ((MatcherMatchResult$groupValues$1) matchEntire8.getGroupValues()).get(2);
                Pair search$known = search$known(apps, phrases2, prefs4, str11);
                if (search$known != null) {
                    Pair search$known2 = search$known(apps, phrases2, prefs4, str2);
                    Object obj7 = search$known2 != null ? (String) search$known2.first : search;
                    Object obj8 = search$known.first;
                    if (!Intrinsics.areEqual(obj7, obj8)) {
                        String str12 = (String) obj8;
                        String str13 = (String) search$known.second;
                        String spelled = spelled(text, str2);
                        ArrayList arrayList = phrases2.apps;
                        Iterator it5 = arrayList.iterator();
                        while (true) {
                            if (!it5.hasNext()) {
                                obj2 = search;
                                break;
                            }
                            obj2 = it5.next();
                            if (((Phrases.Alias) obj2).pkgs.contains(obj8)) {
                                break;
                            }
                        }
                        Phrases.Alias alias2 = (Phrases.Alias) obj2;
                        if (alias2 == null) {
                            Iterator it6 = arrayList.iterator();
                            while (true) {
                                if (!it6.hasNext()) {
                                    alias = search;
                                    break;
                                }
                                alias = it6.next();
                                if (((Phrases.Alias) alias).names.contains(str11)) {
                                    break;
                                }
                            }
                            alias2 = alias;
                        }
                        searchCommand = searchCommand(str12, str13, spelled, alias2);
                        if (searchCommand == null) {
                            return searchCommand;
                        }
                        MatcherMatchResult matchEntire9 = phrases2.open.matchEntire(strip);
                        Object obj9 = matchEntire9 != null ? (String) ((MatcherMatchResult$groupValues$1) matchEntire9.getGroupValues()).get(1) : search;
                        ?? r4 = obj9 == null ? strip : obj9;
                        Pair app2 = app(r4, apps, phrases2, false, prefs4);
                        if (app2 != null) {
                            return new Command.App((String) app2.first, (String) app2.second);
                        }
                        Command best2 = best(r4, apps, pins, true, obj9 != null);
                        if (best2 != null) {
                            return best2;
                        }
                        MatcherMatchResult matchEntire10 = phrases2.appWord.matchEntire(strip);
                        if (matchEntire10 == null || (str6 = (String) ((MatcherMatchResult$groupValues$1) matchEntire10.getGroupValues()).get(1)) == null) {
                            obj3 = obj9;
                            emptyList = emptyList3;
                            prefs2 = prefs4;
                            str3 = strip;
                        } else {
                            Command best3 = best(str6, apps, pins, false, true);
                            if (best3 == null) {
                                String sound = sound(str6);
                                if (sound.length() < 3) {
                                    best3 = search;
                                } else {
                                    ArrayList arrayList2 = new ArrayList(apps.size());
                                    Iterator it7 = apps.entrySet().iterator();
                                    Object obj10 = obj9;
                                    while (it7.hasNext()) {
                                        Map.Entry entry4 = (Map.Entry) it7.next();
                                        String str14 = (String) entry4.getKey();
                                        String str15 = (String) entry4.getValue();
                                        String sound2 = sound(fold(str15));
                                        if (sound2.length() == 0) {
                                            i = 99;
                                            obj5 = obj10;
                                            emptyList2 = emptyList3;
                                            prefs3 = prefs4;
                                            str7 = strip;
                                            it = it7;
                                        } else {
                                            emptyList2 = emptyList3;
                                            int length = sound2.length() + 1;
                                            it = it7;
                                            int[] iArr3 = new int[length];
                                            for (int i2 = 0; i2 < length; i2++) {
                                                iArr3[i2] = i2;
                                            }
                                            int length2 = sound.length();
                                            int i3 = 1;
                                            Object obj11 = obj10;
                                            if (1 <= length2) {
                                                while (true) {
                                                    iArr2 = new int[sound2.length() + 1];
                                                    iArr2[0] = i3;
                                                    int length3 = sound2.length();
                                                    prefs3 = prefs4;
                                                    int i4 = 1;
                                                    if (1 <= length3) {
                                                        Object obj12 = obj11;
                                                        while (true) {
                                                            obj5 = obj12;
                                                            int i5 = i4 - 1;
                                                            str7 = strip;
                                                            iArr2[i4] = Math.min(iArr3[i4] + 1, Math.min(iArr2[i5] + 1, iArr3[i5] + (sound.charAt(i3 + (-1)) == sound2.charAt(i5) ? 0 : 1)));
                                                            if (i4 == length3) {
                                                                break;
                                                            }
                                                            i4++;
                                                            obj12 = obj5;
                                                            strip = str7;
                                                        }
                                                    } else {
                                                        obj5 = obj11;
                                                        str7 = strip;
                                                    }
                                                    if (i3 == length2) {
                                                        break;
                                                    }
                                                    i3++;
                                                    iArr3 = iArr2;
                                                    prefs4 = prefs3;
                                                    obj11 = obj5;
                                                    strip = str7;
                                                }
                                                iArr = iArr2;
                                            } else {
                                                obj5 = obj10;
                                                prefs3 = prefs4;
                                                str7 = strip;
                                                iArr = iArr3;
                                            }
                                            i = iArr[sound2.length()];
                                        }
                                        arrayList2.add(new Triple(str14, str15, Integer.valueOf(i)));
                                        it7 = it;
                                        emptyList3 = emptyList2;
                                        prefs4 = prefs3;
                                        obj10 = obj5;
                                        strip = str7;
                                    }
                                    obj3 = obj10;
                                    emptyList = emptyList3;
                                    prefs2 = prefs4;
                                    str3 = strip;
                                    ArrayList arrayList3 = new ArrayList();
                                    Iterator it8 = arrayList2.iterator();
                                    while (it8.hasNext()) {
                                        Object next = it8.next();
                                        Triple triple = (Triple) next;
                                        if (((Number) triple.third).intValue() <= Math.max(1, Math.min(sound.length(), sound(fold((String) triple.second)).length()) / 4)) {
                                            arrayList3.add(next);
                                        }
                                    }
                                    Iterator it9 = arrayList3.iterator();
                                    if (it9.hasNext()) {
                                        valueOf = Integer.valueOf(((Number) ((Triple) it9.next()).third).intValue());
                                        while (it9.hasNext()) {
                                            Integer valueOf2 = Integer.valueOf(((Number) ((Triple) it9.next()).third).intValue());
                                            if (valueOf.compareTo(valueOf2) > 0) {
                                                valueOf = valueOf2;
                                            }
                                        }
                                    } else {
                                        valueOf = search;
                                    }
                                    if (valueOf != 0) {
                                        int intValue = valueOf.intValue();
                                        ArrayList arrayList4 = new ArrayList();
                                        Iterator it10 = arrayList3.iterator();
                                        while (it10.hasNext()) {
                                            Object next2 = it10.next();
                                            if (((Number) ((Triple) next2).third).intValue() == intValue) {
                                                arrayList4.add(next2);
                                            }
                                        }
                                        List<Triple> sortedWith = CollectionsKt.sortedWith(arrayList4, MathKt.compareBy(new HomeQr$$ExternalSyntheticLambda0(14), new HomeQr$$ExternalSyntheticLambda0(15)));
                                        ArrayList arrayList5 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(sortedWith));
                                        for (Triple triple2 : sortedWith) {
                                            arrayList5.add(new Command.App((String) triple2.first, (String) triple2.second));
                                        }
                                        best3 = arrayList5.size() == 1 ? (Command) arrayList5.get(0) : new Command.Choice(CollectionsKt.take(arrayList5, 3));
                                    } else {
                                        best3 = search;
                                    }
                                    if (best3 != null) {
                                        return best3;
                                    }
                                }
                            }
                            obj3 = obj9;
                            emptyList = emptyList3;
                            prefs2 = prefs4;
                            str3 = strip;
                            if (best3 != null) {
                            }
                        }
                        String str16 = (String) phrases2.settingWords.get(r4);
                        if (str16 != null) {
                            ?? r2 = (List) phrases2.settings.get(str16);
                            return new Command.Setting(str16, r2 == 0 ? emptyList : r2);
                        }
                        String str17 = str3;
                        MatcherMatchResult matchEntire11 = phrases2.channel.matchEntire(str17);
                        if (matchEntire11 != null) {
                            String str18 = (String) ((MatcherMatchResult$groupValues$1) matchEntire11.getGroupValues()).get(1);
                            if (phrases2.channelNames.matches(str18)) {
                                str18 = channelName(str18);
                            }
                            return new Command.Channel(str18);
                        }
                        if (phrases2.channelNames.matches(r4)) {
                            return new Command.Channel(channelName(r4));
                        }
                        MatcherMatchResult matchEntire12 = phrases2.tuneRe.matchEntire(str17);
                        if (matchEntire12 != null) {
                            return new Command.Channel((String) ((MatcherMatchResult$groupValues$1) matchEntire12.getGroupValues()).get(1));
                        }
                        if (obj3 != null && (best = best(obj3, apps, pins, false, true)) != null) {
                            return best;
                        }
                        Prefs prefs5 = prefs2;
                        String str19 = (String) apps.get(prefs5.search);
                        if (str19 == null || (regex = phrases2.searchBare) == null || (matchEntire2 = regex.matchEntire(str17)) == null || (str4 = (String) ((MatcherMatchResult$groupValues$1) matchEntire2.getGroupValues()).get(1)) == null) {
                            searchCommand2 = search;
                        } else {
                            String spelled2 = spelled(text, str4);
                            Iterator it11 = phrases2.apps.iterator();
                            while (true) {
                                boolean hasNext = it11.hasNext();
                                str5 = prefs5.search;
                                if (!hasNext) {
                                    obj4 = search;
                                    break;
                                }
                                obj4 = it11.next();
                                if (((Phrases.Alias) obj4).pkgs.contains(str5)) {
                                    break;
                                }
                            }
                            searchCommand2 = searchCommand(str5, str19, spelled2, (Phrases.Alias) obj4);
                        }
                        return searchCommand2 != null ? searchCommand2 : search;
                    }
                }
            }
        }
        searchCommand = search;
        if (searchCommand == null) {
        }
    }

    /* JADX WARN: Type inference failed for: r1v10, types: [java.util.Map, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r3v4, types: [java.util.Map, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r7v36, types: [java.util.Map, java.lang.Object] */
    public static Say say(Command c) {
        Intrinsics.checkNotNullParameter(c, "c");
        if (c instanceof Command.Key) {
            Command.Key key = (Command.Key) c;
            String str = key.key;
            int i = key.times;
            if (i > 1) {
                String str2 = (String) KEY_N.get(str);
                if (str2 == null) {
                    str2 = "talk.k_vol_up_n";
                }
                return new Say(str2, MapsKt__MapsKt.mapOf(new Pair("n", String.valueOf(i))));
            }
            String str3 = (String) KEY_SAY.get(str);
            if (str3 != null) {
                return new Say(str3);
            }
            String lowerCase = str.toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
            return new Say("talk.key", MapsKt__MapsKt.mapOf(new Pair("key", StringsKt__StringsJVMKt.replace$default(lowerCase, '_', ' '))));
        }
        if (c instanceof Command.App) {
            return new Say("talk.open_app", MapsKt__MapsKt.mapOf(new Pair("name", ((Command.App) c).name)));
        }
        if (c instanceof Command.Channel) {
            return new Say("talk.channel", MapsKt__MapsKt.mapOf(new Pair("name", ((Command.Channel) c).name)));
        }
        if (c instanceof Command.Search) {
            Command.Search search = (Command.Search) c;
            return new Say("talk.search_in", MapsKt__MapsKt.mapOf(new Pair("name", search.name), new Pair("q", search.query)));
        }
        if (c instanceof Command.Close) {
            return new Say("talk.close_app", MapsKt__MapsKt.mapOf(new Pair("name", ((Command.Close) c).name)));
        }
        if (c instanceof Command.Timer) {
            int i2 = ((Command.Timer) c).minutes;
            if (i2 == 0) {
                return new Say("talk.timer_off");
            }
            return new Say("talk.timer", MapsKt__MapsKt.mapOf(new Pair("n", String.valueOf(i2))));
        }
        if (c instanceof Command.Scene) {
            return new Say("talk.scene");
        }
        if (c instanceof Command.Setting) {
            String str4 = (String) SETTING_SAY.get(((Command.Setting) c).id);
            if (str4 == null) {
                str4 = "talk.s_settings";
            }
            return new Say(str4);
        }
        if (c instanceof Command.Pin) {
            return new Say("talk.open_app", MapsKt__MapsKt.mapOf(new Pair("name", ((Command.Pin) c).name)));
        }
        if (c instanceof Command.Choice) {
            return new Say("talk.pick_one", MapsKt__MapsKt.mapOf(new Pair("names", CollectionsKt.joinToString$default(((Command.Choice) c).options, " · ", null, null, new HomeQr$$ExternalSyntheticLambda0(16), 30))));
        }
        throw new RuntimeException();
    }

    public static final Pair search$known(Map map, Phrases phrases2, Prefs prefs2, String str) {
        Object obj;
        Pair app = app(str, map, phrases2, false, prefs2);
        if (app == null) {
            Iterator it = map.entrySet().iterator();
            while (true) {
                if (it.hasNext()) {
                    obj = it.next();
                    if (Intrinsics.areEqual(fold((String) ((Map.Entry) obj).getValue()), str)) {
                        break;
                    }
                } else {
                    obj = null;
                    break;
                }
            }
            Map.Entry entry = (Map.Entry) obj;
            if (entry == null) {
                return null;
            }
            return new Pair(entry.getKey(), entry.getValue());
        }
        return app;
    }

    public static Command.Search searchCommand(String str, String str2, String str3, Phrases.Alias alias) {
        String str4;
        String str5;
        if (alias != null && (str5 = alias.search) != null) {
            String encode = URLEncoder.encode(str3, "UTF-8");
            Intrinsics.checkNotNullExpressionValue(encode, "encode(...)");
            str4 = StringsKt__StringsJVMKt.replace$default(str5, "{q}", StringsKt__StringsJVMKt.replace$default(encode, "+", "%20"));
        } else {
            str4 = null;
        }
        return new Command.Search(str, str2, str3, str4);
    }

    public static String sound(String str) {
        String lowerCase = str.toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        return StringsKt__StringsJVMKt.replace$default(NOT_ALNUM.replace(lowerCase, ""), 'y', 'i');
    }

    public static String spelled(String str, String str2) {
        int i = 0;
        List split$default = StringsKt.split$default(str2, new char[]{' '});
        List<String> split = new Regex("\\s+").split(StringsKt.trim(str).toString(), 0);
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(split));
        for (String str3 : split) {
            String replaceAll = Census$$ExternalSyntheticOutline0.m7m("[^\\p{L}\\p{N}]", "compile(...)", str3, "input", str3).replaceAll("");
            Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
            arrayList.add(replaceAll);
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            Object next = it.next();
            if (((String) next).length() > 0) {
                arrayList2.add(next);
            }
        }
        ArrayList arrayList3 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList2));
        Iterator it2 = arrayList2.iterator();
        while (it2.hasNext()) {
            arrayList3.add(fold((String) it2.next()));
        }
        int size = arrayList3.size() - split$default.size();
        if (size >= 0) {
            while (!Intrinsics.areEqual(arrayList3.subList(i, split$default.size() + i), split$default)) {
                if (i != size) {
                    i++;
                }
            }
            return CollectionsKt.joinToString$default(arrayList2.subList(i, split$default.size() + i), " ", null, null, null, 62);
        }
        return str2;
    }

    public static String strip(String str, Phrases phrases2) {
        while (true) {
            for (boolean z = true; z; z = false) {
                for (String str2 : phrases2.fillers) {
                    if (StringsKt__StringsJVMKt.startsWith(str, false, str2 + " ")) {
                        str = str.substring(str2.length() + 1);
                        Intrinsics.checkNotNullExpressionValue(str, "substring(...)");
                    } else {
                        if (StringsKt__StringsJVMKt.endsWith(str, false, " " + str2)) {
                            str = str.substring(0, (str.length() - str2.length()) - 1);
                            Intrinsics.checkNotNullExpressionValue(str, "substring(...)");
                        }
                    }
                }
            }
            return str;
        }
    }

    public final Plan preview(String text, Map apps, Map scenes, boolean z, List pins, Map sayings) {
        Say say;
        Intrinsics.checkNotNullParameter(text, "text");
        Intrinsics.checkNotNullParameter(apps, "apps");
        Intrinsics.checkNotNullParameter(scenes, "scenes");
        Intrinsics.checkNotNullParameter(pins, "pins");
        Intrinsics.checkNotNullParameter(sayings, "sayings");
        if (fold(text).length() == 0) {
            return null;
        }
        Command parse$default = parse$default(this, text, apps, scenes, pins, sayings);
        if (parse$default == null) {
            return new Plan(null, new Say("talk.ask", MapsKt__MapsKt.mapOf(new Pair("sentence", StringsKt.trim(text).toString()))));
        }
        if (parse$default instanceof Command.Scene) {
            String str = (String) scenes.get(((Command.Scene) parse$default).id);
            if (str == null) {
                str = "";
            }
            say = new Say("talk.scene", MapsKt__MapsKt.mapOf(new Pair("name", str)));
        } else if ((parse$default instanceof Command.Close) && !z) {
            say = new Say("talk.close_needs_adb", MapsKt__MapsKt.mapOf(new Pair("name", ((Command.Close) parse$default).name)));
        } else {
            say = say(parse$default);
        }
        return new Plan(parse$default, say);
    }

    /* loaded from: classes.dex */
    public final class Say {
        public final Map args;
        public final String id;

        public Say(String str) {
            EmptyMap emptyMap = EmptyMap.INSTANCE;
            this.id = str;
            this.args = emptyMap;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof Say)) {
                return false;
            }
            Say say = (Say) obj;
            return Intrinsics.areEqual(this.id, say.id) && Intrinsics.areEqual(this.args, say.args);
        }

        public final int hashCode() {
            return this.args.hashCode() + (this.id.hashCode() * 31);
        }

        public final String toString() {
            return "Say(id=" + this.id + ", args=" + this.args + ")";
        }

        public Say(String str, Map map) {
            this.id = str;
            this.args = map;
        }
    }
}
