package dev.tvremote.core;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Looper;
import java.io.File;
import java.io.FileOutputStream;

/* loaded from: classes.dex */
public final class Meta {
    public static void main(String[] strArr) {
        String str;
        Drawable drawable;
        int i;
        File file = new File(strArr[0]);
        file.mkdirs();
        Looper.prepareMainLooper();
        Class<?> cls = Class.forName("android.app.ActivityThread");
        PackageManager packageManager = ((Context) cls.getMethod("getSystemContext", new Class[0]).invoke(cls.getMethod("systemMain", new Class[0]).invoke(null, new Object[0]), new Object[0])).getPackageManager();
        for (ApplicationInfo applicationInfo : packageManager.getInstalledApplications(0)) {
            String str2 = applicationInfo.packageName;
            try {
                str = applicationInfo.loadLabel(packageManager).toString();
            } catch (Exception unused) {
                str = str2;
            }
            System.out.println(str2 + "\t" + str.replace('\n', ' ').replace('\t', ' '));
            File file2 = new File(file, Census$$ExternalSyntheticOutline0.m(str2, ".png"));
            boolean z = true;
            if ((applicationInfo.flags & 1) == 0 || packageManager.getLeanbackLaunchIntentForPackage(str2) != null || packageManager.getLaunchIntentForPackage(str2) != null) {
                if (file2.length() <= 0 || file2.lastModified() < new File(applicationInfo.sourceDir).lastModified()) {
                    try {
                        drawable = packageManager.getApplicationBanner(applicationInfo);
                    } catch (Exception unused2) {
                        drawable = null;
                    }
                    if (drawable == null) {
                        z = false;
                    }
                    if (!z) {
                        try {
                            drawable = packageManager.getApplicationIcon(applicationInfo);
                        } catch (Exception unused3) {
                        }
                    }
                    int i2 = 96;
                    if (z) {
                        i = 240;
                    } else {
                        i = 96;
                    }
                    if (z) {
                        i2 = 135;
                    }
                    Bitmap createBitmap = Bitmap.createBitmap(i, i2, Bitmap.Config.ARGB_8888);
                    drawable.setBounds(0, 0, createBitmap.getWidth(), createBitmap.getHeight());
                    drawable.draw(new Canvas(createBitmap));
                    File file3 = new File(file, str2 + ".tmp");
                    FileOutputStream fileOutputStream = new FileOutputStream(file3);
                    try {
                        createBitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
                        fileOutputStream.close();
                        file3.renameTo(file2);
                    } catch (Throwable th) {
                        try {
                            fileOutputStream.close();
                        } catch (Throwable th2) {
                            th.addSuppressed(th2);
                        }
                        throw th;
                        break;
                    }
                }
            }
        }
        System.out.flush();
        System.exit(0);
    }
}
