package dev.tvremote.core;

import java.io.File;
import java.util.Comparator;
import kotlin.math.MathKt;

/* loaded from: classes.dex */
public final class SupportAndroid$prefs$lambda$1$$inlined$sortedBy$1 implements Comparator {
    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        return MathKt.compareValues(((File) obj).getName(), ((File) obj2).getName());
    }
}
