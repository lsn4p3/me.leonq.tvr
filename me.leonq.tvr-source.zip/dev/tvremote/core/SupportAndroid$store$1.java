package dev.tvremote.core;

import android.content.SharedPreferences;
import android.media.AudioTimestamp;
import android.media.AudioTrack;
import android.media.MediaCodec;
import android.media.MediaCrypto;
import android.media.MediaFormat;
import android.os.Build;
import android.view.Surface;
import com.android.apksig.KeyConfig$Jca;
import com.android.apksig.internal.util.Pair;
import com.android.apksig.util.DataSink;
import dev.tvremote.core.ontv.Games;
import dev.tvremote.core.ontv.Tailscale;
import dev.tvremote.core.picture.AudioOut;
import dev.tvremote.core.picture.SoundPace;
import dev.tvremote.core.picture.SoundQueue;
import dev.tvremote.phone.media.TalkKt$$ExternalSyntheticLambda1;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.MessageDigest;
import java.security.cert.X509Certificate;
import java.util.Iterator;
import java.util.Map;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;

/* loaded from: classes.dex */
public final class SupportAndroid$store$1 implements DataSink {
    public Object $p;
    public final /* synthetic */ int $r8$classId;

    public /* synthetic */ SupportAndroid$store$1() {
        this.$r8$classId = 3;
    }

    /* JADX WARN: Code restructure failed: missing block: B:136:0x0272, code lost:
    
        if ((r14 - r6.lastDrop) >= 10000) goto L77;
     */
    /* JADX WARN: Removed duplicated region for block: B:100:0x0400  */
    /* JADX WARN: Removed duplicated region for block: B:108:0x03a2  */
    /* JADX WARN: Removed duplicated region for block: B:113:0x02c5  */
    /* JADX WARN: Removed duplicated region for block: B:64:0x02ab  */
    /* JADX WARN: Removed duplicated region for block: B:71:0x0312  */
    /* JADX WARN: Removed duplicated region for block: B:82:0x03aa  */
    /* JADX WARN: Removed duplicated region for block: B:93:0x03eb  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void audio(byte[] bArr, boolean z) {
        int dequeueInputBuffer;
        ByteBuffer inputBuffer;
        MediaCodec.BufferInfo bufferInfo;
        long j;
        int i;
        int i2;
        long j2;
        SoundQueue.Do r27;
        boolean z2;
        SoundQueue.Do r13;
        int i3;
        int ordinal;
        AudioTrack audioTrack;
        long currentTimeMillis;
        int i4;
        String str;
        String str2;
        int i5;
        int i6;
        AudioOut audioOut = (AudioOut) this.$p;
        audioOut.getClass();
        int i7 = 48000;
        if (z) {
            audioOut.release();
            String str3 = audioOut.mime;
            MediaFormat createAudioFormat = MediaFormat.createAudioFormat(str3, 48000, 2);
            Intrinsics.checkNotNullExpressionValue(createAudioFormat, "createAudioFormat(...)");
            createAudioFormat.setByteBuffer("csd-0", ByteBuffer.wrap(bArr));
            if (Intrinsics.areEqual(str3, "audio/opus")) {
                if (bArr.length >= 12) {
                    i6 = ((bArr[11] & 255) << 8) | (bArr[10] & 255);
                } else {
                    i6 = 312;
                }
                long j3 = (i6 * 1000000000) / 48000;
                ByteBuffer allocate = ByteBuffer.allocate(8);
                ByteOrder byteOrder = ByteOrder.LITTLE_ENDIAN;
                ByteBuffer putLong = allocate.order(byteOrder).putLong(j3);
                putLong.flip();
                createAudioFormat.setByteBuffer("csd-1", putLong);
                ByteBuffer putLong2 = ByteBuffer.allocate(8).order(byteOrder).putLong(80000000L);
                putLong2.flip();
                createAudioFormat.setByteBuffer("csd-2", putLong2);
            }
            MediaCodec createDecoderByType = MediaCodec.createDecoderByType(str3);
            Intrinsics.checkNotNullExpressionValue(createDecoderByType, "createDecoderByType(...)");
            createDecoderByType.configure(createAudioFormat, (Surface) null, (MediaCrypto) null, 0);
            createDecoderByType.start();
            audioOut.codec = createDecoderByType;
            int minBufferSize = AudioTrack.getMinBufferSize(48000, 12, 2) * 2;
            int i8 = Build.VERSION.SDK_INT;
            if (i8 >= 24) {
                i5 = 403200;
            } else {
                i5 = 38400;
            }
            AudioTrack audioTrack2 = new AudioTrack(3, 48000, 12, 2, Math.max(minBufferSize, i5), 1);
            audioOut.q = new SoundQueue(audioOut.base, audioOut.getFirst());
            audioOut.held.clear();
            int i9 = audioOut.q.target + 1920;
            audioOut.room = i9;
            if (i8 >= 24) {
                audioTrack2.setBufferSizeInFrames(i9);
            }
            audioTrack2.play();
            audioOut.track = audioTrack2;
            if (Fleet.times != 1.0f) {
                audioOut.boost(audioTrack2);
            }
            audioOut.written = 0L;
            return;
        }
        MediaCodec mediaCodec = audioOut.codec;
        if (mediaCodec != null && (dequeueInputBuffer = mediaCodec.dequeueInputBuffer(20000L)) >= 0 && (inputBuffer = mediaCodec.getInputBuffer(dequeueInputBuffer)) != null) {
            inputBuffer.clear();
            inputBuffer.put(bArr);
            mediaCodec.queueInputBuffer(dequeueInputBuffer, 0, bArr.length, 0L, 0);
            MediaCodec.BufferInfo bufferInfo2 = new MediaCodec.BufferInfo();
            long j4 = 0;
            while (true) {
                int dequeueOutputBuffer = mediaCodec.dequeueOutputBuffer(bufferInfo2, j4);
                if (dequeueOutputBuffer >= 0) {
                    AudioTrack audioTrack3 = audioOut.track;
                    ByteBuffer outputBuffer = mediaCodec.getOutputBuffer(dequeueOutputBuffer);
                    if (audioTrack3 != null && outputBuffer != null && bufferInfo2.size > 0) {
                        if (audioOut.loudAt != Fleet.times) {
                            audioOut.boost(audioTrack3);
                        }
                        long j5 = audioOut.written;
                        long playbackHeadPosition = audioTrack3.getPlaybackHeadPosition() & 4294967295L;
                        AudioTimestamp audioTimestamp = audioOut.stamp;
                        if (audioTrack3.getTimestamp(audioTimestamp)) {
                            playbackHeadPosition = Math.min(audioOut.written, Math.max(playbackHeadPosition, (((System.nanoTime() - audioTimestamp.nanoTime) * i7) / 1000000000) + audioTimestamp.framePosition));
                        }
                        long j6 = j5 - playbackHeadPosition;
                        int i10 = bufferInfo2.size;
                        byte[] bArr2 = new byte[i10];
                        outputBuffer.position(bufferInfo2.offset);
                        outputBuffer.get(bArr2);
                        SoundQueue soundQueue = audioOut.q;
                        int i11 = soundQueue.target;
                        int i12 = i10 / 4;
                        long nanoTime = System.nanoTime() / 1000000;
                        long j7 = 1000;
                        long j8 = 48000;
                        long j9 = (nanoTime - soundQueue.lastAt) - ((soundQueue.lastBehind * j7) / j8);
                        soundQueue.lastAt = nanoTime;
                        bufferInfo = bufferInfo2;
                        long j10 = i12;
                        soundQueue.lastBehind = Math.max(0L, j6) + j10;
                        int i13 = soundQueue.heldFrames;
                        int i14 = soundQueue.base;
                        SoundQueue.Do r132 = SoundQueue.Do.PLAY;
                        if (i13 == 0 && j6 <= 0) {
                            if (soundQueue.played) {
                                i2 = i12;
                                j2 = j10;
                                r27 = r132;
                                long max = Math.max(0L, j9);
                                soundQueue.gaps++;
                                soundQueue.gapMs += max;
                                soundQueue.gapMax = Math.max(soundQueue.gapMax, max);
                            } else {
                                i2 = i12;
                                j2 = j10;
                                r27 = r132;
                            }
                            if (soundQueue.played && nanoTime - soundQueue.started > 3000) {
                                soundQueue.target = Math.min(48000, Math.max(soundQueue.target * 2, i14 + ((int) ((j9 * j8) / j7))));
                            }
                            soundQueue.calm = nanoTime;
                        } else {
                            i2 = i12;
                            j2 = j10;
                            r27 = r132;
                            if (i13 == 0) {
                                int i15 = soundQueue.target;
                                if (i15 > i14 && nanoTime - soundQueue.calm > 120000) {
                                    soundQueue.target = Math.max(i14, (i15 * 4) / 5);
                                    soundQueue.calm = nanoTime;
                                }
                                if (!soundQueue.cutting) {
                                    int i16 = soundQueue.target;
                                    if (j6 >= Math.max(9600, i16 / 2) + i16 + 1920) {
                                    }
                                    r13 = r27;
                                    i3 = 1;
                                    ordinal = r13.ordinal();
                                    if (ordinal != 0) {
                                        if (ordinal != i3) {
                                            if (ordinal == 2) {
                                                audioOut.drops += i3;
                                            } else {
                                                throw new RuntimeException();
                                            }
                                        } else {
                                            audioOut.held.add(bArr2);
                                        }
                                        audioTrack = audioTrack3;
                                    } else {
                                        Iterator it = audioOut.held.iterator();
                                        Intrinsics.checkNotNullExpressionValue(it, "iterator(...)");
                                        while (it.hasNext()) {
                                            Object next = it.next();
                                            Intrinsics.checkNotNullExpressionValue(next, "next(...)");
                                            byte[] bArr3 = (byte[]) next;
                                            audioTrack3.write(bArr3, 0, bArr3.length);
                                            audioOut.written += bArr3.length / 4;
                                        }
                                        audioTrack = audioTrack3;
                                        audioOut.held.clear();
                                        audioTrack.write(bArr2, 0, i10);
                                        audioOut.written += j2;
                                    }
                                    currentTimeMillis = System.currentTimeMillis();
                                    if (currentTimeMillis - audioOut.told > 30000) {
                                        SoundQueue soundQueue2 = audioOut.q;
                                        int i17 = soundQueue2.gaps;
                                        if (i17 == 0) {
                                            str = null;
                                            j = 0;
                                        } else {
                                            str = i17 + " gaps, " + soundQueue2.gapMs + " ms in all, longest " + soundQueue2.gapMax + " ms";
                                            soundQueue2.gaps = 0;
                                            j = 0;
                                            soundQueue2.gapMs = 0L;
                                            soundQueue2.gapMax = 0L;
                                        }
                                        int i18 = audioOut.drops;
                                        if (i18 > 0 || audioOut.dry > 0 || str != null) {
                                            WireLog wireLog = WireLog.all;
                                            int i19 = audioOut.dry;
                                            int i20 = (audioOut.q.target * 1000) / 48000;
                                            if (str == null || (str2 = ", ".concat(str)) == null) {
                                                str2 = "";
                                            }
                                            wireLog.add("·", "sound: " + i18 + " packets dropped, ran dry " + i19 + " times, keeping " + i20 + " ms" + str2);
                                        }
                                        audioOut.told = currentTimeMillis;
                                        audioOut.drops = 0;
                                        audioOut.dry = 0;
                                    } else {
                                        j = 0;
                                    }
                                    i4 = audioOut.q.target;
                                    if (i4 != i11) {
                                        if (i4 > i11) {
                                            audioOut.dry++;
                                        }
                                        if (audioOut.host.length() > 0) {
                                            boolean z3 = SoundPace.even;
                                            if (!SoundPace.even) {
                                                SoundPace.learned.put(audioOut.host, Integer.valueOf((audioOut.q.target * 1000) / 48000));
                                                TalkKt$$ExternalSyntheticLambda1 talkKt$$ExternalSyntheticLambda1 = SoundPace.changed;
                                                if (talkKt$$ExternalSyntheticLambda1 != null) {
                                                    talkKt$$ExternalSyntheticLambda1.invoke();
                                                }
                                                if (Build.VERSION.SDK_INT >= 24) {
                                                    int i21 = audioOut.q.target;
                                                    if (i21 + 1920 != audioOut.room) {
                                                        int i22 = i21 + 1920;
                                                        audioTrack.setBufferSizeInFrames(i22);
                                                        audioOut.room = i22;
                                                    }
                                                }
                                            }
                                        }
                                        if (Build.VERSION.SDK_INT >= 24) {
                                        }
                                    }
                                    i = dequeueOutputBuffer;
                                }
                                if (j6 > soundQueue.target) {
                                    z2 = true;
                                } else {
                                    z2 = false;
                                }
                                soundQueue.cutting = z2;
                                soundQueue.lastDrop = nanoTime;
                                if (z2) {
                                    r13 = SoundQueue.Do.DROP;
                                    i3 = 1;
                                    ordinal = r13.ordinal();
                                    if (ordinal != 0) {
                                    }
                                    currentTimeMillis = System.currentTimeMillis();
                                    if (currentTimeMillis - audioOut.told > 30000) {
                                    }
                                    i4 = audioOut.q.target;
                                    if (i4 != i11) {
                                    }
                                    i = dequeueOutputBuffer;
                                }
                                r13 = r27;
                                i3 = 1;
                                ordinal = r13.ordinal();
                                if (ordinal != 0) {
                                }
                                currentTimeMillis = System.currentTimeMillis();
                                if (currentTimeMillis - audioOut.told > 30000) {
                                }
                                i4 = audioOut.q.target;
                                if (i4 != i11) {
                                }
                                i = dequeueOutputBuffer;
                            }
                        }
                        int i23 = soundQueue.heldFrames + i2;
                        soundQueue.heldFrames = i23;
                        if (i23 < soundQueue.target) {
                            r13 = SoundQueue.Do.HOLD;
                            i3 = 1;
                            ordinal = r13.ordinal();
                            if (ordinal != 0) {
                            }
                            currentTimeMillis = System.currentTimeMillis();
                            if (currentTimeMillis - audioOut.told > 30000) {
                            }
                            i4 = audioOut.q.target;
                            if (i4 != i11) {
                            }
                            i = dequeueOutputBuffer;
                        } else {
                            soundQueue.heldFrames = 0;
                            if (!soundQueue.played) {
                                soundQueue.started = nanoTime;
                            }
                            i3 = 1;
                            soundQueue.played = true;
                            r13 = r27;
                            ordinal = r13.ordinal();
                            if (ordinal != 0) {
                            }
                            currentTimeMillis = System.currentTimeMillis();
                            if (currentTimeMillis - audioOut.told > 30000) {
                            }
                            i4 = audioOut.q.target;
                            if (i4 != i11) {
                            }
                            i = dequeueOutputBuffer;
                        }
                    } else {
                        bufferInfo = bufferInfo2;
                        j = 0;
                        i = dequeueOutputBuffer;
                    }
                    mediaCodec.releaseOutputBuffer(i, false);
                    bufferInfo2 = bufferInfo;
                    j4 = j;
                    i7 = 48000;
                } else {
                    return;
                }
            }
        }
    }

    @Override // com.android.apksig.util.DataSink
    public void consume(byte[] bArr, int i, int i2) {
        switch (this.$r8$classId) {
            case 4:
                for (MessageDigest messageDigest : (MessageDigest[]) this.$p) {
                    messageDigest.update(bArr, 0, i2);
                }
                return;
            default:
                for (DataSink dataSink : (DataSink[]) this.$p) {
                    dataSink.consume(bArr, 0, i2);
                }
                return;
        }
    }

    public String get(String key) {
        Intrinsics.checkNotNullParameter(key, "key");
        Object obj = ((SharedPreferences) this.$p).getAll().get(key);
        if (obj != null) {
            return obj.toString();
        }
        return null;
    }

    public void put(String key, String value) {
        Intrinsics.checkNotNullParameter(key, "key");
        Intrinsics.checkNotNullParameter(value, "value");
        ((SharedPreferences) this.$p).edit().putString(key, value).apply();
    }

    public /* synthetic */ SupportAndroid$store$1(int i, Object obj) {
        this.$r8$classId = i;
        this.$p = obj;
    }

    public SupportAndroid$store$1(String str) {
        this.$r8$classId = 6;
        Regex regex = Tailscale.LOGIN;
        this.$p = new AudioOut(Games.isAddress(str), str);
    }

    public SupportAndroid$store$1(KeyConfig$Jca keyConfig$Jca, X509Certificate x509Certificate) {
        this.$r8$classId = 1;
        this.$p = x509Certificate;
    }

    @Override // com.android.apksig.util.DataSink
    public void consume(ByteBuffer byteBuffer) {
        switch (this.$r8$classId) {
            case 4:
                int position = byteBuffer.position();
                for (MessageDigest messageDigest : (MessageDigest[]) this.$p) {
                    byteBuffer.position(position);
                    messageDigest.update(byteBuffer);
                }
                return;
            default:
                int position2 = byteBuffer.position();
                int i = 0;
                while (true) {
                    DataSink[] dataSinkArr = (DataSink[]) this.$p;
                    if (i >= dataSinkArr.length) {
                        return;
                    }
                    if (i > 0) {
                        byteBuffer.position(position2);
                    }
                    dataSinkArr[i].consume(byteBuffer);
                    i++;
                }
        }
    }

    public SupportAndroid$store$1(Pair pair, Map map) {
        this.$r8$classId = 2;
        this.$p = pair;
    }
}
