package dev.tvremote.core;

import android.os.Build;
import dev.tvremote.core.picture.TvAndroidKt$$ExternalSyntheticLambda0;
import dev.tvremote.core.remote.Lg$$ExternalSyntheticLambda2;
import dev.tvremote.phone.MainActivity$onCreate$2;
import dev.tvremote.phone.picker.NetKt$$ExternalSyntheticLambda1;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class SupportRelay {
    public final NetKt$$ExternalSyntheticLambda1 answer;
    public volatile String code;
    public volatile String lastKey;
    public volatile int left;
    public volatile String liveKey;
    public final Lan$$ExternalSyntheticLambda0 onOpen;
    public final TvAndroidKt$$ExternalSyntheticLambda0 report;
    public final SupportAndroid$store$1 store;
    public volatile Thread thread;
    public volatile long until;
    public final String version;

    public SupportRelay(String str, SupportAndroid$store$1 supportAndroid$store$1, TvAndroidKt$$ExternalSyntheticLambda0 tvAndroidKt$$ExternalSyntheticLambda0, NetKt$$ExternalSyntheticLambda1 netKt$$ExternalSyntheticLambda1) {
        String model = Build.MODEL;
        Intrinsics.checkNotNullParameter(model, "model");
        this.version = str;
        this.store = supportAndroid$store$1;
        this.report = tvAndroidKt$$ExternalSyntheticLambda0;
        this.answer = netKt$$ExternalSyntheticLambda1;
        this.onOpen = new Lan$$ExternalSyntheticLambda0(18);
        this.code = "";
        this.lastKey = "";
        this.liveKey = "";
        this.left = -1;
    }

    public static String base() {
        MainActivity$onCreate$2 mainActivity$onCreate$2 = Census.store;
        return Census$$ExternalSyntheticOutline0.m(StringsKt.trimEnd(Census.url, '/'), "/v1/support");
    }

    public static long ends(JSONObject jSONObject, long j) {
        long optLong = jSONObject.optLong("live");
        long optLong2 = jSONObject.optLong("now");
        if (optLong <= 0) {
            return 0L;
        }
        if (optLong2 > 0) {
            return (optLong - optLong2) + System.currentTimeMillis();
        }
        return j;
    }

    public static JSONObject post(String str, JSONObject jSONObject) {
        JSONObject put;
        try {
            URLConnection openConnection = new URL(str).openConnection();
            Intrinsics.checkNotNull(openConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
            HttpURLConnection httpURLConnection = (HttpURLConnection) openConnection;
            try {
                httpURLConnection.setConnectTimeout(6000);
                httpURLConnection.setReadTimeout(20000);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setRequestProperty("Content-Type", "application/json");
                OutputStream outputStream = httpURLConnection.getOutputStream();
                try {
                    String jSONObject2 = jSONObject.toString();
                    Intrinsics.checkNotNullExpressionValue(jSONObject2, "toString(...)");
                    Charset charset = Charsets.UTF_8;
                    byte[] bytes = jSONObject2.getBytes(charset);
                    Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                    outputStream.write(bytes);
                    outputStream.close();
                    if (httpURLConnection.getResponseCode() != 403 && httpURLConnection.getResponseCode() != 404 && httpURLConnection.getResponseCode() != 429) {
                        int responseCode = httpURLConnection.getResponseCode();
                        if (200 <= responseCode && responseCode < 300) {
                            InputStream inputStream = httpURLConnection.getInputStream();
                            try {
                                Intrinsics.checkNotNull(inputStream);
                                String str2 = new String(MathKt.readBytes(inputStream), charset);
                                inputStream.close();
                                if (StringsKt.isBlank(str2)) {
                                    put = new JSONObject();
                                } else {
                                    put = new JSONObject(str2);
                                }
                            } finally {
                            }
                        } else {
                            put = null;
                        }
                        return put;
                    }
                    put = new JSONObject().put("error", httpURLConnection.getResponseCode()).put("left", 0);
                    return put;
                } finally {
                }
            } finally {
                httpURLConnection.disconnect();
            }
        } catch (Exception unused) {
            return null;
        }
    }

    public final boolean open() {
        if (this.until > System.currentTimeMillis() && this.thread != null) {
            return true;
        }
        return false;
    }

    public final void run(long j, String str, String str2) {
        Thread thread = this.thread;
        if (thread != null) {
            thread.interrupt();
        }
        this.thread = null;
        this.until = j;
        this.code = str;
        this.liveKey = str2;
        this.store.put("live_code", str);
        this.store.put("live_key", str2);
        this.store.put("live_until", String.valueOf(j));
        this.onOpen.invoke(str);
        Thread thread2 = new Thread(new Lg$$ExternalSyntheticLambda2(this, str, str2, 1), "support");
        thread2.setDaemon(true);
        this.thread = thread2;
        thread2.start();
    }

    public final JSONObject state() {
        String str;
        JSONObject put = new JSONObject().put("open", open());
        if (open()) {
            str = this.code;
        } else {
            str = "";
        }
        JSONObject put2 = put.put("code", str);
        long j = 0;
        if (open()) {
            long currentTimeMillis = ((this.until - System.currentTimeMillis()) / 60000) + 1;
            if (currentTimeMillis >= 0) {
                j = currentTimeMillis;
            }
        }
        JSONObject put3 = put2.put("min", j).put("left", this.left);
        Intrinsics.checkNotNullExpressionValue(put3, "put(...)");
        return put3;
    }
}
