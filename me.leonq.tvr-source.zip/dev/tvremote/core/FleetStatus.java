package dev.tvremote.core;

import dev.tvremote.core.ontv.Bundle;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;

/* loaded from: classes.dex */
public abstract class FleetStatus {
    public static final Regex FOCUS = new Regex("u\\d+ ([\\w.]+)/");
    public static final LinkedHashMap KNOWN;
    public static final Set NOISE;

    /* loaded from: classes.dex */
    public final class Status {
        public final String android;
        public final String app;
        public final String appName;
        public final long at;
        public final boolean home;
        public final String host;
        public final int memFree;
        public final String model;
        public final String state;
        public final long uptime;

        public /* synthetic */ Status(String str, String str2, long j, int i) {
            this(str, (i & 2) != 0 ? "unknown" : str2, "", "", "", "", false, 0L, -1, (i & 512) != 0 ? 0L : j);
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof Status)) {
                return false;
            }
            Status status = (Status) obj;
            return Intrinsics.areEqual(this.host, status.host) && Intrinsics.areEqual(this.state, status.state) && Intrinsics.areEqual(this.model, status.model) && Intrinsics.areEqual(this.android, status.android) && Intrinsics.areEqual(this.app, status.app) && Intrinsics.areEqual(this.appName, status.appName) && this.home == status.home && this.uptime == status.uptime && this.memFree == status.memFree && this.at == status.at;
        }

        public final int hashCode() {
            int i;
            int hashCode = (this.appName.hashCode() + ((this.app.hashCode() + ((this.android.hashCode() + ((this.model.hashCode() + ((this.state.hashCode() + (this.host.hashCode() * 31)) * 31)) * 31)) * 31)) * 31)) * 31;
            if (this.home) {
                i = 1231;
            } else {
                i = 1237;
            }
            long j = this.uptime;
            int i2 = (((((hashCode + i) * 31) + ((int) (j ^ (j >>> 32)))) * 31) + this.memFree) * 31;
            long j2 = this.at;
            return i2 + ((int) (j2 ^ (j2 >>> 32)));
        }

        public final String toString() {
            return "Status(host=" + this.host + ", state=" + this.state + ", model=" + this.model + ", android=" + this.android + ", app=" + this.app + ", appName=" + this.appName + ", home=" + this.home + ", uptime=" + this.uptime + ", memFree=" + this.memFree + ", at=" + this.at + ")";
        }

        public Status(String host, String state, String model, String android, String app, String appName, boolean z, long j, int i, long j2) {
            Intrinsics.checkNotNullParameter(host, "host");
            Intrinsics.checkNotNullParameter(state, "state");
            Intrinsics.checkNotNullParameter(model, "model");
            Intrinsics.checkNotNullParameter(android, "android");
            Intrinsics.checkNotNullParameter(app, "app");
            Intrinsics.checkNotNullParameter(appName, "appName");
            this.host = host;
            this.state = state;
            this.model = model;
            this.android = android;
            this.app = app;
            this.appName = appName;
            this.home = z;
            this.uptime = j;
            this.memFree = i;
            this.at = j2;
        }
    }

    static {
        Map mapOf = MapsKt__MapsKt.mapOf(new Pair("com.google.android.youtube.tv", "YouTube"), new Pair("com.google.android.youtube.tvunplugged", "YouTube TV"), new Pair("com.netflix.ninja", "Netflix"), new Pair("com.amazon.amazonvideo.livingroom", "Prime Video"), new Pair("com.disney.disneyplus", "Disney+"), new Pair("com.google.android.apps.youtube.music", "YouTube Music"), new Pair("com.spotify.tv.android", "Spotify"), new Pair("com.plexapp.android", "Plex"), new Pair("org.xbmc.kodi", "Kodi"), new Pair("com.android.tv.settings", "Settings"), new Pair("com.android.vending", "Play Store"), new Pair("dev.tvremote.setup", "TV Setup"));
        List<Bundle.App> list = Bundle.apps;
        int mapCapacity = MapsKt__MapsKt.mapCapacity(CollectionsKt__IterablesKt.collectionSizeOrDefault(list));
        if (mapCapacity < 16) {
            mapCapacity = 16;
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap(mapCapacity);
        for (Bundle.App app : list) {
            linkedHashMap.put(app.pkg, app.name);
        }
        KNOWN = MapsKt__MapsKt.plus(mapOf, linkedHashMap);
        NOISE = SetsKt.setOf((Object[]) new String[]{"com", "org", "net", "tv", "android", "app", "apps", "google", "tvapp", "ninja", "livingroom"});
    }

    /* JADX WARN: Code restructure failed: missing block: B:16:0x00a6, code lost:
    
        if (r11 == null) goto L26;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static Status parse(long j, String host, String out) {
        String str;
        String str2;
        String str3;
        long j2;
        long j3;
        boolean z;
        long j4;
        int i;
        boolean z2;
        String str4;
        String str5;
        String str6;
        String str7;
        long j5;
        long j6;
        String str8;
        String str9;
        Long longOrNull;
        Object obj;
        String str10;
        Long longOrNull2;
        String str11;
        Long longOrNull3;
        Intrinsics.checkNotNullParameter(host, "host");
        Intrinsics.checkNotNullParameter(out, "out");
        List split$default = StringsKt.split$default(StringsKt__StringsJVMKt.replace$default(out, "\r", ""), new String[]{"#~#\n"}, 0, 6);
        ArrayList arrayList = new ArrayList(4);
        for (int i2 = 0; i2 < 4; i2++) {
            arrayList.add("");
        }
        ArrayList plus = CollectionsKt.plus(split$default, (Iterable) arrayList);
        Pattern compile = Pattern.compile("mWakefulness=(\\w+)");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        CharSequence input = (CharSequence) plus.get(0);
        Intrinsics.checkNotNullParameter(input, "input");
        Matcher matcher = compile.matcher(input);
        Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
        MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, input);
        if (access$findNext != null) {
            str = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1);
        } else {
            str = null;
        }
        if (str == null) {
            str2 = "up";
        } else if (str.equals("Awake") || str.equals("Dreaming")) {
            str2 = "on";
        } else {
            str2 = "standby";
        }
        if (str2.equals("on")) {
            MatcherMatchResult find = FOCUS.find((CharSequence) plus.get(1), 0);
            if (find != null) {
                str3 = (String) ((MatcherMatchResult$groupValues$1) find.getGroupValues()).get(1);
            } else {
                str3 = null;
            }
        }
        str3 = "";
        Pattern compile2 = Pattern.compile("MemTotal:\\s+(\\d+)");
        Intrinsics.checkNotNullExpressionValue(compile2, "compile(...)");
        CharSequence input2 = (CharSequence) plus.get(2);
        Intrinsics.checkNotNullParameter(input2, "input");
        Matcher matcher2 = compile2.matcher(input2);
        Intrinsics.checkNotNullExpressionValue(matcher2, "matcher(...)");
        MatcherMatchResult access$findNext2 = MathKt.access$findNext(matcher2, 0, input2);
        if (access$findNext2 != null && (str11 = (String) ((MatcherMatchResult$groupValues$1) access$findNext2.getGroupValues()).get(1)) != null && (longOrNull3 = StringsKt__StringNumberConversionsKt.toLongOrNull(str11)) != null) {
            j2 = longOrNull3.longValue();
        } else {
            j2 = 0;
        }
        Pattern compile3 = Pattern.compile("MemAvailable:\\s+(\\d+)");
        Intrinsics.checkNotNullExpressionValue(compile3, "compile(...)");
        CharSequence input3 = (CharSequence) plus.get(2);
        Intrinsics.checkNotNullParameter(input3, "input");
        Matcher matcher3 = compile3.matcher(input3);
        Intrinsics.checkNotNullExpressionValue(matcher3, "matcher(...)");
        MatcherMatchResult access$findNext3 = MathKt.access$findNext(matcher3, 0, input3);
        if (access$findNext3 != null && (str10 = (String) ((MatcherMatchResult$groupValues$1) access$findNext3.getGroupValues()).get(1)) != null && (longOrNull2 = StringsKt__StringNumberConversionsKt.toLongOrNull(str10)) != null) {
            j3 = longOrNull2.longValue();
        } else {
            j3 = 0;
        }
        List split$default2 = StringsKt.split$default(StringsKt.trim((String) plus.get(3)).toString(), new String[]{"\n"}, 0, 6);
        ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(split$default2));
        Iterator it = split$default2.iterator();
        while (it.hasNext()) {
            arrayList2.add(StringsKt.trim((String) it.next()).toString());
        }
        ArrayList arrayList3 = new ArrayList(3);
        for (int i3 = 0; i3 < 3; i3++) {
            arrayList3.add("");
        }
        ArrayList plus2 = CollectionsKt.plus((List) arrayList2, (Iterable) arrayList3);
        String str12 = (String) plus2.get(0);
        String str13 = (String) plus2.get(1);
        String str14 = "";
        if (!StringsKt__StringsJVMKt.startsWith(str13, true, str12) && str12.length() != 0) {
            str13 = Census$$ExternalSyntheticOutline0.m(str12, " ", str13);
        }
        String obj2 = StringsKt.trim(str13).toString();
        String str15 = (String) plus2.get(2);
        String str16 = (String) KNOWN.get(str3);
        if (str16 == null) {
            if (str3.length() != 0 && (!StringsKt.contains(str3, "launcher", false) || StringsKt__StringsJVMKt.startsWith(str3, false, "dev.tvremote"))) {
                Iterator it2 = StringsKt.split$default(str3, new char[]{'.'}).iterator();
                while (true) {
                    if (it2.hasNext()) {
                        obj = it2.next();
                        if (!NOISE.contains((String) obj)) {
                            break;
                        }
                    } else {
                        obj = null;
                        break;
                    }
                }
                String str17 = (String) obj;
                if (str17 != null) {
                    str14 = str17;
                }
                if (str14.length() > 0) {
                    StringBuilder sb = new StringBuilder();
                    String valueOf = String.valueOf(str14.charAt(0));
                    Intrinsics.checkNotNull(valueOf, "null cannot be cast to non-null type java.lang.String");
                    String upperCase = valueOf.toUpperCase(Locale.ROOT);
                    Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
                    sb.append((Object) upperCase);
                    String substring = str14.substring(1);
                    Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
                    sb.append(substring);
                    str14 = sb.toString();
                }
            }
        } else {
            str14 = str16;
        }
        if (str3.length() > 0 && StringsKt.contains(str3, "launcher", false) && !StringsKt__StringsJVMKt.startsWith(str3, false, "dev.tvremote")) {
            z = true;
        } else {
            z = false;
        }
        Pattern compile4 = Pattern.compile("^(\\d+)");
        Intrinsics.checkNotNullExpressionValue(compile4, "compile(...)");
        String input4 = StringsKt.trim((String) plus.get(2)).toString();
        Intrinsics.checkNotNullParameter(input4, "input");
        Matcher matcher4 = compile4.matcher(input4);
        Intrinsics.checkNotNullExpressionValue(matcher4, "matcher(...)");
        MatcherMatchResult access$findNext4 = MathKt.access$findNext(matcher4, 0, input4);
        if (access$findNext4 != null && (str9 = (String) ((MatcherMatchResult$groupValues$1) access$findNext4.getGroupValues()).get(1)) != null && (longOrNull = StringsKt__StringNumberConversionsKt.toLongOrNull(str9)) != null) {
            j4 = longOrNull.longValue();
        } else {
            j4 = 0;
        }
        if (j2 > 0 && j3 > 0) {
            i = (int) ((j3 * 100) / j2);
            z2 = z;
            str7 = str14;
            j5 = j;
            str8 = str2;
            str4 = str15;
            str5 = obj2;
            str6 = str3;
            j6 = j4;
        } else {
            i = -1;
            z2 = z;
            str4 = str15;
            str5 = obj2;
            str6 = str3;
            str7 = str14;
            j5 = j;
            j6 = j4;
            str8 = str2;
        }
        return new Status(host, str8, str5, str4, str6, str7, z2, j6, i, j5);
    }
}
