package dev.tvremote.tvapps;

import android.net.IpPrefix;
import android.net.RouteInfo;
import android.util.Log;
import dev.tvremote.core.FleetStatus;
import dev.tvremote.core.FleetStatus$read$1;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda4;
import dev.tvremote.phone.ir.IrProfile;
import dev.tvremote.phone.picker.AppRow;
import dev.tvremote.phone.picker.ManyTvsKt;
import dev.tvremote.phone.picker.TvStatus;
import java.io.File;
import java.net.InetAddress;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import org.conscrypt.FileClientSessionCache;
import org.conscrypt.metrics.ConscryptStatsLog;

/* loaded from: classes.dex */
public final /* synthetic */ class ApkCert$$ExternalSyntheticLambda0 implements Function1 {
    public final /* synthetic */ int $r8$classId;

    public /* synthetic */ ApkCert$$ExternalSyntheticLambda0(int i) {
        this.$r8$classId = i;
    }

    /* JADX WARN: Type inference failed for: r1v15, types: [java.util.Map, java.lang.Object] */
    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        String hostAddress;
        String concat;
        AdbLink adbLink;
        FleetStatus.Status status;
        String str = "";
        boolean z = false;
        switch (this.$r8$classId) {
            case 0:
                Byte b = (Byte) obj;
                b.byteValue();
                return String.format("%02x", Arrays.copyOf(new Object[]{b}, 1));
            case 1:
                Map.Entry it = (Map.Entry) obj;
                Intrinsics.checkNotNullParameter(it, "it");
                Object key = it.getKey();
                Object value = it.getValue();
                Intrinsics.checkNotNullExpressionValue(value, "<get-value>(...)");
                return key + "=" + Long.toHexString(((Number) value).longValue());
            case 2:
                Pair it2 = (Pair) obj;
                Intrinsics.checkNotNullParameter(it2, "it");
                return (String) MapsKt__MapsKt.getValue(((IrProfile) it2.first).keys, "VOL_UP");
            case 3:
                Pair it3 = (Pair) obj;
                Intrinsics.checkNotNullParameter(it3, "it");
                return (CharSequence) it3.second;
            case 4:
                String hostAddress2 = ((InetAddress) obj).getHostAddress();
                if (hostAddress2 == null) {
                    return "";
                }
                return hostAddress2;
            case 5:
                RouteInfo routeInfo = (RouteInfo) obj;
                IpPrefix destination = routeInfo.getDestination();
                InetAddress gateway = routeInfo.getGateway();
                if (gateway != null && (hostAddress = gateway.getHostAddress()) != null && (concat = " via ".concat(hostAddress)) != null) {
                    str = concat;
                }
                return destination + str;
            case 6:
                String p = (String) obj;
                Intrinsics.checkNotNullParameter(p, "p");
                String str2 = (String) ManyTvsKt.checkoutNames.get(p);
                if (str2 == null) {
                    return StringsKt.substringAfterLast(p, '.', p);
                }
                return str2;
            case 7:
                AppRow it4 = (AppRow) obj;
                Intrinsics.checkNotNullParameter(it4, "it");
                return Integer.valueOf(-it4.on.size());
            case 8:
                AppRow it5 = (AppRow) obj;
                Intrinsics.checkNotNullParameter(it5, "it");
                String lowerCase = it5.name.toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                return lowerCase;
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                AppRow it6 = (AppRow) obj;
                Intrinsics.checkNotNullParameter(it6, "it");
                return "• " + it6.name;
            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                String it7 = (String) obj;
                Intrinsics.checkNotNullParameter(it7, "it");
                return it7.concat("x");
            case 11:
                List it8 = (List) obj;
                Intrinsics.checkNotNullParameter(it8, "it");
                return it8.get(1) + " " + it8.get(2) + " → " + it8.get(3);
            case FileClientSessionCache.MAX_SIZE /* 12 */:
                List it9 = (List) obj;
                Intrinsics.checkNotNullParameter(it9, "it");
                return "'" + it9.get(0) + "'";
            case 13:
                List it10 = (List) obj;
                Intrinsics.checkNotNullParameter(it10, "it");
                return it10.get(1) + " " + it10.get(3);
            case 14:
                Throwable it11 = (Throwable) obj;
                Intrinsics.checkNotNullParameter(it11, "it");
                return it11.getCause();
            case 15:
                String it12 = (String) obj;
                Intrinsics.checkNotNullParameter(it12, "it");
                boolean z2 = TvStatus.shots;
                Triple triple = (Triple) TvStatus.resolve.invoke(it12);
                if (triple == null) {
                    return new FleetStatus.Status(it12, null, 0L, 1022);
                }
                String host = (String) triple.first;
                String kind = (String) triple.second;
                File file = (File) triple.third;
                if (Intrinsics.areEqual(kind, "android")) {
                    adbLink = TvStatus.link(file, it12, host);
                } else {
                    adbLink = null;
                }
                Regex regex = FleetStatus.FOCUS;
                Guard$$ExternalSyntheticLambda4 guard$$ExternalSyntheticLambda4 = new Guard$$ExternalSyntheticLambda4(host, 6);
                FleetStatus$read$1 fleetStatus$read$1 = FleetStatus$read$1.INSTANCE;
                Intrinsics.checkNotNullParameter(host, "host");
                Intrinsics.checkNotNullParameter(kind, "kind");
                String str3 = "up";
                if (!kind.equals("android")) {
                    List ports = Remote.Kind.ports(kind);
                    if (!ports.isEmpty()) {
                        Iterator it13 = ports.iterator();
                        while (it13.hasNext()) {
                            if (((Boolean) guard$$ExternalSyntheticLambda4.invoke(Integer.valueOf(((Number) it13.next()).intValue()))).booleanValue()) {
                                status = new FleetStatus.Status(host, str3, ((Number) fleetStatus$read$1.invoke()).longValue(), 508);
                            }
                        }
                    }
                    str3 = "off";
                    status = new FleetStatus.Status(host, str3, ((Number) fleetStatus$read$1.invoke()).longValue(), 508);
                } else if (!((Boolean) guard$$ExternalSyntheticLambda4.invoke(5555)).booleanValue()) {
                    if (!((Boolean) guard$$ExternalSyntheticLambda4.invoke(6466)).booleanValue()) {
                        str3 = "off";
                    }
                    status = new FleetStatus.Status(host, str3, ((Number) fleetStatus$read$1.invoke()).longValue(), 508);
                } else if (adbLink == null) {
                    status = new FleetStatus.Status(host, "up", ((Number) fleetStatus$read$1.invoke()).longValue(), 508);
                } else {
                    long nanoTime = System.nanoTime() + 3000000000L;
                    String state = adbLink.state();
                    while (state.equals("unknown") && System.nanoTime() < nanoTime) {
                        Thread.sleep(150L);
                        state = adbLink.state();
                    }
                    if (!state.equals("ready")) {
                        status = new FleetStatus.Status(host, "up", ((Number) fleetStatus$read$1.invoke()).longValue(), 508);
                    } else {
                        try {
                            status = FleetStatus.parse(((Number) fleetStatus$read$1.invoke()).longValue(), host, adbLink.get().shell(6000L, "dumpsys power 2>/dev/null | grep -m1 mWakefulness=; printf '\\043~\\043\\n'; dumpsys window 2>/dev/null | grep -m1 mCurrentFocus; printf '\\043~\\043\\n'; cat /proc/uptime; grep -E 'MemTotal|MemAvailable' /proc/meminfo; printf '\\043~\\043\\n'; getprop ro.product.manufacturer; getprop ro.product.model; getprop ro.build.version.release"));
                        } catch (Exception unused) {
                            status = new FleetStatus.Status(host, "up", ((Number) fleetStatus$read$1.invoke()).longValue(), 508);
                        }
                    }
                }
                String state2 = status.state;
                String model = status.model;
                String android = status.android;
                String app = status.app;
                String appName = status.appName;
                boolean z3 = status.home;
                long j = status.uptime;
                int i = status.memFree;
                long j2 = status.at;
                Intrinsics.checkNotNullParameter(state2, "state");
                Intrinsics.checkNotNullParameter(model, "model");
                Intrinsics.checkNotNullParameter(android, "android");
                Intrinsics.checkNotNullParameter(app, "app");
                Intrinsics.checkNotNullParameter(appName, "appName");
                return new FleetStatus.Status(it12, state2, model, android, app, appName, z3, j, i, j2);
            case 16:
                Intrinsics.checkNotNullParameter((String) obj, "it");
                return Unit.INSTANCE;
            case 17:
                String it14 = (String) obj;
                Intrinsics.checkNotNullParameter(it14, "it");
                Log.i("airstat", it14);
                return Unit.INSTANCE;
            case 18:
                Byte b2 = (Byte) obj;
                b2.byteValue();
                return String.format("%02x", Arrays.copyOf(new Object[]{b2}, 1));
            case 19:
                Byte b3 = (Byte) obj;
                b3.byteValue();
                return String.format("%02x", Arrays.copyOf(new Object[]{b3}, 1));
            default:
                if (obj == null) {
                    z = true;
                }
                return Boolean.valueOf(z);
        }
    }
}
