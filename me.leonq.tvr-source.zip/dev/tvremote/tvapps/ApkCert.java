package dev.tvremote.tvapps;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyMap;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;

/* loaded from: classes.dex */
public abstract class ApkCert {
    public static final byte[] MAGIC;

    /* loaded from: classes.dex */
    public final class Tlv {
        public final int start;
        public final int tag;
        public final int ve;
        public final int vs;

        public Tlv(int i, int i2, int i3, int i4) {
            this.tag = i;
            this.start = i2;
            this.vs = i3;
            this.ve = i4;
        }
    }

    static {
        byte[] bytes = "APK Sig Block 42".getBytes(Charsets.US_ASCII);
        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        MAGIC = bytes;
    }

    public static ByteBuffer block(RandomAccessFile randomAccessFile) {
        long length = randomAccessFile.length();
        int min = (int) Math.min(length, 65557L);
        byte[] bArr = new byte[min];
        randomAccessFile.seek(length - min);
        randomAccessFile.readFully(bArr);
        int i = min - 22;
        while (true) {
            if (-1 < i) {
                if (bArr[i] == 80 && bArr[i + 1] == 75 && bArr[i + 2] == 5 && bArr[i + 3] == 6) {
                    break;
                }
                i--;
            } else {
                i = -1;
                break;
            }
        }
        if (i >= 0) {
            ByteBuffer wrap = ByteBuffer.wrap(bArr, i + 16, 4);
            ByteOrder byteOrder = ByteOrder.LITTLE_ENDIAN;
            long j = wrap.order(byteOrder).getInt() & 4294967295L;
            if (j >= 32 && j <= length) {
                byte[] bArr2 = new byte[24];
                long j2 = 24;
                randomAccessFile.seek(j - j2);
                randomAccessFile.readFully(bArr2);
                if (!Arrays.equals(ArraysKt.copyOfRange(bArr2, 8, 24), MAGIC)) {
                    return null;
                }
                long j3 = ByteBuffer.wrap(bArr2, 0, 8).order(byteOrder).getLong();
                if (j3 >= 24 && j3 <= j - 8 && j3 <= 33554432) {
                    byte[] bArr3 = new byte[(int) (j3 - j2)];
                    randomAccessFile.seek(j - j3);
                    randomAccessFile.readFully(bArr3);
                    return ByteBuffer.wrap(bArr3).order(byteOrder);
                }
                throw new IOException("bad signing block");
            }
            throw new IOException("not an APK");
        }
        throw new IOException("not an APK");
    }

    public static ArrayList children(byte[] bArr, int i, int i2) {
        ArrayList arrayList = new ArrayList();
        while (i < i2) {
            Tlv der = der(bArr, i, i2);
            arrayList.add(der);
            i = der.ve;
        }
        return arrayList;
    }

    public static Tlv der(byte[] bArr, int i, int i2) {
        int i3 = i + 2;
        if (i3 <= i2) {
            int i4 = bArr[i] & 255;
            int i5 = bArr[i + 1];
            int i6 = i5 & 255;
            if (i6 >= 128) {
                int i7 = i5 & 127;
                if (i7 != 0 && i7 <= 3 && i3 + i7 <= i2) {
                    int i8 = 0;
                    int i9 = 0;
                    while (i8 < i7) {
                        i9 = (i9 << 8) | (bArr[i3] & 255);
                        i8++;
                        i3++;
                    }
                    i6 = i9;
                } else {
                    throw new IOException("bad signature file");
                }
            }
            int i10 = i6 + i3;
            if (i10 <= i2) {
                return new Tlv(i4, i, i3, i10);
            }
            throw new IOException("bad signature file");
        }
        throw new IOException("bad signature file");
    }

    public static Map read(File file) {
        String str;
        boolean z;
        RandomAccessFile randomAccessFile = new RandomAccessFile(file, "r");
        try {
            ByteBuffer block = block(randomAccessFile);
            if (block == null) {
                EmptyMap emptyMap = EmptyMap.INSTANCE;
                randomAccessFile.close();
                return emptyMap;
            }
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            while (block.remaining() >= 12) {
                long j = block.getLong();
                if (j >= 4 && j <= block.remaining()) {
                    int i = block.getInt();
                    ByteBuffer slice = slice(block, (int) (j - 4));
                    if (i != -262969152) {
                        if (i != 462663009) {
                            if (i != 1896449818) {
                                str = null;
                            } else {
                                str = "v2";
                            }
                        } else {
                            str = "v3.1";
                        }
                    } else {
                        str = "v3";
                    }
                    if (str != null) {
                        if (i != 1896449818) {
                            z = true;
                        } else {
                            z = false;
                        }
                        linkedHashMap.put(str, signers(slice, z));
                    }
                } else {
                    throw new IOException("bad signing block");
                }
            }
            ArrayList v1 = v1(file);
            if (v1 != null) {
                linkedHashMap.put("v1", v1);
            }
            randomAccessFile.close();
            return linkedHashMap;
        } catch (Throwable th) {
            try {
                throw th;
            } catch (Throwable th2) {
                MathKt.closeFinally(randomAccessFile, th);
                throw th2;
            }
        }
    }

    public static String sha256(byte[] bArr) {
        byte[] digest = MessageDigest.getInstance("SHA-256").digest(bArr);
        Intrinsics.checkNotNullExpressionValue(digest, "digest(...)");
        return ArraysKt.joinToString$default(digest, "", new ApkCert$$ExternalSyntheticLambda0(0));
    }

    public static ArrayList signerIds(byte[] bArr) {
        try {
            Tlv der = der(bArr, 0, bArr.length);
            Iterator it = children(bArr, der.vs, der.ve).iterator();
            while (it.hasNext()) {
                Object next = it.next();
                if (((Tlv) next).tag == 160) {
                    Tlv tlv = (Tlv) next;
                    Tlv tlv2 = (Tlv) CollectionsKt.first((List) children(bArr, tlv.vs, tlv.ve));
                    ArrayList children = children(bArr, tlv2.vs, tlv2.ve);
                    ListIterator listIterator = children.listIterator(children.size());
                    while (listIterator.hasPrevious()) {
                        Object previous = listIterator.previous();
                        if (((Tlv) previous).tag == 49) {
                            Tlv tlv3 = (Tlv) previous;
                            ArrayList children2 = children(bArr, tlv3.vs, tlv3.ve);
                            ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(children2));
                            Iterator it2 = children2.iterator();
                            while (it2.hasNext()) {
                                Tlv tlv4 = (Tlv) it2.next();
                                ArrayList children3 = children(bArr, tlv4.vs, tlv4.ve);
                                ArrayList children4 = children(bArr, ((Tlv) children3.get(1)).vs, ((Tlv) children3.get(1)).ve);
                                Tlv tlv5 = (Tlv) children4.get(0);
                                arrayList.add(new Pair(ArraysKt.copyOfRange(bArr, tlv5.start, tlv5.ve), new BigInteger(ArraysKt.copyOfRange(bArr, ((Tlv) children4.get(1)).vs, ((Tlv) children4.get(1)).ve))));
                            }
                            if (!arrayList.isEmpty()) {
                                return arrayList;
                            }
                            throw new IOException("signature file without a signer");
                        }
                    }
                    throw new NoSuchElementException("List contains no element matching the predicate.");
                }
            }
            throw new NoSuchElementException("Collection contains no element matching the predicate.");
        } catch (IOException e) {
            throw e;
        } catch (RuntimeException unused) {
            throw new IOException("bad signature file");
        }
    }

    public static ArrayList signers(ByteBuffer byteBuffer, boolean z) {
        ByteBuffer slice = slice(byteBuffer, byteBuffer.getInt());
        ArrayList arrayList = new ArrayList();
        while (slice.hasRemaining()) {
            ByteBuffer slice2 = slice(slice, slice.getInt());
            ByteBuffer slice3 = slice(slice2, slice2.getInt());
            slice(slice3, slice3.getInt());
            ByteBuffer slice4 = slice(slice3, slice3.getInt());
            if (slice4.hasRemaining()) {
                ByteBuffer slice5 = slice(slice4, slice4.getInt());
                byte[] bArr = new byte[slice5.remaining()];
                slice5.get(bArr);
                arrayList.add(sha256(bArr));
                if (z) {
                    slice2.getInt();
                }
            } else {
                throw new IOException("signer without a certificate");
            }
        }
        return arrayList;
    }

    public static ByteBuffer slice(ByteBuffer byteBuffer, int i) {
        if (i >= 0 && i <= byteBuffer.remaining()) {
            ByteBuffer order = byteBuffer.slice().order(ByteOrder.LITTLE_ENDIAN);
            order.limit(i);
            byteBuffer.position(byteBuffer.position() + i);
            return order;
        }
        throw new IOException("bad signing block");
    }

    public static ArrayList v1(File file) {
        Object obj;
        ZipFile zipFile = new ZipFile(file);
        try {
            HashSet hashSet = new HashSet();
            Enumeration<? extends ZipEntry> entries = zipFile.entries();
            Intrinsics.checkNotNullExpressionValue(entries, "entries(...)");
            while (entries.hasMoreElements()) {
                String name = entries.nextElement().getName();
                Intrinsics.checkNotNullExpressionValue(name, "getName(...)");
                String upperCase = name.toUpperCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
                hashSet.add(upperCase);
            }
            ArrayList arrayList = new ArrayList();
            Enumeration<? extends ZipEntry> entries2 = zipFile.entries();
            Intrinsics.checkNotNullExpressionValue(entries2, "entries(...)");
            while (entries2.hasMoreElements()) {
                ZipEntry nextElement = entries2.nextElement();
                String name2 = nextElement.getName();
                Intrinsics.checkNotNullExpressionValue(name2, "getName(...)");
                String upperCase2 = name2.toUpperCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(upperCase2, "toUpperCase(...)");
                if (StringsKt__StringsJVMKt.startsWith(upperCase2, false, "META-INF/") && StringsKt.indexOf$default(upperCase2, '/', 4) < 0 && (StringsKt__StringsJVMKt.endsWith(upperCase2, false, ".RSA") || StringsKt__StringsJVMKt.endsWith(upperCase2, false, ".DSA") || StringsKt__StringsJVMKt.endsWith(upperCase2, false, ".EC"))) {
                    String substring = upperCase2.substring(0, StringsKt.lastIndexOf$default(upperCase2, '.', 6));
                    Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
                    if (!hashSet.contains(substring + ".SF")) {
                        continue;
                    } else if (nextElement.getSize() <= 1048576) {
                        InputStream inputStream = zipFile.getInputStream(nextElement);
                        try {
                            Intrinsics.checkNotNull(inputStream);
                            byte[] readBytes = MathKt.readBytes(inputStream);
                            inputStream.close();
                            try {
                                Collection<? extends Certificate> generateCertificates = CertificateFactory.getInstance("X.509").generateCertificates(new ByteArrayInputStream(readBytes));
                                Intrinsics.checkNotNullExpressionValue(generateCertificates, "generateCertificates(...)");
                                ArrayList arrayList2 = new ArrayList();
                                for (Object obj2 : generateCertificates) {
                                    if (obj2 instanceof X509Certificate) {
                                        arrayList2.add(obj2);
                                    }
                                }
                                if (!arrayList2.isEmpty()) {
                                    Iterator it = signerIds(readBytes).iterator();
                                    while (it.hasNext()) {
                                        Pair pair = (Pair) it.next();
                                        byte[] bArr = (byte[]) pair.first;
                                        BigInteger bigInteger = (BigInteger) pair.second;
                                        Iterator it2 = arrayList2.iterator();
                                        while (true) {
                                            if (it2.hasNext()) {
                                                obj = it2.next();
                                                X509Certificate x509Certificate = (X509Certificate) obj;
                                                if (Intrinsics.areEqual(x509Certificate.getSerialNumber(), bigInteger) && Arrays.equals(x509Certificate.getIssuerX500Principal().getEncoded(), bArr)) {
                                                    break;
                                                }
                                            } else {
                                                obj = null;
                                                break;
                                            }
                                        }
                                        X509Certificate x509Certificate2 = (X509Certificate) obj;
                                        if (x509Certificate2 != null) {
                                            byte[] encoded = x509Certificate2.getEncoded();
                                            Intrinsics.checkNotNullExpressionValue(encoded, "getEncoded(...)");
                                            arrayList.add(sha256(encoded));
                                        } else {
                                            throw new IOException("signer certificate missing");
                                        }
                                    }
                                } else {
                                    throw new IOException("signature file without a certificate");
                                }
                            } catch (GeneralSecurityException unused) {
                                throw new IOException("bad signature file");
                            }
                        } finally {
                        }
                    } else {
                        throw new IOException("bad signature file");
                    }
                }
            }
            if (arrayList.isEmpty()) {
                arrayList = null;
            }
            zipFile.close();
            return arrayList;
        } finally {
        }
    }
}
