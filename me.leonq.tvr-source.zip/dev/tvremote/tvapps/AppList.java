package dev.tvremote.tvapps;

import dev.tvremote.core.adb.Adb$$ExternalSyntheticLambda0;
import dev.tvremote.core.manage.TvAppsApi$$ExternalSyntheticLambda1;
import dev.tvremote.core.ontv.Home$$ExternalSyntheticLambda6;
import dev.tvremote.update.SignedList;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyList;
import kotlin.collections.EmptyMap;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgressionIterator;
import kotlin.ranges.IntRange;
import kotlin.sequences.ConstrainedOnceSequence;
import kotlin.sequences.Sequence;
import kotlin.sequences.SequencesKt;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class AppList {
    public static final AtomicBoolean asking;
    public static final List bases;
    public static final ConcurrentHashMap icons;
    public static final List keys;
    public static volatile Pair mem;

    /* loaded from: classes.dex */
    public final class App {
        public final Object also;
        public final LinkedHashMap apk;
        public final String cat;
        public final ArrayList certs;
        public final Object desc;
        public final String icon;
        public final String iconSha;
        public final String id;
        public final String license;
        public final int minSdk;
        public final String name;
        public final Object notes;
        public final String pkg;
        public final String setup;
        public final String source;

        public App(String str, String str2, String str3, String str4, Map map, Map map2, String str5, String str6, String str7, String str8, ArrayList arrayList, int i, LinkedHashMap linkedHashMap, String str9, List list) {
            this.id = str;
            this.pkg = str2;
            this.name = str3;
            this.cat = str4;
            this.desc = map;
            this.notes = map2;
            this.icon = str5;
            this.iconSha = str6;
            this.source = str7;
            this.license = str8;
            this.certs = arrayList;
            this.minSdk = i;
            this.apk = linkedHashMap;
            this.setup = str9;
            this.also = list;
        }
    }

    /* loaded from: classes.dex */
    public final class Cat {
        public final String id;
        public final Object name;

        public Cat(String str, Map map) {
            this.id = str;
            this.name = map;
        }
    }

    /* loaded from: classes.dex */
    public final class List_ {
        public final ArrayList apps;
        public final String base;
        public final ArrayList cats;
        public final String updated;

        public List_(String str, ArrayList arrayList, ArrayList arrayList2, String base) {
            Intrinsics.checkNotNullParameter(base, "base");
            this.updated = str;
            this.cats = arrayList;
            this.apps = arrayList2;
            this.base = base;
        }

        public final App get(String str) {
            Object obj;
            Iterator it = this.apps.iterator();
            while (true) {
                if (it.hasNext()) {
                    obj = it.next();
                    if (((App) obj).id.equals(str)) {
                        break;
                    }
                } else {
                    obj = null;
                    break;
                }
            }
            return (App) obj;
        }
    }

    /* loaded from: classes.dex */
    public final class Source {
        public final String match;
        public final String repo;
        public final String url;

        public Source(String url, String str, String str2) {
            Intrinsics.checkNotNullParameter(url, "url");
            this.url = url;
            this.repo = str;
            this.match = str2;
        }
    }

    static {
        List asList;
        String obj;
        String str = System.getenv("TVR_TVAPPS");
        if (str != null && (obj = StringsKt.trim(str).toString()) != null) {
            if (obj.length() <= 0) {
                obj = null;
            }
            if (obj != null) {
                if (!StringsKt__StringsJVMKt.endsWith(obj, false, "/")) {
                    obj = obj.concat("/");
                }
                asList = MathKt.listOf(obj);
                bases = asList;
                keys = SignedList.KEYS;
                asking = new AtomicBoolean();
                icons = new ConcurrentHashMap();
            }
        }
        asList = ArraysKt.asList(new String[]{"https://tvremote.pages.dev/apps/", "https://raw.githubusercontent.com/HoangTran0410/tv-remote/main/docs/apps/"});
        bases = asList;
        keys = SignedList.KEYS;
        asking = new AtomicBoolean();
        icons = new ConcurrentHashMap();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v11, types: [java.util.ArrayList] */
    /* JADX WARN: Type inference failed for: r4v7, types: [kotlin.collections.EmptyList] */
    /* JADX WARN: Type inference failed for: r4v8 */
    public static App app(JSONObject jSONObject) {
        ?? r4;
        Source source;
        JSONArray jSONArray = jSONObject.getJSONArray("certs");
        IntRange until = MathKt.until(0, jSONArray.length());
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until));
        Iterator it = until.iterator();
        while (((IntProgressionIterator) it).hasNext) {
            String string = jSONArray.getString(((IntProgressionIterator) it).nextInt());
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            String lowerCase = string.toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
            arrayList.add(StringsKt__StringsJVMKt.replace$default(lowerCase, ":", ""));
        }
        if (!arrayList.isEmpty()) {
            if (!arrayList.isEmpty()) {
                Iterator it2 = arrayList.iterator();
                while (it2.hasNext()) {
                    String input = (String) it2.next();
                    Pattern compile = Pattern.compile("[0-9a-f]{64}");
                    Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                    Intrinsics.checkNotNullParameter(input, "input");
                    if (!compile.matcher(input).matches()) {
                        return null;
                    }
                }
            }
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            JSONObject optJSONObject = jSONObject.optJSONObject("apk");
            if (optJSONObject == null) {
                optJSONObject = new JSONObject();
            }
            Iterator<String> keys2 = optJSONObject.keys();
            Intrinsics.checkNotNullExpressionValue(keys2, "keys(...)");
            while (keys2.hasNext()) {
                String next = keys2.next();
                Object obj = optJSONObject.get(next);
                if (obj instanceof String) {
                    source = new Source((String) obj, "", "");
                } else {
                    Intrinsics.checkNotNull(obj, "null cannot be cast to non-null type org.json.JSONObject");
                    JSONObject jSONObject2 = (JSONObject) obj;
                    String string2 = jSONObject2.getString("repo");
                    Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
                    String string3 = jSONObject2.getString("match");
                    Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
                    source = new Source("", string2, string3);
                }
                String str = source.url;
                if (str.length() <= 0 || StringsKt__StringsJVMKt.startsWith(str, false, "https://")) {
                    String str2 = source.repo;
                    if (str2.length() > 0) {
                        Pattern compile2 = Pattern.compile("[\\w.-]+/[\\w.-]+");
                        Intrinsics.checkNotNullExpressionValue(compile2, "compile(...)");
                        if (!compile2.matcher(str2).matches()) {
                            return null;
                        }
                    }
                    linkedHashMap.put(next, source);
                } else {
                    return null;
                }
            }
            String optString = jSONObject.optString("setup");
            if (linkedHashMap.isEmpty()) {
                Intrinsics.checkNotNull(optString);
                if (optString.length() == 0) {
                    return null;
                }
            }
            JSONArray optJSONArray = jSONObject.optJSONArray("also");
            if (optJSONArray != null) {
                IntRange until2 = MathKt.until(0, optJSONArray.length());
                r4 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until2));
                Iterator it3 = until2.iterator();
                while (((IntProgressionIterator) it3).hasNext) {
                    r4.add(optJSONArray.getString(((IntProgressionIterator) it3).nextInt()));
                }
            } else {
                r4 = EmptyList.INSTANCE;
            }
            List list = r4;
            String string4 = jSONObject.getString("id");
            Intrinsics.checkNotNullExpressionValue(string4, "getString(...)");
            String string5 = jSONObject.getString("pkg");
            Intrinsics.checkNotNullExpressionValue(string5, "getString(...)");
            String string6 = jSONObject.getString("name");
            Intrinsics.checkNotNullExpressionValue(string6, "getString(...)");
            String optString2 = jSONObject.optString("cat");
            Intrinsics.checkNotNullExpressionValue(optString2, "optString(...)");
            Map words = words(jSONObject.optJSONObject("desc"));
            Map words2 = words(jSONObject.optJSONObject("notes"));
            String optString3 = jSONObject.optString("icon");
            Intrinsics.checkNotNullExpressionValue(optString3, "optString(...)");
            String optString4 = jSONObject.optString("icon_sha");
            Intrinsics.checkNotNullExpressionValue(optString4, "optString(...)");
            String optString5 = jSONObject.optString("source");
            Intrinsics.checkNotNullExpressionValue(optString5, "optString(...)");
            String optString6 = jSONObject.optString("license");
            Intrinsics.checkNotNullExpressionValue(optString6, "optString(...)");
            int optInt = jSONObject.optInt("min_sdk", 21);
            Intrinsics.checkNotNull(optString);
            return new App(string4, string5, string6, optString2, words, words2, optString3, optString4, optString5, optString6, arrayList, optInt, linkedHashMap, optString, list);
        }
        return null;
    }

    public static List_ ask(File file) {
        List list = SignedList.KEYS;
        List_ list_ = (List_) SignedList.fetch$default(bases, "apps.json", keys, new AppList$$ExternalSyntheticLambda1(file, 0), 112);
        mem = new Pair(Long.valueOf(System.currentTimeMillis()), list_);
        return list_;
    }

    public static List_ fetch(File file, boolean z) {
        File file2;
        List_ list_;
        Pair pair = mem;
        if (pair != null && !z && System.currentTimeMillis() - ((Number) pair.first).longValue() < 60000) {
            return (List_) pair.second;
        }
        List_ list_2 = null;
        if (file != null) {
            file2 = new File(file, "apps.json");
        } else {
            file2 = null;
        }
        if (!z) {
            Pair pair2 = mem;
            if (pair2 != null && (list_ = (List_) pair2.second) != null) {
                list_2 = list_;
            } else if (file2 != null) {
                List list = SignedList.KEYS;
                byte[] kept = SignedList.kept(file2, keys);
                if (kept != null) {
                    list_2 = parse((String) CollectionsKt.first(bases), kept);
                }
            }
            if (list_2 != null) {
                if (asking.compareAndSet(false, true)) {
                    new Thread(new Adb$$ExternalSyntheticLambda0(12, file2)).start();
                }
                return list_2;
            }
        }
        try {
            return ask(file2);
        } catch (IOException e) {
            if (file2 != null) {
                List list2 = SignedList.KEYS;
                byte[] kept2 = SignedList.kept(file2, keys);
                if (kept2 != null) {
                    return parse((String) CollectionsKt.first(bases), kept2);
                }
            }
            throw new IOException("apps:offline", e);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:19:0x00b0, code lost:
    
        if (r6 != null) goto L21;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0255, code lost:
    
        throw new java.io.IOException("apps:noapk");
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static File get(App app, List list, File file, Home$$ExternalSyntheticLambda6 home$$ExternalSyntheticLambda6, TvAppsApi$$ExternalSyntheticLambda1 tvAppsApi$$ExternalSyntheticLambda1) {
        Source source;
        long j;
        Map map;
        int i;
        Long longOrNull;
        byte[] bArr;
        Pair pick = pick(app, list);
        if (pick != null && (source = (Source) pick.second) != null) {
            File file2 = new File(file, "tvapps-" + app.id + ".apk");
            String str = source.url;
            if (str.length() <= 0) {
                List list2 = SignedList.KEYS;
                bArr = SignedList.get("https://api.github.com/repos/" + source.repo + "/releases/latest", 1048576, 10000, 30000);
                JSONObject jSONObject = new JSONObject(new String(bArr, Charsets.UTF_8));
                Pattern compile = Pattern.compile(source.match);
                Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                JSONArray optJSONArray = jSONObject.optJSONArray("assets");
                if (optJSONArray == null) {
                    optJSONArray = new JSONArray();
                }
                int length = optJSONArray.length();
                int i2 = 0;
                while (true) {
                    if (i2 >= length) {
                        break;
                    }
                    JSONObject jSONObject2 = optJSONArray.getJSONObject(i2);
                    String string = jSONObject2.getString("name");
                    Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                    if (compile.matcher(string).matches()) {
                        String string2 = jSONObject2.getString("browser_download_url");
                        Intrinsics.checkNotNull(string2);
                        if (!StringsKt__StringsJVMKt.startsWith(string2, false, "https://")) {
                            string2 = null;
                        }
                        str = string2;
                    } else {
                        i2++;
                    }
                }
            }
            URLConnection openConnection = new URL(str).openConnection();
            Intrinsics.checkNotNull(openConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
            HttpURLConnection httpURLConnection = (HttpURLConnection) openConnection;
            httpURLConnection.setConnectTimeout(15000);
            httpURLConnection.setReadTimeout(30000);
            httpURLConnection.setInstanceFollowRedirects(true);
            httpURLConnection.setRequestProperty("User-Agent", "tv-remote");
            try {
                try {
                    if (httpURLConnection.getResponseCode() == 200) {
                        String headerField = httpURLConnection.getHeaderField("Content-Length");
                        if (headerField != null && (longOrNull = StringsKt__StringNumberConversionsKt.toLongOrNull(headerField)) != null) {
                            j = longOrNull.longValue();
                        } else {
                            j = -1;
                        }
                        long j2 = 419430400;
                        if (j <= 419430400) {
                            InputStream inputStream = httpURLConnection.getInputStream();
                            try {
                                FileOutputStream fileOutputStream = new FileOutputStream(file2);
                                try {
                                    byte[] bArr2 = new byte[65536];
                                    int i3 = -1;
                                    long j3 = 0;
                                    while (!((Boolean) tvAppsApi$$ExternalSyntheticLambda1.invoke()).booleanValue()) {
                                        long j4 = j2;
                                        int read = inputStream.read(bArr2);
                                        if (read > 0) {
                                            fileOutputStream.write(bArr2, 0, read);
                                            j3 += read;
                                            if (j3 <= j4) {
                                                if (j > 0 && (i = (int) ((100 * j3) / j)) != i3) {
                                                    home$$ExternalSyntheticLambda6.invoke(Integer.valueOf(i));
                                                    i3 = i;
                                                }
                                                j2 = j4;
                                            } else {
                                                throw new IOException("file too big");
                                            }
                                        } else {
                                            fileOutputStream.close();
                                            inputStream.close();
                                            try {
                                                map = ApkCert.read(file2);
                                            } catch (IOException unused) {
                                                map = EmptyMap.INSTANCE;
                                            }
                                            byte[] bArr3 = ApkCert.MAGIC;
                                            ArrayList arrayList = app.certs;
                                            ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList));
                                            Iterator it = arrayList.iterator();
                                            while (it.hasNext()) {
                                                String lowerCase = ((String) it.next()).toLowerCase(Locale.ROOT);
                                                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                                                arrayList2.add(StringsKt__StringsJVMKt.replace$default(lowerCase, ":", ""));
                                            }
                                            Set set = CollectionsKt.toSet(arrayList2);
                                            Set keySet = map.keySet();
                                            if (keySet == null || !keySet.isEmpty()) {
                                                Iterator it2 = keySet.iterator();
                                                while (true) {
                                                    if (!it2.hasNext()) {
                                                        break;
                                                    }
                                                    if (!Intrinsics.areEqual((String) it2.next(), "v1")) {
                                                        Collection<List> values = map.values();
                                                        if (values == null || !values.isEmpty()) {
                                                            for (List list3 : values) {
                                                                if (!list3.isEmpty()) {
                                                                    if (!list3.isEmpty()) {
                                                                        Iterator it3 = list3.iterator();
                                                                        while (it3.hasNext()) {
                                                                            if (set.contains((String) it3.next())) {
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        return file2;
                                                    }
                                                }
                                            }
                                            file2.delete();
                                            throw new IOException("apps:cert");
                                        }
                                    }
                                    throw new IOException("stopped");
                                } finally {
                                }
                            } finally {
                            }
                        } else {
                            throw new IOException("file too big");
                        }
                    } else {
                        throw new IOException("HTTP " + httpURLConnection.getResponseCode());
                    }
                } catch (IOException e) {
                    file2.delete();
                    throw e;
                }
            } finally {
                httpURLConnection.disconnect();
            }
        } else {
            throw new IOException("apps:noapk");
        }
    }

    public static List_ parse(String base, byte[] bArr) {
        App app;
        Intrinsics.checkNotNullParameter(base, "base");
        JSONObject jSONObject = new JSONObject(new String(bArr, Charsets.UTF_8));
        JSONArray optJSONArray = jSONObject.optJSONArray("cats");
        if (optJSONArray == null) {
            optJSONArray = new JSONArray();
        }
        JSONArray optJSONArray2 = jSONObject.optJSONArray("apps");
        if (optJSONArray2 == null) {
            optJSONArray2 = new JSONArray();
        }
        String optString = jSONObject.optString("updated");
        Intrinsics.checkNotNullExpressionValue(optString, "optString(...)");
        IntRange until = MathKt.until(0, optJSONArray.length());
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until));
        Iterator it = until.iterator();
        while (((IntProgressionIterator) it).hasNext) {
            arrayList.add(optJSONArray.getJSONObject(((IntProgressionIterator) it).nextInt()));
        }
        ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList));
        Iterator it2 = arrayList.iterator();
        while (it2.hasNext()) {
            JSONObject jSONObject2 = (JSONObject) it2.next();
            String string = jSONObject2.getString("id");
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            arrayList2.add(new Cat(string, words(jSONObject2.optJSONObject("name"))));
        }
        IntRange until2 = MathKt.until(0, optJSONArray2.length());
        ArrayList arrayList3 = new ArrayList();
        Iterator it3 = until2.iterator();
        while (((IntProgressionIterator) it3).hasNext) {
            try {
                JSONObject jSONObject3 = optJSONArray2.getJSONObject(((IntProgressionIterator) it3).nextInt());
                Intrinsics.checkNotNullExpressionValue(jSONObject3, "getJSONObject(...)");
                app = app(jSONObject3);
            } catch (Exception unused) {
                app = null;
            }
            if (app != null) {
                arrayList3.add(app);
            }
        }
        return new List_(optString, arrayList2, arrayList3, base);
    }

    public static Pair pick(App app, List list) {
        LinkedHashMap linkedHashMap;
        Pair pair;
        Iterator it = list.iterator();
        while (true) {
            boolean hasNext = it.hasNext();
            linkedHashMap = app.apk;
            if (hasNext) {
                String str = (String) it.next();
                Source source = (Source) linkedHashMap.get(str);
                if (source != null) {
                    pair = new Pair(str, source);
                } else {
                    pair = null;
                }
                if (pair != null) {
                    break;
                }
            } else {
                pair = null;
                break;
            }
        }
        if (pair == null) {
            Source source2 = (Source) linkedHashMap.get("universal");
            if (source2 == null) {
                return null;
            }
            return new Pair("universal", source2);
        }
        return pair;
    }

    public static Map words(JSONObject jSONObject) {
        Iterator<String> keys2;
        if (jSONObject != null && (keys2 = jSONObject.keys()) != null) {
            Sequence asSequence = SequencesKt.asSequence(keys2);
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            Iterator it = ((ConstrainedOnceSequence) asSequence).iterator();
            while (it.hasNext()) {
                Object next = it.next();
                linkedHashMap.put(next, jSONObject.getString((String) next));
            }
            return linkedHashMap;
        }
        return EmptyMap.INSTANCE;
    }
}
