package dev.tvremote.tvapps;

import dev.tvremote.core.Downloader;
import dev.tvremote.update.SignedList;
import java.io.File;
import java.io.IOException;
import java.util.List;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final /* synthetic */ class AppList$$ExternalSyntheticLambda1 implements Function3 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ File f$0;

    public /* synthetic */ AppList$$ExternalSyntheticLambda1(File file, int i) {
        this.$r8$classId = i;
        this.f$0 = file;
    }

    @Override // kotlin.jvm.functions.Function3
    public final Object invoke(Object obj, Object obj2, Object obj3) {
        File file = this.f$0;
        byte[] bArr = (byte[]) obj;
        String str = (String) obj2;
        String base = (String) obj3;
        switch (this.$r8$classId) {
            case 0:
                Intrinsics.checkNotNullParameter(base, "base");
                if (file != null) {
                    try {
                        List list = SignedList.KEYS;
                        SignedList.keep(file, bArr, str);
                    } catch (IOException unused) {
                    }
                }
                List list2 = AppList.bases;
                return AppList.parse(base, bArr);
            default:
                Intrinsics.checkNotNullParameter(base, "<unused var>");
                if (Downloader.accept(str, bArr) == null) {
                    return null;
                }
                List list3 = SignedList.KEYS;
                SignedList.keep(new File(file, "downloader.json"), bArr, str);
                return Boolean.TRUE;
        }
    }
}
