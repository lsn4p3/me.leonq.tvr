package dev.tvremote.update;

import dev.tvremote.core.B64;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda10;
import dev.tvremote.tvapps.ApkCert$$ExternalSyntheticLambda0;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.security.MessageDigest;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;
import kotlin.collections.ArraysKt;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;

/* loaded from: classes.dex */
public final class SignedList {
    public static final List KEYS = MathKt.listOf("de2714846a352ea4e0e5b5dcf2272fee9b10bd2da6ebdea8cff858bac1c3f6ea");

    public static Object fetch$default(List bases, final String str, List keys, Function3 function3, int i) {
        String str2;
        final int i2;
        final int i3;
        byte[] bArr;
        IOException iOException;
        String str3;
        if ((i & 8) != 0) {
            keys = KEYS;
        }
        if ((i & 16) != 0) {
            str2 = "list not signed by this project";
        } else {
            str2 = "launcher list not signed by this project";
        }
        if ((i & 32) != 0) {
            i2 = 10000;
        } else {
            i2 = 6000;
        }
        if ((i & 64) != 0) {
            i3 = 30000;
        } else {
            i3 = 8000;
        }
        Intrinsics.checkNotNullParameter(bases, "bases");
        Intrinsics.checkNotNullParameter(keys, "keys");
        IOException e = new IOException("no ".concat(str));
        Iterator it = bases.iterator();
        while (it.hasNext()) {
            final String str4 = (String) it.next();
            try {
                FutureTask futureTask = new FutureTask(new Callable() { // from class: dev.tvremote.update.SignedList$$ExternalSyntheticLambda1
                    @Override // java.util.concurrent.Callable
                    public final Object call() {
                        List list = SignedList.KEYS;
                        return new String(SignedList.get(str4 + str + ".sig", 1048576, i2, i3), Charsets.UTF_8);
                    }
                });
                Thread thread = new Thread(futureTask, "sig");
                thread.setDaemon(true);
                thread.start();
                bArr = get(str4 + str, 1048576, i2, i3);
                try {
                    str3 = (String) futureTask.get();
                    Intrinsics.checkNotNull(str3);
                } catch (ExecutionException e2) {
                    Throwable cause = e2.getCause();
                    if (cause instanceof IOException) {
                        iOException = (IOException) cause;
                    } else {
                        iOException = null;
                    }
                    if (iOException != null) {
                        throw iOException;
                    }
                    throw new IOException(e2.getCause());
                }
            } catch (IOException e3) {
                e = e3;
            }
            if (verify(bArr, str3, keys)) {
                Object invoke = function3.invoke(bArr, str3, str4);
                if (invoke != null) {
                    return invoke;
                }
            } else {
                throw new IOException(str2);
            }
        }
        throw e;
    }

    public static byte[] get(String url, int i, int i2, int i3) {
        Intrinsics.checkNotNullParameter(url, "url");
        URL url2 = new URL(url);
        if (!Intrinsics.areEqual(url2.getProtocol(), "https") && !Intrinsics.areEqual(url2.getProtocol(), "http")) {
            throw new IOException("not http: ".concat(url));
        }
        URLConnection openConnection = url2.openConnection();
        Intrinsics.checkNotNull(openConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
        HttpURLConnection httpURLConnection = (HttpURLConnection) openConnection;
        httpURLConnection.setConnectTimeout(i2);
        httpURLConnection.setReadTimeout(i3);
        httpURLConnection.setInstanceFollowRedirects(true);
        httpURLConnection.setRequestProperty("User-Agent", "tv-remote");
        try {
            if (httpURLConnection.getResponseCode() == 200) {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                InputStream inputStream = httpURLConnection.getInputStream();
                try {
                    byte[] bArr = new byte[16384];
                    do {
                        int read = inputStream.read(bArr);
                        if (read > 0) {
                            byteArrayOutputStream.write(bArr, 0, read);
                        } else {
                            inputStream.close();
                            byte[] byteArray = byteArrayOutputStream.toByteArray();
                            Intrinsics.checkNotNullExpressionValue(byteArray, "toByteArray(...)");
                            return byteArray;
                        }
                    } while (byteArrayOutputStream.size() <= i);
                    throw new IOException("list too big");
                } catch (Throwable th) {
                    try {
                        throw th;
                    } catch (Throwable th2) {
                        MathKt.closeFinally(inputStream, th);
                        throw th2;
                    }
                }
            }
            throw new IOException("HTTP " + httpURLConnection.getResponseCode());
        } finally {
            httpURLConnection.disconnect();
        }
    }

    public static void keep(File f, byte[] bArr, String str) {
        Intrinsics.checkNotNullParameter(f, "f");
        if (str != null) {
            MathKt.writeText$default(new File(Census$$ExternalSyntheticOutline0.m(f.getPath(), ".sig")), str);
        }
        File file = new File(Census$$ExternalSyntheticOutline0.m(f.getPath(), ".tmp"));
        MathKt.writeBytes(file, bArr);
        file.renameTo(f);
    }

    public static byte[] kept(File file, List keys) {
        Intrinsics.checkNotNullParameter(keys, "keys");
        File file2 = new File(Census$$ExternalSyntheticOutline0.m(file.getPath(), ".sig"));
        File file3 = new File(Census$$ExternalSyntheticOutline0.m(file.getPath(), ".ok"));
        try {
            if (file.isFile() && file2.isFile()) {
                byte[] readBytes = MathKt.readBytes(file);
                String readText$default = MathKt.readText$default(file2);
                String sha = sha(readText$default, readBytes);
                if (file3.isFile() && MathKt.readText$default(file3).equals(sha)) {
                    return readBytes;
                }
                if (!verify(readBytes, readText$default, keys)) {
                    readBytes = null;
                }
                if (readBytes == null) {
                    return null;
                }
                try {
                    MathKt.writeText$default(file3, sha);
                } catch (IOException unused) {
                }
                return readBytes;
            }
            return null;
        } catch (IOException unused2) {
            return null;
        }
    }

    public static byte[] packed$default(MainActivity$$ExternalSyntheticLambda10 mainActivity$$ExternalSyntheticLambda10) {
        List keys = KEYS;
        Intrinsics.checkNotNullParameter(keys, "keys");
        try {
            Closeable closeable = (Closeable) mainActivity$$ExternalSyntheticLambda10.invoke("voice/phrases.json");
            try {
                byte[] readBytes = MathKt.readBytes((InputStream) closeable);
                closeable.close();
                closeable = (Closeable) mainActivity$$ExternalSyntheticLambda10.invoke("voice/phrases.json".concat(".sig"));
                try {
                    String str = new String(MathKt.readBytes((InputStream) closeable), Charsets.UTF_8);
                    closeable.close();
                    if (verify(readBytes, str, keys)) {
                        return readBytes;
                    }
                    return null;
                } finally {
                }
            } finally {
            }
        } catch (Exception unused) {
            return null;
        }
    }

    public static String sha(String str, byte[] bArr) {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        messageDigest.update(bArr);
        messageDigest.update((byte) 0);
        byte[] bytes = StringsKt.trim(str).toString().getBytes(Charsets.UTF_8);
        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        messageDigest.update(bytes);
        byte[] digest = messageDigest.digest();
        Intrinsics.checkNotNullExpressionValue(digest, "digest(...)");
        return ArraysKt.joinToString$default(digest, "", new ApkCert$$ExternalSyntheticLambda0(19));
    }

    public static boolean verify(byte[] bArr, String str, List keys) {
        Intrinsics.checkNotNullParameter(keys, "keys");
        try {
            int[] iArr = B64.INDEX;
            byte[] decode = B64.decode(StringsKt.trim(str).toString());
            if (!keys.isEmpty()) {
                Iterator it = keys.iterator();
                while (it.hasNext()) {
                    String str2 = (String) it.next();
                    BigInteger bigInteger = Ed25519.P;
                    byte[] bArr2 = new byte[32];
                    for (int i = 0; i < 32; i++) {
                        int i2 = i * 2;
                        String substring = str2.substring(i2, i2 + 2);
                        Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
                        MathKt.checkRadix(16);
                        bArr2[i] = (byte) Integer.parseInt(substring, 16);
                    }
                    if (Ed25519.verify(bArr2, bArr, decode)) {
                        return true;
                    }
                }
            }
        } catch (IllegalArgumentException unused) {
        }
        return false;
    }
}
