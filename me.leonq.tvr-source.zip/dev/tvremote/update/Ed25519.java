package dev.tvremote.update;

import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Diagnose$$ExternalSyntheticLambda1;
import dev.tvremote.core.FleetStatus;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.manage.Jobs;
import dev.tvremote.core.ontv.RemoteLabels;
import dev.tvremote.core.web.HttpServer;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda5;
import dev.tvremote.home.HomeQr$$ExternalSyntheticLambda0;
import dev.tvremote.tvapps.ApkCert$$ExternalSyntheticLambda0;
import java.io.File;
import java.io.Serializable;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public abstract class Ed25519 {
    public static final Pt B;
    public static final BigInteger D;
    public static final BigInteger L;
    public static final BigInteger P;
    public static final BigInteger SQRT_M1;
    public static final BigInteger TWO;
    public static final Pt ZERO_PT;

    static {
        BigInteger bigInteger = BigInteger.ONE;
        BigInteger subtract = bigInteger.shiftLeft(255).subtract(BigInteger.valueOf(19L));
        P = subtract;
        L = bigInteger.shiftLeft(252).add(new BigInteger("27742317777372353535851937790883648493"));
        D = BigInteger.valueOf(-121665L).multiply(BigInteger.valueOf(121666L).modInverse(subtract)).mod(subtract);
        SQRT_M1 = BigInteger.valueOf(2L).modPow(subtract.subtract(bigInteger).shiftRight(2), subtract);
        TWO = BigInteger.valueOf(2L);
        BigInteger ZERO = BigInteger.ZERO;
        Intrinsics.checkNotNullExpressionValue(ZERO, "ZERO");
        ZERO_PT = new Pt(ZERO, bigInteger, bigInteger, ZERO);
        BigInteger mod = BigInteger.valueOf(4L).multiply(BigInteger.valueOf(5L).modInverse(subtract)).mod(subtract);
        Intrinsics.checkNotNull(mod);
        BigInteger recoverX = recoverX(mod, 0);
        Intrinsics.checkNotNull(recoverX);
        BigInteger mod2 = recoverX.multiply(mod).mod(subtract);
        Intrinsics.checkNotNullExpressionValue(mod2, "mod(...)");
        B = new Pt(recoverX, mod, bigInteger, mod2);
    }

    public static Pt add(Pt pt, Pt pt2) {
        BigInteger bigInteger = (BigInteger) pt.y;
        BigInteger bigInteger2 = (BigInteger) pt.x;
        BigInteger subtract = bigInteger.subtract(bigInteger2);
        BigInteger bigInteger3 = (BigInteger) pt2.y;
        BigInteger bigInteger4 = (BigInteger) pt2.x;
        BigInteger multiply = subtract.multiply(bigInteger3.subtract(bigInteger4));
        BigInteger bigInteger5 = P;
        BigInteger mod = multiply.mod(bigInteger5);
        BigInteger mod2 = ((BigInteger) pt.y).add(bigInteger2).multiply(((BigInteger) pt2.y).add(bigInteger4)).mod(bigInteger5);
        BigInteger bigInteger6 = (BigInteger) pt.t;
        BigInteger bigInteger7 = TWO;
        BigInteger mod3 = bigInteger7.multiply(bigInteger6).multiply((BigInteger) pt2.t).multiply(D).mod(bigInteger5);
        BigInteger mod4 = bigInteger7.multiply((BigInteger) pt.z).multiply((BigInteger) pt2.z).mod(bigInteger5);
        BigInteger subtract2 = mod2.subtract(mod);
        BigInteger subtract3 = mod4.subtract(mod3);
        BigInteger add = mod4.add(mod3);
        BigInteger add2 = mod2.add(mod);
        BigInteger mod5 = subtract2.multiply(subtract3).mod(bigInteger5);
        Intrinsics.checkNotNullExpressionValue(mod5, "mod(...)");
        BigInteger mod6 = add.multiply(add2).mod(bigInteger5);
        Intrinsics.checkNotNullExpressionValue(mod6, "mod(...)");
        BigInteger mod7 = subtract3.multiply(add).mod(bigInteger5);
        Intrinsics.checkNotNullExpressionValue(mod7, "mod(...)");
        BigInteger mod8 = subtract2.multiply(add2).mod(bigInteger5);
        Intrinsics.checkNotNullExpressionValue(mod8, "mod(...)");
        return new Pt(mod5, mod6, mod7, mod8);
    }

    public static Pt mul(BigInteger bigInteger, Pt pt) {
        Pt pt2 = ZERO_PT;
        while (bigInteger.signum() > 0) {
            if (bigInteger.testBit(0)) {
                pt2 = add(pt2, pt);
            }
            pt = add(pt, pt);
            bigInteger = bigInteger.shiftRight(1);
            Intrinsics.checkNotNullExpressionValue(bigInteger, "shiftRight(...)");
        }
        return pt2;
    }

    public static Pt point(byte[] bArr) {
        if (bArr.length == 32) {
            int i = (bArr[31] >> 7) & 1;
            byte[] copyOf = Arrays.copyOf(bArr, bArr.length);
            Intrinsics.checkNotNullExpressionValue(copyOf, "copyOf(...)");
            copyOf[31] = (byte) (copyOf[31] & Byte.MAX_VALUE);
            BigInteger bigInteger = new BigInteger(1, ArraysKt.reversedArray(copyOf));
            BigInteger recoverX = recoverX(bigInteger, i);
            if (recoverX == null) {
                return null;
            }
            BigInteger ONE = BigInteger.ONE;
            Intrinsics.checkNotNullExpressionValue(ONE, "ONE");
            BigInteger mod = recoverX.multiply(bigInteger).mod(P);
            Intrinsics.checkNotNullExpressionValue(mod, "mod(...)");
            return new Pt(recoverX, bigInteger, ONE, mod);
        }
        return null;
    }

    public static BigInteger recoverX(BigInteger bigInteger, int i) {
        BigInteger bigInteger2 = P;
        if (bigInteger.compareTo(bigInteger2) < 0) {
            BigInteger multiply = bigInteger.multiply(bigInteger);
            BigInteger bigInteger3 = BigInteger.ONE;
            BigInteger mod = multiply.subtract(bigInteger3).multiply(D.multiply(bigInteger).multiply(bigInteger).add(bigInteger3).modInverse(bigInteger2)).mod(bigInteger2);
            boolean z = true;
            if (mod.signum() == 0) {
                if (i != 1) {
                    return BigInteger.ZERO;
                }
                return null;
            }
            BigInteger modPow = mod.modPow(bigInteger2.add(BigInteger.valueOf(3L)).shiftRight(3), bigInteger2);
            if (modPow.multiply(modPow).subtract(mod).mod(bigInteger2).signum() != 0) {
                modPow = modPow.multiply(SQRT_M1).mod(bigInteger2);
            }
            if (modPow.multiply(modPow).subtract(mod).mod(bigInteger2).signum() != 0) {
                return null;
            }
            boolean testBit = modPow.testBit(0);
            if (i != 1) {
                z = false;
            }
            if (testBit != z) {
                return bigInteger2.subtract(modPow);
            }
            return modPow;
        }
        return null;
    }

    public static boolean verify(byte[] bArr, byte[] bArr2, byte[] bArr3) {
        Pt point;
        byte[] copyOfRange;
        Pt point2;
        if (bArr.length == 32 && bArr3.length == 64 && (point = point(bArr)) != null && (point2 = point((copyOfRange = ArraysKt.copyOfRange(bArr3, 0, 32)))) != null) {
            BigInteger bigInteger = new BigInteger(1, ArraysKt.reversedArray(ArraysKt.copyOfRange(bArr3, 32, 64)));
            BigInteger bigInteger2 = L;
            if (bigInteger.compareTo(bigInteger2) < 0) {
                MessageDigest messageDigest = MessageDigest.getInstance("SHA-512");
                messageDigest.update(copyOfRange);
                messageDigest.update(bArr);
                messageDigest.update(bArr2);
                byte[] digest = messageDigest.digest();
                Intrinsics.checkNotNullExpressionValue(digest, "digest(...)");
                BigInteger mod = new BigInteger(1, ArraysKt.reversedArray(digest)).mod(bigInteger2);
                Pt mul = mul(bigInteger, B);
                Intrinsics.checkNotNull(mod);
                Pt add = add(point2, mul(mod, point));
                BigInteger bigInteger3 = (BigInteger) mul.x;
                BigInteger bigInteger4 = (BigInteger) add.z;
                BigInteger multiply = bigInteger3.multiply(bigInteger4);
                BigInteger bigInteger5 = (BigInteger) add.x;
                BigInteger bigInteger6 = (BigInteger) mul.z;
                BigInteger subtract = multiply.subtract(bigInteger5.multiply(bigInteger6));
                BigInteger bigInteger7 = P;
                if (subtract.mod(bigInteger7).signum() == 0 && ((BigInteger) mul.y).multiply(bigInteger4).subtract(((BigInteger) add.y).multiply(bigInteger6)).mod(bigInteger7).signum() == 0) {
                    return true;
                }
            }
        }
        return false;
    }

    /* loaded from: classes.dex */
    public final class Pt {
        public final Object t;
        public final Object x;
        public final Object y;
        public final Serializable z;

        public Pt(AdbLink link, RemoteLabels remoteLabels, File file) {
            Intrinsics.checkNotNullParameter(link, "link");
            this.x = link;
            this.y = remoteLabels;
            this.z = file;
            this.t = new Jobs();
        }

        public ArrayList round(ArrayList arrayList) {
            Future<?> future;
            long currentTimeMillis = System.currentTimeMillis();
            List<String> distinct = CollectionsKt.distinct(arrayList);
            ArrayList arrayList2 = new ArrayList();
            for (String str : distinct) {
                FleetStatus.Status status = (FleetStatus.Status) ((ConcurrentHashMap) this.z).get(str);
                if (status != null && currentTimeMillis - status.at < 4000) {
                    future = null;
                } else {
                    synchronized (((ConcurrentHashMap) this.t)) {
                        Future<?> future2 = (Future) ((ConcurrentHashMap) this.t).get(str);
                        if (future2 == null) {
                            future2 = ((ExecutorService) this.y).submit(new Guard$$ExternalSyntheticLambda5(this, str, 2));
                            ((ConcurrentHashMap) this.t).put(str, future2);
                        }
                        future = future2;
                    }
                }
                if (future != null) {
                    arrayList2.add(future);
                }
            }
            long nanoTime = (9000 * 1000000) + System.nanoTime();
            Iterator it = arrayList2.iterator();
            while (it.hasNext()) {
                try {
                    ((Future) it.next()).get(Math.max(0L, nanoTime - System.nanoTime()), TimeUnit.NANOSECONDS);
                } catch (Exception unused) {
                }
            }
            ArrayList arrayList3 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList));
            Iterator it2 = arrayList.iterator();
            while (it2.hasNext()) {
                String str2 = (String) it2.next();
                FleetStatus.Status status2 = (FleetStatus.Status) ((ConcurrentHashMap) this.z).get(str2);
                if (status2 == null) {
                    status2 = new FleetStatus.Status(str2, null, 0L, 1022);
                }
                arrayList3.add(status2);
            }
            return arrayList3;
        }

        public HttpServer.Response text(long j, String cmd) {
            Intrinsics.checkNotNullParameter(cmd, "cmd");
            JSONObject put = new JSONObject().put("text", StringsKt__StringsJVMKt.replace$default(((AdbLink) this.x).get().shell(j, cmd), "\r\n", "\n"));
            Intrinsics.checkNotNullExpressionValue(put, "put(...)");
            HttpServer.Response response = new HttpServer.Response();
            response.status = 200;
            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = HttpServer.trusted;
            response.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put);
            return response;
        }

        public Pt(BigInteger bigInteger, BigInteger bigInteger2, BigInteger bigInteger3, BigInteger bigInteger4) {
            this.x = bigInteger;
            this.y = bigInteger2;
            this.z = bigInteger3;
            this.t = bigInteger4;
        }

        /* JADX WARN: Type inference failed for: r0v1, types: [int[], java.io.Serializable] */
        public Pt(int[] iArr, int[] iArr2) {
            this.x = iArr2;
            this.y = new int[17];
            ?? r0 = new int[17];
            int i = 0;
            for (int i2 = 0; i2 < 17; i2++) {
                r0[i2] = -1;
            }
            this.z = r0;
            this.t = new int[17];
            int i3 = 0;
            for (int i4 = 1; i4 < 17; i4++) {
                ((int[]) this.t)[i4] = i;
                ((int[]) this.y)[i4] = i3;
                int i5 = iArr[i4];
                int i6 = i3 + i5;
                i += i5;
                if (i5 > 0) {
                    ((int[]) this.z)[i4] = i6 - 1;
                }
                i3 = i6 << 1;
            }
        }

        public Pt(ApkCert$$ExternalSyntheticLambda0 apkCert$$ExternalSyntheticLambda0) {
            this.x = apkCert$$ExternalSyntheticLambda0;
            ExecutorService newFixedThreadPool = Executors.newFixedThreadPool(8, new Diagnose$$ExternalSyntheticLambda1(2));
            Intrinsics.checkNotNullExpressionValue(newFixedThreadPool, "newFixedThreadPool(...)");
            this.y = newFixedThreadPool;
            this.z = new ConcurrentHashMap();
            this.t = new ConcurrentHashMap();
        }
    }
}
