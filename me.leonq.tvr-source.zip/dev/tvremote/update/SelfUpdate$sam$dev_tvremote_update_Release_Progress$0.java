package dev.tvremote.update;

import dev.tvremote.core.ontv.Axml$$ExternalSyntheticLambda2;
import dev.tvremote.update.Release;
import kotlin.Function;
import kotlin.jvm.internal.FunctionAdapter;

/* loaded from: classes.dex */
public final /* synthetic */ class SelfUpdate$sam$dev_tvremote_update_Release_Progress$0 implements Release.Progress, FunctionAdapter {
    public final /* synthetic */ Axml$$ExternalSyntheticLambda2 function;

    public SelfUpdate$sam$dev_tvremote_update_Release_Progress$0(Axml$$ExternalSyntheticLambda2 axml$$ExternalSyntheticLambda2) {
        this.function = axml$$ExternalSyntheticLambda2;
    }

    @Override // dev.tvremote.update.Release.Progress
    public final /* synthetic */ void at(int i) {
        this.function.invoke(Integer.valueOf(i));
    }

    public final boolean equals(Object obj) {
        if ((obj instanceof Release.Progress) && (obj instanceof FunctionAdapter)) {
            return this.function.equals(((FunctionAdapter) obj).getFunctionDelegate());
        }
        return false;
    }

    @Override // kotlin.jvm.internal.FunctionAdapter
    public final Function getFunctionDelegate() {
        return this.function;
    }

    public final int hashCode() {
        return this.function.hashCode();
    }
}
