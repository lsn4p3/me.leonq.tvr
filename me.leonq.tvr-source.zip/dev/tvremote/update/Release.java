package dev.tvremote.update;

import dev.tvremote.tvapps.ApkCert$$ExternalSyntheticLambda0;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.security.MessageDigest;
import java.util.List;
import kotlin.collections.ArraysKt;
import kotlin.collections.EmptyList;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;

/* loaded from: classes.dex */
public final class Release {
    public static final List KEYS = ArraysKt.asList(new String[]{"8bda551ed91896e42bafabe7cee2b95f8401e33da105b3a092c333db4dc96b3a", "510ce48a7e710113b56e9c51c70ce3023be5188c722e4e304c159729481d9149"});
    public static final String api = "https://api.github.com";
    public static final EmptyList testKeys = EmptyList.INSTANCE;
    public final String notes;
    public final String sha256;
    public final String url;
    public final String version;

    /* loaded from: classes.dex */
    public interface Progress {
        void at(int i);
    }

    public Release(String str, String str2, String str3, String str4) {
        this.version = str;
        this.url = str2;
        this.notes = str3;
        this.sha256 = str4;
    }

    public final void check(MessageDigest messageDigest) {
        byte[] digest = messageDigest.digest();
        Intrinsics.checkNotNullExpressionValue(digest, "digest(...)");
        if (Intrinsics.areEqual(ArraysKt.joinToString$default(digest, "", new ApkCert$$ExternalSyntheticLambda0(18)), this.sha256)) {
        } else {
            throw new IOException("update file does not match its signed checksum");
        }
    }

    public final void download(File file, Progress progress) {
        HttpURLConnection open = MathKt.open(this.url);
        try {
            try {
                if (open.getResponseCode() == 200) {
                    MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
                    InputStream inputStream = open.getInputStream();
                    try {
                        FileOutputStream fileOutputStream = new FileOutputStream(file);
                        try {
                            Intrinsics.checkNotNull(inputStream);
                            MathKt.copy(inputStream, fileOutputStream, open.getContentLength(), progress, messageDigest);
                            fileOutputStream.close();
                            inputStream.close();
                            Intrinsics.checkNotNull(messageDigest);
                            check(messageDigest);
                        } finally {
                        }
                    } finally {
                    }
                } else {
                    throw new IOException("HTTP " + open.getResponseCode());
                }
            } catch (Exception e) {
                file.delete();
                throw e;
            }
        } finally {
            open.disconnect();
        }
    }
}
