package dev.tvremote.phone;

import android.content.DialogInterface;
import dev.tvremote.phone.manage.Managing;
import dev.tvremote.phone.picker.AdbHelpKt;
import dev.tvremote.phone.ui.UiKt;
import org.conscrypt.metrics.ConscryptStatsLog;

/* loaded from: classes.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda14 implements DialogInterface.OnClickListener {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda14(MainActivity mainActivity, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i) {
        switch (this.$r8$classId) {
            case 0:
                int i2 = MainActivity.$r8$clinit;
                this.f$0.disconnect$android_release(null);
                return;
            case 1:
                MainActivity mainActivity = this.f$0;
                int i3 = MainActivity.$r8$clinit;
                mainActivity.getPrefs$android_release().edit().putString("picEnc", "auto").apply();
                if (mainActivity.pic != null) {
                    mainActivity.stopPicture$android_release();
                    mainActivity.startPicture$android_release();
                    return;
                }
                return;
            case 2:
                AdbHelpKt.installSetup(this.f$0, UiKt.SETUP_APP);
                return;
            case 3:
                AdbHelpKt.installSetupByHand(this.f$0);
                return;
            case 4:
                AdbHelpKt.adbSteps(this.f$0);
                return;
            case 5:
                AdbHelpKt.otherHome(this.f$0);
                return;
            case 6:
                AdbHelpKt.adbSteps(this.f$0);
                return;
            case 7:
                AdbHelpKt.lookOnHome(this.f$0);
                return;
            case 8:
                AdbHelpKt.adbSteps(this.f$0);
                return;
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                AdbHelpKt.otherHome(this.f$0);
                return;
            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                AdbHelpKt.adbSteps(this.f$0);
                return;
            case 11:
                AdbHelpKt.otherHome(this.f$0);
                return;
            default:
                MainActivity mainActivity2 = this.f$0;
                Managing.open$default(mainActivity2.getManaging$android_release(), mainActivity2.host, "auto", null, 4);
                return;
        }
    }
}
