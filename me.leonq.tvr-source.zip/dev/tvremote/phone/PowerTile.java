package dev.tvremote.phone;

import android.content.Intent;
import android.service.quicksettings.Tile;
import dev.tvremote.core.Fleet;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class PowerTile extends TvTile {
    @Override // dev.tvremote.phone.TvTile
    public final Intent job(Intent intent) {
        Intent putExtra = intent.putExtra("do", "power");
        Intrinsics.checkNotNullExpressionValue(putExtra, "putExtra(...)");
        return putExtra;
    }

    @Override // dev.tvremote.phone.TvTile
    public final void paint(Tile tile) {
        tile.setState(1);
        tile.setLabel(Fleet.T("tiles.tv_power", new Pair[0]));
    }
}
