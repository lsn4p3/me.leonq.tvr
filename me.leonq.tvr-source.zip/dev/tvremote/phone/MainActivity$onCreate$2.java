package dev.tvremote.phone;

import dev.tvremote.core.picture.Tv;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class MainActivity$onCreate$2 implements Tv.Listener {
    public final /* synthetic */ MainActivity this$0;

    public /* synthetic */ MainActivity$onCreate$2(MainActivity mainActivity) {
        this.this$0 = mainActivity;
    }

    public String get(String key) {
        Intrinsics.checkNotNullParameter(key, "key");
        return this.this$0.getPrefs$android_release().getString(key, null);
    }

    @Override // dev.tvremote.core.picture.Tv.Listener
    public void onPassRefused() {
        MainActivity mainActivity = this.this$0;
        String str = mainActivity.entry;
        if (str == null) {
            str = mainActivity.host;
        }
        if (str != null) {
            mainActivity.getPrefs$android_release().edit().remove("tvs:".concat(str)).apply();
        }
    }

    @Override // dev.tvremote.core.picture.Tv.Listener
    public void onStatus(String str, String detail) {
        Intrinsics.checkNotNullParameter(detail, "detail");
        Tv tv = this.this$0.pic;
        MainActivity mainActivity = this.this$0;
        mainActivity.ui.post(new MainActivity$$ExternalSyntheticLambda27(mainActivity, tv, str, detail, 1));
    }

    @Override // dev.tvremote.core.picture.Tv.Listener
    public void onVideoSize(int i, int i2) {
        this.this$0.onVideoSize(i, i2);
    }

    public void put(String key, String value) {
        Intrinsics.checkNotNullParameter(key, "key");
        Intrinsics.checkNotNullParameter(value, "value");
        this.this$0.getPrefs$android_release().edit().putString(key, value).apply();
    }

    @Override // dev.tvremote.core.picture.Tv.Listener
    public boolean wantsNetwork() {
        return false;
    }

    @Override // dev.tvremote.core.picture.Tv.Listener
    public boolean wantsPass() {
        return false;
    }

    @Override // dev.tvremote.core.picture.Tv.Listener
    public void onPass(String str) {
    }

    @Override // dev.tvremote.core.picture.Tv.Listener
    public void onNetwork(String str, String str2, String str3) {
    }
}
