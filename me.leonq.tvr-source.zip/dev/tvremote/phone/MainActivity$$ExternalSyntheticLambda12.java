package dev.tvremote.phone;

import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.ontv.LauncherSwap;
import dev.tvremote.core.ontv.RulesClient;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.phone.media.TalkKt$$ExternalSyntheticLambda2;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

/* loaded from: classes.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda12 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ int f$0;
    public final /* synthetic */ MainActivity f$1;
    public final /* synthetic */ Tv f$2;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda12(int i, MainActivity mainActivity, Tv tv, int i2) {
        this.$r8$classId = i2;
        this.f$0 = i;
        this.f$1 = mainActivity;
        this.f$2 = tv;
    }

    /* JADX WARN: Can't wrap try/catch for region: R(9:32|(3:34|(1:36)|(2:38|(2:43|44)(1:42)))|45|46|47|48|(1:40)|43|44) */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x00ce, code lost:
    
        r3 = false;
     */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void run() {
        boolean z;
        switch (this.$r8$classId) {
            case 0:
                int i = MainActivity.$r8$clinit;
                Set set = RulesClient.SETUP_KEYS;
                Tv tv = this.f$2;
                TalkKt$$ExternalSyntheticLambda2 talkKt$$ExternalSyntheticLambda2 = new TalkKt$$ExternalSyntheticLambda2(tv, 2);
                int i2 = this.f$0;
                if (!RulesClient.key(i2, talkKt$$ExternalSyntheticLambda2)) {
                    if (RulesClient.appMissing(i2, new TalkKt$$ExternalSyntheticLambda2(tv, 3))) {
                        MainActivity mainActivity = this.f$1;
                        mainActivity.runOnUiThread(new MainActivity$$ExternalSyntheticLambda15(mainActivity, 7));
                        return;
                    } else {
                        tv.press(i2);
                        return;
                    }
                }
                return;
            case 1:
                MainActivity mainActivity2 = this.f$1;
                int i3 = this.f$0;
                Tv tv2 = this.f$2;
                Pair pair = mainActivity2.castOf;
                if (pair != null) {
                    if (pair.first != tv2) {
                        pair = null;
                    }
                    if (pair != null) {
                        z = ((Boolean) pair.second).booleanValue();
                        if (z || !RulesClient.key(i3, new TalkKt$$ExternalSyntheticLambda2(tv2, 1))) {
                            tv2.press(i3);
                            return;
                        }
                        return;
                    }
                }
                Set set2 = RulesClient.SETUP_KEYS;
                Set set3 = LauncherSwap.CAST_HOSTS;
                int i4 = MainActivity.$r8$clinit;
                String lowerCase = StringsKt.trim(tv2.shell("getprop ro.product.device")).toString().toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                boolean z2 = set3.contains(lowerCase);
                mainActivity2.castOf = new Pair(tv2, Boolean.valueOf(z2));
                z = z2;
                if (z) {
                }
                tv2.press(i3);
                return;
            default:
                int i5 = this.f$0;
                MainActivity mainActivity3 = this.f$1;
                Tv tv3 = this.f$2;
                if (RulesClient.SETUP_KEYS.contains(Integer.valueOf(i5))) {
                    if (!RulesClient.key(i5, new TalkKt$$ExternalSyntheticLambda2(tv3, 11))) {
                        if (RulesClient.appMissing(i5, new TalkKt$$ExternalSyntheticLambda2(tv3, 12))) {
                            mainActivity3.ui.post(new MainActivity$$ExternalSyntheticLambda15(mainActivity3, 27));
                            return;
                        }
                    } else {
                        return;
                    }
                }
                Adb adb = tv3.adb;
                if (adb != null) {
                    try {
                        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                        String obj = StringsKt.trim(adb.shell(120000L, "dumpsys window | grep -m1 mCurrentFocus")).toString();
                        if (i5 == 176) {
                            adb.shell(120000L, "am start -a android.settings.SETTINGS");
                        } else {
                            tv3.press(i5);
                        }
                        Thread.sleep(900L);
                        if (obj.length() != 0) {
                            if (Intrinsics.areEqual(StringsKt.trim(adb.shell(120000L, "dumpsys window | grep -m1 mCurrentFocus")).toString(), obj)) {
                                mainActivity3.ui.post(new MainActivity$$ExternalSyntheticLambda38(mainActivity3, tv3, 5));
                            } else {
                                return;
                            }
                        } else {
                            return;
                        }
                    } catch (Exception unused) {
                        return;
                    }
                }
                return;
        }
    }

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda12(Tv tv, MainActivity mainActivity, int i) {
        this.$r8$classId = 1;
        this.f$1 = mainActivity;
        this.f$0 = i;
        this.f$2 = tv;
    }
}
