package dev.tvremote.phone;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Application;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import dev.tvremote.core.Words;
import dev.tvremote.core.Words$$ExternalSyntheticLambda1;
import dev.tvremote.core.ontv.Bloat$$ExternalSyntheticLambda0;
import dev.tvremote.guard.Guard;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda3;
import dev.tvremote.guard.Guard$install$r$1;
import dev.tvremote.home.HomeQr$$ExternalSyntheticLambda0;
import dev.tvremote.phone.PhoneApp;
import dev.tvremote.phone.ui.UiKt;
import java.io.File;
import java.lang.ref.WeakReference;
import java.util.NoSuchElementException;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.Triple;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.LinesIterator;
import kotlin.text.Regex;
import kotlin.text.StringsKt;

/* loaded from: classes.dex */
public final class PhoneApp extends Application {
    public static final /* synthetic */ int $r8$clinit = 0;

    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Thread$UncaughtExceptionHandler, java.lang.Object] */
    @Override // android.app.Application
    public final void onCreate() {
        String str;
        int i = 0;
        super.onCreate();
        ConcurrentHashMap concurrentHashMap = Words.books;
        Words.open = new Words$$ExternalSyntheticLambda1(12, this);
        Words.books.clear();
        UiKt.loadLang(this);
        final HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = new HomeQr$$ExternalSyntheticLambda0(22);
        if (Guard.app == null) {
            Guard.app = this;
            Guard.words = homeQr$$ExternalSyntheticLambda0;
            boolean z = true;
            Guard.share = true;
            Guard.prev = Thread.getDefaultUncaughtExceptionHandler();
            Thread.setDefaultUncaughtExceptionHandler(new Object());
            if ((getApplicationInfo().flags & 2) == 0) {
                z = false;
            }
            Guard.debuggable = z;
            File file = new File(getFilesDir(), "guard-died");
            if (file.exists()) {
                try {
                    str = MathKt.readText$default(new File(getFilesDir(), "guard-last.txt"));
                } catch (Exception unused) {
                    str = null;
                }
                Guard.pending = str;
                file.delete();
            }
            registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() { // from class: dev.tvremote.guard.Guard$install$2
                @Override // android.app.Application.ActivityLifecycleCallbacks
                public final void onActivityCreated(Activity a, Bundle bundle) {
                    Intrinsics.checkNotNullParameter(a, "a");
                }

                @Override // android.app.Application.ActivityLifecycleCallbacks
                public final void onActivityDestroyed(Activity a) {
                    Intrinsics.checkNotNullParameter(a, "a");
                }

                @Override // android.app.Application.ActivityLifecycleCallbacks
                public final void onActivityPaused(Activity a) {
                    Intrinsics.checkNotNullParameter(a, "a");
                    AlertDialog alertDialog = Guard.dialog;
                    if (alertDialog != null && Guard.top.get() == a) {
                        alertDialog.dismiss();
                        Guard.dialog = null;
                    }
                }

                @Override // android.app.Application.ActivityLifecycleCallbacks
                public final void onActivityResumed(Activity a) {
                    String str2;
                    int i2 = 0;
                    Intrinsics.checkNotNullParameter(a, "a");
                    if (Guard.debuggable && new File(PhoneApp.this.getFilesDir(), "guard-resume-throw").delete()) {
                        throw new IllegalStateException("guard test: onResume");
                    }
                    Guard.top = new WeakReference(a);
                    String str3 = Guard.pending;
                    if (str3 != null) {
                        Triple triple = null;
                        Guard.pending = null;
                        String str4 = ((GuardWords) homeQr$$ExternalSyntheticLambda0.invoke(a)).lastTime;
                        Regex regex = GuardLogic.LIFECYCLE;
                        Guard.show(a, str4, str3, GuardLogic.key(new Throwable(str3)), null);
                        String obj = StringsKt.trim(StringsKt.substringAfter(str3, "\n\n", "")).toString();
                        if (obj.length() != 0) {
                            LinesIterator linesIterator = (LinesIterator) StringsKt.lineSequence(obj).iterator();
                            if (linesIterator.hasNext()) {
                                String str5 = (String) linesIterator.next();
                                String obj2 = StringsKt.trim(StringsKt.substringBefore(str5, ": ", str5)).toString();
                                if (!StringsKt.contains(str5, ": ", false)) {
                                    str2 = "";
                                } else {
                                    str2 = StringsKt.trim(StringsKt.substringAfter(str5, ": ", str5)).toString();
                                }
                                triple = new Triple(obj2, str2, StringsKt.trim(StringsKt.substringAfter(obj, '\n', "")).toString());
                            } else {
                                throw new NoSuchElementException("Sequence is empty.");
                            }
                        }
                        if (triple != null) {
                            String str6 = (String) triple.first;
                            String str7 = (String) triple.second;
                            String str8 = (String) triple.third;
                            String key = GuardLogic.key(new Throwable(str3));
                            Bloat$$ExternalSyntheticLambda0 bloat$$ExternalSyntheticLambda0 = Guard.crash;
                            if (bloat$$ExternalSyntheticLambda0 != null) {
                                try {
                                    bloat$$ExternalSyntheticLambda0.invoke(str6, str7, str8, new Guard$$ExternalSyntheticLambda4(key, i2));
                                } catch (Throwable unused2) {
                                }
                            }
                        }
                    }
                }

                @Override // android.app.Application.ActivityLifecycleCallbacks
                public final void onActivitySaveInstanceState(Activity a, Bundle b) {
                    Intrinsics.checkNotNullParameter(a, "a");
                    Intrinsics.checkNotNullParameter(b, "b");
                }

                @Override // android.app.Application.ActivityLifecycleCallbacks
                public final void onActivityStarted(Activity a) {
                    Intrinsics.checkNotNullParameter(a, "a");
                }

                @Override // android.app.Application.ActivityLifecycleCallbacks
                public final void onActivityStopped(Activity a) {
                    Intrinsics.checkNotNullParameter(a, "a");
                }
            });
            if (Guard.debuggable) {
                Guard$install$r$1 guard$install$r$1 = new Guard$install$r$1(0, this);
                IntentFilter intentFilter = new IntentFilter("dev.tvremote.GUARD_TEST");
                if (Build.VERSION.SDK_INT >= 33) {
                    registerReceiver(guard$install$r$1, intentFilter, 2);
                } else {
                    registerReceiver(guard$install$r$1, intentFilter);
                }
            }
            ((Handler) Guard.main$delegate.getValue()).post(new Guard$$ExternalSyntheticLambda3(i));
        }
    }
}
