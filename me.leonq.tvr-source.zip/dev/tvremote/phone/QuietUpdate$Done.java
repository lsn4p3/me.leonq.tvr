package dev.tvremote.phone;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class QuietUpdate$Done extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public final void onReceive(Context c, Intent i) {
        Intrinsics.checkNotNullParameter(c, "c");
        Intrinsics.checkNotNullParameter(i, "i");
        int intExtra = i.getIntExtra("android.content.pm.extra.STATUS", 1);
        String stringExtra = i.getStringExtra("android.content.pm.extra.STATUS_MESSAGE");
        if (stringExtra == null) {
            stringExtra = "";
        }
        Log.i("QuietUpdate", "status " + intExtra + " " + stringExtra);
        if (intExtra == -1) {
            c.getSharedPreferences("quiet_update", 0).edit().putBoolean("asks", true).apply();
        }
    }
}
