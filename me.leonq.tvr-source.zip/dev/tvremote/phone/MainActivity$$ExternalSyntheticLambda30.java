package dev.tvremote.phone;

import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.adb.Adb$$ExternalSyntheticLambda0;
import dev.tvremote.core.manage.Jobs$$ExternalSyntheticLambda0;
import dev.tvremote.core.remote.Vidaa$$ExternalSyntheticLambda6;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda5;
import dev.tvremote.phone.ir.IrCodes;
import dev.tvremote.phone.ir.IrProfile;
import dev.tvremote.phone.ir.IrRemoteKt;
import dev.tvremote.phone.ir.IrState;
import dev.tvremote.phone.manage.UpdaterKt;
import dev.tvremote.phone.media.MediaKt$$ExternalSyntheticLambda4;
import dev.tvremote.phone.media.TalkKt$$ExternalSyntheticLambda1;
import dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda3;
import dev.tvremote.phone.picker.PickerScreenKt;
import dev.tvremote.phone.picture.Air;
import dev.tvremote.phone.picture.DrawView;
import dev.tvremote.phone.remote.TypingKt;
import dev.tvremote.phone.ui.IconBesideText;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.phone.ui.Spin;
import dev.tvremote.phone.ui.UiKt;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.StringsKt;
import org.conscrypt.FileClientSessionCache;
import org.conscrypt.metrics.ConscryptStatsLog;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda30 implements View.OnClickListener {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda30(MainActivity mainActivity, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        String str;
        String T;
        String str2;
        String str3;
        String str4;
        ViewGroup.LayoutParams gap;
        int i = 16;
        int i2 = 17;
        int i3 = 6;
        int i4 = 1;
        int i5 = 0;
        switch (this.$r8$classId) {
            case 0:
                int i6 = MainActivity.$r8$clinit;
                this.f$0.disconnect$android_release(null);
                return;
            case 1:
                MainActivity mainActivity = this.f$0;
                Intent putExtra = new Intent("android.intent.action.CREATE_DOCUMENT").addCategory("android.intent.category.OPENABLE").setType("application/json").putExtra("android.intent.extra.TITLE", "tv-remote-ir.json");
                Intrinsics.checkNotNullExpressionValue(putExtra, "putExtra(...)");
                try {
                    mainActivity.startActivityForResult(putExtra, mainActivity.PICK_IR_SAVE);
                    return;
                } catch (Exception unused) {
                    Fleet.say(mainActivity, Fleet.T("media.this_phone_has_no", new Pair[0]), true);
                    return;
                }
            case 2:
                MainActivity mainActivity2 = this.f$0;
                Intent addCategory = new Intent("android.intent.action.GET_CONTENT").setType("*/*").addCategory("android.intent.category.OPENABLE");
                Intrinsics.checkNotNullExpressionValue(addCategory, "addCategory(...)");
                try {
                    mainActivity2.startActivityForResult(addCategory, mainActivity2.PICK_IR_OPEN);
                    return;
                } catch (Exception unused2) {
                    Fleet.say(mainActivity2, Fleet.T("media.this_phone_has_no", new Pair[0]), true);
                    return;
                }
            case 3:
                MainActivity mainActivity3 = this.f$0;
                ArrayList irCatalog = IrRemoteKt.irCatalog(mainActivity3);
                IrProfile irProfile = IrRemoteKt.irProfile(mainActivity3);
                if (irProfile != null) {
                    str = irProfile.id;
                } else {
                    str = null;
                }
                ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(irCatalog));
                Iterator it = irCatalog.iterator();
                while (it.hasNext()) {
                    arrayList.add(((IrProfile) it.next()).brand);
                }
                List<String> distinct = CollectionsKt.distinct(arrayList);
                ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(distinct));
                for (String str5 : distinct) {
                    ArrayList arrayList3 = new ArrayList();
                    Iterator it2 = irCatalog.iterator();
                    while (it2.hasNext()) {
                        Object next = it2.next();
                        if (Intrinsics.areEqual(((IrProfile) next).brand, str5)) {
                            arrayList3.add(next);
                        }
                    }
                    if (arrayList3.size() == 1) {
                        T = Fleet.T("ir.one_kind", new Pair("n", Integer.valueOf(((IrProfile) arrayList3.get(0)).keys.size())));
                    } else {
                        T = Fleet.T("ir.n_kinds", new Pair("n", Integer.valueOf(arrayList3.size())));
                    }
                    if (!arrayList3.isEmpty()) {
                        Iterator it3 = arrayList3.iterator();
                        while (it3.hasNext()) {
                            if (Intrinsics.areEqual(((IrProfile) it3.next()).id, str)) {
                                str2 = "  ✓";
                                arrayList2.add(new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@tv|", str5, str2), T, new Vidaa$$ExternalSyntheticLambda6(arrayList3, mainActivity3, str5, 2)));
                            }
                        }
                    }
                    str2 = "";
                    arrayList2.add(new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@tv|", str5, str2), T, new Vidaa$$ExternalSyntheticLambda6(arrayList3, mainActivity3, str5, 2)));
                }
                UiKt.menu(mainActivity3, Fleet.T("ir.choose_brand", new Pair[0]), -1, arrayList2);
                return;
            case 4:
                MainActivity mainActivity4 = this.f$0;
                String irTarget = IrRemoteKt.irTarget(mainActivity4);
                if (irTarget.length() > 0) {
                    if (TypingKt.kindOf(mainActivity4, irTarget).equals("android")) {
                        IrState.auto = irTarget;
                        IrRemoteKt.irAuto$default(mainActivity4, null, null, null, 15);
                        return;
                    } else {
                        IrRemoteKt.irFind$default(mainActivity4);
                        return;
                    }
                }
                ArrayList savedIps = PickerScreenKt.savedIps(mainActivity4);
                ArrayList arrayList4 = new ArrayList();
                Iterator it4 = savedIps.iterator();
                while (it4.hasNext()) {
                    Object next2 = it4.next();
                    String ip = (String) next2;
                    Intrinsics.checkNotNullParameter(ip, "ip");
                    if (TypingKt.kindOf(mainActivity4, ip).equals("android")) {
                        arrayList4.add(next2);
                    }
                }
                if (arrayList4.isEmpty()) {
                    IrRemoteKt.irFind$default(mainActivity4);
                    return;
                }
                String T2 = Fleet.T("ir.find_on", new Pair[0]);
                ArrayList arrayList5 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList4));
                Iterator it5 = arrayList4.iterator();
                while (it5.hasNext()) {
                    String str6 = (String) it5.next();
                    arrayList5.add(new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@tv|", IrRemoteKt.irTvName(mainActivity4, str6)), Fleet.T("ir.tv_sub", new Pair[0]), new MediaKt$$ExternalSyntheticLambda4(mainActivity4, str6)));
                }
                UiKt.menu(mainActivity4, T2, -1, CollectionsKt.plus(arrayList5, new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@search|", Fleet.T("ir.other_tv", new Pair[0])), Fleet.T("ir.other_tv_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity4, 4))));
                return;
            case 5:
                IrRemoteKt.irStop();
                IrRemoteKt.irAuto$default(this.f$0, null, null, null, 15);
                return;
            case 6:
                MainActivity mainActivity5 = this.f$0;
                String str7 = IrState.auto;
                String irTvName = IrRemoteKt.irTvName(mainActivity5, str7);
                ArrayList arrayList6 = IrCodes.KEYS;
                ArrayList distinct2 = IrCodes.distinct("VOL_UP", IrRemoteKt.irCatalog(mainActivity5));
                IrState.stop = false;
                IrRemoteKt.irAuto$default(mainActivity5, Fleet.T("ir.auto_connecting", new Pair("name", irTvName)), null, null, 6);
                new Thread(new Jobs$$ExternalSyntheticLambda0(str7, mainActivity5, new MainActivity$$ExternalSyntheticLambda10(mainActivity5, 1), distinct2, irTvName), "ir-auto").start();
                return;
            case 7:
                IrRemoteKt.irStop();
                IrRemoteKt.irFind$default(this.f$0);
                return;
            case 8:
                IrRemoteKt.irLearnRun(this.f$0);
                return;
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                IrRemoteKt.irLearnRun(this.f$0);
                return;
            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                IrState.slot = -2;
                IrRemoteKt.irRemote(this.f$0);
                return;
            case 11:
                this.f$0.getSettings$android_release().setVisibility(8);
                return;
            case FileClientSessionCache.MAX_SIZE /* 12 */:
                this.f$0.getAbout$android_release().setVisibility(8);
                return;
            case 13:
                this.f$0.startActivity(Intent.createChooser(new Intent("android.intent.action.SEND").setType("text/plain").putExtra("android.intent.extra.TEXT", "https://tvremote.pages.dev/dl/tv-remote.apk"), null));
                return;
            case 14:
                try {
                    this.f$0.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://github.com/HoangTran0410/tv-remote/releases/latest")));
                    return;
                } catch (Exception unused3) {
                    return;
                }
            case 15:
                String T3 = Fleet.T("many_tvs.several_tvs_at_once_2", new Pair[0]);
                String m = ApkSigner$$ExternalSyntheticOutline0.m("@package|", Fleet.T("many_tvs.install_an_apk_on", new Pair[0]));
                MainActivity mainActivity6 = this.f$0;
                UiKt.menu(mainActivity6, T3, 0, ArraysKt.asList(new Triple[]{new Triple(m, "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity6, 7)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@home|", Fleet.T("fleet.menu_welcome", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity6, 8)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@close|", Fleet.T("fleet.menu_welcome_off", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity6, 9)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@close|", Fleet.T("many_tvs.remove_apps", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity6, 10)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@tv|", Fleet.T("fleet.menu_launcher", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity6, 11)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@power|", Fleet.T("fleet.menu_restart", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity6, 12)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@sparkle|", Fleet.T("fleet.menu_checkout", new Pair[0])), Fleet.T("fleet.menu_checkout_sub", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity6, 13))}));
                return;
            case 16:
                MainActivity mainActivity7 = this.f$0;
                mainActivity7.getScanBtn$android_release().setEnabled(false);
                Button scanBtn$android_release = mainActivity7.getScanBtn$android_release();
                String s = Fleet.T("picker.scanning", new Pair[0]);
                boolean z = UiKt.LIGHT;
                Intrinsics.checkNotNullParameter(s, "s");
                Pattern compile = Pattern.compile("^[^\\p{L}\\p{N}]+");
                Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                String replaceAll = compile.matcher(s).replaceAll("");
                Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
                scanBtn$android_release.setText(replaceAll);
                int roundToInt = MathKt.roundToInt(scanBtn$android_release.getTextSize() * 1.25f);
                Spin spin = new Spin(scanBtn$android_release.getCurrentTextColor(), roundToInt / 7.0f);
                spin.setBounds(0, 0, roundToInt, roundToInt);
                scanBtn$android_release.setCompoundDrawablesRelative(spin, null, null, null);
                scanBtn$android_release.setCompoundDrawablePadding(MathKt.roundToInt(10 * scanBtn$android_release.getResources().getDisplayMetrics().density));
                IconBesideText iconBesideText = IconBesideText.INSTANCE;
                scanBtn$android_release.removeOnLayoutChangeListener(iconBesideText);
                scanBtn$android_release.addOnLayoutChangeListener(iconBesideText);
                scanBtn$android_release.post(new Adb$$ExternalSyntheticLambda0(11, scanBtn$android_release));
                spin.start();
                mainActivity7.getFoundList$android_release().removeAllViews();
                mainActivity7.probe.run();
                new Thread(new Guard$$ExternalSyntheticLambda5(29, mainActivity7, CollectionsKt.toSet(PickerScreenKt.savedIps(mainActivity7)))).start();
                return;
            case 17:
                MainActivity mainActivity8 = this.f$0;
                mainActivity8.connect$android_release(mainActivity8.getIpBox$android_release().getText().toString(), null);
                return;
            case 18:
                MainActivity mainActivity9 = this.f$0;
                Popup.Builder builder = new Popup.Builder(mainActivity9);
                builder.title = Fleet.T("picker.how_to_connect", new Pair[0]);
                String T4 = Fleet.T("picker.1_turn_on_adb", new Pair[0]);
                String T5 = Fleet.T("setup.tcl_hidden_adb_short", new Pair[0]);
                LinearLayout col = UiKt.col(mainActivity9);
                float f = 16;
                col.setPadding(UiKt.dp(mainActivity9, f), UiKt.dp(mainActivity9, 6), UiKt.dp(mainActivity9, f), UiKt.dp(mainActivity9, 2));
                Iterator it6 = StringsKt.split$default(T4, new String[]{"\n\n"}, 0, 6).iterator();
                ViewGroup viewGroup = null;
                while (it6.hasNext()) {
                    List split$default = StringsKt.split$default(StringsKt.trim((String) it6.next()).toString(), new String[]{"\n"}, i5, i3);
                    if (split$default.size() == i4 && viewGroup != null) {
                        TextView label = UiKt.label(mainActivity9, (String) split$default.get(i5), 14, UiKt.MUTED);
                        label.setLineSpacing(UiKt.dp(mainActivity9, r7), 1.0f);
                        viewGroup.addView(label, UiKt.gap(mainActivity9, i3));
                    } else {
                        Pattern compile2 = Pattern.compile("^(\\w{1,2})\\.\\s+(.*)");
                        Intrinsics.checkNotNullExpressionValue(compile2, "compile(...)");
                        CharSequence input = (CharSequence) split$default.get(i5);
                        Intrinsics.checkNotNullParameter(input, "input");
                        Matcher matcher = compile2.matcher(input);
                        Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
                        MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, i5, input);
                        LinearLayout linearLayout = new LinearLayout(mainActivity9);
                        linearLayout.setBackground(UiKt.box(mainActivity9, UiKt.BTN, 14));
                        float f2 = 12;
                        linearLayout.setPadding(UiKt.dp(mainActivity9, f2), UiKt.dp(mainActivity9, f2), UiKt.dp(mainActivity9, 14), UiKt.dp(mainActivity9, f2));
                        if (access$findNext == null || (str3 = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)) == null) {
                            str3 = "💡";
                        }
                        TextView label2 = UiKt.label(mainActivity9, str3, 14, UiKt.ACCENT_TEXT);
                        Typeface typeface = Typeface.DEFAULT_BOLD;
                        label2.setTypeface(typeface);
                        label2.setGravity(17);
                        label2.setBackground(UiKt.box(mainActivity9, UiKt.SOFT, 15));
                        float f3 = 30;
                        linearLayout.addView(label2, new LinearLayout.LayoutParams(UiKt.dp(mainActivity9, f3), UiKt.dp(mainActivity9, f3)));
                        ViewGroup col2 = UiKt.col(mainActivity9);
                        if (access$findNext == null || (str4 = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(2)) == null) {
                            str4 = (String) split$default.get(0);
                        }
                        TextView label3 = UiKt.label(mainActivity9, str4, 15, UiKt.TEXT);
                        label3.setTypeface(typeface);
                        col2.addView(label3);
                        if (split$default.size() > 1) {
                            TextView label4 = UiKt.label(mainActivity9, CollectionsKt.joinToString$default(CollectionsKt.drop(1, split$default), "\n", null, null, null, 62), 14, UiKt.MUTED);
                            label4.setLineSpacing(UiKt.dp(mainActivity9, r7), 1.0f);
                            col2.addView(label4, UiKt.gap(mainActivity9, 4));
                        }
                        if (col.getChildCount() == 0) {
                            TextView label5 = UiKt.label(mainActivity9, T5, 13, UiKt.TEXT);
                            label5.setBackground(UiKt.box(mainActivity9, UiKt.SEL, 10));
                            float f4 = 10;
                            float f5 = 8;
                            label5.setPadding(UiKt.dp(mainActivity9, f4), UiKt.dp(mainActivity9, f5), UiKt.dp(mainActivity9, f4), UiKt.dp(mainActivity9, f5));
                            col2.addView(label5, UiKt.gap(mainActivity9, 8));
                        }
                        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
                        layoutParams.leftMargin = UiKt.dp(mainActivity9, f2);
                        linearLayout.addView(col2, layoutParams);
                        if (col.getChildCount() == 0) {
                            gap = new LinearLayout.LayoutParams(-1, -2);
                        } else {
                            gap = UiKt.gap(mainActivity9, 8);
                        }
                        col.addView(linearLayout, gap);
                        viewGroup = col2;
                        i3 = 6;
                        i4 = 1;
                        i5 = 0;
                    }
                }
                builder.view = col;
                builder.setPositiveButton(Fleet.T("setup_banner.got_it", new Pair[0]), null);
                builder.show();
                return;
            case 19:
                MainActivity mainActivity10 = this.f$0;
                UiKt.hideKeyboard(mainActivity10);
                mainActivity10.getSettings$android_release().setVisibility(0);
                return;
            case 20:
                UpdaterKt.askUpdate(this.f$0);
                return;
            case 21:
                IrRemoteKt.irOpen(this.f$0, null);
                return;
            case 22:
                Air.stopDrawing(this.f$0);
                return;
            case 23:
                Air.picEnd(this.f$0);
                return;
            case 24:
                MainActivity mainActivity11 = this.f$0;
                Intrinsics.checkNotNullParameter(mainActivity11, "<this>");
                DrawView.Pic placing = mainActivity11.getDrawView$android_release().getPlacing();
                if (placing != null) {
                    JSONObject m8m = Census$$ExternalSyntheticOutline0.m8m("o", "i");
                    int i7 = mainActivity11.drawId + 1;
                    mainActivity11.drawId = i7;
                    JSONObject put = m8m.put("id", i7).put("b", placing.data).put("x", placing.x).put("y", placing.y).put("w", placing.w);
                    Intrinsics.checkNotNullExpressionValue(put, "put(...)");
                    Air.drawSend(mainActivity11, put);
                    DrawView drawView$android_release = mainActivity11.getDrawView$android_release();
                    placing.upAt = System.currentTimeMillis();
                    drawView$android_release.landed.add(placing);
                    drawView$android_release.invalidate();
                    Air.picEnd(mainActivity11);
                    return;
                }
                return;
            case 25:
                MainActivity mainActivity12 = this.f$0;
                MathKt.withSetup(mainActivity12, new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity12, i));
                return;
            case 26:
                MainActivity mainActivity13 = this.f$0;
                MathKt.withSetup(mainActivity13, new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity13, i2));
                return;
            case 27:
                JSONObject put2 = new JSONObject().put("o", "u");
                Intrinsics.checkNotNullExpressionValue(put2, "put(...)");
                Air.drawSend(this.f$0, put2);
                return;
            case 28:
                MainActivity mainActivity14 = this.f$0;
                DrawView drawView$android_release2 = mainActivity14.getDrawView$android_release();
                drawView$android_release2.strokes.clear();
                drawView$android_release2.landed.clear();
                drawView$android_release2.invalidate();
                JSONObject put3 = new JSONObject().put("o", "x");
                Intrinsics.checkNotNullExpressionValue(put3, "put(...)");
                Air.drawSend(mainActivity14, put3);
                return;
            default:
                TypingKt.gamesPointerClose(this.f$0);
                return;
        }
    }
}
