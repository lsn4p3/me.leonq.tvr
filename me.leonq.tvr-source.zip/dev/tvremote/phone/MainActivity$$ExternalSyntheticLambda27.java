package dev.tvremote.phone;

import android.os.SystemClock;
import android.widget.TextView;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.phone.picker.PickerScreenKt;
import dev.tvremote.phone.picture.PipKt;
import dev.tvremote.phone.remote.TypingKt;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;

/* loaded from: classes.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda27 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ Tv f$1;
    public final /* synthetic */ String f$2;
    public final /* synthetic */ String f$3;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda27(MainActivity mainActivity, Tv tv, String str, String str2, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
        this.f$1 = tv;
        this.f$2 = str;
        this.f$3 = str2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        String T;
        String T2;
        String str;
        switch (this.$r8$classId) {
            case 0:
                MainActivity mainActivity = this.f$0;
                Tv tv = this.f$1;
                String str2 = this.f$2;
                String str3 = this.f$3;
                String str4 = mainActivity.host;
                if (mainActivity.tv == tv && str4 != null) {
                    mainActivity.allowAlert$android_release(str2.equals("allow"));
                    switch (str2.hashCode()) {
                        case -1357520532:
                            if (str2.equals("closed")) {
                                mainActivity.tv = null;
                                mainActivity.stopPicture$android_release();
                                mainActivity.reconnect$android_release(Fleet.T("phone.the_tv_closed_the", new Pair[0]));
                                return;
                            }
                            break;
                        case -775651656:
                            if (str2.equals("connecting")) {
                                TextView status$android_release = mainActivity.getStatus$android_release();
                                String str5 = mainActivity.entry;
                                if (str5 != null) {
                                    str4 = str5;
                                }
                                status$android_release.setText(mainActivity.title$android_release(str4) + " · " + Fleet.T("page.connecting", new Pair[0]));
                                mainActivity.getWaitStep$android_release().setText(Fleet.T("phone.looking_for_the_tv", new Pair("ip", str3)));
                                return;
                            }
                            break;
                        case 3322092:
                            if (str2.equals("live")) {
                                mainActivity.wasLive = true;
                                mainActivity.retries = 0;
                                if (tv != null) {
                                    MathKt.checkSetup(tv, mainActivity, str4);
                                }
                                mainActivity.ui.postDelayed(new MainActivity$$ExternalSyntheticLambda9(mainActivity, tv, str4, 2), 3000L);
                                mainActivity.getWaiting$android_release().setVisibility(8);
                                String str6 = mainActivity.pendingAsk;
                                if (str6 != null) {
                                    mainActivity.pendingAsk = null;
                                    new Thread(new MainActivity$$ExternalSyntheticLambda9(tv, str6, mainActivity, 3)).start();
                                }
                                Tv tv2 = mainActivity.pic;
                                if (tv2 == null || !tv2.ready()) {
                                    TextView status$android_release2 = mainActivity.getStatus$android_release();
                                    String str7 = mainActivity.entry;
                                    if (str7 != null) {
                                        str4 = str7;
                                    }
                                    String title$android_release = mainActivity.title$android_release(str4);
                                    if (mainActivity.listen) {
                                        T = Fleet.T("phone.listening_on_the_phone", new Pair[0]);
                                    } else if (mainActivity.video) {
                                        T = Fleet.T("phone.opening_the_picture", new Pair[0]);
                                    } else {
                                        T = Fleet.T("phone.picture_off", new Pair[0]);
                                    }
                                    status$android_release2.setText(title$android_release + " · " + T);
                                    return;
                                }
                                return;
                            }
                            break;
                        case 92906313:
                            if (str2.equals("allow")) {
                                TextView status$android_release3 = mainActivity.getStatus$android_release();
                                String str8 = mainActivity.entry;
                                if (str8 != null) {
                                    str4 = str8;
                                }
                                status$android_release3.setText(mainActivity.title$android_release(str4) + " · " + Fleet.T("phone.look_at_the_tv", new Pair[0]));
                                mainActivity.getWaitStep$android_release().setText(Fleet.T("phone.waiting_for_the_tv", new Pair[0]));
                                return;
                            }
                            break;
                        case 1316806720:
                            if (str2.equals("starting")) {
                                String str9 = mainActivity.entry;
                                if (str9 == null) {
                                    str9 = str4;
                                }
                                PickerScreenKt.save(mainActivity, str9, str3);
                                TextView status$android_release4 = mainActivity.getStatus$android_release();
                                String str10 = mainActivity.entry;
                                if (str10 == null) {
                                    str10 = str4;
                                }
                                status$android_release4.setText(mainActivity.title$android_release(str10) + " · " + Fleet.T("phone.opening_the_controls", new Pair[0]));
                                TextView textView = mainActivity.waitName;
                                if (textView != null) {
                                    String str11 = mainActivity.entry;
                                    if (str11 != null) {
                                        str4 = str11;
                                    }
                                    textView.setText(mainActivity.title$android_release(str4));
                                    mainActivity.getWaitStep$android_release().setText(Fleet.T("phone.connected_opening_the_controls", new Pair[0]));
                                    mainActivity.ui.postDelayed(new MainActivity$$ExternalSyntheticLambda38(mainActivity, tv, 0), 10000L);
                                    return;
                                }
                                Intrinsics.throwUninitializedPropertyAccessException("waitName");
                                throw null;
                            }
                            break;
                    }
                    mainActivity.tv = null;
                    mainActivity.stopPicture$android_release();
                    if (mainActivity.wasLive) {
                        mainActivity.reconnect$android_release(TypingKt.explain(mainActivity, str3));
                        return;
                    }
                    mainActivity.getWaitStep$android_release().setText(Fleet.T("phone.adb_did_not_work", new Pair[0]));
                    String error = TypingKt.explain(mainActivity, str3);
                    Intrinsics.checkNotNullParameter(error, "error");
                    new Thread(new MainActivity$$ExternalSyntheticLambda41(mainActivity, str4, error)).start();
                    return;
                }
                return;
            default:
                MainActivity mainActivity2 = this.f$0;
                Tv tv3 = this.f$1;
                String str12 = this.f$2;
                String str13 = this.f$3;
                String str14 = mainActivity2.host;
                if (mainActivity2.pic == tv3 && tv3 != null && str14 != null) {
                    switch (str12.hashCode()) {
                        case -1357520532:
                            if (!str12.equals("closed")) {
                                return;
                            }
                            break;
                        case 3322092:
                            if (str12.equals("live")) {
                                mainActivity2.picLiveAt = SystemClock.elapsedRealtime();
                                mainActivity2.picShown = true;
                                PipKt.pipUpdate(mainActivity2);
                                Tv tv4 = mainActivity2.tv;
                                if (tv4 != null) {
                                    tv4.carry(tv3);
                                }
                                mainActivity2.ui.removeCallbacks(mainActivity2.countWatchers);
                                mainActivity2.ui.postDelayed(mainActivity2.countWatchers, 3000L);
                                mainActivity2.getWaiting$android_release().setVisibility(8);
                                TextView status$android_release5 = mainActivity2.getStatus$android_release();
                                String str15 = mainActivity2.entry;
                                if (str15 != null) {
                                    str14 = str15;
                                }
                                String title$android_release2 = mainActivity2.title$android_release(str14);
                                if (mainActivity2.listen) {
                                    T2 = Fleet.T("phone.listening_on_the_phone", new Pair[0]);
                                } else {
                                    T2 = Fleet.T("phone.touch_the_picture_to", new Pair[0]);
                                }
                                status$android_release5.setText(title$android_release2 + " · " + T2);
                                return;
                            }
                            return;
                        case 3493088:
                            if (str12.equals("rate")) {
                                TextView status$android_release6 = mainActivity2.getStatus$android_release();
                                String str16 = mainActivity2.entry;
                                if (str16 != null) {
                                    str14 = str16;
                                }
                                String title$android_release3 = mainActivity2.title$android_release(str14);
                                String str17 = "";
                                if (!mainActivity2.listen) {
                                    str = "";
                                } else {
                                    str = "🎧 ";
                                }
                                int i = mainActivity2.picWatchers;
                                if (i > 1) {
                                    str17 = ApkSigner$$ExternalSyntheticOutline0.m(" · 👁 ", i);
                                }
                                status$android_release6.setText(title$android_release3 + " · " + str + str13 + " KB/s" + str17);
                                return;
                            }
                            return;
                        case 96784904:
                            if (!str12.equals("error")) {
                                return;
                            }
                            break;
                        default:
                            return;
                    }
                    mainActivity2.pic = null;
                    Tv tv5 = mainActivity2.tv;
                    if (tv5 != null) {
                        tv5.carry(null);
                    }
                    Tv tv6 = mainActivity2.tv;
                    if (tv6 != null && tv6.ready()) {
                        if (mainActivity2.picLiveAt > 0 && SystemClock.elapsedRealtime() - mainActivity2.picLiveAt > 15000) {
                            mainActivity2.picTries = 0;
                        }
                        mainActivity2.picLiveAt = 0L;
                        int i2 = mainActivity2.picTries + 1;
                        mainActivity2.picTries = i2;
                        if (i2 <= 3) {
                            mainActivity2.ui.postDelayed(mainActivity2.picRetry, i2 * 1000);
                            return;
                        }
                        Tv tv7 = mainActivity2.tv;
                        if (tv7 != null) {
                            new Thread(new MainActivity$$ExternalSyntheticLambda9(tv7, mainActivity2, str14, 4)).start();
                            return;
                        }
                        return;
                    }
                    return;
                }
                return;
        }
    }
}
