package dev.tvremote.phone.remote;

import android.R;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.text.Editable;
import android.text.TextWatcher;
import android.transition.AutoTransition;
import android.transition.TransitionManager;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import com.android.apksig.internal.apk.ApkSigningBlockUtils$$ExternalSyntheticLambda0;
import dev.tvremote.core.Diagnose;
import dev.tvremote.core.Errors;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Words;
import dev.tvremote.core.Words$$ExternalSyntheticLambda1;
import dev.tvremote.core.ontv.Axml$$ExternalSyntheticLambda2;
import dev.tvremote.core.picture.SoundPace;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.remote.Atv;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.core.remote.Vidaa;
import dev.tvremote.core.remote.WebSocket;
import dev.tvremote.core.scenes.RemoteSpec$Entry;
import dev.tvremote.core.scenes.Scenes;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda12;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda7;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda8;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda9;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda10;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda12;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda30;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda38;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda9;
import dev.tvremote.phone.ir.IrRemoteKt$$ExternalSyntheticLambda22;
import dev.tvremote.phone.ir.IrRemoteKt$$ExternalSyntheticLambda60;
import dev.tvremote.phone.manage.Managing;
import dev.tvremote.phone.manage.UpdaterKt$$ExternalSyntheticLambda10;
import dev.tvremote.phone.media.MediaKt$$ExternalSyntheticLambda9;
import dev.tvremote.phone.media.NowApp;
import dev.tvremote.phone.media.NowApp$tick$1;
import dev.tvremote.phone.media.PlayingBar;
import dev.tvremote.phone.media.Talk$$ExternalSyntheticLambda8;
import dev.tvremote.phone.media.TalkKt$$ExternalSyntheticLambda1;
import dev.tvremote.phone.picker.AdbHelpKt;
import dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda3;
import dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda63;
import dev.tvremote.phone.picker.ManyTvsKt$$ExternalSyntheticLambda40;
import dev.tvremote.phone.picker.PickerScreenKt;
import dev.tvremote.phone.picker.PickerScreenKt$$ExternalSyntheticLambda11;
import dev.tvremote.phone.picker.PickerScreenKt$$ExternalSyntheticLambda4;
import dev.tvremote.phone.picture.Air;
import dev.tvremote.phone.picture.DrawView;
import dev.tvremote.phone.picture.DrawingKt$$ExternalSyntheticLambda0;
import dev.tvremote.phone.picture.DrawingKt$$ExternalSyntheticLambda22;
import dev.tvremote.phone.picture.DrawingKt$$ExternalSyntheticLambda3;
import dev.tvremote.phone.picture.DrawingKt$drawTools$step$1;
import dev.tvremote.phone.picture.PipKt;
import dev.tvremote.phone.picture.VideoFrame;
import dev.tvremote.phone.ui.IconButton;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.phone.ui.StatusText;
import dev.tvremote.phone.ui.UiKt;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.collections.EmptyList;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$BooleanRef;
import kotlin.jvm.internal.Ref$FloatRef;
import kotlin.jvm.internal.Ref$IntRef;
import kotlin.jvm.internal.Ref$LongRef;
import kotlin.jvm.internal.Ref$ObjectRef;
import kotlin.math.MathKt;
import kotlin.text.Regex;
import kotlin.text.Regex$$ExternalSyntheticLambda0;
import kotlin.text.StringsKt;
import org.conscrypt.FileClientSessionCache;
import org.conscrypt.metrics.ConscryptStatsLog;

/* loaded from: classes.dex */
public abstract class TypingKt {
    public static final int[] PIC_FPS = {0, 15, 30, 60};
    public static final int[] PIC_RATE = {0, 1, 2, 4, 8};

    /* JADX WARN: Type inference failed for: r15v0, types: [kotlin.jvm.internal.Ref$BooleanRef, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r1v0, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    /* JADX WARN: Type inference failed for: r4v0, types: [dev.tvremote.phone.remote.RemoteScreenKt$bindKey$again$1] */
    /* JADX WARN: Type inference failed for: r8v0, types: [kotlin.jvm.internal.Ref$IntRef, java.lang.Object] */
    public static final void bindKey(final int i, final GradientDrawable gradientDrawable, final Button button, final MainActivity mainActivity) {
        Drawable background = button.getBackground();
        final ?? obj = new Object();
        final ?? obj2 = new Object();
        final ?? obj3 = new Object();
        final ?? r4 = new Runnable() { // from class: dev.tvremote.phone.remote.RemoteScreenKt$bindKey$again$1
            @Override // java.lang.Runnable
            public final void run() {
                Remote remote;
                if (!Ref$BooleanRef.this.element) {
                    return;
                }
                Ref$IntRef ref$IntRef = obj2;
                int i2 = ref$IntRef.element + 1;
                ref$IntRef.element = i2;
                MainActivity mainActivity2 = mainActivity;
                int i3 = i;
                if (i2 == 0) {
                    mainActivity2.buzz$android_release();
                }
                Tv tv = mainActivity2.tv;
                if (tv != null) {
                    tv.key(0, i3, i2, 0);
                } else if (i2 == 0 && (remote = mainActivity2.basic) != null) {
                    remote.key(i3, 1);
                }
                mainActivity2.ui.postDelayed(this, 80L);
            }
        };
        final RemoteScreenKt$$ExternalSyntheticLambda50 remoteScreenKt$$ExternalSyntheticLambda50 = new RemoteScreenKt$$ExternalSyntheticLambda50(obj3, obj, mainActivity, r4, i, button, background);
        button.setOnTouchListener(new View.OnTouchListener() { // from class: dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda51
            @Override // android.view.View.OnTouchListener
            public final boolean onTouch(View view, MotionEvent motionEvent) {
                boolean z;
                boolean z2 = false;
                if (motionEvent.getX() >= 0.0f && motionEvent.getY() >= 0.0f && motionEvent.getX() <= view.getWidth() && motionEvent.getY() <= view.getHeight()) {
                    z = true;
                } else {
                    z = false;
                }
                final Button button2 = button;
                Object tag = button2.getTag();
                final MainActivity mainActivity2 = mainActivity;
                if (tag == "kind-off") {
                    if (motionEvent.getActionMasked() == 1 && z) {
                        PhoneRemoteKt.kindOff(mainActivity2);
                        return true;
                    }
                } else {
                    int actionMasked = motionEvent.getActionMasked();
                    final Ref$ObjectRef ref$ObjectRef = obj3;
                    final GradientDrawable gradientDrawable2 = gradientDrawable;
                    final int i2 = i;
                    if (actionMasked != 0) {
                        RemoteScreenKt$$ExternalSyntheticLambda50 remoteScreenKt$$ExternalSyntheticLambda502 = remoteScreenKt$$ExternalSyntheticLambda50;
                        if (actionMasked != 1) {
                            if (actionMasked != 2) {
                                if (actionMasked == 3) {
                                    remoteScreenKt$$ExternalSyntheticLambda502.invoke();
                                    return true;
                                }
                            } else if (!z) {
                                remoteScreenKt$$ExternalSyntheticLambda502.invoke();
                                return true;
                            }
                        } else {
                            if (ref$ObjectRef.element != null && z) {
                                z2 = true;
                            }
                            remoteScreenKt$$ExternalSyntheticLambda502.invoke();
                            if (z2 && mainActivity2.live$android_release()) {
                                mainActivity2.press$android_release(true, i2);
                                TypingKt.flash(mainActivity2, button2, gradientDrawable2);
                            }
                        }
                    } else {
                        final Ref$BooleanRef ref$BooleanRef = obj;
                        final Ref$IntRef ref$IntRef = obj2;
                        final RemoteScreenKt$bindKey$again$1 remoteScreenKt$bindKey$again$1 = r4;
                        Runnable runnable = new Runnable() { // from class: dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda60
                            @Override // java.lang.Runnable
                            public final void run() {
                                MainActivity mainActivity3 = MainActivity.this;
                                if (!mainActivity3.live$android_release()) {
                                    return;
                                }
                                ref$ObjectRef.element = null;
                                ref$BooleanRef.element = true;
                                ref$IntRef.element = 0;
                                button2.setBackground(gradientDrawable2);
                                int i3 = i2;
                                mainActivity3.buzz$android_release();
                                Tv tv = mainActivity3.tv;
                                if (tv != null) {
                                    tv.key(0, i3, 0, 0);
                                } else {
                                    Remote remote = mainActivity3.basic;
                                    if (remote != null) {
                                        remote.key(i3, 1);
                                    }
                                }
                                mainActivity3.ui.postDelayed(remoteScreenKt$bindKey$again$1, 80L);
                            }
                        };
                        ref$ObjectRef.element = runnable;
                        mainActivity2.ui.postDelayed(runnable, 400L);
                        return true;
                    }
                }
                return true;
            }
        });
    }

    /* JADX WARN: Type inference failed for: r1v8, types: [dev.tvremote.phone.picture.VideoFrame, android.widget.FrameLayout] */
    /* JADX WARN: Type inference failed for: r7v120, types: [kotlin.jvm.internal.Ref$IntRef, java.lang.Object] */
    public static final void buildRemote(final MainActivity mainActivity) {
        int i;
        Iterator it;
        int i2;
        String T;
        int i3;
        final int i4 = 5;
        final int i5 = 0;
        final int i6 = 1;
        mainActivity.remote = UiKt.col(mainActivity);
        mainActivity.status = new StatusText(mainActivity);
        mainActivity.videoBtn = UiKt.icon(mainActivity, "@eye_off", "", UiKt.BTN);
        mainActivity.getVideoBtn$android_release().setOnClickListener(new View.OnClickListener() { // from class: dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i7 = 5;
                int i8 = 3;
                int i9 = 29;
                int i10 = 4;
                int i11 = 6;
                int i12 = 1;
                int i13 = 0;
                switch (i5) {
                    case 0:
                        mainActivity.toggleVideo$android_release();
                        return;
                    case 1:
                        Regex regex = AdbHelpKt.TV_HOME;
                        MainActivity mainActivity2 = mainActivity;
                        UiKt.menu(mainActivity2, Fleet.T("setup.turn_on_adb", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@zap|", Fleet.T("adb_help.automatic_install_tv_setup", new Pair[0])), Fleet.T("adb_help.just_confirm_on_the", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity2, 24)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@gear|", Fleet.T("adb_help.by_hand_open_tv", new Pair[0])), "", new TalkKt$$ExternalSyntheticLambda1(mainActivity2, 25)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@home|", Fleet.T("adb_help.install_another_home_screen", new Pair[0])), Fleet.T("adb_help.when_the_tv_hides", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity2, i9)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@wifi|", Fleet.T("setup.wireless_title", new Pair[0])), Fleet.T("adb_help.android_11_or_newer", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i13)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@refresh|", Fleet.T("adb_help.full_connection", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i8)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@store|", Fleet.T("adb_help.open_the_play_store", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i10)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@package|", Fleet.T("adb_help.open_an_app_by", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i7)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@link|", Fleet.T("setup.direct_title", new Pair[0])), Fleet.T("adb_help.a_fallback_not_reliable", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i11))}));
                        return;
                    case 2:
                        TypingKt.setLive(mainActivity, !r1.live);
                        return;
                    case 3:
                        MainActivity mainActivity3 = mainActivity;
                        Intrinsics.checkNotNullParameter(mainActivity3, "<this>");
                        mainActivity3.getPrefs$android_release().edit().putBoolean("listenEven", !mainActivity3.getPrefs$android_release().getBoolean("listenEven", false)).apply();
                        Fleet.soundChanged(mainActivity3);
                        return;
                    case 4:
                        TypingKt.sendText(mainActivity);
                        return;
                    case 5:
                        mainActivity.onBackPressed();
                        return;
                    case 6:
                        mainActivity.leave$android_release();
                        return;
                    case 7:
                        Fleet.toggleListen(mainActivity);
                        return;
                    case 8:
                        MainActivity mainActivity4 = mainActivity;
                        TextView label = UiKt.label(mainActivity4, TypingKt.gainWords(TypingKt.listenGain(mainActivity4)), 17, -1);
                        label.setTypeface(Typeface.DEFAULT_BOLD);
                        label.setGravity(8388629);
                        SeekBar seekBar = new SeekBar(mainActivity4);
                        seekBar.setMax(19);
                        seekBar.setContentDescription(Fleet.T("listen.loudness", new Pair[0]));
                        Axml$$ExternalSyntheticLambda2 axml$$ExternalSyntheticLambda2 = new Axml$$ExternalSyntheticLambda2(11, mainActivity4, label);
                        seekBar.setProgress((int) ((TypingKt.listenGain(mainActivity4) - 0.5f) * 2));
                        seekBar.setOnSeekBarChangeListener(new PlayingBar.AnonymousClass5(i12, axml$$ExternalSyntheticLambda2));
                        LinearLayout linearLayout = new LinearLayout(mainActivity4);
                        linearLayout.setGravity(16);
                        linearLayout.addView(seekBar, new LinearLayout.LayoutParams(0, UiKt.dp(mainActivity4, 48), 1.0f));
                        linearLayout.addView(label, new LinearLayout.LayoutParams(UiKt.dp(mainActivity4, 56), -2));
                        LinearLayout linearLayout2 = new LinearLayout(mainActivity4);
                        linearLayout2.setOrientation(1);
                        linearLayout2.addView(linearLayout);
                        TextView label2 = UiKt.label(mainActivity4, Fleet.T("listen.boost_note", new Pair[0]), 14, UiKt.DIM);
                        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
                        layoutParams.topMargin = UiKt.dp(mainActivity4, 8);
                        linearLayout2.addView(label2, layoutParams);
                        Popup.Builder builder = new Popup.Builder(mainActivity4);
                        builder.title = Fleet.T("remote_screen.loudness_on_the_phone_2", new Pair[0]);
                        builder.view = UiKt.inDialog(mainActivity4, linearLayout2);
                        builder.setNeutralButton(Fleet.T("listen.back_to_x1", new Pair[0]), null);
                        builder.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                        builder.show().getButton(-3).setOnClickListener(new Guard$$ExternalSyntheticLambda9(7, seekBar, axml$$ExternalSyntheticLambda2));
                        return;
                    case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                        MainActivity mainActivity5 = mainActivity;
                        Object systemService = mainActivity5.getSystemService("input_method");
                        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
                        ((InputMethodManager) systemService).hideSoftInputFromWindow(view.getWindowToken(), 0);
                        if (!mainActivity5.needsAdb$android_release()) {
                            Managing.open$default(mainActivity5.getManaging$android_release(), mainActivity5.host, null, null, 6);
                            return;
                        }
                        return;
                    case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                        mainActivity.setFullscreen$android_release(false);
                        return;
                    case 11:
                        MainActivity mainActivity6 = mainActivity;
                        LinearLayout col = UiKt.col(mainActivity6);
                        LinearLayout linearLayout3 = new LinearLayout(mainActivity6);
                        LinearLayout linearLayout4 = new LinearLayout(mainActivity6);
                        LinearLayout linearLayout5 = new LinearLayout(mainActivity6);
                        LinearLayout linearLayout6 = new LinearLayout(mainActivity6);
                        TypingKt.qualityMenu$draw(mainActivity6, linearLayout3, linearLayout4, linearLayout5, linearLayout6);
                        col.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.size", new Pair[0])));
                        col.addView(linearLayout3, UiKt.gap(mainActivity6, 6));
                        col.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.frames_per_second", new Pair[0])), UiKt.gap(mainActivity6, 14));
                        col.addView(linearLayout4, UiKt.gap(mainActivity6, 6));
                        col.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.bit_rate_mbit_s", new Pair[0])), UiKt.gap(mainActivity6, 14));
                        col.addView(linearLayout5, UiKt.gap(mainActivity6, 6));
                        col.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.encoder", new Pair[0])), UiKt.gap(mainActivity6, 14));
                        col.addView(linearLayout6, UiKt.gap(mainActivity6, 6));
                        Popup.Builder builder2 = new Popup.Builder(mainActivity6);
                        builder2.title = Fleet.T("remote_screen.picture_quality", new Pair[0]);
                        builder2.view = UiKt.inDialog(mainActivity6, col);
                        builder2.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                        builder2.show();
                        return;
                    case FileClientSessionCache.MAX_SIZE /* 12 */:
                        final MainActivity mainActivity7 = mainActivity;
                        final boolean z = mainActivity7.getPrefs$android_release().getBoolean("listenShare", false);
                        PopupMenu popupMenu = new PopupMenu(mainActivity7, mainActivity7.getListenChip$android_release());
                        MenuItem add = popupMenu.getMenu().add(1, 0, 0, Fleet.T("listen.only_the_phone", new Pair[0]));
                        add.setIcon(TypingKt.listenArt(mainActivity7, false));
                        add.setChecked(!z);
                        MenuItem add2 = popupMenu.getMenu().add(1, 1, 1, Fleet.T("listen.tv_and_phone", new Pair[0]));
                        add2.setIcon(TypingKt.listenArt(mainActivity7, true));
                        add2.setChecked(z);
                        popupMenu.getMenu().setGroupCheckable(1, true, true);
                        if (Build.VERSION.SDK_INT >= 29) {
                            popupMenu.setForceShowIcon(true);
                        }
                        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: dev.tvremote.phone.media.ListenKt$$ExternalSyntheticLambda2
                            @Override // android.widget.PopupMenu.OnMenuItemClickListener
                            public final boolean onMenuItemClick(MenuItem menuItem) {
                                boolean z2;
                                boolean z3 = false;
                                if (menuItem.getItemId() == 1) {
                                    z2 = true;
                                } else {
                                    z2 = false;
                                }
                                if (z2 != z) {
                                    MainActivity mainActivity8 = mainActivity7;
                                    SharedPreferences.Editor edit = mainActivity8.getPrefs$android_release().edit();
                                    if (menuItem.getItemId() == 1) {
                                        z3 = true;
                                    }
                                    edit.putBoolean("listenShare", z3).apply();
                                    Fleet.soundChanged(mainActivity8);
                                }
                                return true;
                            }
                        });
                        popupMenu.show();
                        return;
                    case 13:
                        MainActivity mainActivity8 = mainActivity;
                        Intrinsics.checkNotNullParameter(mainActivity8, "<this>");
                        mainActivity8.getPrefs$android_release().edit().putBoolean("listenHq", !mainActivity8.getPrefs$android_release().getBoolean("listenHq", false)).apply();
                        Fleet.soundChanged(mainActivity8);
                        return;
                    case 14:
                        mainActivity.setFullscreen$android_release(true);
                        return;
                    case 15:
                        ArrayList arrayList = PipKt.hidden;
                        MainActivity mainActivity9 = mainActivity;
                        if (mainActivity9.floating) {
                            PipKt.unfloat(mainActivity9);
                            return;
                        } else {
                            if (PipKt.picLive(mainActivity9)) {
                                mainActivity9.floating = true;
                                PipKt.setFloat(1, mainActivity9);
                                TypingKt.layoutRemote(mainActivity9);
                                return;
                            }
                            return;
                        }
                    case 16:
                        MainActivity mainActivity10 = mainActivity;
                        if (mainActivity10.basic != null) {
                            mainActivity10.press$android_release(true, 26);
                            return;
                        }
                        Tv tv = mainActivity10.tv;
                        if (tv != null && tv.ready()) {
                            new Thread(new MainActivity$$ExternalSyntheticLambda38(tv, mainActivity10, i10)).start();
                            return;
                        }
                        return;
                    default:
                        MainActivity mainActivity11 = mainActivity;
                        String pref$android_release = mainActivity11.pref$android_release("talkMode");
                        if (pref$android_release.equals("quick")) {
                            mainActivity11.getTalk$android_release().open();
                            return;
                        } else if (pref$android_release.equals("old")) {
                            mainActivity11.speak$android_release();
                            return;
                        } else {
                            UiKt.menu(mainActivity11, Fleet.T("talk.choose_title", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_quick", new Pair[0])), Fleet.T("talk.mode_quick_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 21)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_old", new Pair[0])), Fleet.T("talk.mode_old_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 22))}));
                            return;
                        }
                }
            }
        });
        Button button = UiKt.button(mainActivity, Fleet.T("remote_screen.keys_only_turn_on", new Pair[0]), UiKt.ACCENT);
        mainActivity.basicBar = button;
        button.setTextSize(13.0f);
        Button button2 = mainActivity.basicBar;
        if (button2 != null) {
            button2.setOnClickListener(new View.OnClickListener() { // from class: dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    int i7 = 5;
                    int i8 = 3;
                    int i9 = 29;
                    int i10 = 4;
                    int i11 = 6;
                    int i12 = 1;
                    int i13 = 0;
                    switch (i6) {
                        case 0:
                            mainActivity.toggleVideo$android_release();
                            return;
                        case 1:
                            Regex regex = AdbHelpKt.TV_HOME;
                            MainActivity mainActivity2 = mainActivity;
                            UiKt.menu(mainActivity2, Fleet.T("setup.turn_on_adb", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@zap|", Fleet.T("adb_help.automatic_install_tv_setup", new Pair[0])), Fleet.T("adb_help.just_confirm_on_the", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity2, 24)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@gear|", Fleet.T("adb_help.by_hand_open_tv", new Pair[0])), "", new TalkKt$$ExternalSyntheticLambda1(mainActivity2, 25)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@home|", Fleet.T("adb_help.install_another_home_screen", new Pair[0])), Fleet.T("adb_help.when_the_tv_hides", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity2, i9)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@wifi|", Fleet.T("setup.wireless_title", new Pair[0])), Fleet.T("adb_help.android_11_or_newer", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i13)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@refresh|", Fleet.T("adb_help.full_connection", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i8)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@store|", Fleet.T("adb_help.open_the_play_store", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i10)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@package|", Fleet.T("adb_help.open_an_app_by", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i7)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@link|", Fleet.T("setup.direct_title", new Pair[0])), Fleet.T("adb_help.a_fallback_not_reliable", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i11))}));
                            return;
                        case 2:
                            TypingKt.setLive(mainActivity, !r1.live);
                            return;
                        case 3:
                            MainActivity mainActivity3 = mainActivity;
                            Intrinsics.checkNotNullParameter(mainActivity3, "<this>");
                            mainActivity3.getPrefs$android_release().edit().putBoolean("listenEven", !mainActivity3.getPrefs$android_release().getBoolean("listenEven", false)).apply();
                            Fleet.soundChanged(mainActivity3);
                            return;
                        case 4:
                            TypingKt.sendText(mainActivity);
                            return;
                        case 5:
                            mainActivity.onBackPressed();
                            return;
                        case 6:
                            mainActivity.leave$android_release();
                            return;
                        case 7:
                            Fleet.toggleListen(mainActivity);
                            return;
                        case 8:
                            MainActivity mainActivity4 = mainActivity;
                            TextView label = UiKt.label(mainActivity4, TypingKt.gainWords(TypingKt.listenGain(mainActivity4)), 17, -1);
                            label.setTypeface(Typeface.DEFAULT_BOLD);
                            label.setGravity(8388629);
                            SeekBar seekBar = new SeekBar(mainActivity4);
                            seekBar.setMax(19);
                            seekBar.setContentDescription(Fleet.T("listen.loudness", new Pair[0]));
                            Axml$$ExternalSyntheticLambda2 axml$$ExternalSyntheticLambda2 = new Axml$$ExternalSyntheticLambda2(11, mainActivity4, label);
                            seekBar.setProgress((int) ((TypingKt.listenGain(mainActivity4) - 0.5f) * 2));
                            seekBar.setOnSeekBarChangeListener(new PlayingBar.AnonymousClass5(i12, axml$$ExternalSyntheticLambda2));
                            LinearLayout linearLayout = new LinearLayout(mainActivity4);
                            linearLayout.setGravity(16);
                            linearLayout.addView(seekBar, new LinearLayout.LayoutParams(0, UiKt.dp(mainActivity4, 48), 1.0f));
                            linearLayout.addView(label, new LinearLayout.LayoutParams(UiKt.dp(mainActivity4, 56), -2));
                            LinearLayout linearLayout2 = new LinearLayout(mainActivity4);
                            linearLayout2.setOrientation(1);
                            linearLayout2.addView(linearLayout);
                            TextView label2 = UiKt.label(mainActivity4, Fleet.T("listen.boost_note", new Pair[0]), 14, UiKt.DIM);
                            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
                            layoutParams.topMargin = UiKt.dp(mainActivity4, 8);
                            linearLayout2.addView(label2, layoutParams);
                            Popup.Builder builder = new Popup.Builder(mainActivity4);
                            builder.title = Fleet.T("remote_screen.loudness_on_the_phone_2", new Pair[0]);
                            builder.view = UiKt.inDialog(mainActivity4, linearLayout2);
                            builder.setNeutralButton(Fleet.T("listen.back_to_x1", new Pair[0]), null);
                            builder.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                            builder.show().getButton(-3).setOnClickListener(new Guard$$ExternalSyntheticLambda9(7, seekBar, axml$$ExternalSyntheticLambda2));
                            return;
                        case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                            MainActivity mainActivity5 = mainActivity;
                            Object systemService = mainActivity5.getSystemService("input_method");
                            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
                            ((InputMethodManager) systemService).hideSoftInputFromWindow(view.getWindowToken(), 0);
                            if (!mainActivity5.needsAdb$android_release()) {
                                Managing.open$default(mainActivity5.getManaging$android_release(), mainActivity5.host, null, null, 6);
                                return;
                            }
                            return;
                        case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                            mainActivity.setFullscreen$android_release(false);
                            return;
                        case 11:
                            MainActivity mainActivity6 = mainActivity;
                            LinearLayout col = UiKt.col(mainActivity6);
                            LinearLayout linearLayout3 = new LinearLayout(mainActivity6);
                            LinearLayout linearLayout4 = new LinearLayout(mainActivity6);
                            LinearLayout linearLayout5 = new LinearLayout(mainActivity6);
                            LinearLayout linearLayout6 = new LinearLayout(mainActivity6);
                            TypingKt.qualityMenu$draw(mainActivity6, linearLayout3, linearLayout4, linearLayout5, linearLayout6);
                            col.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.size", new Pair[0])));
                            col.addView(linearLayout3, UiKt.gap(mainActivity6, 6));
                            col.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.frames_per_second", new Pair[0])), UiKt.gap(mainActivity6, 14));
                            col.addView(linearLayout4, UiKt.gap(mainActivity6, 6));
                            col.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.bit_rate_mbit_s", new Pair[0])), UiKt.gap(mainActivity6, 14));
                            col.addView(linearLayout5, UiKt.gap(mainActivity6, 6));
                            col.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.encoder", new Pair[0])), UiKt.gap(mainActivity6, 14));
                            col.addView(linearLayout6, UiKt.gap(mainActivity6, 6));
                            Popup.Builder builder2 = new Popup.Builder(mainActivity6);
                            builder2.title = Fleet.T("remote_screen.picture_quality", new Pair[0]);
                            builder2.view = UiKt.inDialog(mainActivity6, col);
                            builder2.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                            builder2.show();
                            return;
                        case FileClientSessionCache.MAX_SIZE /* 12 */:
                            final MainActivity mainActivity7 = mainActivity;
                            final boolean z = mainActivity7.getPrefs$android_release().getBoolean("listenShare", false);
                            PopupMenu popupMenu = new PopupMenu(mainActivity7, mainActivity7.getListenChip$android_release());
                            MenuItem add = popupMenu.getMenu().add(1, 0, 0, Fleet.T("listen.only_the_phone", new Pair[0]));
                            add.setIcon(TypingKt.listenArt(mainActivity7, false));
                            add.setChecked(!z);
                            MenuItem add2 = popupMenu.getMenu().add(1, 1, 1, Fleet.T("listen.tv_and_phone", new Pair[0]));
                            add2.setIcon(TypingKt.listenArt(mainActivity7, true));
                            add2.setChecked(z);
                            popupMenu.getMenu().setGroupCheckable(1, true, true);
                            if (Build.VERSION.SDK_INT >= 29) {
                                popupMenu.setForceShowIcon(true);
                            }
                            popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: dev.tvremote.phone.media.ListenKt$$ExternalSyntheticLambda2
                                @Override // android.widget.PopupMenu.OnMenuItemClickListener
                                public final boolean onMenuItemClick(MenuItem menuItem) {
                                    boolean z2;
                                    boolean z3 = false;
                                    if (menuItem.getItemId() == 1) {
                                        z2 = true;
                                    } else {
                                        z2 = false;
                                    }
                                    if (z2 != z) {
                                        MainActivity mainActivity8 = mainActivity7;
                                        SharedPreferences.Editor edit = mainActivity8.getPrefs$android_release().edit();
                                        if (menuItem.getItemId() == 1) {
                                            z3 = true;
                                        }
                                        edit.putBoolean("listenShare", z3).apply();
                                        Fleet.soundChanged(mainActivity8);
                                    }
                                    return true;
                                }
                            });
                            popupMenu.show();
                            return;
                        case 13:
                            MainActivity mainActivity8 = mainActivity;
                            Intrinsics.checkNotNullParameter(mainActivity8, "<this>");
                            mainActivity8.getPrefs$android_release().edit().putBoolean("listenHq", !mainActivity8.getPrefs$android_release().getBoolean("listenHq", false)).apply();
                            Fleet.soundChanged(mainActivity8);
                            return;
                        case 14:
                            mainActivity.setFullscreen$android_release(true);
                            return;
                        case 15:
                            ArrayList arrayList = PipKt.hidden;
                            MainActivity mainActivity9 = mainActivity;
                            if (mainActivity9.floating) {
                                PipKt.unfloat(mainActivity9);
                                return;
                            } else {
                                if (PipKt.picLive(mainActivity9)) {
                                    mainActivity9.floating = true;
                                    PipKt.setFloat(1, mainActivity9);
                                    TypingKt.layoutRemote(mainActivity9);
                                    return;
                                }
                                return;
                            }
                        case 16:
                            MainActivity mainActivity10 = mainActivity;
                            if (mainActivity10.basic != null) {
                                mainActivity10.press$android_release(true, 26);
                                return;
                            }
                            Tv tv = mainActivity10.tv;
                            if (tv != null && tv.ready()) {
                                new Thread(new MainActivity$$ExternalSyntheticLambda38(tv, mainActivity10, i10)).start();
                                return;
                            }
                            return;
                        default:
                            MainActivity mainActivity11 = mainActivity;
                            String pref$android_release = mainActivity11.pref$android_release("talkMode");
                            if (pref$android_release.equals("quick")) {
                                mainActivity11.getTalk$android_release().open();
                                return;
                            } else if (pref$android_release.equals("old")) {
                                mainActivity11.speak$android_release();
                                return;
                            } else {
                                UiKt.menu(mainActivity11, Fleet.T("talk.choose_title", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_quick", new Pair[0])), Fleet.T("talk.mode_quick_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 21)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_old", new Pair[0])), Fleet.T("talk.mode_old_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 22))}));
                                return;
                            }
                    }
                }
            });
            LinearLayout linearLayout = new LinearLayout(mainActivity);
            mainActivity.topBar = linearLayout;
            linearLayout.setGravity(16);
            LinearLayout linearLayout2 = new LinearLayout(mainActivity);
            linearLayout2.setGravity(16);
            IconButton icon = UiKt.icon(mainActivity, "@left", Fleet.T("remote_screen.back_to_the_tvs", new Pair[0]), UiKt.BTN);
            icon.setBackground(UiKt.box(mainActivity, UiKt.BTN, 16));
            icon.setOnClickListener(new View.OnClickListener() { // from class: dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    int i7 = 5;
                    int i8 = 3;
                    int i9 = 29;
                    int i10 = 4;
                    int i11 = 6;
                    int i12 = 1;
                    int i13 = 0;
                    switch (i4) {
                        case 0:
                            mainActivity.toggleVideo$android_release();
                            return;
                        case 1:
                            Regex regex = AdbHelpKt.TV_HOME;
                            MainActivity mainActivity2 = mainActivity;
                            UiKt.menu(mainActivity2, Fleet.T("setup.turn_on_adb", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@zap|", Fleet.T("adb_help.automatic_install_tv_setup", new Pair[0])), Fleet.T("adb_help.just_confirm_on_the", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity2, 24)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@gear|", Fleet.T("adb_help.by_hand_open_tv", new Pair[0])), "", new TalkKt$$ExternalSyntheticLambda1(mainActivity2, 25)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@home|", Fleet.T("adb_help.install_another_home_screen", new Pair[0])), Fleet.T("adb_help.when_the_tv_hides", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity2, i9)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@wifi|", Fleet.T("setup.wireless_title", new Pair[0])), Fleet.T("adb_help.android_11_or_newer", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i13)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@refresh|", Fleet.T("adb_help.full_connection", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i8)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@store|", Fleet.T("adb_help.open_the_play_store", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i10)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@package|", Fleet.T("adb_help.open_an_app_by", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i7)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@link|", Fleet.T("setup.direct_title", new Pair[0])), Fleet.T("adb_help.a_fallback_not_reliable", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i11))}));
                            return;
                        case 2:
                            TypingKt.setLive(mainActivity, !r1.live);
                            return;
                        case 3:
                            MainActivity mainActivity3 = mainActivity;
                            Intrinsics.checkNotNullParameter(mainActivity3, "<this>");
                            mainActivity3.getPrefs$android_release().edit().putBoolean("listenEven", !mainActivity3.getPrefs$android_release().getBoolean("listenEven", false)).apply();
                            Fleet.soundChanged(mainActivity3);
                            return;
                        case 4:
                            TypingKt.sendText(mainActivity);
                            return;
                        case 5:
                            mainActivity.onBackPressed();
                            return;
                        case 6:
                            mainActivity.leave$android_release();
                            return;
                        case 7:
                            Fleet.toggleListen(mainActivity);
                            return;
                        case 8:
                            MainActivity mainActivity4 = mainActivity;
                            TextView label = UiKt.label(mainActivity4, TypingKt.gainWords(TypingKt.listenGain(mainActivity4)), 17, -1);
                            label.setTypeface(Typeface.DEFAULT_BOLD);
                            label.setGravity(8388629);
                            SeekBar seekBar = new SeekBar(mainActivity4);
                            seekBar.setMax(19);
                            seekBar.setContentDescription(Fleet.T("listen.loudness", new Pair[0]));
                            Axml$$ExternalSyntheticLambda2 axml$$ExternalSyntheticLambda2 = new Axml$$ExternalSyntheticLambda2(11, mainActivity4, label);
                            seekBar.setProgress((int) ((TypingKt.listenGain(mainActivity4) - 0.5f) * 2));
                            seekBar.setOnSeekBarChangeListener(new PlayingBar.AnonymousClass5(i12, axml$$ExternalSyntheticLambda2));
                            LinearLayout linearLayout3 = new LinearLayout(mainActivity4);
                            linearLayout3.setGravity(16);
                            linearLayout3.addView(seekBar, new LinearLayout.LayoutParams(0, UiKt.dp(mainActivity4, 48), 1.0f));
                            linearLayout3.addView(label, new LinearLayout.LayoutParams(UiKt.dp(mainActivity4, 56), -2));
                            LinearLayout linearLayout22 = new LinearLayout(mainActivity4);
                            linearLayout22.setOrientation(1);
                            linearLayout22.addView(linearLayout3);
                            TextView label2 = UiKt.label(mainActivity4, Fleet.T("listen.boost_note", new Pair[0]), 14, UiKt.DIM);
                            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
                            layoutParams.topMargin = UiKt.dp(mainActivity4, 8);
                            linearLayout22.addView(label2, layoutParams);
                            Popup.Builder builder = new Popup.Builder(mainActivity4);
                            builder.title = Fleet.T("remote_screen.loudness_on_the_phone_2", new Pair[0]);
                            builder.view = UiKt.inDialog(mainActivity4, linearLayout22);
                            builder.setNeutralButton(Fleet.T("listen.back_to_x1", new Pair[0]), null);
                            builder.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                            builder.show().getButton(-3).setOnClickListener(new Guard$$ExternalSyntheticLambda9(7, seekBar, axml$$ExternalSyntheticLambda2));
                            return;
                        case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                            MainActivity mainActivity5 = mainActivity;
                            Object systemService = mainActivity5.getSystemService("input_method");
                            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
                            ((InputMethodManager) systemService).hideSoftInputFromWindow(view.getWindowToken(), 0);
                            if (!mainActivity5.needsAdb$android_release()) {
                                Managing.open$default(mainActivity5.getManaging$android_release(), mainActivity5.host, null, null, 6);
                                return;
                            }
                            return;
                        case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                            mainActivity.setFullscreen$android_release(false);
                            return;
                        case 11:
                            MainActivity mainActivity6 = mainActivity;
                            LinearLayout col = UiKt.col(mainActivity6);
                            LinearLayout linearLayout32 = new LinearLayout(mainActivity6);
                            LinearLayout linearLayout4 = new LinearLayout(mainActivity6);
                            LinearLayout linearLayout5 = new LinearLayout(mainActivity6);
                            LinearLayout linearLayout6 = new LinearLayout(mainActivity6);
                            TypingKt.qualityMenu$draw(mainActivity6, linearLayout32, linearLayout4, linearLayout5, linearLayout6);
                            col.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.size", new Pair[0])));
                            col.addView(linearLayout32, UiKt.gap(mainActivity6, 6));
                            col.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.frames_per_second", new Pair[0])), UiKt.gap(mainActivity6, 14));
                            col.addView(linearLayout4, UiKt.gap(mainActivity6, 6));
                            col.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.bit_rate_mbit_s", new Pair[0])), UiKt.gap(mainActivity6, 14));
                            col.addView(linearLayout5, UiKt.gap(mainActivity6, 6));
                            col.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.encoder", new Pair[0])), UiKt.gap(mainActivity6, 14));
                            col.addView(linearLayout6, UiKt.gap(mainActivity6, 6));
                            Popup.Builder builder2 = new Popup.Builder(mainActivity6);
                            builder2.title = Fleet.T("remote_screen.picture_quality", new Pair[0]);
                            builder2.view = UiKt.inDialog(mainActivity6, col);
                            builder2.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                            builder2.show();
                            return;
                        case FileClientSessionCache.MAX_SIZE /* 12 */:
                            final MainActivity mainActivity7 = mainActivity;
                            final boolean z = mainActivity7.getPrefs$android_release().getBoolean("listenShare", false);
                            PopupMenu popupMenu = new PopupMenu(mainActivity7, mainActivity7.getListenChip$android_release());
                            MenuItem add = popupMenu.getMenu().add(1, 0, 0, Fleet.T("listen.only_the_phone", new Pair[0]));
                            add.setIcon(TypingKt.listenArt(mainActivity7, false));
                            add.setChecked(!z);
                            MenuItem add2 = popupMenu.getMenu().add(1, 1, 1, Fleet.T("listen.tv_and_phone", new Pair[0]));
                            add2.setIcon(TypingKt.listenArt(mainActivity7, true));
                            add2.setChecked(z);
                            popupMenu.getMenu().setGroupCheckable(1, true, true);
                            if (Build.VERSION.SDK_INT >= 29) {
                                popupMenu.setForceShowIcon(true);
                            }
                            popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: dev.tvremote.phone.media.ListenKt$$ExternalSyntheticLambda2
                                @Override // android.widget.PopupMenu.OnMenuItemClickListener
                                public final boolean onMenuItemClick(MenuItem menuItem) {
                                    boolean z2;
                                    boolean z3 = false;
                                    if (menuItem.getItemId() == 1) {
                                        z2 = true;
                                    } else {
                                        z2 = false;
                                    }
                                    if (z2 != z) {
                                        MainActivity mainActivity8 = mainActivity7;
                                        SharedPreferences.Editor edit = mainActivity8.getPrefs$android_release().edit();
                                        if (menuItem.getItemId() == 1) {
                                            z3 = true;
                                        }
                                        edit.putBoolean("listenShare", z3).apply();
                                        Fleet.soundChanged(mainActivity8);
                                    }
                                    return true;
                                }
                            });
                            popupMenu.show();
                            return;
                        case 13:
                            MainActivity mainActivity8 = mainActivity;
                            Intrinsics.checkNotNullParameter(mainActivity8, "<this>");
                            mainActivity8.getPrefs$android_release().edit().putBoolean("listenHq", !mainActivity8.getPrefs$android_release().getBoolean("listenHq", false)).apply();
                            Fleet.soundChanged(mainActivity8);
                            return;
                        case 14:
                            mainActivity.setFullscreen$android_release(true);
                            return;
                        case 15:
                            ArrayList arrayList = PipKt.hidden;
                            MainActivity mainActivity9 = mainActivity;
                            if (mainActivity9.floating) {
                                PipKt.unfloat(mainActivity9);
                                return;
                            } else {
                                if (PipKt.picLive(mainActivity9)) {
                                    mainActivity9.floating = true;
                                    PipKt.setFloat(1, mainActivity9);
                                    TypingKt.layoutRemote(mainActivity9);
                                    return;
                                }
                                return;
                            }
                        case 16:
                            MainActivity mainActivity10 = mainActivity;
                            if (mainActivity10.basic != null) {
                                mainActivity10.press$android_release(true, 26);
                                return;
                            }
                            Tv tv = mainActivity10.tv;
                            if (tv != null && tv.ready()) {
                                new Thread(new MainActivity$$ExternalSyntheticLambda38(tv, mainActivity10, i10)).start();
                                return;
                            }
                            return;
                        default:
                            MainActivity mainActivity11 = mainActivity;
                            String pref$android_release = mainActivity11.pref$android_release("talkMode");
                            if (pref$android_release.equals("quick")) {
                                mainActivity11.getTalk$android_release().open();
                                return;
                            } else if (pref$android_release.equals("old")) {
                                mainActivity11.speak$android_release();
                                return;
                            } else {
                                UiKt.menu(mainActivity11, Fleet.T("talk.choose_title", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_quick", new Pair[0])), Fleet.T("talk.mode_quick_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 21)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_old", new Pair[0])), Fleet.T("talk.mode_old_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 22))}));
                                return;
                            }
                    }
                }
            });
            float f = 40;
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(UiKt.dp(mainActivity, f), UiKt.dp(mainActivity, f));
            float f2 = 10;
            layoutParams.leftMargin = UiKt.dp(mainActivity, f2);
            linearLayout2.addView(icon, layoutParams);
            LinearLayout col = UiKt.col(mainActivity);
            float f3 = 4;
            float f4 = 8;
            col.setPadding(UiKt.dp(mainActivity, f2), UiKt.dp(mainActivity, f3), UiKt.dp(mainActivity, f4), UiKt.dp(mainActivity, f3));
            col.addView(((StatusText) mainActivity.getStatus$android_release()).getName());
            col.addView(mainActivity.getStatus$android_release());
            linearLayout2.addView(col, new LinearLayout.LayoutParams(0, -2, 1.0f));
            linearLayout.addView(linearLayout2, new LinearLayout.LayoutParams(0, -2, 1.0f));
            LinearLayout linearLayout3 = new LinearLayout(mainActivity);
            linearLayout3.setGravity(8388629);
            mainActivity.listenBtn = UiKt.icon(mainActivity, "@headphones", Fleet.T("remote_screen.hear_the_tv_on", new Pair[0]), UiKt.BTN);
            final int i7 = 7;
            mainActivity.getListenBtn$android_release().setOnClickListener(new View.OnClickListener() { // from class: dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    int i72 = 5;
                    int i8 = 3;
                    int i9 = 29;
                    int i10 = 4;
                    int i11 = 6;
                    int i12 = 1;
                    int i13 = 0;
                    switch (i7) {
                        case 0:
                            mainActivity.toggleVideo$android_release();
                            return;
                        case 1:
                            Regex regex = AdbHelpKt.TV_HOME;
                            MainActivity mainActivity2 = mainActivity;
                            UiKt.menu(mainActivity2, Fleet.T("setup.turn_on_adb", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@zap|", Fleet.T("adb_help.automatic_install_tv_setup", new Pair[0])), Fleet.T("adb_help.just_confirm_on_the", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity2, 24)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@gear|", Fleet.T("adb_help.by_hand_open_tv", new Pair[0])), "", new TalkKt$$ExternalSyntheticLambda1(mainActivity2, 25)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@home|", Fleet.T("adb_help.install_another_home_screen", new Pair[0])), Fleet.T("adb_help.when_the_tv_hides", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity2, i9)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@wifi|", Fleet.T("setup.wireless_title", new Pair[0])), Fleet.T("adb_help.android_11_or_newer", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i13)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@refresh|", Fleet.T("adb_help.full_connection", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i8)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@store|", Fleet.T("adb_help.open_the_play_store", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i10)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@package|", Fleet.T("adb_help.open_an_app_by", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i72)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@link|", Fleet.T("setup.direct_title", new Pair[0])), Fleet.T("adb_help.a_fallback_not_reliable", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i11))}));
                            return;
                        case 2:
                            TypingKt.setLive(mainActivity, !r1.live);
                            return;
                        case 3:
                            MainActivity mainActivity3 = mainActivity;
                            Intrinsics.checkNotNullParameter(mainActivity3, "<this>");
                            mainActivity3.getPrefs$android_release().edit().putBoolean("listenEven", !mainActivity3.getPrefs$android_release().getBoolean("listenEven", false)).apply();
                            Fleet.soundChanged(mainActivity3);
                            return;
                        case 4:
                            TypingKt.sendText(mainActivity);
                            return;
                        case 5:
                            mainActivity.onBackPressed();
                            return;
                        case 6:
                            mainActivity.leave$android_release();
                            return;
                        case 7:
                            Fleet.toggleListen(mainActivity);
                            return;
                        case 8:
                            MainActivity mainActivity4 = mainActivity;
                            TextView label = UiKt.label(mainActivity4, TypingKt.gainWords(TypingKt.listenGain(mainActivity4)), 17, -1);
                            label.setTypeface(Typeface.DEFAULT_BOLD);
                            label.setGravity(8388629);
                            SeekBar seekBar = new SeekBar(mainActivity4);
                            seekBar.setMax(19);
                            seekBar.setContentDescription(Fleet.T("listen.loudness", new Pair[0]));
                            Axml$$ExternalSyntheticLambda2 axml$$ExternalSyntheticLambda2 = new Axml$$ExternalSyntheticLambda2(11, mainActivity4, label);
                            seekBar.setProgress((int) ((TypingKt.listenGain(mainActivity4) - 0.5f) * 2));
                            seekBar.setOnSeekBarChangeListener(new PlayingBar.AnonymousClass5(i12, axml$$ExternalSyntheticLambda2));
                            LinearLayout linearLayout32 = new LinearLayout(mainActivity4);
                            linearLayout32.setGravity(16);
                            linearLayout32.addView(seekBar, new LinearLayout.LayoutParams(0, UiKt.dp(mainActivity4, 48), 1.0f));
                            linearLayout32.addView(label, new LinearLayout.LayoutParams(UiKt.dp(mainActivity4, 56), -2));
                            LinearLayout linearLayout22 = new LinearLayout(mainActivity4);
                            linearLayout22.setOrientation(1);
                            linearLayout22.addView(linearLayout32);
                            TextView label2 = UiKt.label(mainActivity4, Fleet.T("listen.boost_note", new Pair[0]), 14, UiKt.DIM);
                            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
                            layoutParams2.topMargin = UiKt.dp(mainActivity4, 8);
                            linearLayout22.addView(label2, layoutParams2);
                            Popup.Builder builder = new Popup.Builder(mainActivity4);
                            builder.title = Fleet.T("remote_screen.loudness_on_the_phone_2", new Pair[0]);
                            builder.view = UiKt.inDialog(mainActivity4, linearLayout22);
                            builder.setNeutralButton(Fleet.T("listen.back_to_x1", new Pair[0]), null);
                            builder.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                            builder.show().getButton(-3).setOnClickListener(new Guard$$ExternalSyntheticLambda9(7, seekBar, axml$$ExternalSyntheticLambda2));
                            return;
                        case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                            MainActivity mainActivity5 = mainActivity;
                            Object systemService = mainActivity5.getSystemService("input_method");
                            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
                            ((InputMethodManager) systemService).hideSoftInputFromWindow(view.getWindowToken(), 0);
                            if (!mainActivity5.needsAdb$android_release()) {
                                Managing.open$default(mainActivity5.getManaging$android_release(), mainActivity5.host, null, null, 6);
                                return;
                            }
                            return;
                        case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                            mainActivity.setFullscreen$android_release(false);
                            return;
                        case 11:
                            MainActivity mainActivity6 = mainActivity;
                            LinearLayout col2 = UiKt.col(mainActivity6);
                            LinearLayout linearLayout322 = new LinearLayout(mainActivity6);
                            LinearLayout linearLayout4 = new LinearLayout(mainActivity6);
                            LinearLayout linearLayout5 = new LinearLayout(mainActivity6);
                            LinearLayout linearLayout6 = new LinearLayout(mainActivity6);
                            TypingKt.qualityMenu$draw(mainActivity6, linearLayout322, linearLayout4, linearLayout5, linearLayout6);
                            col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.size", new Pair[0])));
                            col2.addView(linearLayout322, UiKt.gap(mainActivity6, 6));
                            col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.frames_per_second", new Pair[0])), UiKt.gap(mainActivity6, 14));
                            col2.addView(linearLayout4, UiKt.gap(mainActivity6, 6));
                            col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.bit_rate_mbit_s", new Pair[0])), UiKt.gap(mainActivity6, 14));
                            col2.addView(linearLayout5, UiKt.gap(mainActivity6, 6));
                            col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.encoder", new Pair[0])), UiKt.gap(mainActivity6, 14));
                            col2.addView(linearLayout6, UiKt.gap(mainActivity6, 6));
                            Popup.Builder builder2 = new Popup.Builder(mainActivity6);
                            builder2.title = Fleet.T("remote_screen.picture_quality", new Pair[0]);
                            builder2.view = UiKt.inDialog(mainActivity6, col2);
                            builder2.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                            builder2.show();
                            return;
                        case FileClientSessionCache.MAX_SIZE /* 12 */:
                            final MainActivity mainActivity7 = mainActivity;
                            final boolean z = mainActivity7.getPrefs$android_release().getBoolean("listenShare", false);
                            PopupMenu popupMenu = new PopupMenu(mainActivity7, mainActivity7.getListenChip$android_release());
                            MenuItem add = popupMenu.getMenu().add(1, 0, 0, Fleet.T("listen.only_the_phone", new Pair[0]));
                            add.setIcon(TypingKt.listenArt(mainActivity7, false));
                            add.setChecked(!z);
                            MenuItem add2 = popupMenu.getMenu().add(1, 1, 1, Fleet.T("listen.tv_and_phone", new Pair[0]));
                            add2.setIcon(TypingKt.listenArt(mainActivity7, true));
                            add2.setChecked(z);
                            popupMenu.getMenu().setGroupCheckable(1, true, true);
                            if (Build.VERSION.SDK_INT >= 29) {
                                popupMenu.setForceShowIcon(true);
                            }
                            popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: dev.tvremote.phone.media.ListenKt$$ExternalSyntheticLambda2
                                @Override // android.widget.PopupMenu.OnMenuItemClickListener
                                public final boolean onMenuItemClick(MenuItem menuItem) {
                                    boolean z2;
                                    boolean z3 = false;
                                    if (menuItem.getItemId() == 1) {
                                        z2 = true;
                                    } else {
                                        z2 = false;
                                    }
                                    if (z2 != z) {
                                        MainActivity mainActivity8 = mainActivity7;
                                        SharedPreferences.Editor edit = mainActivity8.getPrefs$android_release().edit();
                                        if (menuItem.getItemId() == 1) {
                                            z3 = true;
                                        }
                                        edit.putBoolean("listenShare", z3).apply();
                                        Fleet.soundChanged(mainActivity8);
                                    }
                                    return true;
                                }
                            });
                            popupMenu.show();
                            return;
                        case 13:
                            MainActivity mainActivity8 = mainActivity;
                            Intrinsics.checkNotNullParameter(mainActivity8, "<this>");
                            mainActivity8.getPrefs$android_release().edit().putBoolean("listenHq", !mainActivity8.getPrefs$android_release().getBoolean("listenHq", false)).apply();
                            Fleet.soundChanged(mainActivity8);
                            return;
                        case 14:
                            mainActivity.setFullscreen$android_release(true);
                            return;
                        case 15:
                            ArrayList arrayList = PipKt.hidden;
                            MainActivity mainActivity9 = mainActivity;
                            if (mainActivity9.floating) {
                                PipKt.unfloat(mainActivity9);
                                return;
                            } else {
                                if (PipKt.picLive(mainActivity9)) {
                                    mainActivity9.floating = true;
                                    PipKt.setFloat(1, mainActivity9);
                                    TypingKt.layoutRemote(mainActivity9);
                                    return;
                                }
                                return;
                            }
                        case 16:
                            MainActivity mainActivity10 = mainActivity;
                            if (mainActivity10.basic != null) {
                                mainActivity10.press$android_release(true, 26);
                                return;
                            }
                            Tv tv = mainActivity10.tv;
                            if (tv != null && tv.ready()) {
                                new Thread(new MainActivity$$ExternalSyntheticLambda38(tv, mainActivity10, i10)).start();
                                return;
                            }
                            return;
                        default:
                            MainActivity mainActivity11 = mainActivity;
                            String pref$android_release = mainActivity11.pref$android_release("talkMode");
                            if (pref$android_release.equals("quick")) {
                                mainActivity11.getTalk$android_release().open();
                                return;
                            } else if (pref$android_release.equals("old")) {
                                mainActivity11.speak$android_release();
                                return;
                            } else {
                                UiKt.menu(mainActivity11, Fleet.T("talk.choose_title", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_quick", new Pair[0])), Fleet.T("talk.mode_quick_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 21)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_old", new Pair[0])), Fleet.T("talk.mode_old_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 22))}));
                                return;
                            }
                    }
                }
            });
            IconButton icon2 = UiKt.icon(mainActivity, "@apps", Fleet.T("remote_screen.manage", new Pair[0]), UiKt.BTN);
            final int i8 = 9;
            icon2.setOnClickListener(new View.OnClickListener() { // from class: dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    int i72 = 5;
                    int i82 = 3;
                    int i9 = 29;
                    int i10 = 4;
                    int i11 = 6;
                    int i12 = 1;
                    int i13 = 0;
                    switch (i8) {
                        case 0:
                            mainActivity.toggleVideo$android_release();
                            return;
                        case 1:
                            Regex regex = AdbHelpKt.TV_HOME;
                            MainActivity mainActivity2 = mainActivity;
                            UiKt.menu(mainActivity2, Fleet.T("setup.turn_on_adb", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@zap|", Fleet.T("adb_help.automatic_install_tv_setup", new Pair[0])), Fleet.T("adb_help.just_confirm_on_the", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity2, 24)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@gear|", Fleet.T("adb_help.by_hand_open_tv", new Pair[0])), "", new TalkKt$$ExternalSyntheticLambda1(mainActivity2, 25)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@home|", Fleet.T("adb_help.install_another_home_screen", new Pair[0])), Fleet.T("adb_help.when_the_tv_hides", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity2, i9)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@wifi|", Fleet.T("setup.wireless_title", new Pair[0])), Fleet.T("adb_help.android_11_or_newer", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i13)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@refresh|", Fleet.T("adb_help.full_connection", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i82)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@store|", Fleet.T("adb_help.open_the_play_store", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i10)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@package|", Fleet.T("adb_help.open_an_app_by", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i72)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@link|", Fleet.T("setup.direct_title", new Pair[0])), Fleet.T("adb_help.a_fallback_not_reliable", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i11))}));
                            return;
                        case 2:
                            TypingKt.setLive(mainActivity, !r1.live);
                            return;
                        case 3:
                            MainActivity mainActivity3 = mainActivity;
                            Intrinsics.checkNotNullParameter(mainActivity3, "<this>");
                            mainActivity3.getPrefs$android_release().edit().putBoolean("listenEven", !mainActivity3.getPrefs$android_release().getBoolean("listenEven", false)).apply();
                            Fleet.soundChanged(mainActivity3);
                            return;
                        case 4:
                            TypingKt.sendText(mainActivity);
                            return;
                        case 5:
                            mainActivity.onBackPressed();
                            return;
                        case 6:
                            mainActivity.leave$android_release();
                            return;
                        case 7:
                            Fleet.toggleListen(mainActivity);
                            return;
                        case 8:
                            MainActivity mainActivity4 = mainActivity;
                            TextView label = UiKt.label(mainActivity4, TypingKt.gainWords(TypingKt.listenGain(mainActivity4)), 17, -1);
                            label.setTypeface(Typeface.DEFAULT_BOLD);
                            label.setGravity(8388629);
                            SeekBar seekBar = new SeekBar(mainActivity4);
                            seekBar.setMax(19);
                            seekBar.setContentDescription(Fleet.T("listen.loudness", new Pair[0]));
                            Axml$$ExternalSyntheticLambda2 axml$$ExternalSyntheticLambda2 = new Axml$$ExternalSyntheticLambda2(11, mainActivity4, label);
                            seekBar.setProgress((int) ((TypingKt.listenGain(mainActivity4) - 0.5f) * 2));
                            seekBar.setOnSeekBarChangeListener(new PlayingBar.AnonymousClass5(i12, axml$$ExternalSyntheticLambda2));
                            LinearLayout linearLayout32 = new LinearLayout(mainActivity4);
                            linearLayout32.setGravity(16);
                            linearLayout32.addView(seekBar, new LinearLayout.LayoutParams(0, UiKt.dp(mainActivity4, 48), 1.0f));
                            linearLayout32.addView(label, new LinearLayout.LayoutParams(UiKt.dp(mainActivity4, 56), -2));
                            LinearLayout linearLayout22 = new LinearLayout(mainActivity4);
                            linearLayout22.setOrientation(1);
                            linearLayout22.addView(linearLayout32);
                            TextView label2 = UiKt.label(mainActivity4, Fleet.T("listen.boost_note", new Pair[0]), 14, UiKt.DIM);
                            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
                            layoutParams2.topMargin = UiKt.dp(mainActivity4, 8);
                            linearLayout22.addView(label2, layoutParams2);
                            Popup.Builder builder = new Popup.Builder(mainActivity4);
                            builder.title = Fleet.T("remote_screen.loudness_on_the_phone_2", new Pair[0]);
                            builder.view = UiKt.inDialog(mainActivity4, linearLayout22);
                            builder.setNeutralButton(Fleet.T("listen.back_to_x1", new Pair[0]), null);
                            builder.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                            builder.show().getButton(-3).setOnClickListener(new Guard$$ExternalSyntheticLambda9(7, seekBar, axml$$ExternalSyntheticLambda2));
                            return;
                        case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                            MainActivity mainActivity5 = mainActivity;
                            Object systemService = mainActivity5.getSystemService("input_method");
                            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
                            ((InputMethodManager) systemService).hideSoftInputFromWindow(view.getWindowToken(), 0);
                            if (!mainActivity5.needsAdb$android_release()) {
                                Managing.open$default(mainActivity5.getManaging$android_release(), mainActivity5.host, null, null, 6);
                                return;
                            }
                            return;
                        case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                            mainActivity.setFullscreen$android_release(false);
                            return;
                        case 11:
                            MainActivity mainActivity6 = mainActivity;
                            LinearLayout col2 = UiKt.col(mainActivity6);
                            LinearLayout linearLayout322 = new LinearLayout(mainActivity6);
                            LinearLayout linearLayout4 = new LinearLayout(mainActivity6);
                            LinearLayout linearLayout5 = new LinearLayout(mainActivity6);
                            LinearLayout linearLayout6 = new LinearLayout(mainActivity6);
                            TypingKt.qualityMenu$draw(mainActivity6, linearLayout322, linearLayout4, linearLayout5, linearLayout6);
                            col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.size", new Pair[0])));
                            col2.addView(linearLayout322, UiKt.gap(mainActivity6, 6));
                            col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.frames_per_second", new Pair[0])), UiKt.gap(mainActivity6, 14));
                            col2.addView(linearLayout4, UiKt.gap(mainActivity6, 6));
                            col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.bit_rate_mbit_s", new Pair[0])), UiKt.gap(mainActivity6, 14));
                            col2.addView(linearLayout5, UiKt.gap(mainActivity6, 6));
                            col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.encoder", new Pair[0])), UiKt.gap(mainActivity6, 14));
                            col2.addView(linearLayout6, UiKt.gap(mainActivity6, 6));
                            Popup.Builder builder2 = new Popup.Builder(mainActivity6);
                            builder2.title = Fleet.T("remote_screen.picture_quality", new Pair[0]);
                            builder2.view = UiKt.inDialog(mainActivity6, col2);
                            builder2.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                            builder2.show();
                            return;
                        case FileClientSessionCache.MAX_SIZE /* 12 */:
                            final MainActivity mainActivity7 = mainActivity;
                            final boolean z = mainActivity7.getPrefs$android_release().getBoolean("listenShare", false);
                            PopupMenu popupMenu = new PopupMenu(mainActivity7, mainActivity7.getListenChip$android_release());
                            MenuItem add = popupMenu.getMenu().add(1, 0, 0, Fleet.T("listen.only_the_phone", new Pair[0]));
                            add.setIcon(TypingKt.listenArt(mainActivity7, false));
                            add.setChecked(!z);
                            MenuItem add2 = popupMenu.getMenu().add(1, 1, 1, Fleet.T("listen.tv_and_phone", new Pair[0]));
                            add2.setIcon(TypingKt.listenArt(mainActivity7, true));
                            add2.setChecked(z);
                            popupMenu.getMenu().setGroupCheckable(1, true, true);
                            if (Build.VERSION.SDK_INT >= 29) {
                                popupMenu.setForceShowIcon(true);
                            }
                            popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: dev.tvremote.phone.media.ListenKt$$ExternalSyntheticLambda2
                                @Override // android.widget.PopupMenu.OnMenuItemClickListener
                                public final boolean onMenuItemClick(MenuItem menuItem) {
                                    boolean z2;
                                    boolean z3 = false;
                                    if (menuItem.getItemId() == 1) {
                                        z2 = true;
                                    } else {
                                        z2 = false;
                                    }
                                    if (z2 != z) {
                                        MainActivity mainActivity8 = mainActivity7;
                                        SharedPreferences.Editor edit = mainActivity8.getPrefs$android_release().edit();
                                        if (menuItem.getItemId() == 1) {
                                            z3 = true;
                                        }
                                        edit.putBoolean("listenShare", z3).apply();
                                        Fleet.soundChanged(mainActivity8);
                                    }
                                    return true;
                                }
                            });
                            popupMenu.show();
                            return;
                        case 13:
                            MainActivity mainActivity8 = mainActivity;
                            Intrinsics.checkNotNullParameter(mainActivity8, "<this>");
                            mainActivity8.getPrefs$android_release().edit().putBoolean("listenHq", !mainActivity8.getPrefs$android_release().getBoolean("listenHq", false)).apply();
                            Fleet.soundChanged(mainActivity8);
                            return;
                        case 14:
                            mainActivity.setFullscreen$android_release(true);
                            return;
                        case 15:
                            ArrayList arrayList = PipKt.hidden;
                            MainActivity mainActivity9 = mainActivity;
                            if (mainActivity9.floating) {
                                PipKt.unfloat(mainActivity9);
                                return;
                            } else {
                                if (PipKt.picLive(mainActivity9)) {
                                    mainActivity9.floating = true;
                                    PipKt.setFloat(1, mainActivity9);
                                    TypingKt.layoutRemote(mainActivity9);
                                    return;
                                }
                                return;
                            }
                        case 16:
                            MainActivity mainActivity10 = mainActivity;
                            if (mainActivity10.basic != null) {
                                mainActivity10.press$android_release(true, 26);
                                return;
                            }
                            Tv tv = mainActivity10.tv;
                            if (tv != null && tv.ready()) {
                                new Thread(new MainActivity$$ExternalSyntheticLambda38(tv, mainActivity10, i10)).start();
                                return;
                            }
                            return;
                        default:
                            MainActivity mainActivity11 = mainActivity;
                            String pref$android_release = mainActivity11.pref$android_release("talkMode");
                            if (pref$android_release.equals("quick")) {
                                mainActivity11.getTalk$android_release().open();
                                return;
                            } else if (pref$android_release.equals("old")) {
                                mainActivity11.speak$android_release();
                                return;
                            } else {
                                UiKt.menu(mainActivity11, Fleet.T("talk.choose_title", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_quick", new Pair[0])), Fleet.T("talk.mode_quick_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 21)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_old", new Pair[0])), Fleet.T("talk.mode_old_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 22))}));
                                return;
                            }
                    }
                }
            });
            for (IconButton iconButton : ArraysKt.asList(new IconButton[]{mainActivity.getListenBtn$android_release(), mainActivity.getVideoBtn$android_release(), icon2})) {
                LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(UiKt.dp(mainActivity, 46), UiKt.dp(mainActivity, f));
                if (iconButton == icon2) {
                    i3 = 10;
                } else {
                    i3 = 6;
                }
                layoutParams2.rightMargin = UiKt.dp(mainActivity, i3);
                linearLayout3.addView(iconButton, layoutParams2);
            }
            linearLayout.addView(linearLayout3, new LinearLayout.LayoutParams(-2, -2));
            linearLayout.setPadding(0, UiKt.dp(mainActivity, f4), 0, UiKt.dp(mainActivity, f2));
            mainActivity.getRemote$android_release().addView(linearLayout);
            ?? frameLayout = new FrameLayout(mainActivity);
            frameLayout.vw = 16;
            frameLayout.vh = 9;
            mainActivity.frame = frameLayout;
            mainActivity.getFrame$android_release().setBackgroundColor(-16777216);
            mainActivity.surface = new SurfaceView(mainActivity);
            mainActivity.getSurface$android_release().getHolder().addCallback(mainActivity);
            mainActivity.getFrame$android_release().addView(mainActivity.getSurface$android_release(), new FrameLayout.LayoutParams(-1, -1, 17));
            mainActivity.getSurface$android_release().setOnTouchListener(new Talk$$ExternalSyntheticLambda8(2, mainActivity));
            mainActivity.tapMark = new TapMark(mainActivity);
            VideoFrame frame$android_release = mainActivity.getFrame$android_release();
            TapMark tapMark = mainActivity.tapMark;
            if (tapMark != null) {
                frame$android_release.addView(tapMark, new FrameLayout.LayoutParams(-1, -1));
                mainActivity.drawView = new DrawView(mainActivity);
                mainActivity.getFrame$android_release().addView(mainActivity.getDrawView$android_release(), new FrameLayout.LayoutParams(-1, -1));
                mainActivity.stage = new FrameLayout(mainActivity);
                mainActivity.getStage$android_release().setBackgroundColor(-16777216);
                mainActivity.getStage$android_release().addView(mainActivity.getFrame$android_release(), new FrameLayout.LayoutParams(-1, -2));
                IconButton icon3 = UiKt.icon(mainActivity, "@close", Fleet.T("remote_screen.leave_full_screen", new Pair[0]), 1711276032);
                mainActivity.exitBtn = icon3;
                icon3.setAlpha(0.5f);
                IconButton iconButton2 = mainActivity.exitBtn;
                if (iconButton2 != null) {
                    final int i9 = 10;
                    iconButton2.setOnClickListener(new View.OnClickListener() { // from class: dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda0
                        @Override // android.view.View.OnClickListener
                        public final void onClick(View view) {
                            int i72 = 5;
                            int i82 = 3;
                            int i92 = 29;
                            int i10 = 4;
                            int i11 = 6;
                            int i12 = 1;
                            int i13 = 0;
                            switch (i9) {
                                case 0:
                                    mainActivity.toggleVideo$android_release();
                                    return;
                                case 1:
                                    Regex regex = AdbHelpKt.TV_HOME;
                                    MainActivity mainActivity2 = mainActivity;
                                    UiKt.menu(mainActivity2, Fleet.T("setup.turn_on_adb", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@zap|", Fleet.T("adb_help.automatic_install_tv_setup", new Pair[0])), Fleet.T("adb_help.just_confirm_on_the", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity2, 24)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@gear|", Fleet.T("adb_help.by_hand_open_tv", new Pair[0])), "", new TalkKt$$ExternalSyntheticLambda1(mainActivity2, 25)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@home|", Fleet.T("adb_help.install_another_home_screen", new Pair[0])), Fleet.T("adb_help.when_the_tv_hides", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity2, i92)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@wifi|", Fleet.T("setup.wireless_title", new Pair[0])), Fleet.T("adb_help.android_11_or_newer", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i13)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@refresh|", Fleet.T("adb_help.full_connection", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i82)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@store|", Fleet.T("adb_help.open_the_play_store", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i10)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@package|", Fleet.T("adb_help.open_an_app_by", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i72)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@link|", Fleet.T("setup.direct_title", new Pair[0])), Fleet.T("adb_help.a_fallback_not_reliable", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i11))}));
                                    return;
                                case 2:
                                    TypingKt.setLive(mainActivity, !r1.live);
                                    return;
                                case 3:
                                    MainActivity mainActivity3 = mainActivity;
                                    Intrinsics.checkNotNullParameter(mainActivity3, "<this>");
                                    mainActivity3.getPrefs$android_release().edit().putBoolean("listenEven", !mainActivity3.getPrefs$android_release().getBoolean("listenEven", false)).apply();
                                    Fleet.soundChanged(mainActivity3);
                                    return;
                                case 4:
                                    TypingKt.sendText(mainActivity);
                                    return;
                                case 5:
                                    mainActivity.onBackPressed();
                                    return;
                                case 6:
                                    mainActivity.leave$android_release();
                                    return;
                                case 7:
                                    Fleet.toggleListen(mainActivity);
                                    return;
                                case 8:
                                    MainActivity mainActivity4 = mainActivity;
                                    TextView label = UiKt.label(mainActivity4, TypingKt.gainWords(TypingKt.listenGain(mainActivity4)), 17, -1);
                                    label.setTypeface(Typeface.DEFAULT_BOLD);
                                    label.setGravity(8388629);
                                    SeekBar seekBar = new SeekBar(mainActivity4);
                                    seekBar.setMax(19);
                                    seekBar.setContentDescription(Fleet.T("listen.loudness", new Pair[0]));
                                    Axml$$ExternalSyntheticLambda2 axml$$ExternalSyntheticLambda2 = new Axml$$ExternalSyntheticLambda2(11, mainActivity4, label);
                                    seekBar.setProgress((int) ((TypingKt.listenGain(mainActivity4) - 0.5f) * 2));
                                    seekBar.setOnSeekBarChangeListener(new PlayingBar.AnonymousClass5(i12, axml$$ExternalSyntheticLambda2));
                                    LinearLayout linearLayout32 = new LinearLayout(mainActivity4);
                                    linearLayout32.setGravity(16);
                                    linearLayout32.addView(seekBar, new LinearLayout.LayoutParams(0, UiKt.dp(mainActivity4, 48), 1.0f));
                                    linearLayout32.addView(label, new LinearLayout.LayoutParams(UiKt.dp(mainActivity4, 56), -2));
                                    LinearLayout linearLayout22 = new LinearLayout(mainActivity4);
                                    linearLayout22.setOrientation(1);
                                    linearLayout22.addView(linearLayout32);
                                    TextView label2 = UiKt.label(mainActivity4, Fleet.T("listen.boost_note", new Pair[0]), 14, UiKt.DIM);
                                    LinearLayout.LayoutParams layoutParams22 = new LinearLayout.LayoutParams(-1, -2);
                                    layoutParams22.topMargin = UiKt.dp(mainActivity4, 8);
                                    linearLayout22.addView(label2, layoutParams22);
                                    Popup.Builder builder = new Popup.Builder(mainActivity4);
                                    builder.title = Fleet.T("remote_screen.loudness_on_the_phone_2", new Pair[0]);
                                    builder.view = UiKt.inDialog(mainActivity4, linearLayout22);
                                    builder.setNeutralButton(Fleet.T("listen.back_to_x1", new Pair[0]), null);
                                    builder.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                                    builder.show().getButton(-3).setOnClickListener(new Guard$$ExternalSyntheticLambda9(7, seekBar, axml$$ExternalSyntheticLambda2));
                                    return;
                                case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                                    MainActivity mainActivity5 = mainActivity;
                                    Object systemService = mainActivity5.getSystemService("input_method");
                                    Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
                                    ((InputMethodManager) systemService).hideSoftInputFromWindow(view.getWindowToken(), 0);
                                    if (!mainActivity5.needsAdb$android_release()) {
                                        Managing.open$default(mainActivity5.getManaging$android_release(), mainActivity5.host, null, null, 6);
                                        return;
                                    }
                                    return;
                                case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                                    mainActivity.setFullscreen$android_release(false);
                                    return;
                                case 11:
                                    MainActivity mainActivity6 = mainActivity;
                                    LinearLayout col2 = UiKt.col(mainActivity6);
                                    LinearLayout linearLayout322 = new LinearLayout(mainActivity6);
                                    LinearLayout linearLayout4 = new LinearLayout(mainActivity6);
                                    LinearLayout linearLayout5 = new LinearLayout(mainActivity6);
                                    LinearLayout linearLayout6 = new LinearLayout(mainActivity6);
                                    TypingKt.qualityMenu$draw(mainActivity6, linearLayout322, linearLayout4, linearLayout5, linearLayout6);
                                    col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.size", new Pair[0])));
                                    col2.addView(linearLayout322, UiKt.gap(mainActivity6, 6));
                                    col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.frames_per_second", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                    col2.addView(linearLayout4, UiKt.gap(mainActivity6, 6));
                                    col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.bit_rate_mbit_s", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                    col2.addView(linearLayout5, UiKt.gap(mainActivity6, 6));
                                    col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.encoder", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                    col2.addView(linearLayout6, UiKt.gap(mainActivity6, 6));
                                    Popup.Builder builder2 = new Popup.Builder(mainActivity6);
                                    builder2.title = Fleet.T("remote_screen.picture_quality", new Pair[0]);
                                    builder2.view = UiKt.inDialog(mainActivity6, col2);
                                    builder2.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                                    builder2.show();
                                    return;
                                case FileClientSessionCache.MAX_SIZE /* 12 */:
                                    final MainActivity mainActivity7 = mainActivity;
                                    final boolean z = mainActivity7.getPrefs$android_release().getBoolean("listenShare", false);
                                    PopupMenu popupMenu = new PopupMenu(mainActivity7, mainActivity7.getListenChip$android_release());
                                    MenuItem add = popupMenu.getMenu().add(1, 0, 0, Fleet.T("listen.only_the_phone", new Pair[0]));
                                    add.setIcon(TypingKt.listenArt(mainActivity7, false));
                                    add.setChecked(!z);
                                    MenuItem add2 = popupMenu.getMenu().add(1, 1, 1, Fleet.T("listen.tv_and_phone", new Pair[0]));
                                    add2.setIcon(TypingKt.listenArt(mainActivity7, true));
                                    add2.setChecked(z);
                                    popupMenu.getMenu().setGroupCheckable(1, true, true);
                                    if (Build.VERSION.SDK_INT >= 29) {
                                        popupMenu.setForceShowIcon(true);
                                    }
                                    popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: dev.tvremote.phone.media.ListenKt$$ExternalSyntheticLambda2
                                        @Override // android.widget.PopupMenu.OnMenuItemClickListener
                                        public final boolean onMenuItemClick(MenuItem menuItem) {
                                            boolean z2;
                                            boolean z3 = false;
                                            if (menuItem.getItemId() == 1) {
                                                z2 = true;
                                            } else {
                                                z2 = false;
                                            }
                                            if (z2 != z) {
                                                MainActivity mainActivity8 = mainActivity7;
                                                SharedPreferences.Editor edit = mainActivity8.getPrefs$android_release().edit();
                                                if (menuItem.getItemId() == 1) {
                                                    z3 = true;
                                                }
                                                edit.putBoolean("listenShare", z3).apply();
                                                Fleet.soundChanged(mainActivity8);
                                            }
                                            return true;
                                        }
                                    });
                                    popupMenu.show();
                                    return;
                                case 13:
                                    MainActivity mainActivity8 = mainActivity;
                                    Intrinsics.checkNotNullParameter(mainActivity8, "<this>");
                                    mainActivity8.getPrefs$android_release().edit().putBoolean("listenHq", !mainActivity8.getPrefs$android_release().getBoolean("listenHq", false)).apply();
                                    Fleet.soundChanged(mainActivity8);
                                    return;
                                case 14:
                                    mainActivity.setFullscreen$android_release(true);
                                    return;
                                case 15:
                                    ArrayList arrayList = PipKt.hidden;
                                    MainActivity mainActivity9 = mainActivity;
                                    if (mainActivity9.floating) {
                                        PipKt.unfloat(mainActivity9);
                                        return;
                                    } else {
                                        if (PipKt.picLive(mainActivity9)) {
                                            mainActivity9.floating = true;
                                            PipKt.setFloat(1, mainActivity9);
                                            TypingKt.layoutRemote(mainActivity9);
                                            return;
                                        }
                                        return;
                                    }
                                case 16:
                                    MainActivity mainActivity10 = mainActivity;
                                    if (mainActivity10.basic != null) {
                                        mainActivity10.press$android_release(true, 26);
                                        return;
                                    }
                                    Tv tv = mainActivity10.tv;
                                    if (tv != null && tv.ready()) {
                                        new Thread(new MainActivity$$ExternalSyntheticLambda38(tv, mainActivity10, i10)).start();
                                        return;
                                    }
                                    return;
                                default:
                                    MainActivity mainActivity11 = mainActivity;
                                    String pref$android_release = mainActivity11.pref$android_release("talkMode");
                                    if (pref$android_release.equals("quick")) {
                                        mainActivity11.getTalk$android_release().open();
                                        return;
                                    } else if (pref$android_release.equals("old")) {
                                        mainActivity11.speak$android_release();
                                        return;
                                    } else {
                                        UiKt.menu(mainActivity11, Fleet.T("talk.choose_title", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_quick", new Pair[0])), Fleet.T("talk.mode_quick_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 21)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_old", new Pair[0])), Fleet.T("talk.mode_old_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 22))}));
                                        return;
                                    }
                            }
                        }
                    });
                    float f5 = 42;
                    FrameLayout.LayoutParams layoutParams3 = new FrameLayout.LayoutParams(UiKt.dp(mainActivity, f5), UiKt.dp(mainActivity, f5), 8388661);
                    layoutParams3.setMargins(UiKt.dp(mainActivity, f4), UiKt.dp(mainActivity, f4), UiKt.dp(mainActivity, f4), UiKt.dp(mainActivity, f4));
                    FrameLayout stage$android_release = mainActivity.getStage$android_release();
                    IconButton iconButton3 = mainActivity.exitBtn;
                    if (iconButton3 != null) {
                        stage$android_release.addView(iconButton3, layoutParams3);
                        mainActivity.getRemote$android_release().addView(mainActivity.getStage$android_release(), new LinearLayout.LayoutParams(-1, -2));
                        LinearLayout linearLayout4 = new LinearLayout(mainActivity);
                        linearLayout4.setOrientation(1);
                        linearLayout4.setVisibility(8);
                        LinearLayout linearLayout5 = new LinearLayout(mainActivity);
                        linearLayout5.setTag("pen");
                        linearLayout5.setGravity(16);
                        linearLayout5.setPadding(UiKt.dp(mainActivity, f4), UiKt.dp(mainActivity, f4), UiKt.dp(mainActivity, f4), UiKt.dp(mainActivity, f4));
                        View view = new View(mainActivity);
                        DrawingKt$$ExternalSyntheticLambda3 drawingKt$$ExternalSyntheticLambda3 = new DrawingKt$$ExternalSyntheticLambda3(view, mainActivity);
                        drawingKt$$ExternalSyntheticLambda3.invoke();
                        view.setContentDescription(Fleet.T("remote.colour", new Pair[0]));
                        view.setOnClickListener(new Guard$$ExternalSyntheticLambda9(5, mainActivity, drawingKt$$ExternalSyntheticLambda3));
                        linearLayout5.addView(new View(mainActivity), new LinearLayout.LayoutParams(0, 1, 1.0f));
                        float f6 = 30;
                        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(UiKt.dp(mainActivity, f6), UiKt.dp(mainActivity, f6));
                        float f7 = 6;
                        layoutParams4.rightMargin = UiKt.dp(mainActivity, f7);
                        linearLayout5.addView(view, layoutParams4);
                        IconButton icon4 = UiKt.icon(mainActivity, "@image", Fleet.T("drawing.put_a_picture_on", new Pair[0]), UiKt.BTN);
                        icon4.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(mainActivity, 25));
                        IconButton icon5 = UiKt.icon(mainActivity, "@type", Fleet.T("drawing.type_a_message_on", new Pair[0]), UiKt.BTN);
                        icon5.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(mainActivity, 26));
                        IconButton icon6 = UiKt.icon(mainActivity, "@undo", Fleet.T("remote.take_back_the_last", new Pair[0]), UiKt.BTN);
                        icon6.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(mainActivity, 27));
                        IconButton icon7 = UiKt.icon(mainActivity, "@trash", Fleet.T("drawing.clear_all", new Pair[0]), UiKt.BTN);
                        icon7.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(mainActivity, 28));
                        IconButton icon8 = UiKt.icon(mainActivity, "@check", Fleet.T("drawing.done", new Pair[0]), UiKt.ACCENT);
                        icon8.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(mainActivity, 22));
                        for (IconButton iconButton4 : ArraysKt.asList(new IconButton[]{icon4, icon5, icon6, icon7, icon8})) {
                            LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(UiKt.dp(mainActivity, f), UiKt.dp(mainActivity, f));
                            layoutParams5.leftMargin = UiKt.dp(mainActivity, f3);
                            linearLayout5.addView(iconButton4, layoutParams5);
                        }
                        linearLayout4.addView(linearLayout5, new LinearLayout.LayoutParams(-1, -2));
                        LinearLayout linearLayout6 = new LinearLayout(mainActivity);
                        linearLayout6.setTag("pic");
                        linearLayout6.setGravity(16);
                        float f8 = 12;
                        linearLayout6.setPadding(UiKt.dp(mainActivity, f8), UiKt.dp(mainActivity, f4), UiKt.dp(mainActivity, f4), UiKt.dp(mainActivity, f4));
                        linearLayout6.setVisibility(8);
                        TextView textView = new TextView(mainActivity);
                        textView.setTextColor(UiKt.TEXT);
                        textView.setTextSize(14.0f);
                        textView.setGravity(17);
                        mainActivity.getDrawView$android_release().setOnSize(new Regex$$ExternalSyntheticLambda0(16, textView, mainActivity));
                        Iterator it2 = ArraysKt.asList(new Pair[]{new Pair("−", Float.valueOf(0.9433963f)), new Pair("+", Float.valueOf(1.06f))}).iterator();
                        while (it2.hasNext()) {
                            Pair pair = (Pair) it2.next();
                            String str = (String) pair.first;
                            float floatValue = ((Number) pair.second).floatValue();
                            Button button3 = UiKt.button(mainActivity, str, UiKt.BTN);
                            button3.setTextSize(20.0f);
                            int i10 = (floatValue > 1.0f ? 1 : (floatValue == 1.0f ? 0 : -1));
                            if (i10 > 0) {
                                it = it2;
                                i2 = i10;
                                T = Fleet.T("remote.bigger", new Pair[0]);
                            } else {
                                it = it2;
                                i2 = i10;
                                T = Fleet.T("remote.smaller", new Pair[0]);
                            }
                            button3.setContentDescription(T);
                            final ?? obj = new Object();
                            final DrawingKt$drawTools$step$1 drawingKt$drawTools$step$1 = new DrawingKt$drawTools$step$1(mainActivity, floatValue, obj);
                            button3.setOnTouchListener(new View.OnTouchListener() { // from class: dev.tvremote.phone.picture.DrawingKt$$ExternalSyntheticLambda12
                                @Override // android.view.View.OnTouchListener
                                public final boolean onTouch(View view2, MotionEvent motionEvent) {
                                    int actionMasked = motionEvent.getActionMasked();
                                    MainActivity mainActivity2 = mainActivity;
                                    DrawingKt$drawTools$step$1 drawingKt$drawTools$step$12 = drawingKt$drawTools$step$1;
                                    if (actionMasked != 0) {
                                        if (actionMasked == 1 || actionMasked == 3) {
                                            mainActivity2.ui.removeCallbacks(drawingKt$drawTools$step$12);
                                        }
                                    } else {
                                        Ref$IntRef.this.element = 0;
                                        mainActivity2.ui.removeCallbacks(drawingKt$drawTools$step$12);
                                        drawingKt$drawTools$step$12.run();
                                    }
                                    return true;
                                }
                            });
                            if (i2 > 0) {
                                linearLayout6.addView(textView, new LinearLayout.LayoutParams(UiKt.dp(mainActivity, 48), UiKt.dp(mainActivity, f)));
                            }
                            button3.setPadding(0, 0, 0, 0);
                            linearLayout6.addView(button3, new LinearLayout.LayoutParams(UiKt.dp(mainActivity, 44), UiKt.dp(mainActivity, f)));
                            it2 = it;
                        }
                        linearLayout6.addView(new View(mainActivity), new LinearLayout.LayoutParams(0, 1, 1.0f));
                        Button button4 = UiKt.button(mainActivity, Fleet.T("common.cancel", new Pair[0]), UiKt.BTN);
                        button4.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(mainActivity, 23));
                        Button button5 = UiKt.button(mainActivity, ApkSigner$$ExternalSyntheticOutline0.m("@check|", Fleet.T("drawing.put_on_tv", new Pair[0])), UiKt.ACCENT);
                        button5.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(mainActivity, 24));
                        for (Button button6 : ArraysKt.asList(new Button[]{button4, button5})) {
                            button6.setPadding(UiKt.dp(mainActivity, f8), 0, UiKt.dp(mainActivity, f8), 0);
                            LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(-2, UiKt.dp(mainActivity, f));
                            layoutParams6.leftMargin = UiKt.dp(mainActivity, f7);
                            linearLayout6.addView(button6, layoutParams6);
                        }
                        linearLayout4.addView(linearLayout6, new LinearLayout.LayoutParams(-1, -2));
                        mainActivity.drawBar = linearLayout4;
                        mainActivity.getRemote$android_release().addView(mainActivity.getDrawBar$android_release(), new LinearLayout.LayoutParams(-1, -2));
                        mainActivity.controls = UiKt.col(mainActivity);
                        float f9 = 14;
                        mainActivity.getControls$android_release().setPadding(UiKt.dp(mainActivity, f9), UiKt.dp(mainActivity, f8), UiKt.dp(mainActivity, f9), UiKt.dp(mainActivity, 20));
                        mainActivity.picBar = new LinearLayout(mainActivity);
                        mainActivity.getPicBar$android_release().setGravity(16);
                        mainActivity.soundBar = new LinearLayout(mainActivity);
                        mainActivity.getSoundBar$android_release().setGravity(16);
                        TextView textView2 = new TextView(mainActivity);
                        textView2.setTextColor(UiKt.TEXT);
                        textView2.setTextSize(13.0f);
                        textView2.setGravity(17);
                        textView2.setPadding(UiKt.dp(mainActivity, f8), 0, UiKt.dp(mainActivity, f8), 0);
                        textView2.setBackground(UiKt.box(mainActivity, UiKt.BTN, 10));
                        textView2.setContentDescription(Fleet.T("remote_screen.picture_quality", new Pair[0]));
                        final int i11 = 11;
                        textView2.setOnClickListener(new View.OnClickListener() { // from class: dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda0
                            @Override // android.view.View.OnClickListener
                            public final void onClick(View view2) {
                                int i72 = 5;
                                int i82 = 3;
                                int i92 = 29;
                                int i102 = 4;
                                int i112 = 6;
                                int i12 = 1;
                                int i13 = 0;
                                switch (i11) {
                                    case 0:
                                        mainActivity.toggleVideo$android_release();
                                        return;
                                    case 1:
                                        Regex regex = AdbHelpKt.TV_HOME;
                                        MainActivity mainActivity2 = mainActivity;
                                        UiKt.menu(mainActivity2, Fleet.T("setup.turn_on_adb", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@zap|", Fleet.T("adb_help.automatic_install_tv_setup", new Pair[0])), Fleet.T("adb_help.just_confirm_on_the", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity2, 24)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@gear|", Fleet.T("adb_help.by_hand_open_tv", new Pair[0])), "", new TalkKt$$ExternalSyntheticLambda1(mainActivity2, 25)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@home|", Fleet.T("adb_help.install_another_home_screen", new Pair[0])), Fleet.T("adb_help.when_the_tv_hides", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity2, i92)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@wifi|", Fleet.T("setup.wireless_title", new Pair[0])), Fleet.T("adb_help.android_11_or_newer", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i13)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@refresh|", Fleet.T("adb_help.full_connection", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i82)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@store|", Fleet.T("adb_help.open_the_play_store", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i102)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@package|", Fleet.T("adb_help.open_an_app_by", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i72)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@link|", Fleet.T("setup.direct_title", new Pair[0])), Fleet.T("adb_help.a_fallback_not_reliable", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i112))}));
                                        return;
                                    case 2:
                                        TypingKt.setLive(mainActivity, !r1.live);
                                        return;
                                    case 3:
                                        MainActivity mainActivity3 = mainActivity;
                                        Intrinsics.checkNotNullParameter(mainActivity3, "<this>");
                                        mainActivity3.getPrefs$android_release().edit().putBoolean("listenEven", !mainActivity3.getPrefs$android_release().getBoolean("listenEven", false)).apply();
                                        Fleet.soundChanged(mainActivity3);
                                        return;
                                    case 4:
                                        TypingKt.sendText(mainActivity);
                                        return;
                                    case 5:
                                        mainActivity.onBackPressed();
                                        return;
                                    case 6:
                                        mainActivity.leave$android_release();
                                        return;
                                    case 7:
                                        Fleet.toggleListen(mainActivity);
                                        return;
                                    case 8:
                                        MainActivity mainActivity4 = mainActivity;
                                        TextView label = UiKt.label(mainActivity4, TypingKt.gainWords(TypingKt.listenGain(mainActivity4)), 17, -1);
                                        label.setTypeface(Typeface.DEFAULT_BOLD);
                                        label.setGravity(8388629);
                                        SeekBar seekBar = new SeekBar(mainActivity4);
                                        seekBar.setMax(19);
                                        seekBar.setContentDescription(Fleet.T("listen.loudness", new Pair[0]));
                                        Axml$$ExternalSyntheticLambda2 axml$$ExternalSyntheticLambda2 = new Axml$$ExternalSyntheticLambda2(11, mainActivity4, label);
                                        seekBar.setProgress((int) ((TypingKt.listenGain(mainActivity4) - 0.5f) * 2));
                                        seekBar.setOnSeekBarChangeListener(new PlayingBar.AnonymousClass5(i12, axml$$ExternalSyntheticLambda2));
                                        LinearLayout linearLayout32 = new LinearLayout(mainActivity4);
                                        linearLayout32.setGravity(16);
                                        linearLayout32.addView(seekBar, new LinearLayout.LayoutParams(0, UiKt.dp(mainActivity4, 48), 1.0f));
                                        linearLayout32.addView(label, new LinearLayout.LayoutParams(UiKt.dp(mainActivity4, 56), -2));
                                        LinearLayout linearLayout22 = new LinearLayout(mainActivity4);
                                        linearLayout22.setOrientation(1);
                                        linearLayout22.addView(linearLayout32);
                                        TextView label2 = UiKt.label(mainActivity4, Fleet.T("listen.boost_note", new Pair[0]), 14, UiKt.DIM);
                                        LinearLayout.LayoutParams layoutParams22 = new LinearLayout.LayoutParams(-1, -2);
                                        layoutParams22.topMargin = UiKt.dp(mainActivity4, 8);
                                        linearLayout22.addView(label2, layoutParams22);
                                        Popup.Builder builder = new Popup.Builder(mainActivity4);
                                        builder.title = Fleet.T("remote_screen.loudness_on_the_phone_2", new Pair[0]);
                                        builder.view = UiKt.inDialog(mainActivity4, linearLayout22);
                                        builder.setNeutralButton(Fleet.T("listen.back_to_x1", new Pair[0]), null);
                                        builder.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                                        builder.show().getButton(-3).setOnClickListener(new Guard$$ExternalSyntheticLambda9(7, seekBar, axml$$ExternalSyntheticLambda2));
                                        return;
                                    case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                                        MainActivity mainActivity5 = mainActivity;
                                        Object systemService = mainActivity5.getSystemService("input_method");
                                        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
                                        ((InputMethodManager) systemService).hideSoftInputFromWindow(view2.getWindowToken(), 0);
                                        if (!mainActivity5.needsAdb$android_release()) {
                                            Managing.open$default(mainActivity5.getManaging$android_release(), mainActivity5.host, null, null, 6);
                                            return;
                                        }
                                        return;
                                    case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                                        mainActivity.setFullscreen$android_release(false);
                                        return;
                                    case 11:
                                        MainActivity mainActivity6 = mainActivity;
                                        LinearLayout col2 = UiKt.col(mainActivity6);
                                        LinearLayout linearLayout322 = new LinearLayout(mainActivity6);
                                        LinearLayout linearLayout42 = new LinearLayout(mainActivity6);
                                        LinearLayout linearLayout52 = new LinearLayout(mainActivity6);
                                        LinearLayout linearLayout62 = new LinearLayout(mainActivity6);
                                        TypingKt.qualityMenu$draw(mainActivity6, linearLayout322, linearLayout42, linearLayout52, linearLayout62);
                                        col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.size", new Pair[0])));
                                        col2.addView(linearLayout322, UiKt.gap(mainActivity6, 6));
                                        col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.frames_per_second", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                        col2.addView(linearLayout42, UiKt.gap(mainActivity6, 6));
                                        col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.bit_rate_mbit_s", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                        col2.addView(linearLayout52, UiKt.gap(mainActivity6, 6));
                                        col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.encoder", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                        col2.addView(linearLayout62, UiKt.gap(mainActivity6, 6));
                                        Popup.Builder builder2 = new Popup.Builder(mainActivity6);
                                        builder2.title = Fleet.T("remote_screen.picture_quality", new Pair[0]);
                                        builder2.view = UiKt.inDialog(mainActivity6, col2);
                                        builder2.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                                        builder2.show();
                                        return;
                                    case FileClientSessionCache.MAX_SIZE /* 12 */:
                                        final MainActivity mainActivity7 = mainActivity;
                                        final boolean z = mainActivity7.getPrefs$android_release().getBoolean("listenShare", false);
                                        PopupMenu popupMenu = new PopupMenu(mainActivity7, mainActivity7.getListenChip$android_release());
                                        MenuItem add = popupMenu.getMenu().add(1, 0, 0, Fleet.T("listen.only_the_phone", new Pair[0]));
                                        add.setIcon(TypingKt.listenArt(mainActivity7, false));
                                        add.setChecked(!z);
                                        MenuItem add2 = popupMenu.getMenu().add(1, 1, 1, Fleet.T("listen.tv_and_phone", new Pair[0]));
                                        add2.setIcon(TypingKt.listenArt(mainActivity7, true));
                                        add2.setChecked(z);
                                        popupMenu.getMenu().setGroupCheckable(1, true, true);
                                        if (Build.VERSION.SDK_INT >= 29) {
                                            popupMenu.setForceShowIcon(true);
                                        }
                                        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: dev.tvremote.phone.media.ListenKt$$ExternalSyntheticLambda2
                                            @Override // android.widget.PopupMenu.OnMenuItemClickListener
                                            public final boolean onMenuItemClick(MenuItem menuItem) {
                                                boolean z2;
                                                boolean z3 = false;
                                                if (menuItem.getItemId() == 1) {
                                                    z2 = true;
                                                } else {
                                                    z2 = false;
                                                }
                                                if (z2 != z) {
                                                    MainActivity mainActivity8 = mainActivity7;
                                                    SharedPreferences.Editor edit = mainActivity8.getPrefs$android_release().edit();
                                                    if (menuItem.getItemId() == 1) {
                                                        z3 = true;
                                                    }
                                                    edit.putBoolean("listenShare", z3).apply();
                                                    Fleet.soundChanged(mainActivity8);
                                                }
                                                return true;
                                            }
                                        });
                                        popupMenu.show();
                                        return;
                                    case 13:
                                        MainActivity mainActivity8 = mainActivity;
                                        Intrinsics.checkNotNullParameter(mainActivity8, "<this>");
                                        mainActivity8.getPrefs$android_release().edit().putBoolean("listenHq", !mainActivity8.getPrefs$android_release().getBoolean("listenHq", false)).apply();
                                        Fleet.soundChanged(mainActivity8);
                                        return;
                                    case 14:
                                        mainActivity.setFullscreen$android_release(true);
                                        return;
                                    case 15:
                                        ArrayList arrayList = PipKt.hidden;
                                        MainActivity mainActivity9 = mainActivity;
                                        if (mainActivity9.floating) {
                                            PipKt.unfloat(mainActivity9);
                                            return;
                                        } else {
                                            if (PipKt.picLive(mainActivity9)) {
                                                mainActivity9.floating = true;
                                                PipKt.setFloat(1, mainActivity9);
                                                TypingKt.layoutRemote(mainActivity9);
                                                return;
                                            }
                                            return;
                                        }
                                    case 16:
                                        MainActivity mainActivity10 = mainActivity;
                                        if (mainActivity10.basic != null) {
                                            mainActivity10.press$android_release(true, 26);
                                            return;
                                        }
                                        Tv tv = mainActivity10.tv;
                                        if (tv != null && tv.ready()) {
                                            new Thread(new MainActivity$$ExternalSyntheticLambda38(tv, mainActivity10, i102)).start();
                                            return;
                                        }
                                        return;
                                    default:
                                        MainActivity mainActivity11 = mainActivity;
                                        String pref$android_release = mainActivity11.pref$android_release("talkMode");
                                        if (pref$android_release.equals("quick")) {
                                            mainActivity11.getTalk$android_release().open();
                                            return;
                                        } else if (pref$android_release.equals("old")) {
                                            mainActivity11.speak$android_release();
                                            return;
                                        } else {
                                            UiKt.menu(mainActivity11, Fleet.T("talk.choose_title", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_quick", new Pair[0])), Fleet.T("talk.mode_quick_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 21)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_old", new Pair[0])), Fleet.T("talk.mode_old_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 22))}));
                                            return;
                                        }
                                }
                            }
                        });
                        mainActivity.qualBtn = textView2;
                        TextView textView3 = new TextView(mainActivity);
                        textView3.setTextColor(UiKt.TEXT);
                        textView3.setTextSize(13.0f);
                        textView3.setGravity(17);
                        textView3.setPadding(UiKt.dp(mainActivity, f2), 0, UiKt.dp(mainActivity, f8), 0);
                        textView3.setMaxLines(1);
                        textView3.setCompoundDrawablePadding(UiKt.dp(mainActivity, f7));
                        textView3.setBackground(UiKt.box(mainActivity, UiKt.BTN, 10));
                        textView3.setContentDescription(Fleet.T("remote.how_to_hear_the", new Pair[0]));
                        final int i12 = 12;
                        textView3.setOnClickListener(new View.OnClickListener() { // from class: dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda0
                            @Override // android.view.View.OnClickListener
                            public final void onClick(View view2) {
                                int i72 = 5;
                                int i82 = 3;
                                int i92 = 29;
                                int i102 = 4;
                                int i112 = 6;
                                int i122 = 1;
                                int i13 = 0;
                                switch (i12) {
                                    case 0:
                                        mainActivity.toggleVideo$android_release();
                                        return;
                                    case 1:
                                        Regex regex = AdbHelpKt.TV_HOME;
                                        MainActivity mainActivity2 = mainActivity;
                                        UiKt.menu(mainActivity2, Fleet.T("setup.turn_on_adb", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@zap|", Fleet.T("adb_help.automatic_install_tv_setup", new Pair[0])), Fleet.T("adb_help.just_confirm_on_the", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity2, 24)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@gear|", Fleet.T("adb_help.by_hand_open_tv", new Pair[0])), "", new TalkKt$$ExternalSyntheticLambda1(mainActivity2, 25)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@home|", Fleet.T("adb_help.install_another_home_screen", new Pair[0])), Fleet.T("adb_help.when_the_tv_hides", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity2, i92)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@wifi|", Fleet.T("setup.wireless_title", new Pair[0])), Fleet.T("adb_help.android_11_or_newer", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i13)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@refresh|", Fleet.T("adb_help.full_connection", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i82)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@store|", Fleet.T("adb_help.open_the_play_store", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i102)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@package|", Fleet.T("adb_help.open_an_app_by", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i72)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@link|", Fleet.T("setup.direct_title", new Pair[0])), Fleet.T("adb_help.a_fallback_not_reliable", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i112))}));
                                        return;
                                    case 2:
                                        TypingKt.setLive(mainActivity, !r1.live);
                                        return;
                                    case 3:
                                        MainActivity mainActivity3 = mainActivity;
                                        Intrinsics.checkNotNullParameter(mainActivity3, "<this>");
                                        mainActivity3.getPrefs$android_release().edit().putBoolean("listenEven", !mainActivity3.getPrefs$android_release().getBoolean("listenEven", false)).apply();
                                        Fleet.soundChanged(mainActivity3);
                                        return;
                                    case 4:
                                        TypingKt.sendText(mainActivity);
                                        return;
                                    case 5:
                                        mainActivity.onBackPressed();
                                        return;
                                    case 6:
                                        mainActivity.leave$android_release();
                                        return;
                                    case 7:
                                        Fleet.toggleListen(mainActivity);
                                        return;
                                    case 8:
                                        MainActivity mainActivity4 = mainActivity;
                                        TextView label = UiKt.label(mainActivity4, TypingKt.gainWords(TypingKt.listenGain(mainActivity4)), 17, -1);
                                        label.setTypeface(Typeface.DEFAULT_BOLD);
                                        label.setGravity(8388629);
                                        SeekBar seekBar = new SeekBar(mainActivity4);
                                        seekBar.setMax(19);
                                        seekBar.setContentDescription(Fleet.T("listen.loudness", new Pair[0]));
                                        Axml$$ExternalSyntheticLambda2 axml$$ExternalSyntheticLambda2 = new Axml$$ExternalSyntheticLambda2(11, mainActivity4, label);
                                        seekBar.setProgress((int) ((TypingKt.listenGain(mainActivity4) - 0.5f) * 2));
                                        seekBar.setOnSeekBarChangeListener(new PlayingBar.AnonymousClass5(i122, axml$$ExternalSyntheticLambda2));
                                        LinearLayout linearLayout32 = new LinearLayout(mainActivity4);
                                        linearLayout32.setGravity(16);
                                        linearLayout32.addView(seekBar, new LinearLayout.LayoutParams(0, UiKt.dp(mainActivity4, 48), 1.0f));
                                        linearLayout32.addView(label, new LinearLayout.LayoutParams(UiKt.dp(mainActivity4, 56), -2));
                                        LinearLayout linearLayout22 = new LinearLayout(mainActivity4);
                                        linearLayout22.setOrientation(1);
                                        linearLayout22.addView(linearLayout32);
                                        TextView label2 = UiKt.label(mainActivity4, Fleet.T("listen.boost_note", new Pair[0]), 14, UiKt.DIM);
                                        LinearLayout.LayoutParams layoutParams22 = new LinearLayout.LayoutParams(-1, -2);
                                        layoutParams22.topMargin = UiKt.dp(mainActivity4, 8);
                                        linearLayout22.addView(label2, layoutParams22);
                                        Popup.Builder builder = new Popup.Builder(mainActivity4);
                                        builder.title = Fleet.T("remote_screen.loudness_on_the_phone_2", new Pair[0]);
                                        builder.view = UiKt.inDialog(mainActivity4, linearLayout22);
                                        builder.setNeutralButton(Fleet.T("listen.back_to_x1", new Pair[0]), null);
                                        builder.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                                        builder.show().getButton(-3).setOnClickListener(new Guard$$ExternalSyntheticLambda9(7, seekBar, axml$$ExternalSyntheticLambda2));
                                        return;
                                    case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                                        MainActivity mainActivity5 = mainActivity;
                                        Object systemService = mainActivity5.getSystemService("input_method");
                                        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
                                        ((InputMethodManager) systemService).hideSoftInputFromWindow(view2.getWindowToken(), 0);
                                        if (!mainActivity5.needsAdb$android_release()) {
                                            Managing.open$default(mainActivity5.getManaging$android_release(), mainActivity5.host, null, null, 6);
                                            return;
                                        }
                                        return;
                                    case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                                        mainActivity.setFullscreen$android_release(false);
                                        return;
                                    case 11:
                                        MainActivity mainActivity6 = mainActivity;
                                        LinearLayout col2 = UiKt.col(mainActivity6);
                                        LinearLayout linearLayout322 = new LinearLayout(mainActivity6);
                                        LinearLayout linearLayout42 = new LinearLayout(mainActivity6);
                                        LinearLayout linearLayout52 = new LinearLayout(mainActivity6);
                                        LinearLayout linearLayout62 = new LinearLayout(mainActivity6);
                                        TypingKt.qualityMenu$draw(mainActivity6, linearLayout322, linearLayout42, linearLayout52, linearLayout62);
                                        col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.size", new Pair[0])));
                                        col2.addView(linearLayout322, UiKt.gap(mainActivity6, 6));
                                        col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.frames_per_second", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                        col2.addView(linearLayout42, UiKt.gap(mainActivity6, 6));
                                        col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.bit_rate_mbit_s", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                        col2.addView(linearLayout52, UiKt.gap(mainActivity6, 6));
                                        col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.encoder", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                        col2.addView(linearLayout62, UiKt.gap(mainActivity6, 6));
                                        Popup.Builder builder2 = new Popup.Builder(mainActivity6);
                                        builder2.title = Fleet.T("remote_screen.picture_quality", new Pair[0]);
                                        builder2.view = UiKt.inDialog(mainActivity6, col2);
                                        builder2.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                                        builder2.show();
                                        return;
                                    case FileClientSessionCache.MAX_SIZE /* 12 */:
                                        final MainActivity mainActivity7 = mainActivity;
                                        final boolean z = mainActivity7.getPrefs$android_release().getBoolean("listenShare", false);
                                        PopupMenu popupMenu = new PopupMenu(mainActivity7, mainActivity7.getListenChip$android_release());
                                        MenuItem add = popupMenu.getMenu().add(1, 0, 0, Fleet.T("listen.only_the_phone", new Pair[0]));
                                        add.setIcon(TypingKt.listenArt(mainActivity7, false));
                                        add.setChecked(!z);
                                        MenuItem add2 = popupMenu.getMenu().add(1, 1, 1, Fleet.T("listen.tv_and_phone", new Pair[0]));
                                        add2.setIcon(TypingKt.listenArt(mainActivity7, true));
                                        add2.setChecked(z);
                                        popupMenu.getMenu().setGroupCheckable(1, true, true);
                                        if (Build.VERSION.SDK_INT >= 29) {
                                            popupMenu.setForceShowIcon(true);
                                        }
                                        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: dev.tvremote.phone.media.ListenKt$$ExternalSyntheticLambda2
                                            @Override // android.widget.PopupMenu.OnMenuItemClickListener
                                            public final boolean onMenuItemClick(MenuItem menuItem) {
                                                boolean z2;
                                                boolean z3 = false;
                                                if (menuItem.getItemId() == 1) {
                                                    z2 = true;
                                                } else {
                                                    z2 = false;
                                                }
                                                if (z2 != z) {
                                                    MainActivity mainActivity8 = mainActivity7;
                                                    SharedPreferences.Editor edit = mainActivity8.getPrefs$android_release().edit();
                                                    if (menuItem.getItemId() == 1) {
                                                        z3 = true;
                                                    }
                                                    edit.putBoolean("listenShare", z3).apply();
                                                    Fleet.soundChanged(mainActivity8);
                                                }
                                                return true;
                                            }
                                        });
                                        popupMenu.show();
                                        return;
                                    case 13:
                                        MainActivity mainActivity8 = mainActivity;
                                        Intrinsics.checkNotNullParameter(mainActivity8, "<this>");
                                        mainActivity8.getPrefs$android_release().edit().putBoolean("listenHq", !mainActivity8.getPrefs$android_release().getBoolean("listenHq", false)).apply();
                                        Fleet.soundChanged(mainActivity8);
                                        return;
                                    case 14:
                                        mainActivity.setFullscreen$android_release(true);
                                        return;
                                    case 15:
                                        ArrayList arrayList = PipKt.hidden;
                                        MainActivity mainActivity9 = mainActivity;
                                        if (mainActivity9.floating) {
                                            PipKt.unfloat(mainActivity9);
                                            return;
                                        } else {
                                            if (PipKt.picLive(mainActivity9)) {
                                                mainActivity9.floating = true;
                                                PipKt.setFloat(1, mainActivity9);
                                                TypingKt.layoutRemote(mainActivity9);
                                                return;
                                            }
                                            return;
                                        }
                                    case 16:
                                        MainActivity mainActivity10 = mainActivity;
                                        if (mainActivity10.basic != null) {
                                            mainActivity10.press$android_release(true, 26);
                                            return;
                                        }
                                        Tv tv = mainActivity10.tv;
                                        if (tv != null && tv.ready()) {
                                            new Thread(new MainActivity$$ExternalSyntheticLambda38(tv, mainActivity10, i102)).start();
                                            return;
                                        }
                                        return;
                                    default:
                                        MainActivity mainActivity11 = mainActivity;
                                        String pref$android_release = mainActivity11.pref$android_release("talkMode");
                                        if (pref$android_release.equals("quick")) {
                                            mainActivity11.getTalk$android_release().open();
                                            return;
                                        } else if (pref$android_release.equals("old")) {
                                            mainActivity11.speak$android_release();
                                            return;
                                        } else {
                                            UiKt.menu(mainActivity11, Fleet.T("talk.choose_title", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_quick", new Pair[0])), Fleet.T("talk.mode_quick_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 21)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_old", new Pair[0])), Fleet.T("talk.mode_old_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 22))}));
                                            return;
                                        }
                                }
                            }
                        });
                        mainActivity.listenChip = textView3;
                        mainActivity.getSoundBar$android_release().addView(mainActivity.getListenChip$android_release(), new LinearLayout.LayoutParams(-2, UiKt.dp((Context) mainActivity, 34)));
                        TextView textView4 = new TextView(mainActivity);
                        textView4.setText("HQ");
                        textView4.setTextSize(13.0f);
                        Typeface typeface = Typeface.DEFAULT_BOLD;
                        textView4.setTypeface(typeface);
                        textView4.setGravity(17);
                        textView4.setContentDescription(Fleet.T("remote.high_quality_sound_160", new Pair[0]));
                        final int i13 = 13;
                        textView4.setOnClickListener(new View.OnClickListener() { // from class: dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda0
                            @Override // android.view.View.OnClickListener
                            public final void onClick(View view2) {
                                int i72 = 5;
                                int i82 = 3;
                                int i92 = 29;
                                int i102 = 4;
                                int i112 = 6;
                                int i122 = 1;
                                int i132 = 0;
                                switch (i13) {
                                    case 0:
                                        mainActivity.toggleVideo$android_release();
                                        return;
                                    case 1:
                                        Regex regex = AdbHelpKt.TV_HOME;
                                        MainActivity mainActivity2 = mainActivity;
                                        UiKt.menu(mainActivity2, Fleet.T("setup.turn_on_adb", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@zap|", Fleet.T("adb_help.automatic_install_tv_setup", new Pair[0])), Fleet.T("adb_help.just_confirm_on_the", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity2, 24)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@gear|", Fleet.T("adb_help.by_hand_open_tv", new Pair[0])), "", new TalkKt$$ExternalSyntheticLambda1(mainActivity2, 25)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@home|", Fleet.T("adb_help.install_another_home_screen", new Pair[0])), Fleet.T("adb_help.when_the_tv_hides", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity2, i92)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@wifi|", Fleet.T("setup.wireless_title", new Pair[0])), Fleet.T("adb_help.android_11_or_newer", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i132)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@refresh|", Fleet.T("adb_help.full_connection", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i82)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@store|", Fleet.T("adb_help.open_the_play_store", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i102)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@package|", Fleet.T("adb_help.open_an_app_by", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i72)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@link|", Fleet.T("setup.direct_title", new Pair[0])), Fleet.T("adb_help.a_fallback_not_reliable", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i112))}));
                                        return;
                                    case 2:
                                        TypingKt.setLive(mainActivity, !r1.live);
                                        return;
                                    case 3:
                                        MainActivity mainActivity3 = mainActivity;
                                        Intrinsics.checkNotNullParameter(mainActivity3, "<this>");
                                        mainActivity3.getPrefs$android_release().edit().putBoolean("listenEven", !mainActivity3.getPrefs$android_release().getBoolean("listenEven", false)).apply();
                                        Fleet.soundChanged(mainActivity3);
                                        return;
                                    case 4:
                                        TypingKt.sendText(mainActivity);
                                        return;
                                    case 5:
                                        mainActivity.onBackPressed();
                                        return;
                                    case 6:
                                        mainActivity.leave$android_release();
                                        return;
                                    case 7:
                                        Fleet.toggleListen(mainActivity);
                                        return;
                                    case 8:
                                        MainActivity mainActivity4 = mainActivity;
                                        TextView label = UiKt.label(mainActivity4, TypingKt.gainWords(TypingKt.listenGain(mainActivity4)), 17, -1);
                                        label.setTypeface(Typeface.DEFAULT_BOLD);
                                        label.setGravity(8388629);
                                        SeekBar seekBar = new SeekBar(mainActivity4);
                                        seekBar.setMax(19);
                                        seekBar.setContentDescription(Fleet.T("listen.loudness", new Pair[0]));
                                        Axml$$ExternalSyntheticLambda2 axml$$ExternalSyntheticLambda2 = new Axml$$ExternalSyntheticLambda2(11, mainActivity4, label);
                                        seekBar.setProgress((int) ((TypingKt.listenGain(mainActivity4) - 0.5f) * 2));
                                        seekBar.setOnSeekBarChangeListener(new PlayingBar.AnonymousClass5(i122, axml$$ExternalSyntheticLambda2));
                                        LinearLayout linearLayout32 = new LinearLayout(mainActivity4);
                                        linearLayout32.setGravity(16);
                                        linearLayout32.addView(seekBar, new LinearLayout.LayoutParams(0, UiKt.dp(mainActivity4, 48), 1.0f));
                                        linearLayout32.addView(label, new LinearLayout.LayoutParams(UiKt.dp(mainActivity4, 56), -2));
                                        LinearLayout linearLayout22 = new LinearLayout(mainActivity4);
                                        linearLayout22.setOrientation(1);
                                        linearLayout22.addView(linearLayout32);
                                        TextView label2 = UiKt.label(mainActivity4, Fleet.T("listen.boost_note", new Pair[0]), 14, UiKt.DIM);
                                        LinearLayout.LayoutParams layoutParams22 = new LinearLayout.LayoutParams(-1, -2);
                                        layoutParams22.topMargin = UiKt.dp(mainActivity4, 8);
                                        linearLayout22.addView(label2, layoutParams22);
                                        Popup.Builder builder = new Popup.Builder(mainActivity4);
                                        builder.title = Fleet.T("remote_screen.loudness_on_the_phone_2", new Pair[0]);
                                        builder.view = UiKt.inDialog(mainActivity4, linearLayout22);
                                        builder.setNeutralButton(Fleet.T("listen.back_to_x1", new Pair[0]), null);
                                        builder.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                                        builder.show().getButton(-3).setOnClickListener(new Guard$$ExternalSyntheticLambda9(7, seekBar, axml$$ExternalSyntheticLambda2));
                                        return;
                                    case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                                        MainActivity mainActivity5 = mainActivity;
                                        Object systemService = mainActivity5.getSystemService("input_method");
                                        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
                                        ((InputMethodManager) systemService).hideSoftInputFromWindow(view2.getWindowToken(), 0);
                                        if (!mainActivity5.needsAdb$android_release()) {
                                            Managing.open$default(mainActivity5.getManaging$android_release(), mainActivity5.host, null, null, 6);
                                            return;
                                        }
                                        return;
                                    case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                                        mainActivity.setFullscreen$android_release(false);
                                        return;
                                    case 11:
                                        MainActivity mainActivity6 = mainActivity;
                                        LinearLayout col2 = UiKt.col(mainActivity6);
                                        LinearLayout linearLayout322 = new LinearLayout(mainActivity6);
                                        LinearLayout linearLayout42 = new LinearLayout(mainActivity6);
                                        LinearLayout linearLayout52 = new LinearLayout(mainActivity6);
                                        LinearLayout linearLayout62 = new LinearLayout(mainActivity6);
                                        TypingKt.qualityMenu$draw(mainActivity6, linearLayout322, linearLayout42, linearLayout52, linearLayout62);
                                        col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.size", new Pair[0])));
                                        col2.addView(linearLayout322, UiKt.gap(mainActivity6, 6));
                                        col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.frames_per_second", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                        col2.addView(linearLayout42, UiKt.gap(mainActivity6, 6));
                                        col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.bit_rate_mbit_s", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                        col2.addView(linearLayout52, UiKt.gap(mainActivity6, 6));
                                        col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.encoder", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                        col2.addView(linearLayout62, UiKt.gap(mainActivity6, 6));
                                        Popup.Builder builder2 = new Popup.Builder(mainActivity6);
                                        builder2.title = Fleet.T("remote_screen.picture_quality", new Pair[0]);
                                        builder2.view = UiKt.inDialog(mainActivity6, col2);
                                        builder2.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                                        builder2.show();
                                        return;
                                    case FileClientSessionCache.MAX_SIZE /* 12 */:
                                        final MainActivity mainActivity7 = mainActivity;
                                        final boolean z = mainActivity7.getPrefs$android_release().getBoolean("listenShare", false);
                                        PopupMenu popupMenu = new PopupMenu(mainActivity7, mainActivity7.getListenChip$android_release());
                                        MenuItem add = popupMenu.getMenu().add(1, 0, 0, Fleet.T("listen.only_the_phone", new Pair[0]));
                                        add.setIcon(TypingKt.listenArt(mainActivity7, false));
                                        add.setChecked(!z);
                                        MenuItem add2 = popupMenu.getMenu().add(1, 1, 1, Fleet.T("listen.tv_and_phone", new Pair[0]));
                                        add2.setIcon(TypingKt.listenArt(mainActivity7, true));
                                        add2.setChecked(z);
                                        popupMenu.getMenu().setGroupCheckable(1, true, true);
                                        if (Build.VERSION.SDK_INT >= 29) {
                                            popupMenu.setForceShowIcon(true);
                                        }
                                        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: dev.tvremote.phone.media.ListenKt$$ExternalSyntheticLambda2
                                            @Override // android.widget.PopupMenu.OnMenuItemClickListener
                                            public final boolean onMenuItemClick(MenuItem menuItem) {
                                                boolean z2;
                                                boolean z3 = false;
                                                if (menuItem.getItemId() == 1) {
                                                    z2 = true;
                                                } else {
                                                    z2 = false;
                                                }
                                                if (z2 != z) {
                                                    MainActivity mainActivity8 = mainActivity7;
                                                    SharedPreferences.Editor edit = mainActivity8.getPrefs$android_release().edit();
                                                    if (menuItem.getItemId() == 1) {
                                                        z3 = true;
                                                    }
                                                    edit.putBoolean("listenShare", z3).apply();
                                                    Fleet.soundChanged(mainActivity8);
                                                }
                                                return true;
                                            }
                                        });
                                        popupMenu.show();
                                        return;
                                    case 13:
                                        MainActivity mainActivity8 = mainActivity;
                                        Intrinsics.checkNotNullParameter(mainActivity8, "<this>");
                                        mainActivity8.getPrefs$android_release().edit().putBoolean("listenHq", !mainActivity8.getPrefs$android_release().getBoolean("listenHq", false)).apply();
                                        Fleet.soundChanged(mainActivity8);
                                        return;
                                    case 14:
                                        mainActivity.setFullscreen$android_release(true);
                                        return;
                                    case 15:
                                        ArrayList arrayList = PipKt.hidden;
                                        MainActivity mainActivity9 = mainActivity;
                                        if (mainActivity9.floating) {
                                            PipKt.unfloat(mainActivity9);
                                            return;
                                        } else {
                                            if (PipKt.picLive(mainActivity9)) {
                                                mainActivity9.floating = true;
                                                PipKt.setFloat(1, mainActivity9);
                                                TypingKt.layoutRemote(mainActivity9);
                                                return;
                                            }
                                            return;
                                        }
                                    case 16:
                                        MainActivity mainActivity10 = mainActivity;
                                        if (mainActivity10.basic != null) {
                                            mainActivity10.press$android_release(true, 26);
                                            return;
                                        }
                                        Tv tv = mainActivity10.tv;
                                        if (tv != null && tv.ready()) {
                                            new Thread(new MainActivity$$ExternalSyntheticLambda38(tv, mainActivity10, i102)).start();
                                            return;
                                        }
                                        return;
                                    default:
                                        MainActivity mainActivity11 = mainActivity;
                                        String pref$android_release = mainActivity11.pref$android_release("talkMode");
                                        if (pref$android_release.equals("quick")) {
                                            mainActivity11.getTalk$android_release().open();
                                            return;
                                        } else if (pref$android_release.equals("old")) {
                                            mainActivity11.speak$android_release();
                                            return;
                                        } else {
                                            UiKt.menu(mainActivity11, Fleet.T("talk.choose_title", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_quick", new Pair[0])), Fleet.T("talk.mode_quick_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 21)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_old", new Pair[0])), Fleet.T("talk.mode_old_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 22))}));
                                            return;
                                        }
                                }
                            }
                        });
                        mainActivity.hqBtn = textView4;
                        LinearLayout soundBar$android_release = mainActivity.getSoundBar$android_release();
                        TextView textView5 = mainActivity.hqBtn;
                        if (textView5 != null) {
                            LinearLayout.LayoutParams layoutParams7 = new LinearLayout.LayoutParams(UiKt.dp((Context) mainActivity, 44), UiKt.dp((Context) mainActivity, 34));
                            layoutParams7.leftMargin = UiKt.dp((Context) mainActivity, 8);
                            soundBar$android_release.addView(textView5, layoutParams7);
                            TextView textView6 = new TextView(mainActivity);
                            textView6.setText(Fleet.T("remote.even", new Pair[0]));
                            textView6.setTextSize(13.0f);
                            textView6.setTypeface(typeface);
                            textView6.setGravity(17);
                            textView6.setPadding(UiKt.dp((Context) mainActivity, 10), 0, UiKt.dp((Context) mainActivity, 10), 0);
                            textView6.setContentDescription(Fleet.T("remote.steadier_sound_half_a", new Pair[0]));
                            final int i14 = 3;
                            textView6.setOnClickListener(new View.OnClickListener() { // from class: dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda0
                                @Override // android.view.View.OnClickListener
                                public final void onClick(View view2) {
                                    int i72 = 5;
                                    int i82 = 3;
                                    int i92 = 29;
                                    int i102 = 4;
                                    int i112 = 6;
                                    int i122 = 1;
                                    int i132 = 0;
                                    switch (i14) {
                                        case 0:
                                            mainActivity.toggleVideo$android_release();
                                            return;
                                        case 1:
                                            Regex regex = AdbHelpKt.TV_HOME;
                                            MainActivity mainActivity2 = mainActivity;
                                            UiKt.menu(mainActivity2, Fleet.T("setup.turn_on_adb", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@zap|", Fleet.T("adb_help.automatic_install_tv_setup", new Pair[0])), Fleet.T("adb_help.just_confirm_on_the", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity2, 24)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@gear|", Fleet.T("adb_help.by_hand_open_tv", new Pair[0])), "", new TalkKt$$ExternalSyntheticLambda1(mainActivity2, 25)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@home|", Fleet.T("adb_help.install_another_home_screen", new Pair[0])), Fleet.T("adb_help.when_the_tv_hides", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity2, i92)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@wifi|", Fleet.T("setup.wireless_title", new Pair[0])), Fleet.T("adb_help.android_11_or_newer", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i132)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@refresh|", Fleet.T("adb_help.full_connection", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i82)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@store|", Fleet.T("adb_help.open_the_play_store", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i102)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@package|", Fleet.T("adb_help.open_an_app_by", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i72)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@link|", Fleet.T("setup.direct_title", new Pair[0])), Fleet.T("adb_help.a_fallback_not_reliable", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i112))}));
                                            return;
                                        case 2:
                                            TypingKt.setLive(mainActivity, !r1.live);
                                            return;
                                        case 3:
                                            MainActivity mainActivity3 = mainActivity;
                                            Intrinsics.checkNotNullParameter(mainActivity3, "<this>");
                                            mainActivity3.getPrefs$android_release().edit().putBoolean("listenEven", !mainActivity3.getPrefs$android_release().getBoolean("listenEven", false)).apply();
                                            Fleet.soundChanged(mainActivity3);
                                            return;
                                        case 4:
                                            TypingKt.sendText(mainActivity);
                                            return;
                                        case 5:
                                            mainActivity.onBackPressed();
                                            return;
                                        case 6:
                                            mainActivity.leave$android_release();
                                            return;
                                        case 7:
                                            Fleet.toggleListen(mainActivity);
                                            return;
                                        case 8:
                                            MainActivity mainActivity4 = mainActivity;
                                            TextView label = UiKt.label(mainActivity4, TypingKt.gainWords(TypingKt.listenGain(mainActivity4)), 17, -1);
                                            label.setTypeface(Typeface.DEFAULT_BOLD);
                                            label.setGravity(8388629);
                                            SeekBar seekBar = new SeekBar(mainActivity4);
                                            seekBar.setMax(19);
                                            seekBar.setContentDescription(Fleet.T("listen.loudness", new Pair[0]));
                                            Axml$$ExternalSyntheticLambda2 axml$$ExternalSyntheticLambda2 = new Axml$$ExternalSyntheticLambda2(11, mainActivity4, label);
                                            seekBar.setProgress((int) ((TypingKt.listenGain(mainActivity4) - 0.5f) * 2));
                                            seekBar.setOnSeekBarChangeListener(new PlayingBar.AnonymousClass5(i122, axml$$ExternalSyntheticLambda2));
                                            LinearLayout linearLayout32 = new LinearLayout(mainActivity4);
                                            linearLayout32.setGravity(16);
                                            linearLayout32.addView(seekBar, new LinearLayout.LayoutParams(0, UiKt.dp(mainActivity4, 48), 1.0f));
                                            linearLayout32.addView(label, new LinearLayout.LayoutParams(UiKt.dp(mainActivity4, 56), -2));
                                            LinearLayout linearLayout22 = new LinearLayout(mainActivity4);
                                            linearLayout22.setOrientation(1);
                                            linearLayout22.addView(linearLayout32);
                                            TextView label2 = UiKt.label(mainActivity4, Fleet.T("listen.boost_note", new Pair[0]), 14, UiKt.DIM);
                                            LinearLayout.LayoutParams layoutParams22 = new LinearLayout.LayoutParams(-1, -2);
                                            layoutParams22.topMargin = UiKt.dp(mainActivity4, 8);
                                            linearLayout22.addView(label2, layoutParams22);
                                            Popup.Builder builder = new Popup.Builder(mainActivity4);
                                            builder.title = Fleet.T("remote_screen.loudness_on_the_phone_2", new Pair[0]);
                                            builder.view = UiKt.inDialog(mainActivity4, linearLayout22);
                                            builder.setNeutralButton(Fleet.T("listen.back_to_x1", new Pair[0]), null);
                                            builder.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                                            builder.show().getButton(-3).setOnClickListener(new Guard$$ExternalSyntheticLambda9(7, seekBar, axml$$ExternalSyntheticLambda2));
                                            return;
                                        case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                                            MainActivity mainActivity5 = mainActivity;
                                            Object systemService = mainActivity5.getSystemService("input_method");
                                            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
                                            ((InputMethodManager) systemService).hideSoftInputFromWindow(view2.getWindowToken(), 0);
                                            if (!mainActivity5.needsAdb$android_release()) {
                                                Managing.open$default(mainActivity5.getManaging$android_release(), mainActivity5.host, null, null, 6);
                                                return;
                                            }
                                            return;
                                        case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                                            mainActivity.setFullscreen$android_release(false);
                                            return;
                                        case 11:
                                            MainActivity mainActivity6 = mainActivity;
                                            LinearLayout col2 = UiKt.col(mainActivity6);
                                            LinearLayout linearLayout322 = new LinearLayout(mainActivity6);
                                            LinearLayout linearLayout42 = new LinearLayout(mainActivity6);
                                            LinearLayout linearLayout52 = new LinearLayout(mainActivity6);
                                            LinearLayout linearLayout62 = new LinearLayout(mainActivity6);
                                            TypingKt.qualityMenu$draw(mainActivity6, linearLayout322, linearLayout42, linearLayout52, linearLayout62);
                                            col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.size", new Pair[0])));
                                            col2.addView(linearLayout322, UiKt.gap(mainActivity6, 6));
                                            col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.frames_per_second", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                            col2.addView(linearLayout42, UiKt.gap(mainActivity6, 6));
                                            col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.bit_rate_mbit_s", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                            col2.addView(linearLayout52, UiKt.gap(mainActivity6, 6));
                                            col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.encoder", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                            col2.addView(linearLayout62, UiKt.gap(mainActivity6, 6));
                                            Popup.Builder builder2 = new Popup.Builder(mainActivity6);
                                            builder2.title = Fleet.T("remote_screen.picture_quality", new Pair[0]);
                                            builder2.view = UiKt.inDialog(mainActivity6, col2);
                                            builder2.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                                            builder2.show();
                                            return;
                                        case FileClientSessionCache.MAX_SIZE /* 12 */:
                                            final MainActivity mainActivity7 = mainActivity;
                                            final boolean z = mainActivity7.getPrefs$android_release().getBoolean("listenShare", false);
                                            PopupMenu popupMenu = new PopupMenu(mainActivity7, mainActivity7.getListenChip$android_release());
                                            MenuItem add = popupMenu.getMenu().add(1, 0, 0, Fleet.T("listen.only_the_phone", new Pair[0]));
                                            add.setIcon(TypingKt.listenArt(mainActivity7, false));
                                            add.setChecked(!z);
                                            MenuItem add2 = popupMenu.getMenu().add(1, 1, 1, Fleet.T("listen.tv_and_phone", new Pair[0]));
                                            add2.setIcon(TypingKt.listenArt(mainActivity7, true));
                                            add2.setChecked(z);
                                            popupMenu.getMenu().setGroupCheckable(1, true, true);
                                            if (Build.VERSION.SDK_INT >= 29) {
                                                popupMenu.setForceShowIcon(true);
                                            }
                                            popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: dev.tvremote.phone.media.ListenKt$$ExternalSyntheticLambda2
                                                @Override // android.widget.PopupMenu.OnMenuItemClickListener
                                                public final boolean onMenuItemClick(MenuItem menuItem) {
                                                    boolean z2;
                                                    boolean z3 = false;
                                                    if (menuItem.getItemId() == 1) {
                                                        z2 = true;
                                                    } else {
                                                        z2 = false;
                                                    }
                                                    if (z2 != z) {
                                                        MainActivity mainActivity8 = mainActivity7;
                                                        SharedPreferences.Editor edit = mainActivity8.getPrefs$android_release().edit();
                                                        if (menuItem.getItemId() == 1) {
                                                            z3 = true;
                                                        }
                                                        edit.putBoolean("listenShare", z3).apply();
                                                        Fleet.soundChanged(mainActivity8);
                                                    }
                                                    return true;
                                                }
                                            });
                                            popupMenu.show();
                                            return;
                                        case 13:
                                            MainActivity mainActivity8 = mainActivity;
                                            Intrinsics.checkNotNullParameter(mainActivity8, "<this>");
                                            mainActivity8.getPrefs$android_release().edit().putBoolean("listenHq", !mainActivity8.getPrefs$android_release().getBoolean("listenHq", false)).apply();
                                            Fleet.soundChanged(mainActivity8);
                                            return;
                                        case 14:
                                            mainActivity.setFullscreen$android_release(true);
                                            return;
                                        case 15:
                                            ArrayList arrayList = PipKt.hidden;
                                            MainActivity mainActivity9 = mainActivity;
                                            if (mainActivity9.floating) {
                                                PipKt.unfloat(mainActivity9);
                                                return;
                                            } else {
                                                if (PipKt.picLive(mainActivity9)) {
                                                    mainActivity9.floating = true;
                                                    PipKt.setFloat(1, mainActivity9);
                                                    TypingKt.layoutRemote(mainActivity9);
                                                    return;
                                                }
                                                return;
                                            }
                                        case 16:
                                            MainActivity mainActivity10 = mainActivity;
                                            if (mainActivity10.basic != null) {
                                                mainActivity10.press$android_release(true, 26);
                                                return;
                                            }
                                            Tv tv = mainActivity10.tv;
                                            if (tv != null && tv.ready()) {
                                                new Thread(new MainActivity$$ExternalSyntheticLambda38(tv, mainActivity10, i102)).start();
                                                return;
                                            }
                                            return;
                                        default:
                                            MainActivity mainActivity11 = mainActivity;
                                            String pref$android_release = mainActivity11.pref$android_release("talkMode");
                                            if (pref$android_release.equals("quick")) {
                                                mainActivity11.getTalk$android_release().open();
                                                return;
                                            } else if (pref$android_release.equals("old")) {
                                                mainActivity11.speak$android_release();
                                                return;
                                            } else {
                                                UiKt.menu(mainActivity11, Fleet.T("talk.choose_title", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_quick", new Pair[0])), Fleet.T("talk.mode_quick_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 21)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_old", new Pair[0])), Fleet.T("talk.mode_old_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 22))}));
                                                return;
                                            }
                                    }
                                }
                            });
                            mainActivity.evenBtn = textView6;
                            LinearLayout soundBar$android_release2 = mainActivity.getSoundBar$android_release();
                            TextView textView7 = mainActivity.evenBtn;
                            if (textView7 != null) {
                                LinearLayout.LayoutParams layoutParams8 = new LinearLayout.LayoutParams(-2, UiKt.dp((Context) mainActivity, 34));
                                layoutParams8.leftMargin = UiKt.dp((Context) mainActivity, 8);
                                soundBar$android_release2.addView(textView7, layoutParams8);
                                TextView textView8 = new TextView(mainActivity);
                                textView8.setTextSize(13.0f);
                                textView8.setTypeface(typeface);
                                textView8.setGravity(17);
                                textView8.setPadding(UiKt.dp((Context) mainActivity, 10), 0, UiKt.dp((Context) mainActivity, 10), 0);
                                textView8.setContentDescription(Fleet.T("remote_screen.loudness_on_the_phone", new Pair[0]));
                                final int i15 = 8;
                                textView8.setOnClickListener(new View.OnClickListener() { // from class: dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda0
                                    @Override // android.view.View.OnClickListener
                                    public final void onClick(View view2) {
                                        int i72 = 5;
                                        int i82 = 3;
                                        int i92 = 29;
                                        int i102 = 4;
                                        int i112 = 6;
                                        int i122 = 1;
                                        int i132 = 0;
                                        switch (i15) {
                                            case 0:
                                                mainActivity.toggleVideo$android_release();
                                                return;
                                            case 1:
                                                Regex regex = AdbHelpKt.TV_HOME;
                                                MainActivity mainActivity2 = mainActivity;
                                                UiKt.menu(mainActivity2, Fleet.T("setup.turn_on_adb", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@zap|", Fleet.T("adb_help.automatic_install_tv_setup", new Pair[0])), Fleet.T("adb_help.just_confirm_on_the", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity2, 24)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@gear|", Fleet.T("adb_help.by_hand_open_tv", new Pair[0])), "", new TalkKt$$ExternalSyntheticLambda1(mainActivity2, 25)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@home|", Fleet.T("adb_help.install_another_home_screen", new Pair[0])), Fleet.T("adb_help.when_the_tv_hides", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity2, i92)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@wifi|", Fleet.T("setup.wireless_title", new Pair[0])), Fleet.T("adb_help.android_11_or_newer", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i132)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@refresh|", Fleet.T("adb_help.full_connection", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i82)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@store|", Fleet.T("adb_help.open_the_play_store", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i102)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@package|", Fleet.T("adb_help.open_an_app_by", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i72)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@link|", Fleet.T("setup.direct_title", new Pair[0])), Fleet.T("adb_help.a_fallback_not_reliable", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i112))}));
                                                return;
                                            case 2:
                                                TypingKt.setLive(mainActivity, !r1.live);
                                                return;
                                            case 3:
                                                MainActivity mainActivity3 = mainActivity;
                                                Intrinsics.checkNotNullParameter(mainActivity3, "<this>");
                                                mainActivity3.getPrefs$android_release().edit().putBoolean("listenEven", !mainActivity3.getPrefs$android_release().getBoolean("listenEven", false)).apply();
                                                Fleet.soundChanged(mainActivity3);
                                                return;
                                            case 4:
                                                TypingKt.sendText(mainActivity);
                                                return;
                                            case 5:
                                                mainActivity.onBackPressed();
                                                return;
                                            case 6:
                                                mainActivity.leave$android_release();
                                                return;
                                            case 7:
                                                Fleet.toggleListen(mainActivity);
                                                return;
                                            case 8:
                                                MainActivity mainActivity4 = mainActivity;
                                                TextView label = UiKt.label(mainActivity4, TypingKt.gainWords(TypingKt.listenGain(mainActivity4)), 17, -1);
                                                label.setTypeface(Typeface.DEFAULT_BOLD);
                                                label.setGravity(8388629);
                                                SeekBar seekBar = new SeekBar(mainActivity4);
                                                seekBar.setMax(19);
                                                seekBar.setContentDescription(Fleet.T("listen.loudness", new Pair[0]));
                                                Axml$$ExternalSyntheticLambda2 axml$$ExternalSyntheticLambda2 = new Axml$$ExternalSyntheticLambda2(11, mainActivity4, label);
                                                seekBar.setProgress((int) ((TypingKt.listenGain(mainActivity4) - 0.5f) * 2));
                                                seekBar.setOnSeekBarChangeListener(new PlayingBar.AnonymousClass5(i122, axml$$ExternalSyntheticLambda2));
                                                LinearLayout linearLayout32 = new LinearLayout(mainActivity4);
                                                linearLayout32.setGravity(16);
                                                linearLayout32.addView(seekBar, new LinearLayout.LayoutParams(0, UiKt.dp(mainActivity4, 48), 1.0f));
                                                linearLayout32.addView(label, new LinearLayout.LayoutParams(UiKt.dp(mainActivity4, 56), -2));
                                                LinearLayout linearLayout22 = new LinearLayout(mainActivity4);
                                                linearLayout22.setOrientation(1);
                                                linearLayout22.addView(linearLayout32);
                                                TextView label2 = UiKt.label(mainActivity4, Fleet.T("listen.boost_note", new Pair[0]), 14, UiKt.DIM);
                                                LinearLayout.LayoutParams layoutParams22 = new LinearLayout.LayoutParams(-1, -2);
                                                layoutParams22.topMargin = UiKt.dp(mainActivity4, 8);
                                                linearLayout22.addView(label2, layoutParams22);
                                                Popup.Builder builder = new Popup.Builder(mainActivity4);
                                                builder.title = Fleet.T("remote_screen.loudness_on_the_phone_2", new Pair[0]);
                                                builder.view = UiKt.inDialog(mainActivity4, linearLayout22);
                                                builder.setNeutralButton(Fleet.T("listen.back_to_x1", new Pair[0]), null);
                                                builder.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                                                builder.show().getButton(-3).setOnClickListener(new Guard$$ExternalSyntheticLambda9(7, seekBar, axml$$ExternalSyntheticLambda2));
                                                return;
                                            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                                                MainActivity mainActivity5 = mainActivity;
                                                Object systemService = mainActivity5.getSystemService("input_method");
                                                Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
                                                ((InputMethodManager) systemService).hideSoftInputFromWindow(view2.getWindowToken(), 0);
                                                if (!mainActivity5.needsAdb$android_release()) {
                                                    Managing.open$default(mainActivity5.getManaging$android_release(), mainActivity5.host, null, null, 6);
                                                    return;
                                                }
                                                return;
                                            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                                                mainActivity.setFullscreen$android_release(false);
                                                return;
                                            case 11:
                                                MainActivity mainActivity6 = mainActivity;
                                                LinearLayout col2 = UiKt.col(mainActivity6);
                                                LinearLayout linearLayout322 = new LinearLayout(mainActivity6);
                                                LinearLayout linearLayout42 = new LinearLayout(mainActivity6);
                                                LinearLayout linearLayout52 = new LinearLayout(mainActivity6);
                                                LinearLayout linearLayout62 = new LinearLayout(mainActivity6);
                                                TypingKt.qualityMenu$draw(mainActivity6, linearLayout322, linearLayout42, linearLayout52, linearLayout62);
                                                col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.size", new Pair[0])));
                                                col2.addView(linearLayout322, UiKt.gap(mainActivity6, 6));
                                                col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.frames_per_second", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                                col2.addView(linearLayout42, UiKt.gap(mainActivity6, 6));
                                                col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.bit_rate_mbit_s", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                                col2.addView(linearLayout52, UiKt.gap(mainActivity6, 6));
                                                col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.encoder", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                                col2.addView(linearLayout62, UiKt.gap(mainActivity6, 6));
                                                Popup.Builder builder2 = new Popup.Builder(mainActivity6);
                                                builder2.title = Fleet.T("remote_screen.picture_quality", new Pair[0]);
                                                builder2.view = UiKt.inDialog(mainActivity6, col2);
                                                builder2.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                                                builder2.show();
                                                return;
                                            case FileClientSessionCache.MAX_SIZE /* 12 */:
                                                final MainActivity mainActivity7 = mainActivity;
                                                final boolean z = mainActivity7.getPrefs$android_release().getBoolean("listenShare", false);
                                                PopupMenu popupMenu = new PopupMenu(mainActivity7, mainActivity7.getListenChip$android_release());
                                                MenuItem add = popupMenu.getMenu().add(1, 0, 0, Fleet.T("listen.only_the_phone", new Pair[0]));
                                                add.setIcon(TypingKt.listenArt(mainActivity7, false));
                                                add.setChecked(!z);
                                                MenuItem add2 = popupMenu.getMenu().add(1, 1, 1, Fleet.T("listen.tv_and_phone", new Pair[0]));
                                                add2.setIcon(TypingKt.listenArt(mainActivity7, true));
                                                add2.setChecked(z);
                                                popupMenu.getMenu().setGroupCheckable(1, true, true);
                                                if (Build.VERSION.SDK_INT >= 29) {
                                                    popupMenu.setForceShowIcon(true);
                                                }
                                                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: dev.tvremote.phone.media.ListenKt$$ExternalSyntheticLambda2
                                                    @Override // android.widget.PopupMenu.OnMenuItemClickListener
                                                    public final boolean onMenuItemClick(MenuItem menuItem) {
                                                        boolean z2;
                                                        boolean z3 = false;
                                                        if (menuItem.getItemId() == 1) {
                                                            z2 = true;
                                                        } else {
                                                            z2 = false;
                                                        }
                                                        if (z2 != z) {
                                                            MainActivity mainActivity8 = mainActivity7;
                                                            SharedPreferences.Editor edit = mainActivity8.getPrefs$android_release().edit();
                                                            if (menuItem.getItemId() == 1) {
                                                                z3 = true;
                                                            }
                                                            edit.putBoolean("listenShare", z3).apply();
                                                            Fleet.soundChanged(mainActivity8);
                                                        }
                                                        return true;
                                                    }
                                                });
                                                popupMenu.show();
                                                return;
                                            case 13:
                                                MainActivity mainActivity8 = mainActivity;
                                                Intrinsics.checkNotNullParameter(mainActivity8, "<this>");
                                                mainActivity8.getPrefs$android_release().edit().putBoolean("listenHq", !mainActivity8.getPrefs$android_release().getBoolean("listenHq", false)).apply();
                                                Fleet.soundChanged(mainActivity8);
                                                return;
                                            case 14:
                                                mainActivity.setFullscreen$android_release(true);
                                                return;
                                            case 15:
                                                ArrayList arrayList = PipKt.hidden;
                                                MainActivity mainActivity9 = mainActivity;
                                                if (mainActivity9.floating) {
                                                    PipKt.unfloat(mainActivity9);
                                                    return;
                                                } else {
                                                    if (PipKt.picLive(mainActivity9)) {
                                                        mainActivity9.floating = true;
                                                        PipKt.setFloat(1, mainActivity9);
                                                        TypingKt.layoutRemote(mainActivity9);
                                                        return;
                                                    }
                                                    return;
                                                }
                                            case 16:
                                                MainActivity mainActivity10 = mainActivity;
                                                if (mainActivity10.basic != null) {
                                                    mainActivity10.press$android_release(true, 26);
                                                    return;
                                                }
                                                Tv tv = mainActivity10.tv;
                                                if (tv != null && tv.ready()) {
                                                    new Thread(new MainActivity$$ExternalSyntheticLambda38(tv, mainActivity10, i102)).start();
                                                    return;
                                                }
                                                return;
                                            default:
                                                MainActivity mainActivity11 = mainActivity;
                                                String pref$android_release = mainActivity11.pref$android_release("talkMode");
                                                if (pref$android_release.equals("quick")) {
                                                    mainActivity11.getTalk$android_release().open();
                                                    return;
                                                } else if (pref$android_release.equals("old")) {
                                                    mainActivity11.speak$android_release();
                                                    return;
                                                } else {
                                                    UiKt.menu(mainActivity11, Fleet.T("talk.choose_title", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_quick", new Pair[0])), Fleet.T("talk.mode_quick_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 21)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_old", new Pair[0])), Fleet.T("talk.mode_old_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 22))}));
                                                    return;
                                                }
                                        }
                                    }
                                });
                                mainActivity.boostBtn = textView8;
                                LinearLayout soundBar$android_release3 = mainActivity.getSoundBar$android_release();
                                TextView textView9 = mainActivity.boostBtn;
                                if (textView9 != null) {
                                    LinearLayout.LayoutParams layoutParams9 = new LinearLayout.LayoutParams(-2, UiKt.dp((Context) mainActivity, 34));
                                    layoutParams9.leftMargin = UiKt.dp((Context) mainActivity, 8);
                                    soundBar$android_release3.addView(textView9, layoutParams9);
                                    mainActivity.getPicBar$android_release().addView(new View(mainActivity), new LinearLayout.LayoutParams(0, 1, 1.0f));
                                    LinearLayout picBar$android_release = mainActivity.getPicBar$android_release();
                                    TextView qualBtn$android_release = mainActivity.getQualBtn$android_release();
                                    LinearLayout.LayoutParams layoutParams10 = new LinearLayout.LayoutParams(-2, UiKt.dp((Context) mainActivity, 34));
                                    layoutParams10.leftMargin = UiKt.dp((Context) mainActivity, 8);
                                    picBar$android_release.addView(qualBtn$android_release, layoutParams10);
                                    mainActivity.fullBtn = UiKt.icon(mainActivity, "@expand", Fleet.T("remote.full_screen", new Pair[0]), UiKt.getBTN());
                                    IconButton iconButton5 = mainActivity.fullBtn;
                                    if (iconButton5 != null) {
                                        final int i16 = 14;
                                        iconButton5.setOnClickListener(new View.OnClickListener() { // from class: dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda0
                                            @Override // android.view.View.OnClickListener
                                            public final void onClick(View view2) {
                                                int i72 = 5;
                                                int i82 = 3;
                                                int i92 = 29;
                                                int i102 = 4;
                                                int i112 = 6;
                                                int i122 = 1;
                                                int i132 = 0;
                                                switch (i16) {
                                                    case 0:
                                                        mainActivity.toggleVideo$android_release();
                                                        return;
                                                    case 1:
                                                        Regex regex = AdbHelpKt.TV_HOME;
                                                        MainActivity mainActivity2 = mainActivity;
                                                        UiKt.menu(mainActivity2, Fleet.T("setup.turn_on_adb", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@zap|", Fleet.T("adb_help.automatic_install_tv_setup", new Pair[0])), Fleet.T("adb_help.just_confirm_on_the", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity2, 24)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@gear|", Fleet.T("adb_help.by_hand_open_tv", new Pair[0])), "", new TalkKt$$ExternalSyntheticLambda1(mainActivity2, 25)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@home|", Fleet.T("adb_help.install_another_home_screen", new Pair[0])), Fleet.T("adb_help.when_the_tv_hides", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity2, i92)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@wifi|", Fleet.T("setup.wireless_title", new Pair[0])), Fleet.T("adb_help.android_11_or_newer", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i132)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@refresh|", Fleet.T("adb_help.full_connection", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i82)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@store|", Fleet.T("adb_help.open_the_play_store", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i102)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@package|", Fleet.T("adb_help.open_an_app_by", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i72)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@link|", Fleet.T("setup.direct_title", new Pair[0])), Fleet.T("adb_help.a_fallback_not_reliable", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i112))}));
                                                        return;
                                                    case 2:
                                                        TypingKt.setLive(mainActivity, !r1.live);
                                                        return;
                                                    case 3:
                                                        MainActivity mainActivity3 = mainActivity;
                                                        Intrinsics.checkNotNullParameter(mainActivity3, "<this>");
                                                        mainActivity3.getPrefs$android_release().edit().putBoolean("listenEven", !mainActivity3.getPrefs$android_release().getBoolean("listenEven", false)).apply();
                                                        Fleet.soundChanged(mainActivity3);
                                                        return;
                                                    case 4:
                                                        TypingKt.sendText(mainActivity);
                                                        return;
                                                    case 5:
                                                        mainActivity.onBackPressed();
                                                        return;
                                                    case 6:
                                                        mainActivity.leave$android_release();
                                                        return;
                                                    case 7:
                                                        Fleet.toggleListen(mainActivity);
                                                        return;
                                                    case 8:
                                                        MainActivity mainActivity4 = mainActivity;
                                                        TextView label = UiKt.label(mainActivity4, TypingKt.gainWords(TypingKt.listenGain(mainActivity4)), 17, -1);
                                                        label.setTypeface(Typeface.DEFAULT_BOLD);
                                                        label.setGravity(8388629);
                                                        SeekBar seekBar = new SeekBar(mainActivity4);
                                                        seekBar.setMax(19);
                                                        seekBar.setContentDescription(Fleet.T("listen.loudness", new Pair[0]));
                                                        Axml$$ExternalSyntheticLambda2 axml$$ExternalSyntheticLambda2 = new Axml$$ExternalSyntheticLambda2(11, mainActivity4, label);
                                                        seekBar.setProgress((int) ((TypingKt.listenGain(mainActivity4) - 0.5f) * 2));
                                                        seekBar.setOnSeekBarChangeListener(new PlayingBar.AnonymousClass5(i122, axml$$ExternalSyntheticLambda2));
                                                        LinearLayout linearLayout32 = new LinearLayout(mainActivity4);
                                                        linearLayout32.setGravity(16);
                                                        linearLayout32.addView(seekBar, new LinearLayout.LayoutParams(0, UiKt.dp(mainActivity4, 48), 1.0f));
                                                        linearLayout32.addView(label, new LinearLayout.LayoutParams(UiKt.dp(mainActivity4, 56), -2));
                                                        LinearLayout linearLayout22 = new LinearLayout(mainActivity4);
                                                        linearLayout22.setOrientation(1);
                                                        linearLayout22.addView(linearLayout32);
                                                        TextView label2 = UiKt.label(mainActivity4, Fleet.T("listen.boost_note", new Pair[0]), 14, UiKt.DIM);
                                                        LinearLayout.LayoutParams layoutParams22 = new LinearLayout.LayoutParams(-1, -2);
                                                        layoutParams22.topMargin = UiKt.dp(mainActivity4, 8);
                                                        linearLayout22.addView(label2, layoutParams22);
                                                        Popup.Builder builder = new Popup.Builder(mainActivity4);
                                                        builder.title = Fleet.T("remote_screen.loudness_on_the_phone_2", new Pair[0]);
                                                        builder.view = UiKt.inDialog(mainActivity4, linearLayout22);
                                                        builder.setNeutralButton(Fleet.T("listen.back_to_x1", new Pair[0]), null);
                                                        builder.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                                                        builder.show().getButton(-3).setOnClickListener(new Guard$$ExternalSyntheticLambda9(7, seekBar, axml$$ExternalSyntheticLambda2));
                                                        return;
                                                    case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                                                        MainActivity mainActivity5 = mainActivity;
                                                        Object systemService = mainActivity5.getSystemService("input_method");
                                                        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
                                                        ((InputMethodManager) systemService).hideSoftInputFromWindow(view2.getWindowToken(), 0);
                                                        if (!mainActivity5.needsAdb$android_release()) {
                                                            Managing.open$default(mainActivity5.getManaging$android_release(), mainActivity5.host, null, null, 6);
                                                            return;
                                                        }
                                                        return;
                                                    case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                                                        mainActivity.setFullscreen$android_release(false);
                                                        return;
                                                    case 11:
                                                        MainActivity mainActivity6 = mainActivity;
                                                        LinearLayout col2 = UiKt.col(mainActivity6);
                                                        LinearLayout linearLayout322 = new LinearLayout(mainActivity6);
                                                        LinearLayout linearLayout42 = new LinearLayout(mainActivity6);
                                                        LinearLayout linearLayout52 = new LinearLayout(mainActivity6);
                                                        LinearLayout linearLayout62 = new LinearLayout(mainActivity6);
                                                        TypingKt.qualityMenu$draw(mainActivity6, linearLayout322, linearLayout42, linearLayout52, linearLayout62);
                                                        col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.size", new Pair[0])));
                                                        col2.addView(linearLayout322, UiKt.gap(mainActivity6, 6));
                                                        col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.frames_per_second", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                                        col2.addView(linearLayout42, UiKt.gap(mainActivity6, 6));
                                                        col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.bit_rate_mbit_s", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                                        col2.addView(linearLayout52, UiKt.gap(mainActivity6, 6));
                                                        col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.encoder", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                                        col2.addView(linearLayout62, UiKt.gap(mainActivity6, 6));
                                                        Popup.Builder builder2 = new Popup.Builder(mainActivity6);
                                                        builder2.title = Fleet.T("remote_screen.picture_quality", new Pair[0]);
                                                        builder2.view = UiKt.inDialog(mainActivity6, col2);
                                                        builder2.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                                                        builder2.show();
                                                        return;
                                                    case FileClientSessionCache.MAX_SIZE /* 12 */:
                                                        final MainActivity mainActivity7 = mainActivity;
                                                        final boolean z = mainActivity7.getPrefs$android_release().getBoolean("listenShare", false);
                                                        PopupMenu popupMenu = new PopupMenu(mainActivity7, mainActivity7.getListenChip$android_release());
                                                        MenuItem add = popupMenu.getMenu().add(1, 0, 0, Fleet.T("listen.only_the_phone", new Pair[0]));
                                                        add.setIcon(TypingKt.listenArt(mainActivity7, false));
                                                        add.setChecked(!z);
                                                        MenuItem add2 = popupMenu.getMenu().add(1, 1, 1, Fleet.T("listen.tv_and_phone", new Pair[0]));
                                                        add2.setIcon(TypingKt.listenArt(mainActivity7, true));
                                                        add2.setChecked(z);
                                                        popupMenu.getMenu().setGroupCheckable(1, true, true);
                                                        if (Build.VERSION.SDK_INT >= 29) {
                                                            popupMenu.setForceShowIcon(true);
                                                        }
                                                        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: dev.tvremote.phone.media.ListenKt$$ExternalSyntheticLambda2
                                                            @Override // android.widget.PopupMenu.OnMenuItemClickListener
                                                            public final boolean onMenuItemClick(MenuItem menuItem) {
                                                                boolean z2;
                                                                boolean z3 = false;
                                                                if (menuItem.getItemId() == 1) {
                                                                    z2 = true;
                                                                } else {
                                                                    z2 = false;
                                                                }
                                                                if (z2 != z) {
                                                                    MainActivity mainActivity8 = mainActivity7;
                                                                    SharedPreferences.Editor edit = mainActivity8.getPrefs$android_release().edit();
                                                                    if (menuItem.getItemId() == 1) {
                                                                        z3 = true;
                                                                    }
                                                                    edit.putBoolean("listenShare", z3).apply();
                                                                    Fleet.soundChanged(mainActivity8);
                                                                }
                                                                return true;
                                                            }
                                                        });
                                                        popupMenu.show();
                                                        return;
                                                    case 13:
                                                        MainActivity mainActivity8 = mainActivity;
                                                        Intrinsics.checkNotNullParameter(mainActivity8, "<this>");
                                                        mainActivity8.getPrefs$android_release().edit().putBoolean("listenHq", !mainActivity8.getPrefs$android_release().getBoolean("listenHq", false)).apply();
                                                        Fleet.soundChanged(mainActivity8);
                                                        return;
                                                    case 14:
                                                        mainActivity.setFullscreen$android_release(true);
                                                        return;
                                                    case 15:
                                                        ArrayList arrayList = PipKt.hidden;
                                                        MainActivity mainActivity9 = mainActivity;
                                                        if (mainActivity9.floating) {
                                                            PipKt.unfloat(mainActivity9);
                                                            return;
                                                        } else {
                                                            if (PipKt.picLive(mainActivity9)) {
                                                                mainActivity9.floating = true;
                                                                PipKt.setFloat(1, mainActivity9);
                                                                TypingKt.layoutRemote(mainActivity9);
                                                                return;
                                                            }
                                                            return;
                                                        }
                                                    case 16:
                                                        MainActivity mainActivity10 = mainActivity;
                                                        if (mainActivity10.basic != null) {
                                                            mainActivity10.press$android_release(true, 26);
                                                            return;
                                                        }
                                                        Tv tv = mainActivity10.tv;
                                                        if (tv != null && tv.ready()) {
                                                            new Thread(new MainActivity$$ExternalSyntheticLambda38(tv, mainActivity10, i102)).start();
                                                            return;
                                                        }
                                                        return;
                                                    default:
                                                        MainActivity mainActivity11 = mainActivity;
                                                        String pref$android_release = mainActivity11.pref$android_release("talkMode");
                                                        if (pref$android_release.equals("quick")) {
                                                            mainActivity11.getTalk$android_release().open();
                                                            return;
                                                        } else if (pref$android_release.equals("old")) {
                                                            mainActivity11.speak$android_release();
                                                            return;
                                                        } else {
                                                            UiKt.menu(mainActivity11, Fleet.T("talk.choose_title", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_quick", new Pair[0])), Fleet.T("talk.mode_quick_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 21)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_old", new Pair[0])), Fleet.T("talk.mode_old_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 22))}));
                                                            return;
                                                        }
                                                }
                                            }
                                        });
                                        mainActivity.pipBtn = UiKt.icon(mainActivity, "@pip", Fleet.T("float.pip", new Pair[0]), UiKt.getBTN());
                                        final int i17 = 15;
                                        mainActivity.getPipBtn$android_release().setOnClickListener(new View.OnClickListener() { // from class: dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda0
                                            @Override // android.view.View.OnClickListener
                                            public final void onClick(View view2) {
                                                int i72 = 5;
                                                int i82 = 3;
                                                int i92 = 29;
                                                int i102 = 4;
                                                int i112 = 6;
                                                int i122 = 1;
                                                int i132 = 0;
                                                switch (i17) {
                                                    case 0:
                                                        mainActivity.toggleVideo$android_release();
                                                        return;
                                                    case 1:
                                                        Regex regex = AdbHelpKt.TV_HOME;
                                                        MainActivity mainActivity2 = mainActivity;
                                                        UiKt.menu(mainActivity2, Fleet.T("setup.turn_on_adb", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@zap|", Fleet.T("adb_help.automatic_install_tv_setup", new Pair[0])), Fleet.T("adb_help.just_confirm_on_the", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity2, 24)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@gear|", Fleet.T("adb_help.by_hand_open_tv", new Pair[0])), "", new TalkKt$$ExternalSyntheticLambda1(mainActivity2, 25)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@home|", Fleet.T("adb_help.install_another_home_screen", new Pair[0])), Fleet.T("adb_help.when_the_tv_hides", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity2, i92)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@wifi|", Fleet.T("setup.wireless_title", new Pair[0])), Fleet.T("adb_help.android_11_or_newer", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i132)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@refresh|", Fleet.T("adb_help.full_connection", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i82)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@store|", Fleet.T("adb_help.open_the_play_store", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i102)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@package|", Fleet.T("adb_help.open_an_app_by", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i72)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@link|", Fleet.T("setup.direct_title", new Pair[0])), Fleet.T("adb_help.a_fallback_not_reliable", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity2, i112))}));
                                                        return;
                                                    case 2:
                                                        TypingKt.setLive(mainActivity, !r1.live);
                                                        return;
                                                    case 3:
                                                        MainActivity mainActivity3 = mainActivity;
                                                        Intrinsics.checkNotNullParameter(mainActivity3, "<this>");
                                                        mainActivity3.getPrefs$android_release().edit().putBoolean("listenEven", !mainActivity3.getPrefs$android_release().getBoolean("listenEven", false)).apply();
                                                        Fleet.soundChanged(mainActivity3);
                                                        return;
                                                    case 4:
                                                        TypingKt.sendText(mainActivity);
                                                        return;
                                                    case 5:
                                                        mainActivity.onBackPressed();
                                                        return;
                                                    case 6:
                                                        mainActivity.leave$android_release();
                                                        return;
                                                    case 7:
                                                        Fleet.toggleListen(mainActivity);
                                                        return;
                                                    case 8:
                                                        MainActivity mainActivity4 = mainActivity;
                                                        TextView label = UiKt.label(mainActivity4, TypingKt.gainWords(TypingKt.listenGain(mainActivity4)), 17, -1);
                                                        label.setTypeface(Typeface.DEFAULT_BOLD);
                                                        label.setGravity(8388629);
                                                        SeekBar seekBar = new SeekBar(mainActivity4);
                                                        seekBar.setMax(19);
                                                        seekBar.setContentDescription(Fleet.T("listen.loudness", new Pair[0]));
                                                        Axml$$ExternalSyntheticLambda2 axml$$ExternalSyntheticLambda2 = new Axml$$ExternalSyntheticLambda2(11, mainActivity4, label);
                                                        seekBar.setProgress((int) ((TypingKt.listenGain(mainActivity4) - 0.5f) * 2));
                                                        seekBar.setOnSeekBarChangeListener(new PlayingBar.AnonymousClass5(i122, axml$$ExternalSyntheticLambda2));
                                                        LinearLayout linearLayout32 = new LinearLayout(mainActivity4);
                                                        linearLayout32.setGravity(16);
                                                        linearLayout32.addView(seekBar, new LinearLayout.LayoutParams(0, UiKt.dp(mainActivity4, 48), 1.0f));
                                                        linearLayout32.addView(label, new LinearLayout.LayoutParams(UiKt.dp(mainActivity4, 56), -2));
                                                        LinearLayout linearLayout22 = new LinearLayout(mainActivity4);
                                                        linearLayout22.setOrientation(1);
                                                        linearLayout22.addView(linearLayout32);
                                                        TextView label2 = UiKt.label(mainActivity4, Fleet.T("listen.boost_note", new Pair[0]), 14, UiKt.DIM);
                                                        LinearLayout.LayoutParams layoutParams22 = new LinearLayout.LayoutParams(-1, -2);
                                                        layoutParams22.topMargin = UiKt.dp(mainActivity4, 8);
                                                        linearLayout22.addView(label2, layoutParams22);
                                                        Popup.Builder builder = new Popup.Builder(mainActivity4);
                                                        builder.title = Fleet.T("remote_screen.loudness_on_the_phone_2", new Pair[0]);
                                                        builder.view = UiKt.inDialog(mainActivity4, linearLayout22);
                                                        builder.setNeutralButton(Fleet.T("listen.back_to_x1", new Pair[0]), null);
                                                        builder.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                                                        builder.show().getButton(-3).setOnClickListener(new Guard$$ExternalSyntheticLambda9(7, seekBar, axml$$ExternalSyntheticLambda2));
                                                        return;
                                                    case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                                                        MainActivity mainActivity5 = mainActivity;
                                                        Object systemService = mainActivity5.getSystemService("input_method");
                                                        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
                                                        ((InputMethodManager) systemService).hideSoftInputFromWindow(view2.getWindowToken(), 0);
                                                        if (!mainActivity5.needsAdb$android_release()) {
                                                            Managing.open$default(mainActivity5.getManaging$android_release(), mainActivity5.host, null, null, 6);
                                                            return;
                                                        }
                                                        return;
                                                    case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                                                        mainActivity.setFullscreen$android_release(false);
                                                        return;
                                                    case 11:
                                                        MainActivity mainActivity6 = mainActivity;
                                                        LinearLayout col2 = UiKt.col(mainActivity6);
                                                        LinearLayout linearLayout322 = new LinearLayout(mainActivity6);
                                                        LinearLayout linearLayout42 = new LinearLayout(mainActivity6);
                                                        LinearLayout linearLayout52 = new LinearLayout(mainActivity6);
                                                        LinearLayout linearLayout62 = new LinearLayout(mainActivity6);
                                                        TypingKt.qualityMenu$draw(mainActivity6, linearLayout322, linearLayout42, linearLayout52, linearLayout62);
                                                        col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.size", new Pair[0])));
                                                        col2.addView(linearLayout322, UiKt.gap(mainActivity6, 6));
                                                        col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.frames_per_second", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                                        col2.addView(linearLayout42, UiKt.gap(mainActivity6, 6));
                                                        col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.bit_rate_mbit_s", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                                        col2.addView(linearLayout52, UiKt.gap(mainActivity6, 6));
                                                        col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.encoder", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                                        col2.addView(linearLayout62, UiKt.gap(mainActivity6, 6));
                                                        Popup.Builder builder2 = new Popup.Builder(mainActivity6);
                                                        builder2.title = Fleet.T("remote_screen.picture_quality", new Pair[0]);
                                                        builder2.view = UiKt.inDialog(mainActivity6, col2);
                                                        builder2.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                                                        builder2.show();
                                                        return;
                                                    case FileClientSessionCache.MAX_SIZE /* 12 */:
                                                        final MainActivity mainActivity7 = mainActivity;
                                                        final boolean z = mainActivity7.getPrefs$android_release().getBoolean("listenShare", false);
                                                        PopupMenu popupMenu = new PopupMenu(mainActivity7, mainActivity7.getListenChip$android_release());
                                                        MenuItem add = popupMenu.getMenu().add(1, 0, 0, Fleet.T("listen.only_the_phone", new Pair[0]));
                                                        add.setIcon(TypingKt.listenArt(mainActivity7, false));
                                                        add.setChecked(!z);
                                                        MenuItem add2 = popupMenu.getMenu().add(1, 1, 1, Fleet.T("listen.tv_and_phone", new Pair[0]));
                                                        add2.setIcon(TypingKt.listenArt(mainActivity7, true));
                                                        add2.setChecked(z);
                                                        popupMenu.getMenu().setGroupCheckable(1, true, true);
                                                        if (Build.VERSION.SDK_INT >= 29) {
                                                            popupMenu.setForceShowIcon(true);
                                                        }
                                                        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: dev.tvremote.phone.media.ListenKt$$ExternalSyntheticLambda2
                                                            @Override // android.widget.PopupMenu.OnMenuItemClickListener
                                                            public final boolean onMenuItemClick(MenuItem menuItem) {
                                                                boolean z2;
                                                                boolean z3 = false;
                                                                if (menuItem.getItemId() == 1) {
                                                                    z2 = true;
                                                                } else {
                                                                    z2 = false;
                                                                }
                                                                if (z2 != z) {
                                                                    MainActivity mainActivity8 = mainActivity7;
                                                                    SharedPreferences.Editor edit = mainActivity8.getPrefs$android_release().edit();
                                                                    if (menuItem.getItemId() == 1) {
                                                                        z3 = true;
                                                                    }
                                                                    edit.putBoolean("listenShare", z3).apply();
                                                                    Fleet.soundChanged(mainActivity8);
                                                                }
                                                                return true;
                                                            }
                                                        });
                                                        popupMenu.show();
                                                        return;
                                                    case 13:
                                                        MainActivity mainActivity8 = mainActivity;
                                                        Intrinsics.checkNotNullParameter(mainActivity8, "<this>");
                                                        mainActivity8.getPrefs$android_release().edit().putBoolean("listenHq", !mainActivity8.getPrefs$android_release().getBoolean("listenHq", false)).apply();
                                                        Fleet.soundChanged(mainActivity8);
                                                        return;
                                                    case 14:
                                                        mainActivity.setFullscreen$android_release(true);
                                                        return;
                                                    case 15:
                                                        ArrayList arrayList = PipKt.hidden;
                                                        MainActivity mainActivity9 = mainActivity;
                                                        if (mainActivity9.floating) {
                                                            PipKt.unfloat(mainActivity9);
                                                            return;
                                                        } else {
                                                            if (PipKt.picLive(mainActivity9)) {
                                                                mainActivity9.floating = true;
                                                                PipKt.setFloat(1, mainActivity9);
                                                                TypingKt.layoutRemote(mainActivity9);
                                                                return;
                                                            }
                                                            return;
                                                        }
                                                    case 16:
                                                        MainActivity mainActivity10 = mainActivity;
                                                        if (mainActivity10.basic != null) {
                                                            mainActivity10.press$android_release(true, 26);
                                                            return;
                                                        }
                                                        Tv tv = mainActivity10.tv;
                                                        if (tv != null && tv.ready()) {
                                                            new Thread(new MainActivity$$ExternalSyntheticLambda38(tv, mainActivity10, i102)).start();
                                                            return;
                                                        }
                                                        return;
                                                    default:
                                                        MainActivity mainActivity11 = mainActivity;
                                                        String pref$android_release = mainActivity11.pref$android_release("talkMode");
                                                        if (pref$android_release.equals("quick")) {
                                                            mainActivity11.getTalk$android_release().open();
                                                            return;
                                                        } else if (pref$android_release.equals("old")) {
                                                            mainActivity11.speak$android_release();
                                                            return;
                                                        } else {
                                                            UiKt.menu(mainActivity11, Fleet.T("talk.choose_title", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_quick", new Pair[0])), Fleet.T("talk.mode_quick_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 21)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_old", new Pair[0])), Fleet.T("talk.mode_old_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 22))}));
                                                            return;
                                                        }
                                                }
                                            }
                                        });
                                        LinearLayout picBar$android_release2 = mainActivity.getPicBar$android_release();
                                        IconButton pipBtn$android_release = mainActivity.getPipBtn$android_release();
                                        LinearLayout.LayoutParams layoutParams11 = new LinearLayout.LayoutParams(UiKt.dp((Context) mainActivity, 44), UiKt.dp((Context) mainActivity, 34));
                                        layoutParams11.leftMargin = UiKt.dp((Context) mainActivity, 8);
                                        picBar$android_release2.addView(pipBtn$android_release, layoutParams11);
                                        LinearLayout picBar$android_release3 = mainActivity.getPicBar$android_release();
                                        IconButton iconButton6 = mainActivity.fullBtn;
                                        if (iconButton6 != null) {
                                            LinearLayout.LayoutParams layoutParams12 = new LinearLayout.LayoutParams(UiKt.dp((Context) mainActivity, 44), UiKt.dp((Context) mainActivity, 34));
                                            layoutParams12.leftMargin = UiKt.dp((Context) mainActivity, 8);
                                            picBar$android_release3.addView(iconButton6, layoutParams12);
                                            LinearLayout controls$android_release = mainActivity.getControls$android_release();
                                            LinearLayout soundBar$android_release4 = mainActivity.getSoundBar$android_release();
                                            LinearLayout.LayoutParams layoutParams13 = new LinearLayout.LayoutParams(-1, -2);
                                            layoutParams13.bottomMargin = UiKt.dp((Context) mainActivity, 12);
                                            controls$android_release.addView(soundBar$android_release4, layoutParams13);
                                            LinearLayout controls$android_release2 = mainActivity.getControls$android_release();
                                            LinearLayout picBar$android_release4 = mainActivity.getPicBar$android_release();
                                            LinearLayout.LayoutParams layoutParams14 = new LinearLayout.LayoutParams(-1, -2);
                                            layoutParams14.bottomMargin = UiKt.dp((Context) mainActivity, 12);
                                            controls$android_release2.addView(picBar$android_release4, layoutParams14);
                                            LinearLayout.LayoutParams layoutParams15 = new LinearLayout.LayoutParams(-1, UiKt.dp((Context) mainActivity, 44));
                                            layoutParams15.bottomMargin = UiKt.dp((Context) mainActivity, 12);
                                            LinearLayout controls$android_release3 = mainActivity.getControls$android_release();
                                            Button button7 = mainActivity.basicBar;
                                            if (button7 != null) {
                                                controls$android_release3.addView(button7, layoutParams15);
                                                mainActivity.setupBar = UiKt.button(mainActivity, "", UiKt.GREEN);
                                                mainActivity.getSetupBar$android_release().setTextSize(13.0f);
                                                mainActivity.setupClose = UiKt.icon(mainActivity, "@close", Fleet.T("setup_banner.no_thanks", new Pair[0]), UiKt.getBTN());
                                                LinearLayout linearLayout7 = new LinearLayout(mainActivity);
                                                linearLayout7.setGravity(16);
                                                linearLayout7.setVisibility(8);
                                                mainActivity.setupRow = linearLayout7;
                                                mainActivity.getSetupRow$android_release().addView(mainActivity.getSetupBar$android_release(), new LinearLayout.LayoutParams(0, UiKt.dp((Context) mainActivity, 44), 1.0f));
                                                LinearLayout setupRow$android_release = mainActivity.getSetupRow$android_release();
                                                IconButton iconButton7 = mainActivity.setupClose;
                                                if (iconButton7 != null) {
                                                    LinearLayout.LayoutParams layoutParams16 = new LinearLayout.LayoutParams(UiKt.dp((Context) mainActivity, 44), UiKt.dp((Context) mainActivity, 44));
                                                    layoutParams16.leftMargin = UiKt.dp((Context) mainActivity, 8);
                                                    setupRow$android_release.addView(iconButton7, layoutParams16);
                                                    LinearLayout controls$android_release4 = mainActivity.getControls$android_release();
                                                    LinearLayout setupRow$android_release2 = mainActivity.getSetupRow$android_release();
                                                    LinearLayout.LayoutParams layoutParams17 = new LinearLayout.LayoutParams(-1, -2);
                                                    layoutParams17.bottomMargin = UiKt.dp((Context) mainActivity, 12);
                                                    controls$android_release4.addView(setupRow$android_release2, layoutParams17);
                                                    mainActivity.playing = new PlayingBar(mainActivity);
                                                    LinearLayout controls$android_release5 = mainActivity.getControls$android_release();
                                                    PlayingBar playingBar = mainActivity.playing;
                                                    if (playingBar != null) {
                                                        LinearLayout linearLayout8 = playingBar.view;
                                                        LinearLayout.LayoutParams layoutParams18 = new LinearLayout.LayoutParams(-1, -2);
                                                        layoutParams18.bottomMargin = UiKt.dp((Context) mainActivity, 12);
                                                        controls$android_release5.addView(linearLayout8, layoutParams18);
                                                        mainActivity.nowApp = new NowApp(mainActivity);
                                                        KbdWatch kbdWatch = new KbdWatch(mainActivity);
                                                        MainActivity mainActivity2 = kbdWatch.a;
                                                        Handler handler = mainActivity2.ui;
                                                        NowApp$tick$1 nowApp$tick$1 = kbdWatch.tick;
                                                        handler.removeCallbacks(nowApp$tick$1);
                                                        mainActivity2.ui.post(nowApp$tick$1);
                                                        mainActivity.kbdWatch = kbdWatch;
                                                        LinearLayout controls$android_release6 = mainActivity.getControls$android_release();
                                                        NowApp nowApp = mainActivity.nowApp;
                                                        if (nowApp != null) {
                                                            LinearLayout linearLayout9 = nowApp.view;
                                                            LinearLayout.LayoutParams layoutParams19 = new LinearLayout.LayoutParams(-1, -2);
                                                            layoutParams19.bottomMargin = UiKt.dp((Context) mainActivity, 10);
                                                            controls$android_release6.addView(linearLayout9, layoutParams19);
                                                            LinearLayout linearLayout10 = new LinearLayout(mainActivity);
                                                            IconButton icon9 = UiKt.icon(mainActivity, "@power", Fleet.T("remote.power", new Pair[0]), UiKt.getBTN());
                                                            final int i18 = 16;
                                                            icon9.setOnClickListener(new View.OnClickListener() { // from class: dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda0
                                                                @Override // android.view.View.OnClickListener
                                                                public final void onClick(View view2) {
                                                                    int i72 = 5;
                                                                    int i82 = 3;
                                                                    int i92 = 29;
                                                                    int i102 = 4;
                                                                    int i112 = 6;
                                                                    int i122 = 1;
                                                                    int i132 = 0;
                                                                    switch (i18) {
                                                                        case 0:
                                                                            mainActivity.toggleVideo$android_release();
                                                                            return;
                                                                        case 1:
                                                                            Regex regex = AdbHelpKt.TV_HOME;
                                                                            MainActivity mainActivity22 = mainActivity;
                                                                            UiKt.menu(mainActivity22, Fleet.T("setup.turn_on_adb", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@zap|", Fleet.T("adb_help.automatic_install_tv_setup", new Pair[0])), Fleet.T("adb_help.just_confirm_on_the", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity22, 24)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@gear|", Fleet.T("adb_help.by_hand_open_tv", new Pair[0])), "", new TalkKt$$ExternalSyntheticLambda1(mainActivity22, 25)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@home|", Fleet.T("adb_help.install_another_home_screen", new Pair[0])), Fleet.T("adb_help.when_the_tv_hides", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity22, i92)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@wifi|", Fleet.T("setup.wireless_title", new Pair[0])), Fleet.T("adb_help.android_11_or_newer", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity22, i132)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@refresh|", Fleet.T("adb_help.full_connection", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity22, i82)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@store|", Fleet.T("adb_help.open_the_play_store", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity22, i102)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@package|", Fleet.T("adb_help.open_an_app_by", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity22, i72)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@link|", Fleet.T("setup.direct_title", new Pair[0])), Fleet.T("adb_help.a_fallback_not_reliable", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity22, i112))}));
                                                                            return;
                                                                        case 2:
                                                                            TypingKt.setLive(mainActivity, !r1.live);
                                                                            return;
                                                                        case 3:
                                                                            MainActivity mainActivity3 = mainActivity;
                                                                            Intrinsics.checkNotNullParameter(mainActivity3, "<this>");
                                                                            mainActivity3.getPrefs$android_release().edit().putBoolean("listenEven", !mainActivity3.getPrefs$android_release().getBoolean("listenEven", false)).apply();
                                                                            Fleet.soundChanged(mainActivity3);
                                                                            return;
                                                                        case 4:
                                                                            TypingKt.sendText(mainActivity);
                                                                            return;
                                                                        case 5:
                                                                            mainActivity.onBackPressed();
                                                                            return;
                                                                        case 6:
                                                                            mainActivity.leave$android_release();
                                                                            return;
                                                                        case 7:
                                                                            Fleet.toggleListen(mainActivity);
                                                                            return;
                                                                        case 8:
                                                                            MainActivity mainActivity4 = mainActivity;
                                                                            TextView label = UiKt.label(mainActivity4, TypingKt.gainWords(TypingKt.listenGain(mainActivity4)), 17, -1);
                                                                            label.setTypeface(Typeface.DEFAULT_BOLD);
                                                                            label.setGravity(8388629);
                                                                            SeekBar seekBar = new SeekBar(mainActivity4);
                                                                            seekBar.setMax(19);
                                                                            seekBar.setContentDescription(Fleet.T("listen.loudness", new Pair[0]));
                                                                            Axml$$ExternalSyntheticLambda2 axml$$ExternalSyntheticLambda2 = new Axml$$ExternalSyntheticLambda2(11, mainActivity4, label);
                                                                            seekBar.setProgress((int) ((TypingKt.listenGain(mainActivity4) - 0.5f) * 2));
                                                                            seekBar.setOnSeekBarChangeListener(new PlayingBar.AnonymousClass5(i122, axml$$ExternalSyntheticLambda2));
                                                                            LinearLayout linearLayout32 = new LinearLayout(mainActivity4);
                                                                            linearLayout32.setGravity(16);
                                                                            linearLayout32.addView(seekBar, new LinearLayout.LayoutParams(0, UiKt.dp(mainActivity4, 48), 1.0f));
                                                                            linearLayout32.addView(label, new LinearLayout.LayoutParams(UiKt.dp(mainActivity4, 56), -2));
                                                                            LinearLayout linearLayout22 = new LinearLayout(mainActivity4);
                                                                            linearLayout22.setOrientation(1);
                                                                            linearLayout22.addView(linearLayout32);
                                                                            TextView label2 = UiKt.label(mainActivity4, Fleet.T("listen.boost_note", new Pair[0]), 14, UiKt.DIM);
                                                                            LinearLayout.LayoutParams layoutParams22 = new LinearLayout.LayoutParams(-1, -2);
                                                                            layoutParams22.topMargin = UiKt.dp(mainActivity4, 8);
                                                                            linearLayout22.addView(label2, layoutParams22);
                                                                            Popup.Builder builder = new Popup.Builder(mainActivity4);
                                                                            builder.title = Fleet.T("remote_screen.loudness_on_the_phone_2", new Pair[0]);
                                                                            builder.view = UiKt.inDialog(mainActivity4, linearLayout22);
                                                                            builder.setNeutralButton(Fleet.T("listen.back_to_x1", new Pair[0]), null);
                                                                            builder.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                                                                            builder.show().getButton(-3).setOnClickListener(new Guard$$ExternalSyntheticLambda9(7, seekBar, axml$$ExternalSyntheticLambda2));
                                                                            return;
                                                                        case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                                                                            MainActivity mainActivity5 = mainActivity;
                                                                            Object systemService = mainActivity5.getSystemService("input_method");
                                                                            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
                                                                            ((InputMethodManager) systemService).hideSoftInputFromWindow(view2.getWindowToken(), 0);
                                                                            if (!mainActivity5.needsAdb$android_release()) {
                                                                                Managing.open$default(mainActivity5.getManaging$android_release(), mainActivity5.host, null, null, 6);
                                                                                return;
                                                                            }
                                                                            return;
                                                                        case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                                                                            mainActivity.setFullscreen$android_release(false);
                                                                            return;
                                                                        case 11:
                                                                            MainActivity mainActivity6 = mainActivity;
                                                                            LinearLayout col2 = UiKt.col(mainActivity6);
                                                                            LinearLayout linearLayout322 = new LinearLayout(mainActivity6);
                                                                            LinearLayout linearLayout42 = new LinearLayout(mainActivity6);
                                                                            LinearLayout linearLayout52 = new LinearLayout(mainActivity6);
                                                                            LinearLayout linearLayout62 = new LinearLayout(mainActivity6);
                                                                            TypingKt.qualityMenu$draw(mainActivity6, linearLayout322, linearLayout42, linearLayout52, linearLayout62);
                                                                            col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.size", new Pair[0])));
                                                                            col2.addView(linearLayout322, UiKt.gap(mainActivity6, 6));
                                                                            col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.frames_per_second", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                                                            col2.addView(linearLayout42, UiKt.gap(mainActivity6, 6));
                                                                            col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.bit_rate_mbit_s", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                                                            col2.addView(linearLayout52, UiKt.gap(mainActivity6, 6));
                                                                            col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.encoder", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                                                            col2.addView(linearLayout62, UiKt.gap(mainActivity6, 6));
                                                                            Popup.Builder builder2 = new Popup.Builder(mainActivity6);
                                                                            builder2.title = Fleet.T("remote_screen.picture_quality", new Pair[0]);
                                                                            builder2.view = UiKt.inDialog(mainActivity6, col2);
                                                                            builder2.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                                                                            builder2.show();
                                                                            return;
                                                                        case FileClientSessionCache.MAX_SIZE /* 12 */:
                                                                            final MainActivity mainActivity7 = mainActivity;
                                                                            final boolean z = mainActivity7.getPrefs$android_release().getBoolean("listenShare", false);
                                                                            PopupMenu popupMenu = new PopupMenu(mainActivity7, mainActivity7.getListenChip$android_release());
                                                                            MenuItem add = popupMenu.getMenu().add(1, 0, 0, Fleet.T("listen.only_the_phone", new Pair[0]));
                                                                            add.setIcon(TypingKt.listenArt(mainActivity7, false));
                                                                            add.setChecked(!z);
                                                                            MenuItem add2 = popupMenu.getMenu().add(1, 1, 1, Fleet.T("listen.tv_and_phone", new Pair[0]));
                                                                            add2.setIcon(TypingKt.listenArt(mainActivity7, true));
                                                                            add2.setChecked(z);
                                                                            popupMenu.getMenu().setGroupCheckable(1, true, true);
                                                                            if (Build.VERSION.SDK_INT >= 29) {
                                                                                popupMenu.setForceShowIcon(true);
                                                                            }
                                                                            popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: dev.tvremote.phone.media.ListenKt$$ExternalSyntheticLambda2
                                                                                @Override // android.widget.PopupMenu.OnMenuItemClickListener
                                                                                public final boolean onMenuItemClick(MenuItem menuItem) {
                                                                                    boolean z2;
                                                                                    boolean z3 = false;
                                                                                    if (menuItem.getItemId() == 1) {
                                                                                        z2 = true;
                                                                                    } else {
                                                                                        z2 = false;
                                                                                    }
                                                                                    if (z2 != z) {
                                                                                        MainActivity mainActivity8 = mainActivity7;
                                                                                        SharedPreferences.Editor edit = mainActivity8.getPrefs$android_release().edit();
                                                                                        if (menuItem.getItemId() == 1) {
                                                                                            z3 = true;
                                                                                        }
                                                                                        edit.putBoolean("listenShare", z3).apply();
                                                                                        Fleet.soundChanged(mainActivity8);
                                                                                    }
                                                                                    return true;
                                                                                }
                                                                            });
                                                                            popupMenu.show();
                                                                            return;
                                                                        case 13:
                                                                            MainActivity mainActivity8 = mainActivity;
                                                                            Intrinsics.checkNotNullParameter(mainActivity8, "<this>");
                                                                            mainActivity8.getPrefs$android_release().edit().putBoolean("listenHq", !mainActivity8.getPrefs$android_release().getBoolean("listenHq", false)).apply();
                                                                            Fleet.soundChanged(mainActivity8);
                                                                            return;
                                                                        case 14:
                                                                            mainActivity.setFullscreen$android_release(true);
                                                                            return;
                                                                        case 15:
                                                                            ArrayList arrayList = PipKt.hidden;
                                                                            MainActivity mainActivity9 = mainActivity;
                                                                            if (mainActivity9.floating) {
                                                                                PipKt.unfloat(mainActivity9);
                                                                                return;
                                                                            } else {
                                                                                if (PipKt.picLive(mainActivity9)) {
                                                                                    mainActivity9.floating = true;
                                                                                    PipKt.setFloat(1, mainActivity9);
                                                                                    TypingKt.layoutRemote(mainActivity9);
                                                                                    return;
                                                                                }
                                                                                return;
                                                                            }
                                                                        case 16:
                                                                            MainActivity mainActivity10 = mainActivity;
                                                                            if (mainActivity10.basic != null) {
                                                                                mainActivity10.press$android_release(true, 26);
                                                                                return;
                                                                            }
                                                                            Tv tv = mainActivity10.tv;
                                                                            if (tv != null && tv.ready()) {
                                                                                new Thread(new MainActivity$$ExternalSyntheticLambda38(tv, mainActivity10, i102)).start();
                                                                                return;
                                                                            }
                                                                            return;
                                                                        default:
                                                                            MainActivity mainActivity11 = mainActivity;
                                                                            String pref$android_release = mainActivity11.pref$android_release("talkMode");
                                                                            if (pref$android_release.equals("quick")) {
                                                                                mainActivity11.getTalk$android_release().open();
                                                                                return;
                                                                            } else if (pref$android_release.equals("old")) {
                                                                                mainActivity11.speak$android_release();
                                                                                return;
                                                                            } else {
                                                                                UiKt.menu(mainActivity11, Fleet.T("talk.choose_title", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_quick", new Pair[0])), Fleet.T("talk.mode_quick_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 21)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_old", new Pair[0])), Fleet.T("talk.mode_old_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 22))}));
                                                                                return;
                                                                            }
                                                                    }
                                                                }
                                                            });
                                                            linearLayout10.addView(icon9, UiKt.cell(58, mainActivity, false));
                                                            IconButton icon10 = UiKt.icon(mainActivity, "@mic", Fleet.T("remote.speak", new Pair[0]), UiKt.getBTN());
                                                            final int i19 = 17;
                                                            icon10.setOnClickListener(new View.OnClickListener() { // from class: dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda0
                                                                @Override // android.view.View.OnClickListener
                                                                public final void onClick(View view2) {
                                                                    int i72 = 5;
                                                                    int i82 = 3;
                                                                    int i92 = 29;
                                                                    int i102 = 4;
                                                                    int i112 = 6;
                                                                    int i122 = 1;
                                                                    int i132 = 0;
                                                                    switch (i19) {
                                                                        case 0:
                                                                            mainActivity.toggleVideo$android_release();
                                                                            return;
                                                                        case 1:
                                                                            Regex regex = AdbHelpKt.TV_HOME;
                                                                            MainActivity mainActivity22 = mainActivity;
                                                                            UiKt.menu(mainActivity22, Fleet.T("setup.turn_on_adb", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@zap|", Fleet.T("adb_help.automatic_install_tv_setup", new Pair[0])), Fleet.T("adb_help.just_confirm_on_the", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity22, 24)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@gear|", Fleet.T("adb_help.by_hand_open_tv", new Pair[0])), "", new TalkKt$$ExternalSyntheticLambda1(mainActivity22, 25)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@home|", Fleet.T("adb_help.install_another_home_screen", new Pair[0])), Fleet.T("adb_help.when_the_tv_hides", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity22, i92)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@wifi|", Fleet.T("setup.wireless_title", new Pair[0])), Fleet.T("adb_help.android_11_or_newer", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity22, i132)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@refresh|", Fleet.T("adb_help.full_connection", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity22, i82)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@store|", Fleet.T("adb_help.open_the_play_store", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity22, i102)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@package|", Fleet.T("adb_help.open_an_app_by", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity22, i72)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@link|", Fleet.T("setup.direct_title", new Pair[0])), Fleet.T("adb_help.a_fallback_not_reliable", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity22, i112))}));
                                                                            return;
                                                                        case 2:
                                                                            TypingKt.setLive(mainActivity, !r1.live);
                                                                            return;
                                                                        case 3:
                                                                            MainActivity mainActivity3 = mainActivity;
                                                                            Intrinsics.checkNotNullParameter(mainActivity3, "<this>");
                                                                            mainActivity3.getPrefs$android_release().edit().putBoolean("listenEven", !mainActivity3.getPrefs$android_release().getBoolean("listenEven", false)).apply();
                                                                            Fleet.soundChanged(mainActivity3);
                                                                            return;
                                                                        case 4:
                                                                            TypingKt.sendText(mainActivity);
                                                                            return;
                                                                        case 5:
                                                                            mainActivity.onBackPressed();
                                                                            return;
                                                                        case 6:
                                                                            mainActivity.leave$android_release();
                                                                            return;
                                                                        case 7:
                                                                            Fleet.toggleListen(mainActivity);
                                                                            return;
                                                                        case 8:
                                                                            MainActivity mainActivity4 = mainActivity;
                                                                            TextView label = UiKt.label(mainActivity4, TypingKt.gainWords(TypingKt.listenGain(mainActivity4)), 17, -1);
                                                                            label.setTypeface(Typeface.DEFAULT_BOLD);
                                                                            label.setGravity(8388629);
                                                                            SeekBar seekBar = new SeekBar(mainActivity4);
                                                                            seekBar.setMax(19);
                                                                            seekBar.setContentDescription(Fleet.T("listen.loudness", new Pair[0]));
                                                                            Axml$$ExternalSyntheticLambda2 axml$$ExternalSyntheticLambda2 = new Axml$$ExternalSyntheticLambda2(11, mainActivity4, label);
                                                                            seekBar.setProgress((int) ((TypingKt.listenGain(mainActivity4) - 0.5f) * 2));
                                                                            seekBar.setOnSeekBarChangeListener(new PlayingBar.AnonymousClass5(i122, axml$$ExternalSyntheticLambda2));
                                                                            LinearLayout linearLayout32 = new LinearLayout(mainActivity4);
                                                                            linearLayout32.setGravity(16);
                                                                            linearLayout32.addView(seekBar, new LinearLayout.LayoutParams(0, UiKt.dp(mainActivity4, 48), 1.0f));
                                                                            linearLayout32.addView(label, new LinearLayout.LayoutParams(UiKt.dp(mainActivity4, 56), -2));
                                                                            LinearLayout linearLayout22 = new LinearLayout(mainActivity4);
                                                                            linearLayout22.setOrientation(1);
                                                                            linearLayout22.addView(linearLayout32);
                                                                            TextView label2 = UiKt.label(mainActivity4, Fleet.T("listen.boost_note", new Pair[0]), 14, UiKt.DIM);
                                                                            LinearLayout.LayoutParams layoutParams22 = new LinearLayout.LayoutParams(-1, -2);
                                                                            layoutParams22.topMargin = UiKt.dp(mainActivity4, 8);
                                                                            linearLayout22.addView(label2, layoutParams22);
                                                                            Popup.Builder builder = new Popup.Builder(mainActivity4);
                                                                            builder.title = Fleet.T("remote_screen.loudness_on_the_phone_2", new Pair[0]);
                                                                            builder.view = UiKt.inDialog(mainActivity4, linearLayout22);
                                                                            builder.setNeutralButton(Fleet.T("listen.back_to_x1", new Pair[0]), null);
                                                                            builder.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                                                                            builder.show().getButton(-3).setOnClickListener(new Guard$$ExternalSyntheticLambda9(7, seekBar, axml$$ExternalSyntheticLambda2));
                                                                            return;
                                                                        case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                                                                            MainActivity mainActivity5 = mainActivity;
                                                                            Object systemService = mainActivity5.getSystemService("input_method");
                                                                            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
                                                                            ((InputMethodManager) systemService).hideSoftInputFromWindow(view2.getWindowToken(), 0);
                                                                            if (!mainActivity5.needsAdb$android_release()) {
                                                                                Managing.open$default(mainActivity5.getManaging$android_release(), mainActivity5.host, null, null, 6);
                                                                                return;
                                                                            }
                                                                            return;
                                                                        case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                                                                            mainActivity.setFullscreen$android_release(false);
                                                                            return;
                                                                        case 11:
                                                                            MainActivity mainActivity6 = mainActivity;
                                                                            LinearLayout col2 = UiKt.col(mainActivity6);
                                                                            LinearLayout linearLayout322 = new LinearLayout(mainActivity6);
                                                                            LinearLayout linearLayout42 = new LinearLayout(mainActivity6);
                                                                            LinearLayout linearLayout52 = new LinearLayout(mainActivity6);
                                                                            LinearLayout linearLayout62 = new LinearLayout(mainActivity6);
                                                                            TypingKt.qualityMenu$draw(mainActivity6, linearLayout322, linearLayout42, linearLayout52, linearLayout62);
                                                                            col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.size", new Pair[0])));
                                                                            col2.addView(linearLayout322, UiKt.gap(mainActivity6, 6));
                                                                            col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.frames_per_second", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                                                            col2.addView(linearLayout42, UiKt.gap(mainActivity6, 6));
                                                                            col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.bit_rate_mbit_s", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                                                            col2.addView(linearLayout52, UiKt.gap(mainActivity6, 6));
                                                                            col2.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.encoder", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                                                            col2.addView(linearLayout62, UiKt.gap(mainActivity6, 6));
                                                                            Popup.Builder builder2 = new Popup.Builder(mainActivity6);
                                                                            builder2.title = Fleet.T("remote_screen.picture_quality", new Pair[0]);
                                                                            builder2.view = UiKt.inDialog(mainActivity6, col2);
                                                                            builder2.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                                                                            builder2.show();
                                                                            return;
                                                                        case FileClientSessionCache.MAX_SIZE /* 12 */:
                                                                            final MainActivity mainActivity7 = mainActivity;
                                                                            final boolean z = mainActivity7.getPrefs$android_release().getBoolean("listenShare", false);
                                                                            PopupMenu popupMenu = new PopupMenu(mainActivity7, mainActivity7.getListenChip$android_release());
                                                                            MenuItem add = popupMenu.getMenu().add(1, 0, 0, Fleet.T("listen.only_the_phone", new Pair[0]));
                                                                            add.setIcon(TypingKt.listenArt(mainActivity7, false));
                                                                            add.setChecked(!z);
                                                                            MenuItem add2 = popupMenu.getMenu().add(1, 1, 1, Fleet.T("listen.tv_and_phone", new Pair[0]));
                                                                            add2.setIcon(TypingKt.listenArt(mainActivity7, true));
                                                                            add2.setChecked(z);
                                                                            popupMenu.getMenu().setGroupCheckable(1, true, true);
                                                                            if (Build.VERSION.SDK_INT >= 29) {
                                                                                popupMenu.setForceShowIcon(true);
                                                                            }
                                                                            popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: dev.tvremote.phone.media.ListenKt$$ExternalSyntheticLambda2
                                                                                @Override // android.widget.PopupMenu.OnMenuItemClickListener
                                                                                public final boolean onMenuItemClick(MenuItem menuItem) {
                                                                                    boolean z2;
                                                                                    boolean z3 = false;
                                                                                    if (menuItem.getItemId() == 1) {
                                                                                        z2 = true;
                                                                                    } else {
                                                                                        z2 = false;
                                                                                    }
                                                                                    if (z2 != z) {
                                                                                        MainActivity mainActivity8 = mainActivity7;
                                                                                        SharedPreferences.Editor edit = mainActivity8.getPrefs$android_release().edit();
                                                                                        if (menuItem.getItemId() == 1) {
                                                                                            z3 = true;
                                                                                        }
                                                                                        edit.putBoolean("listenShare", z3).apply();
                                                                                        Fleet.soundChanged(mainActivity8);
                                                                                    }
                                                                                    return true;
                                                                                }
                                                                            });
                                                                            popupMenu.show();
                                                                            return;
                                                                        case 13:
                                                                            MainActivity mainActivity8 = mainActivity;
                                                                            Intrinsics.checkNotNullParameter(mainActivity8, "<this>");
                                                                            mainActivity8.getPrefs$android_release().edit().putBoolean("listenHq", !mainActivity8.getPrefs$android_release().getBoolean("listenHq", false)).apply();
                                                                            Fleet.soundChanged(mainActivity8);
                                                                            return;
                                                                        case 14:
                                                                            mainActivity.setFullscreen$android_release(true);
                                                                            return;
                                                                        case 15:
                                                                            ArrayList arrayList = PipKt.hidden;
                                                                            MainActivity mainActivity9 = mainActivity;
                                                                            if (mainActivity9.floating) {
                                                                                PipKt.unfloat(mainActivity9);
                                                                                return;
                                                                            } else {
                                                                                if (PipKt.picLive(mainActivity9)) {
                                                                                    mainActivity9.floating = true;
                                                                                    PipKt.setFloat(1, mainActivity9);
                                                                                    TypingKt.layoutRemote(mainActivity9);
                                                                                    return;
                                                                                }
                                                                                return;
                                                                            }
                                                                        case 16:
                                                                            MainActivity mainActivity10 = mainActivity;
                                                                            if (mainActivity10.basic != null) {
                                                                                mainActivity10.press$android_release(true, 26);
                                                                                return;
                                                                            }
                                                                            Tv tv = mainActivity10.tv;
                                                                            if (tv != null && tv.ready()) {
                                                                                new Thread(new MainActivity$$ExternalSyntheticLambda38(tv, mainActivity10, i102)).start();
                                                                                return;
                                                                            }
                                                                            return;
                                                                        default:
                                                                            MainActivity mainActivity11 = mainActivity;
                                                                            String pref$android_release = mainActivity11.pref$android_release("talkMode");
                                                                            if (pref$android_release.equals("quick")) {
                                                                                mainActivity11.getTalk$android_release().open();
                                                                                return;
                                                                            } else if (pref$android_release.equals("old")) {
                                                                                mainActivity11.speak$android_release();
                                                                                return;
                                                                            } else {
                                                                                UiKt.menu(mainActivity11, Fleet.T("talk.choose_title", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_quick", new Pair[0])), Fleet.T("talk.mode_quick_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 21)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_old", new Pair[0])), Fleet.T("talk.mode_old_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 22))}));
                                                                                return;
                                                                            }
                                                                    }
                                                                }
                                                            });
                                                            icon10.setOnLongClickListener(new PickerScreenKt$$ExternalSyntheticLambda4(1, mainActivity));
                                                            linearLayout10.addView(icon10, UiKt.cell(58, mainActivity, true));
                                                            IconButton icon11 = UiKt.icon(mainActivity, "@keyboard", Fleet.T("rkey.keyboard", new Pair[0]), UiKt.getBTN());
                                                            linearLayout10.addView(icon11, UiKt.cell(58, mainActivity, true));
                                                            IconButton icon12 = UiKt.icon(mainActivity, "@more", Fleet.T("remote.more_keys", new Pair[0]), UiKt.getBTN());
                                                            linearLayout10.addView(icon12, UiKt.cell(58, mainActivity, true));
                                                            LinearLayout controls$android_release7 = mainActivity.getControls$android_release();
                                                            captioned(mainActivity, linearLayout10);
                                                            controls$android_release7.addView(linearLayout10);
                                                            icon12.setCaption(Fleet.T("remote.more", new Pair[0]));
                                                            LinearLayout col2 = UiKt.col(mainActivity);
                                                            Object obj2 = ((LinkedHashMap) PhoneRemoteKt.remoteSpec(mainActivity).link).get("more");
                                                            Intrinsics.checkNotNull(obj2);
                                                            int size = ((Collection) obj2).size();
                                                            for (int i20 = 0; i20 < size; i20++) {
                                                                col2.addView(PhoneRemoteKt.remoteRow(mainActivity, "more", i20, 58, 4), UiKt.gap(mainActivity, 8));
                                                            }
                                                            LinearLayout col3 = UiKt.col(mainActivity);
                                                            Object systemService = mainActivity.getSystemService("input_method");
                                                            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
                                                            InputMethodManager inputMethodManager = (InputMethodManager) systemService;
                                                            ApkSigningBlockUtils$$ExternalSyntheticLambda0 apkSigningBlockUtils$$ExternalSyntheticLambda0 = new ApkSigningBlockUtils$$ExternalSyntheticLambda0(mainActivity, inputMethodManager);
                                                            RemoteScreenKt$$ExternalSyntheticLambda9 remoteScreenKt$$ExternalSyntheticLambda9 = new RemoteScreenKt$$ExternalSyntheticLambda9(apkSigningBlockUtils$$ExternalSyntheticLambda0, col3, icon11, col2, icon12, 0);
                                                            RemoteScreenKt$$ExternalSyntheticLambda9 remoteScreenKt$$ExternalSyntheticLambda92 = new RemoteScreenKt$$ExternalSyntheticLambda9(apkSigningBlockUtils$$ExternalSyntheticLambda0, col2, icon12, col3, icon11, 1);
                                                            mainActivity.getPrefs$android_release().edit().remove("kbd").apply();
                                                            Object obj3 = Boolean.FALSE;
                                                            apkSigningBlockUtils$$ExternalSyntheticLambda0.invoke(col3, icon11, "kbd", obj3);
                                                            remoteScreenKt$$ExternalSyntheticLambda9.invoke(Boolean.valueOf(mainActivity.getPrefs$android_release().getBoolean("more", false)));
                                                            icon12.setOnClickListener(new Guard$$ExternalSyntheticLambda7(mainActivity, remoteScreenKt$$ExternalSyntheticLambda9, col2, 7));
                                                            IrRemoteKt$$ExternalSyntheticLambda22 irRemoteKt$$ExternalSyntheticLambda22 = new IrRemoteKt$$ExternalSyntheticLambda22(col3, mainActivity, remoteScreenKt$$ExternalSyntheticLambda92, inputMethodManager, 3);
                                                            icon11.setOnClickListener(new ManyTvsKt$$ExternalSyntheticLambda40(col3, irRemoteKt$$ExternalSyntheticLambda22, mainActivity, remoteScreenKt$$ExternalSyntheticLambda92));
                                                            mainActivity.kbdOpen = new IrRemoteKt$$ExternalSyntheticLambda22(irRemoteKt$$ExternalSyntheticLambda22, mainActivity, col3, remoteScreenKt$$ExternalSyntheticLambda92, 4);
                                                            mainActivity.getControls$android_release().addView(col2);
                                                            mainActivity.getControls$android_release().addView(col3);
                                                            FrameLayout frameLayout2 = new FrameLayout(mainActivity);
                                                            frameLayout2.setBackground(UiKt.oval(mainActivity, UiKt.CARD));
                                                            int[][] iArr = {new int[]{19, 49}, new int[]{20, 81}, new int[]{21, 8388627}, new int[]{22, 8388629}};
                                                            String[] strArr = {"@up", "@down", "@left", "@right"};
                                                            int i21 = 0;
                                                            String[] strArr2 = {Fleet.T("remote.up", new Pair[0]), Fleet.T("remote.down", new Pair[0]), Fleet.T("remote.left", new Pair[0]), Fleet.T("remote.right", new Pair[0])};
                                                            int i22 = 0;
                                                            while (i22 < 4) {
                                                                IconButton icon13 = UiKt.icon(mainActivity, strArr[i22], strArr2[i22], i21);
                                                                icon13.setIcon(strArr[i22], UiKt.MUTED);
                                                                icon13.setSize(26.0f);
                                                                icon13.setBackground(UiKt.oval(mainActivity, i21));
                                                                bindKey(iArr[i22][i21], UiKt.oval(mainActivity, UiKt.HELD), icon13, mainActivity);
                                                                float f10 = 72;
                                                                FrameLayout.LayoutParams layoutParams20 = new FrameLayout.LayoutParams(UiKt.dp(mainActivity, f10), UiKt.dp(mainActivity, f10), iArr[i22][1]);
                                                                float f11 = 4;
                                                                layoutParams20.setMargins(UiKt.dp(mainActivity, f11), UiKt.dp(mainActivity, f11), UiKt.dp(mainActivity, f11), UiKt.dp(mainActivity, f11));
                                                                frameLayout2.addView(icon13, layoutParams20);
                                                                i22++;
                                                                i21 = 0;
                                                            }
                                                            Button button8 = UiKt.button(mainActivity, "OK", UiKt.ACCENT);
                                                            button8.setTypeface(Typeface.DEFAULT_BOLD);
                                                            button8.setTextSize(18.0f);
                                                            button8.setPadding(0, 0, 0, 0);
                                                            button8.setBackground(UiKt.oval(mainActivity, UiKt.ACCENT));
                                                            button8.setElevation(UiKt.dp(mainActivity, 6));
                                                            bindKey(23, UiKt.oval(mainActivity, UiKt.HELD), button8, mainActivity);
                                                            float f12 = 84;
                                                            frameLayout2.addView(button8, new FrameLayout.LayoutParams(UiKt.dp(mainActivity, f12), UiKt.dp(mainActivity, f12), 17));
                                                            LinearLayout linearLayout11 = new LinearLayout(mainActivity);
                                                            linearLayout11.setGravity(17);
                                                            float f13 = 216;
                                                            linearLayout11.addView(frameLayout2, new LinearLayout.LayoutParams(UiKt.dp(mainActivity, f13), UiKt.dp(mainActivity, f13)));
                                                            FrameLayout frameLayout3 = touchpad(mainActivity);
                                                            FrameLayout airPad = Air.airPad(mainActivity);
                                                            String str2 = "arrows";
                                                            List listOf = CollectionsKt__CollectionsKt.listOf((Object[]) new Pair[]{new Pair("arrows", ApkSigner$$ExternalSyntheticOutline0.m("@move|", Fleet.T("remote_screen.mid_arrows", new Pair[0]))), new Pair("touch", ApkSigner$$ExternalSyntheticOutline0.m("@hand|", Fleet.T("remote_screen.mid_touch", new Pair[0]))), new Pair("mouse", ApkSigner$$ExternalSyntheticOutline0.m("@mouse|", Fleet.T("rkey.air", new Pair[0])))});
                                                            Button button9 = UiKt.button(mainActivity, (String) ((Pair) listOf.get(0)).second, UiKt.getBTN());
                                                            button9.setTextSize(13.0f);
                                                            button9.setPadding(UiKt.dp((Context) mainActivity, 12), 0, UiKt.dp((Context) mainActivity, 12), 0);
                                                            button9.setMinHeight(0);
                                                            button9.setMinimumHeight(0);
                                                            RemoteScreenKt$$ExternalSyntheticLambda16 remoteScreenKt$$ExternalSyntheticLambda16 = new RemoteScreenKt$$ExternalSyntheticLambda16(linearLayout11, frameLayout3, airPad, button9, listOf, mainActivity);
                                                            Air.airPick = new Words$$ExternalSyntheticLambda1(19, remoteScreenKt$$ExternalSyntheticLambda16);
                                                            String string = mainActivity.getPrefs$android_release().getString("mid", null);
                                                            if (string == null) {
                                                                if (mainActivity.getPrefs$android_release().getBoolean("pad", false)) {
                                                                    str2 = "touch";
                                                                }
                                                            } else {
                                                                str2 = string;
                                                            }
                                                            remoteScreenKt$$ExternalSyntheticLambda16.invoke(str2, obj3);
                                                            button9.setOnClickListener(new Guard$$ExternalSyntheticLambda7(mainActivity, listOf, remoteScreenKt$$ExternalSyntheticLambda16, 8));
                                                            mainActivity.getControls$android_release().addView(linearLayout11, UiKt.gap(mainActivity, 16));
                                                            LinearLayout controls$android_release8 = mainActivity.getControls$android_release();
                                                            LinearLayout.LayoutParams layoutParams21 = new LinearLayout.LayoutParams(-1, UiKt.dp((Context) mainActivity, 250));
                                                            layoutParams21.topMargin = UiKt.dp((Context) mainActivity, 16);
                                                            controls$android_release8.addView(frameLayout3, layoutParams21);
                                                            LinearLayout controls$android_release9 = mainActivity.getControls$android_release();
                                                            LinearLayout.LayoutParams layoutParams22 = new LinearLayout.LayoutParams(-1, UiKt.dp((Context) mainActivity, 280));
                                                            layoutParams22.topMargin = UiKt.dp((Context) mainActivity, 16);
                                                            controls$android_release9.addView(airPad, layoutParams22);
                                                            LinearLayout linearLayout12 = new LinearLayout(mainActivity);
                                                            linearLayout12.addView(button9, new LinearLayout.LayoutParams(-2, UiKt.dp((Context) mainActivity, 36)));
                                                            LinearLayout.LayoutParams layoutParams23 = new LinearLayout.LayoutParams(-2, -2);
                                                            layoutParams23.gravity = 1;
                                                            layoutParams23.topMargin = UiKt.dp((Context) mainActivity, 8);
                                                            mainActivity.getControls$android_release().addView(linearLayout12, layoutParams23);
                                                            mainActivity.getControls$android_release().addView(PhoneRemoteKt.remoteRow(mainActivity, "nav", 0, 52, 0), UiKt.gap(mainActivity, 10));
                                                            LinearLayout col4 = UiKt.col(mainActivity);
                                                            Object obj4 = ((LinkedHashMap) PhoneRemoteKt.remoteSpec(mainActivity).link).get("media");
                                                            Intrinsics.checkNotNull(obj4);
                                                            int size2 = ((Collection) obj4).size();
                                                            for (int i23 = 0; i23 < size2; i23++) {
                                                                LinearLayout remoteRow = PhoneRemoteKt.remoteRow(mainActivity, "media", i23, 58, 0);
                                                                if (i23 == 0) {
                                                                    col4.addView(remoteRow);
                                                                } else {
                                                                    col4.addView(remoteRow, UiKt.gap(mainActivity, 8));
                                                                }
                                                            }
                                                            LinearLayout linearLayout13 = new LinearLayout(mainActivity);
                                                            linearLayout13.addView(pill(mainActivity, "Vol", "@plus", 24, Fleet.T("remote.volume_up", new Pair[0]), "@minus", 25, Fleet.T("remote.volume_down", new Pair[0])), new LinearLayout.LayoutParams(0, -1, 1.0f));
                                                            LinearLayout.LayoutParams layoutParams24 = new LinearLayout.LayoutParams(0, -2, 2.4f);
                                                            layoutParams24.leftMargin = UiKt.dp((Context) mainActivity, 10);
                                                            layoutParams24.rightMargin = UiKt.dp((Context) mainActivity, 10);
                                                            linearLayout13.addView(col4, layoutParams24);
                                                            linearLayout13.addView(pill(mainActivity, Fleet.T("remote.ch_2", new Pair[0]), "@up", 166, Fleet.T("remote_screen.channel_up", new Pair[0]), "@down", 167, Fleet.T("remote_screen.channel_down", new Pair[0])), new LinearLayout.LayoutParams(0, -1, 1.0f));
                                                            mainActivity.getControls$android_release().addView(linearLayout13, UiKt.gap(mainActivity, 16));
                                                            LinearLayout linearLayout14 = new LinearLayout(mainActivity);
                                                            mainActivity.liveBtn = UiKt.icon(mainActivity, "@zap", Fleet.T("remote_screen.live_typing", new Pair[0]), UiKt.getBTN());
                                                            mainActivity.getLiveBtn$android_release().setPadding(0, 0, 0, 0);
                                                            final int i24 = 2;
                                                            mainActivity.getLiveBtn$android_release().setOnClickListener(new View.OnClickListener() { // from class: dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda0
                                                                @Override // android.view.View.OnClickListener
                                                                public final void onClick(View view2) {
                                                                    int i72 = 5;
                                                                    int i82 = 3;
                                                                    int i92 = 29;
                                                                    int i102 = 4;
                                                                    int i112 = 6;
                                                                    int i122 = 1;
                                                                    int i132 = 0;
                                                                    switch (i24) {
                                                                        case 0:
                                                                            mainActivity.toggleVideo$android_release();
                                                                            return;
                                                                        case 1:
                                                                            Regex regex = AdbHelpKt.TV_HOME;
                                                                            MainActivity mainActivity22 = mainActivity;
                                                                            UiKt.menu(mainActivity22, Fleet.T("setup.turn_on_adb", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@zap|", Fleet.T("adb_help.automatic_install_tv_setup", new Pair[0])), Fleet.T("adb_help.just_confirm_on_the", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity22, 24)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@gear|", Fleet.T("adb_help.by_hand_open_tv", new Pair[0])), "", new TalkKt$$ExternalSyntheticLambda1(mainActivity22, 25)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@home|", Fleet.T("adb_help.install_another_home_screen", new Pair[0])), Fleet.T("adb_help.when_the_tv_hides", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity22, i92)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@wifi|", Fleet.T("setup.wireless_title", new Pair[0])), Fleet.T("adb_help.android_11_or_newer", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity22, i132)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@refresh|", Fleet.T("adb_help.full_connection", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity22, i82)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@store|", Fleet.T("adb_help.open_the_play_store", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity22, i102)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@package|", Fleet.T("adb_help.open_an_app_by", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity22, i72)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@link|", Fleet.T("setup.direct_title", new Pair[0])), Fleet.T("adb_help.a_fallback_not_reliable", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity22, i112))}));
                                                                            return;
                                                                        case 2:
                                                                            TypingKt.setLive(mainActivity, !r1.live);
                                                                            return;
                                                                        case 3:
                                                                            MainActivity mainActivity3 = mainActivity;
                                                                            Intrinsics.checkNotNullParameter(mainActivity3, "<this>");
                                                                            mainActivity3.getPrefs$android_release().edit().putBoolean("listenEven", !mainActivity3.getPrefs$android_release().getBoolean("listenEven", false)).apply();
                                                                            Fleet.soundChanged(mainActivity3);
                                                                            return;
                                                                        case 4:
                                                                            TypingKt.sendText(mainActivity);
                                                                            return;
                                                                        case 5:
                                                                            mainActivity.onBackPressed();
                                                                            return;
                                                                        case 6:
                                                                            mainActivity.leave$android_release();
                                                                            return;
                                                                        case 7:
                                                                            Fleet.toggleListen(mainActivity);
                                                                            return;
                                                                        case 8:
                                                                            MainActivity mainActivity4 = mainActivity;
                                                                            TextView label = UiKt.label(mainActivity4, TypingKt.gainWords(TypingKt.listenGain(mainActivity4)), 17, -1);
                                                                            label.setTypeface(Typeface.DEFAULT_BOLD);
                                                                            label.setGravity(8388629);
                                                                            SeekBar seekBar = new SeekBar(mainActivity4);
                                                                            seekBar.setMax(19);
                                                                            seekBar.setContentDescription(Fleet.T("listen.loudness", new Pair[0]));
                                                                            Axml$$ExternalSyntheticLambda2 axml$$ExternalSyntheticLambda2 = new Axml$$ExternalSyntheticLambda2(11, mainActivity4, label);
                                                                            seekBar.setProgress((int) ((TypingKt.listenGain(mainActivity4) - 0.5f) * 2));
                                                                            seekBar.setOnSeekBarChangeListener(new PlayingBar.AnonymousClass5(i122, axml$$ExternalSyntheticLambda2));
                                                                            LinearLayout linearLayout32 = new LinearLayout(mainActivity4);
                                                                            linearLayout32.setGravity(16);
                                                                            linearLayout32.addView(seekBar, new LinearLayout.LayoutParams(0, UiKt.dp(mainActivity4, 48), 1.0f));
                                                                            linearLayout32.addView(label, new LinearLayout.LayoutParams(UiKt.dp(mainActivity4, 56), -2));
                                                                            LinearLayout linearLayout22 = new LinearLayout(mainActivity4);
                                                                            linearLayout22.setOrientation(1);
                                                                            linearLayout22.addView(linearLayout32);
                                                                            TextView label2 = UiKt.label(mainActivity4, Fleet.T("listen.boost_note", new Pair[0]), 14, UiKt.DIM);
                                                                            LinearLayout.LayoutParams layoutParams222 = new LinearLayout.LayoutParams(-1, -2);
                                                                            layoutParams222.topMargin = UiKt.dp(mainActivity4, 8);
                                                                            linearLayout22.addView(label2, layoutParams222);
                                                                            Popup.Builder builder = new Popup.Builder(mainActivity4);
                                                                            builder.title = Fleet.T("remote_screen.loudness_on_the_phone_2", new Pair[0]);
                                                                            builder.view = UiKt.inDialog(mainActivity4, linearLayout22);
                                                                            builder.setNeutralButton(Fleet.T("listen.back_to_x1", new Pair[0]), null);
                                                                            builder.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                                                                            builder.show().getButton(-3).setOnClickListener(new Guard$$ExternalSyntheticLambda9(7, seekBar, axml$$ExternalSyntheticLambda2));
                                                                            return;
                                                                        case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                                                                            MainActivity mainActivity5 = mainActivity;
                                                                            Object systemService2 = mainActivity5.getSystemService("input_method");
                                                                            Intrinsics.checkNotNull(systemService2, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
                                                                            ((InputMethodManager) systemService2).hideSoftInputFromWindow(view2.getWindowToken(), 0);
                                                                            if (!mainActivity5.needsAdb$android_release()) {
                                                                                Managing.open$default(mainActivity5.getManaging$android_release(), mainActivity5.host, null, null, 6);
                                                                                return;
                                                                            }
                                                                            return;
                                                                        case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                                                                            mainActivity.setFullscreen$android_release(false);
                                                                            return;
                                                                        case 11:
                                                                            MainActivity mainActivity6 = mainActivity;
                                                                            LinearLayout col22 = UiKt.col(mainActivity6);
                                                                            LinearLayout linearLayout322 = new LinearLayout(mainActivity6);
                                                                            LinearLayout linearLayout42 = new LinearLayout(mainActivity6);
                                                                            LinearLayout linearLayout52 = new LinearLayout(mainActivity6);
                                                                            LinearLayout linearLayout62 = new LinearLayout(mainActivity6);
                                                                            TypingKt.qualityMenu$draw(mainActivity6, linearLayout322, linearLayout42, linearLayout52, linearLayout62);
                                                                            col22.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.size", new Pair[0])));
                                                                            col22.addView(linearLayout322, UiKt.gap(mainActivity6, 6));
                                                                            col22.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.frames_per_second", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                                                            col22.addView(linearLayout42, UiKt.gap(mainActivity6, 6));
                                                                            col22.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.bit_rate_mbit_s", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                                                            col22.addView(linearLayout52, UiKt.gap(mainActivity6, 6));
                                                                            col22.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.encoder", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                                                            col22.addView(linearLayout62, UiKt.gap(mainActivity6, 6));
                                                                            Popup.Builder builder2 = new Popup.Builder(mainActivity6);
                                                                            builder2.title = Fleet.T("remote_screen.picture_quality", new Pair[0]);
                                                                            builder2.view = UiKt.inDialog(mainActivity6, col22);
                                                                            builder2.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                                                                            builder2.show();
                                                                            return;
                                                                        case FileClientSessionCache.MAX_SIZE /* 12 */:
                                                                            final MainActivity mainActivity7 = mainActivity;
                                                                            final boolean z = mainActivity7.getPrefs$android_release().getBoolean("listenShare", false);
                                                                            PopupMenu popupMenu = new PopupMenu(mainActivity7, mainActivity7.getListenChip$android_release());
                                                                            MenuItem add = popupMenu.getMenu().add(1, 0, 0, Fleet.T("listen.only_the_phone", new Pair[0]));
                                                                            add.setIcon(TypingKt.listenArt(mainActivity7, false));
                                                                            add.setChecked(!z);
                                                                            MenuItem add2 = popupMenu.getMenu().add(1, 1, 1, Fleet.T("listen.tv_and_phone", new Pair[0]));
                                                                            add2.setIcon(TypingKt.listenArt(mainActivity7, true));
                                                                            add2.setChecked(z);
                                                                            popupMenu.getMenu().setGroupCheckable(1, true, true);
                                                                            if (Build.VERSION.SDK_INT >= 29) {
                                                                                popupMenu.setForceShowIcon(true);
                                                                            }
                                                                            popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: dev.tvremote.phone.media.ListenKt$$ExternalSyntheticLambda2
                                                                                @Override // android.widget.PopupMenu.OnMenuItemClickListener
                                                                                public final boolean onMenuItemClick(MenuItem menuItem) {
                                                                                    boolean z2;
                                                                                    boolean z3 = false;
                                                                                    if (menuItem.getItemId() == 1) {
                                                                                        z2 = true;
                                                                                    } else {
                                                                                        z2 = false;
                                                                                    }
                                                                                    if (z2 != z) {
                                                                                        MainActivity mainActivity8 = mainActivity7;
                                                                                        SharedPreferences.Editor edit = mainActivity8.getPrefs$android_release().edit();
                                                                                        if (menuItem.getItemId() == 1) {
                                                                                            z3 = true;
                                                                                        }
                                                                                        edit.putBoolean("listenShare", z3).apply();
                                                                                        Fleet.soundChanged(mainActivity8);
                                                                                    }
                                                                                    return true;
                                                                                }
                                                                            });
                                                                            popupMenu.show();
                                                                            return;
                                                                        case 13:
                                                                            MainActivity mainActivity8 = mainActivity;
                                                                            Intrinsics.checkNotNullParameter(mainActivity8, "<this>");
                                                                            mainActivity8.getPrefs$android_release().edit().putBoolean("listenHq", !mainActivity8.getPrefs$android_release().getBoolean("listenHq", false)).apply();
                                                                            Fleet.soundChanged(mainActivity8);
                                                                            return;
                                                                        case 14:
                                                                            mainActivity.setFullscreen$android_release(true);
                                                                            return;
                                                                        case 15:
                                                                            ArrayList arrayList = PipKt.hidden;
                                                                            MainActivity mainActivity9 = mainActivity;
                                                                            if (mainActivity9.floating) {
                                                                                PipKt.unfloat(mainActivity9);
                                                                                return;
                                                                            } else {
                                                                                if (PipKt.picLive(mainActivity9)) {
                                                                                    mainActivity9.floating = true;
                                                                                    PipKt.setFloat(1, mainActivity9);
                                                                                    TypingKt.layoutRemote(mainActivity9);
                                                                                    return;
                                                                                }
                                                                                return;
                                                                            }
                                                                        case 16:
                                                                            MainActivity mainActivity10 = mainActivity;
                                                                            if (mainActivity10.basic != null) {
                                                                                mainActivity10.press$android_release(true, 26);
                                                                                return;
                                                                            }
                                                                            Tv tv = mainActivity10.tv;
                                                                            if (tv != null && tv.ready()) {
                                                                                new Thread(new MainActivity$$ExternalSyntheticLambda38(tv, mainActivity10, i102)).start();
                                                                                return;
                                                                            }
                                                                            return;
                                                                        default:
                                                                            MainActivity mainActivity11 = mainActivity;
                                                                            String pref$android_release = mainActivity11.pref$android_release("talkMode");
                                                                            if (pref$android_release.equals("quick")) {
                                                                                mainActivity11.getTalk$android_release().open();
                                                                                return;
                                                                            } else if (pref$android_release.equals("old")) {
                                                                                mainActivity11.speak$android_release();
                                                                                return;
                                                                            } else {
                                                                                UiKt.menu(mainActivity11, Fleet.T("talk.choose_title", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_quick", new Pair[0])), Fleet.T("talk.mode_quick_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 21)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_old", new Pair[0])), Fleet.T("talk.mode_old_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 22))}));
                                                                                return;
                                                                            }
                                                                    }
                                                                }
                                                            });
                                                            LinearLayout.LayoutParams layoutParams25 = new LinearLayout.LayoutParams(UiKt.dp((Context) mainActivity, 48), UiKt.dp((Context) mainActivity, 48));
                                                            layoutParams25.rightMargin = UiKt.dp((Context) mainActivity, 6);
                                                            linearLayout14.addView(mainActivity.getLiveBtn$android_release(), layoutParams25);
                                                            mainActivity.textBox = UiKt.input(mainActivity, "");
                                                            mainActivity.getTextBox$android_release().setImeOptions(4);
                                                            mainActivity.getTextBox$android_release().setSingleLine(true);
                                                            mainActivity.getTextBox$android_release().setOnEditorActionListener(new PickerScreenKt$$ExternalSyntheticLambda11(1, mainActivity));
                                                            mainActivity.getTextBox$android_release().addTextChangedListener(new TextWatcher() { // from class: dev.tvremote.phone.remote.RemoteScreenKt$buildRemote$43
                                                                @Override // android.text.TextWatcher
                                                                public final void afterTextChanged(Editable editable) {
                                                                    Atv atv = null;
                                                                    if (!MainActivity.this.quiet && editable != null && editable.length() != 0) {
                                                                        KbdWatch kbdWatch2 = MainActivity.this.kbdWatch;
                                                                        if (kbdWatch2 != null) {
                                                                            kbdWatch2.follow.typed = true;
                                                                        } else {
                                                                            Intrinsics.throwUninitializedPropertyAccessException("kbdWatch");
                                                                            throw null;
                                                                        }
                                                                    }
                                                                    MainActivity mainActivity3 = MainActivity.this;
                                                                    String valueOf = String.valueOf(editable);
                                                                    if (mainActivity3.live && !mainActivity3.quiet) {
                                                                        Remote remote = mainActivity3.basic;
                                                                        int i25 = 0;
                                                                        if (remote != null) {
                                                                            if (remote instanceof Atv) {
                                                                                atv = (Atv) remote;
                                                                            }
                                                                            if (atv == null) {
                                                                                while (i25 < mainActivity3.onTv.length() && i25 < valueOf.length() && mainActivity3.onTv.charAt(i25) == valueOf.charAt(i25)) {
                                                                                    i25++;
                                                                                }
                                                                                int length = mainActivity3.onTv.length() - i25;
                                                                                String substring = valueOf.substring(i25);
                                                                                Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
                                                                                remote.type(substring, length);
                                                                                mainActivity3.onTv = valueOf;
                                                                                return;
                                                                            }
                                                                            if (atv.hasField) {
                                                                                for (int i26 = 0; i26 < valueOf.length(); i26++) {
                                                                                    if (Fleet.code(valueOf.charAt(i26)) == 0) {
                                                                                        if (valueOf.length() > 0) {
                                                                                            atv.text(valueOf);
                                                                                        }
                                                                                        mainActivity3.onTv = valueOf;
                                                                                        return;
                                                                                    }
                                                                                }
                                                                            }
                                                                            int i27 = 0;
                                                                            while (i27 < mainActivity3.onTv.length() && i27 < valueOf.length() && mainActivity3.onTv.charAt(i27) == valueOf.charAt(i27)) {
                                                                                i27++;
                                                                            }
                                                                            int length2 = mainActivity3.onTv.length() - i27;
                                                                            while (i25 < length2) {
                                                                                atv.key(67, 3);
                                                                                i25++;
                                                                            }
                                                                            String substring2 = valueOf.substring(i27);
                                                                            Intrinsics.checkNotNullExpressionValue(substring2, "substring(...)");
                                                                            atv.keys(substring2);
                                                                            mainActivity3.onTv = valueOf;
                                                                            return;
                                                                        }
                                                                        Tv tv = mainActivity3.tv;
                                                                        if (tv != null && tv.ready()) {
                                                                            int i28 = 0;
                                                                            while (i28 < mainActivity3.onTv.length() && i28 < valueOf.length() && mainActivity3.onTv.charAt(i28) == valueOf.charAt(i28)) {
                                                                                i28++;
                                                                            }
                                                                            int length3 = mainActivity3.onTv.length() - i28;
                                                                            while (i25 < length3) {
                                                                                tv.press(67);
                                                                                i25++;
                                                                            }
                                                                            if (valueOf.length() > i28) {
                                                                                String substring3 = valueOf.substring(i28);
                                                                                Intrinsics.checkNotNullExpressionValue(substring3, "substring(...)");
                                                                                tv.text(substring3);
                                                                            }
                                                                            mainActivity3.onTv = valueOf;
                                                                        }
                                                                    }
                                                                }

                                                                @Override // android.text.TextWatcher
                                                                public final void beforeTextChanged(CharSequence charSequence, int i25, int i26, int i27) {
                                                                }

                                                                @Override // android.text.TextWatcher
                                                                public final void onTextChanged(CharSequence charSequence, int i25, int i26, int i27) {
                                                                }
                                                            });
                                                            linearLayout14.addView(mainActivity.getTextBox$android_release(), new LinearLayout.LayoutParams(0, UiKt.dp((Context) mainActivity, 48), 1.0f));
                                                            IconButton icon14 = UiKt.icon(mainActivity, "@send", Fleet.T("notify.send", new Pair[0]), UiKt.ACCENT);
                                                            final int i25 = 4;
                                                            icon14.setOnClickListener(new View.OnClickListener() { // from class: dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda0
                                                                @Override // android.view.View.OnClickListener
                                                                public final void onClick(View view2) {
                                                                    int i72 = 5;
                                                                    int i82 = 3;
                                                                    int i92 = 29;
                                                                    int i102 = 4;
                                                                    int i112 = 6;
                                                                    int i122 = 1;
                                                                    int i132 = 0;
                                                                    switch (i25) {
                                                                        case 0:
                                                                            mainActivity.toggleVideo$android_release();
                                                                            return;
                                                                        case 1:
                                                                            Regex regex = AdbHelpKt.TV_HOME;
                                                                            MainActivity mainActivity22 = mainActivity;
                                                                            UiKt.menu(mainActivity22, Fleet.T("setup.turn_on_adb", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@zap|", Fleet.T("adb_help.automatic_install_tv_setup", new Pair[0])), Fleet.T("adb_help.just_confirm_on_the", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity22, 24)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@gear|", Fleet.T("adb_help.by_hand_open_tv", new Pair[0])), "", new TalkKt$$ExternalSyntheticLambda1(mainActivity22, 25)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@home|", Fleet.T("adb_help.install_another_home_screen", new Pair[0])), Fleet.T("adb_help.when_the_tv_hides", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity22, i92)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@wifi|", Fleet.T("setup.wireless_title", new Pair[0])), Fleet.T("adb_help.android_11_or_newer", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity22, i132)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@refresh|", Fleet.T("adb_help.full_connection", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity22, i82)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@store|", Fleet.T("adb_help.open_the_play_store", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity22, i102)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@package|", Fleet.T("adb_help.open_an_app_by", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity22, i72)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@link|", Fleet.T("setup.direct_title", new Pair[0])), Fleet.T("adb_help.a_fallback_not_reliable", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity22, i112))}));
                                                                            return;
                                                                        case 2:
                                                                            TypingKt.setLive(mainActivity, !r1.live);
                                                                            return;
                                                                        case 3:
                                                                            MainActivity mainActivity3 = mainActivity;
                                                                            Intrinsics.checkNotNullParameter(mainActivity3, "<this>");
                                                                            mainActivity3.getPrefs$android_release().edit().putBoolean("listenEven", !mainActivity3.getPrefs$android_release().getBoolean("listenEven", false)).apply();
                                                                            Fleet.soundChanged(mainActivity3);
                                                                            return;
                                                                        case 4:
                                                                            TypingKt.sendText(mainActivity);
                                                                            return;
                                                                        case 5:
                                                                            mainActivity.onBackPressed();
                                                                            return;
                                                                        case 6:
                                                                            mainActivity.leave$android_release();
                                                                            return;
                                                                        case 7:
                                                                            Fleet.toggleListen(mainActivity);
                                                                            return;
                                                                        case 8:
                                                                            MainActivity mainActivity4 = mainActivity;
                                                                            TextView label = UiKt.label(mainActivity4, TypingKt.gainWords(TypingKt.listenGain(mainActivity4)), 17, -1);
                                                                            label.setTypeface(Typeface.DEFAULT_BOLD);
                                                                            label.setGravity(8388629);
                                                                            SeekBar seekBar = new SeekBar(mainActivity4);
                                                                            seekBar.setMax(19);
                                                                            seekBar.setContentDescription(Fleet.T("listen.loudness", new Pair[0]));
                                                                            Axml$$ExternalSyntheticLambda2 axml$$ExternalSyntheticLambda2 = new Axml$$ExternalSyntheticLambda2(11, mainActivity4, label);
                                                                            seekBar.setProgress((int) ((TypingKt.listenGain(mainActivity4) - 0.5f) * 2));
                                                                            seekBar.setOnSeekBarChangeListener(new PlayingBar.AnonymousClass5(i122, axml$$ExternalSyntheticLambda2));
                                                                            LinearLayout linearLayout32 = new LinearLayout(mainActivity4);
                                                                            linearLayout32.setGravity(16);
                                                                            linearLayout32.addView(seekBar, new LinearLayout.LayoutParams(0, UiKt.dp(mainActivity4, 48), 1.0f));
                                                                            linearLayout32.addView(label, new LinearLayout.LayoutParams(UiKt.dp(mainActivity4, 56), -2));
                                                                            LinearLayout linearLayout22 = new LinearLayout(mainActivity4);
                                                                            linearLayout22.setOrientation(1);
                                                                            linearLayout22.addView(linearLayout32);
                                                                            TextView label2 = UiKt.label(mainActivity4, Fleet.T("listen.boost_note", new Pair[0]), 14, UiKt.DIM);
                                                                            LinearLayout.LayoutParams layoutParams222 = new LinearLayout.LayoutParams(-1, -2);
                                                                            layoutParams222.topMargin = UiKt.dp(mainActivity4, 8);
                                                                            linearLayout22.addView(label2, layoutParams222);
                                                                            Popup.Builder builder = new Popup.Builder(mainActivity4);
                                                                            builder.title = Fleet.T("remote_screen.loudness_on_the_phone_2", new Pair[0]);
                                                                            builder.view = UiKt.inDialog(mainActivity4, linearLayout22);
                                                                            builder.setNeutralButton(Fleet.T("listen.back_to_x1", new Pair[0]), null);
                                                                            builder.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                                                                            builder.show().getButton(-3).setOnClickListener(new Guard$$ExternalSyntheticLambda9(7, seekBar, axml$$ExternalSyntheticLambda2));
                                                                            return;
                                                                        case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                                                                            MainActivity mainActivity5 = mainActivity;
                                                                            Object systemService2 = mainActivity5.getSystemService("input_method");
                                                                            Intrinsics.checkNotNull(systemService2, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
                                                                            ((InputMethodManager) systemService2).hideSoftInputFromWindow(view2.getWindowToken(), 0);
                                                                            if (!mainActivity5.needsAdb$android_release()) {
                                                                                Managing.open$default(mainActivity5.getManaging$android_release(), mainActivity5.host, null, null, 6);
                                                                                return;
                                                                            }
                                                                            return;
                                                                        case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                                                                            mainActivity.setFullscreen$android_release(false);
                                                                            return;
                                                                        case 11:
                                                                            MainActivity mainActivity6 = mainActivity;
                                                                            LinearLayout col22 = UiKt.col(mainActivity6);
                                                                            LinearLayout linearLayout322 = new LinearLayout(mainActivity6);
                                                                            LinearLayout linearLayout42 = new LinearLayout(mainActivity6);
                                                                            LinearLayout linearLayout52 = new LinearLayout(mainActivity6);
                                                                            LinearLayout linearLayout62 = new LinearLayout(mainActivity6);
                                                                            TypingKt.qualityMenu$draw(mainActivity6, linearLayout322, linearLayout42, linearLayout52, linearLayout62);
                                                                            col22.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.size", new Pair[0])));
                                                                            col22.addView(linearLayout322, UiKt.gap(mainActivity6, 6));
                                                                            col22.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.frames_per_second", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                                                            col22.addView(linearLayout42, UiKt.gap(mainActivity6, 6));
                                                                            col22.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.bit_rate_mbit_s", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                                                            col22.addView(linearLayout52, UiKt.gap(mainActivity6, 6));
                                                                            col22.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.encoder", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                                                            col22.addView(linearLayout62, UiKt.gap(mainActivity6, 6));
                                                                            Popup.Builder builder2 = new Popup.Builder(mainActivity6);
                                                                            builder2.title = Fleet.T("remote_screen.picture_quality", new Pair[0]);
                                                                            builder2.view = UiKt.inDialog(mainActivity6, col22);
                                                                            builder2.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                                                                            builder2.show();
                                                                            return;
                                                                        case FileClientSessionCache.MAX_SIZE /* 12 */:
                                                                            final MainActivity mainActivity7 = mainActivity;
                                                                            final boolean z = mainActivity7.getPrefs$android_release().getBoolean("listenShare", false);
                                                                            PopupMenu popupMenu = new PopupMenu(mainActivity7, mainActivity7.getListenChip$android_release());
                                                                            MenuItem add = popupMenu.getMenu().add(1, 0, 0, Fleet.T("listen.only_the_phone", new Pair[0]));
                                                                            add.setIcon(TypingKt.listenArt(mainActivity7, false));
                                                                            add.setChecked(!z);
                                                                            MenuItem add2 = popupMenu.getMenu().add(1, 1, 1, Fleet.T("listen.tv_and_phone", new Pair[0]));
                                                                            add2.setIcon(TypingKt.listenArt(mainActivity7, true));
                                                                            add2.setChecked(z);
                                                                            popupMenu.getMenu().setGroupCheckable(1, true, true);
                                                                            if (Build.VERSION.SDK_INT >= 29) {
                                                                                popupMenu.setForceShowIcon(true);
                                                                            }
                                                                            popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: dev.tvremote.phone.media.ListenKt$$ExternalSyntheticLambda2
                                                                                @Override // android.widget.PopupMenu.OnMenuItemClickListener
                                                                                public final boolean onMenuItemClick(MenuItem menuItem) {
                                                                                    boolean z2;
                                                                                    boolean z3 = false;
                                                                                    if (menuItem.getItemId() == 1) {
                                                                                        z2 = true;
                                                                                    } else {
                                                                                        z2 = false;
                                                                                    }
                                                                                    if (z2 != z) {
                                                                                        MainActivity mainActivity8 = mainActivity7;
                                                                                        SharedPreferences.Editor edit = mainActivity8.getPrefs$android_release().edit();
                                                                                        if (menuItem.getItemId() == 1) {
                                                                                            z3 = true;
                                                                                        }
                                                                                        edit.putBoolean("listenShare", z3).apply();
                                                                                        Fleet.soundChanged(mainActivity8);
                                                                                    }
                                                                                    return true;
                                                                                }
                                                                            });
                                                                            popupMenu.show();
                                                                            return;
                                                                        case 13:
                                                                            MainActivity mainActivity8 = mainActivity;
                                                                            Intrinsics.checkNotNullParameter(mainActivity8, "<this>");
                                                                            mainActivity8.getPrefs$android_release().edit().putBoolean("listenHq", !mainActivity8.getPrefs$android_release().getBoolean("listenHq", false)).apply();
                                                                            Fleet.soundChanged(mainActivity8);
                                                                            return;
                                                                        case 14:
                                                                            mainActivity.setFullscreen$android_release(true);
                                                                            return;
                                                                        case 15:
                                                                            ArrayList arrayList = PipKt.hidden;
                                                                            MainActivity mainActivity9 = mainActivity;
                                                                            if (mainActivity9.floating) {
                                                                                PipKt.unfloat(mainActivity9);
                                                                                return;
                                                                            } else {
                                                                                if (PipKt.picLive(mainActivity9)) {
                                                                                    mainActivity9.floating = true;
                                                                                    PipKt.setFloat(1, mainActivity9);
                                                                                    TypingKt.layoutRemote(mainActivity9);
                                                                                    return;
                                                                                }
                                                                                return;
                                                                            }
                                                                        case 16:
                                                                            MainActivity mainActivity10 = mainActivity;
                                                                            if (mainActivity10.basic != null) {
                                                                                mainActivity10.press$android_release(true, 26);
                                                                                return;
                                                                            }
                                                                            Tv tv = mainActivity10.tv;
                                                                            if (tv != null && tv.ready()) {
                                                                                new Thread(new MainActivity$$ExternalSyntheticLambda38(tv, mainActivity10, i102)).start();
                                                                                return;
                                                                            }
                                                                            return;
                                                                        default:
                                                                            MainActivity mainActivity11 = mainActivity;
                                                                            String pref$android_release = mainActivity11.pref$android_release("talkMode");
                                                                            if (pref$android_release.equals("quick")) {
                                                                                mainActivity11.getTalk$android_release().open();
                                                                                return;
                                                                            } else if (pref$android_release.equals("old")) {
                                                                                mainActivity11.speak$android_release();
                                                                                return;
                                                                            } else {
                                                                                UiKt.menu(mainActivity11, Fleet.T("talk.choose_title", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_quick", new Pair[0])), Fleet.T("talk.mode_quick_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 21)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_old", new Pair[0])), Fleet.T("talk.mode_old_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 22))}));
                                                                                return;
                                                                            }
                                                                    }
                                                                }
                                                            });
                                                            LinearLayout.LayoutParams layoutParams26 = new LinearLayout.LayoutParams(-2, UiKt.dp((Context) mainActivity, 48));
                                                            layoutParams26.leftMargin = UiKt.dp((Context) mainActivity, 6);
                                                            layoutParams26.width = UiKt.dp((Context) mainActivity, 60);
                                                            linearLayout14.addView(icon14, layoutParams26);
                                                            col3.addView(linearLayout14, UiKt.gap(mainActivity, 8));
                                                            LinearLayout keys = keys(mainActivity, ApkSigner$$ExternalSyntheticOutline0.m("@backspace|", Fleet.T("auto.delete", new Pair[0])), 67, "@enter|Enter", 66);
                                                            Button button10 = UiKt.button(mainActivity, "123", UiKt.getBTN());
                                                            button10.setContentDescription(Fleet.T("remote.number_keys", new Pair[0]));
                                                            LinearLayout.LayoutParams layoutParams27 = new LinearLayout.LayoutParams(UiKt.dp((Context) mainActivity, 64), UiKt.dp((Context) mainActivity, 48));
                                                            layoutParams27.rightMargin = UiKt.dp((Context) mainActivity, 8);
                                                            keys.addView(button10, 0, layoutParams27);
                                                            col3.addView(keys, UiKt.gap(mainActivity, 8));
                                                            LinearLayout col5 = UiKt.col(mainActivity);
                                                            col5.addView(keys(mainActivity, "1", 8, "2", 9, "3", 10), UiKt.gap(mainActivity, 8));
                                                            col5.addView(keys(mainActivity, "4", 11, "5", 12, "6", 13), UiKt.gap(mainActivity, 8));
                                                            col5.addView(keys(mainActivity, "7", 14, "8", 15, "9", 16), UiKt.gap(mainActivity, 8));
                                                            col5.addView(keys(mainActivity, "", 0, "0", 7, "", 0), UiKt.gap(mainActivity, 8));
                                                            if (mainActivity.getPrefs$android_release().getBoolean("numpad", false)) {
                                                                i = 0;
                                                            } else {
                                                                i = 8;
                                                            }
                                                            col5.setVisibility(i);
                                                            button10.setOnClickListener(new Guard$$ExternalSyntheticLambda9(6, col5, mainActivity));
                                                            col3.addView(col5);
                                                            LinearLayout linearLayout15 = new LinearLayout(mainActivity);
                                                            EditText input = UiKt.input(mainActivity, Fleet.T("remote.ask_the_tv_open", new Pair[0]));
                                                            input.setImeOptions(3);
                                                            input.setSingleLine(true);
                                                            Regex$$ExternalSyntheticLambda0 regex$$ExternalSyntheticLambda0 = new Regex$$ExternalSyntheticLambda0(17, input, mainActivity);
                                                            input.setOnEditorActionListener(new PickerScreenKt$$ExternalSyntheticLambda11(2, regex$$ExternalSyntheticLambda0));
                                                            linearLayout15.addView(input, new LinearLayout.LayoutParams(0, UiKt.dp((Context) mainActivity, 48), 1.0f));
                                                            IconButton icon15 = UiKt.icon(mainActivity, "@search", Fleet.T("remote.commands_open_youtube_mute", new Pair[0]), UiKt.ACCENT);
                                                            icon15.setOnClickListener(new Guard$$ExternalSyntheticLambda8(9, regex$$ExternalSyntheticLambda0));
                                                            LinearLayout.LayoutParams layoutParams28 = new LinearLayout.LayoutParams(UiKt.dp((Context) mainActivity, 60), UiKt.dp((Context) mainActivity, 48));
                                                            layoutParams28.leftMargin = UiKt.dp((Context) mainActivity, 6);
                                                            linearLayout15.addView(icon15, layoutParams28);
                                                            col3.addView(linearLayout15, UiKt.gap(mainActivity, 8));
                                                            mainActivity.askBox = new Regex$$ExternalSyntheticLambda0(18, irRemoteKt$$ExternalSyntheticLambda22, input);
                                                            setLive(mainActivity, mainActivity.getPrefs$android_release().getBoolean("live", false));
                                                            Button button11 = UiKt.button(mainActivity, Fleet.T("remote_screen.disconnect", new Pair[0]), 0);
                                                            button11.setTextColor(UiKt.RED);
                                                            final int i26 = 6;
                                                            button11.setOnClickListener(new View.OnClickListener() { // from class: dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda0
                                                                @Override // android.view.View.OnClickListener
                                                                public final void onClick(View view2) {
                                                                    int i72 = 5;
                                                                    int i82 = 3;
                                                                    int i92 = 29;
                                                                    int i102 = 4;
                                                                    int i112 = 6;
                                                                    int i122 = 1;
                                                                    int i132 = 0;
                                                                    switch (i26) {
                                                                        case 0:
                                                                            mainActivity.toggleVideo$android_release();
                                                                            return;
                                                                        case 1:
                                                                            Regex regex = AdbHelpKt.TV_HOME;
                                                                            MainActivity mainActivity22 = mainActivity;
                                                                            UiKt.menu(mainActivity22, Fleet.T("setup.turn_on_adb", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@zap|", Fleet.T("adb_help.automatic_install_tv_setup", new Pair[0])), Fleet.T("adb_help.just_confirm_on_the", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity22, 24)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@gear|", Fleet.T("adb_help.by_hand_open_tv", new Pair[0])), "", new TalkKt$$ExternalSyntheticLambda1(mainActivity22, 25)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@home|", Fleet.T("adb_help.install_another_home_screen", new Pair[0])), Fleet.T("adb_help.when_the_tv_hides", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity22, i92)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@wifi|", Fleet.T("setup.wireless_title", new Pair[0])), Fleet.T("adb_help.android_11_or_newer", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity22, i132)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@refresh|", Fleet.T("adb_help.full_connection", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity22, i82)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@store|", Fleet.T("adb_help.open_the_play_store", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity22, i102)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@package|", Fleet.T("adb_help.open_an_app_by", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity22, i72)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@link|", Fleet.T("setup.direct_title", new Pair[0])), Fleet.T("adb_help.a_fallback_not_reliable", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity22, i112))}));
                                                                            return;
                                                                        case 2:
                                                                            TypingKt.setLive(mainActivity, !r1.live);
                                                                            return;
                                                                        case 3:
                                                                            MainActivity mainActivity3 = mainActivity;
                                                                            Intrinsics.checkNotNullParameter(mainActivity3, "<this>");
                                                                            mainActivity3.getPrefs$android_release().edit().putBoolean("listenEven", !mainActivity3.getPrefs$android_release().getBoolean("listenEven", false)).apply();
                                                                            Fleet.soundChanged(mainActivity3);
                                                                            return;
                                                                        case 4:
                                                                            TypingKt.sendText(mainActivity);
                                                                            return;
                                                                        case 5:
                                                                            mainActivity.onBackPressed();
                                                                            return;
                                                                        case 6:
                                                                            mainActivity.leave$android_release();
                                                                            return;
                                                                        case 7:
                                                                            Fleet.toggleListen(mainActivity);
                                                                            return;
                                                                        case 8:
                                                                            MainActivity mainActivity4 = mainActivity;
                                                                            TextView label = UiKt.label(mainActivity4, TypingKt.gainWords(TypingKt.listenGain(mainActivity4)), 17, -1);
                                                                            label.setTypeface(Typeface.DEFAULT_BOLD);
                                                                            label.setGravity(8388629);
                                                                            SeekBar seekBar = new SeekBar(mainActivity4);
                                                                            seekBar.setMax(19);
                                                                            seekBar.setContentDescription(Fleet.T("listen.loudness", new Pair[0]));
                                                                            Axml$$ExternalSyntheticLambda2 axml$$ExternalSyntheticLambda2 = new Axml$$ExternalSyntheticLambda2(11, mainActivity4, label);
                                                                            seekBar.setProgress((int) ((TypingKt.listenGain(mainActivity4) - 0.5f) * 2));
                                                                            seekBar.setOnSeekBarChangeListener(new PlayingBar.AnonymousClass5(i122, axml$$ExternalSyntheticLambda2));
                                                                            LinearLayout linearLayout32 = new LinearLayout(mainActivity4);
                                                                            linearLayout32.setGravity(16);
                                                                            linearLayout32.addView(seekBar, new LinearLayout.LayoutParams(0, UiKt.dp(mainActivity4, 48), 1.0f));
                                                                            linearLayout32.addView(label, new LinearLayout.LayoutParams(UiKt.dp(mainActivity4, 56), -2));
                                                                            LinearLayout linearLayout22 = new LinearLayout(mainActivity4);
                                                                            linearLayout22.setOrientation(1);
                                                                            linearLayout22.addView(linearLayout32);
                                                                            TextView label2 = UiKt.label(mainActivity4, Fleet.T("listen.boost_note", new Pair[0]), 14, UiKt.DIM);
                                                                            LinearLayout.LayoutParams layoutParams222 = new LinearLayout.LayoutParams(-1, -2);
                                                                            layoutParams222.topMargin = UiKt.dp(mainActivity4, 8);
                                                                            linearLayout22.addView(label2, layoutParams222);
                                                                            Popup.Builder builder = new Popup.Builder(mainActivity4);
                                                                            builder.title = Fleet.T("remote_screen.loudness_on_the_phone_2", new Pair[0]);
                                                                            builder.view = UiKt.inDialog(mainActivity4, linearLayout22);
                                                                            builder.setNeutralButton(Fleet.T("listen.back_to_x1", new Pair[0]), null);
                                                                            builder.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                                                                            builder.show().getButton(-3).setOnClickListener(new Guard$$ExternalSyntheticLambda9(7, seekBar, axml$$ExternalSyntheticLambda2));
                                                                            return;
                                                                        case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                                                                            MainActivity mainActivity5 = mainActivity;
                                                                            Object systemService2 = mainActivity5.getSystemService("input_method");
                                                                            Intrinsics.checkNotNull(systemService2, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
                                                                            ((InputMethodManager) systemService2).hideSoftInputFromWindow(view2.getWindowToken(), 0);
                                                                            if (!mainActivity5.needsAdb$android_release()) {
                                                                                Managing.open$default(mainActivity5.getManaging$android_release(), mainActivity5.host, null, null, 6);
                                                                                return;
                                                                            }
                                                                            return;
                                                                        case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                                                                            mainActivity.setFullscreen$android_release(false);
                                                                            return;
                                                                        case 11:
                                                                            MainActivity mainActivity6 = mainActivity;
                                                                            LinearLayout col22 = UiKt.col(mainActivity6);
                                                                            LinearLayout linearLayout322 = new LinearLayout(mainActivity6);
                                                                            LinearLayout linearLayout42 = new LinearLayout(mainActivity6);
                                                                            LinearLayout linearLayout52 = new LinearLayout(mainActivity6);
                                                                            LinearLayout linearLayout62 = new LinearLayout(mainActivity6);
                                                                            TypingKt.qualityMenu$draw(mainActivity6, linearLayout322, linearLayout42, linearLayout52, linearLayout62);
                                                                            col22.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.size", new Pair[0])));
                                                                            col22.addView(linearLayout322, UiKt.gap(mainActivity6, 6));
                                                                            col22.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.frames_per_second", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                                                            col22.addView(linearLayout42, UiKt.gap(mainActivity6, 6));
                                                                            col22.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.bit_rate_mbit_s", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                                                            col22.addView(linearLayout52, UiKt.gap(mainActivity6, 6));
                                                                            col22.addView(UiKt.head(mainActivity6, Fleet.T("remote_screen.encoder", new Pair[0])), UiKt.gap(mainActivity6, 14));
                                                                            col22.addView(linearLayout62, UiKt.gap(mainActivity6, 6));
                                                                            Popup.Builder builder2 = new Popup.Builder(mainActivity6);
                                                                            builder2.title = Fleet.T("remote_screen.picture_quality", new Pair[0]);
                                                                            builder2.view = UiKt.inDialog(mainActivity6, col22);
                                                                            builder2.setPositiveButton(Fleet.T("drawing.done", new Pair[0]), null);
                                                                            builder2.show();
                                                                            return;
                                                                        case FileClientSessionCache.MAX_SIZE /* 12 */:
                                                                            final MainActivity mainActivity7 = mainActivity;
                                                                            final boolean z = mainActivity7.getPrefs$android_release().getBoolean("listenShare", false);
                                                                            PopupMenu popupMenu = new PopupMenu(mainActivity7, mainActivity7.getListenChip$android_release());
                                                                            MenuItem add = popupMenu.getMenu().add(1, 0, 0, Fleet.T("listen.only_the_phone", new Pair[0]));
                                                                            add.setIcon(TypingKt.listenArt(mainActivity7, false));
                                                                            add.setChecked(!z);
                                                                            MenuItem add2 = popupMenu.getMenu().add(1, 1, 1, Fleet.T("listen.tv_and_phone", new Pair[0]));
                                                                            add2.setIcon(TypingKt.listenArt(mainActivity7, true));
                                                                            add2.setChecked(z);
                                                                            popupMenu.getMenu().setGroupCheckable(1, true, true);
                                                                            if (Build.VERSION.SDK_INT >= 29) {
                                                                                popupMenu.setForceShowIcon(true);
                                                                            }
                                                                            popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: dev.tvremote.phone.media.ListenKt$$ExternalSyntheticLambda2
                                                                                @Override // android.widget.PopupMenu.OnMenuItemClickListener
                                                                                public final boolean onMenuItemClick(MenuItem menuItem) {
                                                                                    boolean z2;
                                                                                    boolean z3 = false;
                                                                                    if (menuItem.getItemId() == 1) {
                                                                                        z2 = true;
                                                                                    } else {
                                                                                        z2 = false;
                                                                                    }
                                                                                    if (z2 != z) {
                                                                                        MainActivity mainActivity8 = mainActivity7;
                                                                                        SharedPreferences.Editor edit = mainActivity8.getPrefs$android_release().edit();
                                                                                        if (menuItem.getItemId() == 1) {
                                                                                            z3 = true;
                                                                                        }
                                                                                        edit.putBoolean("listenShare", z3).apply();
                                                                                        Fleet.soundChanged(mainActivity8);
                                                                                    }
                                                                                    return true;
                                                                                }
                                                                            });
                                                                            popupMenu.show();
                                                                            return;
                                                                        case 13:
                                                                            MainActivity mainActivity8 = mainActivity;
                                                                            Intrinsics.checkNotNullParameter(mainActivity8, "<this>");
                                                                            mainActivity8.getPrefs$android_release().edit().putBoolean("listenHq", !mainActivity8.getPrefs$android_release().getBoolean("listenHq", false)).apply();
                                                                            Fleet.soundChanged(mainActivity8);
                                                                            return;
                                                                        case 14:
                                                                            mainActivity.setFullscreen$android_release(true);
                                                                            return;
                                                                        case 15:
                                                                            ArrayList arrayList = PipKt.hidden;
                                                                            MainActivity mainActivity9 = mainActivity;
                                                                            if (mainActivity9.floating) {
                                                                                PipKt.unfloat(mainActivity9);
                                                                                return;
                                                                            } else {
                                                                                if (PipKt.picLive(mainActivity9)) {
                                                                                    mainActivity9.floating = true;
                                                                                    PipKt.setFloat(1, mainActivity9);
                                                                                    TypingKt.layoutRemote(mainActivity9);
                                                                                    return;
                                                                                }
                                                                                return;
                                                                            }
                                                                        case 16:
                                                                            MainActivity mainActivity10 = mainActivity;
                                                                            if (mainActivity10.basic != null) {
                                                                                mainActivity10.press$android_release(true, 26);
                                                                                return;
                                                                            }
                                                                            Tv tv = mainActivity10.tv;
                                                                            if (tv != null && tv.ready()) {
                                                                                new Thread(new MainActivity$$ExternalSyntheticLambda38(tv, mainActivity10, i102)).start();
                                                                                return;
                                                                            }
                                                                            return;
                                                                        default:
                                                                            MainActivity mainActivity11 = mainActivity;
                                                                            String pref$android_release = mainActivity11.pref$android_release("talkMode");
                                                                            if (pref$android_release.equals("quick")) {
                                                                                mainActivity11.getTalk$android_release().open();
                                                                                return;
                                                                            } else if (pref$android_release.equals("old")) {
                                                                                mainActivity11.speak$android_release();
                                                                                return;
                                                                            } else {
                                                                                UiKt.menu(mainActivity11, Fleet.T("talk.choose_title", new Pair[0]), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_quick", new Pair[0])), Fleet.T("talk.mode_quick_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 21)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("talk.mode_old", new Pair[0])), Fleet.T("talk.mode_old_sub", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity11, 22))}));
                                                                                return;
                                                                            }
                                                                    }
                                                                }
                                                            });
                                                            LinearLayout.LayoutParams layoutParams29 = new LinearLayout.LayoutParams(-1, UiKt.dp((Context) mainActivity, 48));
                                                            layoutParams29.topMargin = UiKt.dp((Context) mainActivity, 10);
                                                            mainActivity.getControls$android_release().addView(button11, layoutParams29);
                                                            ScrollView scrollView = new ScrollView(mainActivity);
                                                            scrollView.addView(mainActivity.getControls$android_release());
                                                            mainActivity.getRemote$android_release().addView(scrollView, new LinearLayout.LayoutParams(-1, 0, 1.0f));
                                                            layoutRemote(mainActivity);
                                                            return;
                                                        }
                                                        Intrinsics.throwUninitializedPropertyAccessException("nowApp");
                                                        throw null;
                                                    }
                                                    Intrinsics.throwUninitializedPropertyAccessException("playing");
                                                    throw null;
                                                }
                                                Intrinsics.throwUninitializedPropertyAccessException("setupClose");
                                                throw null;
                                            }
                                            Intrinsics.throwUninitializedPropertyAccessException("basicBar");
                                            throw null;
                                        }
                                        Intrinsics.throwUninitializedPropertyAccessException("fullBtn");
                                        throw null;
                                    }
                                    Intrinsics.throwUninitializedPropertyAccessException("fullBtn");
                                    throw null;
                                }
                                Intrinsics.throwUninitializedPropertyAccessException("boostBtn");
                                throw null;
                            }
                            Intrinsics.throwUninitializedPropertyAccessException("evenBtn");
                            throw null;
                        }
                        Intrinsics.throwUninitializedPropertyAccessException("hqBtn");
                        throw null;
                    }
                    Intrinsics.throwUninitializedPropertyAccessException("exitBtn");
                    throw null;
                }
                Intrinsics.throwUninitializedPropertyAccessException("exitBtn");
                throw null;
            }
            Intrinsics.throwUninitializedPropertyAccessException("tapMark");
            throw null;
        }
        Intrinsics.throwUninitializedPropertyAccessException("basicBar");
        throw null;
    }

    public static final void captioned(MainActivity mainActivity, LinearLayout linearLayout) {
        IconButton iconButton;
        int childCount = linearLayout.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = linearLayout.getChildAt(i);
            String str = null;
            if (childAt instanceof IconButton) {
                iconButton = (IconButton) childAt;
            } else {
                iconButton = null;
            }
            if (iconButton != null) {
                CharSequence contentDescription = iconButton.getContentDescription();
                if (contentDescription != null) {
                    str = contentDescription.toString();
                }
                iconButton.setCaption(str);
            }
        }
    }

    public static final void clearBox(MainActivity mainActivity) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        mainActivity.quiet = true;
        mainActivity.getTextBox$android_release().setText("");
        mainActivity.quiet = false;
        mainActivity.onTv = "";
    }

    public static final String explain(MainActivity mainActivity, String str) {
        String str2;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        String str3 = "";
        if (str == null) {
            str2 = "";
        } else {
            Locale ROOT = Locale.ROOT;
            Intrinsics.checkNotNullExpressionValue(ROOT, "ROOT");
            str2 = str.toLowerCase(ROOT);
            Intrinsics.checkNotNullExpressionValue(str2, "toLowerCase(...)");
        }
        if (!StringsKt.contains(str2, "roku: control by mobile apps is off", false) && ((str == null || !StringsKt.contains(str, "vidaa: the certificate from Hisense's app is needed", false)) && (str == null || !StringsKt.contains(str, "the home network is out of reach under the VPN", false)))) {
            if (str != null) {
                Locale ROOT2 = Locale.ROOT;
                Intrinsics.checkNotNullExpressionValue(ROOT2, "ROOT");
                str3 = str.toLowerCase(ROOT2);
                Intrinsics.checkNotNullExpressionValue(str3, "toLowerCase(...)");
            }
            if ((StringsKt.contains(str3, "refused", false) && !StringsKt.contains(str3, "refused:", false)) || StringsKt.contains(str3, "econnrefused", false)) {
                return Fleet.T("keys_only.the_tv_refused_the", new Pair[0]);
            }
            if (!StringsKt.contains(str2, "timed out", false) && !StringsKt.contains(str2, "timeout", false) && !StringsKt.contains(str2, "unreachable", false) && !StringsKt.contains(str2, "no route", false) && !StringsKt.contains(str2, "failed to connect", false)) {
                return Fleet.T("keys_only.error", new Pair("error", str));
            }
            return Fleet.T("keys_only.cannot_reach_the_tv", new Pair[0]) + "\n\n" + Fleet.T("keys_only.if_the_tv_is", new Pair[0]) + "\n\n(" + str + ")";
        }
        Object obj = Errors.ANDROID;
        IOException iOException = new IOException(str);
        ConcurrentHashMap concurrentHashMap = Words.books;
        return Errors.say(Words.lang, iOException);
    }

    public static final void flash(MainActivity mainActivity, Button button, GradientDrawable gradientDrawable) {
        Drawable background = button.getBackground();
        if (background == gradientDrawable) {
            return;
        }
        button.setBackground(gradientDrawable);
        mainActivity.ui.postDelayed(new DrawingKt$$ExternalSyntheticLambda0(7, button, background), 160L);
    }

    public static final String gainWords(float f) {
        String valueOf;
        if (f % 1.0f == 0.0f) {
            valueOf = String.valueOf((int) f);
        } else {
            valueOf = String.valueOf(f);
        }
        return ApkSigner$$ExternalSyntheticOutline0.m("×", valueOf);
    }

    public static final boolean gamesPointerClose(MainActivity mainActivity) {
        ViewGroup viewGroup;
        SensorManager sensorManager;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        FrameLayout frameLayout = Gp.host;
        if (frameLayout == null) {
            return false;
        }
        Gp.alive = false;
        GamesPointerKt$gpListen$l$1 gamesPointerKt$gpListen$l$1 = Gp.listener;
        if (gamesPointerKt$gpListen$l$1 != null && (sensorManager = Gp.sensors) != null) {
            sensorManager.unregisterListener(gamesPointerKt$gpListen$l$1);
        }
        Gp.listener = null;
        HandlerThread handlerThread = Gp.sensorThread;
        if (handlerThread != null) {
            handlerThread.quitSafely();
        }
        Gp.sensorThread = null;
        try {
            WebSocket webSocket = Gp.ws;
            if (webSocket != null) {
                webSocket.close();
            }
        } catch (Exception unused) {
        }
        Gp.ws = null;
        Thread thread = Gp.net;
        if (thread != null) {
            thread.interrupt();
        }
        Gp.net = null;
        ViewParent parent = frameLayout.getParent();
        if (parent instanceof ViewGroup) {
            viewGroup = (ViewGroup) parent;
        } else {
            viewGroup = null;
        }
        if (viewGroup != null) {
            viewGroup.removeView(frameLayout);
        }
        Gp.host = null;
        Gp.status = null;
        return true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.Object, kotlin.jvm.internal.Ref$LongRef] */
    /* JADX WARN: Type inference failed for: r1v4, types: [dev.tvremote.phone.remote.GamesPointerKt$gpListen$l$1, android.hardware.SensorEventListener] */
    public static final void gamesPointerOpen(MainActivity mainActivity) {
        boolean z;
        String str;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Tv tv = mainActivity.tv;
        if (tv != null && tv.ready()) {
            Object systemService = mainActivity.getSystemService("sensor");
            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.hardware.SensorManager");
            SensorManager sensorManager = (SensorManager) systemService;
            Sensor defaultSensor = sensorManager.getDefaultSensor(4);
            gamesPointerClose(mainActivity);
            Gp gp = Gp.INSTANCE;
            Gp.sensors = sensorManager;
            Gp.alive = true;
            Gp.ready = false;
            synchronized (gp) {
                Gp.pending = new float[2];
            }
            if (defaultSensor != null) {
                z = true;
            } else {
                z = false;
            }
            FrameLayout frameLayout = new FrameLayout(mainActivity);
            frameLayout.setBackgroundColor(UiKt.BG);
            frameLayout.setClickable(true);
            LinearLayout col = UiKt.col(mainActivity);
            float f = 16;
            float f2 = 20;
            col.setPadding(UiKt.dp(mainActivity, f), UiKt.dp(mainActivity, f2), UiKt.dp(mainActivity, f), UiKt.dp(mainActivity, f2));
            LinearLayout linearLayout = new LinearLayout(mainActivity);
            linearLayout.setGravity(16);
            TextView label = UiKt.label(mainActivity, Fleet.T("gpad.title", new Pair[0]), 24, UiKt.TEXT);
            label.setTypeface(Typeface.DEFAULT_BOLD);
            linearLayout.addView(label, new LinearLayout.LayoutParams(0, -2, 1.0f));
            IconButton icon = UiKt.icon(mainActivity, "@check", Fleet.T("drawing.done", new Pair[0]), UiKt.ACCENT);
            icon.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(mainActivity, 29));
            float f3 = 52;
            linearLayout.addView(icon, new LinearLayout.LayoutParams(UiKt.dp(mainActivity, f3), UiKt.dp(mainActivity, 44)));
            col.addView(linearLayout);
            if (z) {
                str = "gpad.hint";
            } else {
                str = "gpad.nogyro";
            }
            col.addView(UiKt.note(mainActivity, Fleet.T(str, new Pair[0])), UiKt.gap(mainActivity, 6));
            TextView label2 = UiKt.label(mainActivity, Fleet.T("gpad.joining", new Pair[0]), 16, UiKt.MUTED);
            Gp.status = label2;
            col.addView(label2, UiKt.gap(mainActivity, 10));
            Button button = UiKt.button(mainActivity, Fleet.T("gpad.fire", new Pair[0]), UiKt.ACCENT);
            button.setTextSize(28.0f);
            button.setOnTouchListener(new Talk$$ExternalSyntheticLambda8(1, mainActivity));
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, 0, 1.0f);
            layoutParams.topMargin = UiKt.dp(mainActivity, 12);
            col.addView(button, layoutParams);
            LinearLayout linearLayout2 = new LinearLayout(mainActivity);
            Button button2 = UiKt.button(mainActivity, Fleet.T("gpad.center", new Pair[0]), UiKt.MUTED);
            button2.setOnClickListener(new IrRemoteKt$$ExternalSyntheticLambda60(3));
            Button button3 = UiKt.button(mainActivity, Fleet.T("gpad.ready", new Pair[0]), UiKt.GREEN);
            button3.setOnClickListener(new Guard$$ExternalSyntheticLambda8(8, button3));
            linearLayout2.addView(button2, new LinearLayout.LayoutParams(0, UiKt.dp(mainActivity, f3), 1.0f));
            linearLayout2.addView(button3, UiKt.cell(UiKt.dp(mainActivity, f3), mainActivity, true));
            col.addView(linearLayout2, UiKt.gap(mainActivity, 12));
            frameLayout.addView(col, new FrameLayout.LayoutParams(-1, -1));
            ((ViewGroup) mainActivity.findViewById(R.id.content)).addView(frameLayout, new FrameLayout.LayoutParams(-1, -1));
            Gp.host = frameLayout;
            String str2 = mainActivity.host;
            if (str2 == null) {
                gamesPointerClose(mainActivity);
                return;
            }
            Thread thread = new Thread(new MainActivity$$ExternalSyntheticLambda9(mainActivity, tv, str2, 8), "gpad-net");
            thread.setDaemon(true);
            thread.start();
            Gp.net = thread;
            if (defaultSensor != null) {
                final ?? obj = new Object();
                ?? r1 = new SensorEventListener() { // from class: dev.tvremote.phone.remote.GamesPointerKt$gpListen$l$1
                    @Override // android.hardware.SensorEventListener
                    public final void onAccuracyChanged(Sensor sensor, int i) {
                    }

                    @Override // android.hardware.SensorEventListener
                    public final void onSensorChanged(SensorEvent e) {
                        Intrinsics.checkNotNullParameter(e, "e");
                        Ref$LongRef ref$LongRef = Ref$LongRef.this;
                        long j = ref$LongRef.element;
                        if (j == 0) {
                            ref$LongRef.element = e.timestamp;
                            return;
                        }
                        long j2 = e.timestamp;
                        float f4 = ((float) (j2 - j)) / 1.0E9f;
                        ref$LongRef.element = j2;
                        if (f4 > 0.0f && f4 <= 0.2f) {
                            float[] fArr = e.values;
                            float f5 = -fArr[2];
                            float f6 = -fArr[0];
                            float hypot = (float) Math.hypot(f5, f6);
                            if (hypot >= 0.02f) {
                                float f7 = ((hypot * 0.35f) + 1.0f) * f4 * 540.0f;
                                synchronized (Gp.INSTANCE) {
                                    float[] fArr2 = Gp.pending;
                                    fArr2[0] = (f5 * f7) + fArr2[0];
                                    fArr2[1] = (f6 * f7) + fArr2[1];
                                }
                            }
                        }
                    }
                };
                Gp.listener = r1;
                HandlerThread handlerThread = new HandlerThread("gpad-sensor");
                handlerThread.start();
                Gp.sensorThread = handlerThread;
                sensorManager.registerListener((SensorEventListener) r1, defaultSensor, 5000, new Handler(handlerThread.getLooper()));
                return;
            }
            return;
        }
        Fleet.say(mainActivity, Fleet.T("air.needs_adb", new Pair[0]), true);
    }

    public static final void gpStatus(MainActivity mainActivity, String str) {
        mainActivity.runOnUiThread(new Guard$$ExternalSyntheticLambda12(str, 1));
    }

    public static final LinearLayout keys(MainActivity mainActivity, Object... objArr) {
        String str;
        Button button;
        View view;
        boolean z;
        LinearLayout linearLayout = new LinearLayout(mainActivity);
        int progressionLastElement = MathKt.getProgressionLastElement(0, objArr.length - 1, 2);
        if (progressionLastElement >= 0) {
            int i = 0;
            while (true) {
                Object obj = objArr[i];
                Intrinsics.checkNotNull(obj, "null cannot be cast to non-null type kotlin.String");
                String str2 = (String) obj;
                int indexOf$default = StringsKt.indexOf$default(str2, '|', 6);
                if (indexOf$default > 0) {
                    str = str2.substring(indexOf$default + 1);
                    Intrinsics.checkNotNullExpressionValue(str, "substring(...)");
                    str2 = str2.substring(0, indexOf$default);
                    Intrinsics.checkNotNullExpressionValue(str2, "substring(...)");
                } else {
                    str = str2;
                }
                Object obj2 = objArr[i + 1];
                Intrinsics.checkNotNull(obj2, "null cannot be cast to non-null type kotlin.Int");
                Integer num = (Integer) obj2;
                int intValue = num.intValue();
                if (str2.length() == 0) {
                    view = new View(mainActivity);
                } else {
                    if (indexOf$default > 0) {
                        button = UiKt.icon(mainActivity, str2, str, UiKt.BTN);
                    } else {
                        button = UiKt.button(mainActivity, str2, UiKt.BTN);
                    }
                    if (indexOf$default < 0) {
                        button.setTextSize(18.0f);
                    }
                    if (Tv.OPENERS.contains(num)) {
                        button.setOnClickListener(new DrawingKt$$ExternalSyntheticLambda22(intValue, UiKt.box(mainActivity, UiKt.HELD, 16), button, mainActivity));
                        view = button;
                    } else {
                        bindKey(intValue, UiKt.box(mainActivity, UiKt.HELD, 16), button, mainActivity);
                        view = button;
                    }
                }
                if (i > 0) {
                    z = true;
                } else {
                    z = false;
                }
                linearLayout.addView(view, UiKt.cell(48, mainActivity, z));
                if (i == progressionLastElement) {
                    break;
                }
                i += 2;
            }
        }
        return linearLayout;
    }

    public static final String keysLine(Remote remote) {
        String str;
        if (Intrinsics.areEqual(remote.getKind(), "android")) {
            return Fleet.T("keys_only.keys_only", new Pair[0]);
        }
        if (Intrinsics.areEqual(remote.getKind(), "vidaa")) {
            str = "keys_only.tv_beta_vidaa";
        } else {
            str = "keys_only.tv_beta";
        }
        List list = Remote.Kind.ALL;
        return Fleet.T(str, new Pair("kind", Remote.Kind.name(remote.getKind())));
    }

    public static final void keysLost(Remote remote, MainActivity mainActivity, String ip) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Intrinsics.checkNotNullParameter(ip, "ip");
        mainActivity.basic = null;
        remote.close();
        if (mainActivity.foreground) {
            resumeBasic(mainActivity, ip);
            return;
        }
        mainActivity.keysAway = true;
        TextView status$android_release = mainActivity.getStatus$android_release();
        String str = mainActivity.entry;
        if (str != null) {
            ip = str;
        }
        status$android_release.setText(mainActivity.title$android_release(ip) + " · " + Fleet.T("phone.reconnects_when_the_app", new Pair[0]));
    }

    public static final String kindOf(MainActivity mainActivity, String ip) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Intrinsics.checkNotNullParameter(ip, "ip");
        List list = Remote.Kind.ALL;
        return Remote.Kind.of(mainActivity.pref$android_release("kind:".concat(ip)));
    }

    /* JADX WARN: Removed duplicated region for block: B:219:0x0467  */
    /* JADX WARN: Removed duplicated region for block: B:221:0x0171  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x0072  */
    /* JADX WARN: Removed duplicated region for block: B:72:0x016e  */
    /* JADX WARN: Removed duplicated region for block: B:80:0x019d  */
    /* JADX WARN: Type inference failed for: r13v0, types: [java.util.Map, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r14v3, types: [java.util.List, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r9v23, types: [java.util.Map, java.lang.Object] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void layoutRemote(MainActivity mainActivity) {
        boolean z;
        int i;
        int i2;
        Set set;
        Iterator it;
        boolean z2;
        int i3;
        LinearLayout linearLayout;
        int i4;
        LinearLayout.LayoutParams layoutParams;
        int i5;
        int i6;
        String T;
        int i7;
        int i8;
        int i9;
        int i10;
        int i11;
        float f;
        int i12;
        String T2;
        boolean z3;
        int i13;
        int i14;
        String str;
        String T3;
        View findFocus;
        boolean z4;
        String str2;
        float f2;
        String str3;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        if (mainActivity.video && mainActivity.basic == null) {
            z = true;
        } else {
            z = false;
        }
        IconButton videoBtn$android_release = mainActivity.getVideoBtn$android_release();
        if (mainActivity.basic == null) {
            i = 0;
        } else {
            i = 8;
        }
        videoBtn$android_release.setVisibility(i);
        Button button = mainActivity.basicBar;
        if (button != null) {
            if (mainActivity.basic != null && PhoneRemoteKt.kind(mainActivity).equals("android")) {
                i2 = 0;
            } else {
                i2 = 8;
            }
            button.setVisibility(i2);
            Diagnose.Real real = PhoneRemoteKt.loaded;
            List list = Remote.Kind.ALL;
            Set caps = Remote.Kind.caps(PhoneRemoteKt.kind(mainActivity));
            Remote remote = mainActivity.basic;
            if (remote != null) {
                if (PhoneRemoteKt.kind(mainActivity).equals("android")) {
                    remote = null;
                }
                if (remote != null) {
                    set = remote.getKeys();
                    it = PhoneRemoteKt.drawn.iterator();
                    Intrinsics.checkNotNullExpressionValue(it, "iterator(...)");
                    while (it.hasNext()) {
                        Object next = it.next();
                        Intrinsics.checkNotNullExpressionValue(next, "next(...)");
                        Pair pair = (Pair) next;
                        IconButton iconButton = (IconButton) pair.first;
                        RemoteSpec$Entry remoteSpec$Entry = (RemoteSpec$Entry) pair.second;
                        String kind = PhoneRemoteKt.kind(mainActivity);
                        remoteSpec$Entry.getClass();
                        ?? r13 = remoteSpec$Entry.kinds;
                        Pair pair2 = (Pair) r13.get(kind);
                        if (pair2 != null) {
                            String str4 = (String) pair2.first;
                            String str5 = (String) pair2.second;
                            if (str5 == null) {
                                str5 = remoteSpec$Entry.icon;
                            }
                            String str6 = str5;
                            if (str4 == null) {
                                str4 = remoteSpec$Entry.t;
                            }
                            String str7 = str4;
                            String str8 = remoteSpec$Entry.style;
                            ?? r14 = remoteSpec$Entry.needs;
                            String str9 = remoteSpec$Entry.id;
                            String str10 = remoteSpec$Entry.sub;
                            String str11 = remoteSpec$Entry.key;
                            String str12 = remoteSpec$Entry.action;
                            String str13 = remoteSpec$Entry.arg;
                            String str14 = remoteSpec$Entry.whenCond;
                            String str15 = remoteSpec$Entry.expand;
                            String str16 = remoteSpec$Entry.tint;
                            remoteSpec$Entry = new RemoteSpec$Entry(str9, str6, str7, str10, str11, str12, str16, str16, str16, str8, r14, str16, remoteSpec$Entry.kinds);
                        }
                        if (!r13.isEmpty()) {
                            iconButton.setIcon("@" + remoteSpec$Entry.icon, iconButton.getCurrentTextColor());
                            iconButton.setContentDescription(remoteSpec$Entry.words());
                            iconButton.setCaption(remoteSpec$Entry.words());
                        }
                        if (remoteSpec$Entry.can(caps) && (set == null || (str3 = remoteSpec$Entry.key) == null || set.contains(Scenes.KEYS.get(str3)))) {
                            z4 = true;
                        } else {
                            z4 = false;
                        }
                        if (z4) {
                            str2 = null;
                        } else {
                            str2 = "kind-off";
                        }
                        iconButton.setTag(str2);
                        if (z4) {
                            f2 = 1.0f;
                        } else {
                            f2 = 0.3f;
                        }
                        iconButton.setAlpha(f2);
                    }
                    if (!z && mainActivity.host != null && !mainActivity.floating && (mainActivity.fullscreen || mainActivity.getResources().getConfiguration().orientation == 2)) {
                        z2 = true;
                    } else {
                        z2 = false;
                    }
                    Object parent = mainActivity.getControls$android_release().getParent();
                    Intrinsics.checkNotNull(parent, "null cannot be cast to non-null type android.view.View");
                    View view = (View) parent;
                    if (!z2) {
                        i3 = 8;
                    } else {
                        i3 = 0;
                    }
                    view.setVisibility(i3);
                    if (z2 && (findFocus = mainActivity.getControls$android_release().findFocus()) != null) {
                        findFocus.clearFocus();
                        Object systemService = mainActivity.getSystemService("input_method");
                        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
                        ((InputMethodManager) systemService).hideSoftInputFromWindow(findFocus.getWindowToken(), 0);
                    }
                    linearLayout = mainActivity.topBar;
                    if (linearLayout == null) {
                        if (z2) {
                            i4 = 8;
                        } else {
                            i4 = 0;
                        }
                        linearLayout.setVisibility(i4);
                        FrameLayout stage$android_release = mainActivity.getStage$android_release();
                        int i15 = -2;
                        if (z2) {
                            layoutParams = new LinearLayout.LayoutParams(-1, 0, 1.0f);
                        } else {
                            layoutParams = new LinearLayout.LayoutParams(-1, -2);
                        }
                        stage$android_release.setLayoutParams(layoutParams);
                        if ((!z || mainActivity.floating) && mainActivity.drawing) {
                            Air.stopDrawing(mainActivity);
                        }
                        if (mainActivity.floatMode == 0) {
                            VideoFrame frame$android_release = mainActivity.getFrame$android_release();
                            if (z2) {
                                i15 = -1;
                            }
                            frame$android_release.setLayoutParams(new FrameLayout.LayoutParams(-1, i15));
                        }
                        FrameLayout stage$android_release2 = mainActivity.getStage$android_release();
                        if (z && !mainActivity.floating) {
                            i5 = 0;
                        } else {
                            i5 = 8;
                        }
                        stage$android_release2.setVisibility(i5);
                        IconButton listenBtn$android_release = mainActivity.getListenBtn$android_release();
                        if (mainActivity.basic == null) {
                            i6 = 0;
                        } else {
                            i6 = 8;
                        }
                        listenBtn$android_release.setVisibility(i6);
                        UiKt.setOn$default(mainActivity.getListenBtn$android_release(), mainActivity.listen, 16, 4);
                        IconButton listenBtn$android_release2 = mainActivity.getListenBtn$android_release();
                        if (mainActivity.listen) {
                            T = Fleet.T("remote_screen.stop_listening_on_the", new Pair[0]);
                        } else {
                            T = Fleet.T("remote_screen.hear_the_tv_on", new Pair[0]);
                        }
                        listenBtn$android_release2.setContentDescription(T);
                        IconButton iconButton2 = mainActivity.exitBtn;
                        if (iconButton2 != null) {
                            if (z2) {
                                i7 = 0;
                            } else {
                                i7 = 8;
                            }
                            iconButton2.setVisibility(i7);
                            LinearLayout picBar$android_release = mainActivity.getPicBar$android_release();
                            if (z && !z2) {
                                i8 = 0;
                            } else {
                                i8 = 8;
                            }
                            picBar$android_release.setVisibility(i8);
                            LinearLayout soundBar$android_release = mainActivity.getSoundBar$android_release();
                            if (mainActivity.listen && mainActivity.basic == null && !z2) {
                                i9 = 0;
                            } else {
                                i9 = 8;
                            }
                            soundBar$android_release.setVisibility(i9);
                            TextView qualBtn$android_release = mainActivity.getQualBtn$android_release();
                            if (z) {
                                i10 = 0;
                            } else {
                                i10 = 8;
                            }
                            qualBtn$android_release.setVisibility(i10);
                            IconButton iconButton3 = mainActivity.fullBtn;
                            if (iconButton3 != null) {
                                iconButton3.setVisibility(mainActivity.getQualBtn$android_release().getVisibility());
                                IconButton pipBtn$android_release = mainActivity.getPipBtn$android_release();
                                if (mainActivity.getQualBtn$android_release().getVisibility() == 0 && Build.VERSION.SDK_INT >= 26 && mainActivity.getPackageManager().hasSystemFeature("android.software.picture_in_picture")) {
                                    i11 = 0;
                                } else {
                                    i11 = 8;
                                }
                                pipBtn$android_release.setVisibility(i11);
                                UiKt.setOn$default(mainActivity.getPipBtn$android_release(), mainActivity.floating, 10, 4);
                                IconButton pipBtn$android_release2 = mainActivity.getPipBtn$android_release();
                                if (!PipKt.picLive(mainActivity) && !mainActivity.floating) {
                                    f = 0.4f;
                                } else {
                                    f = 1.0f;
                                }
                                pipBtn$android_release2.setAlpha(f);
                                TextView listenChip$android_release = mainActivity.getListenChip$android_release();
                                if (mainActivity.listen) {
                                    i12 = 0;
                                } else {
                                    i12 = 8;
                                }
                                listenChip$android_release.setVisibility(i12);
                                boolean z5 = mainActivity.getPrefs$android_release().getBoolean("listenShare", false);
                                TextView listenChip$android_release2 = mainActivity.getListenChip$android_release();
                                if (!z5 && !mainActivity.listenTvLoud) {
                                    T2 = Fleet.T("remote_screen.phone", new Pair[0]);
                                } else {
                                    T2 = Fleet.T("listen.both", new Pair[0]);
                                }
                                listenChip$android_release2.setText(T2 + " ▾");
                                mainActivity.getListenChip$android_release().setCompoundDrawables(listenArt(mainActivity, z5), null, null, null);
                                boolean z6 = mainActivity.getPrefs$android_release().getBoolean("listenHq", false);
                                TextView textView = mainActivity.hqBtn;
                                if (textView != null) {
                                    textView.setVisibility(mainActivity.getListenChip$android_release().getVisibility());
                                    TextView textView2 = mainActivity.hqBtn;
                                    if (textView2 != null) {
                                        UiKt.setOn(textView2, z6, 10, UiKt.DIM);
                                        boolean z7 = mainActivity.getPrefs$android_release().getBoolean("listenEven", false);
                                        boolean z8 = SoundPace.even;
                                        SoundPace.even = z7;
                                        TextView textView3 = mainActivity.evenBtn;
                                        if (textView3 != null) {
                                            textView3.setVisibility(mainActivity.getListenChip$android_release().getVisibility());
                                            TextView textView4 = mainActivity.evenBtn;
                                            if (textView4 != null) {
                                                UiKt.setOn(textView4, z7, 10, UiKt.DIM);
                                                float listenGain = listenGain(mainActivity);
                                                Fleet.times = listenGain;
                                                TextView textView5 = mainActivity.boostBtn;
                                                if (textView5 != null) {
                                                    textView5.setVisibility(mainActivity.getListenChip$android_release().getVisibility());
                                                    TextView textView6 = mainActivity.boostBtn;
                                                    if (textView6 != null) {
                                                        textView6.setText("🔊 " + gainWords(listenGain));
                                                        TextView textView7 = mainActivity.boostBtn;
                                                        if (textView7 != null) {
                                                            if (listenGain == 1.0f) {
                                                                z3 = true;
                                                            } else {
                                                                z3 = false;
                                                            }
                                                            UiKt.setOn(textView7, !z3, 10, UiKt.DIM);
                                                            TextView qualBtn$android_release2 = mainActivity.getQualBtn$android_release();
                                                            int[][] iArr = Tv.QUALITY;
                                                            qualBtn$android_release2.setText(iArr[MathKt.coerceIn(mainActivity.getPrefs$android_release().getInt("quality", 1), 0, iArr.length - 1)][0] + "p ▾");
                                                            View decorView = mainActivity.getWindow().getDecorView();
                                                            if (z2) {
                                                                i14 = 4102;
                                                            } else if (!UiKt.LIGHT) {
                                                                i14 = 0;
                                                            } else {
                                                                if (Build.VERSION.SDK_INT >= 26) {
                                                                    i13 = 16;
                                                                } else {
                                                                    i13 = 0;
                                                                }
                                                                i14 = i13 | 8192;
                                                            }
                                                            decorView.setSystemUiVisibility(i14);
                                                            IconButton videoBtn$android_release2 = mainActivity.getVideoBtn$android_release();
                                                            if (z) {
                                                                str = "@eye_off";
                                                            } else {
                                                                str = "@eye";
                                                            }
                                                            videoBtn$android_release2.setIcon(str, UiKt.TEXT);
                                                            UiKt.setOn$default(mainActivity.getVideoBtn$android_release(), z, 16, 4);
                                                            IconButton videoBtn$android_release3 = mainActivity.getVideoBtn$android_release();
                                                            if (z) {
                                                                T3 = Fleet.T("remote_screen.hide_the_tv_picture", new Pair[0]);
                                                            } else {
                                                                T3 = Fleet.T("remote_screen.show_the_tv_picture", new Pair[0]);
                                                            }
                                                            videoBtn$android_release3.setContentDescription(T3);
                                                            PipKt.pipUpdate(mainActivity);
                                                            return;
                                                        }
                                                        Intrinsics.throwUninitializedPropertyAccessException("boostBtn");
                                                        throw null;
                                                    }
                                                    Intrinsics.throwUninitializedPropertyAccessException("boostBtn");
                                                    throw null;
                                                }
                                                Intrinsics.throwUninitializedPropertyAccessException("boostBtn");
                                                throw null;
                                            }
                                            Intrinsics.throwUninitializedPropertyAccessException("evenBtn");
                                            throw null;
                                        }
                                        Intrinsics.throwUninitializedPropertyAccessException("evenBtn");
                                        throw null;
                                    }
                                    Intrinsics.throwUninitializedPropertyAccessException("hqBtn");
                                    throw null;
                                }
                                Intrinsics.throwUninitializedPropertyAccessException("hqBtn");
                                throw null;
                            }
                            Intrinsics.throwUninitializedPropertyAccessException("fullBtn");
                            throw null;
                        }
                        Intrinsics.throwUninitializedPropertyAccessException("exitBtn");
                        throw null;
                    }
                    Intrinsics.throwUninitializedPropertyAccessException("topBar");
                    throw null;
                }
            }
            set = null;
            it = PhoneRemoteKt.drawn.iterator();
            Intrinsics.checkNotNullExpressionValue(it, "iterator(...)");
            while (it.hasNext()) {
            }
            if (!z) {
            }
            z2 = false;
            Object parent2 = mainActivity.getControls$android_release().getParent();
            Intrinsics.checkNotNull(parent2, "null cannot be cast to non-null type android.view.View");
            View view2 = (View) parent2;
            if (!z2) {
            }
            view2.setVisibility(i3);
            if (z2) {
                findFocus.clearFocus();
                Object systemService2 = mainActivity.getSystemService("input_method");
                Intrinsics.checkNotNull(systemService2, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
                ((InputMethodManager) systemService2).hideSoftInputFromWindow(findFocus.getWindowToken(), 0);
            }
            linearLayout = mainActivity.topBar;
            if (linearLayout == null) {
            }
        } else {
            Intrinsics.throwUninitializedPropertyAccessException("basicBar");
            throw null;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static final Drawable listenArt(MainActivity mainActivity, boolean z) {
        Drawable drawable;
        int i;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        MainActivity$$ExternalSyntheticLambda10 mainActivity$$ExternalSyntheticLambda10 = new MainActivity$$ExternalSyntheticLambda10(mainActivity, 15);
        int dp = UiKt.dp(mainActivity, 18);
        if (!z) {
            drawable = (Drawable) mainActivity$$ExternalSyntheticLambda10.invoke("phone");
        } else {
            LayerDrawable layerDrawable = new LayerDrawable(new Drawable[]{mainActivity$$ExternalSyntheticLambda10.invoke("tv"), mainActivity$$ExternalSyntheticLambda10.invoke("phone")});
            float f = 2;
            layerDrawable.setLayerInset(0, 0, 0, UiKt.dp(mainActivity, f) + dp, 0);
            layerDrawable.setLayerInset(1, UiKt.dp(mainActivity, f) + dp, 0, 0, 0);
            drawable = layerDrawable;
        }
        if (z) {
            i = UiKt.dp(mainActivity, 2) + (dp * 2);
        } else {
            i = dp;
        }
        drawable.setBounds(0, 0, i, dp);
        return drawable;
    }

    public static final float listenGain(MainActivity mainActivity) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        return MathKt.coerceIn(Math.round(mainActivity.getPrefs$android_release().getFloat("listenGain", 1.0f) * 2) / 2.0f, 0.5f, 10.0f);
    }

    public static final void opens(int i, MainActivity mainActivity) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        if (mainActivity.basic != null) {
            if (i == 176) {
                AdbHelpKt.findSettings(mainActivity);
                return;
            } else {
                mainActivity.press$android_release(true, i);
                return;
            }
        }
        Tv tv = mainActivity.tv;
        if (tv != null && tv.ready()) {
            new Thread(new MainActivity$$ExternalSyntheticLambda12(i, mainActivity, tv, 2)).start();
        }
    }

    public static final LinearLayout pill(MainActivity mainActivity, String name, String str, int i, String sayUp, String str2, int i2, String sayDown) {
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(sayUp, "sayUp");
        Intrinsics.checkNotNullParameter(sayDown, "sayDown");
        LinearLayout col = UiKt.col(mainActivity);
        col.setBackground(UiKt.box(mainActivity, UiKt.BTN, 26));
        IconButton icon = UiKt.icon(mainActivity, str, sayUp, 0);
        bindKey(i, UiKt.box(mainActivity, UiKt.HELD, 26), icon, mainActivity);
        IconButton icon2 = UiKt.icon(mainActivity, str2, sayDown, 0);
        bindKey(i2, UiKt.box(mainActivity, UiKt.HELD, 26), icon2, mainActivity);
        TextView label = UiKt.label(mainActivity, name, 13, UiKt.MUTED);
        label.setGravity(17);
        label.setTypeface(Typeface.DEFAULT_BOLD);
        col.addView(icon, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        col.addView(label, new LinearLayout.LayoutParams(-1, -2));
        col.addView(icon2, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        return col;
    }

    public static final void qualityMenu$draw(final MainActivity mainActivity, final LinearLayout linearLayout, final LinearLayout linearLayout2, final LinearLayout linearLayout3, final LinearLayout linearLayout4) {
        String valueOf;
        String valueOf2;
        int coerceIn = MathKt.coerceIn(mainActivity.getPrefs$android_release().getInt("quality", 1), 0, Tv.QUALITY.length - 1);
        linearLayout.removeAllViews();
        linearLayout2.removeAllViews();
        linearLayout3.removeAllViews();
        linearLayout4.removeAllViews();
        int[] iArr = Tv.LEVELS;
        ArrayList arrayList = new ArrayList(iArr.length);
        for (int i : iArr) {
            arrayList.add(new Pair(String.valueOf(i), Tv.QUALITY[i][0] + "p"));
        }
        final int i2 = 0;
        linearLayout.addView(UiKt.chips(mainActivity, arrayList, String.valueOf(coerceIn), new Function1() { // from class: dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda42
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                switch (i2) {
                    case 0:
                        String it = (String) obj;
                        Intrinsics.checkNotNullParameter(it, "it");
                        int parseInt = Integer.parseInt(it);
                        MainActivity mainActivity2 = mainActivity;
                        if (parseInt != MathKt.coerceIn(mainActivity2.getPrefs$android_release().getInt("quality", 1), 0, Tv.QUALITY.length - 1)) {
                            mainActivity2.getPrefs$android_release().edit().putInt("quality", parseInt).apply();
                            mainActivity2.stopPicture$android_release();
                            TypingKt.layoutRemote(mainActivity2);
                            mainActivity2.startPicture$android_release();
                        }
                        TypingKt.qualityMenu$draw(mainActivity2, linearLayout, linearLayout2, linearLayout3, linearLayout4);
                        return Unit.INSTANCE;
                    case 1:
                        String it2 = (String) obj;
                        Intrinsics.checkNotNullParameter(it2, "it");
                        int parseInt2 = Integer.parseInt(it2);
                        MainActivity mainActivity3 = mainActivity;
                        TypingKt.tune(mainActivity3, "picFps", parseInt2);
                        TypingKt.qualityMenu$draw(mainActivity3, linearLayout, linearLayout2, linearLayout3, linearLayout4);
                        return Unit.INSTANCE;
                    case 2:
                        String it3 = (String) obj;
                        Intrinsics.checkNotNullParameter(it3, "it");
                        int parseInt3 = Integer.parseInt(it3);
                        MainActivity mainActivity4 = mainActivity;
                        TypingKt.tune(mainActivity4, "picRate", parseInt3);
                        TypingKt.qualityMenu$draw(mainActivity4, linearLayout, linearLayout2, linearLayout3, linearLayout4);
                        return Unit.INSTANCE;
                    default:
                        MainActivity mainActivity5 = mainActivity;
                        LinearLayout linearLayout5 = linearLayout;
                        LinearLayout linearLayout6 = linearLayout2;
                        LinearLayout linearLayout7 = linearLayout3;
                        LinearLayout linearLayout8 = linearLayout4;
                        String it4 = (String) obj;
                        Intrinsics.checkNotNullParameter(it4, "it");
                        if (!Intrinsics.areEqual(mainActivity5.getPrefs$android_release().getString("picEnc", "auto"), it4)) {
                            mainActivity5.getPrefs$android_release().edit().putString("picEnc", it4).apply();
                            if (mainActivity5.pic != null) {
                                mainActivity5.stopPicture$android_release();
                                mainActivity5.startPicture$android_release();
                            }
                        }
                        TypingKt.qualityMenu$draw(mainActivity5, linearLayout5, linearLayout6, linearLayout7, linearLayout8);
                        return Unit.INSTANCE;
                }
            }
        }), new LinearLayout.LayoutParams(-1, -2));
        int[] iArr2 = PIC_FPS;
        ArrayList arrayList2 = new ArrayList(4);
        for (int i3 = 0; i3 < 4; i3++) {
            int i4 = iArr2[i3];
            String valueOf3 = String.valueOf(i4);
            if (i4 == 0) {
                valueOf2 = Fleet.T("screen.auto", new Pair[0]);
            } else {
                valueOf2 = String.valueOf(i4);
            }
            arrayList2.add(new Pair(valueOf3, valueOf2));
        }
        final int i5 = 1;
        linearLayout2.addView(UiKt.chips(mainActivity, arrayList2, String.valueOf(mainActivity.getPrefs$android_release().getInt("picFps", 0)), new Function1() { // from class: dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda42
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                switch (i5) {
                    case 0:
                        String it = (String) obj;
                        Intrinsics.checkNotNullParameter(it, "it");
                        int parseInt = Integer.parseInt(it);
                        MainActivity mainActivity2 = mainActivity;
                        if (parseInt != MathKt.coerceIn(mainActivity2.getPrefs$android_release().getInt("quality", 1), 0, Tv.QUALITY.length - 1)) {
                            mainActivity2.getPrefs$android_release().edit().putInt("quality", parseInt).apply();
                            mainActivity2.stopPicture$android_release();
                            TypingKt.layoutRemote(mainActivity2);
                            mainActivity2.startPicture$android_release();
                        }
                        TypingKt.qualityMenu$draw(mainActivity2, linearLayout, linearLayout2, linearLayout3, linearLayout4);
                        return Unit.INSTANCE;
                    case 1:
                        String it2 = (String) obj;
                        Intrinsics.checkNotNullParameter(it2, "it");
                        int parseInt2 = Integer.parseInt(it2);
                        MainActivity mainActivity3 = mainActivity;
                        TypingKt.tune(mainActivity3, "picFps", parseInt2);
                        TypingKt.qualityMenu$draw(mainActivity3, linearLayout, linearLayout2, linearLayout3, linearLayout4);
                        return Unit.INSTANCE;
                    case 2:
                        String it3 = (String) obj;
                        Intrinsics.checkNotNullParameter(it3, "it");
                        int parseInt3 = Integer.parseInt(it3);
                        MainActivity mainActivity4 = mainActivity;
                        TypingKt.tune(mainActivity4, "picRate", parseInt3);
                        TypingKt.qualityMenu$draw(mainActivity4, linearLayout, linearLayout2, linearLayout3, linearLayout4);
                        return Unit.INSTANCE;
                    default:
                        MainActivity mainActivity5 = mainActivity;
                        LinearLayout linearLayout5 = linearLayout;
                        LinearLayout linearLayout6 = linearLayout2;
                        LinearLayout linearLayout7 = linearLayout3;
                        LinearLayout linearLayout8 = linearLayout4;
                        String it4 = (String) obj;
                        Intrinsics.checkNotNullParameter(it4, "it");
                        if (!Intrinsics.areEqual(mainActivity5.getPrefs$android_release().getString("picEnc", "auto"), it4)) {
                            mainActivity5.getPrefs$android_release().edit().putString("picEnc", it4).apply();
                            if (mainActivity5.pic != null) {
                                mainActivity5.stopPicture$android_release();
                                mainActivity5.startPicture$android_release();
                            }
                        }
                        TypingKt.qualityMenu$draw(mainActivity5, linearLayout5, linearLayout6, linearLayout7, linearLayout8);
                        return Unit.INSTANCE;
                }
            }
        }), new LinearLayout.LayoutParams(-1, -2));
        int[] iArr3 = PIC_RATE;
        ArrayList arrayList3 = new ArrayList(5);
        for (int i6 = 0; i6 < 5; i6++) {
            int i7 = iArr3[i6];
            String valueOf4 = String.valueOf(i7);
            if (i7 == 0) {
                valueOf = Fleet.T("screen.auto", new Pair[0]);
            } else {
                valueOf = String.valueOf(i7);
            }
            arrayList3.add(new Pair(valueOf4, valueOf));
        }
        final int i8 = 2;
        linearLayout3.addView(UiKt.chips(mainActivity, arrayList3, String.valueOf(mainActivity.getPrefs$android_release().getInt("picRate", 0)), new Function1() { // from class: dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda42
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                switch (i8) {
                    case 0:
                        String it = (String) obj;
                        Intrinsics.checkNotNullParameter(it, "it");
                        int parseInt = Integer.parseInt(it);
                        MainActivity mainActivity2 = mainActivity;
                        if (parseInt != MathKt.coerceIn(mainActivity2.getPrefs$android_release().getInt("quality", 1), 0, Tv.QUALITY.length - 1)) {
                            mainActivity2.getPrefs$android_release().edit().putInt("quality", parseInt).apply();
                            mainActivity2.stopPicture$android_release();
                            TypingKt.layoutRemote(mainActivity2);
                            mainActivity2.startPicture$android_release();
                        }
                        TypingKt.qualityMenu$draw(mainActivity2, linearLayout, linearLayout2, linearLayout3, linearLayout4);
                        return Unit.INSTANCE;
                    case 1:
                        String it2 = (String) obj;
                        Intrinsics.checkNotNullParameter(it2, "it");
                        int parseInt2 = Integer.parseInt(it2);
                        MainActivity mainActivity3 = mainActivity;
                        TypingKt.tune(mainActivity3, "picFps", parseInt2);
                        TypingKt.qualityMenu$draw(mainActivity3, linearLayout, linearLayout2, linearLayout3, linearLayout4);
                        return Unit.INSTANCE;
                    case 2:
                        String it3 = (String) obj;
                        Intrinsics.checkNotNullParameter(it3, "it");
                        int parseInt3 = Integer.parseInt(it3);
                        MainActivity mainActivity4 = mainActivity;
                        TypingKt.tune(mainActivity4, "picRate", parseInt3);
                        TypingKt.qualityMenu$draw(mainActivity4, linearLayout, linearLayout2, linearLayout3, linearLayout4);
                        return Unit.INSTANCE;
                    default:
                        MainActivity mainActivity5 = mainActivity;
                        LinearLayout linearLayout5 = linearLayout;
                        LinearLayout linearLayout6 = linearLayout2;
                        LinearLayout linearLayout7 = linearLayout3;
                        LinearLayout linearLayout8 = linearLayout4;
                        String it4 = (String) obj;
                        Intrinsics.checkNotNullParameter(it4, "it");
                        if (!Intrinsics.areEqual(mainActivity5.getPrefs$android_release().getString("picEnc", "auto"), it4)) {
                            mainActivity5.getPrefs$android_release().edit().putString("picEnc", it4).apply();
                            if (mainActivity5.pic != null) {
                                mainActivity5.stopPicture$android_release();
                                mainActivity5.startPicture$android_release();
                            }
                        }
                        TypingKt.qualityMenu$draw(mainActivity5, linearLayout5, linearLayout6, linearLayout7, linearLayout8);
                        return Unit.INSTANCE;
                }
            }
        }), new LinearLayout.LayoutParams(-1, -2));
        List asList = ArraysKt.asList(new Pair[]{new Pair("auto", Fleet.T("screen.auto", new Pair[0])), new Pair("hw", Fleet.T("screen.hardware", new Pair[0])), new Pair("sw", Fleet.T("screen.software", new Pair[0]))});
        String string = mainActivity.getPrefs$android_release().getString("picEnc", "auto");
        Intrinsics.checkNotNull(string);
        final int i9 = 3;
        linearLayout4.addView(UiKt.chips(mainActivity, asList, string, new Function1() { // from class: dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda42
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                switch (i9) {
                    case 0:
                        String it = (String) obj;
                        Intrinsics.checkNotNullParameter(it, "it");
                        int parseInt = Integer.parseInt(it);
                        MainActivity mainActivity2 = mainActivity;
                        if (parseInt != MathKt.coerceIn(mainActivity2.getPrefs$android_release().getInt("quality", 1), 0, Tv.QUALITY.length - 1)) {
                            mainActivity2.getPrefs$android_release().edit().putInt("quality", parseInt).apply();
                            mainActivity2.stopPicture$android_release();
                            TypingKt.layoutRemote(mainActivity2);
                            mainActivity2.startPicture$android_release();
                        }
                        TypingKt.qualityMenu$draw(mainActivity2, linearLayout, linearLayout2, linearLayout3, linearLayout4);
                        return Unit.INSTANCE;
                    case 1:
                        String it2 = (String) obj;
                        Intrinsics.checkNotNullParameter(it2, "it");
                        int parseInt2 = Integer.parseInt(it2);
                        MainActivity mainActivity3 = mainActivity;
                        TypingKt.tune(mainActivity3, "picFps", parseInt2);
                        TypingKt.qualityMenu$draw(mainActivity3, linearLayout, linearLayout2, linearLayout3, linearLayout4);
                        return Unit.INSTANCE;
                    case 2:
                        String it3 = (String) obj;
                        Intrinsics.checkNotNullParameter(it3, "it");
                        int parseInt3 = Integer.parseInt(it3);
                        MainActivity mainActivity4 = mainActivity;
                        TypingKt.tune(mainActivity4, "picRate", parseInt3);
                        TypingKt.qualityMenu$draw(mainActivity4, linearLayout, linearLayout2, linearLayout3, linearLayout4);
                        return Unit.INSTANCE;
                    default:
                        MainActivity mainActivity5 = mainActivity;
                        LinearLayout linearLayout5 = linearLayout;
                        LinearLayout linearLayout6 = linearLayout2;
                        LinearLayout linearLayout7 = linearLayout3;
                        LinearLayout linearLayout8 = linearLayout4;
                        String it4 = (String) obj;
                        Intrinsics.checkNotNullParameter(it4, "it");
                        if (!Intrinsics.areEqual(mainActivity5.getPrefs$android_release().getString("picEnc", "auto"), it4)) {
                            mainActivity5.getPrefs$android_release().edit().putString("picEnc", it4).apply();
                            if (mainActivity5.pic != null) {
                                mainActivity5.stopPicture$android_release();
                                mainActivity5.startPicture$android_release();
                            }
                        }
                        TypingKt.qualityMenu$draw(mainActivity5, linearLayout5, linearLayout6, linearLayout7, linearLayout8);
                        return Unit.INSTANCE;
                }
            }
        }), new LinearLayout.LayoutParams(-1, -2));
    }

    public static final void resumeBasic(MainActivity mainActivity, String ip) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Intrinsics.checkNotNullParameter(ip, "ip");
        String str = mainActivity.entry;
        if (str == null) {
            str = ip;
        }
        mainActivity.waitFor$android_release(mainActivity.title$android_release(str), Fleet.T("keys_only.reconnecting", new Pair[0]));
        new Thread(new AdbHelpKt$$ExternalSyntheticLambda63(mainActivity, ip, 4)).start();
    }

    public static final void sendText(MainActivity mainActivity) {
        Atv atv;
        String obj = mainActivity.getTextBox$android_release().getText().toString();
        Remote remote = mainActivity.basic;
        if (remote != null) {
            if (mainActivity.live) {
                remote.key(66, 3);
                clearBox(mainActivity);
                return;
            }
            if (obj.length() == 0) {
                remote.key(66, 3);
                return;
            }
            if (remote instanceof Atv) {
                atv = (Atv) remote;
            } else {
                atv = null;
            }
            if (atv == null) {
                remote.text(obj);
            } else {
                if (atv.hasField) {
                    for (int i = 0; i < obj.length(); i++) {
                        if (Fleet.code(obj.charAt(i)) == 0) {
                            atv.text(obj);
                            break;
                        }
                    }
                }
                atv.keys(obj);
            }
            mainActivity.getTextBox$android_release().setText("");
            return;
        }
        Tv tv = mainActivity.tv;
        if (tv != null && tv.ready()) {
            if (mainActivity.live) {
                tv.press(66);
                clearBox(mainActivity);
            } else if (obj.length() > 0) {
                tv.text(obj);
                mainActivity.getTextBox$android_release().setText("");
            }
        }
    }

    public static final void setLive(MainActivity mainActivity, boolean z) {
        String T;
        String T2;
        mainActivity.live = z;
        mainActivity.getPrefs$android_release().edit().putBoolean("live", z).apply();
        UiKt.setOn$default(mainActivity.getLiveBtn$android_release(), z, 0, 6);
        IconButton liveBtn$android_release = mainActivity.getLiveBtn$android_release();
        if (z) {
            T = Fleet.T("typing.live_typing_is_on", new Pair[0]);
        } else {
            T = Fleet.T("typing.type_then_send_is", new Pair[0]);
        }
        liveBtn$android_release.setContentDescription(T);
        EditText textBox$android_release = mainActivity.getTextBox$android_release();
        if (z) {
            T2 = Fleet.T("typing.live_the_tv_gets", new Pair[0]);
        } else {
            T2 = Fleet.T("typing.type_then_send", new Pair[0]);
        }
        textBox$android_release.setHint(T2);
        clearBox(mainActivity);
    }

    public static final void slide(LinearLayout linearLayout) {
        View rootView = linearLayout.getRootView();
        Intrinsics.checkNotNull(rootView, "null cannot be cast to non-null type android.view.ViewGroup");
        TransitionManager.beginDelayedTransition((ViewGroup) rootView, new AutoTransition().setDuration(220L));
    }

    public static final void startBasic(MainActivity mainActivity, String ip, boolean z) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Intrinsics.checkNotNullParameter(ip, "ip");
        PickerScreenKt.message(mainActivity, Fleet.T("keys_only.connecting_to", new Pair("ip", ip)), false);
        String str = mainActivity.entry;
        if (str == null) {
            str = ip;
        }
        String kindOf = kindOf(mainActivity, str);
        File filesDir = mainActivity.getFilesDir();
        Intrinsics.checkNotNullExpressionValue(filesDir, "getFilesDir(...)");
        Remote of = Vidaa.Companion.of(filesDir, kindOf, ip);
        Thread thread = new Thread(new MediaKt$$ExternalSyntheticLambda9(of, mainActivity, 5));
        thread.setDaemon(true);
        thread.start();
        new Thread(new UpdaterKt$$ExternalSyntheticLambda10(of, mainActivity, z, ip)).start();
    }

    /* JADX WARN: Type inference failed for: r1v4, types: [java.lang.Object, kotlin.jvm.internal.Ref$FloatRef] */
    /* JADX WARN: Type inference failed for: r2v2, types: [java.lang.Object, kotlin.jvm.internal.Ref$FloatRef] */
    /* JADX WARN: Type inference failed for: r3v1, types: [kotlin.jvm.internal.Ref$BooleanRef, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r4v1, types: [kotlin.jvm.internal.Ref$IntRef, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r5v0, types: [java.lang.Object, kotlin.jvm.internal.Ref$LongRef] */
    public static final FrameLayout touchpad(final MainActivity mainActivity) {
        final FrameLayout frameLayout = new FrameLayout(mainActivity);
        frameLayout.setBackground(UiKt.box(mainActivity, UiKt.CARD, 28));
        TextView label = UiKt.label(mainActivity, Fleet.T("remote_screen.swipe_move_tap_ok", new Pair[0]), 13, UiKt.MUTED);
        label.setGravity(17);
        frameLayout.addView(label, new FrameLayout.LayoutParams(-1, -2, 17));
        final float dp = UiKt.dp(mainActivity, 20);
        final ?? obj = new Object();
        final ?? obj2 = new Object();
        final ?? obj3 = new Object();
        final ?? obj4 = new Object();
        final ?? obj5 = new Object();
        frameLayout.setOnTouchListener(new View.OnTouchListener() { // from class: dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda38
            @Override // android.view.View.OnTouchListener
            public final boolean onTouch(View view, MotionEvent motionEvent) {
                int i;
                float f;
                boolean z;
                int i2;
                float f2;
                boolean z2;
                int i3;
                int actionMasked = motionEvent.getActionMasked();
                Ref$FloatRef ref$FloatRef = Ref$FloatRef.this;
                Ref$FloatRef ref$FloatRef2 = obj2;
                Ref$BooleanRef ref$BooleanRef = obj3;
                Ref$IntRef ref$IntRef = obj4;
                Ref$LongRef ref$LongRef = obj5;
                if (actionMasked != 0) {
                    MainActivity mainActivity2 = mainActivity;
                    if (actionMasked != 1) {
                        if (actionMasked != 2) {
                            if (actionMasked == 5) {
                                ref$IntRef.element = Math.max(ref$IntRef.element, motionEvent.getPointerCount());
                                return true;
                            }
                        } else if (ref$IntRef.element == 1 && mainActivity2.live$android_release()) {
                            while (true) {
                                float abs = Math.abs(motionEvent.getX() - ref$FloatRef.element);
                                f = dp;
                                if (abs < f) {
                                    break;
                                }
                                if (motionEvent.getX() > ref$FloatRef.element) {
                                    z2 = true;
                                } else {
                                    z2 = false;
                                }
                                if (z2) {
                                    i3 = 22;
                                } else {
                                    i3 = 21;
                                }
                                mainActivity2.press$android_release(true, i3);
                                float f3 = ref$FloatRef.element;
                                if (!z2) {
                                    f = -f;
                                }
                                ref$FloatRef.element = f3 + f;
                                ref$BooleanRef.element = true;
                            }
                            while (Math.abs(motionEvent.getY() - ref$FloatRef2.element) >= f) {
                                if (motionEvent.getY() > ref$FloatRef2.element) {
                                    z = true;
                                } else {
                                    z = false;
                                }
                                if (z) {
                                    i2 = 20;
                                } else {
                                    i2 = 19;
                                }
                                mainActivity2.press$android_release(true, i2);
                                float f4 = ref$FloatRef2.element;
                                if (z) {
                                    f2 = f;
                                } else {
                                    f2 = -f;
                                }
                                ref$FloatRef2.element = f4 + f2;
                                ref$BooleanRef.element = true;
                            }
                        }
                    } else if (!ref$BooleanRef.element && mainActivity2.live$android_release() && motionEvent.getEventTime() - ref$LongRef.element < 400) {
                        if (ref$IntRef.element >= 2) {
                            i = 4;
                        } else {
                            i = 23;
                        }
                        mainActivity2.press$android_release(true, i);
                        FrameLayout frameLayout2 = frameLayout;
                        Drawable background = frameLayout2.getBackground();
                        frameLayout2.setBackground(UiKt.box(mainActivity2, UiKt.HELD, 28));
                        mainActivity2.ui.postDelayed(new DrawingKt$$ExternalSyntheticLambda0(8, frameLayout2, background), 120L);
                    }
                    return true;
                }
                view.getParent().requestDisallowInterceptTouchEvent(true);
                ref$FloatRef.element = motionEvent.getX();
                ref$FloatRef2.element = motionEvent.getY();
                ref$BooleanRef.element = false;
                ref$IntRef.element = 1;
                ref$LongRef.element = motionEvent.getEventTime();
                return true;
            }
        });
        return frameLayout;
    }

    public static final void tune(MainActivity mainActivity, String str, int i) {
        if (mainActivity.getPrefs$android_release().getInt(str, 0) != i) {
            mainActivity.getPrefs$android_release().edit().putInt(str, i).apply();
            if (mainActivity.pic != null) {
                mainActivity.stopPicture$android_release();
                mainActivity.startPicture$android_release();
            }
        }
    }

    public static final void vidaaCert(MainActivity mainActivity) {
        List list;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Vidaa.Companion companion = Vidaa.Companion;
        File filesDir = mainActivity.getFilesDir();
        Intrinsics.checkNotNullExpressionValue(filesDir, "getFilesDir(...)");
        if (!new File(filesDir, "vidaa.p12").isFile()) {
            Iterator it = Vidaa.APPS.iterator();
            while (it.hasNext()) {
                try {
                    ApplicationInfo applicationInfo = mainActivity.getPackageManager().getApplicationInfo((String) it.next(), 0);
                    Intrinsics.checkNotNullExpressionValue(applicationInfo, "getApplicationInfo(...)");
                    String str = applicationInfo.sourceDir;
                    if (str != null) {
                        list = MathKt.listOf(str);
                    } else {
                        list = EmptyList.INSTANCE;
                    }
                    String[] strArr = applicationInfo.splitSourceDirs;
                    if (strArr == null) {
                        strArr = new String[0];
                    }
                    Iterator it2 = CollectionsKt.plus(list, (Object[]) strArr).iterator();
                    while (it2.hasNext()) {
                        File file = new File((String) it2.next());
                        FileInputStream fileInputStream = new FileInputStream(file);
                        try {
                            Vidaa.Companion companion2 = Vidaa.Companion;
                            File filesDir2 = mainActivity.getFilesDir();
                            Intrinsics.checkNotNullExpressionValue(filesDir2, "getFilesDir(...)");
                            boolean importCert = Vidaa.Companion.importCert(filesDir2, fileInputStream, file.length());
                            fileInputStream.close();
                            if (importCert) {
                                return;
                            }
                        } catch (Throwable th) {
                            try {
                                throw th;
                                break;
                            } catch (Throwable th2) {
                                MathKt.closeFinally(fileInputStream, th);
                                throw th2;
                                break;
                            }
                        }
                    }
                } catch (Exception unused) {
                }
            }
        }
    }

    public static final void watchAdb(MainActivity mainActivity, Atv atv, String ip) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Intrinsics.checkNotNullParameter(ip, "ip");
        if (mainActivity.adbFailed.contains(ip)) {
            return;
        }
        Thread thread = new Thread(new KeysOnlyKt$$ExternalSyntheticLambda14(mainActivity, atv, ip, 0));
        thread.setDaemon(true);
        thread.start();
    }
}
