package dev.tvremote.phone.remote;

import android.content.SharedPreferences;
import android.widget.TextView;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.remote.Atv;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.picker.PickerScreenKt;
import java.util.regex.Pattern;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final /* synthetic */ class KeysOnlyKt$$ExternalSyntheticLambda2 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ String f$1;
    public final /* synthetic */ Remote f$2;

    public /* synthetic */ KeysOnlyKt$$ExternalSyntheticLambda2(Remote remote, MainActivity mainActivity, String str) {
        this.$r8$classId = 0;
        this.f$0 = mainActivity;
        this.f$1 = str;
        this.f$2 = remote;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.$r8$classId) {
            case 0:
                MainActivity mainActivity = this.f$0;
                String str = this.f$1;
                Remote remote = this.f$2;
                if (!mainActivity.isFinishing() && Intrinsics.areEqual(mainActivity.host, str) && mainActivity.basic == null && mainActivity.tv == null) {
                    mainActivity.basic = remote;
                    mainActivity.getWaiting$android_release().setVisibility(8);
                    TextView status$android_release = mainActivity.getStatus$android_release();
                    String str2 = mainActivity.entry;
                    if (str2 == null) {
                        str2 = str;
                    }
                    status$android_release.setText(mainActivity.title$android_release(str2) + " · " + TypingKt.keysLine(remote));
                    TypingKt.layoutRemote(mainActivity);
                    if (remote instanceof Atv) {
                        TypingKt.watchAdb(mainActivity, (Atv) remote, str);
                        return;
                    }
                    return;
                }
                remote.close();
                return;
            case 1:
                MainActivity mainActivity2 = this.f$0;
                boolean isFinishing = mainActivity2.isFinishing();
                Remote remote2 = this.f$2;
                if (!isFinishing && mainActivity2.host == null) {
                    boolean areEqual = Intrinsics.areEqual(remote2.getKind(), "android");
                    String input = this.f$1;
                    if (areEqual) {
                        mainActivity2.getPrefs$android_release().edit().putBoolean("atv:" + input, true).apply();
                    } else {
                        SharedPreferences.Editor edit = mainActivity2.getPrefs$android_release().edit();
                        String str3 = mainActivity2.entry;
                        if (str3 == null) {
                            str3 = input;
                        }
                        SharedPreferences.Editor putString = edit.putString(ApkSigner$$ExternalSyntheticOutline0.m("kind:", str3), remote2.getKind());
                        if (remote2.getMac().length() > 0) {
                            String str4 = mainActivity2.entry;
                            if (str4 == null) {
                                str4 = input;
                            }
                            putString.putString(ApkSigner$$ExternalSyntheticOutline0.m("mac:", str4), remote2.getMac());
                        }
                        Pattern compile = Pattern.compile("^(10|192\\.168|172\\.(1[6-9]|2\\d|3[01]))\\.");
                        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                        Intrinsics.checkNotNullParameter(input, "input");
                        if (compile.matcher(input).find()) {
                            String str5 = mainActivity2.entry;
                            if (str5 == null) {
                                str5 = input;
                            }
                            putString.putString("lan:".concat(str5), input);
                        }
                        putString.apply();
                    }
                    mainActivity2.basic = remote2;
                    mainActivity2.host = input;
                    String str6 = mainActivity2.entry;
                    if (str6 == null) {
                        str6 = input;
                    }
                    PickerScreenKt.save(mainActivity2, str6, remote2.getModel());
                    PickerScreenKt.message(mainActivity2, null, false);
                    mainActivity2.show$android_release(true);
                    TypingKt.layoutRemote(mainActivity2);
                    mainActivity2.getStatus$android_release().setText(mainActivity2.title$android_release(input) + " · " + TypingKt.keysLine(remote2));
                    if (remote2 instanceof Atv) {
                        TypingKt.watchAdb(mainActivity2, (Atv) remote2, input);
                        return;
                    }
                    return;
                }
                remote2.close();
                return;
            case 2:
                MainActivity mainActivity3 = this.f$0;
                Remote remote3 = mainActivity3.basic;
                Remote remote4 = this.f$2;
                if (remote3 == remote4) {
                    TypingKt.keysLost(remote4, mainActivity3, this.f$1);
                    return;
                }
                return;
            default:
                MainActivity mainActivity4 = this.f$0;
                Remote remote5 = mainActivity4.basic;
                Remote remote6 = this.f$2;
                if (remote5 == remote6) {
                    TypingKt.keysLost(remote6, mainActivity4, this.f$1);
                    return;
                }
                return;
        }
    }

    public /* synthetic */ KeysOnlyKt$$ExternalSyntheticLambda2(MainActivity mainActivity, Remote remote, String str, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
        this.f$2 = remote;
        this.f$1 = str;
    }
}
