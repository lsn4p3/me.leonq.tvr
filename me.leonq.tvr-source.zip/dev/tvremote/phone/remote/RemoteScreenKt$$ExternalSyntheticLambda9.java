package dev.tvremote.phone.remote;

import android.widget.LinearLayout;
import com.android.apksig.internal.apk.ApkSigningBlockUtils$$ExternalSyntheticLambda0;
import dev.tvremote.phone.ui.IconButton;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;

/* loaded from: classes.dex */
public final /* synthetic */ class RemoteScreenKt$$ExternalSyntheticLambda9 implements Function1 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ ApkSigningBlockUtils$$ExternalSyntheticLambda0 f$0;
    public final /* synthetic */ LinearLayout f$1;
    public final /* synthetic */ IconButton f$2;
    public final /* synthetic */ LinearLayout f$3;
    public final /* synthetic */ IconButton f$4;

    public /* synthetic */ RemoteScreenKt$$ExternalSyntheticLambda9(ApkSigningBlockUtils$$ExternalSyntheticLambda0 apkSigningBlockUtils$$ExternalSyntheticLambda0, LinearLayout linearLayout, IconButton iconButton, LinearLayout linearLayout2, IconButton iconButton2, int i) {
        this.$r8$classId = i;
        this.f$0 = apkSigningBlockUtils$$ExternalSyntheticLambda0;
        this.f$1 = linearLayout;
        this.f$2 = iconButton;
        this.f$3 = linearLayout2;
        this.f$4 = iconButton2;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        Boolean bool = (Boolean) obj;
        switch (this.$r8$classId) {
            case 0:
                boolean booleanValue = bool.booleanValue();
                ApkSigningBlockUtils$$ExternalSyntheticLambda0 apkSigningBlockUtils$$ExternalSyntheticLambda0 = this.f$0;
                if (booleanValue) {
                    apkSigningBlockUtils$$ExternalSyntheticLambda0.invoke(this.f$1, this.f$2, "kbd", Boolean.FALSE);
                }
                apkSigningBlockUtils$$ExternalSyntheticLambda0.invoke(this.f$3, this.f$4, "more", bool);
                return Unit.INSTANCE;
            default:
                boolean booleanValue2 = bool.booleanValue();
                ApkSigningBlockUtils$$ExternalSyntheticLambda0 apkSigningBlockUtils$$ExternalSyntheticLambda02 = this.f$0;
                if (booleanValue2) {
                    apkSigningBlockUtils$$ExternalSyntheticLambda02.invoke(this.f$1, this.f$2, "more", Boolean.FALSE);
                }
                apkSigningBlockUtils$$ExternalSyntheticLambda02.invoke(this.f$3, this.f$4, "kbd", bool);
                return Unit.INSTANCE;
        }
    }
}
