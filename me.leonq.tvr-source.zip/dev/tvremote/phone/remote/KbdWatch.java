package dev.tvremote.phone.remote;

import dev.tvremote.core.adb.TvKeyboard;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.media.NowApp$tick$1;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* loaded from: classes.dex */
public final class KbdWatch {
    public final MainActivity a;
    public boolean asking;
    public final TvKeyboard.Follow follow = new Object();
    public final TvKeyboard.Reader reader = new TvKeyboard.Reader();
    public final ExecutorService work = Executors.newSingleThreadExecutor();
    public final NowApp$tick$1 tick = new NowApp$tick$1(2, this);

    /* JADX WARN: Type inference failed for: r2v1, types: [dev.tvremote.core.adb.TvKeyboard$Follow, java.lang.Object] */
    public KbdWatch(MainActivity mainActivity) {
        this.a = mainActivity;
    }
}
