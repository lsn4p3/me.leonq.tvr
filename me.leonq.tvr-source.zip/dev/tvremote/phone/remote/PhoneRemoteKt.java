package dev.tvremote.phone.remote;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Diagnose;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Words$$ExternalSyntheticLambda1;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.core.remote.Vidaa$$ExternalSyntheticLambda0;
import dev.tvremote.core.remote.Vidaa$$ExternalSyntheticLambda6;
import dev.tvremote.core.scenes.RemoteSpec$Entry;
import dev.tvremote.core.scenes.Scenes;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.media.MediaKt$$ExternalSyntheticLambda4;
import dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda3;
import dev.tvremote.phone.picker.ManyTvsKt$$ExternalSyntheticLambda40;
import dev.tvremote.phone.picture.DrawingKt$$ExternalSyntheticLambda22;
import dev.tvremote.phone.scenes.Headless$$ExternalSyntheticLambda0;
import dev.tvremote.phone.ui.IconButton;
import dev.tvremote.phone.ui.UiKt;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.CollectionsKt__MutableCollectionsKt;
import kotlin.collections.EmptyMap;
import kotlin.collections.EmptySet;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgressionIterator;
import kotlin.ranges.IntRange;
import kotlin.text.Charsets;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public abstract class PhoneRemoteKt {
    public static Diagnose.Real loaded;
    public static final Object remoteGroups = MapsKt__MapsKt.mapOf(new Pair("get", "rkey.open_get"), new Pair("send", "rkey.open_send"), new Pair("timerMore", "rkey.timer_more"), new Pair("tools", "rkey.tools"), new Pair("tvkeys", "rkey.tools_keys"));
    public static final Object phoneActions = MapsKt__MapsKt.mapOf(new Pair("shot", new Vidaa$$ExternalSyntheticLambda0(3)), new Pair("open", new Vidaa$$ExternalSyntheticLambda0(5)), new Pair("apps", new Vidaa$$ExternalSyntheticLambda0(17)), new Pair("menu", new Vidaa$$ExternalSyntheticLambda0(24)), new Pair("key", new Vidaa$$ExternalSyntheticLambda0(26)), new Pair("timer", new Vidaa$$ExternalSyntheticLambda0(27)), new Pair("scenes", new Vidaa$$ExternalSyntheticLambda0(28)), new Pair("privacy", new Vidaa$$ExternalSyntheticLambda0(29)), new Pair("notify", new Headless$$ExternalSyntheticLambda0(1)), new Pair("draw", new Headless$$ExternalSyntheticLambda0(2)), new Pair("search", new Vidaa$$ExternalSyntheticLambda0(14)), new Pair("package", new Vidaa$$ExternalSyntheticLambda0(25)), new Pair("link", new Headless$$ExternalSyntheticLambda0(3)), new Pair("media", new Headless$$ExternalSyntheticLambda0(4)), new Pair("file", new Headless$$ExternalSyntheticLambda0(5)), new Pair("cast", new Headless$$ExternalSyntheticLambda0(6)), new Pair("store", new Headless$$ExternalSyntheticLambda0(7)), new Pair("timerPlus", new Headless$$ExternalSyntheticLambda0(8)), new Pair("timerCancel", new Headless$$ExternalSyntheticLambda0(9)), new Pair("timerCustom", new Vidaa$$ExternalSyntheticLambda0(4)), new Pair("automation", new Vidaa$$ExternalSyntheticLambda0(6)), new Pair("clip", new Vidaa$$ExternalSyntheticLambda0(7)), new Pair("screenOff", new Vidaa$$ExternalSyntheticLambda0(8)), new Pair("dim", new Vidaa$$ExternalSyntheticLambda0(9)), new Pair("vbox", new Vidaa$$ExternalSyntheticLambda0(10)), new Pair("share", new Vidaa$$ExternalSyntheticLambda0(11)), new Pair("inputs", new Vidaa$$ExternalSyntheticLambda0(12)), new Pair("air", new Vidaa$$ExternalSyntheticLambda0(13)), new Pair("gamespad", new Vidaa$$ExternalSyntheticLambda0(15)), new Pair("ir", new Vidaa$$ExternalSyntheticLambda0(16)), new Pair("manage", new Vidaa$$ExternalSyntheticLambda0(18)), new Pair("homeCustom", new Vidaa$$ExternalSyntheticLambda0(19)), new Pair("rescue", new Vidaa$$ExternalSyntheticLambda0(20)));
    public static final Object phoneButtonHooks = MapsKt__MapsKt.mapOf(new Pair("draw", new Vidaa$$ExternalSyntheticLambda0(21)), new Pair("shot", new Vidaa$$ExternalSyntheticLambda0(22)), new Pair("air", new Vidaa$$ExternalSyntheticLambda0(23)));
    public static final ArrayList drawn = new ArrayList();

    public static final String kind(MainActivity mainActivity) {
        String kind;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Remote remote = mainActivity.basic;
        if (remote != null && (kind = remote.getKind()) != null) {
            return kind;
        }
        return "android";
    }

    public static final void kindOff(MainActivity mainActivity) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Toast.makeText(mainActivity, Fleet.T("core.only_android", new Pair[0]), 0).show();
    }

    /* JADX WARN: Type inference failed for: r7v5, types: [java.util.Map, java.lang.Object] */
    public static final ArrayList remoteMenu(MainActivity mainActivity, String name, Set conditions, Map map) {
        String str;
        Iterator it;
        String concat;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(conditions, "conditions");
        ArrayList arrayList = new ArrayList();
        List list = Remote.Kind.ALL;
        Set caps = Remote.Kind.caps(kind(mainActivity));
        Object obj = ((LinkedHashMap) remoteSpec(mainActivity).bindUdp).get(name);
        Intrinsics.checkNotNull(obj);
        Iterator it2 = ((List) obj).iterator();
        while (it2.hasNext()) {
            RemoteSpec$Entry remoteSpec$Entry = (RemoteSpec$Entry) it2.next();
            String str2 = remoteSpec$Entry.whenCond;
            if (str2 == null || conditions.contains(str2)) {
                if (remoteSpec$Entry.can(caps)) {
                    String str3 = remoteSpec$Entry.expand;
                    if (str3 != null) {
                        Function0 function0 = (Function0) map.get(str3);
                        if (function0 != null) {
                            arrayList.addAll((Collection) function0.invoke());
                        }
                    } else {
                        String str4 = remoteSpec$Entry.action;
                        boolean areEqual = Intrinsics.areEqual(str4, "menu");
                        String str5 = "";
                        String str6 = remoteSpec$Entry.sub;
                        String str7 = remoteSpec$Entry.icon;
                        String str8 = remoteSpec$Entry.arg;
                        if (areEqual) {
                            if (str8 == null) {
                                str8 = "";
                            }
                            ArrayList remoteMenu = remoteMenu(mainActivity, str8, conditions, map);
                            if (remoteMenu.size() == 1) {
                                arrayList.add(remoteMenu.get(0));
                            } else if (!remoteMenu.isEmpty()) {
                                String m = Census$$ExternalSyntheticOutline0.m("@", str7, "|", remoteSpec$Entry.words());
                                if (str6.length() != 0) {
                                    str5 = Fleet.T(str6, new Pair[0]);
                                }
                                arrayList.add(new Triple(m, str5, new Vidaa$$ExternalSyntheticLambda6(mainActivity, remoteSpec$Entry, remoteMenu, 9)));
                            }
                        } else {
                            if (str4 == null) {
                                str = "key";
                            } else {
                                str = str4;
                            }
                            if (str4 == null) {
                                str8 = remoteSpec$Entry.key;
                            }
                            Function2 function2 = (Function2) phoneActions.get(str);
                            if (function2 != null) {
                                String str9 = remoteSpec$Entry.tint;
                                if (str9.length() == 0) {
                                    it = it2;
                                    concat = "";
                                } else {
                                    it = it2;
                                    concat = ":".concat(str9);
                                }
                                String m2 = Census$$ExternalSyntheticOutline0.m("@", str7, concat, "|", remoteSpec$Entry.words());
                                if (str6.length() != 0) {
                                    str5 = Fleet.T(str6, new Pair[0]);
                                }
                                arrayList.add(new Triple(m2, str5, new Vidaa$$ExternalSyntheticLambda6(function2, mainActivity, str8, 10)));
                                it2 = it;
                            } else {
                                throw new IllegalStateException(("remote.json: no phone handler for \"" + str + "\"").toString());
                            }
                        }
                    }
                } else {
                    continue;
                }
            }
        }
        return arrayList;
    }

    public static /* synthetic */ ArrayList remoteMenu$default(MainActivity mainActivity, String str, LinkedHashSet linkedHashSet, int i) {
        Set set = linkedHashSet;
        if ((i & 2) != 0) {
            set = EmptySet.INSTANCE;
        }
        return remoteMenu(mainActivity, str, set, EmptyMap.INSTANCE);
    }

    /* JADX WARN: Type inference failed for: r11v19, types: [java.util.Map, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r5v5, types: [java.util.Map, java.lang.Object] */
    public static final LinearLayout remoteRow(MainActivity mainActivity, String str, int i, int i2, int i3) {
        MainActivity mainActivity2;
        LinearLayout linearLayout = new LinearLayout(mainActivity);
        Intrinsics.checkNotNull(((LinkedHashMap) remoteSpec(mainActivity).link).get(str));
        linearLayout.setWeightSum(Math.max(i3, ((List) ((List) r2).get(i)).size()));
        Object obj = ((LinkedHashMap) remoteSpec(mainActivity).link).get(str);
        Intrinsics.checkNotNull(obj);
        Iterator it = ((Iterable) ((List) obj).get(i)).iterator();
        int i4 = 0;
        while (true) {
            boolean z = true;
            if (it.hasNext()) {
                Object next = it.next();
                int i5 = i4 + 1;
                if (i4 >= 0) {
                    RemoteSpec$Entry remoteSpec$Entry = (RemoteSpec$Entry) next;
                    IconButton icon = UiKt.icon(mainActivity, ApkSigner$$ExternalSyntheticOutline0.m("@", remoteSpec$Entry.icon), remoteSpec$Entry.words(), UiKt.BTN);
                    String str2 = remoteSpec$Entry.action;
                    if (str2 != null) {
                        Function2 function2 = (Function2) phoneActions.get(str2);
                        if (function2 != null) {
                            mainActivity2 = mainActivity;
                            icon.setOnClickListener(new ManyTvsKt$$ExternalSyntheticLambda40(icon, mainActivity2, function2, remoteSpec$Entry, 1));
                            Function2 function22 = (Function2) phoneButtonHooks.get(str2);
                            if (function22 != null) {
                                function22.invoke(mainActivity2, icon);
                            }
                        } else {
                            throw new IllegalStateException(("remote.json: no phone handler for \"" + str2 + "\"").toString());
                        }
                    } else {
                        mainActivity2 = mainActivity;
                        HashMap hashMap = Scenes.KEYS;
                        String str3 = remoteSpec$Entry.key;
                        Integer num = (Integer) hashMap.get(str3);
                        if (num != null) {
                            int intValue = num.intValue();
                            if (Tv.OPENERS.contains(num)) {
                                icon.setOnClickListener(new DrawingKt$$ExternalSyntheticLambda22(icon, mainActivity2, UiKt.box(mainActivity2, UiKt.HELD, 16), intValue));
                            } else {
                                TypingKt.bindKey(intValue, UiKt.box(mainActivity2, UiKt.HELD, 16), icon, mainActivity2);
                            }
                        } else {
                            throw new IllegalStateException(("remote.json: unknown key " + str3).toString());
                        }
                    }
                    if (i4 <= 0) {
                        z = false;
                    }
                    linearLayout.addView(icon, UiKt.cell(i2, mainActivity2, z));
                    ArrayList arrayList = drawn;
                    CollectionsKt__MutableCollectionsKt.removeAll(arrayList, new Words$$ExternalSyntheticLambda1(18, remoteSpec$Entry));
                    arrayList.add(new Pair(icon, remoteSpec$Entry));
                    i4 = i5;
                    mainActivity = mainActivity2;
                } else {
                    CollectionsKt__CollectionsKt.throwIndexOverflow();
                    throw null;
                }
            } else {
                MainActivity mainActivity3 = mainActivity;
                for (int childCount = linearLayout.getChildCount(); childCount < i3; childCount++) {
                    linearLayout.addView(new View(mainActivity3), UiKt.cell(i2, mainActivity3, true));
                }
                TypingKt.captioned(mainActivity3, linearLayout);
                return linearLayout;
            }
        }
    }

    public static final Diagnose.Real remoteSpec(MainActivity mainActivity) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Diagnose.Real real = loaded;
        if (real == null) {
            InputStream open = mainActivity.getAssets().open("remote.json");
            try {
                Intrinsics.checkNotNull(open);
                String str = new String(MathKt.readBytes(open), Charsets.UTF_8);
                open.close();
                JSONObject jSONObject = new JSONObject(str);
                LinkedHashMap linkedHashMap = new LinkedHashMap();
                JSONObject optJSONObject = jSONObject.optJSONObject("rows");
                if (optJSONObject != null) {
                    Iterator<String> keys = optJSONObject.keys();
                    Intrinsics.checkNotNullExpressionValue(keys, "keys(...)");
                    while (keys.hasNext()) {
                        String next = keys.next();
                        JSONArray jSONArray = optJSONObject.getJSONArray(next);
                        IntRange until = MathKt.until(0, jSONArray.length());
                        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until));
                        Iterator it = until.iterator();
                        while (((IntProgressionIterator) it).hasNext) {
                            JSONArray jSONArray2 = jSONArray.getJSONArray(((IntProgressionIterator) it).nextInt());
                            Intrinsics.checkNotNullExpressionValue(jSONArray2, "getJSONArray(...)");
                            arrayList.add(Fleet.entries(jSONArray2));
                        }
                        linkedHashMap.put(next, arrayList);
                    }
                }
                LinkedHashMap linkedHashMap2 = new LinkedHashMap();
                JSONObject optJSONObject2 = jSONObject.optJSONObject("menus");
                if (optJSONObject2 != null) {
                    Iterator<String> keys2 = optJSONObject2.keys();
                    Intrinsics.checkNotNullExpressionValue(keys2, "keys(...)");
                    while (keys2.hasNext()) {
                        String next2 = keys2.next();
                        JSONArray jSONArray3 = optJSONObject2.getJSONArray(next2);
                        Intrinsics.checkNotNullExpressionValue(jSONArray3, "getJSONArray(...)");
                        linkedHashMap2.put(next2, Fleet.entries(jSONArray3));
                    }
                }
                Diagnose.Real real2 = new Diagnose.Real(linkedHashMap, linkedHashMap2);
                loaded = real2;
                return real2;
            } finally {
            }
        } else {
            return real;
        }
    }

    public static final void trackingMenu(MainActivity mainActivity) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        String kind = kind(mainActivity);
        if (kind.equals("android")) {
            return;
        }
        MediaKt$$ExternalSyntheticLambda4 mediaKt$$ExternalSyntheticLambda4 = new MediaKt$$ExternalSyntheticLambda4(mainActivity, kind, 10);
        UiKt.menu(mainActivity, Fleet.T("track.title", new Pair("tv", Remote.Kind.name(kind))), 0, ArraysKt.asList(new Triple[]{new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@settings|", Fleet.T("track.open", new Pair[0])), Fleet.T("track.open_sub", new Pair[0]), mediaKt$$ExternalSyntheticLambda4), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@eye|", Fleet.T("track.acr", new Pair[0])), Fleet.T(ApkSigner$$ExternalSyntheticOutline0.m("track.", kind, "_acr"), new Pair[0]), mediaKt$$ExternalSyntheticLambda4), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@tag|", Fleet.T("track.ads", new Pair[0])), Fleet.T(ApkSigner$$ExternalSyntheticOutline0.m("track.", kind, "_ads"), new Pair[0]), mediaKt$$ExternalSyntheticLambda4), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T("track.mic", new Pair[0])), Fleet.T(ApkSigner$$ExternalSyntheticOutline0.m("track.", kind, "_mic"), new Pair[0]), mediaKt$$ExternalSyntheticLambda4), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@guide|", Fleet.T("track.guide", new Pair[0])), Fleet.T("track.guide_sub", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity, 20))}));
    }
}
