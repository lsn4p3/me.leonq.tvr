package dev.tvremote.phone.remote;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.widget.Toast;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.ui.IconButton;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import kotlin.Pair;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class KeysOnlyKt$$ExternalSyntheticLambda3 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ Object f$1;
    public final /* synthetic */ Object f$2;

    public /* synthetic */ KeysOnlyKt$$ExternalSyntheticLambda3(Tv tv, MainActivity mainActivity, IconButton iconButton) {
        this.$r8$classId = 1;
        this.f$1 = tv;
        this.f$0 = mainActivity;
        this.f$2 = iconButton;
    }

    @Override // java.lang.Runnable
    public final void run() {
        String T;
        byte[] bArr;
        OutputStream outputStream;
        Uri uri;
        switch (this.$r8$classId) {
            case 0:
                MainActivity mainActivity = this.f$0;
                String str = (String) this.f$1;
                Exception exc = (Exception) this.f$2;
                if (Intrinsics.areEqual(mainActivity.host, str) && mainActivity.basic == null && mainActivity.tv == null) {
                    mainActivity.disconnect$android_release(TypingKt.explain(mainActivity, exc.getMessage()));
                    return;
                }
                return;
            case 1:
                Tv tv = (Tv) this.f$1;
                MainActivity mainActivity2 = this.f$0;
                IconButton iconButton = (IconButton) this.f$2;
                try {
                    Adb adb = tv.adb;
                    bArr = null;
                    if (adb != null) {
                        try {
                            byte[] bArr2 = Tv.MOUSE_DESC;
                            bArr = Fleet.screencap(adb);
                        } catch (IOException unused) {
                        }
                    }
                } catch (Exception e) {
                    T = Fleet.T("remote_screen.screenshot_failed", new Pair("why", e.getMessage()));
                }
                if (bArr != null) {
                    String str2 = "tv-" + (System.currentTimeMillis() / 1000) + ".png";
                    if (Build.VERSION.SDK_INT >= 29) {
                        ContentValues contentValues = new ContentValues();
                        contentValues.put("_display_name", str2);
                        contentValues.put("mime_type", "image/png");
                        contentValues.put("relative_path", Environment.DIRECTORY_DOWNLOADS);
                        ContentResolver contentResolver = mainActivity2.getContentResolver();
                        ContentResolver contentResolver2 = mainActivity2.getContentResolver();
                        uri = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                        Uri insert = contentResolver2.insert(uri, contentValues);
                        Intrinsics.checkNotNull(insert);
                        outputStream = contentResolver.openOutputStream(insert);
                        Intrinsics.checkNotNull(outputStream);
                        T = Fleet.T("remote_screen.saved_to_download", new Pair("file", str2));
                    } else {
                        File file = new File(mainActivity2.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), str2);
                        FileOutputStream fileOutputStream = new FileOutputStream(file);
                        String T2 = Fleet.T("remote_screen.saved", new Pair("file", file.getAbsolutePath()));
                        outputStream = fileOutputStream;
                        T = T2;
                    }
                    try {
                        outputStream.write(bArr);
                        outputStream.close();
                        mainActivity2.ui.post(new KeysOnlyKt$$ExternalSyntheticLambda3(iconButton, mainActivity2, T));
                        return;
                    } finally {
                    }
                } else {
                    throw new IOException(Fleet.T("remote_screen.the_tv_sent_no", new Pair[0]));
                }
            case 2:
                IconButton iconButton2 = (IconButton) this.f$2;
                if (iconButton2 != null) {
                    iconButton2.setBusy(false);
                }
                MainActivity mainActivity3 = this.f$0;
                if (!mainActivity3.isFinishing()) {
                    Toast.makeText(mainActivity3, (String) this.f$1, 1).show();
                    return;
                }
                return;
            default:
                if (!this.f$0.isFinishing()) {
                    JSONObject jSONObject = (JSONObject) this.f$2;
                    Intrinsics.checkNotNull(jSONObject);
                    ((Function1) this.f$1).invoke(jSONObject);
                    return;
                }
                return;
        }
    }

    public /* synthetic */ KeysOnlyKt$$ExternalSyntheticLambda3(MainActivity mainActivity, Object obj, Object obj2, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
        this.f$1 = obj;
        this.f$2 = obj2;
    }

    public /* synthetic */ KeysOnlyKt$$ExternalSyntheticLambda3(IconButton iconButton, MainActivity mainActivity, String str) {
        this.$r8$classId = 2;
        this.f$2 = iconButton;
        this.f$0 = mainActivity;
        this.f$1 = str;
    }
}
