package dev.tvremote.phone.remote;

import dev.tvremote.core.Fleet;
import dev.tvremote.phone.MainActivity;
import java.io.File;
import java.io.IOException;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class RescuingKt$$ExternalSyntheticLambda2 implements Runnable {
    public final /* synthetic */ int $r8$classId = 1;
    public final /* synthetic */ JSONObject f$0;
    public final /* synthetic */ MainActivity f$1;
    public final /* synthetic */ String f$2;

    public /* synthetic */ RescuingKt$$ExternalSyntheticLambda2(MainActivity mainActivity, String str, JSONObject jSONObject) {
        this.f$1 = mainActivity;
        this.f$2 = str;
        this.f$0 = jSONObject;
    }

    @Override // java.lang.Runnable
    public final void run() {
        String str;
        String T;
        String T2;
        JSONObject jSONObject = this.f$0;
        String input = this.f$2;
        MainActivity mainActivity = this.f$1;
        switch (this.$r8$classId) {
            case 0:
                if (jSONObject == null) {
                    Fleet.say(mainActivity, Fleet.T("rescue.failed", new Pair[0]), true);
                    return;
                }
                String optString = jSONObject.optString("stopped");
                try {
                    File cacheDir = mainActivity.getCacheDir();
                    Pattern compile = Pattern.compile("[^\\w.-]");
                    Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                    Intrinsics.checkNotNullParameter(input, "input");
                    String replaceAll = compile.matcher(input).replaceAll("_");
                    Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
                    str = new JSONObject(MathKt.readText$default(new File(cacheDir, "meta/" + replaceAll + "/names.json"))).optString(optString);
                } catch (Exception unused) {
                    str = "";
                }
                Intrinsics.checkNotNull(optString);
                if (optString.length() == 0) {
                    T = Fleet.T("rescue.home", new Pair[0]);
                } else {
                    if (str.length() != 0) {
                        optString = str;
                    }
                    T = Fleet.T("rescue.closed", new Pair("name", optString));
                }
                Fleet.say(mainActivity, T, false);
                return;
            default:
                if (!mainActivity.isFinishing()) {
                    if (input == null || !MathKt.offerSetup(mainActivity, new IOException(input))) {
                        if (input == null) {
                            T2 = Fleet.T("auto.done", new Pair("name", jSONObject.optString("name")));
                        } else {
                            T2 = Fleet.T("automation.some_steps_did_not", new Pair("steps", input));
                        }
                        MathKt.toast(mainActivity, T2);
                        return;
                    }
                    return;
                }
                return;
        }
    }

    public /* synthetic */ RescuingKt$$ExternalSyntheticLambda2(JSONObject jSONObject, MainActivity mainActivity, String str) {
        this.f$0 = jSONObject;
        this.f$1 = mainActivity;
        this.f$2 = str;
    }
}
