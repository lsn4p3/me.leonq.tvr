package dev.tvremote.phone.remote;

import android.hardware.SensorManager;
import android.os.HandlerThread;
import android.widget.FrameLayout;
import android.widget.TextView;
import dev.tvremote.core.remote.WebSocket;

/* loaded from: classes.dex */
public final class Gp {
    public static volatile boolean alive;
    public static FrameLayout host;
    public static GamesPointerKt$gpListen$l$1 listener;
    public static Thread net;
    public static volatile boolean ready;
    public static HandlerThread sensorThread;
    public static SensorManager sensors;
    public static TextView status;
    public static volatile WebSocket ws;
    public static final Gp INSTANCE = new Object();
    public static float[] pending = new float[2];
}
