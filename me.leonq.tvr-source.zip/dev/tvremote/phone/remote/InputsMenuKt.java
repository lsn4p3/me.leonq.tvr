package dev.tvremote.phone.remote;

import java.util.concurrent.ConcurrentHashMap;

/* loaded from: classes.dex */
public abstract class InputsMenuKt {
    public static final ConcurrentHashMap inputCaches = new ConcurrentHashMap();
}
