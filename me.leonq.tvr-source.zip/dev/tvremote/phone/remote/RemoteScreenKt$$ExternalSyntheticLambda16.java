package dev.tvremote.phone.remote;

import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.picture.Air;
import dev.tvremote.phone.picture.DrawingKt$$ExternalSyntheticLambda0;
import dev.tvremote.phone.ui.IconButton;
import dev.tvremote.phone.ui.UiKt;
import java.util.List;
import java.util.NoSuchElementException;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final /* synthetic */ class RemoteScreenKt$$ExternalSyntheticLambda16 implements Function2 {
    public final /* synthetic */ LinearLayout f$0;
    public final /* synthetic */ FrameLayout f$1;
    public final /* synthetic */ FrameLayout f$2;
    public final /* synthetic */ Button f$3;
    public final /* synthetic */ List f$4;
    public final /* synthetic */ MainActivity f$5;

    public /* synthetic */ RemoteScreenKt$$ExternalSyntheticLambda16(LinearLayout linearLayout, FrameLayout frameLayout, FrameLayout frameLayout2, Button button, List list, MainActivity mainActivity) {
        this.f$0 = linearLayout;
        this.f$1 = frameLayout;
        this.f$2 = frameLayout2;
        this.f$3 = button;
        this.f$4 = list;
        this.f$5 = mainActivity;
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(Object obj, Object obj2) {
        int i;
        int i2;
        String m = (String) obj;
        boolean booleanValue = ((Boolean) obj2).booleanValue();
        Intrinsics.checkNotNullParameter(m, "m");
        int i3 = 8;
        if (m.equals("arrows")) {
            i = 0;
        } else {
            i = 8;
        }
        this.f$0.setVisibility(i);
        if (m.equals("touch")) {
            i2 = 0;
        } else {
            i2 = 8;
        }
        FrameLayout frameLayout = this.f$1;
        frameLayout.setVisibility(i2);
        if (m.equals("mouse")) {
            i3 = 0;
        }
        FrameLayout frameLayout2 = this.f$2;
        frameLayout2.setVisibility(i3);
        for (Pair pair : this.f$4) {
            if (Intrinsics.areEqual(pair.first, m)) {
                UiKt.setLabel(this.f$3, pair.second + "  ▾");
                MainActivity mainActivity = this.f$5;
                IconButton iconButton = mainActivity.airBtn;
                if (iconButton != null) {
                    UiKt.setOn$default(iconButton, m.equals("mouse"), 16, 4);
                }
                mainActivity.getPrefs$android_release().edit().putString("mid", m).apply();
                Air.airStart(mainActivity, m);
                if (m.equals("mouse")) {
                    frameLayout = frameLayout2;
                } else if (!m.equals("touch")) {
                    frameLayout = null;
                }
                if (booleanValue && frameLayout != null) {
                    frameLayout.post(new DrawingKt$$ExternalSyntheticLambda0(frameLayout, mainActivity, 6));
                }
                return Unit.INSTANCE;
            }
        }
        throw new NoSuchElementException("Collection contains no element matching the predicate.");
    }
}
