package dev.tvremote.phone.remote;

import android.graphics.drawable.Drawable;
import android.widget.Button;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.phone.MainActivity;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Ref$BooleanRef;
import kotlin.jvm.internal.Ref$ObjectRef;

/* loaded from: classes.dex */
public final /* synthetic */ class RemoteScreenKt$$ExternalSyntheticLambda50 implements Function0 {
    public final /* synthetic */ Ref$ObjectRef f$0;
    public final /* synthetic */ Ref$BooleanRef f$1;
    public final /* synthetic */ MainActivity f$2;
    public final /* synthetic */ RemoteScreenKt$bindKey$again$1 f$3;
    public final /* synthetic */ int f$4;
    public final /* synthetic */ Button f$5;
    public final /* synthetic */ Drawable f$6;

    public /* synthetic */ RemoteScreenKt$$ExternalSyntheticLambda50(Ref$ObjectRef ref$ObjectRef, Ref$BooleanRef ref$BooleanRef, MainActivity mainActivity, RemoteScreenKt$bindKey$again$1 remoteScreenKt$bindKey$again$1, int i, Button button, Drawable drawable) {
        this.f$0 = ref$ObjectRef;
        this.f$1 = ref$BooleanRef;
        this.f$2 = mainActivity;
        this.f$3 = remoteScreenKt$bindKey$again$1;
        this.f$4 = i;
        this.f$5 = button;
        this.f$6 = drawable;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        Ref$ObjectRef ref$ObjectRef = this.f$0;
        Ref$BooleanRef ref$BooleanRef = this.f$1;
        MainActivity mainActivity = this.f$2;
        RemoteScreenKt$bindKey$again$1 remoteScreenKt$bindKey$again$1 = this.f$3;
        int i = this.f$4;
        Button button = this.f$5;
        Drawable drawable = this.f$6;
        Runnable runnable = (Runnable) ref$ObjectRef.element;
        if (runnable != null) {
            mainActivity.ui.removeCallbacks(runnable);
        }
        ref$ObjectRef.element = null;
        if (ref$BooleanRef.element) {
            ref$BooleanRef.element = false;
            mainActivity.ui.removeCallbacks(remoteScreenKt$bindKey$again$1);
            Tv tv = mainActivity.tv;
            if (tv != null) {
                tv.key(1, i, 0, 0);
            } else {
                Remote remote = mainActivity.basic;
                if (remote != null) {
                    remote.key(i, 2);
                }
            }
            button.setBackground(drawable);
        }
        return Unit.INSTANCE;
    }
}
