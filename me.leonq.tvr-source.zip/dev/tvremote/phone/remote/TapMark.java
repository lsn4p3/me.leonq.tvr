package dev.tvremote.phone.remote;

import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;
import dev.tvremote.phone.MainActivity;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class TapMark extends View {
    public ValueAnimator anim;
    public final float d;
    public final Paint fill;
    public float gone;
    public boolean held;
    public final Paint ring;
    public float x;
    public float y;

    public TapMark(MainActivity mainActivity) {
        super(mainActivity);
        float f = getResources().getDisplayMetrics().density;
        this.d = f;
        Paint paint = new Paint(1);
        paint.setColor(1308622847);
        this.fill = paint;
        Paint paint2 = new Paint(1);
        paint2.setStyle(Paint.Style.STROKE);
        paint2.setStrokeWidth(2 * f);
        paint2.setColor(-419430401);
        paint2.setShadowLayer(4 * f, 0.0f, 0.0f, Integer.MIN_VALUE);
        this.ring = paint2;
        this.gone = 1.0f;
        setClickable(false);
        setFocusable(false);
        setLayerType(1, null);
    }

    @Override // android.view.View
    public final void onDraw(Canvas c) {
        Intrinsics.checkNotNullParameter(c, "c");
        if (!this.held && this.gone >= 1.0f) {
            return;
        }
        float f = 17 * this.d;
        float f2 = 1;
        float f3 = this.gone;
        float f4 = ((0.9f * f3) + f2) * f;
        float f5 = f2 - f3;
        Paint paint = this.fill;
        paint.setAlpha((int) (77 * f5 * f5));
        Paint paint2 = this.ring;
        paint2.setAlpha((int) (230 * f5));
        c.drawCircle(this.x, this.y, f4, paint);
        c.drawCircle(this.x, this.y, f4, paint2);
    }
}
