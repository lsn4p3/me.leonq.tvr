package dev.tvremote.phone.remote;

import android.widget.Toast;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.remote.Atv;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.phone.MainActivity;
import kotlin.Pair;
import kotlin.math.MathKt;

/* loaded from: classes.dex */
public final /* synthetic */ class KeysOnlyKt$$ExternalSyntheticLambda14 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ Atv f$1;
    public final /* synthetic */ String f$2;

    public /* synthetic */ KeysOnlyKt$$ExternalSyntheticLambda14(MainActivity mainActivity, Atv atv, String str, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
        this.f$1 = atv;
        this.f$2 = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.$r8$classId) {
            case 0:
                break;
            default:
                MainActivity mainActivity = this.f$0;
                if (mainActivity.basic == this.f$1 && !mainActivity.isFinishing()) {
                    Toast.makeText(mainActivity, Fleet.T("keys_only.adb_is_on_switching", new Pair[0]), 1).show();
                    String str = mainActivity.entry;
                    mainActivity.disconnect$android_release(null);
                    mainActivity.connect$android_release(this.f$2, str);
                    return;
                }
                return;
        }
        while (true) {
            MainActivity mainActivity2 = this.f$0;
            Remote remote = mainActivity2.basic;
            Atv atv = this.f$1;
            if (remote == atv && !mainActivity2.isFinishing()) {
                Thread.sleep(4000L);
                if (mainActivity2.basic == atv) {
                    String str2 = this.f$2;
                    if (MathKt.open(str2, 5555, 1200, null)) {
                        mainActivity2.ui.post(new KeysOnlyKt$$ExternalSyntheticLambda14(mainActivity2, atv, str2, 1));
                        return;
                    }
                }
            } else {
                return;
            }
        }
    }
}
