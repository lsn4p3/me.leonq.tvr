package dev.tvremote.phone;

import android.content.Intent;
import android.os.Build;
import android.service.quicksettings.Tile;
import dev.tvremote.core.Fleet;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.math.MathKt;
import kotlin.text.StringsKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class SceneTile extends TvTile {
    @Override // dev.tvremote.phone.TvTile
    public final Intent job(Intent intent) {
        JSONObject jSONObject = (JSONObject) CollectionsKt.firstOrNull(MathKt.list(this));
        if (jSONObject != null) {
            return intent.putExtra("scene", jSONObject.optString("id"));
        }
        return null;
    }

    /* JADX WARN: Code restructure failed: missing block: B:4:0x0038, code lost:
    
        if (r2 != null) goto L8;
     */
    @Override // dev.tvremote.phone.TvTile
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void paint(Tile tile) {
        String T;
        String str;
        tile.setState(1);
        JSONObject jSONObject = (JSONObject) CollectionsKt.firstOrNull(MathKt.list(this));
        if (jSONObject != null) {
            T = StringsKt.trim(jSONObject.optString("icon") + " " + jSONObject.optString("name")).toString();
        }
        T = Fleet.T("tiles.tv_scene", new Pair[0]);
        tile.setLabel(T);
        if (Build.VERSION.SDK_INT >= 29) {
            if (jSONObject == null) {
                str = Fleet.T("tiles.make_one_in_the", new Pair[0]);
            } else {
                str = "TV Remote";
            }
            tile.setSubtitle(str);
        }
    }
}
