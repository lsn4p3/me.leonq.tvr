package dev.tvremote.phone;

import android.widget.Toast;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.AdbTls;
import dev.tvremote.core.ontv.Games;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.remote.Lg$$ExternalSyntheticLambda2;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.media.MediaKt$$ExternalSyntheticLambda2;
import dev.tvremote.phone.media.Talk$$ExternalSyntheticLambda5;
import dev.tvremote.phone.ui.Popup;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.StringsKt;

/* loaded from: classes.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda38 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ Tv f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda38(Tv tv, MainActivity mainActivity, int i) {
        this.$r8$classId = i;
        this.f$1 = tv;
        this.f$0 = mainActivity;
    }

    /* JADX WARN: Type inference failed for: r4v2, types: [kotlin.jvm.internal.Ref$BooleanRef, java.lang.Object] */
    @Override // java.lang.Runnable
    public final void run() {
        Adb adb;
        Exception e = null;
        String str = null;
        e = null;
        final boolean z = true;
        char c = 1;
        int i = 0;
        switch (this.$r8$classId) {
            case 0:
                MainActivity mainActivity = this.f$0;
                Tv tv = this.f$1;
                if (mainActivity.tv == tv && tv != null && tv.ready()) {
                    mainActivity.getWaiting$android_release().setVisibility(8);
                    return;
                }
                return;
            case 1:
                try {
                    AdbTls.Wireless parse = Fleet.parse(this.f$1.shell("ps -A -o ARGS 2>/dev/null"));
                    if (parse != null) {
                        i = parse.connect;
                    }
                } catch (Exception unused) {
                }
                MainActivity mainActivity2 = this.f$0;
                mainActivity2.ui.post(new MediaKt$$ExternalSyntheticLambda2(mainActivity2, i, c == true ? 1 : 0));
                return;
            case 2:
                Tv tv2 = this.f$1;
                try {
                    byte[] bArr = Tv.MOUSE_DESC;
                    str = tv2.clipboard();
                } catch (Exception unused2) {
                }
                MainActivity mainActivity3 = this.f$0;
                mainActivity3.ui.post(new MainActivity$$ExternalSyntheticLambda9(tv2, mainActivity3, str));
                return;
            case 3:
                Tv tv3 = this.f$1;
                MainActivity mainActivity4 = this.f$0;
                ?? obj = new Object();
                try {
                    adb = tv3.adb;
                } catch (Exception e2) {
                    e = e2;
                }
                if (adb != null) {
                    InputStream open = mainActivity4.getAssets().open("tvr-helper.jar");
                    try {
                        Intrinsics.checkNotNull(open);
                        byte[] readBytes = MathKt.readBytes(open);
                        open.close();
                        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                        boolean areEqual = Intrinsics.areEqual(StringsKt.trim(adb.shell(120000L, "pgrep -f 'core[.]Screen off' >/dev/null && echo off")).toString(), "off");
                        obj.element = areEqual;
                        if (areEqual) {
                            Games.run(adb, "on", readBytes);
                        } else {
                            Games.run(adb, "off", readBytes);
                        }
                        mainActivity4.ui.post(new Lg$$ExternalSyntheticLambda2(mainActivity4, e, obj, 13));
                        return;
                    } finally {
                    }
                } else {
                    throw new IOException("not connected");
                }
            case 4:
                final Tv tv4 = this.f$1;
                try {
                    z = true ^ StringsKt.contains(tv4.shell("dumpsys power | grep -m1 mWakefulness="), "Asleep", false);
                } catch (Exception unused3) {
                }
                final MainActivity mainActivity5 = this.f$0;
                mainActivity5.ui.post(new Runnable() { // from class: dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda55
                    @Override // java.lang.Runnable
                    public final void run() {
                        MainActivity mainActivity6 = MainActivity.this;
                        Tv tv5 = tv4;
                        boolean z2 = z;
                        if (!mainActivity6.isFinishing() && mainActivity6.tv == tv5) {
                            if (!z2) {
                                tv5.press(224);
                                Toast.makeText(mainActivity6, Fleet.T("remote_screen.waking_the_tv", new Pair[0]), 0).show();
                                return;
                            }
                            Popup.Builder builder = new Popup.Builder(mainActivity6);
                            builder.message = Fleet.T("remote_screen.put_the_tv_in", new Pair[0]);
                            builder.setPositiveButton(Fleet.T("remote_screen.standby", new Pair[0]), new Talk$$ExternalSyntheticLambda5(3, tv5));
                            builder.setNegativeButton(Fleet.T("common.cancel", new Pair[0]), null);
                            builder.show();
                        }
                    }
                });
                return;
            default:
                MainActivity mainActivity6 = this.f$0;
                Tv tv5 = this.f$1;
                if (!mainActivity6.isFinishing() && mainActivity6.tv == tv5) {
                    Toast.makeText(mainActivity6, Fleet.T("remote.key_no_reaction", new Pair[0]), 0).show();
                    return;
                }
                return;
        }
    }

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda38(MainActivity mainActivity, Tv tv, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
        this.f$1 = tv;
    }
}
