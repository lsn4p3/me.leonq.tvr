package dev.tvremote.phone.media;

import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.remote.Inputs;
import dev.tvremote.core.remote.Lg$$ExternalSyntheticLambda2;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.phone.MainActivity;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$ObjectRef;

/* loaded from: classes.dex */
public final /* synthetic */ class NowApp$tick$1$$ExternalSyntheticLambda3 implements Runnable {
    public final /* synthetic */ int $r8$classId = 0;
    public final /* synthetic */ Object f$0;
    public final /* synthetic */ boolean f$1;
    public final /* synthetic */ Object f$2;
    public final /* synthetic */ Object f$3;
    public final /* synthetic */ Object f$4;
    public final /* synthetic */ Object f$5;

    public /* synthetic */ NowApp$tick$1$$ExternalSyntheticLambda3(NowApp nowApp, boolean z, Ref$ObjectRef ref$ObjectRef, String str, Ref$ObjectRef ref$ObjectRef2, Ref$ObjectRef ref$ObjectRef3) {
        this.f$0 = nowApp;
        this.f$1 = z;
        this.f$2 = ref$ObjectRef;
        this.f$3 = str;
        this.f$4 = ref$ObjectRef2;
        this.f$5 = ref$ObjectRef3;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Object obj = this.f$5;
        boolean z = this.f$1;
        Object obj2 = this.f$2;
        Object obj3 = this.f$3;
        Object obj4 = this.f$4;
        Object obj5 = this.f$0;
        switch (this.$r8$classId) {
            case 0:
                NowApp nowApp = (NowApp) obj5;
                nowApp.asking = false;
                if (z) {
                    nowApp.fine = System.currentTimeMillis();
                }
                Ref$ObjectRef ref$ObjectRef = (Ref$ObjectRef) obj2;
                String str = (String) obj3;
                if (((CharSequence) ref$ObjectRef.element).length() > 0 || z || !Intrinsics.areEqual(str, nowApp.shownFor) || System.currentTimeMillis() - nowApp.fine > 5000) {
                    NowApp.access$show(nowApp, (String) ref$ObjectRef.element, (String) ((Ref$ObjectRef) obj4).element, (byte[]) ((Ref$ObjectRef) obj).element);
                    nowApp.shownFor = str;
                    return;
                }
                return;
            default:
                Remote remote = (Remote) obj5;
                Inputs.Cache cache = (Inputs.Cache) obj4;
                Tv tv = (Tv) obj3;
                Inputs.Input input = (Inputs.Input) obj2;
                String str2 = input.id;
                try {
                    if (z) {
                        Intrinsics.checkNotNull(remote);
                        if (!remote.switchInput(str2)) {
                            throw new IllegalArgumentException("this TV cannot switch inputs from here");
                        }
                    } else {
                        Object obj6 = Inputs.TYPES;
                        Inputs.m14switch(new TalkKt$$ExternalSyntheticLambda2(tv, 9), str2, cache.peek());
                    }
                    e = null;
                } catch (Exception e) {
                    e = e;
                }
                MainActivity mainActivity = (MainActivity) obj;
                mainActivity.ui.post(new Lg$$ExternalSyntheticLambda2(mainActivity, e, input, 29));
                return;
        }
    }

    public /* synthetic */ NowApp$tick$1$$ExternalSyntheticLambda3(boolean z, Remote remote, Inputs.Input input, Inputs.Cache cache, MainActivity mainActivity, Tv tv) {
        this.f$1 = z;
        this.f$0 = remote;
        this.f$2 = input;
        this.f$4 = cache;
        this.f$5 = mainActivity;
        this.f$3 = tv;
    }
}
