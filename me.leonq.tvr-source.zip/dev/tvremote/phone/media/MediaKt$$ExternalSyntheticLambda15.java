package dev.tvremote.phone.media;

import android.widget.Toast;
import dev.tvremote.core.Errors;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Words;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.picker.PickerScreenKt;
import dev.tvremote.phone.picture.Air;
import dev.tvremote.phone.remote.TypingKt;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.Pair;
import kotlin.math.MathKt;
import org.conscrypt.metrics.ConscryptStatsLog;

/* loaded from: classes.dex */
public final /* synthetic */ class MediaKt$$ExternalSyntheticLambda15 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ Exception f$1;

    public /* synthetic */ MediaKt$$ExternalSyntheticLambda15(MainActivity mainActivity, Exception exc, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
        this.f$1 = exc;
    }

    @Override // java.lang.Runnable
    public final void run() {
        String str = "";
        switch (this.$r8$classId) {
            case 0:
                MainActivity mainActivity = this.f$0;
                Exception exc = this.f$1;
                Object obj = Errors.ANDROID;
                ConcurrentHashMap concurrentHashMap = Words.books;
                Fleet.say(mainActivity, Errors.say(Words.lang, exc), true);
                return;
            case 1:
                MainActivity mainActivity2 = this.f$0;
                Exception exc2 = this.f$1;
                Object obj2 = Errors.ANDROID;
                ConcurrentHashMap concurrentHashMap2 = Words.books;
                Toast.makeText(mainActivity2, Errors.say(Words.lang, exc2), 1).show();
                return;
            case 2:
                MainActivity mainActivity3 = this.f$0;
                if (mainActivity3.drawing) {
                    Air.stopDrawing(mainActivity3);
                }
                Air.drawFail(mainActivity3, this.f$1);
                return;
            case 3:
                MainActivity mainActivity4 = this.f$0;
                if (mainActivity4.drawing) {
                    Air.stopDrawing(mainActivity4);
                }
                Air.drawFail(mainActivity4, this.f$1);
                return;
            case 4:
                String message = this.f$1.getMessage();
                MainActivity mainActivity5 = this.f$0;
                PickerScreenKt.message(mainActivity5, TypingKt.explain(mainActivity5, message), true);
                return;
            case 5:
                PickerScreenKt.message(this.f$0, Fleet.T("keys_only.could_not_pair_with", new Pair("error", this.f$1.getMessage())), true);
                return;
            case 6:
                String message2 = this.f$1.getMessage();
                if (message2 != null) {
                    str = message2;
                }
                MathKt.toast(this.f$0, str);
                return;
            case 7:
                String message3 = this.f$1.getMessage();
                if (message3 != null) {
                    str = message3;
                }
                MathKt.toast(this.f$0, str);
                return;
            case 8:
                String message4 = this.f$1.getMessage();
                if (message4 != null) {
                    str = message4;
                }
                MathKt.toast(this.f$0, str);
                return;
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                String message5 = this.f$1.getMessage();
                if (message5 != null) {
                    str = message5;
                }
                MathKt.toast(this.f$0, str);
                return;
            default:
                String message6 = this.f$1.getMessage();
                if (message6 != null) {
                    str = message6;
                }
                MathKt.toast(this.f$0, str);
                return;
        }
    }
}
