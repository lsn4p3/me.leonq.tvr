package dev.tvremote.phone.media;

import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.ontv.Foreground;
import dev.tvremote.core.ontv.RemoteLabels;
import dev.tvremote.core.ontv.Setup$$ExternalSyntheticLambda5;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.remote.Inputs;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.manage.UpdaterKt$$ExternalSyntheticLambda10;
import java.io.File;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyList;
import kotlin.collections.EmptyMap;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$ObjectRef;
import kotlin.math.MathKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class NowApp$tick$1$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ int $r8$classId = 1;
    public final /* synthetic */ Remote f$0;
    public final /* synthetic */ Object f$1;
    public final /* synthetic */ Tv f$2;
    public final /* synthetic */ Object f$3;
    public final /* synthetic */ boolean f$4;

    public /* synthetic */ NowApp$tick$1$$ExternalSyntheticLambda0(Inputs.Cache cache, MainActivity mainActivity, boolean z, Remote remote, Tv tv) {
        this.f$1 = cache;
        this.f$3 = mainActivity;
        this.f$4 = z;
        this.f$0 = remote;
        this.f$2 = tv;
    }

    /* JADX WARN: Type inference failed for: r3v20, types: [java.util.Map, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r3v24, types: [java.util.Map, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r4v0, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    /* JADX WARN: Type inference failed for: r6v0, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    /* JADX WARN: Type inference failed for: r7v0, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    @Override // java.lang.Runnable
    public final void run() {
        String str;
        String label;
        Map map;
        TalkKt$$ExternalSyntheticLambda2 talkKt$$ExternalSyntheticLambda2;
        Tv tv;
        List list;
        switch (this.$r8$classId) {
            case 0:
                NowApp nowApp = (NowApp) this.f$1;
                String str2 = (String) this.f$3;
                ?? obj = new Object();
                Remote remote = this.f$0;
                String str3 = "";
                if (remote == null || (str = remote.getApp()) == null) {
                    str = "";
                }
                obj.element = str;
                ?? obj2 = new Object();
                obj2.element = "";
                ?? obj3 = new Object();
                try {
                    int length = ((CharSequence) obj.element).length();
                    Tv tv2 = this.f$2;
                    byte[] bArr = null;
                    if (length == 0) {
                        Foreground foreground = nowApp.front;
                        if (tv2 != null) {
                            if (tv2.ready()) {
                                tv = tv2;
                            } else {
                                tv = null;
                            }
                            if (tv != null) {
                                talkKt$$ExternalSyntheticLambda2 = new TalkKt$$ExternalSyntheticLambda2(tv, 5);
                                obj.element = foreground.get(talkKt$$ExternalSyntheticLambda2);
                            }
                        }
                        talkKt$$ExternalSyntheticLambda2 = null;
                        obj.element = foreground.get(talkKt$$ExternalSyntheticLambda2);
                    }
                    if (((CharSequence) obj.element).length() > 0 && remote != null && !Intrinsics.areEqual(remote.getKind(), "android")) {
                        if (nowApp.namesFrom != remote || !nowApp.remoteNames.containsKey(obj.element)) {
                            try {
                                List<Remote.App> apps = remote.apps();
                                int mapCapacity = MapsKt__MapsKt.mapCapacity(CollectionsKt__IterablesKt.collectionSizeOrDefault(apps));
                                if (mapCapacity < 16) {
                                    mapCapacity = 16;
                                }
                                map = new LinkedHashMap(mapCapacity);
                                for (Remote.App app : apps) {
                                    map.put(app.id, app.label);
                                }
                            } catch (Exception unused) {
                                map = EmptyMap.INSTANCE;
                            }
                            nowApp.remoteNames = map;
                            nowApp.namesFrom = remote;
                        }
                        String str4 = (String) nowApp.remoteNames.get(obj.element);
                        if (str4 == null) {
                            if (Intrinsics.areEqual(remote.getKind(), "vidaa")) {
                                str3 = (String) obj.element;
                            }
                        } else {
                            str3 = str4;
                        }
                        obj2.element = str3;
                    } else if (((CharSequence) obj.element).length() > 0) {
                        File access$cacheDir = NowApp.access$cacheDir(nowApp, str2);
                        if (tv2 != null && tv2.ready() && remote == null) {
                            if (!Intrinsics.areEqual(nowApp.labelsFor, str2)) {
                                AdbLink adbLink = nowApp.link;
                                if (adbLink != null) {
                                    adbLink.close();
                                }
                                File filesDir = nowApp.a.getFilesDir();
                                Intrinsics.checkNotNullExpressionValue(filesDir, "getFilesDir(...)");
                                AdbLink adbLink2 = new AdbLink(filesDir, str2);
                                nowApp.link = adbLink2;
                                nowApp.labels = new RemoteLabels(adbLink2, new Setup$$ExternalSyntheticLambda5(8, nowApp), access$cacheDir);
                                nowApp.labelsFor = str2;
                            }
                            RemoteLabels remoteLabels = nowApp.labels;
                            if (remoteLabels != null && (label = remoteLabels.label((String) obj.element)) != null) {
                                str3 = label;
                            }
                            obj2.element = str3;
                            RemoteLabels remoteLabels2 = nowApp.labels;
                            if (remoteLabels2 != null) {
                                bArr = remoteLabels2.icon((String) obj.element);
                            }
                            obj3.element = bArr;
                        } else {
                            try {
                                String optString = new JSONObject(MathKt.readText$default(new File(access$cacheDir, "names.json"))).optString((String) obj.element);
                                Intrinsics.checkNotNull(optString);
                                str3 = optString;
                            } catch (Exception unused2) {
                            }
                            obj2.element = str3;
                            File file = new File(access$cacheDir, obj.element + ".png");
                            if (file.length() <= 0) {
                                file = null;
                            }
                            if (file != null) {
                                bArr = MathKt.readBytes(file);
                            }
                            obj3.element = bArr;
                        }
                    }
                } catch (Exception unused3) {
                }
                nowApp.a.ui.post(new NowApp$tick$1$$ExternalSyntheticLambda3(nowApp, this.f$4, (Ref$ObjectRef) obj, str2, (Ref$ObjectRef) obj2, (Ref$ObjectRef) obj3));
                return;
            default:
                Inputs.Cache cache = (Inputs.Cache) this.f$1;
                final boolean z = this.f$4;
                final Remote remote2 = this.f$0;
                final Tv tv3 = this.f$2;
                try {
                    list = cache.get(false, new Function0() { // from class: dev.tvremote.phone.remote.InputsMenuKt$$ExternalSyntheticLambda1
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            if (z) {
                                Remote remote3 = remote2;
                                Intrinsics.checkNotNull(remote3);
                                return remote3.inputs();
                            }
                            Object obj4 = Inputs.TYPES;
                            Tv tv4 = tv3;
                            Intrinsics.checkNotNull(tv4);
                            try {
                                return Inputs.parseUnsafe(tv4.shell("dumpsys tv_input 2>/dev/null; echo '#--tvr-inputs--'; dumpsys hdmi_control 2>/dev/null"));
                            } catch (Exception unused4) {
                                return EmptyList.INSTANCE;
                            }
                        }
                    });
                } catch (Exception unused4) {
                    list = null;
                }
                MainActivity mainActivity = (MainActivity) this.f$3;
                mainActivity.ui.post(new UpdaterKt$$ExternalSyntheticLambda10(mainActivity, list, z, cache));
                return;
        }
    }

    public /* synthetic */ NowApp$tick$1$$ExternalSyntheticLambda0(Remote remote, NowApp nowApp, Tv tv, String str, boolean z) {
        this.f$0 = remote;
        this.f$1 = nowApp;
        this.f$2 = tv;
        this.f$3 = str;
        this.f$4 = z;
    }
}
