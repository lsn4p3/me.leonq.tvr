package dev.tvremote.phone.media;

import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.picture.Tv$$ExternalSyntheticLambda4;
import java.io.IOException;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;

/* loaded from: classes.dex */
public final /* synthetic */ class PlayingBar$$ExternalSyntheticLambda13 implements Function0 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Tv f$0;

    public /* synthetic */ PlayingBar$$ExternalSyntheticLambda13(Tv tv, int i) {
        this.$r8$classId = i;
        this.f$0 = tv;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        switch (this.$r8$classId) {
            case 0:
                Adb adb = this.f$0.adb;
                if (adb != null) {
                    return adb;
                }
                throw new IOException("not connected");
            default:
                new Thread(new Tv$$ExternalSyntheticLambda4(this.f$0, 3)).start();
                return Unit.INSTANCE;
        }
    }
}
