package dev.tvremote.phone.media;

import android.widget.Toast;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.scenes.Scenes;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda15;
import dev.tvremote.phone.ir.IrRemoteKt;
import dev.tvremote.phone.ir.IrState;
import dev.tvremote.phone.picker.PickerScreenKt;
import java.util.HashMap;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import org.conscrypt.metrics.ConscryptStatsLog;

/* loaded from: classes.dex */
public final /* synthetic */ class MediaKt$$ExternalSyntheticLambda4 implements Function0 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ MediaKt$$ExternalSyntheticLambda4(MainActivity mainActivity, String str) {
        this.$r8$classId = 1;
        this.f$1 = str;
        this.f$0 = mainActivity;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        String str;
        String str2 = null;
        String ip = this.f$1;
        MainActivity mainActivity = this.f$0;
        switch (this.$r8$classId) {
            case 0:
                Fleet.confirmShare(mainActivity, ip, new MediaKt$$ExternalSyntheticLambda4(mainActivity, ip, 6));
                return Unit.INSTANCE;
            case 1:
                Object obj = IrState.catalog;
                Intrinsics.checkNotNullParameter(ip, "<set-?>");
                IrState.auto = ip;
                IrRemoteKt.irAuto$default(mainActivity, null, null, null, 15);
                return Unit.INSTANCE;
            case 2:
                IrRemoteKt.irLearn$default(mainActivity, Fleet.T("ir.auto_noadb", new Pair("name", ip)), Fleet.T("ir.auto_noadb_sub", new Pair[0]), 0, 4);
                return Unit.INSTANCE;
            case 3:
                IrRemoteKt.irLearn$default(mainActivity, Fleet.T("ir.auto_noadb", new Pair("name", ip)), Fleet.T("ir.auto_noadb_sub", new Pair[0]), 0, 4);
                return Unit.INSTANCE;
            case 4:
                IrRemoteKt.irAuto$default(mainActivity, Fleet.T("ir.auto_noadb", new Pair("name", ip)), Fleet.T("ir.auto_noadb_sub", new Pair[0]), null, 12);
                return Unit.INSTANCE;
            case 5:
                IrRemoteKt.irAuto$default(mainActivity, Fleet.T("ir.auto_noadb", new Pair("name", ip)), Fleet.T("ir.auto_noadb_sub", new Pair[0]), null, 12);
                return Unit.INSTANCE;
            case 6:
                Fleet.openLink(mainActivity, ip);
                Toast.makeText(mainActivity, Fleet.T("notify.sent", new Pair[0]), 0).show();
                return Unit.INSTANCE;
            case 7:
                mainActivity.getClass();
                Intrinsics.checkNotNullParameter(ip, "ip");
                String str3 = (String) mainActivity.route.get(ip);
                if (str3 == null) {
                    str3 = ip;
                }
                if (!str3.equals(ip)) {
                    str2 = ip;
                }
                mainActivity.connect$android_release(str3, str2);
                return Unit.INSTANCE;
            case 8:
                PickerScreenKt.askRemove(mainActivity, ip);
                return Unit.INSTANCE;
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                mainActivity.getPrefs$android_release().edit().remove("kind:" + ip).apply();
                mainActivity.connect$android_release(ip, null);
                return Unit.INSTANCE;
            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                HashMap hashMap = Scenes.KEYS;
                if (ip.equals("roku")) {
                    str = "HOME";
                } else {
                    str = "SETTINGS";
                }
                Object obj2 = hashMap.get(str);
                Intrinsics.checkNotNull(obj2);
                int intValue = ((Number) obj2).intValue();
                int i = MainActivity.$r8$clinit;
                mainActivity.press$android_release(true, intValue);
                mainActivity.getWindow().getDecorView().postDelayed(new MainActivity$$ExternalSyntheticLambda15(mainActivity, 26), 300L);
                return Unit.INSTANCE;
            default:
                Fleet.openLink(mainActivity, ip);
                return Unit.INSTANCE;
        }
    }

    public /* synthetic */ MediaKt$$ExternalSyntheticLambda4(MainActivity mainActivity, String str, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
        this.f$1 = str;
    }
}
