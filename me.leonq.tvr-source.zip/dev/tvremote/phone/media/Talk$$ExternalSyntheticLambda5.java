package dev.tvremote.phone.media;

import android.content.DialogInterface;
import android.os.Build;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.remote.CodePairing;
import dev.tvremote.core.web.Cancel;

/* loaded from: classes.dex */
public final /* synthetic */ class Talk$$ExternalSyntheticLambda5 implements DialogInterface.OnClickListener {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;

    public /* synthetic */ Talk$$ExternalSyntheticLambda5(int i, Object obj) {
        this.$r8$classId = i;
        this.f$0 = obj;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i) {
        switch (this.$r8$classId) {
            case 0:
                if (Build.VERSION.SDK_INT >= 23) {
                    ((Talk) this.f$0).a.requestPermissions(new String[]{"android.permission.RECORD_AUDIO"}, 31);
                    return;
                }
                return;
            case 1:
                ((Cancel) this.f$0).stop();
                return;
            case 2:
                ((CodePairing) this.f$0).close();
                return;
            default:
                Tv tv = (Tv) this.f$0;
                if (tv.ready()) {
                    tv.press(223);
                    return;
                }
                return;
        }
    }
}
