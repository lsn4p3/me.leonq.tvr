package dev.tvremote.phone.media;

/* loaded from: classes.dex */
public abstract /* synthetic */ class Talk$$ExternalSyntheticApiModelOutline2 {
}
