package dev.tvremote.phone.media;

import android.content.DialogInterface;
import android.widget.EditText;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticLambda4;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda10;
import dev.tvremote.phone.manage.InfoScreensKt$$ExternalSyntheticLambda25;
import dev.tvremote.phone.picker.AdbHelpKt;
import dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda47;
import dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda9;
import dev.tvremote.phone.picker.AppRow;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.tvapps.ApkCert$$ExternalSyntheticLambda0;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.CollectionsKt__MutableCollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Ref$BooleanRef;
import kotlin.jvm.internal.Ref$ObjectRef;
import kotlin.text.StringsKt;

/* loaded from: classes.dex */
public final /* synthetic */ class MediaKt$$ExternalSyntheticLambda10 implements DialogInterface.OnClickListener {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;
    public final /* synthetic */ Object f$1;

    public /* synthetic */ MediaKt$$ExternalSyntheticLambda10(int i, Object obj, Object obj2) {
        this.$r8$classId = i;
        this.f$0 = obj;
        this.f$1 = obj2;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i) {
        String T;
        String str;
        String str2;
        int i2 = 9;
        int i3 = 0;
        Object obj = this.f$1;
        Object obj2 = this.f$0;
        switch (this.$r8$classId) {
            case 0:
                String obj3 = StringsKt.trim(((EditText) obj2).getText().toString()).toString();
                if (obj3.length() > 0) {
                    ((Function1) obj).invoke(obj3);
                    return;
                }
                return;
            case 1:
                new Thread(new InfoScreensKt$$ExternalSyntheticLambda25(1, (MainActivity) obj2, (Ref$ObjectRef) obj)).start();
                return;
            case 2:
                String obj4 = StringsKt.trim(((EditText) obj2).getText().toString()).toString();
                MainActivity mainActivity = (MainActivity) obj;
                Remote remote = mainActivity.basic;
                if (obj4.length() > 0 && remote != null) {
                    if (StringsKt.contains(obj4, ":", false)) {
                        remote.launch(obj4);
                        return;
                    } else {
                        AdbHelpKt.tvJob(mainActivity, new AdbHelpKt$$ExternalSyntheticLambda47(mainActivity, remote, obj4, i3));
                        return;
                    }
                }
                return;
            case 3:
                ((Ref$BooleanRef) obj2).element = true;
                AdbHelpKt.installSetupByHand((MainActivity) obj);
                return;
            case 4:
                MainActivity mainActivity2 = (MainActivity) obj2;
                Remote remote2 = (Remote) obj;
                AdbHelpKt.openHome(mainActivity2, remote2, new Census$$ExternalSyntheticLambda4(19));
                mainActivity2.ui.postDelayed(new MediaKt$$ExternalSyntheticLambda9(mainActivity2, remote2, 4), 800L);
                return;
            default:
                ArrayList arrayList = new ArrayList();
                for (Object obj5 : (List) obj2) {
                    if (((AppRow) obj5).picked) {
                        arrayList.add(obj5);
                    }
                }
                ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList));
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    arrayList2.add(((AppRow) it.next()).pkg);
                }
                ArrayList arrayList3 = new ArrayList();
                Iterator it2 = arrayList.iterator();
                while (it2.hasNext()) {
                    CollectionsKt__MutableCollectionsKt.addAll(((AppRow) it2.next()).on, arrayList3);
                }
                List distinct = CollectionsKt.distinct(arrayList3);
                if (arrayList2.size() == 1) {
                    T = ((AppRow) arrayList.get(0)).name;
                } else {
                    T = Fleet.T("many_tvs.apps", new Pair("n", Integer.valueOf(arrayList2.size())));
                }
                String str3 = T;
                MainActivity mainActivity3 = (MainActivity) obj;
                Popup.Builder builder = new Popup.Builder(mainActivity3);
                String T2 = Fleet.T("many_tvs.remove_from_these_tvs", new Pair("what", str3));
                if (arrayList2.size() > 1) {
                    str = "\n";
                    str2 = ApkSigner$$ExternalSyntheticOutline0.m(str, CollectionsKt.joinToString$default(arrayList, "\n", null, null, new ApkCert$$ExternalSyntheticLambda0(i2), 30));
                } else {
                    str = "\n";
                    str2 = "";
                }
                builder.message = T2 + str2 + "\n\n" + Fleet.T("many_tvs.tvs", new Pair[0]) + str + CollectionsKt.joinToString$default(distinct, "\n", null, null, new MainActivity$$ExternalSyntheticLambda10(mainActivity3, i2), 30);
                builder.setPositiveButton(Fleet.T("fleet.remove", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda9(mainActivity3, str3, distinct, arrayList2));
                builder.setNegativeButton(Fleet.T("common.cancel", new Pair[0]), null);
                builder.show();
                return;
        }
    }
}
