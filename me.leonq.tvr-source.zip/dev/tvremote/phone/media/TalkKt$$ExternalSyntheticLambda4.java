package dev.tvremote.phone.media;

import android.widget.TextView;
import dev.tvremote.core.Census$$ExternalSyntheticLambda6;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Diagnose;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Words;
import dev.tvremote.core.Words$$ExternalSyntheticLambda1;
import dev.tvremote.core.adb.Adb$$ExternalSyntheticLambda5;
import dev.tvremote.core.adb.AdbPrompt;
import dev.tvremote.core.ontv.Checkout;
import dev.tvremote.core.ontv.Power$$ExternalSyntheticLambda2;
import dev.tvremote.core.remote.Lg$$ExternalSyntheticLambda2;
import dev.tvremote.core.scenes.Voice;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.picker.AdbHelpKt;
import dev.tvremote.phone.picker.ManyTvsKt;
import dev.tvremote.phone.picker.ManyTvsKt$$ExternalSyntheticLambda25;
import dev.tvremote.phone.picker.ManyTvsKt$$ExternalSyntheticLambda6;
import dev.tvremote.phone.picker.PickerScreenKt;
import dev.tvremote.phone.ui.Popup;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import javax.net.ssl.SSLException;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyMap;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgressionIterator;
import kotlin.ranges.IntRange;
import kotlin.text.Charsets;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import org.conscrypt.PSKKeyManager;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class TalkKt$$ExternalSyntheticLambda4 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ Object f$1;
    public final /* synthetic */ Object f$2;
    public final /* synthetic */ Object f$3;
    public final /* synthetic */ Object f$4;
    public final /* synthetic */ Object f$5;

    public /* synthetic */ TalkKt$$ExternalSyntheticLambda4(MainActivity mainActivity, String str, Object obj, Object obj2, Object obj3, Object obj4, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
        this.f$1 = str;
        this.f$2 = obj;
        this.f$3 = obj2;
        this.f$4 = obj3;
        this.f$5 = obj4;
    }

    /* JADX WARN: Removed duplicated region for block: B:110:0x03f6  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x009a  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x00c5  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x010f  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x018d A[LOOP:3: B:53:0x018b->B:54:0x018d, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:58:0x01b9  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x01c4  */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void run() {
        String str;
        boolean equals;
        JSONObject jSONObject;
        List list;
        int i;
        List<String> sortedWith;
        int size;
        int i2;
        int i3;
        JSONArray optJSONArray;
        String string;
        switch (this.$r8$classId) {
            case 0:
                MainActivity mainActivity = this.f$0;
                String str2 = (String) this.f$1;
                Map map = (Map) this.f$2;
                Object obj = this.f$3;
                Voice.Prefs prefs = (Voice.Prefs) this.f$4;
                Census$$ExternalSyntheticLambda6 census$$ExternalSyntheticLambda6 = (Census$$ExternalSyntheticLambda6) this.f$5;
                if (!mainActivity.isFinishing() && Intrinsics.areEqual(mainActivity.host, str2)) {
                    mainActivity.appNames = map;
                    mainActivity.appNamesFor = str2;
                    mainActivity.voicePins = obj;
                    Voice voice = Voice.INSTANCE;
                    Voice.prefs = prefs;
                    mainActivity.voicePinsAt = System.currentTimeMillis();
                }
                if (census$$ExternalSyntheticLambda6 != null) {
                    census$$ExternalSyntheticLambda6.invoke();
                    return;
                }
                return;
            case 1:
                int i4 = MainActivity.$r8$clinit;
                AdbPrompt adbPrompt = AdbPrompt.INSTANCE;
                String str3 = "error";
                String host = (String) this.f$1;
                Intrinsics.checkNotNullParameter(host, "host");
                String str4 = (String) this.f$2;
                String str5 = (String) this.f$3;
                try {
                    HttpURLConnection openSetup = AdbPrompt.openSetup(host, str4, "/api/adb/allow");
                    openSetup.setReadTimeout(60000);
                    openSetup.setRequestMethod("POST");
                    openSetup.setDoOutput(true);
                    openSetup.setRequestProperty("Content-Type", "application/json");
                    OutputStream outputStream = openSetup.getOutputStream();
                    try {
                        String jSONObject2 = new JSONObject().put("fingerprint", str5).put("wait", 30).put("others", true).toString();
                        Intrinsics.checkNotNullExpressionValue(jSONObject2, "toString(...)");
                        Charset charset = Charsets.UTF_8;
                        byte[] bytes = jSONObject2.getBytes(charset);
                        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                        outputStream.write(bytes);
                        outputStream.close();
                        int responseCode = openSetup.getResponseCode();
                        if (responseCode != 200) {
                            if (responseCode == 401 || responseCode == 403) {
                                str = "forgotten";
                            } else {
                                str = "error";
                            }
                        } else {
                            InputStream inputStream = openSetup.getInputStream();
                            Intrinsics.checkNotNullExpressionValue(inputStream, "getInputStream(...)");
                            str = new JSONObject(MathKt.readText(new BufferedReader(new InputStreamReader(inputStream, charset), 8192))).optString("result");
                        }
                        Intrinsics.checkNotNull(str);
                    } finally {
                    }
                } catch (SSLException unused) {
                    str = str3;
                    equals = str.equals("forgotten");
                    MainActivity mainActivity2 = this.f$0;
                    if (equals) {
                    }
                    mainActivity2.ui.post(new Lg$$ExternalSyntheticLambda2(mainActivity2, (TextView) this.f$5, str, 9));
                    return;
                } catch (Exception unused2) {
                    str3 = "unreachable";
                    str = str3;
                    equals = str.equals("forgotten");
                    MainActivity mainActivity22 = this.f$0;
                    if (equals) {
                    }
                    mainActivity22.ui.post(new Lg$$ExternalSyntheticLambda2(mainActivity22, (TextView) this.f$5, str, 9));
                    return;
                }
                equals = str.equals("forgotten");
                MainActivity mainActivity222 = this.f$0;
                if (equals) {
                    mainActivity222.getPrefs$android_release().edit().remove("tvs:".concat((String) this.f$4)).apply();
                }
                mainActivity222.ui.post(new Lg$$ExternalSyntheticLambda2(mainActivity222, (TextView) this.f$5, str, 9));
                return;
            case 2:
                MainActivity mainActivity3 = this.f$0;
                String str6 = (String) this.f$1;
                Diagnose.Result result = (Diagnose.Result) this.f$2;
                String str7 = (String) this.f$3;
                String str8 = (String) this.f$4;
                String str9 = (String) this.f$5;
                if (!mainActivity3.isFinishing() && Intrinsics.areEqual(mainActivity3.getPickerMsg$android_release().getText().toString(), str6)) {
                    if (result == null) {
                        PickerScreenKt.message(mainActivity3, str7, true);
                        return;
                    }
                    Regex regex = Diagnose.OTHER_BRANDS;
                    ConcurrentHashMap concurrentHashMap = Words.books;
                    String lang = Words.lang;
                    Intrinsics.checkNotNullParameter(lang, "lang");
                    Pair say = Diagnose.say(new Diagnose.Facts(result.kind, result.ip, EmptyMap.INSTANCE, Diagnose.Net.NA, false, null, false, result.found, false, result.brand, PSKKeyManager.MAX_KEY_LENGTH_BYTES), result.code, lang);
                    String m = Census$$ExternalSyntheticOutline0.m((String) say.first, "\n", (String) say.second);
                    if (result.code.equals("off") || result.code.equals("closed")) {
                        m = Census$$ExternalSyntheticOutline0.m(m, "\n", Fleet.T("diagnosing.or_tap_the_power", new Pair[0]));
                    }
                    if (result.code.equals("up")) {
                        m = m + "\n\n(" + str7 + ")";
                    }
                    PickerScreenKt.message(mainActivity3, m, !result.code.equals("up"));
                    if (result.code.equals("wireless")) {
                        AdbHelpKt.offerWireless(mainActivity3, str8, str9);
                    }
                    Diagnose.Found found = result.found;
                    if (result.code.equals("moved") && found != null) {
                        Popup.Builder builder = new Popup.Builder(mainActivity3);
                        builder.title = Fleet.T("diagnosing.the_tv_has_a", new Pair[0]);
                        builder.message = Fleet.T("diagnosing.is_at_it_was", new Pair("name", found.name), new Pair("ip", found.ip), new Pair("ip2", str8));
                        builder.setPositiveButton(Fleet.T("diagnosing.use_the_new_address", new Pair[0]), new ManyTvsKt$$ExternalSyntheticLambda6(mainActivity3, found, str9, 5));
                        builder.setNegativeButton(Fleet.T("common.close", new Pair[0]), null);
                        builder.show();
                        return;
                    }
                    return;
                }
                return;
            default:
                ((Popup) this.f$1).dismiss();
                MainActivity mainActivity4 = this.f$0;
                if (!mainActivity4.isFinishing()) {
                    HashMap hashMap = (HashMap) this.f$2;
                    ManyTvsKt.checkoutNames = new HashMap(hashMap);
                    try {
                        string = mainActivity4.getPrefs$android_release().getString("checkout", null);
                    } catch (Exception unused3) {
                    }
                    if (string != null) {
                        jSONObject = new JSONObject(string);
                        if (jSONObject == null && (optJSONArray = jSONObject.optJSONArray("apps")) != null) {
                            LinkedHashMap linkedHashMap = Checkout.SUGGEST;
                            IntRange until = MathKt.until(0, optJSONArray.length());
                            ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until));
                            Iterator it = until.iterator();
                            while (((IntProgressionIterator) it).hasNext) {
                                arrayList.add(optJSONArray.optString(((IntProgressionIterator) it).nextInt()));
                            }
                            list = Checkout.clean(arrayList);
                        } else {
                            list = null;
                        }
                        i = 25;
                        if (jSONObject != null && jSONObject.has("volume")) {
                            LinkedHashMap linkedHashMap2 = Checkout.SUGGEST;
                            i = MathKt.coerceIn(jSONObject.optInt("volume", 25), 0, 100);
                        }
                        Checkout.Config config = new Checkout.Config(list, i);
                        if (list == null) {
                            Set keySet = Checkout.SUGGEST.keySet();
                            Intrinsics.checkNotNullExpressionValue(keySet, "<get-keys>(...)");
                            list = CollectionsKt.toList(keySet);
                        }
                        Set set = CollectionsKt.toSet(list);
                        HashMap hashMap2 = (HashMap) this.f$3;
                        Set keySet2 = hashMap2.keySet();
                        Intrinsics.checkNotNullExpressionValue(keySet2, "<get-keys>(...)");
                        ArrayList arrayList2 = new ArrayList();
                        for (Object obj2 : keySet2) {
                            String str10 = (String) obj2;
                            LinkedHashMap linkedHashMap3 = Checkout.SUGGEST;
                            Intrinsics.checkNotNull(str10);
                            if (Checkout.blocked(str10) == null) {
                                arrayList2.add(obj2);
                            }
                        }
                        sortedWith = CollectionsKt.sortedWith(arrayList2, MathKt.compareBy(new Words$$ExternalSyntheticLambda1(13, set), new Power$$ExternalSyntheticLambda2(hashMap2, 1), new Power$$ExternalSyntheticLambda2(hashMap, 2)));
                        ArrayList arrayList3 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(sortedWith));
                        for (String str11 : sortedWith) {
                            String str12 = (String) hashMap.get(str11);
                            if (str12 == null) {
                                Intrinsics.checkNotNull(str11);
                                str12 = StringsKt.substringAfterLast(str11, '.', str11);
                            }
                            Integer num = (Integer) hashMap2.get(str11);
                            if (num != null) {
                                i3 = num.intValue();
                            } else {
                                i3 = 0;
                            }
                            arrayList3.add(str12 + "  ·  " + Fleet.T("fleet.on_tvs", new Pair("n", Integer.valueOf(i3)), new Pair("total", Integer.valueOf(((HashSet) this.f$4).size()))));
                        }
                        String[] strArr = (String[]) arrayList3.toArray(new String[0]);
                        size = sortedWith.size();
                        boolean[] zArr = new boolean[size];
                        for (i2 = 0; i2 < size; i2++) {
                            zArr[i2] = set.contains(sortedWith.get(i2));
                        }
                        Adb$$ExternalSyntheticLambda5 adb$$ExternalSyntheticLambda5 = new Adb$$ExternalSyntheticLambda5(mainActivity4, config, (List) this.f$5, 6);
                        Popup.Builder builder2 = new Popup.Builder(mainActivity4);
                        builder2.title = Fleet.T("fleet.co_apps", new Pair[0]);
                        if (!sortedWith.isEmpty()) {
                            builder2.message = Fleet.T("fleet.co_none", new Pair[0]);
                        } else {
                            String[] items = strArr;
                            ManyTvsKt$$ExternalSyntheticLambda25 manyTvsKt$$ExternalSyntheticLambda25 = new ManyTvsKt$$ExternalSyntheticLambda25(zArr, 1);
                            Intrinsics.checkNotNullParameter(items, "items");
                            builder2.choices = new Triple(items, zArr, manyTvsKt$$ExternalSyntheticLambda25);
                        }
                        builder2.setPositiveButton(Fleet.T("draw.next", new Pair[0]), new ManyTvsKt$$ExternalSyntheticLambda6(adb$$ExternalSyntheticLambda5, sortedWith, zArr));
                        builder2.setNegativeButton(Fleet.T("common.cancel", new Pair[0]), null);
                        builder2.show();
                        return;
                    }
                    jSONObject = null;
                    if (jSONObject == null) {
                    }
                    list = null;
                    i = 25;
                    if (jSONObject != null) {
                        LinkedHashMap linkedHashMap22 = Checkout.SUGGEST;
                        i = MathKt.coerceIn(jSONObject.optInt("volume", 25), 0, 100);
                    }
                    Checkout.Config config2 = new Checkout.Config(list, i);
                    if (list == null) {
                    }
                    Set set2 = CollectionsKt.toSet(list);
                    HashMap hashMap22 = (HashMap) this.f$3;
                    Set keySet22 = hashMap22.keySet();
                    Intrinsics.checkNotNullExpressionValue(keySet22, "<get-keys>(...)");
                    ArrayList arrayList22 = new ArrayList();
                    while (r12.hasNext()) {
                    }
                    sortedWith = CollectionsKt.sortedWith(arrayList22, MathKt.compareBy(new Words$$ExternalSyntheticLambda1(13, set2), new Power$$ExternalSyntheticLambda2(hashMap22, 1), new Power$$ExternalSyntheticLambda2(hashMap, 2)));
                    ArrayList arrayList32 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(sortedWith));
                    while (r12.hasNext()) {
                    }
                    String[] strArr2 = (String[]) arrayList32.toArray(new String[0]);
                    size = sortedWith.size();
                    boolean[] zArr2 = new boolean[size];
                    while (i2 < size) {
                    }
                    Adb$$ExternalSyntheticLambda5 adb$$ExternalSyntheticLambda52 = new Adb$$ExternalSyntheticLambda5(mainActivity4, config2, (List) this.f$5, 6);
                    Popup.Builder builder22 = new Popup.Builder(mainActivity4);
                    builder22.title = Fleet.T("fleet.co_apps", new Pair[0]);
                    if (!sortedWith.isEmpty()) {
                    }
                    builder22.setPositiveButton(Fleet.T("draw.next", new Pair[0]), new ManyTvsKt$$ExternalSyntheticLambda6(adb$$ExternalSyntheticLambda52, sortedWith, zArr2));
                    builder22.setNegativeButton(Fleet.T("common.cancel", new Pair[0]), null);
                    builder22.show();
                    return;
                }
                return;
        }
    }

    public /* synthetic */ TalkKt$$ExternalSyntheticLambda4(Popup popup, MainActivity mainActivity, HashMap hashMap, HashMap hashMap2, HashSet hashSet, List list) {
        this.$r8$classId = 3;
        this.f$1 = popup;
        this.f$0 = mainActivity;
        this.f$2 = hashMap;
        this.f$3 = hashMap2;
        this.f$4 = hashSet;
        this.f$5 = list;
    }

    public /* synthetic */ TalkKt$$ExternalSyntheticLambda4(String str, String str2, String str3, MainActivity mainActivity, String str4, TextView textView) {
        this.$r8$classId = 1;
        this.f$1 = str;
        this.f$2 = str2;
        this.f$3 = str3;
        this.f$0 = mainActivity;
        this.f$4 = str4;
        this.f$5 = textView;
    }
}
