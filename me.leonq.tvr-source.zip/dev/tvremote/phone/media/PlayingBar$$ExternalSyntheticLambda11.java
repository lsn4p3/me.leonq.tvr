package dev.tvremote.phone.media;

import dev.tvremote.phone.ListenService;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.WorkService;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class PlayingBar$$ExternalSyntheticLambda11 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ PlayingBar f$0;
    public final /* synthetic */ JSONObject f$1;

    public /* synthetic */ PlayingBar$$ExternalSyntheticLambda11(PlayingBar playingBar, JSONObject jSONObject, int i) {
        this.$r8$classId = i;
        this.f$0 = playingBar;
        this.f$1 = jSONObject;
    }

    @Override // java.lang.Runnable
    public final void run() {
        JSONObject jSONObject = this.f$1;
        PlayingBar playingBar = this.f$0;
        switch (this.$r8$classId) {
            case 0:
                playingBar.o = jSONObject;
                playingBar.at = System.currentTimeMillis();
                playingBar.draw();
                return;
            default:
                playingBar.asking = false;
                playingBar.o = jSONObject;
                MainActivity mainActivity = playingBar.a;
                playingBar.oHost = mainActivity.host;
                playingBar.at = System.currentTimeMillis();
                playingBar.draw();
                WorkService.Companion companion = ListenService.Companion;
                JSONObject jSONObject2 = playingBar.o;
                String str = mainActivity.host;
                if (str == null) {
                    str = "";
                }
                WorkService.Companion.show(mainActivity.title$android_release(str), jSONObject2);
                return;
        }
    }
}
