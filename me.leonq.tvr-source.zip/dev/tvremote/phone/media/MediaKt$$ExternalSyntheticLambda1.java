package dev.tvremote.phone.media;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Errors;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Words;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.adb.Pkg;
import dev.tvremote.core.manage.Jobs$$ExternalSyntheticLambda0;
import dev.tvremote.core.manage.Manage;
import dev.tvremote.core.ontv.Rescue;
import dev.tvremote.core.ontv.Setup;
import dev.tvremote.core.ontv.Setup$$ExternalSyntheticLambda5;
import dev.tvremote.core.remote.Vidaa$$ExternalSyntheticLambda3;
import dev.tvremote.core.web.Cancel;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda6;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda7;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda10;
import dev.tvremote.phone.picker.AppRow;
import dev.tvremote.phone.picker.ManyTvsKt;
import dev.tvremote.phone.picker.ManyTvsKt$$ExternalSyntheticLambda41;
import dev.tvremote.phone.picker.NetKt$$ExternalSyntheticLambda3;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.phone.ui.UiKt;
import dev.tvremote.tvapps.ApkCert$$ExternalSyntheticLambda0;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$LongRef;
import kotlin.jvm.internal.Ref$ObjectRef;
import kotlin.math.MathKt;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class MediaKt$$ExternalSyntheticLambda1 implements Runnable {
    public final /* synthetic */ int $r8$classId = 1;
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ Serializable f$1;
    public final /* synthetic */ Object f$2;
    public final /* synthetic */ Serializable f$3;
    public final /* synthetic */ Serializable f$4;
    public final /* synthetic */ Object f$5;
    public final /* synthetic */ Object f$6;
    public final /* synthetic */ Popup f$7;

    public /* synthetic */ MediaKt$$ExternalSyntheticLambda1(MainActivity mainActivity, Popup popup, HashMap hashMap, List list, HashSet hashSet, ArrayList arrayList, HashMap hashMap2, HashMap hashMap3) {
        this.f$0 = mainActivity;
        this.f$7 = popup;
        this.f$1 = hashMap;
        this.f$2 = list;
        this.f$3 = hashSet;
        this.f$4 = arrayList;
        this.f$5 = hashMap2;
        this.f$6 = hashMap3;
    }

    /* JADX WARN: Type inference failed for: r22v0, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    @Override // java.lang.Runnable
    public final void run() {
        String str;
        InputStream openInputStream;
        String str2;
        final List list;
        String str3;
        float f;
        Character ch;
        char c;
        boolean z;
        String str4;
        int i = 7;
        int i2 = 8;
        int i3 = 1;
        switch (this.$r8$classId) {
            case 0:
                MainActivity mainActivity = this.f$0;
                String str5 = (String) this.f$1;
                Uri uri = (Uri) this.f$2;
                Ref$LongRef ref$LongRef = (Ref$LongRef) this.f$3;
                Ref$ObjectRef ref$ObjectRef = (Ref$ObjectRef) this.f$4;
                JSONObject jSONObject = (JSONObject) this.f$5;
                Cancel cancel = (Cancel) this.f$6;
                Popup popup = this.f$7;
                File filesDir = mainActivity.getFilesDir();
                Intrinsics.checkNotNullExpressionValue(filesDir, "getFilesDir(...)");
                AdbLink adbLink = new AdbLink(filesDir, str5);
                try {
                    try {
                        openInputStream = mainActivity.getContentResolver().openInputStream(uri);
                        try {
                        } catch (Throwable th) {
                            try {
                                throw th;
                            } catch (Throwable th2) {
                                MathKt.closeFinally(openInputStream, th);
                                throw th2;
                            }
                        }
                    } catch (Exception e) {
                        Object obj = Errors.ANDROID;
                        ConcurrentHashMap concurrentHashMap = Words.books;
                        String say = Errors.say(Words.lang, e);
                        adbLink.close();
                        str = say;
                    }
                    if (openInputStream != null) {
                        new Manage(adbLink, null, mainActivity.getCacheDir(), null).cast(openInputStream, ref$LongRef.element, (String) ref$ObjectRef.element, jSONObject, cancel);
                        openInputStream.close();
                        adbLink.close();
                        str = null;
                        mainActivity.ui.post(new Jobs$$ExternalSyntheticLambda0(popup, mainActivity, cancel, str, ref$ObjectRef));
                        return;
                    }
                    throw new IOException("cannot read the file");
                } catch (Throwable th3) {
                    adbLink.close();
                    throw th3;
                }
            default:
                Setup$$ExternalSyntheticLambda5 setup$$ExternalSyntheticLambda5 = new Setup$$ExternalSyntheticLambda5(10, (ArrayList) this.f$4);
                MainActivity mainActivity2 = this.f$0;
                if (mainActivity2.isFinishing()) {
                    setup$$ExternalSyntheticLambda5.invoke();
                    return;
                }
                this.f$7.dismiss();
                LinkedHashMap linkedHashMap = new LinkedHashMap();
                for (Map.Entry entry : ((HashMap) this.f$1).entrySet()) {
                    String pkg = (String) entry.getKey();
                    Intrinsics.checkNotNullParameter(pkg, "pkg");
                    Regex regex = Pkg.RE;
                    if (!Pkg.RE.matches(pkg)) {
                        str4 = "bad package name";
                    } else {
                        String[] strArr = Setup.GOOGLE;
                        if (Rescue.mustKeep(pkg)) {
                            str4 = "protected: the TV needs this app";
                        } else {
                            str4 = null;
                        }
                    }
                    if (str4 == null && !pkg.equals("com.tailscale.ipn")) {
                        linkedHashMap.put(entry.getKey(), entry.getValue());
                    }
                }
                ArrayList arrayList = new ArrayList(linkedHashMap.size());
                for (Map.Entry entry2 : linkedHashMap.entrySet()) {
                    String str6 = (String) entry2.getKey();
                    List list2 = (List) entry2.getValue();
                    HashMap hashMap = (HashMap) this.f$5;
                    String str7 = (String) hashMap.get(str6);
                    if (str7 == null) {
                        str7 = StringsKt.substringAfterLast(str6, '.', str6);
                    }
                    String str8 = str7;
                    if (hashMap.get(str6) != null) {
                        z = true;
                    } else {
                        z = false;
                    }
                    arrayList.add(new AppRow(str6, str8, list2, z));
                }
                List sortedWith = CollectionsKt.sortedWith(arrayList, MathKt.compareBy(new ApkCert$$ExternalSyntheticLambda0(i), new ApkCert$$ExternalSyntheticLambda0(i2)));
                if (sortedWith.isEmpty()) {
                    setup$$ExternalSyntheticLambda5.invoke();
                    ManyTvsKt.toast(mainActivity2, Fleet.T("fleet.no_apps", new Pair[0]));
                    return;
                }
                ?? obj2 = new Object();
                LinearLayout col = UiKt.col(mainActivity2);
                TextView label = UiKt.label(mainActivity2, Fleet.T("fleet.no_match", new Pair[0]), 14, UiKt.MUTED);
                label.setVisibility(8);
                float f2 = 4;
                float f3 = 8;
                label.setPadding(UiKt.dp(mainActivity2, f2), UiKt.dp(mainActivity2, f3), 0, 0);
                Button button = UiKt.button(mainActivity2, Fleet.T("fleet.pick_all", new Pair[0]), UiKt.BTN);
                button.setTextSize(13.0f);
                Setup$$ExternalSyntheticLambda5 setup$$ExternalSyntheticLambda52 = new Setup$$ExternalSyntheticLambda5(11, sortedWith);
                final NetKt$$ExternalSyntheticLambda3 netKt$$ExternalSyntheticLambda3 = new NetKt$$ExternalSyntheticLambda3(sortedWith, (Ref$ObjectRef) obj2, setup$$ExternalSyntheticLambda52, button, label);
                Ref$ObjectRef ref$ObjectRef2 = obj2;
                Button button2 = button;
                char c2 = 0;
                ManyTvsKt$$ExternalSyntheticLambda41 manyTvsKt$$ExternalSyntheticLambda41 = new ManyTvsKt$$ExternalSyntheticLambda41(mainActivity2, i3);
                Iterator it = sortedWith.iterator();
                while (true) {
                    boolean hasNext = it.hasNext();
                    HashSet hashSet = (HashSet) this.f$3;
                    if (hasNext) {
                        AppRow appRow = (AppRow) it.next();
                        String str9 = appRow.pkg;
                        Setup$$ExternalSyntheticLambda5 setup$$ExternalSyntheticLambda53 = setup$$ExternalSyntheticLambda5;
                        Ref$ObjectRef ref$ObjectRef3 = ref$ObjectRef2;
                        int i4 = 7;
                        for (int i5 = 0; i5 < str9.length(); i5++) {
                            i4 = ((i4 * 31) + str9.charAt(i5)) % 360;
                        }
                        float f4 = i4;
                        FrameLayout frameLayout = new FrameLayout(mainActivity2);
                        int i6 = 0;
                        while (true) {
                            str3 = appRow.name;
                            f = f4;
                            if (i6 < str3.length()) {
                                char charAt = str3.charAt(i6);
                                if (Character.isLetterOrDigit(charAt)) {
                                    ch = Character.valueOf(charAt);
                                } else {
                                    i6++;
                                    f4 = f;
                                }
                            } else {
                                ch = null;
                            }
                        }
                        if (ch != null) {
                            c = ch.charValue();
                        } else {
                            c = '?';
                        }
                        Button button3 = button2;
                        appRow.letter = UiKt.label(mainActivity2, String.valueOf(Character.toUpperCase(c)), 18, -1);
                        TextView letter = appRow.getLetter();
                        Typeface typeface = Typeface.DEFAULT_BOLD;
                        letter.setTypeface(typeface);
                        appRow.getLetter().setGravity(17);
                        TextView letter2 = appRow.getLetter();
                        float[] fArr = new float[3];
                        fArr[c2] = f;
                        fArr[1] = 0.62f;
                        fArr[2] = 0.46f;
                        List list3 = sortedWith;
                        letter2.setBackground(UiKt.box(mainActivity2, Color.HSVToColor(fArr), 10));
                        appRow.image = new ImageView(mainActivity2);
                        appRow.getImage().setVisibility(8);
                        appRow.getImage().setBackground(UiKt.box(mainActivity2, UiKt.BTN, 10));
                        appRow.getImage().setClipToOutline(true);
                        appRow.getImage().setOutlineProvider(ViewOutlineProvider.BACKGROUND);
                        appRow.getImage().setScaleType(ImageView.ScaleType.FIT_CENTER);
                        frameLayout.addView(appRow.getLetter(), new FrameLayout.LayoutParams(-1, -1));
                        frameLayout.addView(appRow.getImage(), new FrameLayout.LayoutParams(-1, -1));
                        LinearLayout col2 = UiKt.col(mainActivity2);
                        appRow.title = UiKt.label(mainActivity2, str3, 16, UiKt.TEXT);
                        appRow.getTitle().setTypeface(typeface);
                        appRow.getTitle().setMaxLines(1);
                        appRow.getTitle().setEllipsize(TextUtils.TruncateAt.END);
                        col2.addView(appRow.getTitle());
                        Pair pair = new Pair("n", Integer.valueOf(appRow.on.size()));
                        Pair pair2 = new Pair("total", Integer.valueOf(hashSet.size()));
                        Pair[] pairArr = new Pair[2];
                        pairArr[c2] = pair;
                        pairArr[1] = pair2;
                        col2.addView(UiKt.label(mainActivity2, Fleet.T("fleet.on_tvs", pairArr), 12, UiKt.MUTED));
                        if (!appRow.named) {
                            TextView label2 = UiKt.label(mainActivity2, appRow.pkg, 11, UiKt.MUTED);
                            label2.setMaxLines(1);
                            label2.setEllipsize(TextUtils.TruncateAt.MIDDLE);
                            col2.addView(label2);
                        }
                        CheckBox checkBox = new CheckBox(mainActivity2);
                        appRow.tick = checkBox;
                        checkBox.setButtonTintList(ColorStateList.valueOf(UiKt.ACCENT));
                        CheckBox checkBox2 = appRow.tick;
                        if (checkBox2 != null) {
                            checkBox2.setClickable(false);
                            LinearLayout linearLayout = new LinearLayout(mainActivity2);
                            linearLayout.setGravity(16);
                            linearLayout.setPadding(UiKt.dp(mainActivity2, 10), UiKt.dp(mainActivity2, f3), UiKt.dp(mainActivity2, 6), UiKt.dp(mainActivity2, f3));
                            float f5 = 40;
                            linearLayout.addView(frameLayout, new LinearLayout.LayoutParams(UiKt.dp(mainActivity2, f5), UiKt.dp(mainActivity2, f5)));
                            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
                            layoutParams.leftMargin = UiKt.dp(mainActivity2, 12);
                            linearLayout.addView(col2, layoutParams);
                            CheckBox checkBox3 = appRow.tick;
                            if (checkBox3 != null) {
                                linearLayout.addView(checkBox3);
                                linearLayout.setBackground(UiKt.onBox(12, mainActivity2, false));
                                linearLayout.setOnClickListener(new Guard$$ExternalSyntheticLambda7(manyTvsKt$$ExternalSyntheticLambda41, appRow, netKt$$ExternalSyntheticLambda3, 5));
                                appRow.view = linearLayout;
                                col.addView(linearLayout, UiKt.gap(mainActivity2, 4));
                                ref$ObjectRef2 = ref$ObjectRef3;
                                setup$$ExternalSyntheticLambda5 = setup$$ExternalSyntheticLambda53;
                                sortedWith = list3;
                                button2 = button3;
                                c2 = 0;
                            } else {
                                Intrinsics.throwUninitializedPropertyAccessException("tick");
                                throw null;
                            }
                        } else {
                            Intrinsics.throwUninitializedPropertyAccessException("tick");
                            throw null;
                        }
                    } else {
                        List list4 = sortedWith;
                        Button button4 = button2;
                        Setup$$ExternalSyntheticLambda5 setup$$ExternalSyntheticLambda54 = setup$$ExternalSyntheticLambda5;
                        Ref$ObjectRef ref$ObjectRef4 = ref$ObjectRef2;
                        col.addView(label);
                        float f6 = 16;
                        col.setPadding(UiKt.dp(mainActivity2, f6), UiKt.dp(mainActivity2, f3), UiKt.dp(mainActivity2, f6), 0);
                        LinearLayout col3 = UiKt.col(mainActivity2);
                        float f7 = 20;
                        col3.setPadding(UiKt.dp(mainActivity2, f7), UiKt.dp(mainActivity2, f2), UiKt.dp(mainActivity2, f7), UiKt.dp(mainActivity2, f2));
                        List list5 = (List) this.f$2;
                        int size = list5.size() - hashSet.size();
                        String T = Fleet.T("fleet.remove_from", new Pair("tvs", CollectionsKt.joinToString$default(list5, " · ", null, null, new MainActivity$$ExternalSyntheticLambda10(mainActivity2, 8), 30)));
                        if (size > 0) {
                            str2 = ApkSigner$$ExternalSyntheticOutline0.m(" ", Fleet.T("fleet.remove_skipped", new Pair("n", Integer.valueOf(size))));
                        } else {
                            str2 = "";
                        }
                        col3.addView(UiKt.label(mainActivity2, Census$$ExternalSyntheticOutline0.m(T, str2), 13, UiKt.MUTED));
                        LinearLayout linearLayout2 = new LinearLayout(mainActivity2);
                        linearLayout2.setGravity(16);
                        if (list4.size() > 6) {
                            EditText input = UiKt.input(mainActivity2, Fleet.T("common.search_by_app_name", new Pair[0]));
                            input.setBackground(UiKt.box(mainActivity2, UiKt.BTN, 12));
                            list = list4;
                            input.addTextChangedListener(new TextWatcher() { // from class: dev.tvremote.phone.picker.ManyTvsKt$fleetUninstall$2$1$3
                                @Override // android.text.TextWatcher
                                public final void afterTextChanged(Editable editable) {
                                    String lowerCase = StringsKt.trim(String.valueOf(editable)).toString().toLowerCase(Locale.ROOT);
                                    Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                                    for (AppRow appRow2 : list) {
                                        LinearLayout linearLayout3 = appRow2.view;
                                        if (linearLayout3 != null) {
                                            int i7 = 0;
                                            if (lowerCase.length() != 0 && !StringsKt.contains(appRow2.key, lowerCase, false)) {
                                                i7 = 8;
                                            }
                                            linearLayout3.setVisibility(i7);
                                        } else {
                                            Intrinsics.throwUninitializedPropertyAccessException("view");
                                            throw null;
                                        }
                                    }
                                    netKt$$ExternalSyntheticLambda3.invoke();
                                }

                                @Override // android.text.TextWatcher
                                public final void beforeTextChanged(CharSequence charSequence, int i7, int i8, int i9) {
                                }

                                @Override // android.text.TextWatcher
                                public final void onTextChanged(CharSequence charSequence, int i7, int i8, int i9) {
                                }
                            });
                            linearLayout2.addView(input, new LinearLayout.LayoutParams(0, UiKt.dp(mainActivity2, 44), 1.0f));
                        } else {
                            list = list4;
                            linearLayout2.addView(new View(mainActivity2), new LinearLayout.LayoutParams(0, 1, 1.0f));
                        }
                        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, UiKt.dp(mainActivity2, 44));
                        layoutParams2.leftMargin = UiKt.dp(mainActivity2, f3);
                        linearLayout2.addView(button4, layoutParams2);
                        col3.addView(linearLayout2, UiKt.gap(mainActivity2, 8));
                        button4.setOnClickListener(new Guard$$ExternalSyntheticLambda7(setup$$ExternalSyntheticLambda52, netKt$$ExternalSyntheticLambda3, manyTvsKt$$ExternalSyntheticLambda41, 6));
                        LinearLayout col4 = UiKt.col(mainActivity2);
                        col4.addView(col3);
                        col4.addView(col);
                        Popup.Builder builder = new Popup.Builder(mainActivity2);
                        builder.title = Fleet.T("many_tvs.remove_which_apps", new Pair[0]);
                        builder.view = col4;
                        builder.setPositiveButton(Fleet.T("fleet.remove", new Pair[0]), new MediaKt$$ExternalSyntheticLambda10(5, list, mainActivity2));
                        builder.setNegativeButton(Fleet.T("common.cancel", new Pair[0]), null);
                        builder.onDismiss = new Guard$$ExternalSyntheticLambda6(1, setup$$ExternalSyntheticLambda54);
                        ref$ObjectRef4.element = builder.show();
                        netKt$$ExternalSyntheticLambda3.invoke();
                        ExecutorService newFixedThreadPool = Executors.newFixedThreadPool(4);
                        Iterator it2 = list.iterator();
                        while (it2.hasNext()) {
                            newFixedThreadPool.execute(new Vidaa$$ExternalSyntheticLambda3(ref$ObjectRef4, (AppRow) it2.next(), mainActivity2, (HashMap) this.f$6, 11));
                        }
                        newFixedThreadPool.shutdown();
                        return;
                    }
                }
                break;
        }
    }

    public /* synthetic */ MediaKt$$ExternalSyntheticLambda1(MainActivity mainActivity, String str, Uri uri, Ref$LongRef ref$LongRef, Ref$ObjectRef ref$ObjectRef, JSONObject jSONObject, Cancel cancel, Popup popup) {
        this.f$0 = mainActivity;
        this.f$1 = str;
        this.f$2 = uri;
        this.f$3 = ref$LongRef;
        this.f$4 = ref$ObjectRef;
        this.f$5 = jSONObject;
        this.f$6 = cancel;
        this.f$7 = popup;
    }
}
