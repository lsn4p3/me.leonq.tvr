package dev.tvremote.phone.media;

import android.graphics.Typeface;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import dev.tvremote.core.Census$$ExternalSyntheticLambda4;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.adb.Adb$$ExternalSyntheticLambda0;
import dev.tvremote.core.ontv.Axml$$ExternalSyntheticLambda2;
import dev.tvremote.core.ontv.NowPlaying;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.remote.Lg$$ExternalSyntheticLambda2;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda8;
import dev.tvremote.phone.ListenService;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.WorkService;
import dev.tvremote.phone.ui.IconButton;
import dev.tvremote.phone.ui.UiKt;
import java.util.Arrays;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kotlin.Pair;
import kotlin.SynchronizedLazyImpl;
import kotlin.collections.ArraysKt;
import kotlin.jvm.internal.Intrinsics;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class PlayingBar {
    public final MainActivity a;
    public boolean asking;
    public long at;
    public final SynchronizedLazyImpl blackBmp$delegate;
    public int blackFor;
    public final SynchronizedLazyImpl blackHint$delegate;
    public volatile boolean busy;
    public boolean dragging;
    public final TextView dur;
    public long fine;
    public NowPlaying np;
    public Tv npFor;
    public JSONObject o;
    public String oHost;
    public final IconButton play;
    public final TextView pos;
    public final SeekBar seek;
    public final HashMap spins;
    public final TextView sub;
    public final NowApp$tick$1 tick;
    public final LinearLayout times;
    public final TextView title;
    public final LinearLayout view;
    public final ExecutorService work;

    /* renamed from: dev.tvremote.phone.media.PlayingBar$5, reason: invalid class name */
    /* loaded from: classes.dex */
    public final class AnonymousClass5 implements SeekBar.OnSeekBarChangeListener {
        public final /* synthetic */ int $r8$classId;
        public final /* synthetic */ Object this$0;

        public /* synthetic */ AnonymousClass5(int i, Object obj) {
            this.$r8$classId = i;
            this.this$0 = obj;
        }

        @Override // android.widget.SeekBar.OnSeekBarChangeListener
        public final void onProgressChanged(SeekBar s, int i, boolean z) {
            switch (this.$r8$classId) {
                case 0:
                    Intrinsics.checkNotNullParameter(s, "s");
                    if (z) {
                        ((PlayingBar) this.this$0).pos.setText(PlayingBar.clock((i / 1000.0d) * r5.o.optLong("dur")));
                        return;
                    }
                    return;
                default:
                    Intrinsics.checkNotNullParameter(s, "b");
                    if (z) {
                        ((Axml$$ExternalSyntheticLambda2) this.this$0).invoke(Float.valueOf((i / 2.0f) + 0.5f));
                        return;
                    }
                    return;
            }
        }

        @Override // android.widget.SeekBar.OnSeekBarChangeListener
        public final void onStartTrackingTouch(SeekBar s) {
            switch (this.$r8$classId) {
                case 0:
                    Intrinsics.checkNotNullParameter(s, "s");
                    ((PlayingBar) this.this$0).dragging = true;
                    return;
                default:
                    Intrinsics.checkNotNullParameter(s, "b");
                    return;
            }
        }

        @Override // android.widget.SeekBar.OnSeekBarChangeListener
        public final void onStopTrackingTouch(SeekBar s) {
            switch (this.$r8$classId) {
                case 0:
                    Intrinsics.checkNotNullParameter(s, "s");
                    ((PlayingBar) this.this$0).dragging = false;
                    long progress = (long) ((s.getProgress() / 1000.0d) * ((PlayingBar) this.this$0).o.optLong("dur"));
                    if (!((PlayingBar) this.this$0).busy) {
                        ((PlayingBar) this.this$0).o.put("pos", progress);
                        ((PlayingBar) this.this$0).at = System.currentTimeMillis();
                        ((PlayingBar) this.this$0).send("seek", progress, null);
                        return;
                    }
                    return;
                default:
                    Intrinsics.checkNotNullParameter(s, "b");
                    return;
            }
        }
    }

    public PlayingBar(MainActivity mainActivity) {
        int i = 17;
        int i2 = 8;
        boolean z = true;
        char c = 1;
        final int i3 = 0;
        this.a = mainActivity;
        LinearLayout col = UiKt.col(mainActivity);
        this.view = col;
        TextView label = UiKt.label(mainActivity, "", 15, UiKt.TEXT);
        this.title = label;
        TextView label2 = UiKt.label(mainActivity, "", 12, UiKt.MUTED);
        this.sub = label2;
        this.play = UiKt.icon(mainActivity, "@pause", Fleet.T("remote.play_pause", new Pair[0]), UiKt.ACCENT);
        this.seek = new SeekBar(mainActivity);
        this.pos = UiKt.label(mainActivity, "0:00", 12, UiKt.MUTED);
        this.dur = UiKt.label(mainActivity, "", 12, UiKt.MUTED);
        this.times = new LinearLayout(mainActivity);
        this.work = Executors.newSingleThreadExecutor();
        this.o = Census$$ExternalSyntheticOutline0.m8m("state", "none");
        this.spins = new HashMap();
        col.setBackground(UiKt.box(mainActivity, UiKt.CARD, 16));
        float f = 12;
        float f2 = 6;
        col.setPadding(UiKt.dp(mainActivity, f), UiKt.dp(mainActivity, 10), UiKt.dp(mainActivity, f), UiKt.dp(mainActivity, f2));
        col.setVisibility(8);
        LinearLayout linearLayout = new LinearLayout(mainActivity);
        linearLayout.setGravity(16);
        LinearLayout col2 = UiKt.col(mainActivity);
        for (TextView textView : ArraysKt.asList(new TextView[]{label, label2})) {
            UiKt.runs(textView);
            col2.addView(textView);
        }
        this.title.setTypeface(Typeface.DEFAULT_BOLD);
        linearLayout.addView(col2, new LinearLayout.LayoutParams(0, -2, 1.0f));
        final IconButton icon = UiKt.icon(this.a, "@prev", Fleet.T("remote.previous", new Pair[0]), UiKt.BTN);
        final IconButton icon2 = UiKt.icon(this.a, "@next", Fleet.T("remote.next", new Pair[0]), UiKt.BTN);
        icon.setOnClickListener(new View.OnClickListener(this) { // from class: dev.tvremote.phone.media.PlayingBar$$ExternalSyntheticLambda1
            public final /* synthetic */ PlayingBar f$0;

            {
                this.f$0 = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                switch (i3) {
                    case 0:
                        this.f$0.send("prev", 0L, icon);
                        return;
                    default:
                        this.f$0.send("next", 0L, icon);
                        return;
                }
            }
        });
        final char c2 = c == true ? 1 : 0;
        icon2.setOnClickListener(new View.OnClickListener(this) { // from class: dev.tvremote.phone.media.PlayingBar$$ExternalSyntheticLambda1
            public final /* synthetic */ PlayingBar f$0;

            {
                this.f$0 = this;
            }

            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                switch (c2) {
                    case 0:
                        this.f$0.send("prev", 0L, icon2);
                        return;
                    default:
                        this.f$0.send("next", 0L, icon2);
                        return;
                }
            }
        });
        this.play.setOnClickListener(new Guard$$ExternalSyntheticLambda8(5, this));
        for (IconButton iconButton : ArraysKt.asList(new IconButton[]{icon, this.play, icon2})) {
            ProgressBar progressBar = new ProgressBar(this.a);
            progressBar.setIndeterminate(z);
            progressBar.setVisibility(8);
            this.spins.put(iconButton, progressBar);
            FrameLayout frameLayout = new FrameLayout(this.a);
            frameLayout.addView(iconButton, new FrameLayout.LayoutParams(-1, -1));
            float f3 = 20;
            frameLayout.addView(progressBar, new FrameLayout.LayoutParams(UiKt.dp(this.a, f3), UiKt.dp(this.a, f3), 17));
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(UiKt.dp(this.a, 44), UiKt.dp(this.a, 40));
            layoutParams.leftMargin = UiKt.dp(this.a, f2);
            linearLayout.addView(frameLayout, layoutParams);
            z = true;
        }
        this.view.addView(linearLayout);
        this.times.setGravity(16);
        this.seek.setMax(1000);
        this.seek.setOnSeekBarChangeListener(new AnonymousClass5(i3, this));
        this.times.addView(this.pos);
        this.times.addView(this.seek, new LinearLayout.LayoutParams(0, -2, 1.0f));
        this.times.addView(this.dur);
        LinearLayout linearLayout2 = this.view;
        View view = this.times;
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams2.topMargin = UiKt.dp(this.a, 4);
        linearLayout2.addView(view, layoutParams2);
        this.a.ui.post(new Adb$$ExternalSyntheticLambda0(i2, this));
        WorkService.Companion companion = ListenService.Companion;
        ListenService.control = new PlayingBar$$ExternalSyntheticLambda5(this, i3);
        this.tick = new NowApp$tick$1(1, this);
        this.blackBmp$delegate = new SynchronizedLazyImpl(new Census$$ExternalSyntheticLambda4(i));
        this.blackHint$delegate = new SynchronizedLazyImpl(new PlayingBar$$ExternalSyntheticLambda7(this, i3));
    }

    public static String clock(double d) {
        long j = (long) (d / 1000);
        if (j >= 3600) {
            long j2 = 60;
            return String.format("%d:%02d:%02d", Arrays.copyOf(new Object[]{Long.valueOf(j / 3600), Long.valueOf((j / j2) % j2), Long.valueOf(j % j2)}, 3));
        }
        long j3 = 60;
        return String.format("%d:%02d", Arrays.copyOf(new Object[]{Long.valueOf(j / j3), Long.valueOf(j % j3)}, 2));
    }

    public static String sig(JSONObject jSONObject) {
        return jSONObject.optString("state") + "|" + jSONObject.opt("title") + "|" + jSONObject.optString("pkg");
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x0041  */
    /* JADX WARN: Removed duplicated region for block: B:14:0x004c  */
    /* JADX WARN: Removed duplicated region for block: B:40:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:41:0x0043  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void draw() {
        boolean z;
        int i;
        int i2;
        String str;
        PlayingBar$$ExternalSyntheticLambda5 playingBar$$ExternalSyntheticLambda5 = new PlayingBar$$ExternalSyntheticLambda5(this, 1);
        CharSequence charSequence = (CharSequence) playingBar$$ExternalSyntheticLambda5.invoke("title");
        if (charSequence.length() == 0) {
            charSequence = (String) playingBar$$ExternalSyntheticLambda5.invoke("app");
        }
        String str2 = (String) charSequence;
        int i3 = 0;
        if (!Intrinsics.areEqual(this.o.optString("state", "none"), "none")) {
            Intrinsics.checkNotNull(str2);
            if (str2.length() > 0) {
                z = true;
                LinearLayout linearLayout = this.view;
                if (!z) {
                    i = 0;
                } else {
                    i = 8;
                }
                linearLayout.setVisibility(i);
                if (!z) {
                    TextView textView = this.title;
                    Intrinsics.checkNotNull(str2);
                    UiKt.say(textView, str2);
                    TextView textView2 = this.sub;
                    Object invoke = playingBar$$ExternalSyntheticLambda5.invoke("sub");
                    Object invoke2 = playingBar$$ExternalSyntheticLambda5.invoke("title");
                    Intrinsics.checkNotNullExpressionValue(invoke2, "invoke(...)");
                    if (((CharSequence) invoke2).length() <= 0) {
                        invoke = null;
                    }
                    String str3 = (String) invoke;
                    if (str3 == null) {
                        str3 = "";
                    }
                    UiKt.say(textView2, str3);
                    CharSequence text = textView2.getText();
                    Intrinsics.checkNotNullExpressionValue(text, "getText(...)");
                    if (text.length() == 0) {
                        i2 = 8;
                    } else {
                        i2 = 0;
                    }
                    textView2.setVisibility(i2);
                    if (Intrinsics.areEqual(this.o.optString("state"), "paused")) {
                        str = "@play";
                    } else {
                        str = "@pause";
                    }
                    this.play.setIcon(str, UiKt.TEXT);
                    long optLong = this.o.optLong("dur");
                    LinearLayout linearLayout2 = this.times;
                    if (optLong <= 0) {
                        i3 = 8;
                    }
                    linearLayout2.setVisibility(i3);
                    SeekBar seekBar = this.seek;
                    seekBar.setEnabled(this.o.optBoolean("seek"));
                    if (optLong > 0 && !this.dragging) {
                        seekBar.setProgress((int) ((now() * 1000) / optLong));
                        this.pos.setText(clock(now()));
                        this.dur.setText(clock(optLong));
                        return;
                    }
                    return;
                }
                return;
            }
        }
        z = false;
        LinearLayout linearLayout3 = this.view;
        if (!z) {
        }
        linearLayout3.setVisibility(i);
        if (!z) {
        }
    }

    public final void mark(View view, boolean z) {
        float f;
        int i;
        if (view != null) {
            if (z) {
                f = 0.25f;
            } else {
                f = 1.0f;
            }
            view.setAlpha(f);
            ProgressBar progressBar = (ProgressBar) this.spins.get(view);
            if (progressBar != null) {
                if (z) {
                    i = 0;
                } else {
                    i = 8;
                }
                progressBar.setVisibility(i);
            }
        }
    }

    public final long now() {
        long optLong = this.o.optLong("pos");
        if (Intrinsics.areEqual(this.o.optString("state"), "playing")) {
            optLong += (long) (this.o.optDouble("speed", 1.0d) * (System.currentTimeMillis() - this.at));
        }
        long optLong2 = this.o.optLong("dur");
        if (optLong2 > 0) {
            return Math.min(optLong, optLong2);
        }
        return optLong;
    }

    public final NowPlaying player(Tv tv) {
        NowPlaying nowPlaying;
        synchronized (this) {
            try {
                if (this.npFor != tv) {
                    this.np = new NowPlaying(new PlayingBar$$ExternalSyntheticLambda13(tv, 0), new PlayingBar$$ExternalSyntheticLambda7(this, 1));
                    this.npFor = tv;
                }
                nowPlaying = this.np;
                Intrinsics.checkNotNull(nowPlaying);
            } catch (Throwable th) {
                throw th;
            }
        }
        return nowPlaying;
    }

    public final void send(final String str, final long j, final View view) {
        final Tv tv = this.a.tv;
        if (tv == null || this.busy) {
            return;
        }
        this.busy = true;
        mark(view, true);
        JSONObject o = this.o;
        Intrinsics.checkNotNullExpressionValue(o, "o");
        final String sig = sig(o);
        this.work.execute(new Runnable() { // from class: dev.tvremote.phone.media.PlayingBar$$ExternalSyntheticLambda8
            /* JADX WARN: Type inference failed for: r7v0, types: [kotlin.jvm.internal.Ref$BooleanRef, java.lang.Object] */
            @Override // java.lang.Runnable
            public final void run() {
                int i;
                JSONObject state;
                PlayingBar playingBar = PlayingBar.this;
                Tv tv2 = tv;
                String str2 = str;
                long j2 = j;
                String str3 = sig;
                ?? obj = new Object();
                try {
                    playingBar.player(tv2).command(j2, str2);
                    long currentTimeMillis = System.currentTimeMillis();
                    if (str2.equals("seek")) {
                        i = 600;
                    } else {
                        i = 2500;
                    }
                    long j3 = currentTimeMillis + i;
                    while (System.currentTimeMillis() < j3) {
                        Thread.sleep(400L);
                        try {
                            state = playingBar.player(tv2).state();
                            playingBar.a.ui.post(new PlayingBar$$ExternalSyntheticLambda11(playingBar, state, 0));
                        } catch (Exception unused) {
                        }
                        if (str2.equals("seek") || !Intrinsics.areEqual(PlayingBar.sig(state), str3)) {
                            break;
                        }
                    }
                } catch (Exception unused2) {
                    obj.element = true;
                }
                playingBar.a.ui.post(new Lg$$ExternalSyntheticLambda2(playingBar, view, obj, 14));
            }
        });
    }
}
