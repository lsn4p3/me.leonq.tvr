package dev.tvremote.phone.media;

import dev.tvremote.core.Fleet;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final /* synthetic */ class PlayingBar$$ExternalSyntheticLambda5 implements Function1 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ PlayingBar f$0;

    public /* synthetic */ PlayingBar$$ExternalSyntheticLambda5(PlayingBar playingBar, int i) {
        this.$r8$classId = i;
        this.f$0 = playingBar;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        switch (this.$r8$classId) {
            case 0:
                PlayingBar playingBar = this.f$0;
                String what = (String) obj;
                Intrinsics.checkNotNullParameter(what, "what");
                if (what.equals("dev.tvremote.phone.STOP_LISTEN")) {
                    Fleet.stopListen(playingBar.a, null);
                } else if (playingBar.a.tv != null) {
                    playingBar.send(what, 0L, null);
                }
                return Unit.INSTANCE;
            default:
                String k = (String) obj;
                Intrinsics.checkNotNullParameter(k, "k");
                PlayingBar playingBar2 = this.f$0;
                if (playingBar2.o.isNull(k)) {
                    return "";
                }
                return playingBar2.o.optString(k);
        }
    }
}
