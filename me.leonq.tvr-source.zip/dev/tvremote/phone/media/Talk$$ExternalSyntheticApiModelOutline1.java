package dev.tvremote.phone.media;

import android.widget.TextView;
import dev.tvremote.phone.MainActivity;
import java.lang.reflect.Type;
import java.util.concurrent.Executor;

/* loaded from: classes.dex */
public abstract /* synthetic */ class Talk$$ExternalSyntheticApiModelOutline1 {
    public static /* bridge */ /* synthetic */ String m(Type type) {
        return type.getTypeName();
    }

    public static /* bridge */ /* synthetic */ Executor m(MainActivity mainActivity) {
        return mainActivity.getMainExecutor();
    }

    public static /* bridge */ /* synthetic */ void m(TextView textView) {
        textView.setAccessibilityHeading(true);
    }
}
