package dev.tvremote.phone.media;

import android.animation.ValueAnimator;
import android.view.MotionEvent;
import android.view.View;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.remote.Lg$$ExternalSyntheticLambda14;
import dev.tvremote.core.remote.WebSocket;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda5;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.picture.Air;
import dev.tvremote.phone.picture.DrawView;
import dev.tvremote.phone.remote.Gp;
import dev.tvremote.phone.remote.TapMark;
import dev.tvremote.phone.ui.UiKt;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class Talk$$ExternalSyntheticLambda8 implements View.OnTouchListener {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;

    public /* synthetic */ Talk$$ExternalSyntheticLambda8(int i, Object obj) {
        this.$r8$classId = i;
        this.f$0 = obj;
    }

    /* JADX WARN: Code restructure failed: missing block: B:39:0x0125, code lost:
    
        if (r2 != 3) goto L145;
     */
    @Override // android.view.View.OnTouchListener
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean onTouch(View view, MotionEvent motionEvent) {
        int i;
        int i2;
        String str;
        boolean z;
        float f;
        boolean z2 = false;
        int i3 = 0;
        switch (this.$r8$classId) {
            case 0:
                int actionMasked = motionEvent.getActionMasked();
                Talk talk = (Talk) this.f$0;
                if (actionMasked != 0) {
                    if (actionMasked != 1) {
                        if (actionMasked != 2) {
                            if (actionMasked == 3) {
                                talk.let_go(true);
                            }
                        } else {
                            double hypot = Math.hypot(motionEvent.getX() - (view.getWidth() / 2.0f), motionEvent.getY() - (view.getHeight() / 2.0f));
                            MainActivity mainActivity = talk.a;
                            boolean z3 = UiKt.LIGHT;
                            if (hypot > UiKt.dp(mainActivity, 110)) {
                                z2 = true;
                            }
                            if (z2 != talk.cancelling && talk.holding) {
                                talk.cancelling = z2;
                                talk.paintButton();
                                if (z2) {
                                    talk.a.buzz$android_release();
                                }
                            }
                        }
                    } else {
                        talk.let_go(talk.cancelling);
                    }
                } else {
                    view.getParent().requestDisallowInterceptTouchEvent(true);
                    talk.begin(false);
                }
                return true;
            case 1:
                MainActivity mainActivity2 = (MainActivity) this.f$0;
                WebSocket webSocket = Gp.ws;
                int actionMasked2 = motionEvent.getActionMasked();
                if (actionMasked2 != 0) {
                    if (actionMasked2 == 1 || actionMasked2 == 3) {
                        view.setPressed(false);
                        new Thread(new Lg$$ExternalSyntheticLambda14(webSocket, 5)).start();
                    }
                } else {
                    view.setPressed(true);
                    mainActivity2.buzz$android_release();
                    new Thread(new Lg$$ExternalSyntheticLambda14(webSocket, 4)).start();
                }
                return true;
            default:
                MainActivity mainActivity3 = (MainActivity) this.f$0;
                Tv tv = mainActivity3.pic;
                if (tv != null && tv.ready()) {
                    DrawView.Stroke stroke = null;
                    if (mainActivity3.drawing) {
                        Intrinsics.checkNotNull(motionEvent);
                        Intrinsics.checkNotNull(view);
                        if (mainActivity3.getDrawView$android_release().getPlacing() != null) {
                            DrawView drawView$android_release = mainActivity3.getDrawView$android_release();
                            DrawView.Pic pic = drawView$android_release.placing;
                            if (pic != null) {
                                if (motionEvent.getPointerCount() >= 2) {
                                    z = true;
                                } else {
                                    z = false;
                                }
                                if (z) {
                                    f = (float) Math.hypot(motionEvent.getX(0) - motionEvent.getX(1), motionEvent.getY(0) - motionEvent.getY(1));
                                } else {
                                    f = 0.0f;
                                }
                                if (motionEvent.getActionMasked() == 2) {
                                    if (z) {
                                        float f2 = drawView$android_release.lastD;
                                        if (f2 > 0.0f) {
                                            pic.w = MathKt.coerceIn((int) ((pic.w * f) / f2), 400, 10000);
                                            drawView$android_release.onSize.invoke();
                                            drawView$android_release.invalidate();
                                        }
                                    }
                                    if (!z) {
                                        float f3 = 10000;
                                        pic.x = MathKt.coerceIn((int) ((((motionEvent.getX() - drawView$android_release.lastX) / view.getWidth()) * f3) + pic.x), 0, 10000);
                                        pic.y = MathKt.coerceIn((int) ((((motionEvent.getY() - drawView$android_release.lastY) / view.getHeight()) * f3) + pic.y), 0, 10000);
                                    }
                                    drawView$android_release.invalidate();
                                }
                                drawView$android_release.lastX = motionEvent.getX();
                                drawView$android_release.lastY = motionEvent.getY();
                                drawView$android_release.lastD = f;
                                if (motionEvent.getActionMasked() == 6) {
                                    if (motionEvent.getActionIndex() == 0) {
                                        i3 = 1;
                                    }
                                    drawView$android_release.lastX = motionEvent.getX(i3);
                                    drawView$android_release.lastY = motionEvent.getY(i3);
                                    drawView$android_release.lastD = 0.0f;
                                }
                            }
                        } else {
                            float f4 = 10000;
                            int coerceIn = MathKt.coerceIn((int) ((motionEvent.getX() / view.getWidth()) * f4), 0, 10000);
                            int coerceIn2 = MathKt.coerceIn((int) ((motionEvent.getY() / view.getHeight()) * f4), 0, 10000);
                            int actionMasked3 = motionEvent.getActionMasked();
                            if (actionMasked3 != 0) {
                                if (actionMasked3 != 1) {
                                    if (actionMasked3 == 2) {
                                        DrawView drawView$android_release2 = mainActivity3.getDrawView$android_release();
                                        DrawView.Stroke stroke2 = (DrawView.Stroke) CollectionsKt.lastOrNull(drawView$android_release2.strokes);
                                        if (stroke2 != null) {
                                            if (stroke2.upAt == 0) {
                                                stroke = stroke2;
                                            }
                                            if (stroke != null) {
                                                ArrayList arrayList = stroke.pts;
                                                Object obj = arrayList.get(arrayList.size() - 2);
                                                Intrinsics.checkNotNullExpressionValue(obj, "get(...)");
                                                int abs = Math.abs(coerceIn - ((Number) obj).intValue());
                                                Object obj2 = arrayList.get(arrayList.size() - 1);
                                                Intrinsics.checkNotNullExpressionValue(obj2, "get(...)");
                                                if (Math.abs(coerceIn2 - ((Number) obj2).intValue()) + abs >= 25) {
                                                    arrayList.add(Integer.valueOf(coerceIn));
                                                    arrayList.add(Integer.valueOf(coerceIn2));
                                                    drawView$android_release2.invalidate();
                                                    JSONObject put = new JSONObject().put("o", "a").put("id", mainActivity3.drawId).put("p", new JSONArray().put(coerceIn).put(coerceIn2));
                                                    Intrinsics.checkNotNullExpressionValue(put, "put(...)");
                                                    Air.drawSend(mainActivity3, put);
                                                }
                                            }
                                        }
                                    }
                                }
                                DrawView drawView$android_release3 = mainActivity3.getDrawView$android_release();
                                DrawView.Stroke stroke3 = (DrawView.Stroke) CollectionsKt.lastOrNull(drawView$android_release3.strokes);
                                if (stroke3 != null && stroke3.upAt == 0) {
                                    stroke3.upAt = System.currentTimeMillis();
                                }
                                drawView$android_release3.invalidate();
                            } else {
                                int i4 = mainActivity3.drawId + 1;
                                mainActivity3.drawId = i4;
                                DrawView drawView$android_release4 = mainActivity3.getDrawView$android_release();
                                int i5 = mainActivity3.drawColor;
                                int i6 = mainActivity3.drawWidth;
                                ArrayList arrayList2 = drawView$android_release4.strokes;
                                DrawView.Stroke stroke4 = new DrawView.Stroke(i5, i6);
                                Integer valueOf = Integer.valueOf(coerceIn);
                                ArrayList arrayList3 = stroke4.pts;
                                arrayList3.add(valueOf);
                                arrayList3.add(Integer.valueOf(coerceIn2));
                                arrayList2.add(stroke4);
                                drawView$android_release4.invalidate();
                                JSONObject put2 = new JSONObject().put("o", "s").put("id", i4).put("c", String.format("#%06x", Arrays.copyOf(new Object[]{Integer.valueOf(mainActivity3.drawColor & 16777215)}, 1))).put("w", mainActivity3.drawWidth).put("p", new JSONArray().put(coerceIn).put(coerceIn2));
                                Intrinsics.checkNotNullExpressionValue(put2, "put(...)");
                                Air.drawSend(mainActivity3, put2);
                            }
                        }
                    } else {
                        int actionMasked4 = motionEvent.getActionMasked();
                        if (actionMasked4 != 0) {
                            if (actionMasked4 != 1) {
                                if (actionMasked4 != 2) {
                                    if (actionMasked4 != 3) {
                                        i = -1;
                                    }
                                } else {
                                    i = 2;
                                }
                            }
                            i = 1;
                        } else {
                            i = 0;
                        }
                        if (i >= 0) {
                            float x = motionEvent.getX() / view.getWidth();
                            float y = motionEvent.getY() / view.getHeight();
                            if (tv.relaying) {
                                JSONObject jSONObject = new JSONObject();
                                if (i != 0) {
                                    if (i != 1) {
                                        str = "move";
                                    } else {
                                        str = "up";
                                    }
                                } else {
                                    str = "down";
                                }
                                JSONObject put3 = jSONObject.put("a", str).put("x", x).put("y", y);
                                Intrinsics.checkNotNullExpressionValue(put3, "put(...)");
                                if (tv.relay != null) {
                                    String optString = put3.optString("a");
                                    synchronized (tv.touchLock) {
                                        try {
                                            if (Intrinsics.areEqual(optString, "down")) {
                                                JSONObject jSONObject2 = tv.heldDown;
                                                if (jSONObject2 != null) {
                                                    tv.postTouch(jSONObject2);
                                                }
                                                tv.heldDown = put3;
                                                try {
                                                    tv.touchIo.schedule(new Guard$$ExternalSyntheticLambda5(13, tv, put3), 250L, TimeUnit.MILLISECONDS);
                                                } catch (RuntimeException unused) {
                                                }
                                            } else {
                                                if (Intrinsics.areEqual(optString, "up")) {
                                                    JSONObject jSONObject3 = tv.heldDown;
                                                    if (jSONObject3 != null) {
                                                        tv.heldDown = null;
                                                        JSONObject put4 = new JSONObject().put("a", "tap").put("x", jSONObject3.opt("x")).put("y", jSONObject3.opt("y"));
                                                        Intrinsics.checkNotNullExpressionValue(put4, "put(...)");
                                                        tv.postTouch(put4);
                                                    }
                                                } else {
                                                    JSONObject jSONObject4 = tv.heldDown;
                                                    if (jSONObject4 != null) {
                                                        tv.heldDown = null;
                                                        tv.postTouch(jSONObject4);
                                                    }
                                                }
                                                tv.postTouch(put3);
                                            }
                                        } catch (Throwable th) {
                                            throw th;
                                        }
                                    }
                                }
                            } else {
                                ByteBuffer putShort = ByteBuffer.allocate(32).put((byte) 2).put((byte) i).putLong(-2L).putInt(Math.round(MathKt.coerceIn(x, 0.0f, 1.0f) * (tv.width - 1))).putInt(Math.round(MathKt.coerceIn(y, 0.0f, 1.0f) * (tv.height - 1))).putShort((short) tv.width).putShort((short) tv.height);
                                if (i == 1) {
                                    i2 = 0;
                                } else {
                                    i2 = 65535;
                                }
                                byte[] array = putShort.putShort((short) i2).putInt(0).putInt(0).array();
                                Intrinsics.checkNotNullExpressionValue(array, "array(...)");
                                tv.send(array);
                            }
                        }
                        if (i != 0) {
                            if (i != 1) {
                                if (i == 2) {
                                    TapMark tapMark = mainActivity3.tapMark;
                                    if (tapMark != null) {
                                        float x2 = motionEvent.getX();
                                        float y2 = motionEvent.getY();
                                        if (tapMark.held) {
                                            tapMark.x = x2;
                                            tapMark.y = y2;
                                            tapMark.invalidate();
                                        }
                                    } else {
                                        Intrinsics.throwUninitializedPropertyAccessException("tapMark");
                                        throw null;
                                    }
                                }
                            } else {
                                final TapMark tapMark2 = mainActivity3.tapMark;
                                if (tapMark2 != null) {
                                    if (tapMark2.held) {
                                        tapMark2.held = false;
                                        ValueAnimator duration = ValueAnimator.ofFloat(0.0f, 1.0f).setDuration(450L);
                                        duration.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: dev.tvremote.phone.remote.TapMark$$ExternalSyntheticLambda0
                                            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
                                            public final void onAnimationUpdate(ValueAnimator it) {
                                                Intrinsics.checkNotNullParameter(it, "it");
                                                Object animatedValue = it.getAnimatedValue();
                                                Intrinsics.checkNotNull(animatedValue, "null cannot be cast to non-null type kotlin.Float");
                                                float floatValue = ((Float) animatedValue).floatValue();
                                                TapMark tapMark3 = TapMark.this;
                                                tapMark3.gone = floatValue;
                                                tapMark3.invalidate();
                                            }
                                        });
                                        duration.start();
                                        tapMark2.anim = duration;
                                    }
                                } else {
                                    Intrinsics.throwUninitializedPropertyAccessException("tapMark");
                                    throw null;
                                }
                            }
                        } else {
                            TapMark tapMark3 = mainActivity3.tapMark;
                            if (tapMark3 != null) {
                                float x3 = motionEvent.getX();
                                float y3 = motionEvent.getY();
                                ValueAnimator valueAnimator = tapMark3.anim;
                                if (valueAnimator != null) {
                                    valueAnimator.cancel();
                                }
                                tapMark3.x = x3;
                                tapMark3.y = y3;
                                tapMark3.held = true;
                                tapMark3.gone = 0.0f;
                                tapMark3.invalidate();
                            } else {
                                Intrinsics.throwUninitializedPropertyAccessException("tapMark");
                                throw null;
                            }
                        }
                    }
                }
                return true;
        }
    }
}
