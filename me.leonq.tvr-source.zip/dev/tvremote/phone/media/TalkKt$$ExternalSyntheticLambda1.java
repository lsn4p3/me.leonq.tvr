package dev.tvremote.phone.media;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.SharedPreferences;
import android.os.Vibrator;
import android.widget.Toast;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.WireLog;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.picture.SoundPace;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda15;
import dev.tvremote.phone.ir.IrRemoteKt;
import dev.tvremote.phone.manage.UpdaterKt;
import dev.tvremote.phone.picker.AdbHelpKt;
import dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda18;
import dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda40;
import dev.tvremote.phone.ui.UiKt;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import org.conscrypt.FileClientSessionCache;
import org.conscrypt.metrics.ConscryptStatsLog;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class TalkKt$$ExternalSyntheticLambda1 implements Function0 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ TalkKt$$ExternalSyntheticLambda1(MainActivity mainActivity) {
        this.$r8$classId = 20;
        boolean z = SoundPace.even;
        this.f$0 = mainActivity;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        Adb adb;
        int i = 12;
        int i2 = 4;
        Remote remote = null;
        switch (this.$r8$classId) {
            case 0:
                InputStream open = this.f$0.getAssets().open("tvr-helper.jar");
                try {
                    Intrinsics.checkNotNull(open);
                    byte[] readBytes = MathKt.readBytes(open);
                    MathKt.closeFinally(open, null);
                    return readBytes;
                } catch (Throwable th) {
                    try {
                        throw th;
                    } catch (Throwable th2) {
                        MathKt.closeFinally(open, th);
                        throw th2;
                    }
                }
            case 1:
                int i3 = MainActivity.$r8$clinit;
                Object systemService = this.f$0.getSystemService("vibrator");
                if (!(systemService instanceof Vibrator)) {
                    return null;
                }
                return (Vibrator) systemService;
            case 2:
                int i4 = MainActivity.$r8$clinit;
                return new Talk(this.f$0);
            case 3:
                Tv tv = this.f$0.tv;
                if (tv != null && (adb = tv.adb) != null) {
                    return adb;
                }
                throw new IOException("no TV");
            case 4:
                IrRemoteKt.irFind$default(this.f$0);
                return Unit.INSTANCE;
            case 5:
                IrRemoteKt.irStop();
                IrRemoteKt.irRemote(this.f$0);
                return Unit.INSTANCE;
            case 6:
                this.f$0.getIrHost$android_release().setVisibility(8);
                return Unit.INSTANCE;
            case 7:
                IrRemoteKt.irRemote(this.f$0);
                return Unit.INSTANCE;
            case 8:
                IrRemoteKt.irUp(this.f$0);
                return Unit.INSTANCE;
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                IrRemoteKt.irLearn$default(this.f$0, Fleet.T("ir.learn_bad", new Pair[0]), Fleet.T("ir.learn_bad_sub", new Pair("n", 4)), 0, 4);
                return Unit.INSTANCE;
            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                IrRemoteKt.irAuto$default(this.f$0, Fleet.T("ir.auto_none", new Pair[0]), Fleet.T("ir.auto_none_sub", new Pair[0]), null, 12);
                return Unit.INSTANCE;
            case 11:
                IrRemoteKt.irStop();
                IrRemoteKt.irAuto$default(this.f$0, null, null, null, 15);
                return Unit.INSTANCE;
            case FileClientSessionCache.MAX_SIZE /* 12 */:
                Fleet.web(this.f$0, "https://github.com/HoangTran0410");
                return Unit.INSTANCE;
            case 13:
                Fleet.web(this.f$0, "https://tvremote.pages.dev");
                return Unit.INSTANCE;
            case 14:
                Fleet.web(this.f$0, "https://tvremote.pages.dev/guide");
                return Unit.INSTANCE;
            case 15:
                Fleet.web(this.f$0, "https://tvremote.pages.dev/#install");
                return Unit.INSTANCE;
            case 16:
                WireLog wireLog = WireLog.all;
                MainActivity mainActivity = this.f$0;
                Remote remote2 = mainActivity.basic;
                if (remote2 != null && !Intrinsics.areEqual(remote2.getKind(), "android")) {
                    remote = remote2;
                }
                String report = wireLog.report(remote);
                Object systemService2 = mainActivity.getSystemService("clipboard");
                Intrinsics.checkNotNull(systemService2, "null cannot be cast to non-null type android.content.ClipboardManager");
                ((ClipboardManager) systemService2).setPrimaryClip(ClipData.newPlainText("TV Remote", report));
                Toast.makeText(mainActivity, Fleet.T("core.log_copied", new Pair[0]), 1).show();
                Fleet.web(mainActivity, "https://tvremote.pages.dev/log");
                return Unit.INSTANCE;
            case 17:
                Fleet.web(this.f$0, "https://github.com/Genymobile/scrcpy");
                return Unit.INSTANCE;
            case 18:
                UpdaterKt.checkUpdate(this.f$0, true);
                return Unit.INSTANCE;
            case 19:
                this.f$0.getAbout$android_release().setVisibility(0);
                return Unit.INSTANCE;
            case 20:
                boolean z = SoundPace.even;
                SharedPreferences.Editor edit = this.f$0.getPrefs$android_release().edit();
                ConcurrentHashMap concurrentHashMap = SoundPace.learned;
                Intrinsics.checkNotNull(concurrentHashMap, "null cannot be cast to non-null type kotlin.collections.Map<*, *>");
                edit.putString("soundLead", new JSONObject(concurrentHashMap).toString()).apply();
                return Unit.INSTANCE;
            case 21:
                MainActivity mainActivity2 = this.f$0;
                Fleet.setTalkMode(mainActivity2, "quick");
                mainActivity2.getTalk$android_release().open();
                return Unit.INSTANCE;
            case 22:
                MainActivity mainActivity3 = this.f$0;
                Fleet.setTalkMode(mainActivity3, "old");
                mainActivity3.speak$android_release();
                return Unit.INSTANCE;
            case 23:
                Tv tv2 = this.f$0.tv;
                if (tv2 != null && tv2.ready()) {
                    tv2.press(219);
                }
                return Unit.INSTANCE;
            case 24:
                AdbHelpKt.installSetup(this.f$0, UiKt.SETUP_APP);
                return Unit.INSTANCE;
            case 25:
                AdbHelpKt.findSettings(this.f$0);
                return Unit.INSTANCE;
            case 26:
                MainActivity mainActivity4 = this.f$0;
                Remote remote3 = mainActivity4.basic;
                if (remote3 != null) {
                    AdbHelpKt.tvJob(mainActivity4, new AdbHelpKt$$ExternalSyntheticLambda18(mainActivity4, remote3, 5));
                }
                mainActivity4.ui.postDelayed(new MainActivity$$ExternalSyntheticLambda15(mainActivity4, 14), 600L);
                return Unit.INSTANCE;
            case 27:
                MainActivity mainActivity5 = this.f$0;
                Remote remote4 = mainActivity5.basic;
                if (remote4 != null) {
                    AdbHelpKt.tvJob(mainActivity5, new AdbHelpKt$$ExternalSyntheticLambda40(remote4, 3));
                }
                Toast.makeText(mainActivity5, Fleet.T("adb_help.asking_downloader_to_download", new Pair[0]), 1).show();
                mainActivity5.ui.postDelayed(new MainActivity$$ExternalSyntheticLambda15(mainActivity5, i), 600L);
                return Unit.INSTANCE;
            case 28:
                MainActivity mainActivity6 = this.f$0;
                Remote remote5 = mainActivity6.basic;
                if (remote5 != null) {
                    AdbHelpKt.tvJob(mainActivity6, new AdbHelpKt$$ExternalSyntheticLambda18(mainActivity6, remote5, i2));
                }
                Toast.makeText(mainActivity6, Fleet.T("adb_help.entering_the_link_on", new Pair[0]), 1).show();
                mainActivity6.ui.postDelayed(new MainActivity$$ExternalSyntheticLambda15(mainActivity6, 13), 600L);
                return Unit.INSTANCE;
            default:
                AdbHelpKt.otherHome(this.f$0);
                return Unit.INSTANCE;
        }
    }

    public /* synthetic */ TalkKt$$ExternalSyntheticLambda1(MainActivity mainActivity, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
    }
}
