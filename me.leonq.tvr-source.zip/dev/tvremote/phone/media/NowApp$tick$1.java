package dev.tvremote.phone.media;

import android.graphics.Bitmap;
import android.os.Build;
import android.view.PixelCopy;
import android.widget.TextView;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.ontv.Foreground;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda5;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.picture.DrawingKt$$ExternalSyntheticLambda0;
import dev.tvremote.phone.remote.KbdWatch;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class NowApp$tick$1 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object this$0;

    public /* synthetic */ NowApp$tick$1(int i, Object obj) {
        this.$r8$classId = i;
        this.this$0 = obj;
    }

    /* JADX WARN: Type inference failed for: r5v5, types: [dev.tvremote.phone.media.PlayingBar$$ExternalSyntheticLambda10] */
    @Override // java.lang.Runnable
    public final void run() {
        boolean z;
        boolean z2;
        boolean z3;
        switch (this.$r8$classId) {
            case 0:
                if (!((NowApp) this.this$0).work.isShutdown()) {
                    ((NowApp) this.this$0).a.ui.postDelayed(this, 2000L);
                    MainActivity mainActivity = ((NowApp) this.this$0).a;
                    String str = mainActivity.host;
                    Tv tv = mainActivity.tv;
                    NowApp nowApp = (NowApp) this.this$0;
                    MainActivity mainActivity2 = nowApp.a;
                    Remote remote = mainActivity2.basic;
                    if (!mainActivity2.foreground) {
                        nowApp.fine = System.currentTimeMillis();
                    }
                    MainActivity mainActivity3 = ((NowApp) this.this$0).a;
                    if (mainActivity3.foreground && mainActivity3.getRemote$android_release().getVisibility() == 0 && !((NowApp) this.this$0).a.covered$android_release() && str != null) {
                        NowApp nowApp2 = (NowApp) this.this$0;
                        if (!nowApp2.asking) {
                            nowApp2.asking = true;
                            if (!str.equals(nowApp2.frontFor)) {
                                ((NowApp) this.this$0).front = new Foreground();
                                ((NowApp) this.this$0).frontFor = str;
                            }
                            if (remote == null && (tv == null || !tv.ready())) {
                                z = false;
                            } else {
                                z = true;
                            }
                            NowApp nowApp3 = (NowApp) this.this$0;
                            nowApp3.work.execute(new NowApp$tick$1$$ExternalSyntheticLambda0(remote, nowApp3, tv, str, z));
                            return;
                        }
                    }
                    if (str == null) {
                        NowApp.access$show((NowApp) this.this$0, "", "", null);
                        return;
                    }
                    return;
                }
                return;
            case 1:
                Tv tv2 = ((PlayingBar) this.this$0).a.tv;
                MainActivity mainActivity4 = ((PlayingBar) this.this$0).a;
                if (mainActivity4.foreground && mainActivity4.getRemote$android_release().getVisibility() == 0 && !((PlayingBar) this.this$0).a.covered$android_release() && ((PlayingBar) this.this$0).a.basic == null && tv2 != null && tv2.ready()) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                MainActivity mainActivity5 = ((PlayingBar) this.this$0).a;
                if (mainActivity5.listen && mainActivity5.basic == null && tv2 != null && tv2.ready()) {
                    z3 = true;
                } else {
                    z3 = false;
                }
                if (z2 || !((PlayingBar) this.this$0).a.foreground) {
                    ((PlayingBar) this.this$0).fine = System.currentTimeMillis();
                }
                if (!z2 && !z3) {
                    PlayingBar playingBar = (PlayingBar) this.this$0;
                    if (!Intrinsics.areEqual(playingBar.a.host, playingBar.oHost) || (((PlayingBar) this.this$0).a.foreground && System.currentTimeMillis() - ((PlayingBar) this.this$0).fine > 5000)) {
                        ((PlayingBar) this.this$0).o = Census$$ExternalSyntheticOutline0.m8m("state", "none");
                    }
                    ((PlayingBar) this.this$0).draw();
                    ((PlayingBar) this.this$0).a.ui.postDelayed(this, 2000L);
                    return;
                }
                PlayingBar playingBar2 = (PlayingBar) this.this$0;
                if (!playingBar2.asking) {
                    playingBar2.asking = true;
                    playingBar2.work.execute(new Guard$$ExternalSyntheticLambda5(25, playingBar2, tv2));
                }
                ((PlayingBar) this.this$0).draw();
                final PlayingBar playingBar3 = (PlayingBar) this.this$0;
                if (!Intrinsics.areEqual(playingBar3.o.optString("state", "none"), "none")) {
                    MainActivity mainActivity6 = playingBar3.a;
                    if (mainActivity6.getStage$android_release().getVisibility() == 0 && mainActivity6.getSurface$android_release().getVisibility() == 0 && mainActivity6.getSurface$android_release().getHolder().getSurface().isValid() && Build.VERSION.SDK_INT >= 24) {
                        try {
                            PixelCopy.request(mainActivity6.getSurface$android_release(), (Bitmap) playingBar3.blackBmp$delegate.getValue(), (PixelCopy.OnPixelCopyFinishedListener) new PixelCopy.OnPixelCopyFinishedListener() { // from class: dev.tvremote.phone.media.PlayingBar$$ExternalSyntheticLambda10
                                @Override // android.view.PixelCopy.OnPixelCopyFinishedListener
                                public final void onPixelCopyFinished(int i) {
                                    int i2;
                                    int i3;
                                    PlayingBar playingBar4 = PlayingBar.this;
                                    int i4 = 0;
                                    if (i == 0) {
                                        i2 = 0;
                                        for (int i5 = 0; i5 < 18; i5++) {
                                            for (int i6 = 0; i6 < 32; i6++) {
                                                int pixel = ((Bitmap) playingBar4.blackBmp$delegate.getValue()).getPixel(i6, i5);
                                                if (((pixel >> 16) & 255) + ((pixel >> 8) & 255) + (pixel & 255) < 60) {
                                                    i2++;
                                                }
                                            }
                                        }
                                    } else {
                                        i2 = 0;
                                    }
                                    if (i == 0 && i2 > 518) {
                                        i3 = playingBar4.blackFor + 1;
                                    } else {
                                        i3 = 0;
                                    }
                                    playingBar4.blackFor = i3;
                                    TextView textView = (TextView) playingBar4.blackHint$delegate.getValue();
                                    if (playingBar4.blackFor < 4) {
                                        i4 = 8;
                                    }
                                    textView.setVisibility(i4);
                                }
                            }, mainActivity6.ui);
                        } catch (Exception unused) {
                            playingBar3.blackFor = 0;
                        }
                        ((PlayingBar) this.this$0).a.ui.postDelayed(this, 1000L);
                        return;
                    }
                }
                playingBar3.blackFor = 0;
                ((TextView) playingBar3.blackHint$delegate.getValue()).setVisibility(8);
                ((PlayingBar) this.this$0).a.ui.postDelayed(this, 1000L);
                return;
            default:
                if (!((KbdWatch) this.this$0).work.isShutdown()) {
                    ((KbdWatch) this.this$0).a.ui.postDelayed(this, 1000L);
                    Tv tv3 = ((KbdWatch) this.this$0).a.tv;
                    KbdWatch kbdWatch = (KbdWatch) this.this$0;
                    if (!kbdWatch.asking) {
                        MainActivity mainActivity7 = kbdWatch.a;
                        if (mainActivity7.foreground && mainActivity7.getRemote$android_release().getVisibility() == 0 && !((KbdWatch) this.this$0).a.covered$android_release() && tv3 != null && tv3.ready() && ((KbdWatch) this.this$0).a.getPrefs$android_release().getBoolean("kbdAuto", true)) {
                            KbdWatch kbdWatch2 = (KbdWatch) this.this$0;
                            kbdWatch2.asking = true;
                            kbdWatch2.work.execute(new DrawingKt$$ExternalSyntheticLambda0(4, kbdWatch2, tv3));
                            return;
                        }
                        return;
                    }
                    return;
                }
                return;
        }
    }
}
