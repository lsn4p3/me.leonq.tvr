package dev.tvremote.phone.media;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import com.android.apksig.internal.apk.ApkSigningBlockUtils;
import dev.tvremote.core.SupportAndroid$store$1;
import dev.tvremote.core.picture.Sps;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.ui.Popup;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.security.DigestException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Iterator;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class MediaKt$castFile$tick$1 implements Runnable {
    public final Object $box;
    public final Object $job;
    public final /* synthetic */ int $r8$classId = 1;
    public final Object $sending;
    public final Object $this_castFile;

    public MediaKt$castFile$tick$1(Popup popup, MainActivity mainActivity, JSONObject jSONObject, String str) {
        this.$box = popup;
        this.$this_castFile = mainActivity;
        this.$job = jSONObject;
        this.$sending = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        String str;
        switch (this.$r8$classId) {
            case 0:
                Popup popup = (Popup) this.$box;
                if (popup.isShowing()) {
                    MainActivity mainActivity = (MainActivity) this.$this_castFile;
                    if (!mainActivity.isFinishing()) {
                        int optInt = ((JSONObject) this.$job).optInt("pct", 0);
                        if (optInt > 0) {
                            str = ApkSigner$$ExternalSyntheticOutline0.m(" · ", optInt, "%");
                        } else {
                            str = "...";
                        }
                        popup.setMessage(((String) this.$sending) + str);
                        mainActivity.ui.postDelayed(this, 500L);
                        return;
                    }
                    return;
                }
                return;
            default:
                ArrayList arrayList = (ArrayList) this.$this_castFile;
                ApkSigningBlockUtils.ChunkSupplier chunkSupplier = (ApkSigningBlockUtils.ChunkSupplier) this.$box;
                byte[] bArr = new byte[5];
                bArr[0] = -91;
                try {
                    for (Sps.Out out = chunkSupplier.get(); out != null; out = chunkSupplier.get()) {
                        int i = out.n;
                        if (i <= 1048576) {
                            ApkSigningBlockUtils.access$500(i, bArr);
                            SupportAndroid$store$1 supportAndroid$store$1 = (SupportAndroid$store$1) this.$sending;
                            supportAndroid$store$1.consume(bArr, 0, 5);
                            supportAndroid$store$1.consume((ByteBuffer) out.o);
                            for (int i2 = 0; i2 < arrayList.size(); i2++) {
                                ApkSigningBlockUtils.ChunkDigests chunkDigests = (ApkSigningBlockUtils.ChunkDigests) arrayList.get(i2);
                                MessageDigest messageDigest = (MessageDigest) ((ArrayList) this.$job).get(i2);
                                byte[] bArr2 = chunkDigests.concatOfDigestsOfChunks;
                                int i3 = out.cur;
                                int i4 = chunkDigests.digestOutputSize;
                                int digest = messageDigest.digest(bArr2, (i3 * i4) + 5, i4);
                                if (digest != i4) {
                                    throw new RuntimeException("Unexpected output size of " + chunkDigests.algorithm + " digest: " + digest);
                                }
                            }
                        } else {
                            throw new RuntimeException("Chunk size greater than expected: " + i);
                        }
                    }
                    return;
                } catch (IOException e) {
                    e = e;
                    throw new RuntimeException(e);
                } catch (DigestException e2) {
                    e = e2;
                    throw new RuntimeException(e);
                }
        }
    }

    public MediaKt$castFile$tick$1(ApkSigningBlockUtils.ChunkSupplier chunkSupplier, ArrayList arrayList) {
        this.$box = chunkSupplier;
        this.$this_castFile = arrayList;
        this.$job = new ArrayList(arrayList.size());
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            try {
                ((ArrayList) this.$job).add(MessageDigest.getInstance(((ApkSigningBlockUtils.ChunkDigests) it.next()).algorithm.mJcaMessageDigestAlgorithm));
            } catch (NoSuchAlgorithmException e) {
                throw new RuntimeException(e);
            }
        }
        this.$sending = new SupportAndroid$store$1(4, (MessageDigest[]) ((ArrayList) this.$job).toArray(new MessageDigest[0]));
    }
}
