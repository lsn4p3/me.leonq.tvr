package dev.tvremote.phone.media;

import dev.tvremote.core.Fleet;
import dev.tvremote.phone.MainActivity;

/* loaded from: classes.dex */
public final /* synthetic */ class MediaKt$$ExternalSyntheticLambda2 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ int f$1;

    public /* synthetic */ MediaKt$$ExternalSyntheticLambda2(MainActivity mainActivity, int i, int i2) {
        this.$r8$classId = i2;
        this.f$0 = mainActivity;
        this.f$1 = i;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.$r8$classId) {
            case 0:
                MainActivity mainActivity = this.f$0;
                if (!mainActivity.isFinishing()) {
                    Fleet.sendShared(this.f$1 + 1, mainActivity);
                    return;
                }
                return;
            case 1:
                this.f$0.picWatchers = this.f$1;
                return;
            default:
                this.f$0.press$android_release(false, this.f$1);
                return;
        }
    }
}
