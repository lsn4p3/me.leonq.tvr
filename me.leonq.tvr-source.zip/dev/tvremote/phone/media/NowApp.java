package dev.tvremote.phone.media;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.adb.Adb$$ExternalSyntheticLambda0;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.ontv.Foreground;
import dev.tvremote.core.ontv.RemoteLabels;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda8;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.picture.MiniPlayer;
import dev.tvremote.phone.ui.UiKt;
import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kotlin.Pair;
import kotlin.collections.EmptyMap;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

/* loaded from: classes.dex */
public final class NowApp {
    public final MainActivity a;
    public boolean asking;
    public final Button chip;
    public long fine;
    public Foreground front;
    public String frontFor;
    public final ImageView icon;
    public RemoteLabels labels;
    public String labelsFor;
    public AdbLink link;
    public final TextView name;
    public Remote namesFrom;
    public Object remoteNames;
    public String shown;
    public String shownFor;
    public final NowApp$tick$1 tick;
    public final LinearLayout view;
    public final ExecutorService work;

    /* renamed from: dev.tvremote.phone.media.NowApp$2, reason: invalid class name */
    /* loaded from: classes.dex */
    public final class AnonymousClass2 extends ViewOutlineProvider {
        public final /* synthetic */ int $r8$classId;
        public final /* synthetic */ Object this$0;

        public /* synthetic */ AnonymousClass2(int i, Object obj) {
            this.$r8$classId = i;
            this.this$0 = obj;
        }

        @Override // android.view.ViewOutlineProvider
        public final void getOutline(View v, Outline o) {
            float dp;
            switch (this.$r8$classId) {
                case 0:
                    Intrinsics.checkNotNullParameter(v, "v");
                    Intrinsics.checkNotNullParameter(o, "o");
                    o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), UiKt.dp((Context) ((NowApp) this.this$0).a, 6));
                    return;
                default:
                    Intrinsics.checkNotNullParameter(v, "v");
                    Intrinsics.checkNotNullParameter(o, "o");
                    int width = v.getWidth();
                    int height = v.getHeight();
                    MiniPlayer miniPlayer = (MiniPlayer) this.this$0;
                    if (miniPlayer.pip) {
                        dp = 0.0f;
                    } else {
                        dp = UiKt.dp((Context) miniPlayer.a, 14);
                    }
                    o.setRoundRect(0, 0, width, height, dp);
                    return;
            }
        }
    }

    public NowApp(MainActivity mainActivity) {
        this.a = mainActivity;
        LinearLayout linearLayout = new LinearLayout(mainActivity);
        this.view = linearLayout;
        ImageView imageView = new ImageView(mainActivity);
        this.icon = imageView;
        TextView label = UiKt.label(mainActivity, "", 14, UiKt.TEXT);
        this.name = label;
        this.front = new Foreground();
        this.work = Executors.newSingleThreadExecutor();
        this.labelsFor = "";
        this.remoteNames = EmptyMap.INSTANCE;
        this.shown = "";
        String T = Fleet.T("rkey.pad_chip", new Pair[0]);
        String replaceAll = Census$$ExternalSyntheticOutline0.m7m("^[^\\p{L}]+", "compile(...)", T, "input", T).replaceAll("");
        Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
        Button button = UiKt.button(mainActivity, "@gamepad|".concat(replaceAll), UiKt.BTN);
        this.chip = button;
        linearLayout.setGravity(17);
        linearLayout.setVisibility(8);
        linearLayout.addView(UiKt.label(mainActivity, Fleet.T("apps.now_open", new Pair[0]), 13, UiKt.MUTED));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, UiKt.dp(mainActivity, 24));
        float f = 8;
        layoutParams.leftMargin = UiKt.dp(mainActivity, f);
        linearLayout.addView(imageView, layoutParams);
        imageView.setOutlineProvider(new AnonymousClass2(0, this));
        imageView.setClipToOutline(true);
        imageView.setAdjustViewBounds(true);
        imageView.setMaxWidth(UiKt.dp(mainActivity, 96));
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        label.setTypeface(Typeface.DEFAULT_BOLD);
        UiKt.runs(label);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.leftMargin = UiKt.dp(mainActivity, f);
        linearLayout.addView(label, layoutParams2);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-2, UiKt.dp(mainActivity, 32));
        layoutParams3.leftMargin = UiKt.dp(mainActivity, 12);
        linearLayout.addView(button, layoutParams3);
        button.setVisibility(8);
        button.setTextSize(13.0f);
        button.setOnClickListener(new Guard$$ExternalSyntheticLambda8(3, this));
        mainActivity.ui.post(new Adb$$ExternalSyntheticLambda0(7, this));
        this.tick = new NowApp$tick$1(0, this);
    }

    public static final File access$cacheDir(NowApp nowApp, String str) {
        nowApp.getClass();
        File cacheDir = nowApp.a.getCacheDir();
        String replaceAll = Census$$ExternalSyntheticOutline0.m7m("[^\\w.-]", "compile(...)", str, "input", str).replaceAll("_");
        Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
        return new File(cacheDir, "meta/".concat(replaceAll));
    }

    public static final void access$show(NowApp nowApp, String str, String str2, byte[] bArr) {
        boolean z;
        int i;
        int i2;
        Integer num;
        Integer num2;
        Tv tv;
        nowApp.getClass();
        int i3 = 0;
        if (str.length() == 0 || (str2.length() == 0 && StringsKt.contains$default(str, '.') && bArr == null)) {
            z = true;
        } else {
            z = false;
        }
        LinearLayout linearLayout = nowApp.view;
        if (z) {
            i = 8;
        } else {
            i = 0;
        }
        linearLayout.setVisibility(i);
        Button button = nowApp.chip;
        if (str.equals("dev.tvremote.games") && (tv = nowApp.a.tv) != null && tv.ready()) {
            i2 = 0;
        } else {
            i2 = 8;
        }
        button.setVisibility(i2);
        if (!z) {
            Bitmap bitmap = null;
            if (bArr != null) {
                num = Integer.valueOf(bArr.length);
            } else {
                num = null;
            }
            if (!Intrinsics.areEqual(str + "|" + str2 + "|" + num, nowApp.shown)) {
                if (bArr != null) {
                    num2 = Integer.valueOf(bArr.length);
                } else {
                    num2 = null;
                }
                nowApp.shown = str + "|" + str2 + "|" + num2;
                TextView textView = nowApp.name;
                if (str2.length() != 0) {
                    str = str2;
                }
                UiKt.say(textView, str);
                if (bArr != null) {
                    bitmap = BitmapFactory.decodeByteArray(bArr, 0, bArr.length);
                }
                nowApp.icon.setImageBitmap(bitmap);
                ImageView imageView = nowApp.icon;
                if (bitmap == null) {
                    i3 = 8;
                }
                imageView.setVisibility(i3);
            }
        }
    }
}
