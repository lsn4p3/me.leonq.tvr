package dev.tvremote.phone.media;

import android.speech.SpeechRecognizer;
import dev.tvremote.core.Fleet;
import kotlin.Pair;
import kotlin.text.StringsKt;

/* loaded from: classes.dex */
public final /* synthetic */ class Talk$$ExternalSyntheticLambda4 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Talk f$0;

    public /* synthetic */ Talk$$ExternalSyntheticLambda4(Talk talk, int i) {
        this.$r8$classId = i;
        this.f$0 = talk;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.$r8$classId) {
            case 0:
                Talk talk = this.f$0;
                SpeechRecognizer speechRecognizer = talk.rec;
                if (speechRecognizer != null) {
                    speechRecognizer.destroy();
                }
                talk.rec = null;
                return;
            default:
                Talk talk2 = this.f$0;
                talk2.settle = null;
                if (!StringsKt.isBlank(talk2.lastPartial)) {
                    talk2.send(talk2.lastPartial);
                    return;
                } else {
                    talk2.end();
                    talk2.say(Fleet.T("talk.heard_nothing", new Pair[0]));
                    return;
                }
        }
    }
}
