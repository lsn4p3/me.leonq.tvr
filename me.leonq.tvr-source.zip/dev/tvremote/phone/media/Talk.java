package dev.tvremote.phone.media;

import android.R;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.speech.RecognitionListener;
import android.speech.RecognitionSupport;
import android.speech.RecognitionSupportCallback;
import android.speech.SpeechRecognizer;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewPropertyAnimator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Words;
import dev.tvremote.core.adb.Adb$$ExternalSyntheticLambda0;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.scenes.Scenes;
import dev.tvremote.core.scenes.Voice;
import dev.tvremote.guard.Guard$install$r$1;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.phone.ui.UiKt;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyList;
import kotlin.collections.EmptyMap;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class Talk {
    public final MainActivity a;
    public FrameLayout btn;
    public boolean cancelling;
    public boolean fake;
    public boolean holding;
    public final Talk$listener$1 listener;
    public TextView live;
    public boolean offline;
    public FrameLayout overlay;
    public LinearLayout plans;
    public SpeechRecognizer rec;
    public final Talk$$ExternalSyntheticLambda4 release;
    public View ring;
    public Guard$install$r$1 rx;
    public Object sayings;
    public Object scenes;
    public Talk$$ExternalSyntheticLambda4 settle;
    public TextView state;
    public TextView willDo;
    public final Handler h = new Handler(Looper.getMainLooper());
    public String lastPartial = "";
    public List alternatives = EmptyList.INSTANCE;

    /* JADX WARN: Type inference failed for: r2v6, types: [dev.tvremote.phone.media.Talk$listener$1] */
    public Talk(MainActivity mainActivity) {
        this.a = mainActivity;
        EmptyMap emptyMap = EmptyMap.INSTANCE;
        this.scenes = emptyMap;
        this.sayings = emptyMap;
        this.release = new Talk$$ExternalSyntheticLambda4(this, 0);
        this.listener = new RecognitionListener() { // from class: dev.tvremote.phone.media.Talk$listener$1
            @Override // android.speech.RecognitionListener
            public final void onBeginningOfSpeech() {
            }

            @Override // android.speech.RecognitionListener
            public final void onBufferReceived(byte[] bArr) {
            }

            @Override // android.speech.RecognitionListener
            public final void onEndOfSpeech() {
            }

            @Override // android.speech.RecognitionListener
            public final void onError(int i) {
                Talk.this.failed(i);
            }

            @Override // android.speech.RecognitionListener
            public final void onEvent(int i, Bundle bundle) {
            }

            @Override // android.speech.RecognitionListener
            public final void onPartialResults(Bundle p) {
                Intrinsics.checkNotNullParameter(p, "p");
                ArrayList<String> stringArrayList = p.getStringArrayList("results_recognition");
                if (stringArrayList != null) {
                    ArrayList arrayList = new ArrayList();
                    for (Object obj : stringArrayList) {
                        String str = (String) obj;
                        Intrinsics.checkNotNull(str);
                        if (!StringsKt.isBlank(str)) {
                            arrayList.add(obj);
                        }
                    }
                    Talk.access$heard(Talk.this, arrayList, false);
                }
            }

            @Override // android.speech.RecognitionListener
            public final void onReadyForSpeech(Bundle bundle) {
            }

            @Override // android.speech.RecognitionListener
            public final void onResults(Bundle p) {
                List list;
                Intrinsics.checkNotNullParameter(p, "p");
                ArrayList<String> stringArrayList = p.getStringArrayList("results_recognition");
                if (stringArrayList != null) {
                    list = new ArrayList();
                    for (Object obj : stringArrayList) {
                        String str = (String) obj;
                        Intrinsics.checkNotNull(str);
                        if (!StringsKt.isBlank(str)) {
                            list.add(obj);
                        }
                    }
                } else {
                    list = EmptyList.INSTANCE;
                }
                Talk.access$heard(Talk.this, list, true);
            }

            @Override // android.speech.RecognitionListener
            public final void onRmsChanged(float f) {
                ViewPropertyAnimator animate;
                ViewPropertyAnimator scaleX;
                ViewPropertyAnimator scaleY;
                ViewPropertyAnimator duration;
                Talk talk = Talk.this;
                if (talk.holding) {
                    float coerceIn = ((MathKt.coerceIn(f, 0.0f, 10.0f) / 10.0f) * 0.35f) + 1.0f;
                    View view = talk.ring;
                    if (view != null && (animate = view.animate()) != null && (scaleX = animate.scaleX(coerceIn)) != null && (scaleY = scaleX.scaleY(coerceIn)) != null && (duration = scaleY.setDuration(90L)) != null) {
                        duration.start();
                    }
                }
            }
        };
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r6v0, types: [java.util.Map, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r8v0, types: [java.util.List, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r9v0, types: [java.util.Map, java.lang.Object] */
    public static final void access$heard(Talk talk, List list, boolean z) {
        String str;
        boolean z2;
        if (talk.holding || talk.settle != null) {
            if (!list.isEmpty()) {
                talk.lastPartial = (String) list.get(0);
                talk.alternatives = list;
            }
            if (talk.holding) {
                if (StringsKt.isBlank(talk.lastPartial)) {
                    talk.liveText(false, Fleet.T("talk.listening", new Pair[0]));
                } else {
                    talk.liveText(true, talk.lastPartial);
                }
                List<String> take = CollectionsKt.take(CollectionsKt.distinct(talk.alternatives), 3);
                ArrayList arrayList = new ArrayList();
                for (String str2 : take) {
                    Voice voice = Voice.INSTANCE;
                    MainActivity mainActivity = talk.a;
                    Map map = mainActivity.appNames;
                    ?? r6 = talk.scenes;
                    Tv tv = mainActivity.tv;
                    if (tv != null && tv.ready()) {
                        z2 = true;
                    } else {
                        z2 = false;
                    }
                    Voice.Plan preview = voice.preview(str2, map, r6, z2, talk.a.voicePins, talk.sayings);
                    if (preview != null) {
                        arrayList.add(preview);
                    }
                }
                HashSet hashSet = new HashSet();
                ArrayList arrayList2 = new ArrayList();
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    Object next = it.next();
                    if (hashSet.add(((Voice.Plan) next).say)) {
                        arrayList2.add(next);
                    }
                }
                talk.listPlans(arrayList2);
                return;
            }
            if (z) {
                Talk$$ExternalSyntheticLambda4 talk$$ExternalSyntheticLambda4 = talk.settle;
                if (talk$$ExternalSyntheticLambda4 != null) {
                    talk.h.removeCallbacks(talk$$ExternalSyntheticLambda4);
                }
                talk.settle = null;
                if (!list.isEmpty()) {
                    str = (String) list.get(0);
                } else {
                    str = talk.lastPartial;
                }
                talk.send(str);
            }
        }
    }

    public final void begin(boolean z) {
        if (!this.holding && this.overlay != null) {
            this.holding = true;
            this.cancelling = false;
            this.fake = z;
            this.lastPartial = "";
            this.alternatives = EmptyList.INSTANCE;
            Talk$$ExternalSyntheticLambda4 talk$$ExternalSyntheticLambda4 = this.settle;
            Handler handler = this.h;
            if (talk$$ExternalSyntheticLambda4 != null) {
                handler.removeCallbacks(talk$$ExternalSyntheticLambda4);
            }
            this.settle = null;
            this.a.buzz$android_release();
            try {
                ToneGenerator toneGenerator = new ToneGenerator(3, 35);
                toneGenerator.startTone(25, 80);
                handler.postDelayed(new Adb$$ExternalSyntheticLambda0(9, toneGenerator), 300L);
            } catch (Exception unused) {
            }
            liveText(false, Fleet.T("talk.listening", new Pair[0]));
            LinearLayout linearLayout = this.plans;
            if (linearLayout != null) {
                linearLayout.removeAllViews();
            }
            TextView textView = this.willDo;
            if (textView != null) {
                textView.setVisibility(8);
            }
            TextView textView2 = this.state;
            if (textView2 != null) {
                textView2.setText(Fleet.T("talk.release", new Pair[0]));
            }
            paintButton();
            if (!z) {
                try {
                    SpeechRecognizer speechRecognizer = this.rec;
                    if (speechRecognizer != null) {
                        speechRecognizer.startListening(intent());
                    }
                } catch (Exception unused2) {
                    this.rec = null;
                    warm();
                    try {
                        SpeechRecognizer speechRecognizer2 = this.rec;
                        if (speechRecognizer2 != null) {
                            speechRecognizer2.startListening(intent());
                        }
                    } catch (Exception unused3) {
                        failed(-1);
                    }
                }
            }
        }
    }

    public final void cancelNow() {
        this.holding = false;
        this.cancelling = false;
        Talk$$ExternalSyntheticLambda4 talk$$ExternalSyntheticLambda4 = this.settle;
        if (talk$$ExternalSyntheticLambda4 != null) {
            this.h.removeCallbacks(talk$$ExternalSyntheticLambda4);
        }
        this.settle = null;
        if (!this.fake) {
            try {
                SpeechRecognizer speechRecognizer = this.rec;
                if (speechRecognizer != null) {
                    speechRecognizer.cancel();
                }
            } catch (Exception unused) {
            }
        }
        this.lastPartial = "";
        idle();
    }

    public final void close() {
        ViewGroup viewGroup;
        cancelNow();
        FrameLayout frameLayout = this.overlay;
        if (frameLayout != null) {
            ViewParent parent = frameLayout.getParent();
            if (parent instanceof ViewGroup) {
                viewGroup = (ViewGroup) parent;
            } else {
                viewGroup = null;
            }
            if (viewGroup != null) {
                viewGroup.removeView(frameLayout);
            }
        }
        this.overlay = null;
        this.h.postDelayed(this.release, 30000L);
    }

    public final void end() {
        this.holding = false;
        Talk$$ExternalSyntheticLambda4 talk$$ExternalSyntheticLambda4 = this.settle;
        if (talk$$ExternalSyntheticLambda4 != null) {
            this.h.removeCallbacks(talk$$ExternalSyntheticLambda4);
        }
        this.settle = null;
        if (!this.fake) {
            try {
                SpeechRecognizer speechRecognizer = this.rec;
                if (speechRecognizer != null) {
                    speechRecognizer.cancel();
                }
            } catch (Exception unused) {
            }
        }
        paintButton();
    }

    public final void failed(int i) {
        boolean z = this.holding;
        if (z || this.settle != null) {
            if (i == 9) {
                end();
                this.a.speak$android_release();
                return;
            }
            if (z && i != 7 && i != 6 && i != 5) {
                end();
                say(Fleet.T("talk.error", new Pair("code", Integer.valueOf(i))));
                return;
            }
            if (z) {
                return;
            }
            Talk$$ExternalSyntheticLambda4 talk$$ExternalSyntheticLambda4 = this.settle;
            if (talk$$ExternalSyntheticLambda4 != null) {
                this.h.removeCallbacks(talk$$ExternalSyntheticLambda4);
            }
            this.settle = null;
            if (!StringsKt.isBlank(this.lastPartial)) {
                send(this.lastPartial);
            } else {
                end();
                say(Fleet.T("talk.heard_nothing", new Pair[0]));
            }
        }
    }

    public final void idle() {
        liveText(false, Fleet.T("talk.hint", new Pair[0]));
        LinearLayout linearLayout = this.plans;
        if (linearLayout != null) {
            linearLayout.removeAllViews();
        }
        TextView textView = this.willDo;
        if (textView != null) {
            textView.setVisibility(8);
        }
        TextView textView2 = this.state;
        if (textView2 != null) {
            textView2.setText(Fleet.T("talk.hold", new Pair[0]));
        }
        paintButton();
    }

    public final Intent intent() {
        String str;
        Intent putExtra = new Intent("android.speech.action.RECOGNIZE_SPEECH").putExtra("android.speech.extra.LANGUAGE_MODEL", "free_form");
        ConcurrentHashMap concurrentHashMap = Words.books;
        String str2 = Words.lang;
        if (Intrinsics.areEqual(str2, "vi")) {
            str = "vi-VN";
        } else if (Intrinsics.areEqual(str2, "en")) {
            str = "en-US";
        } else {
            str = Words.lang;
        }
        Intent putExtra2 = putExtra.putExtra("android.speech.extra.LANGUAGE", str).putExtra("android.speech.extra.PARTIAL_RESULTS", true).putExtra("android.speech.extra.MAX_RESULTS", 3).putExtra("android.speech.extra.PREFER_OFFLINE", this.offline).putExtra("calling_package", this.a.getPackageName());
        Intrinsics.checkNotNullExpressionValue(putExtra2, "putExtra(...)");
        return putExtra2;
    }

    public final void let_go(boolean z) {
        long j;
        if (!this.holding) {
            return;
        }
        this.holding = false;
        if (z) {
            cancelNow();
            say(Fleet.T("talk.cancelled", new Pair[0]));
            return;
        }
        SystemClock.uptimeMillis();
        paintButton();
        if (!this.fake) {
            try {
                SpeechRecognizer speechRecognizer = this.rec;
                if (speechRecognizer != null) {
                    speechRecognizer.stopListening();
                }
            } catch (Exception unused) {
            }
        }
        Talk$$ExternalSyntheticLambda4 talk$$ExternalSyntheticLambda4 = new Talk$$ExternalSyntheticLambda4(this, 1);
        this.settle = talk$$ExternalSyntheticLambda4;
        Handler handler = this.h;
        if (!StringsKt.isBlank(this.lastPartial)) {
            j = 300;
        } else {
            j = 1000;
        }
        handler.postDelayed(talk$$ExternalSyntheticLambda4, j);
    }

    public final void listPlans(List list) {
        float f;
        Typeface typeface;
        boolean z;
        int i;
        GradientDrawable box;
        int i2;
        int i3;
        LinearLayout linearLayout = this.plans;
        if (linearLayout != null) {
            linearLayout.removeAllViews();
            TextView textView = this.willDo;
            if (textView != null) {
                if (list.isEmpty()) {
                    i3 = 8;
                } else {
                    i3 = 0;
                }
                textView.setVisibility(i3);
            }
            int i4 = 0;
            for (Object obj : list) {
                int i5 = i4 + 1;
                if (i4 >= 0) {
                    Voice.Plan plan = (Voice.Plan) obj;
                    MainActivity mainActivity = this.a;
                    TextView textView2 = new TextView(mainActivity);
                    Voice.Say say = plan.say;
                    Map map = say.args;
                    ArrayList arrayList = new ArrayList(map.size());
                    for (Map.Entry entry : map.entrySet()) {
                        arrayList.add(new Pair(entry.getKey(), entry.getValue()));
                    }
                    Pair[] pairArr = (Pair[]) arrayList.toArray(new Pair[0]);
                    textView2.setText(Fleet.T(say.id, (Pair[]) Arrays.copyOf(pairArr, pairArr.length)));
                    if (i4 == 0) {
                        f = 17.0f;
                    } else {
                        f = 14.0f;
                    }
                    textView2.setTextSize(f);
                    if (i4 == 0) {
                        typeface = Typeface.DEFAULT_BOLD;
                    } else {
                        typeface = Typeface.DEFAULT;
                    }
                    textView2.setTypeface(typeface);
                    if (plan.command != null) {
                        z = true;
                    } else {
                        z = false;
                    }
                    if (i4 == 0 && z) {
                        i = UiKt.ACCENT_TEXT;
                    } else {
                        i = UiKt.MUTED;
                    }
                    textView2.setTextColor(i);
                    float f2 = 14;
                    float f3 = 10;
                    textView2.setPadding(UiKt.dp(mainActivity, f2), UiKt.dp(mainActivity, f3), UiKt.dp(mainActivity, f2), UiKt.dp(mainActivity, f3));
                    if (i4 == 0 && z) {
                        box = UiKt.onBox(14, mainActivity, true);
                    } else {
                        box = UiKt.box(mainActivity, UiKt.BTN, 14);
                    }
                    textView2.setBackground(box);
                    if (i4 == 0) {
                        i2 = 0;
                    } else {
                        i2 = 6;
                    }
                    linearLayout.addView(textView2, UiKt.gap(mainActivity, i2));
                    i4 = i5;
                } else {
                    CollectionsKt__CollectionsKt.throwIndexOverflow();
                    throw null;
                }
            }
        }
    }

    public final void liveText(boolean z, String str) {
        int i;
        float f;
        Typeface typeface;
        TextView textView = this.live;
        if (textView != null) {
            textView.setText(str);
            if (z) {
                i = UiKt.TEXT;
            } else {
                i = UiKt.MUTED;
            }
            textView.setTextColor(i);
            if (z) {
                f = 24.0f;
            } else {
                f = 16.0f;
            }
            textView.setTextSize(f);
            if (z) {
                typeface = Typeface.DEFAULT_BOLD;
            } else {
                typeface = Typeface.DEFAULT;
            }
            textView.setTypeface(typeface);
        }
    }

    public final void open() {
        final int i = 1;
        final int i2 = 0;
        if (this.overlay == null) {
            MainActivity mainActivity = this.a;
            if (mainActivity.getPackageManager().checkPermission("android.permission.RECORD_AUDIO", mainActivity.getPackageName()) != 0) {
                Popup.Builder builder = new Popup.Builder(mainActivity);
                builder.title = Fleet.T("talk.title", new Pair[0]);
                builder.message = Fleet.T("talk.why_mic", new Pair[0]);
                builder.setPositiveButton(Fleet.T("common.ok", new Pair[0]), new Talk$$ExternalSyntheticLambda5(0, this));
                builder.setNegativeButton(Fleet.T("common.cancel", new Pair[0]), null);
                builder.show();
                return;
            }
            if (!SpeechRecognizer.isRecognitionAvailable(mainActivity) && (mainActivity.getApplicationInfo().flags & 2) == 0) {
                mainActivity.speak$android_release();
                return;
            }
            this.h.removeCallbacks(this.release);
            ArrayList list = MathKt.list(mainActivity);
            int mapCapacity = MapsKt__MapsKt.mapCapacity(CollectionsKt__IterablesKt.collectionSizeOrDefault(list));
            if (mapCapacity < 16) {
                mapCapacity = 16;
            }
            LinkedHashMap linkedHashMap = new LinkedHashMap(mapCapacity);
            Iterator it = list.iterator();
            while (it.hasNext()) {
                JSONObject jSONObject = (JSONObject) it.next();
                linkedHashMap.put(jSONObject.optString("id"), jSONObject.optString("name"));
            }
            this.scenes = linkedHashMap;
            HashMap hashMap = Scenes.KEYS;
            this.sayings = Scenes.sayings(new JSONArray((Collection) MathKt.list(mainActivity)));
            Fleet.warmAppNames(mainActivity, null);
            FrameLayout frameLayout = new FrameLayout(mainActivity);
            frameLayout.setBackgroundColor(UiKt.BG);
            frameLayout.setClickable(true);
            frameLayout.setFitsSystemWindows(true);
            LinearLayout col = UiKt.col(mainActivity);
            float f = 18;
            float f2 = 8;
            col.setPadding(UiKt.dp(mainActivity, f), UiKt.dp(mainActivity, f2), UiKt.dp(mainActivity, f), UiKt.dp(mainActivity, 28));
            LinearLayout linearLayout = new LinearLayout(mainActivity);
            linearLayout.setGravity(16);
            TextView label = UiKt.label(mainActivity, Fleet.T("talk.title", new Pair[0]), 20, UiKt.TEXT);
            label.setTypeface(Typeface.DEFAULT_BOLD);
            linearLayout.addView(label, new LinearLayout.LayoutParams(0, -2, 1.0f));
            TextView textView = new TextView(mainActivity);
            textView.setText(Fleet.T("talk.old_chip", new Pair[0]));
            textView.setTextSize(13.0f);
            textView.setTextColor(UiKt.TEXT);
            textView.setGravity(17);
            textView.setBackground(UiKt.box(mainActivity, UiKt.BTN, 14));
            float f3 = 12;
            textView.setPadding(UiKt.dp(mainActivity, f3), 0, UiKt.dp(mainActivity, f3), 0);
            textView.setContentDescription(Fleet.T("talk.mode_old", new Pair[0]));
            textView.setOnClickListener(new View.OnClickListener(this) { // from class: dev.tvremote.phone.media.Talk$$ExternalSyntheticLambda6
                public final /* synthetic */ Talk f$0;

                {
                    this.f$0 = this;
                }

                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    switch (i2) {
                        case 0:
                            Talk talk = this.f$0;
                            Fleet.setTalkMode(talk.a, "old");
                            talk.close();
                            talk.a.speak$android_release();
                            return;
                        default:
                            this.f$0.close();
                            return;
                    }
                }
            });
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, UiKt.dp(mainActivity, 40));
            layoutParams.rightMargin = UiKt.dp(mainActivity, f2);
            linearLayout.addView(textView, layoutParams);
            TextView textView2 = new TextView(mainActivity);
            UiKt.setMarked(textView2, "✕");
            textView2.setTextSize(20.0f);
            textView2.setTextColor(UiKt.TEXT);
            textView2.setGravity(17);
            textView2.setBackground(UiKt.box(mainActivity, UiKt.BTN, 14));
            textView2.setContentDescription(Fleet.T("common.close", new Pair[0]));
            textView2.setOnClickListener(new View.OnClickListener(this) { // from class: dev.tvremote.phone.media.Talk$$ExternalSyntheticLambda6
                public final /* synthetic */ Talk f$0;

                {
                    this.f$0 = this;
                }

                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    switch (i) {
                        case 0:
                            Talk talk = this.f$0;
                            Fleet.setTalkMode(talk.a, "old");
                            talk.close();
                            talk.a.speak$android_release();
                            return;
                        default:
                            this.f$0.close();
                            return;
                    }
                }
            });
            float f4 = 48;
            linearLayout.addView(textView2, new LinearLayout.LayoutParams(UiKt.dp(mainActivity, f4), UiKt.dp(mainActivity, f4)));
            col.addView(linearLayout, new LinearLayout.LayoutParams(-1, -2));
            LinearLayout col2 = UiKt.col(mainActivity);
            col2.setGravity(80);
            TextView textView3 = new TextView(mainActivity);
            textView3.setGravity(17);
            textView3.setMaxLines(4);
            this.live = textView3;
            col2.addView(textView3, UiKt.gap(mainActivity, 0));
            TextView label2 = UiKt.label(mainActivity, Fleet.T("talk.will_do", new Pair[0]), 12, UiKt.MUTED);
            label2.setGravity(17);
            label2.setVisibility(8);
            this.willDo = label2;
            col2.addView(label2, UiKt.gap(mainActivity, 18));
            LinearLayout col3 = UiKt.col(mainActivity);
            this.plans = col3;
            col2.addView(col3, UiKt.gap(mainActivity, 6));
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, 0, 1.0f);
            layoutParams2.bottomMargin = UiKt.dp(mainActivity, 24);
            col.addView(col2, layoutParams2);
            FrameLayout frameLayout2 = new FrameLayout(mainActivity);
            View view = new View(mainActivity);
            view.setBackground(UiKt.oval(mainActivity, UiKt.SEL));
            this.ring = view;
            float f5 = 150;
            frameLayout2.addView(view, new FrameLayout.LayoutParams(UiKt.dp(mainActivity, f5), UiKt.dp(mainActivity, f5), 17));
            this.btn = new FrameLayout(mainActivity);
            ImageView imageView = new ImageView(mainActivity);
            imageView.setImageResource(mainActivity.getResources().getIdentifier("ic_mic", "drawable", mainActivity.getPackageName()));
            FrameLayout frameLayout3 = this.btn;
            Intrinsics.checkNotNull(frameLayout3);
            frameLayout3.addView(imageView, new FrameLayout.LayoutParams(UiKt.dp(mainActivity, f4), UiKt.dp(mainActivity, f4), 17));
            FrameLayout frameLayout4 = this.btn;
            Intrinsics.checkNotNull(frameLayout4);
            frameLayout4.setContentDescription(Fleet.T("talk.hold", new Pair[0]));
            float f6 = 120;
            frameLayout2.addView(this.btn, new FrameLayout.LayoutParams(UiKt.dp(mainActivity, f6), UiKt.dp(mainActivity, f6), 17));
            FrameLayout frameLayout5 = this.btn;
            Intrinsics.checkNotNull(frameLayout5);
            frameLayout5.setOnTouchListener(new Talk$$ExternalSyntheticLambda8(0, this));
            col.addView(frameLayout2, new LinearLayout.LayoutParams(-1, UiKt.dp(mainActivity, 170)));
            TextView label3 = UiKt.label(mainActivity, Fleet.T("talk.hold", new Pair[0]), 14, UiKt.MUTED);
            label3.setGravity(17);
            this.state = label3;
            col.addView(label3, UiKt.gap(mainActivity, 6));
            frameLayout.addView(col, new FrameLayout.LayoutParams(-1, -1));
            this.overlay = frameLayout;
            ((ViewGroup) mainActivity.findViewById(R.id.content)).addView(frameLayout, new ViewGroup.LayoutParams(-1, -1));
            idle();
            if ((mainActivity.getApplicationInfo().flags & 2) == 0 || SpeechRecognizer.isRecognitionAvailable(mainActivity)) {
                warm();
            }
            if ((mainActivity.getApplicationInfo().flags & 2) == 0 || this.rx != null) {
                return;
            }
            this.rx = new Guard$install$r$1(1, this);
            IntentFilter intentFilter = new IntentFilter("dev.tvremote.phone.TALK");
            if (Build.VERSION.SDK_INT >= 33) {
                mainActivity.registerReceiver(this.rx, intentFilter, 2);
            } else {
                mainActivity.registerReceiver(this.rx, intentFilter);
            }
        }
    }

    public final void paintButton() {
        int i;
        ImageView imageView;
        View view;
        ViewPropertyAnimator animate;
        ViewPropertyAnimator scaleX;
        ViewPropertyAnimator scaleY;
        ViewPropertyAnimator duration;
        int i2;
        String T;
        int i3;
        FrameLayout frameLayout = this.btn;
        if (frameLayout != null) {
            if (this.cancelling) {
                i = -3790808;
            } else if (this.holding) {
                i = UiKt.ACCENT;
            } else {
                i = UiKt.SOFT;
            }
            frameLayout.setBackground(UiKt.oval(this.a, i));
            View childAt = frameLayout.getChildAt(0);
            if (childAt instanceof ImageView) {
                imageView = (ImageView) childAt;
            } else {
                imageView = null;
            }
            if (imageView != null) {
                if (!this.holding && !this.cancelling) {
                    i3 = UiKt.ACCENT_TEXT;
                } else {
                    i3 = -1;
                }
                imageView.setColorFilter(i3);
            }
            TextView textView = this.state;
            if (textView != null) {
                if (this.cancelling) {
                    T = Fleet.T("talk.release_cancel", new Pair[0]);
                } else if (this.holding) {
                    T = Fleet.T("talk.release", new Pair[0]);
                } else {
                    T = Fleet.T("talk.hold", new Pair[0]);
                }
                textView.setText(T);
            }
            TextView textView2 = this.state;
            if (textView2 != null) {
                if (this.cancelling) {
                    i2 = UiKt.RED;
                } else {
                    i2 = UiKt.MUTED;
                }
                textView2.setTextColor(i2);
            }
            if (!this.holding && (view = this.ring) != null && (animate = view.animate()) != null && (scaleX = animate.scaleX(1.0f)) != null && (scaleY = scaleX.scaleY(1.0f)) != null && (duration = scaleY.setDuration(120L)) != null) {
                duration.start();
            }
        }
    }

    public final void say(String str) {
        liveText(false, str);
        LinearLayout linearLayout = this.plans;
        if (linearLayout != null) {
            linearLayout.removeAllViews();
        }
        TextView textView = this.willDo;
        if (textView != null) {
            textView.setVisibility(8);
        }
        TextView textView2 = this.state;
        if (textView2 != null) {
            textView2.setText(Fleet.T("talk.hold", new Pair[0]));
        }
        paintButton();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r6v0, types: [java.util.Map, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r8v0, types: [java.util.List, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r9v0, types: [java.util.Map, java.lang.Object] */
    public final void send(String str) {
        boolean z;
        end();
        if (StringsKt.isBlank(str)) {
            say(Fleet.T("talk.heard_nothing", new Pair[0]));
            return;
        }
        liveText(true, "“" + StringsKt.trim(str).toString() + "”");
        Voice voice = Voice.INSTANCE;
        MainActivity mainActivity = this.a;
        Map map = mainActivity.appNames;
        ?? r6 = this.scenes;
        Tv tv = mainActivity.tv;
        if (tv != null && tv.ready()) {
            z = true;
        } else {
            z = false;
        }
        Voice.Plan preview = voice.preview(str, map, r6, z, this.a.voicePins, this.sayings);
        if (preview != null) {
            listPlans(MathKt.listOf(preview));
        }
        TextView textView = this.state;
        if (textView != null) {
            textView.setText(Fleet.T("talk.sent", new Pair("sentence", StringsKt.trim(str).toString())));
        }
        this.a.buzz$android_release();
        MathKt.voice(this.a, str);
    }

    public final void warm() {
        Executor mainExecutor;
        SpeechRecognizer speechRecognizer = this.rec;
        MainActivity mainActivity = this.a;
        if (speechRecognizer == null) {
            SpeechRecognizer createSpeechRecognizer = SpeechRecognizer.createSpeechRecognizer(mainActivity);
            createSpeechRecognizer.setRecognitionListener(this.listener);
            this.rec = createSpeechRecognizer;
        }
        if (Build.VERSION.SDK_INT >= 33) {
            try {
                SpeechRecognizer speechRecognizer2 = this.rec;
                if (speechRecognizer2 != null) {
                    Intent intent = intent();
                    mainExecutor = mainActivity.getMainExecutor();
                    speechRecognizer2.checkRecognitionSupport(intent, mainExecutor, new RecognitionSupportCallback() { // from class: dev.tvremote.phone.media.Talk$warm$2
                        @Override // android.speech.RecognitionSupportCallback
                        public final void onError(int i) {
                        }

                        @Override // android.speech.RecognitionSupportCallback
                        public final void onSupportResult(RecognitionSupport s) {
                            List installedOnDeviceLanguages;
                            String str;
                            Intrinsics.checkNotNullParameter(s, "s");
                            Talk talk = Talk.this;
                            installedOnDeviceLanguages = s.getInstalledOnDeviceLanguages();
                            Intrinsics.checkNotNullExpressionValue(installedOnDeviceLanguages, "getInstalledOnDeviceLanguages(...)");
                            Talk talk2 = Talk.this;
                            boolean z = false;
                            if (!installedOnDeviceLanguages.isEmpty()) {
                                Iterator it = installedOnDeviceLanguages.iterator();
                                while (true) {
                                    if (!it.hasNext()) {
                                        break;
                                    }
                                    String str2 = (String) it.next();
                                    Intrinsics.checkNotNull(str2);
                                    talk2.getClass();
                                    ConcurrentHashMap concurrentHashMap = Words.books;
                                    String str3 = Words.lang;
                                    if (Intrinsics.areEqual(str3, "vi")) {
                                        str = "vi-VN";
                                    } else if (Intrinsics.areEqual(str3, "en")) {
                                        str = "en-US";
                                    } else {
                                        str = Words.lang;
                                    }
                                    if (StringsKt__StringsJVMKt.startsWith(str2, false, StringsKt.substringBefore(str, '-', str))) {
                                        z = true;
                                        break;
                                    }
                                }
                            }
                            talk.offline = z;
                        }
                    });
                    return;
                }
                return;
            } catch (Exception unused) {
                return;
            }
        }
        this.offline = true;
    }
}
