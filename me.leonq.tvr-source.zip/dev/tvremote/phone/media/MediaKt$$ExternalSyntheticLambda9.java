package dev.tvremote.phone.media;

import dev.tvremote.core.remote.Lg$$ExternalSyntheticLambda2;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.core.scenes.Phrases$alt$$inlined$sortedByDescending$1;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda15;
import dev.tvremote.phone.manage.UpdaterKt$$ExternalSyntheticLambda10;
import dev.tvremote.phone.manage.UpdaterKt$$ExternalSyntheticLambda3;
import dev.tvremote.phone.picker.AdbHelpKt;
import dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda40;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.EmptyList;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

/* loaded from: classes.dex */
public final /* synthetic */ class MediaKt$$ExternalSyntheticLambda9 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Remote f$0;
    public final /* synthetic */ MainActivity f$1;

    public /* synthetic */ MediaKt$$ExternalSyntheticLambda9(Remote remote, MainActivity mainActivity, int i) {
        this.$r8$classId = i;
        this.f$0 = remote;
        this.f$1 = mainActivity;
    }

    /* JADX WARN: Removed duplicated region for block: B:71:0x00e5  */
    /* JADX WARN: Removed duplicated region for block: B:77:0x00e7  */
    /* JADX WARN: Type inference failed for: r9v1, types: [kotlin.jvm.internal.Ref$BooleanRef, java.lang.Object] */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void run() {
        Object obj;
        AtomicBoolean atomicBoolean;
        ?? obj2;
        boolean z;
        int i = 12;
        int i2 = 2;
        int i3 = 0;
        MainActivity mainActivity = this.f$1;
        Remote remote = this.f$0;
        int i4 = 1;
        switch (this.$r8$classId) {
            case 0:
                try {
                    obj = CollectionsKt.sortedWith(remote.apps(), new Phrases$alt$$inlined$sortedByDescending$1(8));
                } catch (Exception unused) {
                    obj = EmptyList.INSTANCE;
                }
                mainActivity.ui.post(new Lg$$ExternalSyntheticLambda2(mainActivity, remote, obj, i));
                return;
            case 1:
                mainActivity.ui.post(new UpdaterKt$$ExternalSyntheticLambda3(mainActivity, remote.screenOff(), i4));
                return;
            case 2:
                MainActivity mainActivity2 = this.f$1;
                Remote remote2 = this.f$0;
                try {
                    List<Function0> asList = ArraysKt.asList(new Function0[]{new AdbHelpKt$$ExternalSyntheticLambda40(remote2, i3), new AdbHelpKt$$ExternalSyntheticLambda40(remote2, i4), new AdbHelpKt$$ExternalSyntheticLambda40(remote2, i2)});
                    obj2 = new Object();
                    String pkg = remote2.getApp();
                    Intrinsics.checkNotNullParameter(mainActivity2, "<this>");
                    Intrinsics.checkNotNullParameter(pkg, "pkg");
                    obj2.element = StringsKt.contains(pkg, "settings", true);
                } catch (Exception unused2) {
                    atomicBoolean = mainActivity2.tvBusy;
                } catch (Throwable th) {
                    mainActivity2.tvBusy.set(false);
                    throw th;
                }
                for (Function0 function0 : asList) {
                    if (!obj2.element) {
                        for (int i5 = 0; i5 < 30 && !remote2.ready(); i5++) {
                            Thread.sleep(200L);
                        }
                        function0.invoke();
                        int i6 = 0;
                        while (true) {
                            if (i6 < 12) {
                                Thread.sleep(200L);
                                String pkg2 = remote2.getApp();
                                Intrinsics.checkNotNullParameter(pkg2, "pkg");
                                if (StringsKt.contains(pkg2, "settings", true)) {
                                    obj2.element = true;
                                } else {
                                    i6++;
                                }
                            }
                        }
                    } else {
                        if (remote2.getApp().length() != 0) {
                            z = true;
                        } else {
                            z = false;
                        }
                        mainActivity2.ui.post(new UpdaterKt$$ExternalSyntheticLambda10(mainActivity2, remote2, obj2, z, 2));
                        atomicBoolean = mainActivity2.tvBusy;
                        atomicBoolean.set(false);
                        return;
                    }
                }
                if (remote2.getApp().length() != 0) {
                }
                mainActivity2.ui.post(new UpdaterKt$$ExternalSyntheticLambda10(mainActivity2, remote2, obj2, z, 2));
                atomicBoolean = mainActivity2.tvBusy;
                atomicBoolean.set(false);
                return;
            case 3:
                if (mainActivity.basic == remote && !mainActivity.isFinishing()) {
                    AdbHelpKt.adbSteps(mainActivity);
                    return;
                }
                return;
            case 4:
                if (mainActivity.basic == remote && !mainActivity.isFinishing()) {
                    AdbHelpKt.adbSteps(mainActivity);
                    return;
                }
                return;
        }
        while (!remote.ready() && !mainActivity.isFinishing()) {
            if (remote.getAsking() && i3 == 0) {
                mainActivity.ui.post(new MainActivity$$ExternalSyntheticLambda15(mainActivity, 25));
                i3 = 1;
            }
            try {
                Thread.sleep(300L);
                if (Intrinsics.areEqual(remote.getKind(), "android")) {
                    return;
                }
            } catch (InterruptedException unused3) {
                return;
            }
        }
    }

    public /* synthetic */ MediaKt$$ExternalSyntheticLambda9(MainActivity mainActivity, Remote remote, int i) {
        this.$r8$classId = i;
        this.f$1 = mainActivity;
        this.f$0 = remote;
    }
}
