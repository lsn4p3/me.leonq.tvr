package dev.tvremote.phone.media;

import dev.tvremote.core.picture.Tv;
import dev.tvremote.phone.MainActivity;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.conscrypt.FileClientSessionCache;
import org.conscrypt.metrics.ConscryptStatsLog;

/* loaded from: classes.dex */
public final /* synthetic */ class TalkKt$$ExternalSyntheticLambda2 implements Function1 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Tv f$0;

    public /* synthetic */ TalkKt$$ExternalSyntheticLambda2(Tv tv, int i) {
        this.$r8$classId = i;
        this.f$0 = tv;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        Tv tv = this.f$0;
        String it = (String) obj;
        switch (this.$r8$classId) {
            case 0:
                Intrinsics.checkNotNullParameter(it, "it");
                return tv.shell(it);
            case 1:
                int i = MainActivity.$r8$clinit;
                Intrinsics.checkNotNullParameter(it, "it");
                return tv.shell(it);
            case 2:
                int i2 = MainActivity.$r8$clinit;
                Intrinsics.checkNotNullParameter(it, "it");
                return tv.shell(it);
            case 3:
                int i3 = MainActivity.$r8$clinit;
                Intrinsics.checkNotNullParameter(it, "it");
                return tv.shell(it);
            case 4:
                Intrinsics.checkNotNullParameter(it, "it");
                return tv.shell(it);
            case 5:
                Intrinsics.checkNotNullParameter(it, "c");
                return tv.shell(it);
            case 6:
                Intrinsics.checkNotNullParameter(it, "it");
                return tv.shell(it);
            case 7:
                Intrinsics.checkNotNullParameter(it, "it");
                return tv.shell(it);
            case 8:
                Intrinsics.checkNotNullParameter(it, "it");
                return tv.shell(it);
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                Intrinsics.checkNotNullParameter(it, "it");
                Intrinsics.checkNotNull(tv);
                return tv.shell(it);
            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                Intrinsics.checkNotNullParameter(it, "it");
                return tv.shell(it);
            case 11:
                Intrinsics.checkNotNullParameter(it, "it");
                return tv.shell(it);
            case FileClientSessionCache.MAX_SIZE /* 12 */:
                Intrinsics.checkNotNullParameter(it, "it");
                return tv.shell(it);
            case 13:
                Intrinsics.checkNotNullParameter(it, "it");
                return tv.shell(it);
            case 14:
                Intrinsics.checkNotNullParameter(it, "it");
                return tv.shell(it);
            case 15:
                Intrinsics.checkNotNullParameter(it, "it");
                return tv.shell(it);
            case 16:
                Intrinsics.checkNotNullParameter(it, "it");
                return tv.shell(it);
            case 17:
                Intrinsics.checkNotNullParameter(it, "it");
                return tv.shell(it);
            default:
                Intrinsics.checkNotNullParameter(it, "it");
                return tv.shell(it);
        }
    }
}
