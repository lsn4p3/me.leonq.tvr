package dev.tvremote.phone.media;

import android.content.Context;
import android.widget.FrameLayout;
import android.widget.TextView;
import dev.tvremote.core.Fleet;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.picture.VideoFrame;
import dev.tvremote.phone.ui.UiKt;
import java.io.InputStream;
import kotlin.Pair;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;

/* loaded from: classes.dex */
public final /* synthetic */ class PlayingBar$$ExternalSyntheticLambda7 implements Function0 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ PlayingBar f$0;

    public /* synthetic */ PlayingBar$$ExternalSyntheticLambda7(PlayingBar playingBar, int i) {
        this.$r8$classId = i;
        this.f$0 = playingBar;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        switch (this.$r8$classId) {
            case 0:
                PlayingBar playingBar = this.f$0;
                TextView label = UiKt.label(playingBar.a, Fleet.T("now_playing.the_tv_does_not", new Pair[0]), 13, UiKt.TEXT);
                label.setGravity(17);
                int i = UiKt.PILL;
                MainActivity mainActivity = playingBar.a;
                label.setBackground(UiKt.box(mainActivity, i, 10));
                label.setPadding(UiKt.dp((Context) mainActivity, 12), UiKt.dp((Context) mainActivity, 8), UiKt.dp((Context) mainActivity, 12), UiKt.dp((Context) mainActivity, 8));
                label.setVisibility(8);
                VideoFrame frame$android_release = mainActivity.getFrame$android_release();
                FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-2, -2, 17);
                layoutParams.leftMargin = UiKt.dp((Context) mainActivity, 24);
                layoutParams.rightMargin = UiKt.dp((Context) mainActivity, 24);
                frame$android_release.addView(label, layoutParams);
                return label;
            default:
                InputStream open = this.f$0.a.getAssets().open("tvr-helper.jar");
                try {
                    Intrinsics.checkNotNull(open);
                    byte[] readBytes = MathKt.readBytes(open);
                    MathKt.closeFinally(open, null);
                    return readBytes;
                } finally {
                }
        }
    }
}
