package dev.tvremote.phone;

import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;
import dev.tvremote.phone.ui.UiKt;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public abstract class TvTile extends TileService {
    public abstract Intent job(Intent intent);

    @Override // android.service.quicksettings.TileService
    public final void onClick() {
        Intent addFlags = new Intent(this, (Class<?>) SceneActivity.class).addFlags(268435456);
        Intrinsics.checkNotNullExpressionValue(addFlags, "addFlags(...)");
        Intent job = job(addFlags);
        if (job == null) {
            job = new Intent(this, (Class<?>) MainActivity.class).addFlags(268435456);
            Intrinsics.checkNotNullExpressionValue(job, "addFlags(...)");
        }
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(PendingIntent.getActivity(this, 0, job, 201326592));
        } else {
            startActivityAndCollapse(job);
        }
    }

    @Override // android.service.quicksettings.TileService
    public final void onStartListening() {
        Tile qsTile;
        UiKt.loadLang(this);
        qsTile = getQsTile();
        if (qsTile == null) {
            return;
        }
        paint(qsTile);
        qsTile.updateTile();
    }

    public abstract void paint(Tile tile);
}
