package dev.tvremote.phone.ui;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.widget.Button;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.StringsKt__StringsJVMKt;

/* loaded from: classes.dex */
public final class IconButton extends Button {
    public final Paint arc;
    public Drawable art;
    public boolean busy;
    public String caption;
    public boolean chosen;
    public final Paint ink;
    public boolean lit;
    public float size;
    public int tint;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public IconButton(Context c) {
        super(c);
        Intrinsics.checkNotNullParameter(c, "c");
        this.size = 24.0f;
        Paint paint = new Paint(1);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setColor(UiKt.DIM);
        this.ink = paint;
        this.tint = UiKt.DIM;
        Paint paint2 = new Paint(1);
        paint2.setStyle(Paint.Style.STROKE);
        paint2.setStrokeCap(Paint.Cap.ROUND);
        this.arc = paint2;
    }

    public final boolean getBusy() {
        return this.busy;
    }

    public final String getCaption() {
        return this.caption;
    }

    public final boolean getChosen() {
        return this.chosen;
    }

    public final boolean getLit() {
        return this.lit;
    }

    public final float getSize() {
        return this.size;
    }

    @Override // android.widget.TextView, android.view.View
    public final void onDraw(Canvas c) {
        Intrinsics.checkNotNullParameter(c, "c");
        super.onDraw(c);
        Drawable drawable = this.art;
        if (drawable == null) {
            return;
        }
        int roundToInt = MathKt.roundToInt((this.size * getResources().getDisplayMetrics().density) / 2);
        int width = getWidth() / 2;
        int height = getHeight() / 2;
        String str = this.caption;
        Paint paint = this.ink;
        if (str != null) {
            float f = getResources().getDisplayMetrics().density;
            height -= MathKt.roundToInt(7 * f);
            paint.setTextSize(getResources().getDisplayMetrics().scaledDensity * 10.5f);
            c.drawText(str, width, (15 * f) + height + roundToInt, paint);
        }
        if (this.busy) {
            float f2 = roundToInt * 0.75f;
            Paint paint2 = this.arc;
            paint2.setStrokeWidth(getResources().getDisplayMetrics().density * 2.2f);
            paint2.setColor(paint.getColor());
            float f3 = width;
            float f4 = height;
            c.drawArc(f3 - f2, f4 - f2, f3 + f2, f4 + f2, ((float) (SystemClock.uptimeMillis() % 1000)) * 0.36f, 270.0f, false, paint2);
            postInvalidateOnAnimation();
            return;
        }
        drawable.setBounds(width - roundToInt, height - roundToInt, width + roundToInt, height + roundToInt);
        drawable.draw(c);
    }

    public final void paint() {
        int i;
        Paint paint = this.ink;
        int i2 = -1;
        if (this.lit) {
            i = -1;
        } else if (this.chosen) {
            i = UiKt.ACCENT_TEXT;
        } else {
            i = UiKt.DIM;
        }
        paint.setColor(i);
        Drawable drawable = this.art;
        if (drawable != null) {
            if (!this.lit) {
                if (this.chosen) {
                    i2 = UiKt.ACCENT_TEXT;
                } else {
                    i2 = this.tint;
                }
            }
            drawable.setTint(i2);
        }
        invalidate();
    }

    public final void setBusy(boolean z) {
        this.busy = z;
        invalidate();
    }

    public final void setCaption(String str) {
        this.caption = str;
    }

    public final void setChosen(boolean z) {
        this.chosen = z;
        paint();
    }

    public final void setIcon(String symbol, int i) {
        Intrinsics.checkNotNullParameter(symbol, "symbol");
        Drawable drawable = null;
        if (!StringsKt__StringsJVMKt.startsWith(symbol, false, "@")) {
            this.art = null;
            setText(symbol);
            return;
        }
        Resources resources = getResources();
        String substring = symbol.substring(1);
        Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
        int identifier = resources.getIdentifier("ic_".concat(substring), "drawable", getContext().getPackageName());
        if (identifier != 0) {
            drawable = getResources().getDrawable(identifier, null).mutate();
        }
        this.art = drawable;
        this.tint = i;
        setText("");
        paint();
    }

    public final void setLit(boolean z) {
        this.lit = z;
        paint();
    }

    public final void setSize(float f) {
        this.size = f;
    }
}
