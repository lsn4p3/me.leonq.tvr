package dev.tvremote.phone.ui;

import android.app.Activity;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.ontv.Checkout;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda10;
import dev.tvremote.phone.ir.IrLearn;
import dev.tvremote.phone.ir.IrRemoteKt;
import dev.tvremote.phone.picker.ManyTvsKt$$ExternalSyntheticLambda6;
import dev.tvremote.phone.ui.Popup;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.math.MathKt;

/* loaded from: classes.dex */
public final /* synthetic */ class UiKt$$ExternalSyntheticLambda8 implements Function0 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Activity f$0;
    public final /* synthetic */ Object f$1;
    public final /* synthetic */ int f$2;
    public final /* synthetic */ Object f$3;

    public /* synthetic */ UiKt$$ExternalSyntheticLambda8(Activity activity, String str, int i, Object obj, int i2) {
        this.$r8$classId = i2;
        this.f$0 = activity;
        this.f$1 = str;
        this.f$2 = i;
        this.f$3 = obj;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        String str;
        String str2;
        int i;
        Object obj = this.f$1;
        Activity activity = this.f$0;
        int i2 = this.f$2;
        Object obj2 = this.f$3;
        int i3 = 0;
        switch (this.$r8$classId) {
            case 0:
                UiKt.menu(activity, (String) obj, i2, (List) obj2);
                return Unit.INSTANCE;
            case 1:
                String str3 = (String) obj;
                switch (str3.hashCode()) {
                    case -1757544025:
                        if (str3.equals("VOL_UP")) {
                            str = Fleet.T("ir.key_vol_up", new Pair[0]);
                            break;
                        }
                        str = str3;
                        break;
                    case -1078165330:
                        if (str3.equals("VOL_DOWN")) {
                            str = Fleet.T("ir.key_vol_down", new Pair[0]);
                            break;
                        }
                        str = str3;
                        break;
                    case 2524:
                        if (str3.equals("OK")) {
                            str = Fleet.T("ir.key_ok", new Pair[0]);
                            break;
                        }
                        str = str3;
                        break;
                    case 2715:
                        if (str3.equals("UP")) {
                            str = Fleet.T("ir.key_up", new Pair[0]);
                            break;
                        }
                        str = str3;
                        break;
                    case 2030823:
                        if (str3.equals("BACK")) {
                            str = Fleet.T("ir.key_back", new Pair[0]);
                            break;
                        }
                        str = str3;
                        break;
                    case 2104482:
                        if (str3.equals("DOWN")) {
                            str = Fleet.T("ir.key_down", new Pair[0]);
                            break;
                        }
                        str = str3;
                        break;
                    case 2223327:
                        if (str3.equals("HOME")) {
                            str = Fleet.T("ir.key_home", new Pair[0]);
                            break;
                        }
                        str = str3;
                        break;
                    case 2332679:
                        if (str3.equals("LEFT")) {
                            str = Fleet.T("ir.key_left", new Pair[0]);
                            break;
                        }
                        str = str3;
                        break;
                    case 2362719:
                        if (str3.equals("MENU")) {
                            str = Fleet.T("ir.key_menu", new Pair[0]);
                            break;
                        }
                        str = str3;
                        break;
                    case 2378265:
                        if (str3.equals("MUTE")) {
                            str = Fleet.T("ir.key_mute", new Pair[0]);
                            break;
                        }
                        str = str3;
                        break;
                    case 76320997:
                        if (str3.equals("POWER")) {
                            str = Fleet.T("ir.key_power", new Pair[0]);
                            break;
                        }
                        str = str3;
                        break;
                    case 77974012:
                        if (str3.equals("RIGHT")) {
                            str = Fleet.T("ir.key_right", new Pair[0]);
                            break;
                        }
                        str = str3;
                        break;
                    default:
                        str = str3;
                        break;
                }
                String T = Fleet.T("ir.learn_press", new Pair("key", str));
                String T2 = Fleet.T("ir.learn_step", new Pair("n", Integer.valueOf(i2 + 1)), new Pair("total", Integer.valueOf(IrLearn.KEYS.size())));
                if (str3.equals("POWER")) {
                    str2 = ApkSigner$$ExternalSyntheticOutline0.m(" · ", Fleet.T("ir.learn_power", new Pair[0]));
                } else {
                    str2 = "";
                }
                IrRemoteKt.irLearn$default((MainActivity) activity, T, Census$$ExternalSyntheticOutline0.m(T2, str2), ((LinkedHashMap) obj2).size(), 8);
                return Unit.INSTANCE;
            case 2:
                List list = (List) obj;
                Checkout.Config config = new Checkout.Config(list, i2);
                MainActivity mainActivity = (MainActivity) activity;
                Popup.Builder builder = new Popup.Builder(mainActivity);
                builder.title = Fleet.T("fleet.menu_checkout", new Pair[0]);
                List list2 = (List) obj2;
                Pair pair = new Pair("n", Integer.valueOf(list2.size()));
                if (list != null) {
                    i = list.size();
                } else {
                    i = 0;
                }
                builder.message = Census$$ExternalSyntheticOutline0.m(Fleet.T("fleet.co_ask", pair, new Pair("apps", Integer.valueOf(i))), "\n\n", CollectionsKt.joinToString$default(list2, "\n", null, null, new MainActivity$$ExternalSyntheticLambda10(mainActivity, 7), 30));
                builder.setPositiveButton(Fleet.T("fleet.co_go", new Pair("n", Integer.valueOf(list2.size()))), new ManyTvsKt$$ExternalSyntheticLambda6(mainActivity, config, list2, i3));
                builder.setNegativeButton(Fleet.T("common.cancel", new Pair[0]), null);
                builder.show();
                return Unit.INSTANCE;
            default:
                MainActivity mainActivity2 = (MainActivity) activity;
                MathKt.putOff(i2, mainActivity2, (ArrayList) obj2);
                MathKt.showSetup(mainActivity2, (String) obj);
                return Unit.INSTANCE;
        }
    }

    public /* synthetic */ UiKt$$ExternalSyntheticLambda8(MainActivity mainActivity, ArrayList arrayList, int i, String str) {
        this.$r8$classId = 3;
        this.f$0 = mainActivity;
        this.f$3 = arrayList;
        this.f$2 = i;
        this.f$1 = str;
    }

    public /* synthetic */ UiKt$$ExternalSyntheticLambda8(MainActivity mainActivity, List list, List list2, int i) {
        this.$r8$classId = 2;
        this.f$0 = mainActivity;
        this.f$3 = list;
        this.f$1 = list2;
        this.f$2 = i;
    }
}
