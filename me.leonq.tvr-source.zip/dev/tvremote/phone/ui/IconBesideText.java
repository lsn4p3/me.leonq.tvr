package dev.tvremote.phone.ui;

import android.graphics.drawable.Drawable;
import android.text.Layout;
import android.view.View;
import android.widget.TextView;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class IconBesideText implements View.OnLayoutChangeListener {
    public static final IconBesideText INSTANCE = new Object();

    /* JADX WARN: Code restructure failed: missing block: B:12:0x004e, code lost:
    
        if (r2 < 0) goto L15;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static void place(TextView tv) {
        Layout layout;
        int i;
        Intrinsics.checkNotNullParameter(tv, "tv");
        Drawable drawable = tv.getCompoundDrawablesRelative()[0];
        if (drawable != null && (layout = tv.getLayout()) != null) {
            int height = drawable.getBounds().height();
            if ((tv.getGravity() & 7) == 1) {
                int lineCount = layout.getLineCount();
                float f = 0.0f;
                for (int i2 = 0; i2 < lineCount; i2++) {
                    f = Math.max(f, layout.getLineWidth(i2));
                }
                i = (int) ((((tv.getWidth() - tv.getCompoundPaddingLeft()) - tv.getCompoundPaddingRight()) - f) / 2);
            }
            i = 0;
            if (drawable.getBounds().left != i) {
                drawable.setBounds(i, 0, i + height, height);
                tv.invalidate();
            }
        }
    }

    @Override // android.view.View.OnLayoutChangeListener
    public final void onLayoutChange(View v, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
        Intrinsics.checkNotNullParameter(v, "v");
        place((TextView) v);
    }
}
