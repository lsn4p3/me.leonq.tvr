package dev.tvremote.phone.ui;

import android.R;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Words;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda9;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.tvui.Marks;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$ObjectRef;
import kotlin.math.MathKt;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;

/* loaded from: classes.dex */
public abstract class UiKt {
    public static boolean LIGHT;
    public static Triple menuFrom;
    public static int BG = -15657960;
    public static final DlApp SETUP_APP = new DlApp("setup", "dev.tvremote.setup", "setup.install_setup_title", "adb_help.the_app_has_entered", "adb_help.open_tv_setup");
    public static final DlApp HOME_APP = new DlApp("home", "dev.tvremote.home", "setup.install_home_title", "setup.look_body_home", "adb_help.open_tv_home");
    public static int CARD = -14933978;
    public static int BTN = -14012360;
    public static int ACCENT = -13408536;
    public static int ACCENT_TEXT = -8674561;
    public static int HELD = -2056144;
    public static int TEXT = -1512723;
    public static int MUTED = -6643546;
    public static int RED = -30080;
    public static int GREEN = -13730481;
    public static int ERR_TEXT = -19288;
    public static int ERR_BG = -12967904;
    public static int DIM = -6774093;
    public static int OK_TEXT = -11870592;
    public static int RIPPLE = 1090519039;
    public static int PILL = -652336856;
    public static int SOFT = 861637887;
    public static int SEL = -14602675;
    public static boolean VI = "vi".equals(Locale.getDefault().getLanguage());

    public static final void applyPalette(Context context) {
        Palette palette;
        boolean z = false;
        String str = "";
        String string = context.getSharedPreferences("tvs", 0).getString("theme", "");
        if (string != null) {
            str = string;
        }
        if (str.equals("light") || (!str.equals("dark") && (context.getResources().getConfiguration().uiMode & 48) != 32)) {
            z = true;
        }
        LIGHT = z;
        if (z) {
            palette = Palette.light;
        } else {
            palette = Palette.dark;
        }
        BG = palette.bg;
        CARD = palette.card;
        BTN = palette.btn;
        ACCENT = palette.accent;
        ACCENT_TEXT = palette.accentText;
        HELD = palette.held;
        TEXT = palette.text;
        MUTED = palette.muted;
        RED = palette.red;
        GREEN = palette.green;
        ERR_TEXT = palette.errText;
        ERR_BG = palette.errBg;
        DIM = palette.dim;
        OK_TEXT = palette.okText;
        RIPPLE = palette.ripple;
        PILL = palette.pill;
        SOFT = palette.soft;
        SEL = palette.sel;
    }

    public static final GradientDrawable box(Context context, int i, int i2) {
        Intrinsics.checkNotNullParameter(context, "<this>");
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(i);
        gradientDrawable.setCornerRadius(dp(context, i2));
        return gradientDrawable;
    }

    public static final Button button(Context context, String s, int i) {
        int i2;
        Intrinsics.checkNotNullParameter(context, "<this>");
        Intrinsics.checkNotNullParameter(s, "s");
        Button button = new Button(context);
        button.setAllCaps(false);
        if (onFill(i)) {
            i2 = -1;
        } else {
            i2 = TEXT;
        }
        button.setTextColor(i2);
        button.setTextSize(15.0f);
        setLabel(button, s);
        button.setBackground(box(context, i, 14));
        button.setStateListAnimator(null);
        float f = 14;
        button.setPadding(dp(context, f), 0, dp(context, f), 0);
        button.setMinHeight(0);
        button.setMinimumHeight(0);
        return button;
    }

    public static final LinearLayout.LayoutParams cell(int i, Context context, boolean z) {
        Intrinsics.checkNotNullParameter(context, "<this>");
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, dp(context, i), 1.0f);
        if (z) {
            layoutParams.leftMargin = dp(context, 6);
        }
        return layoutParams;
    }

    public static final LinearLayout chips(MainActivity mainActivity, List list, String now, Function1 function1) {
        boolean z;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Intrinsics.checkNotNullParameter(now, "now");
        LinearLayout linearLayout = new LinearLayout(mainActivity);
        int i = 0;
        for (Object obj : list) {
            int i2 = i + 1;
            if (i >= 0) {
                Pair pair = (Pair) obj;
                String str = (String) pair.first;
                String str2 = (String) pair.second;
                Button button = button(mainActivity, str2, BTN);
                setOn$default(button, Intrinsics.areEqual(str, now), 0, 6);
                button.setTextSize(13.0f);
                boolean z2 = true;
                button.setSingleLine(true);
                button.setPadding(0, button.getPaddingTop(), 0, button.getPaddingBottom());
                button.setOnClickListener(new Guard$$ExternalSyntheticLambda9(9, function1, str));
                if (!list.isEmpty()) {
                    Iterator it = list.iterator();
                    while (true) {
                        if (!it.hasNext()) {
                            break;
                        }
                        if (((String) ((Pair) it.next()).second).length() <= 2) {
                            if (str2.length() > 2) {
                                z = true;
                            }
                        }
                    }
                }
                z = false;
                if (i <= 0) {
                    z2 = false;
                }
                LinearLayout.LayoutParams cell = cell(40, mainActivity, z2);
                if (z) {
                    cell.weight = 1.6f;
                }
                linearLayout.addView(button, cell);
                i = i2;
            } else {
                CollectionsKt__CollectionsKt.throwIndexOverflow();
                throw null;
            }
        }
        return linearLayout;
    }

    public static final LinearLayout col(Context context) {
        Intrinsics.checkNotNullParameter(context, "<this>");
        LinearLayout linearLayout = new LinearLayout(context);
        linearLayout.setOrientation(1);
        return linearLayout;
    }

    public static final int dp(Context context, float f) {
        Intrinsics.checkNotNullParameter(context, "<this>");
        return MathKt.roundToInt(f * context.getResources().getDisplayMetrics().density);
    }

    public static final LinearLayout.LayoutParams gap(Context context, int i) {
        Intrinsics.checkNotNullParameter(context, "<this>");
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.topMargin = dp(context, i);
        return layoutParams;
    }

    public static final int getBTN() {
        return BTN;
    }

    public static final TextView head(Context context, String s) {
        Intrinsics.checkNotNullParameter(context, "<this>");
        Intrinsics.checkNotNullParameter(s, "s");
        TextView label = label(context, s, 12, MUTED);
        label.setTypeface(Typeface.DEFAULT_BOLD);
        label.setLetterSpacing(0.08f);
        return label;
    }

    public static final void hideKeyboard(Activity activity) {
        View currentFocus = activity.getCurrentFocus();
        if (currentFocus != null) {
            Object systemService = activity.getSystemService("input_method");
            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
            ((InputMethodManager) systemService).hideSoftInputFromWindow(currentFocus.getWindowToken(), 0);
        }
    }

    public static final IconButton icon(Context context, String symbol, String says, int i) {
        int i2;
        int i3;
        Intrinsics.checkNotNullParameter(context, "<this>");
        Intrinsics.checkNotNullParameter(symbol, "symbol");
        Intrinsics.checkNotNullParameter(says, "says");
        IconButton iconButton = new IconButton(context);
        if (onFill(i)) {
            i2 = -1;
        } else {
            i2 = TEXT;
        }
        iconButton.setLit(onFill(i));
        if (symbol.equals("@power")) {
            i3 = RED;
        } else {
            i3 = i2;
        }
        iconButton.setIcon(symbol, i3);
        iconButton.setAllCaps(false);
        iconButton.setTextColor(i2);
        iconButton.setTextSize(20.0f);
        iconButton.setContentDescription(says);
        iconButton.setBackground(box(context, i, 16));
        iconButton.setStateListAnimator(null);
        iconButton.setPadding(0, 0, 0, 0);
        iconButton.setMinHeight(0);
        iconButton.setMinimumHeight(0);
        iconButton.setMinWidth(0);
        iconButton.setMinimumWidth(0);
        return iconButton;
    }

    public static final FrameLayout inDialog(Context context, View view) {
        Intrinsics.checkNotNullParameter(context, "<this>");
        inDialog$lift(context, view);
        if (!(view instanceof ViewGroup) && !(view instanceof EditText)) {
            view.setBackground(box(context, BTN, 12));
        }
        FrameLayout frameLayout = new FrameLayout(context);
        float f = 24;
        frameLayout.setPadding(dp(context, f), dp(context, 12), dp(context, f), dp(context, 4));
        frameLayout.addView(view, new FrameLayout.LayoutParams(-1, -2));
        return frameLayout;
    }

    public static final void inDialog$lift(Context context, View view) {
        if (view instanceof EditText) {
            StateListDrawable stateListDrawable = new StateListDrawable();
            int[] iArr = {R.attr.state_focused};
            GradientDrawable box = box(context, BTN, 12);
            box.setStroke(dp(context, 1.5f), ACCENT);
            stateListDrawable.addState(iArr, box);
            GradientDrawable box2 = box(context, BTN, 12);
            box2.setStroke(dp(context, 1), (MUTED & 16777215) | 1426063360);
            stateListDrawable.addState(new int[0], box2);
            ((EditText) view).setBackground(stateListDrawable);
            return;
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int childCount = viewGroup.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = viewGroup.getChildAt(i);
                Intrinsics.checkNotNullExpressionValue(childAt, "getChildAt(...)");
                inDialog$lift(context, childAt);
            }
        }
    }

    public static final EditText input(Context context, String hint) {
        Intrinsics.checkNotNullParameter(context, "<this>");
        Intrinsics.checkNotNullParameter(hint, "hint");
        EditText editText = new EditText(context);
        editText.setHint(hint);
        editText.setHintTextColor(MUTED);
        editText.setTextColor(TEXT);
        editText.setTextSize(15.0f);
        editText.setSingleLine(true);
        editText.setBackground(box(context, CARD, 12));
        float f = 14;
        float f2 = 12;
        editText.setPadding(dp(context, f), dp(context, f2), dp(context, f), dp(context, f2));
        editText.setMinHeight(dp(context, 48));
        return editText;
    }

    public static final TextView label(Context context, String s, int i, int i2) {
        Intrinsics.checkNotNullParameter(context, "<this>");
        Intrinsics.checkNotNullParameter(s, "s");
        TextView textView = new TextView(context);
        textView.setText(s);
        textView.setTextSize(i);
        textView.setTextColor(i2);
        for (int i3 = 0; i3 < s.length(); i3++) {
            if (StringsKt.indexOf$default(Marks.SET, s.charAt(i3), 6) >= 0) {
                setMarked(textView, s);
                return textView;
            }
        }
        return textView;
    }

    public static final void loadLang(Context context) {
        String str;
        String str2 = "";
        String string = context.getSharedPreferences("tvs", 0).getString("lang", "");
        if (string != null) {
            str2 = string;
        }
        if (str2.length() == 0) {
            str = Locale.getDefault().getLanguage();
        } else {
            str = str2;
        }
        VI = "vi".equals(str);
        ConcurrentHashMap concurrentHashMap = Words.books;
        if (str2.length() == 0) {
            str2 = Locale.getDefault().getLanguage();
        }
        Words.lang = Words.pick(str2);
        applyPalette(context);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:12:0x006d  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x00d3  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x0107  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0124  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x013e  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x0173  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x018c  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x01ab  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x01ad  */
    /* JADX WARN: Removed duplicated region for block: B:64:0x0177  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x0139  */
    /* JADX WARN: Removed duplicated region for block: B:66:0x010c  */
    /* JADX WARN: Removed duplicated region for block: B:79:0x021e  */
    /* JADX WARN: Removed duplicated region for block: B:82:0x0237  */
    /* JADX WARN: Removed duplicated region for block: B:84:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void menu(final Activity activity, String str, int i, final List list) {
        final Function0 function0;
        Iterator it;
        String str2;
        String str3;
        Integer num;
        String str4;
        int i2;
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        final String title = str;
        final int i8 = i;
        Intrinsics.checkNotNullParameter(activity, "<this>");
        Intrinsics.checkNotNullParameter(title, "title");
        Triple triple = menuFrom;
        if (triple != null) {
            if (Intrinsics.areEqual(triple.first, title) || SystemClock.uptimeMillis() - ((Number) triple.second).longValue() >= 8000) {
                triple = null;
            }
            if (triple != null) {
                function0 = (Function0) triple.third;
                menuFrom = null;
                LinearLayout col = col(activity);
                float f = 16;
                float f2 = 8;
                col.setPadding(dp(activity, f), dp(activity, f2), dp(activity, f), dp(activity, 4));
                Object obj = new Object();
                it = list.iterator();
                boolean z = false;
                int i9 = 0;
                Ref$ObjectRef ref$ObjectRef = obj;
                while (it.hasNext()) {
                    Object next = it.next();
                    int i10 = i9 + 1;
                    if (i9 >= 0) {
                        Triple triple2 = (Triple) next;
                        String str5 = (String) triple2.first;
                        String str6 = (String) triple2.second;
                        final Function0 function02 = (Function0) triple2.third;
                        if (StringsKt__StringsJVMKt.startsWith(str5, z, "@")) {
                            str2 = StringsKt.substringBefore(str5, "|", str5).substring(1);
                            Intrinsics.checkNotNullExpressionValue(str2, "substring(...)");
                        } else {
                            str2 = null;
                        }
                        if (str2 != null) {
                            str3 = StringsKt.substringBefore(str2, ':', str2);
                        } else {
                            str3 = null;
                        }
                        Ref$ObjectRef ref$ObjectRef2 = ref$ObjectRef;
                        if (str2 != null) {
                            String substringAfter = StringsKt.substringAfter(str2, ':', "");
                            if (!StringsKt__StringsJVMKt.startsWith(substringAfter, false, "#")) {
                                substringAfter = null;
                            }
                            if (substringAfter != null) {
                                try {
                                    num = Integer.valueOf(Color.parseColor(substringAfter));
                                } catch (Exception unused) {
                                }
                                str4 = str3;
                                if (str4 != null) {
                                    str5 = StringsKt.substringAfter(str5, "|", str5);
                                }
                                LinearLayout linearLayout = new LinearLayout(activity);
                                linearLayout.setGravity(16);
                                Integer num2 = num;
                                float f3 = 14;
                                float f4 = 12;
                                Iterator it2 = it;
                                float f5 = 10;
                                linearLayout.setPadding(dp(activity, f3), dp(activity, f4), dp(activity, f5), dp(activity, f4));
                                if (i9 != i8) {
                                    i2 = ACCENT;
                                } else {
                                    i2 = BTN;
                                }
                                linearLayout.setBackground(new RippleDrawable(ColorStateList.valueOf(RIPPLE), box(activity, i2, 14), null));
                                if (str4 == null) {
                                    i3 = activity.getResources().getIdentifier("ic_".concat(str4), "drawable", activity.getPackageName());
                                } else {
                                    i3 = 0;
                                }
                                if (i3 != 0) {
                                    ImageView imageView = new ImageView(activity);
                                    imageView.setImageResource(i3);
                                    if (num2 != null) {
                                        i7 = num2.intValue();
                                    } else if (i9 == i8) {
                                        i7 = -1;
                                    } else {
                                        i7 = ACCENT_TEXT;
                                    }
                                    imageView.setColorFilter(i7);
                                    float f6 = 24;
                                    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(dp(activity, f6), dp(activity, f6));
                                    layoutParams.rightMargin = dp(activity, f3);
                                    linearLayout.addView(imageView, layoutParams);
                                }
                                LinearLayout col2 = col(activity);
                                if (i9 != i8) {
                                    i4 = -1;
                                } else {
                                    i4 = TEXT;
                                }
                                TextView label = label(activity, str5, 16, i4);
                                label.setTypeface(Typeface.DEFAULT_BOLD);
                                col2.addView(label);
                                if (str6.length() > 0) {
                                    if (i9 == i8) {
                                        i6 = -1840129;
                                    } else {
                                        i6 = MUTED;
                                    }
                                    col2.addView(label(activity, str6, 13, i6));
                                }
                                linearLayout.addView(col2, new LinearLayout.LayoutParams(0, -2, 1.0f));
                                if (i9 != i8) {
                                    i5 = -1;
                                } else {
                                    i5 = MUTED;
                                }
                                View label2 = label(activity, "›", 24, i5);
                                LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
                                layoutParams2.leftMargin = dp(activity, f5);
                                linearLayout.addView(label2, layoutParams2);
                                linearLayout.setClickable(true);
                                linearLayout.setFocusable(true);
                                linearLayout.setContentDescription(str5);
                                title = str;
                                final Ref$ObjectRef ref$ObjectRef3 = ref$ObjectRef2;
                                linearLayout.setOnClickListener(new View.OnClickListener() { // from class: dev.tvremote.phone.ui.UiKt$$ExternalSyntheticLambda3
                                    @Override // android.view.View.OnClickListener
                                    public final void onClick(View view) {
                                        Popup popup = (Popup) Ref$ObjectRef.this.element;
                                        if (popup != null) {
                                            popup.dismiss();
                                        }
                                        Long valueOf = Long.valueOf(SystemClock.uptimeMillis());
                                        List list2 = list;
                                        Activity activity2 = activity;
                                        String str7 = title;
                                        UiKt.menuFrom = new Triple(str7, valueOf, new UiKt$$ExternalSyntheticLambda8(activity2, str7, i8, list2, 0));
                                        function02.invoke();
                                    }
                                });
                                LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
                                layoutParams3.topMargin = dp(activity, f2);
                                col.addView(linearLayout, layoutParams3);
                                i8 = i;
                                it = it2;
                                i9 = i10;
                                z = false;
                                ref$ObjectRef = ref$ObjectRef3;
                            }
                        }
                        num = null;
                        str4 = str3;
                        if (str4 != null) {
                        }
                        LinearLayout linearLayout2 = new LinearLayout(activity);
                        linearLayout2.setGravity(16);
                        Integer num22 = num;
                        float f32 = 14;
                        float f42 = 12;
                        Iterator it22 = it;
                        float f52 = 10;
                        linearLayout2.setPadding(dp(activity, f32), dp(activity, f42), dp(activity, f52), dp(activity, f42));
                        if (i9 != i8) {
                        }
                        linearLayout2.setBackground(new RippleDrawable(ColorStateList.valueOf(RIPPLE), box(activity, i2, 14), null));
                        if (str4 == null) {
                        }
                        if (i3 != 0) {
                        }
                        LinearLayout col22 = col(activity);
                        if (i9 != i8) {
                        }
                        TextView label3 = label(activity, str5, 16, i4);
                        label3.setTypeface(Typeface.DEFAULT_BOLD);
                        col22.addView(label3);
                        if (str6.length() > 0) {
                        }
                        linearLayout2.addView(col22, new LinearLayout.LayoutParams(0, -2, 1.0f));
                        if (i9 != i8) {
                        }
                        View label22 = label(activity, "›", 24, i5);
                        LinearLayout.LayoutParams layoutParams22 = new LinearLayout.LayoutParams(-2, -2);
                        layoutParams22.leftMargin = dp(activity, f52);
                        linearLayout2.addView(label22, layoutParams22);
                        linearLayout2.setClickable(true);
                        linearLayout2.setFocusable(true);
                        linearLayout2.setContentDescription(str5);
                        title = str;
                        final Ref$ObjectRef ref$ObjectRef32 = ref$ObjectRef2;
                        linearLayout2.setOnClickListener(new View.OnClickListener() { // from class: dev.tvremote.phone.ui.UiKt$$ExternalSyntheticLambda3
                            @Override // android.view.View.OnClickListener
                            public final void onClick(View view) {
                                Popup popup = (Popup) Ref$ObjectRef.this.element;
                                if (popup != null) {
                                    popup.dismiss();
                                }
                                Long valueOf = Long.valueOf(SystemClock.uptimeMillis());
                                List list2 = list;
                                Activity activity2 = activity;
                                String str7 = title;
                                UiKt.menuFrom = new Triple(str7, valueOf, new UiKt$$ExternalSyntheticLambda8(activity2, str7, i8, list2, 0));
                                function02.invoke();
                            }
                        });
                        LinearLayout.LayoutParams layoutParams32 = new LinearLayout.LayoutParams(-1, -2);
                        layoutParams32.topMargin = dp(activity, f2);
                        col.addView(linearLayout2, layoutParams32);
                        i8 = i;
                        it = it22;
                        i9 = i10;
                        z = false;
                        ref$ObjectRef = ref$ObjectRef32;
                    } else {
                        CollectionsKt__CollectionsKt.throwIndexOverflow();
                        throw null;
                    }
                }
                ScrollView scrollView = new ScrollView(activity);
                scrollView.addView(col);
                Popup.Builder builder = new Popup.Builder(activity);
                builder.title = title;
                builder.view = scrollView;
                builder.setNegativeButton(Fleet.T("common.close", new Pair[0]), null);
                if (function0 != null) {
                    builder.setNeutralButton(Fleet.T("common.back", new Pair[0]), new UiKt$$ExternalSyntheticLambda4(function0, 0));
                }
                Popup show = builder.show();
                ref$ObjectRef.element = show;
                if (function0 == null) {
                    show.setOnKeyListener(new DialogInterface.OnKeyListener() { // from class: dev.tvremote.phone.ui.UiKt$$ExternalSyntheticLambda5
                        @Override // android.content.DialogInterface.OnKeyListener
                        public final boolean onKey(DialogInterface dialogInterface, int i11, KeyEvent keyEvent) {
                            if (i11 != 4) {
                                return false;
                            }
                            if (keyEvent.getAction() == 1) {
                                dialogInterface.dismiss();
                                Function0.this.invoke();
                            }
                            return true;
                        }
                    });
                    return;
                }
                return;
            }
        }
        function0 = null;
        menuFrom = null;
        LinearLayout col3 = col(activity);
        float f7 = 16;
        float f22 = 8;
        col3.setPadding(dp(activity, f7), dp(activity, f22), dp(activity, f7), dp(activity, 4));
        Object obj2 = new Object();
        it = list.iterator();
        boolean z2 = false;
        int i92 = 0;
        Ref$ObjectRef ref$ObjectRef4 = obj2;
        while (it.hasNext()) {
        }
        ScrollView scrollView2 = new ScrollView(activity);
        scrollView2.addView(col3);
        Popup.Builder builder2 = new Popup.Builder(activity);
        builder2.title = title;
        builder2.view = scrollView2;
        builder2.setNegativeButton(Fleet.T("common.close", new Pair[0]), null);
        if (function0 != null) {
        }
        Popup show2 = builder2.show();
        ref$ObjectRef4.element = show2;
        if (function0 == null) {
        }
    }

    public static final TextView note(Context context, String s) {
        Intrinsics.checkNotNullParameter(context, "<this>");
        Intrinsics.checkNotNullParameter(s, "s");
        TextView label = label(context, s, 13, MUTED);
        label.setPadding(0, dp(context, 6), 0, 0);
        label.setLineSpacing(dp(context, 3), 1.0f);
        return label;
    }

    public static final GradientDrawable onBox(int i, Context context, boolean z) {
        if (z) {
            GradientDrawable box = box(context, SEL, i);
            box.setStroke(dp(context, 1.5f), ACCENT);
            return box;
        }
        return box(context, BTN, i);
    }

    public static final boolean onFill(int i) {
        if (i != ACCENT && i != GREEN) {
            return false;
        }
        return true;
    }

    public static final GradientDrawable oval(Context context, int i) {
        Intrinsics.checkNotNullParameter(context, "<this>");
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(1);
        gradientDrawable.setColor(i);
        return gradientDrawable;
    }

    public static final Button row(Context context, String s, Function0 function0) {
        Intrinsics.checkNotNullParameter(context, "<this>");
        Intrinsics.checkNotNullParameter(s, "s");
        Button button = button(context, s, CARD);
        button.setGravity(8388627);
        float f = 14;
        float f2 = 12;
        button.setPadding(dp(context, f), dp(context, f2), dp(context, f), dp(context, f2));
        button.setOnClickListener(new UiKt$$ExternalSyntheticLambda1(function0, 0));
        button.setLayoutParams(gap(context, 6));
        return button;
    }

    public static final void runs(TextView textView) {
        Intrinsics.checkNotNullParameter(textView, "<this>");
        textView.setSingleLine(true);
        if (Settings.Global.getFloat(textView.getContext().getContentResolver(), "animator_duration_scale", 1.0f) == 0.0f) {
            textView.setEllipsize(TextUtils.TruncateAt.END);
            return;
        }
        textView.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        textView.setMarqueeRepeatLimit(3);
        textView.setSelected(true);
    }

    public static final void say(TextView textView, String str) {
        String str2;
        Intrinsics.checkNotNullParameter(textView, "<this>");
        CharSequence text = textView.getText();
        if (text != null) {
            str2 = text.toString();
        } else {
            str2 = null;
        }
        if (!Intrinsics.areEqual(str2, str.toString())) {
            textView.setText(str);
        }
    }

    public static final void setInk(TextView textView, int i) {
        Intrinsics.checkNotNullParameter(textView, "<this>");
        textView.setTextColor(i);
        for (Drawable drawable : textView.getCompoundDrawablesRelative()) {
            if (drawable != null) {
                drawable.setTint(i);
            }
        }
    }

    public static final void setLabel(TextView textView, String s) {
        String str;
        int i;
        Intrinsics.checkNotNullParameter(textView, "<this>");
        Intrinsics.checkNotNullParameter(s, "s");
        if (StringsKt__StringsJVMKt.startsWith(s, false, "@") && StringsKt.contains$default(s, '|')) {
            str = s.substring(1, StringsKt.indexOf$default(s, '|', 6));
            Intrinsics.checkNotNullExpressionValue(str, "substring(...)");
        } else {
            str = null;
        }
        if (str != null) {
            s = StringsKt.substringAfter(s, "|", s);
        }
        setMarked(textView, s);
        if (str != null) {
            i = textView.getResources().getIdentifier("ic_".concat(str), "drawable", textView.getContext().getPackageName());
        } else {
            i = 0;
        }
        if (i == 0) {
            textView.setCompoundDrawablesRelative(null, null, null, null);
            return;
        }
        Drawable mutate = textView.getResources().getDrawable(i, null).mutate();
        Intrinsics.checkNotNullExpressionValue(mutate, "mutate(...)");
        int roundToInt = MathKt.roundToInt(textView.getTextSize() * 1.25f);
        mutate.setBounds(0, 0, roundToInt, roundToInt);
        mutate.setTint(textView.getCurrentTextColor());
        textView.setCompoundDrawablesRelative(mutate, null, null, null);
        textView.setCompoundDrawablePadding(MathKt.roundToInt(10 * textView.getResources().getDisplayMetrics().density));
        IconBesideText iconBesideText = IconBesideText.INSTANCE;
        textView.removeOnLayoutChangeListener(iconBesideText);
        textView.addOnLayoutChangeListener(iconBesideText);
        textView.post(new UiKt$$ExternalSyntheticLambda0(textView, 0));
    }

    /* JADX WARN: Type inference failed for: r8v3, types: [java.util.Map, java.lang.Object] */
    public static final void setMarked(TextView textView, String s) {
        int intValue;
        int i;
        Intrinsics.checkNotNullParameter(textView, "<this>");
        Intrinsics.checkNotNullParameter(s, "s");
        Object obj = Marks.ICONS;
        Context context = textView.getContext();
        Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(s);
        int length = s.length();
        for (int i2 = 0; i2 < length; i2++) {
            if (Marks.isMark(s, i2)) {
                char charAt = s.charAt(i2);
                HashMap hashMap = Marks.ids;
                synchronized (hashMap) {
                    try {
                        Character valueOf = Character.valueOf(charAt);
                        Object obj2 = hashMap.get(valueOf);
                        if (obj2 == null) {
                            String str = (String) Marks.ICONS.get(Character.valueOf(charAt));
                            if (str != null) {
                                i = context.getResources().getIdentifier(str, "drawable", context.getPackageName());
                            } else {
                                i = 0;
                            }
                            obj2 = Integer.valueOf(i);
                            hashMap.put(valueOf, obj2);
                        }
                        intValue = ((Number) obj2).intValue();
                    } catch (Throwable th) {
                        throw th;
                    }
                }
                if (intValue != 0) {
                    try {
                        Drawable drawable = context.getDrawable(intValue);
                        Intrinsics.checkNotNull(drawable);
                        Drawable mutate = drawable.mutate();
                        Intrinsics.checkNotNull(mutate);
                        spannableStringBuilder.setSpan(new Marks.IconSpan(mutate), i2, i2 + 1, 33);
                    } catch (Exception unused) {
                    }
                }
            }
        }
        textView.setText(spannableStringBuilder);
    }

    public static final void setOn(TextView textView, boolean z, int i, int i2) {
        IconButton iconButton;
        Intrinsics.checkNotNullParameter(textView, "<this>");
        Context context = textView.getContext();
        Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
        textView.setBackground(onBox(i, context, z));
        if (z) {
            i2 = ACCENT_TEXT;
        }
        setInk(textView, i2);
        if (textView instanceof IconButton) {
            iconButton = (IconButton) textView;
        } else {
            iconButton = null;
        }
        if (iconButton != null) {
            iconButton.setChosen(z);
        }
    }

    public static /* synthetic */ void setOn$default(TextView textView, boolean z, int i, int i2) {
        if ((i2 & 2) != 0) {
            i = 14;
        }
        setOn(textView, z, i, TEXT);
    }

    public static final void setToggle(TextView textView, boolean z, String s) {
        Intrinsics.checkNotNullParameter(textView, "<this>");
        Intrinsics.checkNotNullParameter(s, "s");
        textView.setText(s);
        int roundToInt = MathKt.roundToInt(textView.getTextSize() * 1.25f);
        Toggle toggle = new Toggle(ACCENT, DIM, z);
        toggle.setBounds(0, 0, roundToInt, roundToInt);
        textView.setCompoundDrawablesRelative(toggle, null, null, null);
        textView.setCompoundDrawablePadding(MathKt.roundToInt(10 * textView.getResources().getDisplayMetrics().density));
        IconBesideText iconBesideText = IconBesideText.INSTANCE;
        textView.removeOnLayoutChangeListener(iconBesideText);
        textView.addOnLayoutChangeListener(iconBesideText);
        textView.post(new UiKt$$ExternalSyntheticLambda0(textView, 1));
    }

    public static final int dp(Context context, int i) {
        Intrinsics.checkNotNullParameter(context, "<this>");
        return dp(context, i);
    }
}
