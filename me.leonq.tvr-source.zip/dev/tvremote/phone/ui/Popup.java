package dev.tvremote.phone.ui;

import android.R;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Words;
import dev.tvremote.core.ontv.Setup$plan$$inlined$sortedBy$1;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda6;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda9;
import dev.tvremote.phone.ir.IrRemoteKt$$ExternalSyntheticLambda8;
import dev.tvremote.phone.media.Talk$$ExternalSyntheticApiModelOutline1;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class Popup extends Dialog {
    public static final Set open = Collections.newSetFromMap(new WeakHashMap());
    public final HashMap buttons;
    public TextView message;
    public TextView title;

    /* loaded from: classes.dex */
    public final class Builder {
        public final LinkedHashMap buttons;
        public final Context c;
        public boolean cancelable;
        public Triple choices;
        public String message;
        public DialogInterface.OnCancelListener onCancel;
        public Guard$$ExternalSyntheticLambda6 onDismiss;
        public CharSequence title;
        public ViewGroup view;

        public Builder(Context c) {
            Intrinsics.checkNotNullParameter(c, "c");
            this.c = c;
            this.buttons = new LinkedHashMap();
            this.cancelable = true;
        }

        /* JADX WARN: Code restructure failed: missing block: B:61:0x02a0, code lost:
        
            if (r25.choices != null) goto L57;
         */
        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r0v10, types: [android.widget.LinearLayout, android.view.View, android.view.ViewGroup] */
        /* JADX WARN: Type inference failed for: r0v16, types: [android.view.View, dev.tvremote.phone.ui.Popup$Capped, android.view.ViewGroup] */
        /* JADX WARN: Type inference failed for: r0v26, types: [dev.tvremote.phone.ui.IconButton] */
        /* JADX WARN: Type inference failed for: r2v11, types: [android.widget.ScrollView, android.view.View] */
        /* JADX WARN: Type inference failed for: r5v0, types: [dev.tvremote.phone.ui.Popup, android.app.Dialog, java.lang.Object] */
        /* JADX WARN: Type inference failed for: r8v3, types: [android.widget.LinearLayout, android.view.View, android.view.ViewGroup] */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final Popup create() {
            HashMap hashMap;
            float f;
            float f2;
            ViewGroup viewGroup;
            View decorView;
            int i;
            Iterator it;
            float f3;
            PopupButton popupButton;
            int i2;
            Context context = this.c;
            final ?? popup = new Popup(context);
            popup.requestWindowFeature(1);
            popup.setCancelable(this.cancelable);
            DialogInterface.OnCancelListener onCancelListener = this.onCancel;
            if (onCancelListener != null) {
                popup.setOnCancelListener(onCancelListener);
            }
            Guard$$ExternalSyntheticLambda6 guard$$ExternalSyntheticLambda6 = this.onDismiss;
            if (guard$$ExternalSyntheticLambda6 != null) {
                popup.setOnDismissListener(guard$$ExternalSyntheticLambda6);
            }
            ?? col = UiKt.col(context);
            col.setBackground(UiKt.box(context, UiKt.CARD, 22));
            float f4 = 16;
            col.setPadding(0, UiKt.dp(context, 22), 0, UiKt.dp(context, f4));
            TextView label = UiKt.label(context, "", 19, UiKt.TEXT);
            label.setTypeface(Typeface.DEFAULT_BOLD);
            if (Build.VERSION.SDK_INT >= 28) {
                Talk$$ExternalSyntheticApiModelOutline1.m(label);
            }
            float f5 = 24;
            float f6 = 4;
            label.setPadding(UiKt.dp(context, f5), 0, UiKt.dp(context, f5), UiKt.dp(context, f6));
            popup.title = label;
            popup.setTitle(this.title);
            String T = Fleet.T("common.close", new Pair[0]);
            String T2 = Fleet.T("common.back", new Pair[0]);
            LinkedHashMap linkedHashMap = this.buttons;
            LinkedHashMap linkedHashMap2 = new LinkedHashMap();
            for (Map.Entry entry : linkedHashMap.entrySet()) {
                Pair pair = (Pair) entry.getValue();
                if (Intrinsics.areEqual(pair.first, T) || Intrinsics.areEqual(pair.first, T2)) {
                    linkedHashMap2.put(entry.getKey(), entry.getValue());
                }
            }
            LinearLayout linearLayout = new LinearLayout(context);
            linearLayout.setGravity(8388629);
            float f7 = 14;
            linearLayout.setPadding(0, 0, UiKt.dp(context, f7), 0);
            TextView textView = popup.title;
            ViewGroup viewGroup2 = null;
            if (textView != null) {
                linearLayout.addView(textView, new LinearLayout.LayoutParams(0, -2, 1.0f));
                Iterator it2 = CollectionsKt.sortedWith(linkedHashMap2.entrySet(), new Setup$plan$$inlined$sortedBy$1(2, T2)).iterator();
                while (true) {
                    boolean hasNext = it2.hasNext();
                    hashMap = popup.buttons;
                    if (!hasNext) {
                        break;
                    }
                    Map.Entry entry2 = (Map.Entry) it2.next();
                    int intValue = ((Number) entry2.getKey()).intValue();
                    Pair pair2 = (Pair) entry2.getValue();
                    CharSequence charSequence = (CharSequence) pair2.first;
                    DialogInterface.OnClickListener onClickListener = (DialogInterface.OnClickListener) pair2.second;
                    if (Intrinsics.areEqual(charSequence, T)) {
                        it = it2;
                        f3 = f6;
                        popupButton = UiKt.icon(context, "@close", charSequence.toString(), UiKt.BTN);
                    } else {
                        it = it2;
                        f3 = f6;
                        PopupButton popupButton2 = new PopupButton(context, charSequence.toString(), UiKt.BTN);
                        float f8 = 40;
                        popupButton2.setMinHeight(UiKt.dp(context, f8));
                        popupButton2.setMinimumHeight(UiKt.dp(context, f8));
                        popupButton = popupButton2;
                    }
                    popupButton.setOnClickListener(new IrRemoteKt$$ExternalSyntheticLambda8(onClickListener, popup, intValue, 1));
                    hashMap.put(Integer.valueOf(intValue), popupButton);
                    if (Intrinsics.areEqual(charSequence, T)) {
                        i2 = UiKt.dp(context, 40);
                    } else {
                        i2 = -2;
                    }
                    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(i2, UiKt.dp(context, 40));
                    layoutParams.leftMargin = UiKt.dp(context, 8);
                    linearLayout.addView(popupButton, layoutParams);
                    it2 = it;
                    f6 = f3;
                }
                float f9 = f6;
                Iterator it3 = linkedHashMap2.keySet().iterator();
                while (it3.hasNext()) {
                    linkedHashMap.remove(Integer.valueOf(((Number) it3.next()).intValue()));
                }
                if (!linkedHashMap2.isEmpty()) {
                    col.setPadding(0, UiKt.dp(context, f4), 0, UiKt.dp(context, f4));
                }
                col.addView(linearLayout);
                ?? col2 = UiKt.col(context);
                TextView label2 = UiKt.label(context, "", 15, UiKt.TEXT);
                label2.setId(R.id.message);
                label2.setLineSpacing(UiKt.dp(context, 3), 1.0f);
                label2.setPadding(UiKt.dp(context, f5), UiKt.dp(context, 8), UiKt.dp(context, f5), UiKt.dp(context, f9));
                popup.message = label2;
                popup.setMessage(this.message);
                TextView textView2 = popup.message;
                if (textView2 != null) {
                    col2.addView(textView2);
                    Triple triple = this.choices;
                    if (triple != null) {
                        CharSequence[] charSequenceArr = (CharSequence[]) triple.first;
                        final boolean[] zArr = (boolean[]) triple.second;
                        final DialogInterface.OnMultiChoiceClickListener onMultiChoiceClickListener = (DialogInterface.OnMultiChoiceClickListener) triple.third;
                        LinearLayout col3 = UiKt.col(context);
                        f2 = f7;
                        f = f4;
                        col3.setPadding(UiKt.dp(context, f2), UiKt.dp(context, f9), UiKt.dp(context, f5), 0);
                        int length = charSequenceArr.length;
                        int i3 = 0;
                        final int i4 = 0;
                        while (i3 < length) {
                            CharSequence charSequence2 = charSequenceArr[i3];
                            CharSequence[] charSequenceArr2 = charSequenceArr;
                            CheckBox checkBox = new CheckBox(context);
                            checkBox.setText(charSequence2);
                            checkBox.setTextSize(16.0f);
                            checkBox.setTextColor(UiKt.TEXT);
                            checkBox.setButtonTintList(ColorStateList.valueOf(UiKt.ACCENT));
                            checkBox.setChecked(zArr[i4]);
                            checkBox.setMinHeight(UiKt.dp(context, 48));
                            checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: dev.tvremote.phone.ui.Popup$Builder$$ExternalSyntheticLambda2
                                @Override // android.widget.CompoundButton.OnCheckedChangeListener
                                public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                                    boolean[] zArr2 = zArr;
                                    int i5 = i4;
                                    zArr2[i5] = z;
                                    DialogInterface.OnMultiChoiceClickListener onMultiChoiceClickListener2 = onMultiChoiceClickListener;
                                    if (onMultiChoiceClickListener2 != null) {
                                        onMultiChoiceClickListener2.onClick(popup, i5, z);
                                    }
                                }
                            });
                            col3.addView(checkBox);
                            i3++;
                            i4++;
                            charSequenceArr = charSequenceArr2;
                        }
                        col2.addView(col3);
                    } else {
                        f = f4;
                        f2 = f7;
                    }
                    ViewGroup viewGroup3 = this.view;
                    if (viewGroup3 instanceof ScrollView) {
                        if (this.message == null) {
                            viewGroup = viewGroup3;
                        }
                        col.addView(col2);
                        viewGroup = viewGroup3;
                    } else {
                        if (viewGroup3 != null) {
                            col2.addView(viewGroup3);
                        }
                        ?? scrollView = new ScrollView(context);
                        scrollView.addView(col2);
                        scrollView.setVerticalFadingEdgeEnabled(true);
                        viewGroup = scrollView;
                    }
                    ViewParent parent = viewGroup.getParent();
                    if (parent instanceof ViewGroup) {
                        viewGroup2 = (ViewGroup) parent;
                    }
                    ViewGroup viewGroup4 = viewGroup2;
                    if (viewGroup4 != null) {
                        viewGroup4.removeView(viewGroup);
                    }
                    col.addView(viewGroup, new LinearLayout.LayoutParams(-1, -2, 1.0f));
                    if (!linkedHashMap.isEmpty()) {
                        ButtonRow buttonRow = new ButtonRow(context);
                        float f10 = 20;
                        buttonRow.setPadding(UiKt.dp(context, f10), UiKt.dp(context, f2), UiKt.dp(context, f10), 0);
                        Iterator it4 = ArraysKt.asList(new Integer[]{-3, -2, -1}).iterator();
                        while (it4.hasNext()) {
                            int intValue2 = ((Number) it4.next()).intValue();
                            Pair pair3 = (Pair) linkedHashMap.get(Integer.valueOf(intValue2));
                            if (pair3 != null) {
                                CharSequence charSequence3 = (CharSequence) pair3.first;
                                DialogInterface.OnClickListener onClickListener2 = (DialogInterface.OnClickListener) pair3.second;
                                String obj = charSequence3.toString();
                                if (intValue2 == -1) {
                                    i = UiKt.ACCENT;
                                } else {
                                    i = UiKt.BTN;
                                }
                                PopupButton popupButton3 = new PopupButton(context, obj, i);
                                popupButton3.setOnClickListener(new IrRemoteKt$$ExternalSyntheticLambda8(onClickListener2, popup, intValue2, 2));
                                hashMap.put(Integer.valueOf(intValue2), popupButton3);
                                buttonRow.addView(popupButton3);
                            }
                        }
                        col.addView(buttonRow);
                    }
                    ?? capped = new Capped(context, UiKt.dp(context, 520));
                    float f11 = f;
                    capped.setPadding(UiKt.dp(context, f11), 0, UiKt.dp(context, f11), 0);
                    capped.addView(col, new FrameLayout.LayoutParams(-1, -2, 17));
                    col.setClickable(true);
                    capped.setOnClickListener(new Guard$$ExternalSyntheticLambda9(8, this, popup));
                    popup.setContentView(capped);
                    Window window = popup.getWindow();
                    if (window != null && (decorView = window.getDecorView()) != null) {
                        decorView.setLayoutDirection(Words.getRtl() ? 1 : 0);
                    }
                    Window window2 = popup.getWindow();
                    if (window2 != null) {
                        window2.setBackgroundDrawable(new ColorDrawable(0));
                        window2.setLayout(-1, -2);
                    }
                    return popup;
                }
                Intrinsics.throwUninitializedPropertyAccessException("message");
                throw null;
            }
            Intrinsics.throwUninitializedPropertyAccessException("title");
            throw null;
        }

        public final void setNegativeButton(String s, DialogInterface.OnClickListener onClickListener) {
            Intrinsics.checkNotNullParameter(s, "s");
            this.buttons.put(-2, new Pair(s, onClickListener));
        }

        public final void setNeutralButton(String s, DialogInterface.OnClickListener onClickListener) {
            Intrinsics.checkNotNullParameter(s, "s");
            this.buttons.put(-3, new Pair(s, onClickListener));
        }

        public final void setPositiveButton(String s, DialogInterface.OnClickListener onClickListener) {
            Intrinsics.checkNotNullParameter(s, "s");
            this.buttons.put(-1, new Pair(s, onClickListener));
        }

        public final Popup show() {
            Popup create = create();
            create.show();
            return create;
        }
    }

    /* loaded from: classes.dex */
    public final class ButtonRow extends LinearLayout {
        public final int gap;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public ButtonRow(Context c) {
            super(c);
            Intrinsics.checkNotNullParameter(c, "c");
            boolean z = UiKt.LIGHT;
            this.gap = UiKt.dp(c, 8);
        }

        @Override // android.widget.LinearLayout, android.view.View
        public final void onMeasure(int i, int i2) {
            int i3;
            int i4;
            int i5;
            int i6;
            int i7;
            int i8;
            int size = (View.MeasureSpec.getSize(i) - getPaddingLeft()) - getPaddingRight();
            int childCount = getChildCount();
            int i9 = 0;
            int i10 = 0;
            int i11 = 0;
            while (true) {
                i3 = this.gap;
                if (i9 >= childCount) {
                    break;
                }
                View childAt = getChildAt(i9);
                if (childAt.getVisibility() != 8) {
                    childAt.measure(View.MeasureSpec.makeMeasureSpec(0, 0), View.MeasureSpec.makeMeasureSpec(0, 0));
                    int measuredWidth = childAt.getMeasuredWidth();
                    int i12 = i11 + 1;
                    if (i11 <= 0) {
                        i3 = 0;
                    }
                    i10 += measuredWidth + i3;
                    i11 = i12;
                }
                i9++;
            }
            boolean z = true;
            if (i10 <= size) {
                i4 = 1;
            } else {
                i4 = 0;
            }
            setOrientation(i4 ^ 1);
            if (i4 != 0) {
                i5 = 8388629;
            } else {
                i5 = 0;
            }
            setGravity(i5);
            int childCount2 = getChildCount();
            for (int i13 = 0; i13 < childCount2; i13++) {
                View childAt2 = getChildAt(i13);
                ViewGroup.LayoutParams layoutParams = childAt2.getLayoutParams();
                Intrinsics.checkNotNull(layoutParams, "null cannot be cast to non-null type android.widget.LinearLayout.LayoutParams");
                LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) layoutParams;
                if (i4 != 0) {
                    i6 = -2;
                } else {
                    i6 = -1;
                }
                layoutParams2.width = i6;
                if (i4 != 0 && !z) {
                    i7 = i3;
                } else {
                    i7 = 0;
                }
                layoutParams2.leftMargin = i7;
                if (i4 == 0 && !z) {
                    i8 = i3;
                } else {
                    i8 = 0;
                }
                layoutParams2.topMargin = i8;
                if (childAt2.getVisibility() != 8) {
                    z = false;
                }
            }
            super.onMeasure(i, i2);
        }
    }

    /* loaded from: classes.dex */
    public final class Capped extends FrameLayout {
        public final int max;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public Capped(Context c, int i) {
            super(c);
            Intrinsics.checkNotNullParameter(c, "c");
            this.max = i;
        }

        @Override // android.widget.FrameLayout, android.view.View
        public final void onMeasure(int i, int i2) {
            ViewGroup.LayoutParams layoutParams;
            int size = (View.MeasureSpec.getSize(i) - getPaddingLeft()) - getPaddingRight();
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams2 = null;
            if (childAt != null) {
                layoutParams = childAt.getLayoutParams();
            } else {
                layoutParams = null;
            }
            if (layoutParams instanceof FrameLayout.LayoutParams) {
                layoutParams2 = (FrameLayout.LayoutParams) layoutParams;
            }
            if (layoutParams2 != null) {
                layoutParams2.width = Math.min(size, this.max);
            }
            super.onMeasure(i, i2);
        }
    }

    /* loaded from: classes.dex */
    public final class PopupButton extends Button {
        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public PopupButton(Context c, String s, int i) {
            super(c);
            int i2;
            Intrinsics.checkNotNullParameter(c, "c");
            Intrinsics.checkNotNullParameter(s, "s");
            setAllCaps(false);
            setTextSize(15.0f);
            if (UiKt.onFill(i)) {
                i2 = -1;
            } else {
                i2 = UiKt.TEXT;
            }
            setTextColor(i2);
            UiKt.setLabel(this, s);
            setBackground(UiKt.box(c, i, 14));
            setStateListAnimator(null);
            float f = 16;
            setPadding(UiKt.dp(c, f), 0, UiKt.dp(c, f), 0);
            float f2 = 64;
            setMinWidth(UiKt.dp(c, f2));
            setMinimumWidth(UiKt.dp(c, f2));
            float f3 = 44;
            setMinHeight(UiKt.dp(c, f3));
            setMinimumHeight(UiKt.dp(c, f3));
            setMaxLines(2);
        }

        @Override // android.widget.TextView, android.view.View
        public final void setEnabled(boolean z) {
            float f;
            super.setEnabled(z);
            if (z) {
                f = 1.0f;
            } else {
                f = 0.4f;
            }
            setAlpha(f);
        }
    }

    public Popup(Context context) {
        super(context);
        this.buttons = new HashMap();
    }

    public final Button getButton(int i) {
        Button button = (Button) this.buttons.get(Integer.valueOf(i));
        if (button != null) {
            return button;
        }
        throw new IllegalArgumentException(ApkSigner$$ExternalSyntheticOutline0.m("no button ", i));
    }

    @Override // android.app.Dialog
    public final void onStart() {
        super.onStart();
        open.add(this);
    }

    @Override // android.app.Dialog
    public final void onStop() {
        open.remove(this);
        super.onStop();
    }

    public final void setMessage(String str) {
        int i;
        TextView textView = this.message;
        if (textView != null) {
            textView.setText(str);
            TextView textView2 = this.message;
            if (textView2 != null) {
                if (str != null && str.length() != 0) {
                    i = 0;
                } else {
                    i = 8;
                }
                textView2.setVisibility(i);
                return;
            }
            Intrinsics.throwUninitializedPropertyAccessException("message");
            throw null;
        }
        Intrinsics.throwUninitializedPropertyAccessException("message");
        throw null;
    }

    @Override // android.app.Dialog
    public final void setTitle(CharSequence charSequence) {
        int i;
        TextView textView = this.title;
        if (textView != null) {
            textView.setText(charSequence);
            TextView textView2 = this.title;
            if (textView2 != null) {
                if (charSequence != null && charSequence.length() != 0) {
                    i = 0;
                } else {
                    i = 8;
                }
                textView2.setVisibility(i);
                Window window = getWindow();
                if (window != null) {
                    window.setTitle(charSequence);
                    return;
                }
                return;
            }
            Intrinsics.throwUninitializedPropertyAccessException("title");
            throw null;
        }
        Intrinsics.throwUninitializedPropertyAccessException("title");
        throw null;
    }
}
