package dev.tvremote.phone.ui;

import android.graphics.Typeface;
import android.text.TextUtils;
import android.widget.TextView;
import dev.tvremote.phone.MainActivity;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

/* loaded from: classes.dex */
public final class StatusText extends TextView {
    public boolean inner;
    public final TextView name;
    public boolean one;

    public StatusText(MainActivity mainActivity) {
        super(mainActivity);
        TextView textView = new TextView(mainActivity);
        textView.setTextColor(UiKt.TEXT);
        textView.setTextSize(15.0f);
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        UiKt.runs(textView);
        textView.setVisibility(8);
        this.name = textView;
        setTextColor(UiKt.MUTED);
        setTextSize(12.0f);
        setEllipsize(TextUtils.TruncateAt.END);
        setMaxLines(2);
    }

    public final TextView getName() {
        return this.name;
    }

    @Override // android.widget.TextView
    public final void setText(CharSequence charSequence, TextView.BufferType bufferType) {
        String str;
        if (charSequence == null || (str = charSequence.toString()) == null) {
            str = "";
        }
        int indexOf$default = StringsKt.indexOf$default(str, " · ", 0, false, 6);
        TextView textView = this.name;
        if (textView != null && !this.inner) {
            this.inner = true;
            try {
                split(textView, str, indexOf$default, bufferType);
                return;
            } finally {
                this.inner = false;
            }
        }
        super.setText(charSequence, bufferType);
    }

    public final void split(TextView textView, String str, int i, TextView.BufferType bufferType) {
        String substring;
        int i2;
        boolean z;
        String str2;
        if (i < 0) {
            substring = "";
        } else {
            substring = str.substring(0, i);
            Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
        }
        UiKt.say(textView, substring);
        if (i < 0) {
            i2 = 8;
        } else {
            i2 = 0;
        }
        textView.setVisibility(i2);
        boolean z2 = true;
        if (i >= 0) {
            z = true;
        } else {
            z = false;
        }
        if (z != this.one) {
            if (i < 0) {
                z2 = false;
            }
            this.one = z2;
            if (z2) {
                UiKt.runs(this);
            } else {
                setSingleLine(false);
                setMaxLines(2);
                setEllipsize(TextUtils.TruncateAt.END);
            }
        }
        if (i >= 0) {
            str = str.substring(i + 3);
            Intrinsics.checkNotNullExpressionValue(str, "substring(...)");
        }
        CharSequence text = getText();
        if (text != null) {
            str2 = text.toString();
        } else {
            str2 = null;
        }
        if (!str.equals(str2)) {
            super.setText(str, bufferType);
        }
    }
}
