package dev.tvremote.phone.ui;

/* loaded from: classes.dex */
public final class Palette {
    public static final Palette dark = new Palette(-15657960, -14933978, -14012360, -13408536, -8674561, -2056144, -1512723, -6643546, -30080, -13730481, -19288, -12967904, -6774093, -11870592, 1090519039, -652336856, 861637887, -14602675);
    public static final Palette light = new Palette(-789257, -1, -1249293, -13668874, -14329386, -1003456, -15065821, -10787210, -4182225, -15500735, -5036514, -268827, -10787210, -15500735, 805306368, -419430401, 640642550, -1643010);
    public final int accent;
    public final int accentText;
    public final int bg;
    public final int btn;
    public final int card;
    public final int dim;
    public final int errBg;
    public final int errText;
    public final int green;
    public final int held;
    public final int muted;
    public final int okText;
    public final int pill;
    public final int red;
    public final int ripple;
    public final int sel;
    public final int soft;
    public final int text;

    public Palette(int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18) {
        this.bg = i;
        this.card = i2;
        this.btn = i3;
        this.accent = i4;
        this.accentText = i5;
        this.held = i6;
        this.text = i7;
        this.muted = i8;
        this.red = i9;
        this.green = i10;
        this.errText = i11;
        this.errBg = i12;
        this.dim = i13;
        this.okText = i14;
        this.ripple = i15;
        this.pill = i16;
        this.soft = i17;
        this.sel = i18;
    }
}
