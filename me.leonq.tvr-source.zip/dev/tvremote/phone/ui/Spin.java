package dev.tvremote.phone.ui;

import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.view.animation.LinearInterpolator;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class Spin extends Drawable implements Animatable {
    public final Paint paint;
    public final ValueAnimator turn;

    public Spin(int i, float f) {
        Paint paint = new Paint(1);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(f);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setColor(i);
        this.paint = paint;
        final ValueAnimator ofFloat = ValueAnimator.ofFloat(0.0f, 360.0f);
        ofFloat.setDuration(1000L);
        ofFloat.setRepeatCount(-1);
        ofFloat.setInterpolator(new LinearInterpolator());
        ofFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: dev.tvremote.phone.ui.Spin$$ExternalSyntheticLambda0
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator it) {
                Intrinsics.checkNotNullParameter(it, "it");
                Spin spin = Spin.this;
                if (spin.getCallback() == null) {
                    ofFloat.cancel();
                } else {
                    spin.invalidateSelf();
                }
            }
        });
        this.turn = ofFloat;
    }

    @Override // android.graphics.drawable.Drawable
    public final void draw(Canvas c) {
        Intrinsics.checkNotNullParameter(c, "c");
        RectF rectF = new RectF(getBounds());
        Paint paint = this.paint;
        float strokeWidth = paint.getStrokeWidth() / 2;
        rectF.inset(strokeWidth, strokeWidth);
        Object animatedValue = this.turn.getAnimatedValue();
        Intrinsics.checkNotNull(animatedValue, "null cannot be cast to non-null type kotlin.Float");
        c.drawArc(rectF, ((Float) animatedValue).floatValue(), 270.0f, false, paint);
    }

    @Override // android.graphics.drawable.Drawable
    public final int getOpacity() {
        return -3;
    }

    @Override // android.graphics.drawable.Animatable
    public final boolean isRunning() {
        return this.turn.isRunning();
    }

    @Override // android.graphics.drawable.Drawable
    public final void setAlpha(int i) {
        this.paint.setAlpha(i);
    }

    @Override // android.graphics.drawable.Drawable
    public final void setColorFilter(ColorFilter colorFilter) {
        this.paint.setColorFilter(colorFilter);
    }

    @Override // android.graphics.drawable.Animatable
    public final void start() {
        this.turn.start();
    }

    @Override // android.graphics.drawable.Animatable
    public final void stop() {
        this.turn.cancel();
    }
}
