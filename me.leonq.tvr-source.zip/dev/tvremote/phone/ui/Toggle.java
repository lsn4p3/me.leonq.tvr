package dev.tvremote.phone.ui;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class Toggle extends Drawable {
    public final int fill;
    public final int off;
    public final boolean on;
    public final Paint p = new Paint(1);

    public Toggle(int i, int i2, boolean z) {
        this.on = z;
        this.fill = i;
        this.off = i2;
    }

    @Override // android.graphics.drawable.Drawable
    public final void draw(Canvas c) {
        Intrinsics.checkNotNullParameter(c, "c");
        Rect bounds = getBounds();
        Intrinsics.checkNotNullExpressionValue(bounds, "getBounds(...)");
        float width = bounds.width() / 2.0f;
        float exactCenterX = bounds.exactCenterX();
        float exactCenterY = bounds.exactCenterY();
        float f = width / 6.0f;
        Paint paint = this.p;
        if (this.on) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(this.fill);
            c.drawCircle(exactCenterX, exactCenterY, width, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(f * 1.3f);
            paint.setColor(-1);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
            Path path = new Path();
            float f2 = 0.45f * width;
            path.moveTo(exactCenterX - f2, (0.02f * width) + exactCenterY);
            path.lineTo(exactCenterX - (0.12f * width), (0.33f * width) + exactCenterY);
            path.lineTo(exactCenterX + f2, exactCenterY - (width * 0.3f));
            c.drawPath(path, paint);
            return;
        }
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(f);
        paint.setColor(this.off);
        c.drawCircle(exactCenterX, exactCenterY, width - (f / 2), paint);
    }

    @Override // android.graphics.drawable.Drawable
    public final int getOpacity() {
        return -3;
    }

    @Override // android.graphics.drawable.Drawable
    public final void setAlpha(int i) {
        this.p.setAlpha(i);
    }

    @Override // android.graphics.drawable.Drawable
    public final void setColorFilter(ColorFilter colorFilter) {
        this.p.setColorFilter(colorFilter);
    }
}
