package dev.tvremote.phone.ui;

import dev.tvremote.core.Downloader;
import dev.tvremote.core.adb.Mdns;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;

/* loaded from: classes.dex */
public final class DlApp {
    public final String key;
    public final Serializable look;
    public final Serializable open;
    public final Serializable pkg;
    public final Serializable title;

    public DlApp(String str, String str2, String str3, String str4, String str5) {
        this.key = str;
        this.pkg = str2;
        this.title = str3;
        this.look = str4;
        this.open = str5;
    }

    public void add(String str, ArrayList arrayList) {
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            Mdns.Record record = (Mdns.Record) it.next();
            int i = record.type;
            String str2 = record.name;
            if (i != 1) {
                HashMap hashMap = (HashMap) this.open;
                if (i != 12) {
                    if (i == 33) {
                        ((HashMap) this.title).put(str2, record);
                        if (hashMap.get(str2) == null) {
                            hashMap.put(str2, str);
                        }
                    }
                } else {
                    if (StringsKt__StringsJVMKt.equals(str2, this.key + ".local")) {
                        LinkedHashSet linkedHashSet = (LinkedHashSet) this.pkg;
                        String str3 = record.target;
                        linkedHashSet.add(str3);
                        if (hashMap.get(str3) == null) {
                            hashMap.put(str3, str);
                        }
                    }
                }
            } else {
                HashMap hashMap2 = (HashMap) this.look;
                String lowerCase = str2.toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                hashMap2.put(lowerCase, record.ip);
            }
        }
    }

    public ArrayList found() {
        LinkedHashSet<String> linkedHashSet = (LinkedHashSet) this.pkg;
        ArrayList arrayList = new ArrayList();
        for (String str : linkedHashSet) {
            Mdns.Record record = (Mdns.Record) ((HashMap) this.title).get(str);
            Mdns.Service service = null;
            if (record != null) {
                String removeSuffix = StringsKt.removeSuffix(str, "." + this.key + ".local");
                HashMap hashMap = (HashMap) this.look;
                String lowerCase = record.target.toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                String str2 = (String) hashMap.get(lowerCase);
                if (str2 != null || (str2 = (String) ((HashMap) this.open).get(str)) != null) {
                    service = new Mdns.Service(removeSuffix, record.port, str2);
                }
            }
            if (service != null) {
                arrayList.add(service);
            }
        }
        return arrayList;
    }

    public String getCode() {
        List list = Downloader.bases;
        String str = (String) Downloader.codes().get(this.key);
        if (str == null) {
            return "";
        }
        return str;
    }

    public ArrayList hosts() {
        Collection values = ((HashMap) this.title).values();
        Intrinsics.checkNotNullExpressionValue(values, "<get-values>(...)");
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(values));
        Iterator it = values.iterator();
        while (it.hasNext()) {
            arrayList.add(((Mdns.Record) it.next()).target);
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator it2 = arrayList.iterator();
        while (it2.hasNext()) {
            Object next = it2.next();
            HashMap hashMap = (HashMap) this.look;
            String lowerCase = ((String) next).toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
            if (!hashMap.containsKey(lowerCase)) {
                arrayList2.add(next);
            }
        }
        return arrayList2;
    }

    public DlApp(String type) {
        Intrinsics.checkNotNullParameter(type, "type");
        this.key = type;
        this.pkg = new LinkedHashSet();
        this.title = new HashMap();
        this.look = new HashMap();
        this.open = new HashMap();
    }
}
