package dev.tvremote.phone.ui;

import android.widget.TextView;

/* loaded from: classes.dex */
public final /* synthetic */ class UiKt$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ TextView f$0;

    public /* synthetic */ UiKt$$ExternalSyntheticLambda0(TextView textView, int i) {
        this.$r8$classId = i;
        this.f$0 = textView;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.$r8$classId) {
            case 0:
                IconBesideText.place(this.f$0);
                return;
            default:
                IconBesideText.place(this.f$0);
                return;
        }
    }
}
