package dev.tvremote.phone;

import android.widget.ImageView;
import android.widget.Toast;
import dev.tvremote.core.Errors;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.FleetStatus;
import dev.tvremote.core.Words;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.remote.Lg$$ExternalSyntheticLambda2;
import dev.tvremote.phone.ir.IrRemoteKt;
import dev.tvremote.phone.ir.IrState;
import dev.tvremote.phone.media.MediaKt$$ExternalSyntheticLambda15;
import dev.tvremote.phone.picker.AdbHelpKt;
import dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda63;
import dev.tvremote.phone.picker.PickerScreenKt;
import dev.tvremote.phone.picker.TvStatus;
import dev.tvremote.phone.picker.TvStatusKt;
import dev.tvremote.phone.picker.TvStatusKt$$ExternalSyntheticLambda9;
import dev.tvremote.phone.picture.Air;
import dev.tvremote.phone.remote.PhoneRemoteKt;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import org.conscrypt.FileClientSessionCache;
import org.conscrypt.metrics.ConscryptStatsLog;
import org.json.JSONArray;

/* loaded from: classes.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda15 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda15(MainActivity mainActivity, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        String str;
        JSONArray jSONArray;
        int i = 2;
        int i2 = 0;
        switch (this.$r8$classId) {
            case 0:
                MainActivity mainActivity = this.f$0;
                if (mainActivity.host != null && mainActivity.tv == null && mainActivity.basic == null) {
                    mainActivity.startSession$android_release();
                    return;
                }
                return;
            case 1:
                MainActivity mainActivity2 = this.f$0;
                int i3 = MainActivity.$r8$clinit;
                List list = PickerScreenKt.PER_TV;
                mainActivity2.ui.removeCallbacks(mainActivity2.probe);
                if (mainActivity2.host == null && !mainActivity2.waking) {
                    Iterator it = PickerScreenKt.savedIps(mainActivity2).iterator();
                    while (it.hasNext()) {
                        String str2 = (String) it.next();
                        Object obj = mainActivity2.reach.get(str2);
                        Boolean bool = Boolean.FALSE;
                        if (Intrinsics.areEqual(obj, bool) && mainActivity2.trying.add(str2)) {
                            PickerScreenKt.showReach(mainActivity2, str2, bool);
                        }
                        new Thread(new AdbHelpKt$$ExternalSyntheticLambda63(str2, mainActivity2, i)).start();
                    }
                }
                mainActivity2.ui.postDelayed(mainActivity2.probe, 8000L);
                if (mainActivity2.host == null && !mainActivity2.waking) {
                    WeakHashMap weakHashMap = TvStatusKt.tickFor;
                    boolean z = TvStatus.shots;
                    TvStatus.resolve = new MainActivity$$ExternalSyntheticLambda10(mainActivity2, 10);
                    if (!TvStatus.busy.get() && mainActivity2.host == null) {
                        mainActivity2.ui.removeCallbacks(TvStatusKt.getStatusTick(mainActivity2));
                        TvStatusKt.getStatusTick(mainActivity2).run();
                        return;
                    }
                    return;
                }
                return;
            case 2:
                MainActivity mainActivity3 = this.f$0;
                Fleet.install(mainActivity3, mainActivity3.update);
                return;
            case 3:
                int i4 = MainActivity.$r8$clinit;
                MainActivity mainActivity4 = this.f$0;
                mainActivity4.stopPicture$android_release();
                Tv tv = mainActivity4.tv;
                if (tv != null) {
                    tv.stop();
                }
                mainActivity4.tv = null;
                return;
            case 4:
                int i5 = MainActivity.$r8$clinit;
                this.f$0.stopPicture$android_release();
                return;
            case 5:
                int i6 = MainActivity.$r8$clinit;
                this.f$0.startPicture$android_release();
                return;
            case 6:
                int i7 = MainActivity.$r8$clinit;
                this.f$0.getMini$android_release().mode(false);
                return;
            case 7:
                int i8 = MainActivity.$r8$clinit;
                Toast.makeText(this.f$0, Fleet.T("remote.app_key_missing", new Pair[0]), 1).show();
                return;
            case 8:
                MainActivity mainActivity5 = this.f$0;
                if (!mainActivity5.isFinishing()) {
                    IrRemoteKt.irRename(IrState.slot, mainActivity5);
                    return;
                }
                return;
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                MainActivity mainActivity6 = this.f$0;
                if (!mainActivity6.isFinishing()) {
                    Toast.makeText(mainActivity6, Fleet.T("ir.failed", new Pair[0]), 0).show();
                    return;
                }
                return;
            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                Fleet.startSound(this.f$0);
                return;
            case 11:
                MainActivity mainActivity7 = this.f$0;
                Object obj2 = Errors.ANDROID;
                IllegalArgumentException illegalArgumentException = new IllegalArgumentException("the TV has no app that can open this");
                ConcurrentHashMap concurrentHashMap = Words.books;
                Fleet.say(mainActivity7, Errors.say(Words.lang, illegalArgumentException), true);
                return;
            case FileClientSessionCache.MAX_SIZE /* 12 */:
                MainActivity mainActivity8 = this.f$0;
                if (mainActivity8.basic != null && !mainActivity8.isFinishing()) {
                    AdbHelpKt.installSetupByHand(mainActivity8);
                    return;
                }
                return;
            case 13:
                MainActivity mainActivity9 = this.f$0;
                if (mainActivity9.basic != null && !mainActivity9.isFinishing()) {
                    AdbHelpKt.installSetupByHand(mainActivity9);
                    return;
                }
                return;
            case 14:
                MainActivity mainActivity10 = this.f$0;
                if (mainActivity10.basic != null && !mainActivity10.isFinishing()) {
                    AdbHelpKt.installSetupByHand(mainActivity10);
                    return;
                }
                return;
            case 15:
                MainActivity mainActivity11 = this.f$0;
                if (mainActivity11.host == null) {
                    mainActivity11.probe.run();
                    return;
                }
                return;
            case 16:
                MainActivity mainActivity12 = this.f$0;
                if (mainActivity12.host == null && !mainActivity12.isFinishing()) {
                    ArrayList savedIps = PickerScreenKt.savedIps(mainActivity12);
                    if (!savedIps.isEmpty() && TvStatus.busy.compareAndSet(false, true)) {
                        new Thread(new TvStatusKt$$ExternalSyntheticLambda9(savedIps, mainActivity12)).start();
                        return;
                    } else {
                        mainActivity12.ui.postDelayed(TvStatusKt.getStatusTick(mainActivity12), 10000L);
                        return;
                    }
                }
                return;
            case 17:
                MainActivity mainActivity13 = this.f$0;
                if (mainActivity13.host == null && !mainActivity13.isFinishing()) {
                    boolean z2 = TvStatus.shots;
                    if (TvStatus.shots) {
                        for (Map.Entry entry : TvStatus.thumbs.entrySet()) {
                            String str3 = (String) entry.getKey();
                            ImageView imageView = (ImageView) entry.getValue();
                            FleetStatus.Status status = (FleetStatus.Status) TvStatus.last.get(str3);
                            if (status != null) {
                                str = status.state;
                            } else {
                                str = null;
                            }
                            if (Intrinsics.areEqual(str, "on") && !Intrinsics.areEqual(imageView.getTag(), "busy")) {
                                imageView.setTag("busy");
                                TvStatus.pool.execute(new Lg$$ExternalSyntheticLambda2(str3, mainActivity13, imageView, 28));
                            }
                        }
                        mainActivity13.ui.removeCallbacks(TvStatusKt.getShotTick(mainActivity13));
                        mainActivity13.ui.postDelayed(TvStatusKt.getShotTick(mainActivity13), 5000L);
                        return;
                    }
                    return;
                }
                return;
            case 18:
                MainActivity mainActivity14 = this.f$0;
                float[] fArr = new float[2];
                try {
                    long nanoTime = System.nanoTime();
                    while (true) {
                        int i9 = i2 + 1;
                        double d = i2 * 0.05d;
                        double d2 = 4;
                        Air.airMove(mainActivity14, (float) (Math.cos(d) * d2), (float) (Math.sin(d) * d2), fArr);
                        nanoTime += 5000000;
                        long nanoTime2 = nanoTime - System.nanoTime();
                        if (nanoTime2 > 0) {
                            long j = 1000000;
                            Thread.sleep(nanoTime2 / j, (int) (nanoTime2 % j));
                        }
                        i2 = i9;
                    }
                } catch (InterruptedException unused) {
                    return;
                }
            case 19:
                MainActivity mainActivity15 = this.f$0;
                while (true) {
                    synchronized (mainActivity15.drawQ) {
                        if (mainActivity15.drawQ.isEmpty()) {
                            mainActivity15.drawBusy = false;
                            return;
                        } else {
                            jSONArray = new JSONArray((Collection) mainActivity15.drawQ);
                            mainActivity15.drawQ.clear();
                        }
                    }
                    try {
                        mainActivity15.drawer.send(jSONArray);
                    } catch (Exception e) {
                        synchronized (mainActivity15.drawQ) {
                            mainActivity15.drawQ.clear();
                            mainActivity15.drawBusy = false;
                            mainActivity15.ui.post(new MediaKt$$ExternalSyntheticLambda15(mainActivity15, e, i));
                            return;
                        }
                    }
                }
            case 20:
                MainActivity mainActivity16 = this.f$0;
                try {
                    mainActivity16.drawer.send(new JSONArray());
                    return;
                } catch (Exception e2) {
                    mainActivity16.ui.post(new MediaKt$$ExternalSyntheticLambda15(mainActivity16, e2, 3));
                    return;
                }
            case 21:
                this.f$0.drawer.close();
                return;
            case 22:
                PickerScreenKt.message(this.f$0, Fleet.T("keys_only.the_tv_said_no", new Pair[0]), true);
                return;
            case 23:
                PickerScreenKt.message(this.f$0, Fleet.T("keys_only.the_tv_did_not", new Pair[0]), true);
                return;
            case 24:
                PickerScreenKt.message(this.f$0, Fleet.T("keys_only.wrong_code_tap_the", new Pair[0]), true);
                return;
            case 25:
                PickerScreenKt.message(this.f$0, Fleet.T("keys_only.look_at_the_tv", new Pair[0]), false);
                return;
            case 26:
                PhoneRemoteKt.trackingMenu(this.f$0);
                return;
            case 27:
                Toast.makeText(this.f$0, Fleet.T("remote.app_key_missing", new Pair[0]), 1).show();
                return;
            default:
                MathKt.toast(this.f$0, Fleet.T("core.fr_channels_missing", new Pair[0]));
                return;
        }
    }
}
