package dev.tvremote.phone;

import android.widget.Toast;
import dev.tvremote.core.scenes.Scenes;
import dev.tvremote.phone.scenes.Headless$$ExternalSyntheticLambda0;
import dev.tvremote.tvui.Marks;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.StringsKt__StringsJVMKt;

/* loaded from: classes.dex */
public final /* synthetic */ class SceneService$$ExternalSyntheticLambda3 implements Runnable {
    public final /* synthetic */ int $r8$classId = 0;
    public final /* synthetic */ SceneService f$0;
    public final /* synthetic */ String f$1;
    public final /* synthetic */ String f$2;

    public /* synthetic */ SceneService$$ExternalSyntheticLambda3(SceneService sceneService, String str, String str2) {
        this.f$0 = sceneService;
        this.f$1 = str;
        this.f$2 = str2;
    }

    /* JADX WARN: Type inference failed for: r2v1, types: [dev.tvremote.core.Diagnose$Real, java.lang.Object] */
    @Override // java.lang.Runnable
    public final void run() {
        String message;
        int i = 0;
        switch (this.$r8$classId) {
            case 0:
                String str = this.f$2;
                int i2 = SceneService.$r8$clinit;
                SceneService sceneService = this.f$0;
                ?? obj = new Object();
                obj.link = sceneService;
                obj.bindUdp = sceneService.getSharedPreferences("tvs", 0);
                MathKt.reachAroundVpn(sceneService);
                String str2 = this.f$1;
                try {
                    if (str2 != null) {
                        message = obj.scene(str2);
                    } else if (str.equals("power")) {
                        message = obj.run(new Headless$$ExternalSyntheticLambda0(i));
                    } else if (str.equals("mute")) {
                        final int i3 = 164;
                        message = obj.run(new Function2() { // from class: dev.tvremote.phone.scenes.Headless$$ExternalSyntheticLambda1
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj2, Object obj3) {
                                Scenes.Target tv = (Scenes.Target) obj2;
                                ((Boolean) obj3).getClass();
                                Intrinsics.checkNotNullParameter(tv, "tv");
                                tv.key(i3);
                                return null;
                            }
                        });
                    } else if (str.equals("vol_up")) {
                        final int i4 = 24;
                        message = obj.run(new Function2() { // from class: dev.tvremote.phone.scenes.Headless$$ExternalSyntheticLambda1
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj2, Object obj3) {
                                Scenes.Target tv = (Scenes.Target) obj2;
                                ((Boolean) obj3).getClass();
                                Intrinsics.checkNotNullParameter(tv, "tv");
                                tv.key(i4);
                                return null;
                            }
                        });
                    } else if (str.equals("vol_down")) {
                        final int i5 = 25;
                        message = obj.run(new Function2() { // from class: dev.tvremote.phone.scenes.Headless$$ExternalSyntheticLambda1
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj2, Object obj3) {
                                Scenes.Target tv = (Scenes.Target) obj2;
                                ((Boolean) obj3).getClass();
                                Intrinsics.checkNotNullParameter(tv, "tv");
                                tv.key(i5);
                                return null;
                            }
                        });
                    } else {
                        message = null;
                    }
                } catch (Exception e) {
                    message = e.getMessage();
                }
                sceneService.ui.post(new SceneService$$ExternalSyntheticLambda3(message, str2, sceneService));
                return;
            default:
                String str3 = this.f$1;
                String str4 = this.f$2;
                SceneService sceneService2 = this.f$0;
                if (str3 != null) {
                    int i6 = SceneService.$r8$clinit;
                    if (!StringsKt__StringsJVMKt.startsWith(str3, false, "✓") || str4 != null) {
                        Toast.makeText(sceneService2, Marks.plain(str3), 0).show();
                    }
                }
                sceneService2.busy = false;
                sceneService2.stopSelf();
                return;
        }
    }

    public /* synthetic */ SceneService$$ExternalSyntheticLambda3(String str, String str2, SceneService sceneService) {
        this.f$1 = str;
        this.f$2 = str2;
        this.f$0 = sceneService;
    }
}
