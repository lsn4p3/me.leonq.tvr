package dev.tvremote.phone.scenes;

import android.os.Handler;
import dev.tvremote.core.Fleet$$ExternalSyntheticLambda0;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.Mdns;
import dev.tvremote.core.adb.TvShell;
import dev.tvremote.core.ontv.Channels;
import dev.tvremote.core.ontv.Home;
import dev.tvremote.core.ontv.OwnApp;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.scenes.Scenes;
import dev.tvremote.core.scenes.Voice;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda15;
import dev.tvremote.phone.media.MediaKt$$ExternalSyntheticLambda15;
import dev.tvremote.phone.media.TalkKt$$ExternalSyntheticLambda2;
import dev.tvremote.phone.picture.DrawingKt$$ExternalSyntheticLambda0;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;
import kotlin.text.StringsKt;

/* loaded from: classes.dex */
public final /* synthetic */ class AutomationKt$$ExternalSyntheticLambda1 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Voice.Command f$0;
    public final /* synthetic */ MainActivity f$1;
    public final /* synthetic */ Tv f$2;

    public /* synthetic */ AutomationKt$$ExternalSyntheticLambda1(Tv tv, Voice.Command command, MainActivity mainActivity, int i) {
        this.$r8$classId = i;
        this.f$2 = tv;
        this.f$0 = command;
        this.f$1 = mainActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i = 9;
        switch (this.$r8$classId) {
            case 0:
                Voice.Command command = this.f$0;
                Tv tv = this.f$2;
                try {
                    HashMap hashMap = Scenes.KEYS;
                    Scenes.launch(((Voice.Command.App) command).pkg, new TalkKt$$ExternalSyntheticLambda2(tv, 15));
                    return;
                } catch (Exception e) {
                    MainActivity mainActivity = this.f$1;
                    mainActivity.ui.post(new MediaKt$$ExternalSyntheticLambda15(mainActivity, e, 6));
                    return;
                }
            case 1:
                Tv tv2 = this.f$2;
                Voice.Command command2 = this.f$0;
                MainActivity mainActivity2 = this.f$1;
                Voice.Command.Search search = (Voice.Command.Search) command2;
                String pkg = search.pkg;
                String str = search.url;
                String query = search.query;
                tv2.getClass();
                Intrinsics.checkNotNullParameter(pkg, "pkg");
                Intrinsics.checkNotNullParameter(query, "query");
                Adb adb = tv2.adb;
                String str2 = null;
                if (adb != null) {
                    try {
                        TvShell tvShell = TvShell.INSTANCE;
                        String obj = StringsKt.trim(adb.shell(120000L, TvShell.searchIn(pkg, str, query))).toString();
                        if (Intrinsics.areEqual(obj, "none")) {
                            HashMap hashMap2 = Scenes.KEYS;
                            Scenes.launch(pkg, new Fleet$$ExternalSyntheticLambda0(adb, 15));
                        }
                        str2 = obj;
                    } catch (Exception unused) {
                    }
                }
                if (str2 == null || str2.equals("none")) {
                    mainActivity2.ui.post(new DrawingKt$$ExternalSyntheticLambda0(i, mainActivity2, command2));
                    return;
                }
                return;
            case 2:
                Tv tv3 = this.f$2;
                Voice.Command command3 = this.f$0;
                try {
                    ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                    tv3.shell("am force-stop " + Mdns.q(((Voice.Command.Close) command3).pkg));
                    return;
                } catch (Exception e2) {
                    MainActivity mainActivity3 = this.f$1;
                    mainActivity3.ui.post(new MediaKt$$ExternalSyntheticLambda15(mainActivity3, e2, 8));
                    return;
                }
            case 3:
                Voice.Command command4 = this.f$0;
                MainActivity mainActivity4 = this.f$1;
                Handler handler = mainActivity4.ui;
                Tv tv4 = this.f$2;
                try {
                    OwnApp ownApp = Channels.app;
                    if (!Channels.open(((Voice.Command.Channel) command4).name, new TalkKt$$ExternalSyntheticLambda2(tv4, 17))) {
                        handler.post(new MainActivity$$ExternalSyntheticLambda15(mainActivity4, 28));
                        return;
                    }
                    return;
                } catch (Exception e3) {
                    handler.post(new MediaKt$$ExternalSyntheticLambda15(mainActivity4, e3, i));
                    return;
                }
            case 4:
                Tv tv5 = this.f$2;
                Voice.Command command5 = this.f$0;
                try {
                    TvShell tvShell2 = TvShell.INSTANCE;
                    tv5.shell(TvShell.setting(((Voice.Command.Setting) command5).actions));
                    return;
                } catch (Exception e4) {
                    MainActivity mainActivity5 = this.f$1;
                    mainActivity5.ui.post(new MediaKt$$ExternalSyntheticLambda15(mainActivity5, e4, 10));
                    return;
                }
            default:
                Voice.Command command6 = this.f$0;
                Tv tv6 = this.f$2;
                try {
                    Regex regex = Home.PIN_KEY;
                    Home.openPin(((Voice.Command.Pin) command6).key, new TalkKt$$ExternalSyntheticLambda2(tv6, 16));
                    return;
                } catch (Exception e5) {
                    MainActivity mainActivity6 = this.f$1;
                    mainActivity6.ui.post(new MediaKt$$ExternalSyntheticLambda15(mainActivity6, e5, 7));
                    return;
                }
        }
    }

    public /* synthetic */ AutomationKt$$ExternalSyntheticLambda1(Voice.Command command, MainActivity mainActivity, Tv tv, int i) {
        this.$r8$classId = i;
        this.f$0 = command;
        this.f$1 = mainActivity;
        this.f$2 = tv;
    }
}
