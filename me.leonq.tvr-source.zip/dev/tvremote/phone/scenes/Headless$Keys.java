package dev.tvremote.phone.scenes;

import dev.tvremote.core.Fleet;
import dev.tvremote.core.remote.Atv;
import dev.tvremote.core.scenes.Scenes;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class Headless$Keys implements Scenes.Target {
    public final Atv a;

    public Headless$Keys(Atv a) {
        Intrinsics.checkNotNullParameter(a, "a");
        this.a = a;
    }

    @Override // dev.tvremote.core.scenes.Scenes.Target
    public final void app(String str) {
        this.a.launch(str);
    }

    @Override // dev.tvremote.core.scenes.Scenes.Target
    public final void input(String str) {
        throw new IllegalArgumentException("this TV cannot switch inputs from here");
    }

    @Override // dev.tvremote.core.scenes.Scenes.Target
    public final void key(int i) {
        Atv atv = this.a;
        if (19 <= i && i < 24) {
            atv.pulse(i, 110L);
        } else {
            atv.key(i, 3);
        }
    }

    @Override // dev.tvremote.core.scenes.Scenes.Target
    public final void link(String str) {
        this.a.launch(str);
    }

    @Override // dev.tvremote.core.scenes.Scenes.Target
    public final void notify(JSONObject jSONObject) {
        throw new IllegalArgumentException("a message on the TV needs ADB and TV Setup");
    }

    @Override // dev.tvremote.core.scenes.Scenes.Target
    public final void timer(int i) {
        throw new IllegalArgumentException(Fleet.T("headless.the_timer_needs_adb", new Pair[0]));
    }

    @Override // dev.tvremote.core.scenes.Scenes.Target
    public final void volume(int i) {
        throw new IllegalArgumentException(Fleet.T("headless.setting_the_volume_needs", new Pair[0]));
    }
}
