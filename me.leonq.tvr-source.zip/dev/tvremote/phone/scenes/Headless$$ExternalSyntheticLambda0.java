package dev.tvremote.phone.scenes;

import android.content.Intent;
import android.os.Build;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.scenes.Scenes;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda10;
import dev.tvremote.phone.manage.Managing;
import dev.tvremote.phone.picture.Air;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.StringsKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class Headless$$ExternalSyntheticLambda0 implements Function2 {
    public final /* synthetic */ int $r8$classId;

    public /* synthetic */ Headless$$ExternalSyntheticLambda0(int i) {
        this.$r8$classId = i;
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(Object obj, Object obj2) {
        int i;
        switch (this.$r8$classId) {
            case 0:
                Scenes.Target tv = (Scenes.Target) obj;
                boolean booleanValue = ((Boolean) obj2).booleanValue();
                Intrinsics.checkNotNullParameter(tv, "tv");
                if (booleanValue && (tv instanceof Scenes.Shell)) {
                    Scenes.Shell shell = (Scenes.Shell) tv;
                    if (!StringsKt.contains((CharSequence) shell.sh.invoke("dumpsys power | grep -m1 mWakefulness="), "Asleep", false)) {
                        i = 223;
                    } else {
                        i = 224;
                    }
                    shell.key(i);
                } else {
                    tv.key(26);
                }
                return null;
            case 1:
                MainActivity act = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act, "$this$act");
                if (!act.needsAdb$android_release()) {
                    Managing.open$default(act.getManaging$android_release(), act.host, null, "fromRemote(notifyDialog)", 2);
                }
                return Unit.INSTANCE;
            case 2:
                MainActivity act2 = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act2, "$this$act");
                if (act2.drawing) {
                    Air.stopDrawing(act2);
                } else {
                    Air.startDrawing(act2);
                }
                return Unit.INSTANCE;
            case 3:
                MainActivity act3 = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act3, "$this$act");
                Fleet.askText(act3, Fleet.T("remote.link", new Pair[0]), "https://youtu.be/...", Fleet.T("apps.open", new Pair[0]), "", new MainActivity$$ExternalSyntheticLambda10(act3, 14));
                return Unit.INSTANCE;
            case 4:
                MainActivity act4 = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act4, "$this$act");
                Intent intent = new Intent("android.provider.action.PICK_IMAGES");
                int i2 = Build.VERSION.SDK_INT;
                int i3 = act4.PICK_CAST;
                if (i2 >= 33 || intent.resolveActivity(act4.getPackageManager()) != null) {
                    try {
                        act4.startActivityForResult(intent, i3);
                    } catch (Exception unused) {
                    }
                    return Unit.INSTANCE;
                }
                Intent intent2 = new Intent("androidx.activity.result.contract.action.PICK_IMAGES");
                if (intent2.resolveActivity(act4.getPackageManager()) != null) {
                    try {
                        act4.startActivityForResult(intent2, i3);
                    } catch (Exception unused2) {
                    }
                    return Unit.INSTANCE;
                }
                Fleet.pickFile(act4, new String[]{"image/*", "video/*"});
                return Unit.INSTANCE;
            case 5:
                MainActivity act5 = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act5, "$this$act");
                Fleet.pickFile(act5, new String[]{"audio/*", "video/*", "image/*"});
                return Unit.INSTANCE;
            case 6:
                MainActivity act6 = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act6, "$this$act");
                try {
                    act6.startActivity(new Intent("android.settings.CAST_SETTINGS"));
                } catch (Exception unused3) {
                    Fleet.say(act6, Fleet.T("phone_remote.this_phone_has_no", new Pair[0]), true);
                }
                return Unit.INSTANCE;
            case 7:
                MainActivity act7 = (MainActivity) obj;
                String str = (String) obj2;
                Intrinsics.checkNotNullParameter(act7, "$this$act");
                if (str == null) {
                    str = "";
                }
                Fleet.openLink(act7, "https://play.google.com/store/apps/details?id=".concat(str));
                return Unit.INSTANCE;
            case 8:
                MainActivity act8 = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act8, "$this$act");
                MathKt.rules(act8, new JSONObject().put("do", "sleep_add").put("minutes", 15), new MainActivity$$ExternalSyntheticLambda10(act8, 18));
                return Unit.INSTANCE;
            default:
                MainActivity act9 = (MainActivity) obj;
                Intrinsics.checkNotNullParameter(act9, "$this$act");
                MathKt.setTimer(0, act9);
                return Unit.INSTANCE;
        }
    }
}
