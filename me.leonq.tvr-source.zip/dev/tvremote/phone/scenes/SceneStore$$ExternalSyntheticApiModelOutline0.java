package dev.tvremote.phone.scenes;

import android.content.Context;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;

/* loaded from: classes.dex */
public abstract /* synthetic */ class SceneStore$$ExternalSyntheticApiModelOutline0 {
    public static /* synthetic */ ShortcutInfo.Builder m(Context context, String str) {
        return new ShortcutInfo.Builder(context, str);
    }

    public static /* bridge */ /* synthetic */ ShortcutManager m(Object obj) {
        return (ShortcutManager) obj;
    }

    public static /* bridge */ /* synthetic */ Class m() {
        return ShortcutManager.class;
    }

    /* renamed from: m, reason: collision with other method in class */
    public static /* synthetic */ void m19m() {
    }
}
