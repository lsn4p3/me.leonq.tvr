package dev.tvremote.phone;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import dev.tvremote.core.Caps$$ExternalSyntheticApiModelOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.ontv.Home$$ExternalSyntheticLambda6;
import dev.tvremote.guard.Guard$$ExternalSyntheticApiModelOutline0;
import dev.tvremote.phone.WorkService;
import dev.tvremote.phone.media.PlayingBar$$ExternalSyntheticLambda5;
import dev.tvremote.phone.ui.UiKt;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import org.conscrypt.R;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class ListenService extends Service {
    public static final WorkService.Companion Companion = new Object();
    public static volatile PlayingBar$$ExternalSyntheticLambda5 control = null;
    public static volatile ListenService current = null;
    public static String last = "";
    public static String shown;
    public static boolean stopAsked;
    public static boolean up;
    public MediaSession session;
    public boolean started;
    public WifiManager.WifiLock wifi;

    public static final Notification.Action show$button(ListenService listenService, int i, String str, String str2, int i2) {
        Icon createWithResource;
        PendingIntent service = PendingIntent.getService(listenService, i2, new Intent(listenService, (Class<?>) ListenService.class).setAction(str2), 201326592);
        if (Build.VERSION.SDK_INT >= 23) {
            createWithResource = Icon.createWithResource(listenService, i);
            Notification.Action build = Caps$$ExternalSyntheticApiModelOutline0.m(createWithResource, str, service).build();
            Intrinsics.checkNotNullExpressionValue(build, "build(...)");
            return build;
        }
        Notification.Action build2 = new Notification.Action.Builder(i, str, service).build();
        Intrinsics.checkNotNullExpressionValue(build2, "build(...)");
        return build2;
    }

    public final void act(String str) {
        PlayingBar$$ExternalSyntheticLambda5 playingBar$$ExternalSyntheticLambda5 = control;
        if (playingBar$$ExternalSyntheticLambda5 != null) {
            playingBar$$ExternalSyntheticLambda5.invoke(str);
        } else if (str.equals("dev.tvremote.phone.STOP_LISTEN")) {
            stopSelf();
        }
    }

    @Override // android.app.Service
    public final IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public final void onCreate() {
        int i;
        super.onCreate();
        UiKt.loadLang(this);
        MathKt.reachAroundVpn(this);
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 26) {
            Object systemService = getSystemService("notification");
            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.app.NotificationManager");
            Guard$$ExternalSyntheticApiModelOutline0.m18m();
            ((NotificationManager) systemService).createNotificationChannel(Guard$$ExternalSyntheticApiModelOutline0.m(Fleet.T("listen_service.tv_sound", new Pair[0])));
        }
        MediaSession mediaSession = new MediaSession(this, "tvremote-listen");
        mediaSession.setCallback(new MediaSession.Callback() { // from class: dev.tvremote.phone.ListenService$onCreate$1$1
            @Override // android.media.session.MediaSession.Callback
            public final void onCustomAction(String action, Bundle bundle) {
                Intrinsics.checkNotNullParameter(action, "action");
                WorkService.Companion companion = ListenService.Companion;
                ListenService.this.act(action);
            }

            @Override // android.media.session.MediaSession.Callback
            public final void onPause() {
                WorkService.Companion companion = ListenService.Companion;
                ListenService.this.act("pause");
            }

            @Override // android.media.session.MediaSession.Callback
            public final void onPlay() {
                WorkService.Companion companion = ListenService.Companion;
                ListenService.this.act("play");
            }

            @Override // android.media.session.MediaSession.Callback
            public final void onSkipToNext() {
                WorkService.Companion companion = ListenService.Companion;
                ListenService.this.act("next");
            }

            @Override // android.media.session.MediaSession.Callback
            public final void onSkipToPrevious() {
                WorkService.Companion companion = ListenService.Companion;
                ListenService.this.act("prev");
            }

            @Override // android.media.session.MediaSession.Callback
            public final void onStop() {
                WorkService.Companion companion = ListenService.Companion;
                ListenService.this.act("dev.tvremote.phone.STOP_LISTEN");
            }
        });
        mediaSession.setActive(true);
        this.session = mediaSession;
        current = this;
        shown = null;
        show(last, null);
        synchronized (Companion) {
            up = true;
            if (stopAsked) {
                stopAsked = false;
                stopSelf();
            }
        }
        Object systemService2 = getApplicationContext().getSystemService("wifi");
        Intrinsics.checkNotNull(systemService2, "null cannot be cast to non-null type android.net.wifi.WifiManager");
        WifiManager wifiManager = (WifiManager) systemService2;
        if (i2 >= 29) {
            i = 4;
        } else {
            i = 3;
        }
        WifiManager.WifiLock createWifiLock = wifiManager.createWifiLock(i, "tvremote:listen");
        createWifiLock.setReferenceCounted(false);
        createWifiLock.acquire();
        this.wifi = createWifiLock;
    }

    @Override // android.app.Service
    public final void onDestroy() {
        synchronized (Companion) {
            up = false;
        }
        if (current == this) {
            current = null;
        }
        MediaSession mediaSession = this.session;
        if (mediaSession != null) {
            mediaSession.setActive(false);
            mediaSession.release();
        }
        WifiManager.WifiLock wifiLock = this.wifi;
        if (wifiLock != null) {
            wifiLock.release();
        }
        super.onDestroy();
    }

    @Override // android.app.Service
    public final int onStartCommand(Intent intent, int i, int i2) {
        String action;
        if (intent != null && (action = intent.getAction()) != null) {
            act(action);
            return 2;
        }
        return 2;
    }

    public final void show(String str, JSONObject jSONObject) {
        String str2;
        long j;
        long j2;
        int i;
        String str3;
        long j3;
        float f;
        Notification.Builder builder;
        int i2;
        int[] iArr;
        String T;
        String str4;
        int i3;
        MediaSession mediaSession = this.session;
        if (mediaSession == null) {
            return;
        }
        Home$$ExternalSyntheticLambda6 home$$ExternalSyntheticLambda6 = new Home$$ExternalSyntheticLambda6(jSONObject, 5);
        if (jSONObject == null || (str2 = jSONObject.optString("state", "none")) == null) {
            str2 = "none";
        }
        boolean equals = str2.equals("none");
        CharSequence charSequence = (CharSequence) home$$ExternalSyntheticLambda6.invoke("title");
        if (charSequence.length() == 0) {
            charSequence = (String) home$$ExternalSyntheticLambda6.invoke("app");
        }
        if (charSequence.length() == 0) {
            charSequence = Fleet.T("listen_service.tv_sound_2", new Pair[0]);
        }
        String str5 = (String) charSequence;
        Object invoke = home$$ExternalSyntheticLambda6.invoke("sub");
        Object invoke2 = home$$ExternalSyntheticLambda6.invoke("title");
        Intrinsics.checkNotNullExpressionValue(invoke2, "invoke(...)");
        if (((CharSequence) invoke2).length() <= 0) {
            invoke = null;
        }
        String str6 = (String) invoke;
        if (str6 == null) {
            str6 = "";
        }
        List asList = ArraysKt.asList(new String[]{str6, str});
        ArrayList arrayList = new ArrayList();
        for (Object obj : asList) {
            if (((String) obj).length() > 0) {
                arrayList.add(obj);
            }
        }
        String joinToString$default = CollectionsKt.joinToString$default(arrayList, " · ", null, null, null, 62);
        if (jSONObject != null) {
            j = jSONObject.optLong("dur");
        } else {
            j = 0;
        }
        MediaMetadata.Builder putString = new MediaMetadata.Builder().putString("android.media.metadata.TITLE", str5).putString("android.media.metadata.ARTIST", joinToString$default);
        if (j > 0) {
            putString.putLong("android.media.metadata.DURATION", j);
        }
        mediaSession.setMetadata(putString.build());
        boolean equals2 = str2.equals("paused");
        PlaybackState.Builder builder2 = new PlaybackState.Builder();
        if (!equals) {
            j2 = 566;
        } else {
            j2 = 0;
        }
        PlaybackState.Builder addCustomAction = builder2.setActions(j2 | 1).addCustomAction(new PlaybackState.CustomAction.Builder("dev.tvremote.phone.STOP_LISTEN", Fleet.T("listen_service.stop_listening", new Pair[0]), R.drawable.ic_close).build());
        if (equals2) {
            i = 2;
        } else {
            i = 3;
        }
        if (jSONObject != null) {
            str3 = "listen_service.stop_listening";
            j3 = jSONObject.optLong("pos");
        } else {
            str3 = "listen_service.stop_listening";
            j3 = 0;
        }
        if (!equals2 && !equals) {
            Intrinsics.checkNotNull(jSONObject);
            f = (float) jSONObject.optDouble("speed", 1.0d);
        } else {
            f = 0.0f;
        }
        mediaSession.setPlaybackState(addCustomAction.setState(i, j3, f).build());
        PendingIntent activity = PendingIntent.getActivity(this, 1, new Intent(this, (Class<?>) MainActivity.class).addFlags(536870912), 201326592);
        int i4 = Build.VERSION.SDK_INT;
        if (i4 >= 26) {
            builder = Guard$$ExternalSyntheticApiModelOutline0.m(this);
        } else {
            builder = new Notification.Builder(this);
        }
        Notification.Builder contentTitle = builder.setSmallIcon(R.drawable.ic_headphones).setContentTitle(str5);
        if (joinToString$default.length() == 0) {
            i2 = 0;
            joinToString$default = Fleet.T("listen_service.listening_to_the_tv", new Pair[0]);
        } else {
            i2 = 0;
        }
        contentTitle.setContentText(joinToString$default).setContentIntent(activity).setOngoing(true).setVisibility(1);
        if (!equals) {
            builder.addAction(show$button(this, R.drawable.ic_prev, Fleet.T("remote.previous", new Pair[i2]), "prev", 3));
            if (equals2) {
                T = Fleet.T("listen_service.play", new Pair[i2]);
                str4 = "play";
                i3 = R.drawable.ic_play;
            } else {
                T = Fleet.T("listen_service.pause", new Pair[i2]);
                str4 = "pause";
                i3 = R.drawable.ic_pause;
            }
            builder.addAction(show$button(this, i3, T, str4, 4));
            builder.addAction(show$button(this, R.drawable.ic_next, Fleet.T("remote.next", new Pair[i2]), "next", 5));
            builder.addAction(show$button(this, R.drawable.ic_close, Fleet.T(str3, new Pair[i2]), "dev.tvremote.phone.STOP_LISTEN", 2));
            iArr = new int[2];
            iArr[i2] = 1;
            iArr[1] = 3;
        } else {
            builder.addAction(show$button(this, R.drawable.ic_close, Fleet.T(str3, new Pair[i2]), "dev.tvremote.phone.STOP_LISTEN", 2));
            iArr = new int[1];
            iArr[i2] = i2;
        }
        builder.setStyle(new Notification.MediaStyle().setMediaSession(mediaSession.getSessionToken()).setShowActionsInCompactView(Arrays.copyOf(iArr, iArr.length)));
        Notification build = builder.build();
        Intrinsics.checkNotNullExpressionValue(build, "build(...)");
        if (!this.started) {
            this.started = true;
            if (i4 >= 29) {
                startForeground(4, build, 2);
                return;
            } else {
                startForeground(4, build);
                return;
            }
        }
        Object systemService = getSystemService("notification");
        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.app.NotificationManager");
        ((NotificationManager) systemService).notify(4, build);
    }
}
