package dev.tvremote.phone;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import dev.tvremote.core.Fleet;
import kotlin.jvm.internal.Intrinsics;
import org.conscrypt.R;

/* loaded from: classes.dex */
public final class RemoteWidget extends AppWidgetProvider {
    public static final int[] SCENES = {R.id.w_scene1, R.id.w_scene2, R.id.w_scene3};

    @Override // android.appwidget.AppWidgetProvider
    public final void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        Intrinsics.checkNotNullParameter(c, "c");
        Intrinsics.checkNotNullParameter(m, "m");
        Intrinsics.checkNotNullParameter(ids, "ids");
        Fleet.paint(c, m, ids);
    }
}
