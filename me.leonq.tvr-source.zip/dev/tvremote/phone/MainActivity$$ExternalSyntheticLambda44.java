package dev.tvremote.phone;

import android.view.KeyEvent;
import dev.tvremote.phone.picture.MiniPlayer;
import dev.tvremote.phone.picture.PipKt;
import dev.tvremote.phone.picture.VideoFrame;

/* loaded from: classes.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda44 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ KeyEvent.Callback f$0;
    public final /* synthetic */ int f$1;
    public final /* synthetic */ int f$2;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda44(KeyEvent.Callback callback, int i, int i2, int i3) {
        this.$r8$classId = i3;
        this.f$0 = callback;
        this.f$1 = i;
        this.f$2 = i2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.$r8$classId) {
            case 0:
                MainActivity mainActivity = (MainActivity) this.f$0;
                int i = this.f$1;
                mainActivity.vidW = i;
                int i2 = this.f$2;
                mainActivity.vidH = i2;
                VideoFrame frame$android_release = mainActivity.getFrame$android_release();
                if (i > 0 && i2 > 0) {
                    frame$android_release.vw = i;
                    frame$android_release.vh = i2;
                    frame$android_release.requestLayout();
                }
                PipKt.pipUpdate(mainActivity);
                return;
            default:
                MiniPlayer miniPlayer = (MiniPlayer) this.f$0;
                miniPlayer.setTranslationX(((miniPlayer.getWidth() - this.f$1) / 2.0f) + miniPlayer.getTranslationX());
                miniPlayer.setTranslationY(((miniPlayer.getHeight() - this.f$2) / 2.0f) + miniPlayer.getTranslationY());
                miniPlayer.keepIn(false);
                return;
        }
    }
}
