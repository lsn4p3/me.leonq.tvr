package dev.tvremote.phone;

import android.R;
import android.app.Activity;
import android.app.Dialog;
import android.app.PictureInPictureParams;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.os.VibrationAttributes;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import com.android.apksig.internal.apk.ApkSigningBlockUtils$$ExternalSyntheticLambda0;
import dev.tvremote.core.Census;
import dev.tvremote.core.Census$$ExternalSyntheticLambda4;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Downloader;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.SupportAndroid$store$1;
import dev.tvremote.core.SupportRelay;
import dev.tvremote.core.WireLog;
import dev.tvremote.core.Words;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.Adb$$ExternalSyntheticLambda4;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.adb.TvShell;
import dev.tvremote.core.manage.Manage;
import dev.tvremote.core.ontv.Bloat$$ExternalSyntheticLambda0;
import dev.tvremote.core.ontv.Draw;
import dev.tvremote.core.ontv.RulesClient;
import dev.tvremote.core.ontv.Setup$$ExternalSyntheticLambda5;
import dev.tvremote.core.ontv.Tailscale;
import dev.tvremote.core.ontv.Welcome;
import dev.tvremote.core.picture.LiveGate;
import dev.tvremote.core.picture.SoundPace;
import dev.tvremote.core.picture.SurfaceScreen;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.core.remote.Vidaa$$ExternalSyntheticLambda6;
import dev.tvremote.core.scenes.Phrases;
import dev.tvremote.core.scenes.Voice;
import dev.tvremote.core.scenes.VoicePhrases;
import dev.tvremote.core.web.HttpServer;
import dev.tvremote.guard.Guard;
import dev.tvremote.guard.Guard$$ExternalSyntheticApiModelOutline0;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda3;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda5;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda8;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda9;
import dev.tvremote.guard.Guard$install$r$1;
import dev.tvremote.home.HomeQr$$ExternalSyntheticLambda0;
import dev.tvremote.i18n.Langs;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.WorkService;
import dev.tvremote.phone.ir.IrProfile;
import dev.tvremote.phone.ir.IrRemoteKt;
import dev.tvremote.phone.ir.IrState;
import dev.tvremote.phone.manage.Managing;
import dev.tvremote.phone.manage.Managing$$ExternalSyntheticLambda1;
import dev.tvremote.phone.manage.PhoneSupport;
import dev.tvremote.phone.manage.UpdaterKt;
import dev.tvremote.phone.manage.UpdaterKt$$ExternalSyntheticLambda6;
import dev.tvremote.phone.media.NowApp;
import dev.tvremote.phone.media.NowApp$tick$1;
import dev.tvremote.phone.media.PlayingBar;
import dev.tvremote.phone.media.PlayingBar$$ExternalSyntheticLambda13;
import dev.tvremote.phone.media.Talk;
import dev.tvremote.phone.media.Talk$$ExternalSyntheticLambda4;
import dev.tvremote.phone.media.TalkKt$$ExternalSyntheticLambda1;
import dev.tvremote.phone.media.TalkKt$$ExternalSyntheticLambda4;
import dev.tvremote.phone.picker.ManyTvsKt;
import dev.tvremote.phone.picker.ManyTvsKt$$ExternalSyntheticLambda36;
import dev.tvremote.phone.picker.PickerScreenKt;
import dev.tvremote.phone.picker.PickerScreenKt$$ExternalSyntheticLambda11;
import dev.tvremote.phone.picker.PickerScreenKt$watchNetworks$cb$1;
import dev.tvremote.phone.picker.TvStatus;
import dev.tvremote.phone.picker.TvStatusKt;
import dev.tvremote.phone.picture.Air;
import dev.tvremote.phone.picture.DrawView;
import dev.tvremote.phone.picture.DrawingKt$$ExternalSyntheticLambda0;
import dev.tvremote.phone.picture.MiniPlayer;
import dev.tvremote.phone.picture.PipKt;
import dev.tvremote.phone.picture.VideoFrame;
import dev.tvremote.phone.remote.KbdWatch;
import dev.tvremote.phone.remote.PhoneRemoteKt;
import dev.tvremote.phone.remote.TapMark;
import dev.tvremote.phone.remote.TypingKt;
import dev.tvremote.phone.ui.IconButton;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.phone.ui.StatusText;
import dev.tvremote.phone.ui.UiKt;
import dev.tvremote.update.Release;
import dev.tvremote.update.SignedList;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.Pair;
import kotlin.SynchronizedLazyImpl;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyList;
import kotlin.collections.EmptyMap;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgressionIterator;
import kotlin.ranges.IntRange;
import kotlin.text.Charsets;
import kotlin.text.Regex;
import kotlin.text.Regex$$ExternalSyntheticLambda0;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class MainActivity extends Activity implements Tv.Listener, SurfaceHolder.Callback {
    public static final /* synthetic */ int $r8$clinit = 0;
    public View about;
    public IconButton airBtn;
    public Dialog allowBox;
    public String appNamesFor;
    public long awaySince;
    public Remote basic;
    public Button basicBar;
    public boolean bgListen;
    public TextView boostBtn;
    public volatile Pair castOf;
    public LinearLayout controls;
    public final MainActivity$workTick$1 countWatchers;
    public LinearLayout drawBar;
    public IconButton drawBtn;
    public boolean drawBusy;
    public int drawId;
    public DrawView drawView;
    public final Draw drawer;
    public boolean drawing;
    public String entry;
    public TextView evenBtn;
    public IconButton exitBtn;
    public Button fleetBtn;
    public int floatMode;
    public boolean floating;
    public boolean foreground;
    public LinearLayout foundList;
    public VideoFrame frame;
    public IconButton fullBtn;
    public boolean fullscreen;
    public String host;
    public TextView hqBtn;
    public final MainActivity$$ExternalSyntheticLambda15 idleStop;
    public EditText ipBox;
    public FrameLayout irHost;
    public KbdWatch kbdWatch;
    public boolean keysAway;
    public boolean listen;
    public IconButton listenBtn;
    public TextView listenChip;
    public boolean listenShare;
    public boolean listenTvLoud;
    public boolean live;
    public IconButton liveBtn;
    public Managing managing;
    public MiniPlayer mini;
    public PickerScreenKt$watchNetworks$cb$1 netWatch;
    public NowApp nowApp;
    public String pendingAsk;
    public volatile Tv pic;
    public LinearLayout picBar;
    public long picLiveAt;
    public boolean picShown;
    public int picTries;
    public int picWatchers;
    public LinearLayout picker;
    public TextView pickerMsg;
    public IconButton pipBtn;
    public Guard$install$r$1 pipRx;
    public PlayingBar playing;
    public SharedPreferences prefs;
    public final MainActivity$$ExternalSyntheticLambda15 probe;
    public TextView qualBtn;
    public boolean quiet;
    public final MainActivity$$ExternalSyntheticLambda15 quietUpdate;
    public LinearLayout remote;
    public int retries;
    public final MainActivity$$ExternalSyntheticLambda15 retry;
    public LinearLayout savedList;
    public Button scanBtn;
    public Button screensBtn;
    public View settings;
    public Button setupBar;
    public IconButton setupClose;
    public LinearLayout setupRow;
    public Intent shared;
    public IconButton shotBtn;
    public volatile Tv sound;
    public LinearLayout soundBar;
    public int soundTries;
    public FrameLayout stage;
    public StatusText status;
    public long stickAt;
    public Integer stickKey;
    public long stickLast;
    public SurfaceView surface;
    public boolean surfaceReady;
    public final SynchronizedLazyImpl talk$delegate;
    public TapMark tapMark;
    public EditText textBox;
    public LinearLayout topBar;
    public volatile Tv tv;
    public Release update;
    public Release updateAfterAllow;
    public Button updateBtn;
    public TextView updateNote;
    public boolean updating;
    public final SynchronizedLazyImpl vibrator$delegate;
    public boolean video;
    public IconButton videoBtn;
    public long voicePinsAt;
    public TextView waitName;
    public TextView waitStep;
    public FrameLayout waiting;
    public boolean wakeNext;
    public boolean waking;
    public boolean wasCovered;
    public boolean wasLive;
    public boolean wasPip;
    public boolean workOn;
    public final MainActivity$workTick$1 workTick;
    public final Handler ui = new Handler(Looper.getMainLooper());
    public Map appNames = EmptyMap.INSTANCE;
    public Object voicePins = EmptyList.INSTANCE;
    public final HashMap route = new HashMap();
    public final HashMap savedRows = new HashMap();
    public final HashMap reach = new HashMap();
    public final HashSet trying = new HashSet();
    public final HashMap awayFrom = new HashMap();
    public int vidW = 16;
    public int vidH = 9;
    public final ExecutorService drawIo = Executors.newSingleThreadExecutor();
    public final ArrayList drawQ = new ArrayList();
    public int drawColor = Air.DRAW_COLORS[0];
    public int drawWidth = 60;
    public Function1 kbdOpen = new HomeQr$$ExternalSyntheticLambda0(21);
    public Function0 askBox = new Census$$ExternalSyntheticLambda4(14);
    public String onTv = "";
    public final HashSet adbFailed = new HashSet();
    public final Pair[] HOMES = {new Pair("Projectivy Launcher", "com.spocky.projengmenu"), new Pair("ATV Launcher", "ca.dstudio.atvlauncher.free"), new Pair("FLauncher", "me.efesser.flauncher")};
    public final AtomicBoolean tvBusy = new AtomicBoolean(false);
    public final int PICK_CAST = 71;
    public final int PICK_DRAW = 73;
    public final int PICK_FLEET_WELCOME = 74;
    public final int PICK_FLEET = 72;
    public final int PICK_IR_SAVE = 75;
    public final int PICK_IR_OPEN = 76;
    public final HashMap setupChecked = new HashMap();
    public final HashMap setupNews = new HashMap();
    public final MainActivity$$ExternalSyntheticLambda15 picAway = new MainActivity$$ExternalSyntheticLambda15(this, 4);
    public final MainActivity$$ExternalSyntheticLambda15 picRetry = new MainActivity$$ExternalSyntheticLambda15(this, 5);
    public final MainActivity$onCreate$2 picListener = new MainActivity$onCreate$2(this);
    public String workWhat = "";
    public int workPct = -2;

    /* JADX WARN: Type inference failed for: r0v3, types: [dev.tvremote.phone.MainActivity$workTick$1] */
    /* JADX WARN: Type inference failed for: r0v6, types: [dev.tvremote.phone.MainActivity$workTick$1] */
    public MainActivity() {
        int i = 3;
        final int i2 = 1;
        final int i3 = 0;
        this.retry = new MainActivity$$ExternalSyntheticLambda15(this, i3);
        int i4 = 2;
        this.talk$delegate = new SynchronizedLazyImpl(new TalkKt$$ExternalSyntheticLambda1(this, i4));
        this.probe = new MainActivity$$ExternalSyntheticLambda15(this, i2);
        this.drawer = new Draw(new TalkKt$$ExternalSyntheticLambda1(this, i));
        this.quietUpdate = new MainActivity$$ExternalSyntheticLambda15(this, i4);
        this.idleStop = new MainActivity$$ExternalSyntheticLambda15(this, i);
        this.countWatchers = new Runnable(this) { // from class: dev.tvremote.phone.MainActivity$workTick$1
            public final /* synthetic */ MainActivity this$0;

            {
                this.this$0 = this;
            }

            @Override // java.lang.Runnable
            public final void run() {
                switch (i2) {
                    case 0:
                        MainActivity mainActivity = this.this$0;
                        if (mainActivity.workOn) {
                            int progress = mainActivity.getManaging$android_release().progress();
                            if (progress != mainActivity.workPct) {
                                mainActivity.workPct = progress;
                                WorkService.Companion companion = WorkService.Companion;
                                WorkService.Companion.show(mainActivity, mainActivity.workWhat, progress);
                            }
                            mainActivity.ui.postDelayed(this, 1000L);
                            return;
                        }
                        return;
                    default:
                        Tv tv = this.this$0.tv;
                        if (this.this$0.pic != null && tv != null && tv.ready()) {
                            new Thread(new MainActivity$$ExternalSyntheticLambda38(tv, this.this$0, 1)).start();
                            this.this$0.ui.postDelayed(this, 10000L);
                            return;
                        }
                        return;
                }
            }
        };
        this.workTick = new Runnable(this) { // from class: dev.tvremote.phone.MainActivity$workTick$1
            public final /* synthetic */ MainActivity this$0;

            {
                this.this$0 = this;
            }

            @Override // java.lang.Runnable
            public final void run() {
                switch (i3) {
                    case 0:
                        MainActivity mainActivity = this.this$0;
                        if (mainActivity.workOn) {
                            int progress = mainActivity.getManaging$android_release().progress();
                            if (progress != mainActivity.workPct) {
                                mainActivity.workPct = progress;
                                WorkService.Companion companion = WorkService.Companion;
                                WorkService.Companion.show(mainActivity, mainActivity.workWhat, progress);
                            }
                            mainActivity.ui.postDelayed(this, 1000L);
                            return;
                        }
                        return;
                    default:
                        Tv tv = this.this$0.tv;
                        if (this.this$0.pic != null && tv != null && tv.ready()) {
                            new Thread(new MainActivity$$ExternalSyntheticLambda38(tv, this.this$0, 1)).start();
                            this.this$0.ui.postDelayed(this, 10000L);
                            return;
                        }
                        return;
                }
            }
        };
        this.vibrator$delegate = new SynchronizedLazyImpl(new TalkKt$$ExternalSyntheticLambda1(this, i2));
    }

    public final void allowAlert$android_release(boolean z) {
        String str;
        int i;
        int i2 = 1;
        if (!z) {
            Dialog dialog = this.allowBox;
            if (dialog != null) {
                dialog.dismiss();
            }
            this.allowBox = null;
            return;
        }
        if (this.allowBox == null && !isFinishing()) {
            Dialog dialog2 = new Dialog(this, R.style.Theme.Black.NoTitleBar);
            LinearLayout linearLayout = new LinearLayout(this);
            linearLayout.setOrientation(1);
            linearLayout.setGravity(17);
            linearLayout.setBackgroundColor(UiKt.BG);
            float f = 28;
            linearLayout.setPadding(UiKt.dp(this, f), UiKt.dp(this, f), UiKt.dp(this, f), UiKt.dp(this, f));
            ApkSigningBlockUtils$$ExternalSyntheticLambda0 apkSigningBlockUtils$$ExternalSyntheticLambda0 = new ApkSigningBlockUtils$$ExternalSyntheticLambda0(linearLayout, this);
            Float valueOf = Float.valueOf(64.0f);
            Integer valueOf2 = Integer.valueOf(UiKt.TEXT);
            Boolean bool = Boolean.FALSE;
            apkSigningBlockUtils$$ExternalSyntheticLambda0.invoke("📺", valueOf, valueOf2, bool, 0);
            String T = Fleet.T("allow.look_at_the_tv", new Pair[0]);
            Float valueOf3 = Float.valueOf(30.0f);
            Integer valueOf4 = Integer.valueOf(UiKt.TEXT);
            Boolean bool2 = Boolean.TRUE;
            apkSigningBlockUtils$$ExternalSyntheticLambda0.invoke(T, valueOf3, valueOf4, bool2, 8);
            apkSigningBlockUtils$$ExternalSyntheticLambda0.invoke(Fleet.T("allow.the_tv_is_asking", new Pair[0]), Float.valueOf(18.0f), Integer.valueOf(UiKt.MUTED), bool, 10);
            apkSigningBlockUtils$$ExternalSyntheticLambda0.invoke(Fleet.T("phone.1_tick_always_allow", new Pair[0]), Float.valueOf(20.0f), Integer.valueOf(UiKt.TEXT), bool2, 26);
            try {
                File filesDir = getFilesDir();
                Intrinsics.checkNotNullExpressionValue(filesDir, "getFilesDir(...)");
                str = new Adb(filesDir).fingerprint();
            } catch (Exception unused) {
                str = "";
            }
            if (str.length() > 0) {
                apkSigningBlockUtils$$ExternalSyntheticLambda0.invoke(Fleet.T("phone.the_code_on_the", new Pair("fp", str)), Float.valueOf(13.0f), Integer.valueOf(UiKt.MUTED), Boolean.FALSE, 18);
            }
            TextView textView = new TextView(this);
            textView.setTextSize(15.0f);
            textView.setTextColor(UiKt.ACCENT_TEXT);
            textView.setGravity(17);
            textView.setVisibility(8);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
            layoutParams.topMargin = UiKt.dp(this, 18);
            linearLayout.addView(textView, layoutParams);
            apkSigningBlockUtils$$ExternalSyntheticLambda0.invoke(Fleet.T("phone.this_screen_closes_by", new Pair[0]), Float.valueOf(15.0f), Integer.valueOf(UiKt.MUTED), Boolean.FALSE, 26);
            String str2 = this.host;
            try {
                if (str2 != null) {
                    String str3 = this.entry;
                    if (str3 == null) {
                        str3 = str2;
                    }
                    String pref$android_release = pref$android_release("tvs:".concat(str3));
                    if (str.length() != 0 && pref$android_release.length() != 0) {
                        textView.setVisibility(0);
                        textView.setText(Fleet.T("phone.tv_setup_on_the", new Pair[0]));
                        i = -1;
                        new Thread(new TalkKt$$ExternalSyntheticLambda4(str2, pref$android_release, str, this, str3, textView)).start();
                        Button button = UiKt.button(this, Fleet.T("common.later", new Pair[0]), UiKt.CARD);
                        button.setOnClickListener(new Guard$$ExternalSyntheticLambda8(i2, dialog2));
                        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(i, UiKt.dp(this, 54));
                        layoutParams2.topMargin = UiKt.dp(this, 30);
                        linearLayout.addView(button, layoutParams2);
                        dialog2.setContentView(linearLayout);
                        this.allowBox = dialog2;
                        dialog2.show();
                        return;
                    }
                }
                dialog2.show();
                return;
            } catch (Exception unused2) {
                this.allowBox = null;
                return;
            }
            i = -1;
            Button button2 = UiKt.button(this, Fleet.T("common.later", new Pair[0]), UiKt.CARD);
            button2.setOnClickListener(new Guard$$ExternalSyntheticLambda8(i2, dialog2));
            LinearLayout.LayoutParams layoutParams22 = new LinearLayout.LayoutParams(i, UiKt.dp(this, 54));
            layoutParams22.topMargin = UiKt.dp(this, 30);
            linearLayout.addView(button2, layoutParams22);
            dialog2.setContentView(linearLayout);
            this.allowBox = dialog2;
        }
    }

    public final void ask$android_release(String sentence) {
        int i = 1;
        Intrinsics.checkNotNullParameter(sentence, "sentence");
        Tv tv = this.tv;
        Remote remote = this.basic;
        if (remote != null) {
            if (!remote.search(sentence)) {
                TvShell tvShell = TvShell.INSTANCE;
                remote.launch(TvShell.youtube(sentence));
            }
            searched$android_release(sentence, "yt");
            return;
        }
        if (tv != null && tv.ready()) {
            new Thread(new MainActivity$$ExternalSyntheticLambda9(tv, sentence, this, i)).start();
        } else {
            this.pendingAsk = sentence;
            Toast.makeText(this, Fleet.T("phone.waiting_for_the_tv_2", new Pair("sentence", sentence)), 0).show();
        }
    }

    public final void askBackground() {
        boolean isIgnoringBatteryOptimizations;
        if (Build.VERSION.SDK_INT >= 23 && pref$android_release("bgAsked").length() <= 0) {
            Object systemService = getSystemService("power");
            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.os.PowerManager");
            isIgnoringBatteryOptimizations = ((PowerManager) systemService).isIgnoringBatteryOptimizations(getPackageName());
            if (!isIgnoringBatteryOptimizations) {
                getPrefs$android_release().edit().putString("bgAsked", "1").apply();
                try {
                    startActivity(new Intent("android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS", Uri.parse("package:" + getPackageName())));
                } catch (Exception unused) {
                }
            }
        }
    }

    public final void buzz$android_release() {
        Vibrator vibrator;
        VibrationEffect createPredefined;
        VibrationEffect createPredefined2;
        VibrationAttributes createForUsage;
        if (getPrefs$android_release().getBoolean("buzz", true) && (vibrator = (Vibrator) this.vibrator$delegate.getValue()) != null && vibrator.hasVibrator()) {
            try {
                int i = Build.VERSION.SDK_INT;
                if (i >= 33) {
                    createPredefined2 = VibrationEffect.createPredefined(0);
                    createForUsage = VibrationAttributes.createForUsage(50);
                    vibrator.vibrate(createPredefined2, createForUsage);
                } else if (i >= 29) {
                    createPredefined = VibrationEffect.createPredefined(0);
                    Guard$$ExternalSyntheticApiModelOutline0.m(vibrator, createPredefined);
                } else {
                    if (i >= 26) {
                        Guard$$ExternalSyntheticApiModelOutline0.m(vibrator, Guard$$ExternalSyntheticApiModelOutline0.m16m());
                        return;
                    }
                    vibrator.vibrate(18L);
                }
            } catch (Exception unused) {
            }
        }
    }

    public final void connect$android_release(String ip, String str) {
        String str2;
        Object obj;
        Intrinsics.checkNotNullParameter(ip, "ip");
        if (str == null) {
            String ip2 = StringsKt.trim(ip).toString();
            List list = PickerScreenKt.PER_TV;
            Intrinsics.checkNotNullParameter(ip2, "ip");
            Iterator it = PickerScreenKt.savedIps(this).iterator();
            while (true) {
                if (it.hasNext()) {
                    obj = it.next();
                    String str3 = (String) obj;
                    if (!Intrinsics.areEqual(str3, ip2) && PickerScreenKt.savedTv(this, str3).getAddresses().contains(ip2)) {
                        break;
                    }
                } else {
                    obj = null;
                    break;
                }
            }
            str2 = (String) obj;
        } else {
            str2 = str;
        }
        this.entry = str2;
        this.wasLive = false;
        this.retries = 0;
        String obj2 = StringsKt.trim(ip).toString();
        this.host = obj2;
        if (obj2.length() == 0) {
            return;
        }
        UiKt.hideKeyboard(this);
        if (!TypingKt.kindOf(this, obj2).equals("android")) {
            this.host = null;
            TypingKt.startBasic(this, obj2, false);
            return;
        }
        getStatus$android_release().setText(title$android_release(obj2) + " · " + Fleet.T("page.connecting", new Pair[0]));
        getSurface$android_release().setVisibility(0);
        show$android_release(true);
        if (str == null) {
            str = obj2;
        }
        waitFor$android_release(title$android_release(str), Fleet.T("phone.looking_for_the_tv", new Pair("ip", obj2)));
        startSession$android_release();
    }

    public final boolean covered$android_release() {
        if (this.managing == null || getManaging$android_release().view.getVisibility() != 0) {
            if (this.settings == null || getSettings$android_release().getVisibility() != 0) {
                if (this.about != null && getAbout$android_release().getVisibility() == 0) {
                    return true;
                }
                return false;
            }
            return true;
        }
        return true;
    }

    public final void disconnect$android_release(String str) {
        String str2;
        String str3;
        String str4 = this.host;
        String str5 = this.entry;
        allowAlert$android_release(false);
        this.fullscreen = false;
        setRequestedOrientation(-1);
        TypingKt.clearBox(this);
        getManaging$android_release().close();
        getSetupRow$android_release().setVisibility(8);
        if (this.listen) {
            this.listen = false;
            this.bgListen = false;
            Fleet.listenService(this, false);
            Fleet.stopSound(this);
        }
        stopPicture$android_release();
        Tv tv = this.tv;
        if (tv != null) {
            tv.stop();
        }
        this.tv = null;
        getWaiting$android_release().setVisibility(8);
        getSurface$android_release().setVisibility(8);
        Remote remote = this.basic;
        if (remote != null) {
            remote.close();
        }
        this.basic = null;
        this.host = null;
        this.wasLive = false;
        this.retries = 0;
        this.keysAway = false;
        this.ui.removeCallbacks(this.retry);
        TypingKt.layoutRemote(this);
        show$android_release(false);
        PickerScreenKt.message(this, str, true);
        PickerScreenKt.refreshSaved(this);
        if (str != null && str4 != null) {
            String T = Fleet.T("diagnosing.checking_the_network_and", new Pair[0]);
            PickerScreenKt.message(this, T, false);
            if (str5 == null) {
                str2 = str4;
            } else {
                str2 = str5;
            }
            String kindOf = TypingKt.kindOf(this, str2);
            if (str5 == null) {
                str3 = str4;
            } else {
                str3 = str5;
            }
            new Thread(new ManyTvsKt$$ExternalSyntheticLambda36(str4, kindOf, PickerScreenKt.name(this, str3), str, this, T, str5)).start();
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public final boolean dispatchKeyEvent(KeyEvent e) {
        boolean z;
        int i;
        Integer valueOf;
        int i2;
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        Intrinsics.checkNotNullParameter(e, "e");
        int keyCode = e.getKeyCode();
        boolean z2 = false;
        if (live$android_release() && (e.getSource() & 16778257) != 0 && !(getCurrentFocus() instanceof EditText)) {
            if (this.video && this.tv != null) {
                z = true;
            } else {
                z = false;
            }
            if (keyCode != 96) {
                if (keyCode != 97) {
                    if (keyCode != 99) {
                        if (keyCode != 100) {
                            switch (keyCode) {
                                case 19:
                                case 20:
                                case 21:
                                case 22:
                                    valueOf = Integer.valueOf(keyCode);
                                    break;
                                default:
                                    switch (keyCode) {
                                        case 102:
                                            if (z) {
                                                i5 = keyCode;
                                            } else {
                                                i5 = 25;
                                            }
                                            valueOf = Integer.valueOf(i5);
                                            break;
                                        case 103:
                                            if (z) {
                                                i6 = keyCode;
                                            } else {
                                                i6 = 24;
                                            }
                                            valueOf = Integer.valueOf(i6);
                                            break;
                                        case 104:
                                            valueOf = 167;
                                            break;
                                        case 105:
                                            valueOf = 166;
                                            break;
                                        default:
                                            int i8 = 3;
                                            switch (keyCode) {
                                                case 108:
                                                    if (z) {
                                                        i8 = keyCode;
                                                    }
                                                    valueOf = Integer.valueOf(i8);
                                                    break;
                                                case 109:
                                                    if (z) {
                                                        i7 = keyCode;
                                                    } else {
                                                        i7 = 82;
                                                    }
                                                    valueOf = Integer.valueOf(i7);
                                                    break;
                                                case 110:
                                                    valueOf = 3;
                                                    break;
                                                default:
                                                    valueOf = null;
                                                    break;
                                            }
                                    }
                            }
                        } else {
                            if (z) {
                                i4 = keyCode;
                            } else {
                                i4 = 164;
                            }
                            valueOf = Integer.valueOf(i4);
                        }
                    } else {
                        if (z) {
                            i3 = keyCode;
                        } else {
                            i3 = 85;
                        }
                        valueOf = Integer.valueOf(i3);
                    }
                } else {
                    if (z) {
                        i2 = keyCode;
                    } else {
                        i2 = 4;
                    }
                    valueOf = Integer.valueOf(i2);
                }
            } else {
                if (z) {
                    i = keyCode;
                } else {
                    i = 23;
                }
                valueOf = Integer.valueOf(i);
            }
            if (valueOf != null) {
                if ((19 <= keyCode && keyCode < 23) || keyCode == 102 || keyCode == 103 || keyCode == 104 || keyCode == 105) {
                    z2 = true;
                }
                if (e.getAction() == 0 && (e.getRepeatCount() == 0 || z2)) {
                    press$android_release(true, valueOf.intValue());
                    return true;
                }
                return true;
            }
        }
        if (live$android_release() && !this.listen && getPrefs$android_release().getBoolean("volKeysTv", true) && (keyCode == 24 || keyCode == 25)) {
            if (e.getAction() == 0) {
                press$android_release(false, keyCode);
            }
            return true;
        }
        return super.dispatchKeyEvent(e);
    }

    public final View getAbout$android_release() {
        View view = this.about;
        if (view != null) {
            return view;
        }
        Intrinsics.throwUninitializedPropertyAccessException("about");
        throw null;
    }

    public final LinearLayout getControls$android_release() {
        LinearLayout linearLayout = this.controls;
        if (linearLayout != null) {
            return linearLayout;
        }
        Intrinsics.throwUninitializedPropertyAccessException("controls");
        throw null;
    }

    public final LinearLayout getDrawBar$android_release() {
        LinearLayout linearLayout = this.drawBar;
        if (linearLayout != null) {
            return linearLayout;
        }
        Intrinsics.throwUninitializedPropertyAccessException("drawBar");
        throw null;
    }

    public final DrawView getDrawView$android_release() {
        DrawView drawView = this.drawView;
        if (drawView != null) {
            return drawView;
        }
        Intrinsics.throwUninitializedPropertyAccessException("drawView");
        throw null;
    }

    public final LinearLayout getFoundList$android_release() {
        LinearLayout linearLayout = this.foundList;
        if (linearLayout != null) {
            return linearLayout;
        }
        Intrinsics.throwUninitializedPropertyAccessException("foundList");
        throw null;
    }

    public final VideoFrame getFrame$android_release() {
        VideoFrame videoFrame = this.frame;
        if (videoFrame != null) {
            return videoFrame;
        }
        Intrinsics.throwUninitializedPropertyAccessException("frame");
        throw null;
    }

    public final EditText getIpBox$android_release() {
        EditText editText = this.ipBox;
        if (editText != null) {
            return editText;
        }
        Intrinsics.throwUninitializedPropertyAccessException("ipBox");
        throw null;
    }

    public final FrameLayout getIrHost$android_release() {
        FrameLayout frameLayout = this.irHost;
        if (frameLayout != null) {
            return frameLayout;
        }
        Intrinsics.throwUninitializedPropertyAccessException("irHost");
        throw null;
    }

    public final IconButton getListenBtn$android_release() {
        IconButton iconButton = this.listenBtn;
        if (iconButton != null) {
            return iconButton;
        }
        Intrinsics.throwUninitializedPropertyAccessException("listenBtn");
        throw null;
    }

    public final TextView getListenChip$android_release() {
        TextView textView = this.listenChip;
        if (textView != null) {
            return textView;
        }
        Intrinsics.throwUninitializedPropertyAccessException("listenChip");
        throw null;
    }

    public final IconButton getLiveBtn$android_release() {
        IconButton iconButton = this.liveBtn;
        if (iconButton != null) {
            return iconButton;
        }
        Intrinsics.throwUninitializedPropertyAccessException("liveBtn");
        throw null;
    }

    public final Managing getManaging$android_release() {
        Managing managing = this.managing;
        if (managing != null) {
            return managing;
        }
        Intrinsics.throwUninitializedPropertyAccessException("managing");
        throw null;
    }

    public final MiniPlayer getMini$android_release() {
        MiniPlayer miniPlayer = this.mini;
        if (miniPlayer != null) {
            return miniPlayer;
        }
        Intrinsics.throwUninitializedPropertyAccessException("mini");
        throw null;
    }

    public final LinearLayout getPicBar$android_release() {
        LinearLayout linearLayout = this.picBar;
        if (linearLayout != null) {
            return linearLayout;
        }
        Intrinsics.throwUninitializedPropertyAccessException("picBar");
        throw null;
    }

    public final LinearLayout getPicker$android_release() {
        LinearLayout linearLayout = this.picker;
        if (linearLayout != null) {
            return linearLayout;
        }
        Intrinsics.throwUninitializedPropertyAccessException("picker");
        throw null;
    }

    public final TextView getPickerMsg$android_release() {
        TextView textView = this.pickerMsg;
        if (textView != null) {
            return textView;
        }
        Intrinsics.throwUninitializedPropertyAccessException("pickerMsg");
        throw null;
    }

    public final IconButton getPipBtn$android_release() {
        IconButton iconButton = this.pipBtn;
        if (iconButton != null) {
            return iconButton;
        }
        Intrinsics.throwUninitializedPropertyAccessException("pipBtn");
        throw null;
    }

    public final SharedPreferences getPrefs$android_release() {
        SharedPreferences sharedPreferences = this.prefs;
        if (sharedPreferences != null) {
            return sharedPreferences;
        }
        Intrinsics.throwUninitializedPropertyAccessException("prefs");
        throw null;
    }

    public final TextView getQualBtn$android_release() {
        TextView textView = this.qualBtn;
        if (textView != null) {
            return textView;
        }
        Intrinsics.throwUninitializedPropertyAccessException("qualBtn");
        throw null;
    }

    public final LinearLayout getRemote$android_release() {
        LinearLayout linearLayout = this.remote;
        if (linearLayout != null) {
            return linearLayout;
        }
        Intrinsics.throwUninitializedPropertyAccessException("remote");
        throw null;
    }

    public final LinearLayout getSavedList$android_release() {
        LinearLayout linearLayout = this.savedList;
        if (linearLayout != null) {
            return linearLayout;
        }
        Intrinsics.throwUninitializedPropertyAccessException("savedList");
        throw null;
    }

    public final Button getScanBtn$android_release() {
        Button button = this.scanBtn;
        if (button != null) {
            return button;
        }
        Intrinsics.throwUninitializedPropertyAccessException("scanBtn");
        throw null;
    }

    public final View getSettings$android_release() {
        View view = this.settings;
        if (view != null) {
            return view;
        }
        Intrinsics.throwUninitializedPropertyAccessException("settings");
        throw null;
    }

    public final Button getSetupBar$android_release() {
        Button button = this.setupBar;
        if (button != null) {
            return button;
        }
        Intrinsics.throwUninitializedPropertyAccessException("setupBar");
        throw null;
    }

    public final LinearLayout getSetupRow$android_release() {
        LinearLayout linearLayout = this.setupRow;
        if (linearLayout != null) {
            return linearLayout;
        }
        Intrinsics.throwUninitializedPropertyAccessException("setupRow");
        throw null;
    }

    public final LinearLayout getSoundBar$android_release() {
        LinearLayout linearLayout = this.soundBar;
        if (linearLayout != null) {
            return linearLayout;
        }
        Intrinsics.throwUninitializedPropertyAccessException("soundBar");
        throw null;
    }

    public final FrameLayout getStage$android_release() {
        FrameLayout frameLayout = this.stage;
        if (frameLayout != null) {
            return frameLayout;
        }
        Intrinsics.throwUninitializedPropertyAccessException("stage");
        throw null;
    }

    public final TextView getStatus$android_release() {
        StatusText statusText = this.status;
        if (statusText != null) {
            return statusText;
        }
        Intrinsics.throwUninitializedPropertyAccessException("status");
        throw null;
    }

    public final SurfaceView getSurface$android_release() {
        SurfaceView surfaceView = this.surface;
        if (surfaceView != null) {
            return surfaceView;
        }
        Intrinsics.throwUninitializedPropertyAccessException("surface");
        throw null;
    }

    public final Talk getTalk$android_release() {
        return (Talk) this.talk$delegate.getValue();
    }

    public final EditText getTextBox$android_release() {
        EditText editText = this.textBox;
        if (editText != null) {
            return editText;
        }
        Intrinsics.throwUninitializedPropertyAccessException("textBox");
        throw null;
    }

    public final Button getUpdateBtn$android_release() {
        Button button = this.updateBtn;
        if (button != null) {
            return button;
        }
        Intrinsics.throwUninitializedPropertyAccessException("updateBtn");
        throw null;
    }

    public final IconButton getVideoBtn$android_release() {
        IconButton iconButton = this.videoBtn;
        if (iconButton != null) {
            return iconButton;
        }
        Intrinsics.throwUninitializedPropertyAccessException("videoBtn");
        throw null;
    }

    public final TextView getWaitStep$android_release() {
        TextView textView = this.waitStep;
        if (textView != null) {
            return textView;
        }
        Intrinsics.throwUninitializedPropertyAccessException("waitStep");
        throw null;
    }

    public final FrameLayout getWaiting$android_release() {
        FrameLayout frameLayout = this.waiting;
        if (frameLayout != null) {
            return frameLayout;
        }
        Intrinsics.throwUninitializedPropertyAccessException("waiting");
        throw null;
    }

    public final void leave$android_release() {
        String str;
        int i = 0;
        Manage manage = getManaging$android_release().manage;
        if (manage != null) {
            str = manage.jobs.working();
        } else {
            str = "";
        }
        if (str.length() == 0) {
            disconnect$android_release(null);
            return;
        }
        Popup.Builder builder = new Popup.Builder(this);
        WorkService.Companion companion = WorkService.Companion;
        builder.title = Census$$ExternalSyntheticOutline0.m(WorkService.Companion.say(str), "...");
        builder.message = Fleet.T("phone.leaving_this_tv_cancels", new Pair[0]);
        builder.setPositiveButton(Fleet.T("phone.stay", new Pair[0]), null);
        builder.setNegativeButton(Fleet.T("phone.leave_anyway", new Pair[0]), new MainActivity$$ExternalSyntheticLambda14(this, i));
        builder.show();
    }

    public final boolean live$android_release() {
        Remote remote;
        Tv tv = this.tv;
        if ((tv != null && tv.ready()) || ((remote = this.basic) != null && remote.ready())) {
            return true;
        }
        return false;
    }

    public final boolean needsAdb$android_release() {
        Remote remote = this.basic;
        if (remote == null) {
            return false;
        }
        if (!Intrinsics.areEqual(remote.getKind(), "android")) {
            PhoneRemoteKt.kindOff(this);
            return true;
        }
        Toast.makeText(this, Fleet.T("phone.this_needs_adb_debugging", new Pair[0]), 0).show();
        return true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v8, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    /* JADX WARN: Type inference failed for: r4v9, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    /* JADX WARN: Type inference failed for: r5v1, types: [kotlin.collections.EmptyList] */
    /* JADX WARN: Type inference failed for: r5v14, types: [java.util.ArrayList] */
    /* JADX WARN: Type inference failed for: r5v2, types: [java.lang.Iterable] */
    @Override // android.app.Activity
    public final void onActivityResult(int i, int i2, Intent intent) {
        ArrayList<String> stringArrayListExtra;
        Uri data;
        ?? r5;
        int i3;
        String T;
        InputStream openInputStream;
        JSONArray jSONArray;
        int read;
        Uri data2;
        String T2;
        OutputStream openOutputStream;
        Object obj;
        String str;
        final Uri data3;
        String str2;
        Cursor query;
        int columnIndex;
        String string;
        final Uri data4;
        int columnIndex2;
        String string2;
        Uri data5;
        Uri data6;
        Managing managing$android_release;
        ValueCallback valueCallback;
        Uri[] uriArr;
        super.onActivityResult(i, i2, intent);
        int i4 = 0;
        if (i == 77 && (valueCallback = (managing$android_release = getManaging$android_release()).picking) != null) {
            if (i2 == -1 && intent != null) {
                ClipData clipData = intent.getClipData();
                if (clipData != null && clipData.getItemCount() > 0) {
                    int itemCount = clipData.getItemCount();
                    uriArr = new Uri[itemCount];
                    for (int i5 = 0; i5 < itemCount; i5++) {
                        Uri uri = clipData.getItemAt(i5).getUri();
                        Intrinsics.checkNotNullExpressionValue(uri, "getUri(...)");
                        uriArr[i5] = uri;
                    }
                } else {
                    uriArr = WebChromeClient.FileChooserParams.parseResult(i2, intent);
                }
            } else {
                uriArr = null;
            }
            valueCallback.onReceiveValue(uriArr);
            managing$android_release.picking = null;
        }
        if (i == this.PICK_CAST && i2 == -1 && intent != null && (data6 = intent.getData()) != null) {
            Fleet.castFile(this, data6);
        }
        if (i == this.PICK_DRAW && i2 == -1 && intent != null && (data5 = intent.getData()) != null) {
            this.drawIo.execute(new DrawingKt$$ExternalSyntheticLambda0(i4, this, data5));
        }
        if (i == this.PICK_FLEET && i2 == -1 && intent != null && (data4 = intent.getData()) != null) {
            Object obj2 = ManyTvsKt.checkoutNames;
            final ?? obj3 = new Object();
            obj3.element = "app.apk";
            try {
                query = getContentResolver().query(data4, null, null, null, null);
                if (query != null) {
                    try {
                        if (query.moveToFirst() && (columnIndex2 = query.getColumnIndex("_display_name")) >= 0 && (string2 = query.getString(columnIndex2)) != null) {
                            obj3.element = string2;
                        }
                        query.close();
                    } finally {
                    }
                }
            } catch (Exception unused) {
            }
            final File file = new File(getCacheDir(), "fleet.apk");
            final int i6 = 1;
            new Thread(new Runnable(this) { // from class: dev.tvremote.phone.picker.ManyTvsKt$$ExternalSyntheticLambda0
                public final /* synthetic */ MainActivity f$0;

                {
                    this.f$0 = this;
                }

                @Override // java.lang.Runnable
                public final void run() {
                    boolean z;
                    InputStream openInputStream2;
                    FileOutputStream fileOutputStream;
                    boolean z2;
                    switch (i6) {
                        case 0:
                            MainActivity mainActivity = this.f$0;
                            Uri uri2 = data4;
                            File file2 = file;
                            try {
                                openInputStream2 = mainActivity.getContentResolver().openInputStream(uri2);
                                Intrinsics.checkNotNull(openInputStream2);
                                try {
                                    fileOutputStream = new FileOutputStream(file2);
                                    try {
                                        MathKt.copyTo(openInputStream2, fileOutputStream, 8192);
                                        fileOutputStream.close();
                                        openInputStream2.close();
                                        z = true;
                                    } finally {
                                        try {
                                            throw th;
                                        } finally {
                                        }
                                    }
                                } finally {
                                    try {
                                        throw th;
                                    } finally {
                                    }
                                }
                            } catch (Exception unused2) {
                                z = false;
                            }
                            mainActivity.ui.post(new ManyTvsKt$$ExternalSyntheticLambda10(mainActivity, z, file2, obj3));
                            return;
                        default:
                            MainActivity mainActivity2 = this.f$0;
                            Uri uri3 = data4;
                            File file3 = file;
                            try {
                                openInputStream2 = mainActivity2.getContentResolver().openInputStream(uri3);
                                Intrinsics.checkNotNull(openInputStream2);
                                try {
                                    fileOutputStream = new FileOutputStream(file3);
                                    try {
                                        MathKt.copyTo(openInputStream2, fileOutputStream, 8192);
                                        fileOutputStream.close();
                                        openInputStream2.close();
                                        z2 = true;
                                    } finally {
                                    }
                                } finally {
                                }
                            } catch (Exception unused3) {
                                z2 = false;
                            }
                            mainActivity2.ui.post(new ManyTvsKt$$ExternalSyntheticLambda10(mainActivity2, z2, obj3, file3));
                            return;
                    }
                }
            }).start();
        }
        if (i == this.PICK_FLEET_WELCOME && i2 == -1 && intent != null && (data3 = intent.getData()) != null) {
            Object obj4 = ManyTvsKt.checkoutNames;
            final ?? obj5 = new Object();
            obj5.element = "welcome.mp4";
            try {
                query = getContentResolver().query(data3, null, null, null, null);
                if (query != null) {
                    try {
                        if (query.moveToFirst() && (columnIndex = query.getColumnIndex("_display_name")) >= 0 && (string = query.getString(columnIndex)) != null) {
                            obj5.element = string;
                        }
                        query.close();
                    } finally {
                    }
                }
            } catch (Exception unused2) {
            }
            Set set = Welcome.VIDEO;
            String ext = Welcome.ext((String) obj5.element);
            if (Welcome.VIDEO.contains(ext)) {
                str2 = "video";
            } else if (Welcome.IMAGE.contains(ext)) {
                str2 = "image";
            } else {
                str2 = null;
            }
            if (str2 == null) {
                ManyTvsKt.toast(this, Fleet.T("core.fr_welcome_kind", new Pair[0]));
            } else {
                final File file2 = new File(getCacheDir(), "fleet-welcome.".concat(Welcome.ext((String) obj5.element)));
                final int i7 = 0;
                new Thread(new Runnable(this) { // from class: dev.tvremote.phone.picker.ManyTvsKt$$ExternalSyntheticLambda0
                    public final /* synthetic */ MainActivity f$0;

                    {
                        this.f$0 = this;
                    }

                    @Override // java.lang.Runnable
                    public final void run() {
                        boolean z;
                        InputStream openInputStream2;
                        FileOutputStream fileOutputStream;
                        boolean z2;
                        switch (i7) {
                            case 0:
                                MainActivity mainActivity = this.f$0;
                                Uri uri2 = data3;
                                File file22 = file2;
                                try {
                                    openInputStream2 = mainActivity.getContentResolver().openInputStream(uri2);
                                    Intrinsics.checkNotNull(openInputStream2);
                                    try {
                                        fileOutputStream = new FileOutputStream(file22);
                                        try {
                                            MathKt.copyTo(openInputStream2, fileOutputStream, 8192);
                                            fileOutputStream.close();
                                            openInputStream2.close();
                                            z = true;
                                        } finally {
                                            try {
                                                throw th;
                                            } finally {
                                            }
                                        }
                                    } finally {
                                        try {
                                            throw th;
                                        } finally {
                                        }
                                    }
                                } catch (Exception unused22) {
                                    z = false;
                                }
                                mainActivity.ui.post(new ManyTvsKt$$ExternalSyntheticLambda10(mainActivity, z, file22, obj5));
                                return;
                            default:
                                MainActivity mainActivity2 = this.f$0;
                                Uri uri3 = data3;
                                File file3 = file2;
                                try {
                                    openInputStream2 = mainActivity2.getContentResolver().openInputStream(uri3);
                                    Intrinsics.checkNotNull(openInputStream2);
                                    try {
                                        fileOutputStream = new FileOutputStream(file3);
                                        try {
                                            MathKt.copyTo(openInputStream2, fileOutputStream, 8192);
                                            fileOutputStream.close();
                                            openInputStream2.close();
                                            z2 = true;
                                        } finally {
                                        }
                                    } finally {
                                    }
                                } catch (Exception unused3) {
                                    z2 = false;
                                }
                                mainActivity2.ui.post(new ManyTvsKt$$ExternalSyntheticLambda10(mainActivity2, z2, obj5, file3));
                                return;
                        }
                    }
                }).start();
            }
        }
        String str3 = "";
        if (i == this.PICK_IR_SAVE && i2 == -1 && intent != null && (data2 = intent.getData()) != null) {
            Set set2 = IrRemoteKt.ONCE;
            JSONArray jSONArray2 = new JSONArray();
            for (Pair pair : IrRemoteKt.irSaved(this)) {
                String str4 = (String) pair.first;
                String str5 = (String) pair.second;
                JSONObject m10m = Census$$ExternalSyntheticOutline0.m10m("name", str4, "id", str5);
                Iterator it = IrRemoteKt.irCatalog(this).iterator();
                while (true) {
                    if (it.hasNext()) {
                        obj = it.next();
                        if (((IrProfile) obj).ids.contains(str5)) {
                            break;
                        }
                    } else {
                        obj = null;
                        break;
                    }
                }
                IrProfile irProfile = (IrProfile) obj;
                if (irProfile == null || (str = irProfile.brand) == null) {
                    str = "";
                }
                jSONArray2.put(m10m.put("brand", str));
            }
            String jSONObject = new JSONObject().put("app", "tv-remote").put("ir", jSONArray2).toString(1);
            try {
                openOutputStream = getContentResolver().openOutputStream(data2, "wt");
                Intrinsics.checkNotNull(openOutputStream);
            } catch (Exception unused3) {
                T2 = Fleet.T("ir.import_none", new Pair[0]);
            }
            try {
                Intrinsics.checkNotNull(jSONObject);
                byte[] bytes = jSONObject.getBytes(Charsets.UTF_8);
                Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                openOutputStream.write(bytes);
                openOutputStream.close();
                T2 = Fleet.T("ir.exported", new Pair("n", Integer.valueOf(jSONArray2.length())));
                Toast.makeText(this, T2, 1).show();
            } finally {
            }
        }
        if (i == this.PICK_IR_OPEN && i2 == -1 && intent != null && (data = intent.getData()) != null) {
            Set set3 = IrRemoteKt.ONCE;
            try {
                openInputStream = getContentResolver().openInputStream(data);
                Intrinsics.checkNotNull(openInputStream);
            } catch (Exception unused4) {
                r5 = EmptyList.INSTANCE;
            }
            try {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                byte[] bArr = new byte[8192];
                while (byteArrayOutputStream.size() <= 1048576 && (read = openInputStream.read(bArr)) >= 0) {
                    byteArrayOutputStream.write(bArr, 0, read);
                }
                if (byteArrayOutputStream.size() <= 1048576) {
                    str3 = byteArrayOutputStream.toString("UTF-8");
                }
                openInputStream.close();
                Intrinsics.checkNotNullExpressionValue(str3, "use(...)");
                String obj6 = StringsKt.trim(str3).toString();
                if (StringsKt__StringsJVMKt.startsWith(obj6, false, "[")) {
                    jSONArray = new JSONArray(obj6);
                } else {
                    jSONArray = new JSONObject(obj6).getJSONArray("ir");
                }
                IntRange until = MathKt.until(0, jSONArray.length());
                r5 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until));
                Iterator it2 = until.iterator();
                while (((IntProgressionIterator) it2).hasNext) {
                    JSONObject jSONObject2 = jSONArray.getJSONObject(((IntProgressionIterator) it2).nextInt());
                    r5.add(new Pair(jSONObject2.optString("name"), jSONObject2.optString("id")));
                }
                ArrayList arrayList = new ArrayList();
                for (Object obj7 : r5) {
                    String str6 = (String) ((Pair) obj7).second;
                    ArrayList irCatalog = IrRemoteKt.irCatalog(this);
                    if (!irCatalog.isEmpty()) {
                        Iterator it3 = irCatalog.iterator();
                        while (true) {
                            if (it3.hasNext()) {
                                if (((IrProfile) it3.next()).ids.contains(str6)) {
                                    arrayList.add(obj7);
                                    break;
                                }
                            } else {
                                break;
                            }
                        }
                    }
                }
                ArrayList mutableList = CollectionsKt.toMutableList((Collection) IrRemoteKt.irSaved(this));
                Iterator it4 = arrayList.iterator();
                while (it4.hasNext()) {
                    Pair pair2 = (Pair) it4.next();
                    String str7 = (String) pair2.first;
                    String str8 = (String) pair2.second;
                    if (str8.length() != 0) {
                        String obj8 = StringsKt.trim(str7).toString();
                        if (obj8.length() == 0) {
                            obj8 = str8;
                        }
                        Pair pair3 = new Pair(obj8, str8);
                        if (!mutableList.contains(pair3)) {
                            mutableList.add(pair3);
                        }
                    }
                }
                int size = mutableList.size() - IrRemoteKt.irSaved(this).size();
                if (size > 0) {
                    IrRemoteKt.irKeep(this, mutableList);
                }
                if (arrayList.isEmpty()) {
                    T = Fleet.T("ir.import_none", new Pair[0]);
                    i3 = 1;
                } else {
                    i3 = 1;
                    T = Fleet.T("ir.imported", new Pair("n", Integer.valueOf(size)));
                }
                Toast.makeText(this, T, i3).show();
                if (getIrHost$android_release().getVisibility() == 0 && IrState.page.equals("list")) {
                    IrRemoteKt.irList(this);
                }
            } finally {
            }
        }
        if (i == 78 && i2 == -1 && intent != null && (stringArrayListExtra = intent.getStringArrayListExtra("android.speech.extra.RESULTS")) != null && !stringArrayListExtra.isEmpty()) {
            String str9 = stringArrayListExtra.get(0);
            Intrinsics.checkNotNullExpressionValue(str9, "get(...)");
            MathKt.voice(this, str9);
        }
    }

    @Override // android.app.Activity
    public final void onBackPressed() {
        if (getTalk$android_release().overlay != null) {
            getTalk$android_release().close();
            return;
        }
        Managing managing$android_release = getManaging$android_release();
        LinearLayout linearLayout = managing$android_release.view;
        if (linearLayout.getVisibility() != 0) {
            Set set = IrRemoteKt.ONCE;
            if (getIrHost$android_release().getVisibility() != 0) {
                if (TypingKt.gamesPointerClose(this)) {
                    return;
                }
                if (this.fullscreen) {
                    setFullscreen$android_release(false);
                    return;
                }
                if (getAbout$android_release().getVisibility() == 0) {
                    getAbout$android_release().setVisibility(8);
                    return;
                }
                if (getSettings$android_release().getVisibility() == 0) {
                    getSettings$android_release().setVisibility(8);
                    return;
                } else if (this.host != null) {
                    leave$android_release();
                    return;
                } else {
                    super.onBackPressed();
                    return;
                }
            }
            if (IrState.onFind) {
                IrRemoteKt.irStop();
                IrRemoteKt.irRemote(this);
                return;
            } else {
                IrRemoteKt.irUp(this);
                return;
            }
        }
        linearLayout.setVisibility(8);
        managing$android_release.web.onPause();
        managing$android_release.web.evaluateJavascript("(function(){ try { return localStorage.getItem('setupUndo') || '' } catch (e) { return '' } })()", new Managing$$ExternalSyntheticLambda1(managing$android_release));
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public final void onConfigurationChanged(Configuration c) {
        Intrinsics.checkNotNullParameter(c, "c");
        super.onConfigurationChanged(c);
        TypingKt.layoutRemote(this);
        if (this.floatMode == 1) {
            getMini$android_release().post(new MainActivity$$ExternalSyntheticLambda15(this, 6));
        }
    }

    /* JADX WARN: Can't wrap try/catch for region: R(27:1|(1:3)(1:195)|4|2d|11|12|13|(1:15)(1:167)|(17:17|(1:21)|22|(8:24|(1:26)|27|(1:29)|30|(1:34)|35|(1:39))|40|41|42|(1:44)(1:163)|45|(2:48|46)|49|50|(1:52)(3:157|(1:159)(1:161)|160)|53|(1:55)|56|(15:58|(1:60)|61|(2:64|62)|65|66|(6:69|(1:71)(1:78)|72|(2:74|75)(1:77)|76|67)|79|80|(1:82)|83|(5:86|(1:88)(1:91)|89|90|84)|92|93|(2:95|(2:97|(2:99|(2:101|(16:103|(1:105)|106|(3:108|(1:110)(1:143)|111)(1:144)|112|(3:116|(1:118)|119)|120|(1:122)|123|(2:125|(1:127))|(1:142)(1:131)|(1:135)|136|(1:138)|139|140)(2:145|146))(2:147|148))(2:149|150))(2:151|152))(2:153|154))(2:155|156))|166|(2:19|21)|22|(0)|40|41|42|(0)(0)|45|(1:46)|49|50|(0)(0)|53|(0)|56|(0)(0)|(1:(0))) */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:155:0x0cff  */
    /* JADX WARN: Removed duplicated region for block: B:157:0x020c  */
    /* JADX WARN: Removed duplicated region for block: B:163:0x0185  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x011b  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x0184 A[DONT_GENERATE] */
    /* JADX WARN: Removed duplicated region for block: B:48:0x0198 A[Catch: Exception -> 0x01ac, LOOP:0: B:46:0x0192->B:48:0x0198, LOOP_END, TRY_LEAVE, TryCatch #2 {Exception -> 0x01ac, blocks: (B:42:0x0176, B:45:0x0186, B:46:0x0192, B:48:0x0198), top: B:41:0x0176 }] */
    /* JADX WARN: Removed duplicated region for block: B:52:0x020a  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x0474  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x04b0  */
    /* JADX WARN: Type inference failed for: r15v43 */
    /* JADX WARN: Type inference failed for: r15v44, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r15v45 */
    /* JADX WARN: Type inference failed for: r3v49, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    /* JADX WARN: Type inference failed for: r4v76, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    /* JADX WARN: Type inference failed for: r4v82, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    /* JADX WARN: Type inference failed for: r4v88, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    /* JADX WARN: Type inference failed for: r4v94, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    /* JADX WARN: Type inference failed for: r5v37, types: [java.util.Map, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r5v44, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    @Override // android.app.Activity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onCreate(Bundle bundle) {
        int i;
        long j;
        File file;
        byte[] bArr;
        String str;
        SupportRelay relay;
        int i2;
        int i3;
        Button button;
        Bundle bundle2;
        ?? r15;
        String str2;
        boolean z;
        boolean z2;
        String str3;
        String string;
        Iterator<String> keys;
        Long longOrNull;
        File file2;
        int i4 = 2;
        int i5 = 3;
        int i6 = 0;
        UiKt.applyPalette(this);
        if (UiKt.LIGHT) {
            i = org.conscrypt.R.style.AppLight;
        } else {
            i = org.conscrypt.R.style.AppDark;
        }
        setTheme(i);
        super.onCreate(bundle);
        VoicePhrases voicePhrases = VoicePhrases.INSTANCE;
        MainActivity$$ExternalSyntheticLambda10 mainActivity$$ExternalSyntheticLambda10 = new MainActivity$$ExternalSyntheticLambda10(this, i6);
        File filesDir = getFilesDir();
        synchronized (voicePhrases) {
            try {
                j = 0;
                if (!VoicePhrases.started) {
                    VoicePhrases.started = true;
                    if (filesDir != null) {
                        file = new File(filesDir, "voice-phrases.json");
                    } else {
                        file = null;
                    }
                    VoicePhrases.kept = file;
                    if (file != null) {
                        List list = SignedList.KEYS;
                        bArr = SignedList.kept(file, SignedList.KEYS);
                    } else {
                        bArr = null;
                    }
                    Pair choose = VoicePhrases.choose(null, bArr, SignedList.packed$default(mainActivity$$ExternalSyntheticLambda10));
                    if (choose != null) {
                        VoicePhrases.bytes = (byte[]) choose.first;
                        Voice voice = Voice.INSTANCE;
                        Voice.phrases = (Phrases) choose.second;
                    }
                    if (file != null) {
                        if (file.isFile()) {
                            long currentTimeMillis = System.currentTimeMillis() - file.lastModified();
                            if (0 <= currentTimeMillis && currentTimeMillis < 86400000) {
                            }
                        }
                        Thread thread = new Thread(new Guard$$ExternalSyntheticLambda3(i5), "voice-phrases");
                        thread.setDaemon(true);
                        thread.start();
                    }
                }
            } finally {
            }
        }
        List list2 = Downloader.bases;
        Downloader.dir = getFilesDir();
        SharedPreferences sharedPreferences = getSharedPreferences("tvs", 0);
        Intrinsics.checkNotNullParameter(sharedPreferences, "<set-?>");
        this.prefs = sharedPreferences;
        MainActivity$onCreate$2 mainActivity$onCreate$2 = Census.store;
        String version = UpdaterKt.version(this);
        MainActivity$onCreate$2 mainActivity$onCreate$22 = new MainActivity$onCreate$2(this);
        Census.app = "phone";
        Census.version = version;
        Census.store = mainActivity$onCreate$22;
        try {
            file2 = new File(getExternalFilesDir(null), "census-url.txt");
            if (!file2.isFile()) {
                file2 = null;
            }
        } catch (IOException unused) {
        }
        if (file2 != null) {
            str = StringsKt.trim(MathKt.readText$default(file2)).toString();
            if (str != null && str.length() != 0) {
                Census.url = str;
            }
            MainActivity$onCreate$2 mainActivity$onCreate$23 = Census.store;
            Census.device = new Census$$ExternalSyntheticLambda4(i5);
            PhoneApp phoneApp = Guard.app;
            Guard.crash = new Bloat$$ExternalSyntheticLambda0(i4);
            PhoneSupport phoneSupport = PhoneSupport.INSTANCE;
            PhoneSupport.activity = new WeakReference(this);
            relay = phoneSupport.relay(this);
            if (!relay.open()) {
                SupportAndroid$store$1 supportAndroid$store$1 = relay.store;
                String str4 = supportAndroid$store$1.get("live_code");
                String str5 = "";
                if (str4 == null) {
                    str4 = "";
                }
                String str6 = supportAndroid$store$1.get("live_key");
                if (str6 != null) {
                    str5 = str6;
                }
                String str7 = supportAndroid$store$1.get("live_until");
                if (str7 != null && (longOrNull = StringsKt__StringNumberConversionsKt.toLongOrNull(str7)) != null) {
                    j = longOrNull.longValue();
                }
                long j2 = j;
                if (str4.length() != 0 && j2 > System.currentTimeMillis()) {
                    relay.run(j2, str4, str5);
                    WireLog.all.add("·", "support goes on after a restart, ".concat(str4));
                }
            }
            String str8 = "{}";
            boolean z3 = SoundPace.even;
            SoundPace.even = getPrefs$android_release().getBoolean("listenEven", false);
            string = getPrefs$android_release().getString("soundLead", "{}");
            if (string == null) {
                str8 = string;
            }
            JSONObject jSONObject = new JSONObject(str8);
            keys = jSONObject.keys();
            Intrinsics.checkNotNullExpressionValue(keys, "keys(...)");
            while (keys.hasNext()) {
                String next = keys.next();
                SoundPace.learned.put(next, Integer.valueOf(jSONObject.getInt(next)));
            }
            SoundPace.changed = new TalkKt$$ExternalSyntheticLambda1(this);
            MathKt.reachAroundVpn(this);
            WireLog wireLog = WireLog.all;
            String m = Census$$ExternalSyntheticOutline0.m("TV Remote ", UpdaterKt.version(this), " (phone, Android ", Build.VERSION.RELEASE, ")");
            Intrinsics.checkNotNullParameter(m, "<set-?>");
            WireLog.app = m;
            this.video = getPrefs$android_release().getBoolean("video", true);
            UiKt.loadLang(this);
            setVolumeControlStream(3);
            getWindow().addFlags(128);
            getWindow().setStatusBarColor(UiKt.BG);
            getWindow().setNavigationBarColor(UiKt.BG);
            View decorView = getWindow().getDecorView();
            if (UiKt.LIGHT) {
                i3 = 0;
            } else {
                if (Build.VERSION.SDK_INT >= 26) {
                    i2 = 16;
                } else {
                    i2 = 0;
                }
                i3 = i2 | 8192;
            }
            decorView.setSystemUiVisibility(i3);
            FrameLayout frameLayout = new FrameLayout(this);
            frameLayout.setBackgroundColor(UiKt.BG);
            frameLayout.setFitsSystemWindows(true);
            List list3 = PickerScreenKt.PER_TV;
            this.picker = UiKt.col(this);
            float f = 16;
            float f2 = 20;
            float f3 = 24;
            getPicker$android_release().setPadding(UiKt.dp(this, f), UiKt.dp(this, f2), UiKt.dp(this, f), UiKt.dp(this, f3));
            TextView label = UiKt.label(this, "TV Remote", 24, UiKt.TEXT);
            Typeface typeface = Typeface.DEFAULT_BOLD;
            label.setTypeface(typeface);
            LinearLayout linearLayout = new LinearLayout(this);
            linearLayout.setGravity(16);
            LinearLayout col = UiKt.col(this);
            col.addView(label);
            col.addView(UiKt.label(this, Fleet.T("picker.version", new Pair("v", UpdaterKt.versionLine(this))), 12, UiKt.MUTED));
            ImageView imageView = new ImageView(this);
            imageView.setImageResource(org.conscrypt.R.drawable.icon);
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            GradientDrawable gradientDrawable = new GradientDrawable();
            float f4 = 40;
            gradientDrawable.setCornerRadius((imageView.getResources().getDisplayMetrics().density * f4) / 4);
            imageView.setBackground(gradientDrawable);
            imageView.setClipToOutline(true);
            imageView.setImportantForAccessibility(2);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(UiKt.dp(this, f4), UiKt.dp(this, f4));
            float f5 = 12;
            layoutParams.rightMargin = UiKt.dp(this, f5);
            linearLayout.addView(imageView, layoutParams);
            linearLayout.addView(col, new LinearLayout.LayoutParams(0, -2, 1.0f));
            View icon = UiKt.icon(this, "@settings", Fleet.T("page.settings", new Pair[0]), UiKt.BTN);
            icon.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(this, 19));
            float f6 = 52;
            float f7 = 44;
            linearLayout.addView(icon, new LinearLayout.LayoutParams(UiKt.dp(this, f6), UiKt.dp(this, f7)));
            getPicker$android_release().addView(linearLayout);
            this.pickerMsg = UiKt.label(this, "", 14, UiKt.ERR_TEXT);
            getPickerMsg$android_release().setBackground(UiKt.box(this, UiKt.ERR_BG, 12));
            float f8 = 10;
            getPickerMsg$android_release().setPadding(UiKt.dp(this, f5), UiKt.dp(this, f8), UiKt.dp(this, f5), UiKt.dp(this, f8));
            getPickerMsg$android_release().setVisibility(8);
            getPicker$android_release().addView(getPickerMsg$android_release(), UiKt.gap(this, 12));
            this.updateBtn = UiKt.button(this, "", UiKt.GREEN);
            getUpdateBtn$android_release().setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(this, 20));
            getUpdateBtn$android_release().setVisibility(8);
            float f9 = 48;
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, UiKt.dp(this, f9));
            layoutParams2.topMargin = UiKt.dp(this, f5);
            getPicker$android_release().addView(getUpdateBtn$android_release(), layoutParams2);
            LinearLayout linearLayout2 = new LinearLayout(this);
            linearLayout2.setGravity(16);
            linearLayout2.addView(UiKt.head(this, Fleet.T("picker.your_tvs", new Pair[0])), new LinearLayout.LayoutParams(0, -2, 1.0f));
            Object obj = ManyTvsKt.checkoutNames;
            Button button2 = UiKt.button(this, ApkSigner$$ExternalSyntheticOutline0.m("@tv|", Fleet.T("many_tvs.several_tvs", new Pair[0])), UiKt.SOFT);
            UiKt.setInk(button2, UiKt.ACCENT_TEXT);
            button2.setTextSize(14.0f);
            button2.setTypeface(typeface);
            button2.setPadding(UiKt.dp(this, f5), 0, UiKt.dp(this, f5), 0);
            button2.setContentDescription(Fleet.T("many_tvs.several_tvs_at_once", new Pair[0]));
            button2.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(this, 15));
            this.fleetBtn = button2;
            WeakHashMap weakHashMap = TvStatusKt.tickFor;
            boolean z4 = TvStatus.shots;
            TvStatus.shots = getPrefs$android_release().getBoolean("tvshots", false);
            Button button3 = UiKt.button(this, "@eye|", UiKt.BTN);
            button3.setTextSize(14.0f);
            button3.setMinWidth(0);
            button3.setMinimumWidth(0);
            button3.setPadding(0, 0, 0, 0);
            button3.setCompoundDrawablePadding(0);
            button3.setContentDescription(StringsKt.trim(StringsKt.removePrefix(Fleet.T("tvstat.show_screens", new Pair[0]), "👁️")).toString() + ". " + Fleet.T("tvstat.show_screens_tip", new Pair[0]));
            if (Build.VERSION.SDK_INT >= 26) {
                Guard$$ExternalSyntheticApiModelOutline0.m(button3, Fleet.T("tvstat.show_screens_tip", new Pair[0]));
            }
            UiKt.setOn$default(button3, TvStatus.shots, 0, 6);
            button3.setOnClickListener(new Guard$$ExternalSyntheticLambda9(4, this, button3));
            this.screensBtn = button3;
            float f10 = 34;
            LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(UiKt.dp(this, 42), UiKt.dp(this, f10));
            float f11 = 6;
            layoutParams3.rightMargin = UiKt.dp(this, f11);
            linearLayout2.addView(button3, layoutParams3);
            button = this.fleetBtn;
            if (button == null) {
                linearLayout2.addView(button, new LinearLayout.LayoutParams(-2, UiKt.dp(this, f10)));
                getPicker$android_release().addView(linearLayout2, UiKt.gap(this, 14));
                this.savedList = UiKt.col(this);
                getPicker$android_release().addView(getSavedList$android_release());
                if (IrRemoteKt.irAvailable(this)) {
                    View button4 = UiKt.button(this, ApkSigner$$ExternalSyntheticOutline0.m("@pulse|", Fleet.T("ir.title", new Pair[0])), UiKt.BTN);
                    button4.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(this, 21));
                    LinearLayout picker$android_release = getPicker$android_release();
                    LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-1, UiKt.dp(this, f9));
                    layoutParams4.topMargin = UiKt.dp(this, f8);
                    picker$android_release.addView(button4, layoutParams4);
                }
                getPicker$android_release().addView(UiKt.head(this, Fleet.T("picker.find_on_the_wi", new Pair[0])), UiKt.gap(this, 18));
                this.scanBtn = UiKt.button(this, ApkSigner$$ExternalSyntheticOutline0.m("@search|", Fleet.T("picker.scan_the_wi_fi", new Pair[0])), UiKt.ACCENT);
                getScanBtn$android_release().setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(this, 16));
                LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(-1, UiKt.dp(this, f9));
                layoutParams5.topMargin = UiKt.dp(this, f11);
                getPicker$android_release().addView(getScanBtn$android_release(), layoutParams5);
                this.foundList = UiKt.col(this);
                getPicker$android_release().addView(getFoundList$android_release());
                getPicker$android_release().addView(UiKt.head(this, Fleet.T("picker.type_the_tv_s", new Pair[0])), UiKt.gap(this, 18));
                LinearLayout linearLayout3 = new LinearLayout(this);
                this.ipBox = UiKt.input(this, Fleet.T("picker.e_g_192_168", new Pair[0]));
                getIpBox$android_release().setInputType(3);
                getIpBox$android_release().setImeOptions(2);
                getIpBox$android_release().setOnEditorActionListener(new PickerScreenKt$$ExternalSyntheticLambda11(0, this));
                IconButton icon2 = UiKt.icon(this, "@right", Fleet.T("page.connect", new Pair[0]), UiKt.ACCENT);
                icon2.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(this, 17));
                linearLayout3.addView(getIpBox$android_release(), new LinearLayout.LayoutParams(0, UiKt.dp(this, f9), 1.0f));
                LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(-2, UiKt.dp(this, f9));
                layoutParams6.leftMargin = UiKt.dp(this, 8);
                layoutParams6.width = UiKt.dp(this, 60);
                linearLayout3.addView(icon2, layoutParams6);
                getPicker$android_release().addView(linearLayout3, UiKt.gap(this, 6));
                Button button5 = UiKt.button(this, Fleet.T("picker.how_to_connect", new Pair[0]), 0);
                button5.setTextColor(UiKt.ACCENT_TEXT);
                button5.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(this, 18));
                getPicker$android_release().addView(button5, new LinearLayout.LayoutParams(-1, UiKt.dp(this, f7)));
                TypingKt.buildRemote(this);
                ScrollView scrollView = new ScrollView(this);
                scrollView.addView(getPicker$android_release());
                scrollView.setTag("picker");
                frameLayout.addView(scrollView, new FrameLayout.LayoutParams(-1, -1));
                frameLayout.addView(getRemote$android_release(), new FrameLayout.LayoutParams(-1, -1));
                FrameLayout frameLayout2 = new FrameLayout(this);
                frameLayout2.setBackgroundColor(UiKt.BG);
                frameLayout2.setClickable(true);
                frameLayout2.setVisibility(8);
                LinearLayout col2 = UiKt.col(this);
                col2.setGravity(1);
                float f12 = 28;
                col2.setPadding(UiKt.dp(this, f12), 0, UiKt.dp(this, f12), 0);
                ProgressBar progressBar = new ProgressBar(this);
                progressBar.setIndeterminate(true);
                progressBar.setIndeterminateTintList(ColorStateList.valueOf(UiKt.ACCENT));
                float f13 = 64;
                col2.addView(progressBar, new LinearLayout.LayoutParams(UiKt.dp(this, f13), UiKt.dp(this, f13)));
                TextView textView = new TextView(this);
                textView.setText(Fleet.T("connecting.connecting", new Pair[0]));
                textView.setTextSize(15.0f);
                textView.setTextColor(UiKt.MUTED);
                textView.setGravity(17);
                LinearLayout.LayoutParams layoutParams7 = new LinearLayout.LayoutParams(-1, -2);
                layoutParams7.topMargin = UiKt.dp(this, f12);
                col2.addView(textView, layoutParams7);
                TextView textView2 = new TextView(this);
                textView2.setTextSize(28.0f);
                textView2.setTextColor(UiKt.TEXT);
                textView2.setTypeface(typeface);
                textView2.setGravity(17);
                this.waitName = textView2;
                LinearLayout.LayoutParams layoutParams8 = new LinearLayout.LayoutParams(-1, -2);
                layoutParams8.topMargin = UiKt.dp(this, f11);
                col2.addView(textView2, layoutParams8);
                TextView textView3 = new TextView(this);
                textView3.setTextSize(16.0f);
                textView3.setTextColor(UiKt.MUTED);
                textView3.setGravity(17);
                textView3.setLineSpacing(UiKt.dp(this, 3), 1.0f);
                this.waitStep = textView3;
                TextView waitStep$android_release = getWaitStep$android_release();
                LinearLayout.LayoutParams layoutParams9 = new LinearLayout.LayoutParams(-1, -2);
                layoutParams9.topMargin = UiKt.dp(this, 14);
                col2.addView(waitStep$android_release, layoutParams9);
                Button button6 = UiKt.button(this, Fleet.T("common.cancel", new Pair[0]), UiKt.CARD);
                button6.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(this, 0));
                LinearLayout.LayoutParams layoutParams10 = new LinearLayout.LayoutParams(UiKt.dp(this, 200), UiKt.dp(this, 54));
                layoutParams10.topMargin = UiKt.dp(this, f4);
                col2.addView(button6, layoutParams10);
                frameLayout2.addView(col2, new FrameLayout.LayoutParams(-1, -2, 17));
                this.waiting = frameLayout2;
                frameLayout.addView(getWaiting$android_release(), new FrameLayout.LayoutParams(-1, -1));
                frameLayout.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() { // from class: dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda11
                    @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
                    public final void onGlobalLayout() {
                        boolean covered$android_release;
                        MainActivity mainActivity = MainActivity.this;
                        if (mainActivity.floatMode != 2 && (covered$android_release = mainActivity.covered$android_release()) != mainActivity.wasCovered) {
                            mainActivity.wasCovered = covered$android_release;
                            if (covered$android_release) {
                                if (PipKt.picLive(mainActivity)) {
                                    PipKt.setFloat(1, mainActivity);
                                    return;
                                } else {
                                    if (!mainActivity.floating) {
                                        mainActivity.stopPicture$android_release();
                                        return;
                                    }
                                    return;
                                }
                            }
                            if (!mainActivity.floating) {
                                PipKt.setFloat(0, mainActivity);
                            }
                            mainActivity.picTries = 0;
                            mainActivity.startPicture$android_release();
                        }
                    }
                });
                LinearLayout col3 = UiKt.col(this);
                col3.setPadding(UiKt.dp(this, f), UiKt.dp(this, f2), UiKt.dp(this, f), UiKt.dp(this, f3));
                TextView label2 = UiKt.label(this, Fleet.T("page.settings", new Pair[0]), 24, UiKt.TEXT);
                label2.setTypeface(typeface);
                LinearLayout linearLayout4 = new LinearLayout(this);
                linearLayout4.setGravity(16);
                linearLayout4.addView(label2, new LinearLayout.LayoutParams(0, -2, 1.0f));
                IconButton icon3 = UiKt.icon(this, "@check", Fleet.T("drawing.done", new Pair[0]), UiKt.ACCENT);
                icon3.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(this, 11));
                linearLayout4.addView(icon3, new LinearLayout.LayoutParams(UiKt.dp(this, f6), UiKt.dp(this, f7)));
                col3.addView(linearLayout4);
                col3.addView(UiKt.head(this, Fleet.T("info_screens.language", new Pair[0])), UiKt.gap(this, 18));
                String pref$android_release = pref$android_release("lang");
                List listOf = MathKt.listOf(new Pair("", ApkSigner$$ExternalSyntheticOutline0.m("@phone|", Fleet.T("info_screens.same_as_the_phone", new Pair[0]))));
                ?? r5 = Langs.NAMES;
                ArrayList arrayList = new ArrayList(r5.size());
                for (Map.Entry entry : r5.entrySet()) {
                    arrayList.add(new Pair((String) entry.getKey(), ApkSigner$$ExternalSyntheticOutline0.m("@globe|", (String) entry.getValue())));
                }
                Iterator it = CollectionsKt.plus(listOf, (Iterable) arrayList).iterator();
                while (it.hasNext()) {
                    Pair pair = (Pair) it.next();
                    String str9 = (String) pair.first;
                    String str10 = (String) pair.second;
                    if (!Intrinsics.areEqual(str9, pref$android_release)) {
                        str3 = "";
                    } else {
                        str3 = "   ✓";
                    }
                    Button row = UiKt.row(this, Census$$ExternalSyntheticOutline0.m(str10, str3), new Vidaa$$ExternalSyntheticLambda6(str9, (Object) pref$android_release, (Object) this, 3));
                    if (Intrinsics.areEqual(str9, pref$android_release)) {
                        UiKt.setInk(row, UiKt.ACCENT_TEXT);
                    }
                    col3.addView(row);
                }
                col3.addView(UiKt.head(this, Fleet.T("info_screens.appearance", new Pair[0])), UiKt.gap(this, 18));
                String pref$android_release2 = pref$android_release("theme");
                String str11 = "auto";
                if (pref$android_release2.length() == 0) {
                    pref$android_release2 = "auto";
                }
                LinearLayout linearLayout5 = new LinearLayout(this);
                Iterator it2 = ArraysKt.asList(new Pair[]{new Pair("auto", Fleet.T("info_screens.auto", new Pair[0])), new Pair("light", Fleet.T("info_screens.light", new Pair[0])), new Pair("dark", Fleet.T("info_screens.dark", new Pair[0]))}).iterator();
                int i7 = 0;
                while (it2.hasNext()) {
                    int i8 = i7 + 1;
                    final Pair pair2 = (Pair) it2.next();
                    final boolean areEqual = Intrinsics.areEqual(pair2.first, pref$android_release2);
                    String str12 = pref$android_release2;
                    String str13 = str11;
                    String str14 = (String) MapsKt__MapsKt.mapOf(new Pair(str11, "contrast"), new Pair("light", "wake"), new Pair("dark", "moon")).get(pair2.first);
                    StringBuilder sb = new StringBuilder("@");
                    sb.append(str14);
                    sb.append("|");
                    Object obj2 = pair2.second;
                    sb.append(obj2);
                    Button button7 = UiKt.button(this, sb.toString(), UiKt.BTN);
                    UiKt.setOn$default(button7, areEqual, 0, 6);
                    Iterator it3 = it2;
                    button7.setPadding(UiKt.dp(this, f11), 0, UiKt.dp(this, f11), 0);
                    button7.setContentDescription((CharSequence) obj2);
                    button7.setOnClickListener(new View.OnClickListener() { // from class: dev.tvremote.phone.manage.InfoScreensKt$$ExternalSyntheticLambda8
                        @Override // android.view.View.OnClickListener
                        public final void onClick(View view) {
                            if (areEqual) {
                                return;
                            }
                            MainActivity mainActivity = this;
                            mainActivity.getPrefs$android_release().edit().putString("theme", (String) pair2.first).apply();
                            mainActivity.recreate();
                        }
                    });
                    if (i7 > 0) {
                        z2 = true;
                    } else {
                        z2 = false;
                    }
                    linearLayout5.addView(button7, UiKt.cell(44, this, z2));
                    i7 = i8;
                    pref$android_release2 = str12;
                    str11 = str13;
                    it2 = it3;
                }
                String str15 = str11;
                col3.addView(linearLayout5, UiKt.gap(this, 6));
                col3.addView(UiKt.head(this, Fleet.T("talk.setting_head", new Pair[0])), UiKt.gap(this, 18));
                View frameLayout3 = new FrameLayout(this);
                ?? obj3 = new Object();
                Vidaa$$ExternalSyntheticLambda6 vidaa$$ExternalSyntheticLambda6 = new Vidaa$$ExternalSyntheticLambda6(frameLayout3, this, (Object) obj3, 4);
                obj3.element = vidaa$$ExternalSyntheticLambda6;
                vidaa$$ExternalSyntheticLambda6.invoke();
                col3.addView(frameLayout3, UiKt.gap(this, 6));
                col3.addView(UiKt.head(this, Fleet.T("info_screens.the_phone_s_volume", new Pair[0])), UiKt.gap(this, 18));
                ?? obj4 = new Object();
                UpdaterKt$$ExternalSyntheticLambda6 updaterKt$$ExternalSyntheticLambda6 = new UpdaterKt$$ExternalSyntheticLambda6(1, this, obj4);
                obj4.element = UiKt.row(this, "", new Regex$$ExternalSyntheticLambda0(7, this, updaterKt$$ExternalSyntheticLambda6));
                updaterKt$$ExternalSyntheticLambda6.invoke();
                Object obj5 = obj4.element;
                if (obj5 != null) {
                    col3.addView((Button) obj5);
                    col3.addView(UiKt.head(this, Fleet.T("info_screens.when_pressing_a_key", new Pair[0])), UiKt.gap(this, 18));
                    ?? obj6 = new Object();
                    UpdaterKt$$ExternalSyntheticLambda6 updaterKt$$ExternalSyntheticLambda62 = new UpdaterKt$$ExternalSyntheticLambda6(2, this, obj6);
                    obj6.element = UiKt.row(this, "", new Regex$$ExternalSyntheticLambda0(8, this, updaterKt$$ExternalSyntheticLambda62));
                    updaterKt$$ExternalSyntheticLambda62.invoke();
                    Object obj7 = obj6.element;
                    if (obj7 != null) {
                        col3.addView((Button) obj7);
                        col3.addView(UiKt.head(this, Fleet.T("info_screens.tv_keyboard", new Pair[0])), UiKt.gap(this, 18));
                        ?? obj8 = new Object();
                        UpdaterKt$$ExternalSyntheticLambda6 updaterKt$$ExternalSyntheticLambda63 = new UpdaterKt$$ExternalSyntheticLambda6(3, this, obj8);
                        obj8.element = UiKt.row(this, "", new Regex$$ExternalSyntheticLambda0(9, this, updaterKt$$ExternalSyntheticLambda63));
                        updaterKt$$ExternalSyntheticLambda63.invoke();
                        Object obj9 = obj8.element;
                        if (obj9 != null) {
                            col3.addView((Button) obj9);
                            col3.addView(UiKt.head(this, Fleet.T("info_screens.updates", new Pair[0])), UiKt.gap(this, 18));
                            ?? obj10 = new Object();
                            UpdaterKt$$ExternalSyntheticLambda6 updaterKt$$ExternalSyntheticLambda64 = new UpdaterKt$$ExternalSyntheticLambda6(4, this, obj10);
                            obj10.element = UiKt.row(this, "", new Regex$$ExternalSyntheticLambda0(10, this, updaterKt$$ExternalSyntheticLambda64));
                            updaterKt$$ExternalSyntheticLambda64.invoke();
                            Object obj11 = obj10.element;
                            if (obj11 != null) {
                                col3.addView((Button) obj11);
                                col3.addView(UiKt.row(this, ApkSigner$$ExternalSyntheticOutline0.m("@refresh|", Fleet.T("info_screens.check_now", new Pair[0])), new TalkKt$$ExternalSyntheticLambda1(this, 18)));
                                TextView note = UiKt.note(this, "");
                                this.updateNote = note;
                                col3.addView(note);
                                col3.addView(UiKt.head(this, Fleet.T("info_screens.privacy", new Pair[0])), UiKt.gap(this, 18));
                                ?? obj12 = new Object();
                                Setup$$ExternalSyntheticLambda5 setup$$ExternalSyntheticLambda5 = new Setup$$ExternalSyntheticLambda5(6, obj12);
                                obj12.element = UiKt.row(this, "", new Setup$$ExternalSyntheticLambda5(7, setup$$ExternalSyntheticLambda5));
                                setup$$ExternalSyntheticLambda5.invoke();
                                Object obj13 = obj12.element;
                                if (obj13 != null) {
                                    col3.addView((Button) obj13);
                                    col3.addView(UiKt.note(this, Fleet.T("about.census_note", new Pair[0])));
                                    col3.addView(UiKt.head(this, Fleet.T("info_screens.about", new Pair[0])), UiKt.gap(this, 18));
                                    col3.addView(UiKt.row(this, ApkSigner$$ExternalSyntheticOutline0.m("@info|", Fleet.T("about.about", new Pair[0])), new TalkKt$$ExternalSyntheticLambda1(this, 19)));
                                    ScrollView scrollView2 = new ScrollView(this);
                                    scrollView2.setBackgroundColor(UiKt.BG);
                                    scrollView2.setClickable(true);
                                    scrollView2.addView(col3);
                                    scrollView2.setVisibility(8);
                                    setSettings$android_release(scrollView2);
                                    frameLayout.addView(getSettings$android_release(), new FrameLayout.LayoutParams(-1, -1));
                                    setAbout$android_release(Fleet.buildAbout(this));
                                    frameLayout.addView(getAbout$android_release(), new FrameLayout.LayoutParams(-1, -1));
                                    getWindow().getDecorView().setLayoutDirection(0);
                                    if (Words.getRtl()) {
                                        getSettings$android_release().setLayoutDirection(1);
                                        getAbout$android_release().setLayoutDirection(1);
                                    }
                                    FrameLayout frameLayout4 = new FrameLayout(this);
                                    frameLayout4.setVisibility(8);
                                    this.irHost = frameLayout4;
                                    frameLayout.addView(getIrHost$android_release(), new FrameLayout.LayoutParams(-1, -1));
                                    this.managing = new Managing(this, frameLayout);
                                    this.mini = new MiniPlayer(this);
                                    frameLayout.addView(getMini$android_release(), new FrameLayout.LayoutParams(-2, -2));
                                    setContentView(frameLayout);
                                    show$android_release(false);
                                    if (bundle != null) {
                                        bundle2 = bundle;
                                        this.host = bundle2.getString("host");
                                        this.entry = bundle2.getString("entry");
                                        this.keysAway = bundle2.getBoolean("keys");
                                        if (this.host != null) {
                                            z = true;
                                        } else {
                                            z = false;
                                        }
                                        this.wasLive = z;
                                    } else {
                                        bundle2 = bundle;
                                    }
                                    if (this.keysAway && (str2 = this.host) != null) {
                                        String str16 = this.entry;
                                        if (str16 != null) {
                                            str2 = str16;
                                        }
                                        waitFor$android_release(title$android_release(str2), Fleet.T("keys_only.reconnecting", new Pair[0]));
                                    }
                                    if (this.host != null) {
                                        show$android_release(true);
                                    }
                                    if (!Fleet.takeShare(this, getIntent())) {
                                        Intent intent = getIntent();
                                        Intrinsics.checkNotNullExpressionValue(intent, "getIntent(...)");
                                        if (UpdaterKt.installResult(this, intent)) {
                                            setIntent(new Intent(this, (Class<?>) MainActivity.class));
                                        }
                                    }
                                    if (bundle2 != null && bundle2.getBoolean("settings")) {
                                        r15 = 0;
                                        getSettings$android_release().setVisibility(0);
                                    } else {
                                        r15 = 0;
                                    }
                                    if (bundle2 != null && bundle2.getBoolean("about")) {
                                        getAbout$android_release().setVisibility(r15);
                                    }
                                    if (getPrefs$android_release().getBoolean("autoUpdate", true)) {
                                        UpdaterKt.checkUpdate(this, r15);
                                    }
                                    MathKt.changed(this);
                                    return;
                                }
                                Intrinsics.throwUninitializedPropertyAccessException("censusRow");
                                throw null;
                            }
                            Intrinsics.throwUninitializedPropertyAccessException(str15);
                            throw null;
                        }
                        Intrinsics.throwUninitializedPropertyAccessException("kbdRow");
                        throw null;
                    }
                    Intrinsics.throwUninitializedPropertyAccessException("buzzRow");
                    throw null;
                }
                Intrinsics.throwUninitializedPropertyAccessException("vol");
                throw null;
            }
            Intrinsics.throwUninitializedPropertyAccessException("fleetBtn");
            throw null;
        }
        str = null;
        if (str != null) {
            Census.url = str;
        }
        MainActivity$onCreate$2 mainActivity$onCreate$232 = Census.store;
        Census.device = new Census$$ExternalSyntheticLambda4(i5);
        PhoneApp phoneApp2 = Guard.app;
        Guard.crash = new Bloat$$ExternalSyntheticLambda0(i4);
        PhoneSupport phoneSupport2 = PhoneSupport.INSTANCE;
        PhoneSupport.activity = new WeakReference(this);
        relay = phoneSupport2.relay(this);
        if (!relay.open()) {
        }
        String str82 = "{}";
        boolean z32 = SoundPace.even;
        SoundPace.even = getPrefs$android_release().getBoolean("listenEven", false);
        string = getPrefs$android_release().getString("soundLead", "{}");
        if (string == null) {
        }
        JSONObject jSONObject2 = new JSONObject(str82);
        keys = jSONObject2.keys();
        Intrinsics.checkNotNullExpressionValue(keys, "keys(...)");
        while (keys.hasNext()) {
        }
        SoundPace.changed = new TalkKt$$ExternalSyntheticLambda1(this);
        MathKt.reachAroundVpn(this);
        WireLog wireLog2 = WireLog.all;
        String m2 = Census$$ExternalSyntheticOutline0.m("TV Remote ", UpdaterKt.version(this), " (phone, Android ", Build.VERSION.RELEASE, ")");
        Intrinsics.checkNotNullParameter(m2, "<set-?>");
        WireLog.app = m2;
        this.video = getPrefs$android_release().getBoolean("video", true);
        UiKt.loadLang(this);
        setVolumeControlStream(3);
        getWindow().addFlags(128);
        getWindow().setStatusBarColor(UiKt.BG);
        getWindow().setNavigationBarColor(UiKt.BG);
        View decorView2 = getWindow().getDecorView();
        if (UiKt.LIGHT) {
        }
        decorView2.setSystemUiVisibility(i3);
        FrameLayout frameLayout5 = new FrameLayout(this);
        frameLayout5.setBackgroundColor(UiKt.BG);
        frameLayout5.setFitsSystemWindows(true);
        List list32 = PickerScreenKt.PER_TV;
        this.picker = UiKt.col(this);
        float f14 = 16;
        float f22 = 20;
        float f32 = 24;
        getPicker$android_release().setPadding(UiKt.dp(this, f14), UiKt.dp(this, f22), UiKt.dp(this, f14), UiKt.dp(this, f32));
        TextView label3 = UiKt.label(this, "TV Remote", 24, UiKt.TEXT);
        Typeface typeface2 = Typeface.DEFAULT_BOLD;
        label3.setTypeface(typeface2);
        LinearLayout linearLayout6 = new LinearLayout(this);
        linearLayout6.setGravity(16);
        LinearLayout col4 = UiKt.col(this);
        col4.addView(label3);
        col4.addView(UiKt.label(this, Fleet.T("picker.version", new Pair("v", UpdaterKt.versionLine(this))), 12, UiKt.MUTED));
        ImageView imageView2 = new ImageView(this);
        imageView2.setImageResource(org.conscrypt.R.drawable.icon);
        imageView2.setScaleType(ImageView.ScaleType.CENTER_CROP);
        GradientDrawable gradientDrawable2 = new GradientDrawable();
        float f42 = 40;
        gradientDrawable2.setCornerRadius((imageView2.getResources().getDisplayMetrics().density * f42) / 4);
        imageView2.setBackground(gradientDrawable2);
        imageView2.setClipToOutline(true);
        imageView2.setImportantForAccessibility(2);
        LinearLayout.LayoutParams layoutParams11 = new LinearLayout.LayoutParams(UiKt.dp(this, f42), UiKt.dp(this, f42));
        float f52 = 12;
        layoutParams11.rightMargin = UiKt.dp(this, f52);
        linearLayout6.addView(imageView2, layoutParams11);
        linearLayout6.addView(col4, new LinearLayout.LayoutParams(0, -2, 1.0f));
        View icon4 = UiKt.icon(this, "@settings", Fleet.T("page.settings", new Pair[0]), UiKt.BTN);
        icon4.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(this, 19));
        float f62 = 52;
        float f72 = 44;
        linearLayout6.addView(icon4, new LinearLayout.LayoutParams(UiKt.dp(this, f62), UiKt.dp(this, f72)));
        getPicker$android_release().addView(linearLayout6);
        this.pickerMsg = UiKt.label(this, "", 14, UiKt.ERR_TEXT);
        getPickerMsg$android_release().setBackground(UiKt.box(this, UiKt.ERR_BG, 12));
        float f82 = 10;
        getPickerMsg$android_release().setPadding(UiKt.dp(this, f52), UiKt.dp(this, f82), UiKt.dp(this, f52), UiKt.dp(this, f82));
        getPickerMsg$android_release().setVisibility(8);
        getPicker$android_release().addView(getPickerMsg$android_release(), UiKt.gap(this, 12));
        this.updateBtn = UiKt.button(this, "", UiKt.GREEN);
        getUpdateBtn$android_release().setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(this, 20));
        getUpdateBtn$android_release().setVisibility(8);
        float f92 = 48;
        LinearLayout.LayoutParams layoutParams22 = new LinearLayout.LayoutParams(-1, UiKt.dp(this, f92));
        layoutParams22.topMargin = UiKt.dp(this, f52);
        getPicker$android_release().addView(getUpdateBtn$android_release(), layoutParams22);
        LinearLayout linearLayout22 = new LinearLayout(this);
        linearLayout22.setGravity(16);
        linearLayout22.addView(UiKt.head(this, Fleet.T("picker.your_tvs", new Pair[0])), new LinearLayout.LayoutParams(0, -2, 1.0f));
        Object obj14 = ManyTvsKt.checkoutNames;
        Button button22 = UiKt.button(this, ApkSigner$$ExternalSyntheticOutline0.m("@tv|", Fleet.T("many_tvs.several_tvs", new Pair[0])), UiKt.SOFT);
        UiKt.setInk(button22, UiKt.ACCENT_TEXT);
        button22.setTextSize(14.0f);
        button22.setTypeface(typeface2);
        button22.setPadding(UiKt.dp(this, f52), 0, UiKt.dp(this, f52), 0);
        button22.setContentDescription(Fleet.T("many_tvs.several_tvs_at_once", new Pair[0]));
        button22.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(this, 15));
        this.fleetBtn = button22;
        WeakHashMap weakHashMap2 = TvStatusKt.tickFor;
        boolean z42 = TvStatus.shots;
        TvStatus.shots = getPrefs$android_release().getBoolean("tvshots", false);
        Button button32 = UiKt.button(this, "@eye|", UiKt.BTN);
        button32.setTextSize(14.0f);
        button32.setMinWidth(0);
        button32.setMinimumWidth(0);
        button32.setPadding(0, 0, 0, 0);
        button32.setCompoundDrawablePadding(0);
        button32.setContentDescription(StringsKt.trim(StringsKt.removePrefix(Fleet.T("tvstat.show_screens", new Pair[0]), "👁️")).toString() + ". " + Fleet.T("tvstat.show_screens_tip", new Pair[0]));
        if (Build.VERSION.SDK_INT >= 26) {
        }
        UiKt.setOn$default(button32, TvStatus.shots, 0, 6);
        button32.setOnClickListener(new Guard$$ExternalSyntheticLambda9(4, this, button32));
        this.screensBtn = button32;
        float f102 = 34;
        LinearLayout.LayoutParams layoutParams32 = new LinearLayout.LayoutParams(UiKt.dp(this, 42), UiKt.dp(this, f102));
        float f112 = 6;
        layoutParams32.rightMargin = UiKt.dp(this, f112);
        linearLayout22.addView(button32, layoutParams32);
        button = this.fleetBtn;
        if (button == null) {
        }
    }

    /* JADX WARN: Can't wrap try/catch for region: R(7:16|(4:18|(1:20)(1:27)|(1:22)(1:26)|(2:24|25))|28|29|31|25|14) */
    @Override // android.app.Activity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onDestroy() {
        ContextWrapper contextWrapper;
        Context context;
        Guard$install$r$1 guard$install$r$1 = this.pipRx;
        if (guard$install$r$1 != null) {
            try {
                unregisterReceiver(guard$install$r$1);
            } catch (Exception unused) {
            }
        }
        Managing managing$android_release = getManaging$android_release();
        managing$android_release.destroyed = true;
        managing$android_release.close();
        HttpServer httpServer = managing$android_release.http;
        if (httpServer != null) {
            ServerSocket serverSocket = httpServer.server;
            httpServer.server = null;
            if (serverSocket != null) {
                try {
                    serverSocket.close();
                } catch (IOException unused2) {
                }
            }
        }
        managing$android_release.web.destroy();
        Talk talk$android_release = getTalk$android_release();
        talk$android_release.close();
        Handler handler = talk$android_release.h;
        Talk$$ExternalSyntheticLambda4 talk$$ExternalSyntheticLambda4 = talk$android_release.release;
        handler.removeCallbacks(talk$$ExternalSyntheticLambda4);
        talk$$ExternalSyntheticLambda4.run();
        Guard$install$r$1 guard$install$r$12 = talk$android_release.rx;
        if (guard$install$r$12 != null) {
            try {
                talk$android_release.a.unregisterReceiver(guard$install$r$12);
            } catch (Exception unused3) {
            }
        }
        talk$android_release.rx = null;
        Set set = Popup.open;
        Intrinsics.checkNotNullExpressionValue(set, "access$getOpen$cp(...)");
        for (Popup popup : CollectionsKt.toList(set)) {
            Context context2 = popup.getContext();
            if (context2 != this) {
                if (context2 instanceof ContextWrapper) {
                    contextWrapper = (ContextWrapper) context2;
                } else {
                    contextWrapper = null;
                }
                if (contextWrapper != null) {
                    context = contextWrapper.getBaseContext();
                } else {
                    context = null;
                }
                if (context != this) {
                }
            }
            popup.dismiss();
        }
        NowApp nowApp = this.nowApp;
        if (nowApp != null) {
            if (nowApp != null) {
                nowApp.work.shutdownNow();
                AdbLink adbLink = nowApp.link;
                if (adbLink != null) {
                    adbLink.close();
                }
                nowApp.link = null;
            } else {
                Intrinsics.throwUninitializedPropertyAccessException("nowApp");
                throw null;
            }
        }
        KbdWatch kbdWatch = this.kbdWatch;
        if (kbdWatch != null) {
            if (kbdWatch != null) {
                kbdWatch.work.shutdownNow();
            } else {
                Intrinsics.throwUninitializedPropertyAccessException("kbdWatch");
                throw null;
            }
        }
        this.ui.removeCallbacksAndMessages(null);
        if (this.listen) {
            this.listen = false;
            Fleet.listenService(this, false);
            Fleet.stopSound(this);
        }
        stopPicture$android_release();
        Tv tv = this.tv;
        if (tv != null) {
            tv.stop();
        }
        this.tv = null;
        Remote remote = this.basic;
        if (remote != null) {
            remote.close();
        }
        this.basic = null;
        super.onDestroy();
    }

    @Override // android.app.Activity
    public final boolean onGenericMotionEvent(MotionEvent e) {
        int i;
        Integer valueOf;
        int i2;
        Intrinsics.checkNotNullParameter(e, "e");
        if ((e.getSource() & 16777232) != 0 && e.getAction() == 2 && live$android_release() && !(getCurrentFocus() instanceof EditText)) {
            float axisValue = e.getAxisValue(0);
            if (axisValue == 0.0f) {
                axisValue = e.getAxisValue(15);
            }
            float axisValue2 = e.getAxisValue(1);
            if (axisValue2 == 0.0f) {
                axisValue2 = e.getAxisValue(16);
            }
            if (Math.max(Math.abs(axisValue), Math.abs(axisValue2)) <= 0.5f) {
                valueOf = null;
            } else if (Math.abs(axisValue) > Math.abs(axisValue2)) {
                if (axisValue > 0.0f) {
                    i2 = 22;
                } else {
                    i2 = 21;
                }
                valueOf = Integer.valueOf(i2);
            } else {
                if (axisValue2 > 0.0f) {
                    i = 20;
                } else {
                    i = 19;
                }
                valueOf = Integer.valueOf(i);
            }
            long uptimeMillis = SystemClock.uptimeMillis();
            if (valueOf == null) {
                this.stickKey = null;
                return true;
            }
            if (!valueOf.equals(this.stickKey)) {
                this.stickKey = valueOf;
                this.stickAt = uptimeMillis;
                this.stickLast = uptimeMillis;
                press$android_release(true, valueOf.intValue());
                return true;
            }
            if (uptimeMillis - this.stickAt >= 400 && uptimeMillis - this.stickLast >= 130) {
                this.stickLast = uptimeMillis;
                press$android_release(true, valueOf.intValue());
            }
            return true;
        }
        return super.onGenericMotionEvent(e);
    }

    @Override // dev.tvremote.core.picture.Tv.Listener
    public final void onNetwork(String str, String str2, String str3) {
        String str4 = this.entry;
        if (str4 == null && (str4 = this.host) == null) {
            return;
        }
        SharedPreferences.Editor putString = getPrefs$android_release().edit().putString("mac:".concat(str4), str).putString("lan:".concat(str4), str2);
        if (str3.length() > 0 && !str3.equals(str4)) {
            putString.putString("ts:".concat(str4), str3);
        }
        putString.apply();
        PickerScreenKt.foldSaved(this, str4);
    }

    @Override // android.app.Activity
    public final void onNewIntent(Intent i) {
        Intrinsics.checkNotNullParameter(i, "i");
        super.onNewIntent(i);
        if (Fleet.takeShare(this, i)) {
            return;
        }
        if (Intrinsics.areEqual(i.getAction(), "dev.tvremote.phone.STOP_LISTEN")) {
            Fleet.stopListen(this, null);
        } else {
            UpdaterKt.installResult(this, i);
        }
    }

    @Override // dev.tvremote.core.picture.Tv.Listener
    public final void onPass(String str) {
        String str2 = this.entry;
        if (str2 == null) {
            str2 = this.host;
        }
        if (str2 != null) {
            getPrefs$android_release().edit().putString("tvs:".concat(str2), str).apply();
        }
    }

    @Override // dev.tvremote.core.picture.Tv.Listener
    public final void onPassRefused() {
    }

    @Override // android.app.Activity
    public final void onPause() {
        Air.airStop(this);
        Handler handler = this.ui;
        handler.removeCallbacks(this.probe);
        PickerScreenKt.watchNetworks(this, false);
        handler.removeCallbacks(TvStatusKt.getStatusTick(this));
        handler.removeCallbacks(TvStatusKt.getShotTick(this));
        super.onPause();
    }

    @Override // android.app.Activity
    public final void onPictureInPictureModeChanged(boolean z, Configuration c) {
        int i = 2;
        Intrinsics.checkNotNullParameter(c, "c");
        super.onPictureInPictureModeChanged(z, c);
        ArrayList arrayList = PipKt.hidden;
        ViewParent parent = getMini$android_release().getParent();
        Intrinsics.checkNotNull(parent, "null cannot be cast to non-null type android.view.ViewGroup");
        ViewGroup viewGroup = (ViewGroup) parent;
        if (z) {
            this.wasPip = true;
            PipKt.hidden.clear();
            int childCount = viewGroup.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = viewGroup.getChildAt(i2);
                if (childAt != getMini$android_release()) {
                    PipKt.hidden.add(new Pair(childAt, Integer.valueOf(childAt.getVisibility())));
                    childAt.setVisibility(8);
                }
            }
            PipKt.setFloat(2, this);
            Guard$install$r$1 guard$install$r$1 = new Guard$install$r$1(i, this);
            this.pipRx = guard$install$r$1;
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(guard$install$r$1, new IntentFilter("dev.tvremote.phone.PIP"), 4);
                return;
            } else {
                registerReceiver(guard$install$r$1, new IntentFilter("dev.tvremote.phone.PIP"));
                return;
            }
        }
        BroadcastReceiver broadcastReceiver = this.pipRx;
        if (broadcastReceiver != null) {
            try {
                unregisterReceiver(broadcastReceiver);
            } catch (Exception unused) {
            }
        }
        this.pipRx = null;
        Iterator it = PipKt.hidden.iterator();
        Intrinsics.checkNotNullExpressionValue(it, "iterator(...)");
        while (it.hasNext()) {
            Object next = it.next();
            Intrinsics.checkNotNullExpressionValue(next, "next(...)");
            Pair pair = (Pair) next;
            ((View) pair.first).setVisibility(((Number) pair.second).intValue());
        }
        PipKt.hidden.clear();
        if (this.pic != null && this.floating) {
            PipKt.setFloat(1, this);
            this.wasCovered = covered$android_release();
        } else {
            this.floating = false;
            PipKt.setFloat(0, this);
            TypingKt.layoutRemote(this);
        }
    }

    @Override // android.app.Activity
    public final void onRequestPermissionsResult(int i, String[] permissions, int[] results) {
        boolean z;
        boolean z2;
        Intrinsics.checkNotNullParameter(permissions, "permissions");
        Intrinsics.checkNotNullParameter(results, "results");
        super.onRequestPermissionsResult(i, permissions, results);
        boolean z3 = true;
        if (i == 31) {
            Talk talk$android_release = getTalk$android_release();
            if (results.length == 0) {
                z2 = true;
            } else {
                z2 = false;
            }
            if (!z2 && results[0] == 0) {
                talk$android_release.open();
            } else {
                talk$android_release.getClass();
                String T = Fleet.T("talk.mic_denied", new Pair[0]);
                MainActivity mainActivity = talk$android_release.a;
                Toast.makeText(mainActivity, T, 1).show();
                mainActivity.speak$android_release();
            }
        }
        if (i == 32 && this.managing != null) {
            Managing managing$android_release = getManaging$android_release();
            if (results.length == 0) {
                z = true;
            } else {
                z = false;
            }
            if (z || results[0] != 0) {
                z3 = false;
            }
            PermissionRequest permissionRequest = managing$android_release.camAsk;
            if (permissionRequest != null) {
                managing$android_release.camAsk = null;
                if (z3) {
                    permissionRequest.grant(new String[]{"android.webkit.resource.VIDEO_CAPTURE"});
                } else {
                    permissionRequest.deny();
                }
            }
        }
    }

    @Override // android.app.Activity
    public final void onResume() {
        super.onResume();
        this.wasPip = false;
        if (Air.mode.equals("mouse")) {
            Air.airStart(this, "mouse");
        }
        this.probe.run();
        PickerScreenKt.watchNetworks(this, true);
        List list = UpdaterKt.PHONE_NOTES;
        Release release = this.updateAfterAllow;
        if (release != null) {
            this.updateAfterAllow = null;
            if (Build.VERSION.SDK_INT >= 26 && !Guard$$ExternalSyntheticApiModelOutline0.m(getPackageManager())) {
                return;
            }
            UpdaterKt.startUpdate(this, release);
        }
    }

    @Override // android.app.Activity
    public final void onSaveInstanceState(Bundle out) {
        boolean z;
        boolean z2;
        Intrinsics.checkNotNullParameter(out, "out");
        super.onSaveInstanceState(out);
        out.putString("host", this.host);
        out.putString("entry", this.entry);
        boolean z3 = true;
        if (this.basic == null && !this.keysAway) {
            z = false;
        } else {
            z = true;
        }
        out.putBoolean("keys", z);
        if (getSettings$android_release().getVisibility() == 0) {
            z2 = true;
        } else {
            z2 = false;
        }
        out.putBoolean("settings", z2);
        if (getAbout$android_release().getVisibility() != 0) {
            z3 = false;
        }
        out.putBoolean("about", z3);
    }

    @Override // android.app.Activity
    public final void onStart() {
        Tv tv;
        Adb adb;
        Adb adb2;
        super.onStart();
        this.foreground = true;
        this.wasPip = false;
        this.ui.removeCallbacks(this.quietUpdate);
        this.ui.removeCallbacks(this.idleStop);
        this.ui.removeCallbacks(this.picAway);
        PickerScreenKt.refreshSaved(this);
        this.bgListen = false;
        Fleet.startSound(this);
        Managing managing$android_release = getManaging$android_release();
        if (managing$android_release.view.getVisibility() == 0) {
            AdbLink adbLink = managing$android_release.link;
            if (adbLink != null && (adb2 = adbLink.adb) != null) {
                Thread thread = new Thread(new Guard$$ExternalSyntheticLambda5(4, adb2, adbLink), "adb-check");
                thread.setDaemon(true);
                thread.start();
            }
            managing$android_release.web.evaluateJavascript("typeof refresh === 'function' && refresh()", null);
        }
        if (this.awaySince > 0 && SystemClock.elapsedRealtime() - this.awaySince >= 5000 && (tv = this.tv) != null && (adb = tv.adb) != null && !tv.stopped && !adb.dead) {
            Thread thread2 = new Thread(new Adb$$ExternalSyntheticLambda4(adb, 3), "tv-check");
            thread2.setDaemon(true);
            thread2.start();
        }
        if (this.keysAway) {
            this.keysAway = false;
            String str = this.host;
            if (str != null) {
                TypingKt.resumeBasic(this, str);
            }
        } else {
            startSession$android_release();
        }
        PlayingBar playingBar = this.playing;
        if (playingBar != null) {
            if (playingBar != null) {
                MainActivity mainActivity = playingBar.a;
                Handler handler = mainActivity.ui;
                NowApp$tick$1 nowApp$tick$1 = playingBar.tick;
                handler.removeCallbacks(nowApp$tick$1);
                mainActivity.ui.post(nowApp$tick$1);
                NowApp nowApp = this.nowApp;
                if (nowApp != null) {
                    MainActivity mainActivity2 = nowApp.a;
                    Handler handler2 = mainActivity2.ui;
                    NowApp$tick$1 nowApp$tick$12 = nowApp.tick;
                    handler2.removeCallbacks(nowApp$tick$12);
                    mainActivity2.ui.post(nowApp$tick$12);
                    return;
                }
                Intrinsics.throwUninitializedPropertyAccessException("nowApp");
                throw null;
            }
            Intrinsics.throwUninitializedPropertyAccessException("playing");
            throw null;
        }
    }

    @Override // dev.tvremote.core.picture.Tv.Listener
    public final void onStatus(String str, String detail) {
        Intrinsics.checkNotNullParameter(detail, "detail");
        this.ui.post(new MainActivity$$ExternalSyntheticLambda27(this, this.tv, str, detail, 0));
    }

    @Override // android.app.Activity
    public final void onStop() {
        super.onStop();
        this.foreground = false;
        this.awaySince = SystemClock.elapsedRealtime();
        boolean isChangingConfigurations = isChangingConfigurations();
        Handler handler = this.ui;
        if (!isChangingConfigurations) {
            handler.postDelayed(this.quietUpdate, 3000L);
        }
        if (this.wasPip) {
            stopPicture$android_release();
        }
        handler.removeCallbacks(this.retry);
        handler.removeCallbacks(this.picRetry);
        boolean z = this.listen;
        MainActivity$$ExternalSyntheticLambda15 mainActivity$$ExternalSyntheticLambda15 = this.picAway;
        if (z) {
            if (this.video && this.host != null) {
                this.bgListen = true;
            }
            handler.postDelayed(mainActivity$$ExternalSyntheticLambda15, 15000L);
            return;
        }
        handler.postDelayed(mainActivity$$ExternalSyntheticLambda15, 15000L);
        handler.postDelayed(this.idleStop, 600000L);
    }

    @Override // android.app.Activity
    public final void onUserLeaveHint() {
        boolean isInPictureInPictureMode;
        super.onUserLeaveHint();
        ArrayList arrayList = PipKt.hidden;
        if (Build.VERSION.SDK_INT >= 26 && PipKt.canPip(this)) {
            isInPictureInPictureMode = isInPictureInPictureMode();
            if (!isInPictureInPictureMode) {
                try {
                    PictureInPictureParams pipParams = PipKt.pipParams(this);
                    if (pipParams != null) {
                        Guard$$ExternalSyntheticApiModelOutline0.m$1(this, pipParams);
                    }
                } catch (Exception unused) {
                }
            }
        }
    }

    @Override // dev.tvremote.core.picture.Tv.Listener
    public final void onVideoSize(int i, int i2) {
        this.ui.post(new MainActivity$$ExternalSyntheticLambda44(this, i, i2, 0));
    }

    public final String pref$android_release(String key) {
        Intrinsics.checkNotNullParameter(key, "key");
        String string = getPrefs$android_release().getString(key, "");
        if (string == null) {
            return "";
        }
        return string;
    }

    public final void press$android_release(boolean z, int i) {
        if (z) {
            buzz$android_release();
        }
        Tv tv = this.tv;
        if (tv != null && RulesClient.SETUP_KEYS.contains(Integer.valueOf(i)) && tv.ready()) {
            new Thread(new MainActivity$$ExternalSyntheticLambda12(i, this, tv, 0)).start();
            return;
        }
        if (tv != null && i == 3 && tv.ready()) {
            new Thread(new MainActivity$$ExternalSyntheticLambda12(tv, this, i)).start();
            return;
        }
        if (tv != null) {
            if (tv.ready()) {
                tv.press(i);
            }
        } else {
            if (19 <= i && i < 24) {
                Remote remote = this.basic;
                if (remote != null) {
                    remote.pulse(i, 110L);
                    return;
                }
                return;
            }
            Remote remote2 = this.basic;
            if (remote2 != null) {
                remote2.key(i, 3);
            }
        }
    }

    public final void reconnect$android_release(String error) {
        String str;
        Intrinsics.checkNotNullParameter(error, "error");
        String str2 = this.host;
        if (str2 == null) {
            return;
        }
        if (!this.foreground) {
            TextView status$android_release = getStatus$android_release();
            String str3 = this.entry;
            if (str3 != null) {
                str2 = str3;
            }
            status$android_release.setText(title$android_release(str2) + " · " + Fleet.T("phone.reconnects_when_the_app", new Pair[0]));
            return;
        }
        int i = this.retries;
        if (i >= 4) {
            disconnect$android_release(error);
            return;
        }
        this.retries = i + 1;
        String str4 = this.entry;
        if (str4 != null) {
            str2 = str4;
        }
        String title$android_release = title$android_release(str2);
        int i2 = this.retries;
        if (i2 > 1) {
            str = ApkSigner$$ExternalSyntheticOutline0.m(" (", i2, ")");
        } else {
            str = "";
        }
        waitFor$android_release(title$android_release, Fleet.T("phone.connection_lost_reconnecting", new Pair("tries", str)));
        this.ui.postDelayed(this.retry, this.retries * 1000);
    }

    public final void searched$android_release(String sentence, String str) {
        String T;
        Intrinsics.checkNotNullParameter(sentence, "sentence");
        if (isFinishing()) {
            return;
        }
        if (Intrinsics.areEqual(str, "yt")) {
            T = Fleet.T("phone.searching_youtube_for", new Pair("sentence", sentence));
        } else if (Intrinsics.areEqual(str, "gs")) {
            T = Fleet.T("phone.sent_to_the_tv", new Pair("sentence", sentence));
        } else {
            T = Fleet.T("core.fr_no_search", new Pair[0]);
        }
        Toast.makeText(this, T, 0).show();
    }

    public final void setAbout$android_release(View view) {
        Intrinsics.checkNotNullParameter(view, "<set-?>");
        this.about = view;
    }

    public final void setFullscreen$android_release(boolean z) {
        int i;
        if (z && this.floating) {
            PipKt.unfloat(this);
        }
        this.fullscreen = z;
        if (z) {
            i = 6;
        } else {
            i = 1;
        }
        setRequestedOrientation(i);
        TypingKt.layoutRemote(this);
    }

    public final void setSettings$android_release(View view) {
        Intrinsics.checkNotNullParameter(view, "<set-?>");
        this.settings = view;
    }

    public final void show$android_release(boolean z) {
        int i;
        LinearLayout remote$android_release = getRemote$android_release();
        int i2 = 8;
        if (z) {
            i = 0;
        } else {
            i = 8;
        }
        remote$android_release.setVisibility(i);
        if (z) {
            if (Air.mode.equals("mouse")) {
                Air.airStart(this, "mouse");
            }
        } else {
            Air.airStop(this);
        }
        if (z) {
            getRemote$android_release().setFocusableInTouchMode(true);
            getRemote$android_release().requestFocus();
        }
        Object parent = getPicker$android_release().getParent();
        Intrinsics.checkNotNull(parent, "null cannot be cast to non-null type android.view.View");
        View view = (View) parent;
        if (!z) {
            i2 = 0;
        }
        view.setVisibility(i2);
    }

    public final void speak$android_release() {
        String str;
        Intent putExtra = new Intent("android.speech.action.RECOGNIZE_SPEECH").putExtra("android.speech.extra.LANGUAGE_MODEL", "free_form");
        if (UiKt.VI) {
            str = "vi-VN";
        } else {
            ConcurrentHashMap concurrentHashMap = Words.books;
            str = Words.lang;
        }
        Intent putExtra2 = putExtra.putExtra("android.speech.extra.LANGUAGE", str).putExtra("android.speech.extra.PROMPT", Fleet.T("phone.say_what_the_tv", new Pair[0]));
        Intrinsics.checkNotNullExpressionValue(putExtra2, "putExtra(...)");
        try {
            startActivityForResult(putExtra2, 78);
        } catch (Exception unused) {
            this.askBox.invoke();
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:25:0x009f, code lost:
    
        if (dev.tvremote.core.ontv.Games.isAddress(r1) != false) goto L28;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void startPicture$android_release() {
        int i = 0;
        String str = this.host;
        if (str != null) {
            if ((!covered$android_release() || this.floatMode == 1) && this.pic == null && this.tv != null && this.video && !this.bgListen && this.surfaceReady) {
                DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
                Surface surface = getSurface$android_release().getHolder().getSurface();
                int i2 = getPrefs$android_release().getInt("quality", 1);
                int max = Math.max(displayMetrics.widthPixels, displayMetrics.heightPixels);
                MainActivity$onCreate$2 mainActivity$onCreate$2 = this.picListener;
                int i3 = getPrefs$android_release().getInt("picFps", 0);
                int i4 = getPrefs$android_release().getInt("picRate", 0) * 1000000;
                String string = getPrefs$android_release().getString("picEnc", "auto");
                Intrinsics.checkNotNull(string);
                boolean contains = getPrefs$android_release().contains("quality");
                String str2 = this.entry;
                if (str2 == null) {
                    str2 = str;
                }
                String pref$android_release = pref$android_release("tvs:".concat(str2));
                if (pref$android_release.length() > 0) {
                    Regex regex = Tailscale.LOGIN;
                }
                pref$android_release = null;
                this.pic = Fleet.Tv$default(this, str, surface, i2, max, false, mainActivity$onCreate$2, false, 0, i3, i4, string, contains, pref$android_release, 139136);
                this.picShown = false;
                Tv tv = this.pic;
                String string2 = getPrefs$android_release().getString("picEnc", "auto");
                Intrinsics.checkNotNull(string2);
                if (!string2.equals("auto")) {
                    this.ui.postDelayed(new MainActivity$$ExternalSyntheticLambda9(this, tv, string2, i), 10000L);
                }
            }
        }
    }

    public final void startSession$android_release() {
        String str = this.host;
        if (str != null && this.basic == null && !this.keysAway) {
            String str2 = this.entry;
            if (str2 == null) {
                str2 = str;
            }
            if (TypingKt.kindOf(this, str2).equals("android")) {
                if (this.tv == null) {
                    this.tv = Fleet.Tv$default(this, str, null, 0, 0, this.wakeNext, this, false, 0, 0, 0, null, false, null, 524160);
                    this.wakeNext = false;
                }
                startPicture$android_release();
            }
        }
    }

    public final void stopPicture$android_release() {
        Tv tv;
        this.floating = false;
        if (this.floatMode == 1) {
            PipKt.setFloat(0, this);
        }
        this.ui.removeCallbacks(this.picRetry);
        this.ui.removeCallbacks(this.countWatchers);
        this.picWatchers = 0;
        if (this.pic != null && (tv = this.tv) != null) {
            tv.carry(null);
        }
        Tv tv2 = this.pic;
        if (tv2 != null) {
            tv2.stop();
        }
        this.pic = null;
        PipKt.pipUpdate(this);
    }

    @Override // android.view.SurfaceHolder.Callback
    public final void surfaceChanged(SurfaceHolder h, int i, int i2, int i3) {
        Intrinsics.checkNotNullParameter(h, "h");
    }

    @Override // android.view.SurfaceHolder.Callback
    public final void surfaceCreated(SurfaceHolder h) {
        SurfaceScreen surfaceScreen;
        Integer num;
        Intrinsics.checkNotNullParameter(h, "h");
        this.surfaceReady = true;
        this.ui.removeCallbacks(this.picAway);
        Tv tv = this.pic;
        if (tv != null && (surfaceScreen = tv.screen) != null && surfaceScreen.away) {
            if (surfaceScreen.w > 0) {
                try {
                    surfaceScreen.open();
                } catch (Exception e) {
                    Log.w("TvrPic", "decoder not made again: " + e);
                    surfaceScreen.broken = true;
                }
                Census.Ok ok = surfaceScreen.dec;
                byte[] bArr = surfaceScreen.config;
                if (ok != null && bArr != null && (num = (Integer) ((LinkedBlockingQueue) ok.optimize).poll(1000L, TimeUnit.MILLISECONDS)) != null) {
                    surfaceScreen.queue(ok, num.intValue(), bArr, 0L, true);
                }
                LiveGate liveGate = surfaceScreen.gate;
                synchronized (liveGate) {
                    liveGate.inside.clear();
                    liveGate.run = 0;
                    liveGate.skipping = true;
                    liveGate.askedAt = -2000L;
                }
            }
            surfaceScreen.away = false;
            PlayingBar$$ExternalSyntheticLambda13 playingBar$$ExternalSyntheticLambda13 = surfaceScreen.askKey;
            if (playingBar$$ExternalSyntheticLambda13 != null) {
                playingBar$$ExternalSyntheticLambda13.invoke();
            }
        }
        startSession$android_release();
    }

    @Override // android.view.SurfaceHolder.Callback
    public final void surfaceDestroyed(SurfaceHolder h) {
        SurfaceScreen surfaceScreen;
        Intrinsics.checkNotNullParameter(h, "h");
        this.surfaceReady = false;
        Tv tv = this.pic;
        if (tv != null && (surfaceScreen = tv.screen) != null) {
            surfaceScreen.away = true;
            surfaceScreen.closeDec();
        }
        this.ui.removeCallbacks(this.picAway);
        this.ui.postDelayed(this.picAway, 15000L);
    }

    public final String title$android_release(String ip) {
        Intrinsics.checkNotNullParameter(ip, "ip");
        String name = PickerScreenKt.name(this, ip);
        if (name.length() == 0) {
            return ip;
        }
        return name;
    }

    public final void toggleVideo$android_release() {
        String T;
        this.video = !this.video;
        getPrefs$android_release().edit().putBoolean("video", this.video).apply();
        if (!this.video) {
            stopPicture$android_release();
        }
        this.picTries = 0;
        TypingKt.layoutRemote(this);
        TextView status$android_release = getStatus$android_release();
        String str = this.entry;
        if (str == null && (str = this.host) == null) {
            str = "";
        }
        String title$android_release = title$android_release(str);
        Tv tv = this.tv;
        if (tv != null && tv.ready()) {
            if (this.video) {
                T = Fleet.T("phone.opening_the_picture", new Pair[0]);
            } else {
                T = Fleet.T("phone.picture_off", new Pair[0]);
            }
        } else {
            T = Fleet.T("page.connecting", new Pair[0]);
        }
        status$android_release.setText(title$android_release + " · " + T);
        startSession$android_release();
    }

    public final void waitFor$android_release(String str, String step) {
        Intrinsics.checkNotNullParameter(step, "step");
        TextView textView = this.waitName;
        if (textView != null) {
            textView.setText(str);
            getWaitStep$android_release().setText(step);
            getWaiting$android_release().setVisibility(0);
            return;
        }
        Intrinsics.throwUninitializedPropertyAccessException("waitName");
        throw null;
    }

    @Override // dev.tvremote.core.picture.Tv.Listener
    public final boolean wantsNetwork() {
        return true;
    }

    @Override // dev.tvremote.core.picture.Tv.Listener
    public final boolean wantsPass() {
        String str = this.entry;
        if (str == null) {
            str = this.host;
        }
        if (str == null || pref$android_release("tvs:".concat(str)).length() != 0) {
            return false;
        }
        return true;
    }

    public final void working$android_release(String what) {
        int checkSelfPermission;
        Intrinsics.checkNotNullParameter(what, "what");
        try {
            if (what.length() > 0) {
                this.workWhat = what;
                Intent putExtra = new Intent(this, (Class<?>) WorkService.class).putExtra("what", what);
                Intrinsics.checkNotNullExpressionValue(putExtra, "putExtra(...)");
                if (!this.workOn) {
                    int i = Build.VERSION.SDK_INT;
                    if (i >= 33) {
                        checkSelfPermission = checkSelfPermission("android.permission.POST_NOTIFICATIONS");
                        if (checkSelfPermission != 0) {
                            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 7);
                        }
                    }
                    askBackground();
                    synchronized (WorkService.Companion) {
                        WorkService.stopAsked = false;
                    }
                    if (i >= 26) {
                        Guard$$ExternalSyntheticApiModelOutline0.m(this, putExtra);
                    } else {
                        startService(putExtra);
                    }
                    this.ui.postDelayed(this.workTick, 1000L);
                } else {
                    WorkService.Companion companion = WorkService.Companion;
                    WorkService.Companion.show(this, what, getManaging$android_release().progress());
                }
                this.workOn = true;
                return;
            }
            if (this.workOn) {
                this.workOn = false;
                this.workPct = -2;
                this.ui.removeCallbacks(this.workTick);
                WorkService.Companion companion2 = WorkService.Companion;
                WorkService.Companion.stop$1(this);
            }
        } catch (Exception unused) {
        }
    }
}
