package dev.tvremote.phone.manage;

import android.net.ConnectivityManager;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.Button;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.update.Release;
import java.io.File;
import java.io.FileFilter;
import java.util.List;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.StringsKt__StringsJVMKt;

/* loaded from: classes.dex */
public final /* synthetic */ class UpdaterKt$$ExternalSyntheticLambda3 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ KeyEvent.Callback f$0;
    public final /* synthetic */ boolean f$1;

    public /* synthetic */ UpdaterKt$$ExternalSyntheticLambda3(KeyEvent.Callback callback, boolean z, int i) {
        this.$r8$classId = i;
        this.f$0 = callback;
        this.f$1 = z;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Release release;
        String str;
        ConnectivityManager connectivityManager;
        String T;
        float f;
        boolean z = this.f$1;
        KeyEvent.Callback callback = this.f$0;
        int i = 1;
        switch (this.$r8$classId) {
            case 0:
                MainActivity mainActivity = (MainActivity) callback;
                try {
                    List list = Release.KEYS;
                    release = MathKt.newer(UpdaterKt.version(mainActivity), "android", "tv-remote.apk");
                    str = null;
                } catch (Exception e) {
                    String message = e.getMessage();
                    if (message == null) {
                        message = e.getClass().getSimpleName();
                    }
                    release = null;
                    str = message;
                }
                Handler handler = mainActivity.ui;
                boolean z2 = this.f$1;
                handler.post(new UpdaterKt$$ExternalSyntheticLambda10(mainActivity, str, release, z2, 0));
                if (release != null && !z2) {
                    String why = Fleet.why(mainActivity);
                    if (why.length() > 0) {
                        Log.i("QuietUpdate", "not quiet: ".concat(why));
                    } else {
                        String str2 = release.version;
                        final File file = new File(mainActivity.getCacheDir(), ApkSigner$$ExternalSyntheticOutline0.m("quiet-", str2, ".apk"));
                        File[] listFiles = mainActivity.getCacheDir().listFiles(new FileFilter() { // from class: dev.tvremote.phone.QuietUpdate$$ExternalSyntheticLambda4
                            @Override // java.io.FileFilter
                            public final boolean accept(File file2) {
                                String name = file2.getName();
                                Intrinsics.checkNotNullExpressionValue(name, "getName(...)");
                                if (!StringsKt__StringsJVMKt.startsWith(name, false, "quiet-") || file2.equals(file)) {
                                    return false;
                                }
                                return true;
                            }
                        });
                        if (listFiles != null) {
                            for (File file2 : listFiles) {
                                file2.delete();
                            }
                        }
                        if (!file.exists()) {
                            Object systemService = mainActivity.getSystemService("connectivity");
                            if (systemService instanceof ConnectivityManager) {
                                connectivityManager = (ConnectivityManager) systemService;
                            } else {
                                connectivityManager = null;
                            }
                            if (connectivityManager != null && !connectivityManager.isActiveNetworkMetered()) {
                                File file3 = new File(mainActivity.getCacheDir(), "quiet.part");
                                try {
                                    release.download(file3, null);
                                    file3.renameTo(file);
                                    Log.i("QuietUpdate", "fetched " + str2);
                                } catch (Exception e2) {
                                    file3.delete();
                                    Log.w("QuietUpdate", "fetch " + str2 + ": " + e2);
                                }
                            } else {
                                Log.i("QuietUpdate", "metered: later");
                            }
                        }
                    }
                    handler.post(new UpdaterKt$$ExternalSyntheticLambda1(mainActivity, release, i));
                    return;
                }
                return;
            case 1:
                if (z) {
                    T = Fleet.T("playing.screen_off_any", new Pair[0]);
                } else {
                    T = Fleet.T("now_playing.this_tv_cannot_turn", new Pair[0]);
                }
                Fleet.say((MainActivity) callback, T, !z);
                return;
            default:
                Button button = (Button) callback;
                button.setEnabled(!z);
                if (z) {
                    f = 0.4f;
                } else {
                    f = 1.0f;
                }
                button.setAlpha(f);
                return;
        }
    }
}
