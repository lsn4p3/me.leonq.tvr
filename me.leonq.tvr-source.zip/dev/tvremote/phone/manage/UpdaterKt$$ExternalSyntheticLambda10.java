package dev.tvremote.phone.manage;

import android.os.Handler;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Errors;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Words;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.ontv.Checkout;
import dev.tvremote.core.ontv.Games;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.remote.Atv;
import dev.tvremote.core.remote.CodePairing;
import dev.tvremote.core.remote.Inputs;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.core.remote.Vidaa;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda14;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda15;
import dev.tvremote.phone.media.MediaKt$$ExternalSyntheticLambda15;
import dev.tvremote.phone.media.MediaKt$$ExternalSyntheticLambda4;
import dev.tvremote.phone.media.NowApp$tick$1$$ExternalSyntheticLambda3;
import dev.tvremote.phone.media.Talk$$ExternalSyntheticLambda5;
import dev.tvremote.phone.picker.AdbHelpKt;
import dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda13;
import dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda3;
import dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda47;
import dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda9;
import dev.tvremote.phone.picker.ManyTvsKt;
import dev.tvremote.phone.picker.Part;
import dev.tvremote.phone.picker.PickerScreenKt;
import dev.tvremote.phone.picker.Unreachable;
import dev.tvremote.phone.remote.KeysOnlyKt$$ExternalSyntheticLambda2;
import dev.tvremote.phone.remote.TypingKt;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.phone.ui.UiKt;
import dev.tvremote.update.Release;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$BooleanRef;
import kotlin.text.StringsKt;

/* loaded from: classes.dex */
public final /* synthetic */ class UpdaterKt$$ExternalSyntheticLambda10 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ Object f$1;
    public final /* synthetic */ Object f$2;
    public final /* synthetic */ boolean f$3;

    public /* synthetic */ UpdaterKt$$ExternalSyntheticLambda10(Tv tv, String str, boolean z, MainActivity mainActivity) {
        this.$r8$classId = 1;
        this.f$2 = tv;
        this.f$1 = str;
        this.f$3 = z;
        this.f$0 = mainActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        String T;
        String say;
        String str;
        String T2;
        String T3;
        String str2;
        String T4;
        int i;
        String str3 = "";
        int i2 = 4;
        int i3 = 2;
        final boolean z = true;
        char c = 1;
        switch (this.$r8$classId) {
            case 0:
                MainActivity mainActivity = this.f$0;
                if (!mainActivity.isFinishing()) {
                    String str4 = (String) this.f$1;
                    Release release = (Release) this.f$2;
                    if (str4 == null) {
                        mainActivity.update = release;
                        UpdaterKt.showUpdate(mainActivity);
                    }
                    boolean z2 = this.f$3;
                    if (z2) {
                        TextView textView = mainActivity.updateNote;
                        if (textView != null) {
                            if (str4 != null) {
                                T = Fleet.T("updater.could_not_check", new Pair("error", str4));
                            } else if (release == null) {
                                T = Fleet.T("updater.you_have_the_latest", new Pair("version", UpdaterKt.version(mainActivity)));
                            } else {
                                T = Fleet.T("updater.new_version", new Pair("version", release.version));
                            }
                            textView.setText(T);
                        } else {
                            Intrinsics.throwUninitializedPropertyAccessException("updateNote");
                            throw null;
                        }
                    }
                    if (z2 && release != null) {
                        UpdaterKt.askUpdate(mainActivity);
                        return;
                    }
                    return;
                }
                return;
            case 1:
                Tv tv = (Tv) this.f$2;
                String str5 = (String) this.f$1;
                final boolean z3 = this.f$3;
                try {
                    tv.setClipboard(z3, StringsKt.take(str5, 100000));
                } catch (Exception unused) {
                    z = false;
                }
                final MainActivity mainActivity2 = this.f$0;
                mainActivity2.ui.post(new Runnable() { // from class: dev.tvremote.phone.media.NowPlayingBarKt$$ExternalSyntheticLambda12
                    @Override // java.lang.Runnable
                    public final void run() {
                        String T5;
                        boolean z4 = z;
                        if (!z4) {
                            T5 = Fleet.T("now_playing.the_tv_did_not_3", new Pair[0]);
                        } else if (z3) {
                            T5 = Fleet.T("playing.pasted", new Pair[0]);
                        } else {
                            T5 = Fleet.T("playing.copied_to_tv", new Pair[0]);
                        }
                        Fleet.say(MainActivity.this, T5, !z4);
                    }
                });
                return;
            case 2:
                MainActivity mainActivity3 = this.f$0;
                if (!mainActivity3.isFinishing() && mainActivity3.basic == ((Remote) this.f$1)) {
                    if (((Ref$BooleanRef) this.f$2).element) {
                        AdbHelpKt.adbSteps(mainActivity3);
                        return;
                    }
                    if (this.f$3) {
                        Popup.Builder builder = new Popup.Builder(mainActivity3);
                        builder.message = Fleet.T("setup.settings_opened_q", new Pair[0]);
                        builder.setPositiveButton(Fleet.T("apps.yes", new Pair[0]), new MainActivity$$ExternalSyntheticLambda14(mainActivity3, 6));
                        builder.setNegativeButton(Fleet.T("apps.no", new Pair[0]), new MainActivity$$ExternalSyntheticLambda14(mainActivity3, 7));
                        builder.show();
                        return;
                    }
                    AdbHelpKt.lookOnHome(mainActivity3);
                    return;
                }
                return;
            case 3:
                Part part = (Part) this.f$1;
                MainActivity mainActivity4 = this.f$0;
                Function2 function2 = (Function2) this.f$2;
                boolean z4 = this.f$3;
                if (part.cancel.stopped) {
                    part.setStep("■ " + Fleet.T("files.stopped", new Pair[0]));
                    part.state = 3;
                    return;
                }
                part.setStep(Fleet.T("fleet.step_connecting", new Pair[0]));
                File filesDir = mainActivity4.getFilesDir();
                Intrinsics.checkNotNullExpressionValue(filesDir, "getFilesDir(...)");
                String str6 = (String) mainActivity4.route.get(part.ip);
                if (str6 == null) {
                    str6 = part.ip;
                }
                AdbLink adbLink = new AdbLink(filesDir, str6);
                part.link = adbLink;
                try {
                } catch (Exception e) {
                    if (part.cancel.stopped) {
                        part.setStep("■ " + Fleet.T("files.stopped", new Pair[0]));
                        part.state = 3;
                    } else {
                        if (e instanceof Unreachable) {
                            say = e.getMessage();
                        } else {
                            Object obj = Errors.ANDROID;
                            ConcurrentHashMap concurrentHashMap = Words.books;
                            say = Errors.say(Words.lang, e);
                        }
                        part.setStep("✗ " + say);
                        part.state = 2;
                    }
                }
                try {
                    try {
                        adbLink.get();
                        part.setStep(Fleet.T("many_tvs.working", new Pair[0]));
                        String str7 = (String) function2.invoke(adbLink, part);
                        Intrinsics.checkNotNullParameter(str7, "<set-?>");
                        part.raw = str7;
                        if (z4) {
                            Checkout.Result parse = Games.parse(part.raw);
                            if (parse != null) {
                                str = ManyTvsKt.checkoutLine(parse);
                                if (str == null) {
                                }
                                part.setStep("✓ ".concat(str));
                                part.state = 1;
                                adbLink.close();
                                return;
                            }
                        }
                        str = part.raw;
                        part.setStep("✓ ".concat(str));
                        part.state = 1;
                        adbLink.close();
                        return;
                    } catch (Exception unused2) {
                        String msg = Fleet.T("many_tvs.tv_off_on_another", new Pair[0]);
                        Intrinsics.checkNotNullParameter(msg, "msg");
                        throw new Exception(msg);
                    }
                } catch (Throwable th) {
                    adbLink.close();
                    throw th;
                }
            case 4:
                MainActivity mainActivity5 = this.f$0;
                LinearLayout foundList$android_release = mainActivity5.getFoundList$android_release();
                String str8 = (String) this.f$2;
                if (str8.length() > 0) {
                    str3 = str8.concat("\n");
                }
                if (this.f$3) {
                    T2 = Fleet.T("setup.adb_on", new Pair[0]);
                } else {
                    T2 = Fleet.T("picker.adb_off_keys_only", new Pair[0]);
                }
                StringBuilder sb = new StringBuilder();
                sb.append(str3);
                String str9 = (String) this.f$1;
                sb.append(str9);
                sb.append(" · ");
                sb.append(T2);
                foundList$android_release.addView(UiKt.row(mainActivity5, sb.toString(), new MediaKt$$ExternalSyntheticLambda4(mainActivity5, str9, 9)));
                return;
            case 5:
                final MainActivity mainActivity6 = this.f$0;
                if (!mainActivity6.isFinishing()) {
                    List<Inputs.Input> list = (List) this.f$1;
                    if (list != null && !list.isEmpty()) {
                        ArrayList arrayList = new ArrayList();
                        for (final Inputs.Input input : list) {
                            String m = ApkSigner$$ExternalSyntheticOutline0.m("@input|", input.label);
                            if (!Intrinsics.areEqual(input.connected, Boolean.FALSE)) {
                                str2 = "";
                            } else {
                                str2 = Fleet.T("remote.not_plugged", new Pair[0]);
                            }
                            final Inputs.Cache cache = (Inputs.Cache) this.f$2;
                            final boolean z5 = this.f$3;
                            arrayList.add(new Triple(m, str2, new Function0() { // from class: dev.tvremote.phone.remote.InputsMenuKt$$ExternalSyntheticLambda3
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    MainActivity mainActivity7 = MainActivity.this;
                                    Inputs.Input input2 = input;
                                    new Thread(new NowApp$tick$1$$ExternalSyntheticLambda3(z5, mainActivity7.basic, input2, cache, mainActivity7, mainActivity7.tv)).start();
                                    return Unit.INSTANCE;
                                }
                            }));
                        }
                        arrayList.add(new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@menu|", Fleet.T("remote.tv_picker", new Pair[0])), "", new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity6, 19)));
                        UiKt.menu(mainActivity6, Fleet.T("auto.key_input", new Pair[0]), -1, arrayList);
                        return;
                    }
                    if (list == null) {
                        T3 = Fleet.T("auto.inputs_failed", new Pair[0]);
                    } else {
                        T3 = Fleet.T("auto.no_inputs", new Pair[0]);
                    }
                    Toast.makeText(mainActivity6, T3, 0).show();
                    TypingKt.opens(178, mainActivity6);
                    return;
                }
                return;
            case 6:
                MainActivity mainActivity7 = this.f$0;
                PickerScreenKt.message(mainActivity7, null, false);
                boolean z6 = this.f$3;
                if (z6) {
                    T4 = Fleet.T("keys_only.the_4_digits_on", new Pair[0]);
                } else {
                    T4 = Fleet.T("keys_only.the_6_characters_on", new Pair[0]);
                }
                EditText input2 = UiKt.input(mainActivity7, T4);
                if (z6) {
                    i = 2;
                } else {
                    i = 528385;
                }
                input2.setInputType(i);
                FrameLayout inDialog = UiKt.inDialog(mainActivity7, input2);
                Popup.Builder builder2 = new Popup.Builder(mainActivity7);
                builder2.title = Fleet.T("keys_only.type_the_code_shown", new Pair[0]);
                builder2.view = inDialog;
                String T5 = Fleet.T("keys_only.pair", new Pair[0]);
                CodePairing codePairing = (CodePairing) this.f$2;
                builder2.setPositiveButton(T5, new AdbHelpKt$$ExternalSyntheticLambda9(input2, codePairing, mainActivity7, (String) this.f$1, 3));
                builder2.setNegativeButton(Fleet.T("common.cancel", new Pair[0]), new Talk$$ExternalSyntheticLambda5(i3, codePairing));
                builder2.onCancel = new AdbHelpKt$$ExternalSyntheticLambda13(2, codePairing);
                builder2.show();
                return;
            default:
                Remote remote = (Remote) this.f$2;
                MainActivity mainActivity8 = this.f$0;
                String ip = (String) this.f$1;
                try {
                    if (remote instanceof Vidaa) {
                        TypingKt.vidaaCert(mainActivity8);
                    }
                    remote.connect(new AdbHelpKt$$ExternalSyntheticLambda47(mainActivity8, remote, ip, i2));
                    mainActivity8.ui.post(new KeysOnlyKt$$ExternalSyntheticLambda2(mainActivity8, remote, ip, c == true ? 1 : 0));
                    return;
                } catch (Atv.NotPaired unused3) {
                    remote.close();
                    if (this.f$3) {
                        mainActivity8.ui.post(new MainActivity$$ExternalSyntheticLambda15(mainActivity8, 23));
                        return;
                    }
                    Intrinsics.checkNotNullParameter(mainActivity8, "<this>");
                    Handler handler = mainActivity8.ui;
                    Intrinsics.checkNotNullParameter(ip, "ip");
                    String str10 = mainActivity8.entry;
                    if (str10 == null) {
                        str10 = ip;
                    }
                    boolean equals = TypingKt.kindOf(mainActivity8, str10).equals("vidaa");
                    String str11 = mainActivity8.entry;
                    if (str11 == null) {
                        str11 = ip;
                    }
                    String kindOf = TypingKt.kindOf(mainActivity8, str11);
                    File filesDir2 = mainActivity8.getFilesDir();
                    Intrinsics.checkNotNullExpressionValue(filesDir2, "getFilesDir(...)");
                    CodePairing codePairing2 = (CodePairing) Vidaa.Companion.of(filesDir2, kindOf, ip);
                    try {
                        codePairing2.startPairing();
                        handler.post(new UpdaterKt$$ExternalSyntheticLambda10(mainActivity8, equals, codePairing2, ip));
                        return;
                    } catch (Exception e2) {
                        codePairing2.close();
                        handler.post(new MediaKt$$ExternalSyntheticLambda15(mainActivity8, e2, 5));
                        return;
                    }
                } catch (Remote.Refused unused4) {
                    remote.close();
                    mainActivity8.ui.post(new MainActivity$$ExternalSyntheticLambda15(mainActivity8, 22));
                    return;
                } catch (Exception e3) {
                    remote.close();
                    mainActivity8.ui.post(new MediaKt$$ExternalSyntheticLambda15(mainActivity8, e3, i2));
                    return;
                }
        }
    }

    public /* synthetic */ UpdaterKt$$ExternalSyntheticLambda10(Remote remote, MainActivity mainActivity, boolean z, String str) {
        this.$r8$classId = 7;
        this.f$2 = remote;
        this.f$0 = mainActivity;
        this.f$3 = z;
        this.f$1 = str;
    }

    public /* synthetic */ UpdaterKt$$ExternalSyntheticLambda10(MainActivity mainActivity, Object obj, Object obj2, boolean z, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
        this.f$1 = obj;
        this.f$2 = obj2;
        this.f$3 = z;
    }

    public /* synthetic */ UpdaterKt$$ExternalSyntheticLambda10(MainActivity mainActivity, List list, boolean z, Inputs.Cache cache) {
        this.$r8$classId = 5;
        this.f$0 = mainActivity;
        this.f$1 = list;
        this.f$3 = z;
        this.f$2 = cache;
    }

    public /* synthetic */ UpdaterKt$$ExternalSyntheticLambda10(MainActivity mainActivity, boolean z, CodePairing codePairing, String str) {
        this.$r8$classId = 6;
        this.f$0 = mainActivity;
        this.f$3 = z;
        this.f$2 = codePairing;
        this.f$1 = str;
    }

    public /* synthetic */ UpdaterKt$$ExternalSyntheticLambda10(Part part, MainActivity mainActivity, Function2 function2, boolean z) {
        this.$r8$classId = 3;
        this.f$1 = part;
        this.f$0 = mainActivity;
        this.f$2 = function2;
        this.f$3 = z;
    }
}
