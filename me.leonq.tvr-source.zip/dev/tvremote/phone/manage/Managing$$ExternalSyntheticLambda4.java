package dev.tvremote.phone.manage;

import dev.tvremote.core.scenes.Scenes;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda5;
import dev.tvremote.phone.MainActivity;
import java.io.InputStream;
import java.util.HashMap;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import org.json.JSONArray;

/* loaded from: classes.dex */
public final /* synthetic */ class Managing$$ExternalSyntheticLambda4 implements Function1 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Managing f$0;

    public /* synthetic */ Managing$$ExternalSyntheticLambda4(Managing managing, int i) {
        this.$r8$classId = i;
        this.f$0 = managing;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        Managing managing = this.f$0;
        switch (this.$r8$classId) {
            case 0:
                String it = (String) obj;
                Intrinsics.checkNotNullParameter(it, "it");
                InputStream open = managing.a.getAssets().open(it);
                Intrinsics.checkNotNullExpressionValue(open, "open(...)");
                return open;
            case 1:
                JSONArray it2 = (JSONArray) obj;
                Intrinsics.checkNotNullParameter(it2, "it");
                MainActivity mainActivity = managing.a;
                HashMap hashMap = Scenes.KEYS;
                mainActivity.getSharedPreferences("scenes", 0).edit().putString("list", Scenes.clean(it2).toString()).apply();
                MathKt.changed(mainActivity);
                return Unit.INSTANCE;
            default:
                String w = (String) obj;
                Intrinsics.checkNotNullParameter(w, "w");
                managing.a.ui.post(new Guard$$ExternalSyntheticLambda5(managing, w, 21));
                return Unit.INSTANCE;
        }
    }
}
