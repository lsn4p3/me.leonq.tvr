package dev.tvremote.phone.manage;

import dev.tvremote.phone.MainActivity;
import kotlin.jvm.internal.Ref$ObjectRef;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class InfoScreensKt$$ExternalSyntheticLambda25 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ Ref$ObjectRef f$1;

    public /* synthetic */ InfoScreensKt$$ExternalSyntheticLambda25(int i, MainActivity mainActivity, Ref$ObjectRef ref$ObjectRef) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
        this.f$1 = ref$ObjectRef;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.$r8$classId) {
            case 0:
                PhoneSupport phoneSupport = PhoneSupport.INSTANCE;
                MainActivity mainActivity = this.f$0;
                JSONObject act = phoneSupport.act(mainActivity, "state");
                if (!act.optBoolean("open")) {
                    act = null;
                }
                if (act == null) {
                    act = phoneSupport.act(mainActivity, "start");
                }
                mainActivity.ui.post(new InfoScreensKt$$ExternalSyntheticLambda27(this.f$1, act, mainActivity));
                return;
            default:
                PhoneSupport phoneSupport2 = PhoneSupport.INSTANCE;
                MainActivity mainActivity2 = this.f$0;
                mainActivity2.ui.post(new InfoScreensKt$$ExternalSyntheticLambda27(phoneSupport2.act(mainActivity2, "stop"), mainActivity2, this.f$1));
                return;
        }
    }
}
