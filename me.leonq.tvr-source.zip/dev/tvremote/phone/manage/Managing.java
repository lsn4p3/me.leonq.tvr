package dev.tvremote.phone.manage;

import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census;
import dev.tvremote.core.Census$$ExternalSyntheticLambda4;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Words;
import dev.tvremote.core.Words$$ExternalSyntheticLambda1;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.adb.AdbTls;
import dev.tvremote.core.manage.Jobs;
import dev.tvremote.core.manage.Manage;
import dev.tvremote.core.ontv.Launchers;
import dev.tvremote.core.ontv.RemoteLabels;
import dev.tvremote.core.ontv.Setup$$ExternalSyntheticLambda4;
import dev.tvremote.core.ontv.SetupNeed;
import dev.tvremote.core.remote.Vidaa$$ExternalSyntheticLambda3;
import dev.tvremote.core.scenes.Scenes;
import dev.tvremote.core.scenes.VoicePhrases;
import dev.tvremote.core.web.HttpServer;
import dev.tvremote.core.web.WebPage;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda5;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda8;
import dev.tvremote.home.HomeQr$$ExternalSyntheticLambda0;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.WorkService;
import dev.tvremote.phone.picker.PickerScreenKt;
import dev.tvremote.phone.ui.IconButton;
import dev.tvremote.phone.ui.UiKt;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLDecoder;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.SynchronizedLazyImpl;
import kotlin.collections.ArraysKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$ObjectRef;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgressionIterator;
import kotlin.ranges.IntRange;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class Managing {
    public final MainActivity a;
    public PermissionRequest camAsk;
    public int coverB;
    public boolean destroyed;
    public String forHost;
    public HttpServer http;
    public RemoteLabels labels;
    public String lastTab;
    public String lastThen;
    public AdbLink link;
    public boolean loaded;
    public Manage manage;
    public String pending;
    public ValueCallback picking;
    public int port;
    public final String token;
    public final LinearLayout view;
    public WebView web;
    public final SynchronizedLazyImpl webPage$delegate;

    public Managing(MainActivity mainActivity, FrameLayout frameLayout) {
        this.a = mainActivity;
        LinearLayout col = UiKt.col(mainActivity);
        this.view = col;
        String uuid = UUID.randomUUID().toString();
        Intrinsics.checkNotNullExpressionValue(uuid, "toString(...)");
        this.token = StringsKt__StringsJVMKt.replace$default(uuid, "-", "");
        this.webPage$delegate = new SynchronizedLazyImpl(new Managing$$ExternalSyntheticLambda2(this, 0));
        col.setBackgroundColor(UiKt.BG);
        col.setClickable(true);
        TextView label = UiKt.label(mainActivity, Fleet.T("managing.manage_the_tv", new Pair[0]), 20, UiKt.TEXT);
        label.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout linearLayout = new LinearLayout(mainActivity);
        linearLayout.setGravity(16);
        linearLayout.setPadding(UiKt.dp(mainActivity, 16), UiKt.dp(mainActivity, 10), UiKt.dp(mainActivity, 12), UiKt.dp(mainActivity, 6));
        linearLayout.addView(label, new LinearLayout.LayoutParams(0, -2, 1.0f));
        IconButton icon = UiKt.icon(mainActivity, "@close", Fleet.T("common.close", new Pair[0]), UiKt.BTN);
        icon.setOnClickListener(new Guard$$ExternalSyntheticLambda8(2, this));
        linearLayout.addView(icon, new LinearLayout.LayoutParams(UiKt.dp(mainActivity, 48), UiKt.dp(mainActivity, 40)));
        col.addView(linearLayout);
        WebView makeWeb = makeWeb();
        this.web = makeWeb;
        col.addView(makeWeb, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        col.setVisibility(8);
        frameLayout.addView(col, new FrameLayout.LayoutParams(-1, -1));
    }

    public static /* synthetic */ void open$default(Managing managing, String str, String str2, String str3, int i) {
        if ((i & 2) != 0) {
            str2 = null;
        }
        if ((i & 4) != 0) {
            str3 = null;
        }
        managing.open(str, str2, str3);
    }

    public static String size(long j) {
        if (j >= 1048576) {
            return String.format(Locale.ROOT, "%.1f MB", Arrays.copyOf(new Object[]{Double.valueOf(j / 1048576.0d)}, 1));
        }
        return (j / 1024) + " KB";
    }

    public final void bind(String str) {
        AdbLink adbLink = this.link;
        if (adbLink != null) {
            adbLink.close();
        }
        File filesDir = this.a.getFilesDir();
        Intrinsics.checkNotNullExpressionValue(filesDir, "getFilesDir(...)");
        AdbLink adbLink2 = new AdbLink(filesDir, str);
        this.link = adbLink2;
        Managing$$ExternalSyntheticLambda2 managing$$ExternalSyntheticLambda2 = new Managing$$ExternalSyntheticLambda2(this, 3);
        File cacheDir = this.a.getCacheDir();
        Pattern compile = Pattern.compile("[^\\w.-]");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        String replaceAll = compile.matcher(str).replaceAll("_");
        Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
        RemoteLabels remoteLabels = new RemoteLabels(adbLink2, managing$$ExternalSyntheticLambda2, new File(cacheDir, "meta/".concat(replaceAll)));
        this.labels = remoteLabels;
        List list = Launchers.KEYS;
        Launchers.useTestFile(this.a.getExternalFilesDir(null));
        Launchers.dir = new File(this.a.getCacheDir(), "launchers");
        Manage manage = new Manage(adbLink2, remoteLabels, this.a.getCacheDir(), new Managing$$ExternalSyntheticLambda2(this, 4));
        manage.canPair = true;
        manage.jobs.onWork = new Managing$$ExternalSyntheticLambda4(this, 2);
        this.manage = manage;
        this.forHost = str;
        this.loaded = false;
    }

    public final void close() {
        Manage manage = this.manage;
        if (manage != null) {
            manage.jobs.onWork = null;
        }
        this.a.working$android_release("");
        this.view.setVisibility(8);
        this.web.onPause();
        AdbLink adbLink = this.link;
        if (adbLink != null) {
            adbLink.close();
        }
        this.link = null;
        this.labels = null;
        this.manage = null;
        this.forHost = null;
        this.loaded = false;
    }

    public final void cover(boolean z, int i) {
        if (i == this.coverB && !z) {
            return;
        }
        this.coverB = i;
        this.web.evaluateJavascript("document.documentElement.style.setProperty('--cover-b','" + i + "px')", null);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:209:0x00ed, code lost:
    
        if (r0 == null) goto L19;
     */
    /* JADX WARN: Removed duplicated region for block: B:19:0x01aa A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:20:0x01ab  */
    /* JADX WARN: Removed duplicated region for block: B:85:0x05d0  */
    /* JADX WARN: Removed duplicated region for block: B:88:0x05d4  */
    /* JADX WARN: Type inference failed for: r0v86, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final HttpServer.Response handle(HttpServer.Request request) {
        String str;
        byte[] bArr;
        String str2;
        byte[] bArr2;
        HttpServer.Response response;
        String str3;
        String str4;
        HttpServer.Response response2;
        Object obj;
        HttpServer.Response response3;
        JSONArray jSONArray;
        boolean z;
        AdbTls.Wireless wireless;
        JSONObject put;
        AdbLink adbLink;
        HttpServer.Response handle;
        byte[] bArr3;
        JSONArray jSONArray2;
        String str5;
        int i = 0;
        int i2 = 2;
        int i3 = 1;
        if (!Intrinsics.areEqual(this.token, request.cookie("tvr"))) {
            JSONObject m9m = Census$$ExternalSyntheticOutline0.m9m("error", "this page belongs to the TV Remote app", "put(...)");
            HttpServer.Response response4 = new HttpServer.Response();
            response4.status = 403;
            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = HttpServer.trusted;
            response4.body = Census$$ExternalSyntheticOutline0.m("toString(...)", m9m);
            return response4;
        }
        WebPage webPage = (WebPage) this.webPage$delegate.getValue();
        String str6 = request.path;
        String str7 = (String) request.headers.get("accept-encoding");
        if (str7 == null) {
            str7 = "";
        }
        webPage.getClass();
        if (!str6.equals("/") && !str6.equals("/index.html")) {
            str = StringsKt.drop(str6, 1);
        } else {
            str = "index.html";
        }
        String str8 = str;
        if (WebPage.FILE.matches(str8)) {
            if (str8.equals("voice/phrases.json")) {
                VoicePhrases voicePhrases = VoicePhrases.INSTANCE;
                bArr = VoicePhrases.bytes;
            } else {
                bArr = null;
            }
            if (bArr == null) {
                synchronized (webPage.cache) {
                    try {
                        bArr = (byte[]) webPage.cache.get(str8);
                        if (bArr == null) {
                            try {
                                Closeable closeable = (Closeable) webPage.open.invoke(str8);
                                try {
                                    bArr = MathKt.readBytes((InputStream) closeable);
                                    closeable.close();
                                    if (str8.equals("index.html")) {
                                        Charset charset = Charsets.UTF_8;
                                        bArr = WebPage.LINK.replace(StringsKt__StringsJVMKt.replaceFirst$default(new String(bArr, charset), "<html ", "<html data-core=\"phone\" "), new Words$$ExternalSyntheticLambda1(11, webPage)).getBytes(charset);
                                        Intrinsics.checkNotNullExpressionValue(bArr, "getBytes(...)");
                                    }
                                    if (WebPage.room(webPage.cache, bArr.length)) {
                                        webPage.cache.put(str8, bArr);
                                    }
                                } catch (Throwable th) {
                                    try {
                                        throw th;
                                    } catch (Throwable th2) {
                                        MathKt.closeFinally(closeable, th2);
                                        throw th2;
                                    }
                                }
                            } catch (Exception unused) {
                                bArr = null;
                            }
                        }
                    } catch (Throwable th3) {
                        throw th3;
                    }
                }
            }
            String substringAfterLast = StringsKt.substringAfterLast(str8, '.', str8);
            switch (substringAfterLast.hashCode()) {
                case 98819:
                    if (substringAfterLast.equals("css")) {
                        str2 = "text/css; charset=utf-8";
                        break;
                    }
                    str2 = "text/javascript; charset=utf-8";
                    break;
                case 111145:
                    if (substringAfterLast.equals("png")) {
                        str2 = "image/png";
                        break;
                    }
                    str2 = "text/javascript; charset=utf-8";
                    break;
                case 3213227:
                    if (substringAfterLast.equals("html")) {
                        str2 = "text/html; charset=utf-8";
                        break;
                    }
                    str2 = "text/javascript; charset=utf-8";
                    break;
                case 3271912:
                    if (substringAfterLast.equals("json")) {
                        if (!StringsKt__StringsJVMKt.startsWith(str8, false, "i18n/") && !StringsKt__StringsJVMKt.startsWith(str8, false, "voice/")) {
                            str2 = "application/manifest+json";
                            break;
                        } else {
                            str2 = "application/json; charset=utf-8";
                            break;
                        }
                    }
                    str2 = "text/javascript; charset=utf-8";
                    break;
                default:
                    str2 = "text/javascript; charset=utf-8";
                    break;
            }
            if (!StringsKt__StringsJVMKt.endsWith(str8, false, ".png") && bArr.length >= 1024 && WebPage.GZIP.containsMatchIn(str7)) {
                bArr2 = webPage.gzip(str8, bArr);
            } else {
                bArr2 = null;
            }
            if (bArr2 != null) {
                bArr = bArr2;
            }
            response = new HttpServer.Response();
            response.type = str2;
            response.body = bArr;
            if (!StringsKt__StringsJVMKt.endsWith(str8, false, ".png")) {
                response.headers.put("Vary", "Accept-Encoding");
            }
            if (bArr2 != null) {
                response.headers.put("Content-Encoding", "gzip");
            }
            HashMap hashMap = response.headers;
            if (str8.equals("index.html")) {
                str3 = "no-store";
            } else if (str8.equals("voice/phrases.json")) {
                str3 = "max-age=600";
            } else {
                str3 = "max-age=604800";
            }
            hashMap.put("Cache-Control", str3);
            if (response == null) {
                return response;
            }
            if (!request.path.equals("/api/state") && !request.path.equals("/api/about")) {
                if (request.path.equals("/api/support/app")) {
                    PhoneSupport phoneSupport = PhoneSupport.INSTANCE;
                    MainActivity mainActivity = this.a;
                    if (request.method.equals("POST")) {
                        str5 = request.json(65536).optString("act");
                    } else {
                        str5 = "state";
                    }
                    Intrinsics.checkNotNull(str5);
                    JSONObject act = phoneSupport.act(mainActivity, str5);
                    HttpServer.Response response5 = new HttpServer.Response();
                    response5.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda02 = HttpServer.trusted;
                    response5.body = Census$$ExternalSyntheticOutline0.m("toString(...)", act);
                    return response5;
                }
                if (request.path.equals("/api/phone/back") && request.method.equals("POST")) {
                    this.a.ui.post(new Managing$$ExternalSyntheticLambda12(this, i));
                    JSONObject jSONObject = new JSONObject();
                    HttpServer.Response response6 = new HttpServer.Response();
                    response6.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda03 = HttpServer.trusted;
                    response6.body = Census$$ExternalSyntheticOutline0.m("toString(...)", jSONObject);
                    return response6;
                }
                Managing$$ExternalSyntheticLambda2 managing$$ExternalSyntheticLambda2 = new Managing$$ExternalSyntheticLambda2(this, i3);
                Managing$$ExternalSyntheticLambda4 managing$$ExternalSyntheticLambda4 = new Managing$$ExternalSyntheticLambda4(this, i3);
                Census$$ExternalSyntheticLambda4 census$$ExternalSyntheticLambda4 = new Census$$ExternalSyntheticLambda4(16);
                Managing$$ExternalSyntheticLambda2 managing$$ExternalSyntheticLambda22 = new Managing$$ExternalSyntheticLambda2(this, i2);
                Census.Ok ok = new Census.Ok(managing$$ExternalSyntheticLambda2, managing$$ExternalSyntheticLambda4, census$$ExternalSyntheticLambda4, managing$$ExternalSyntheticLambda22);
                AdbLink adbLink2 = this.link;
                if (adbLink2 != null) {
                    ok.video = new Setup$$ExternalSyntheticLambda4(adbLink2, i3);
                    ok.optimize = new Setup$$ExternalSyntheticLambda4(adbLink2, i2);
                }
                if (request.path.equals("/api/scenes")) {
                    boolean equals = request.method.equals("POST");
                    if (equals) {
                        jSONArray2 = request.json(65536).optJSONArray("scenes");
                    } else {
                        jSONArray2 = null;
                    }
                    if (equals && jSONArray2 == null) {
                        JSONObject m9m2 = Census$$ExternalSyntheticOutline0.m9m("error", "scenes required", "put(...)");
                        response2 = new HttpServer.Response();
                        response2.status = 400;
                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda04 = HttpServer.trusted;
                        response2.body = Census$$ExternalSyntheticOutline0.m("toString(...)", m9m2);
                    } else {
                        if (jSONArray2 != null) {
                            HashMap hashMap2 = Scenes.KEYS;
                            JSONArray clean = Scenes.clean(jSONArray2);
                            managing$$ExternalSyntheticLambda4.invoke(clean);
                            Setup$$ExternalSyntheticLambda4 setup$$ExternalSyntheticLambda4 = (Setup$$ExternalSyntheticLambda4) ok.optimize;
                            if (setup$$ExternalSyntheticLambda4 != null) {
                                setup$$ExternalSyntheticLambda4.invoke(clean);
                            }
                        }
                        if (request.query.containsKey("download")) {
                            HashMap hashMap3 = Scenes.KEYS;
                            String jSONObject2 = Census$$ExternalSyntheticOutline0.m10m("app", "tv-remote", "kind", "scenes").put("version", 1).put("scenes", (JSONArray) managing$$ExternalSyntheticLambda2.invoke()).toString(2);
                            Intrinsics.checkNotNull(jSONObject2);
                            byte[] bytes = jSONObject2.getBytes(Charsets.UTF_8);
                            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                            response2 = new HttpServer.Response();
                            response2.type = "application/json; charset=utf-8";
                            response2.body = bytes;
                            String m = ApkSigner$$ExternalSyntheticOutline0.m("tv-remote-scenes-", new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()), ".json");
                            response2.headers.put("Content-Disposition", Census$$ExternalSyntheticOutline0.m("attachment; filename=\"", m, "\"; filename*=UTF-8''", m));
                        } else {
                            JSONObject put2 = new JSONObject().put("scenes", managing$$ExternalSyntheticLambda2.invoke());
                            Intrinsics.checkNotNullExpressionValue(put2, "put(...)");
                            response2 = new HttpServer.Response();
                            response2.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda05 = HttpServer.trusted;
                            response2.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put2);
                        }
                    }
                } else if (request.path.equals("/api/scene/run") && request.method.equals("POST")) {
                    HashMap hashMap4 = Scenes.KEYS;
                    JSONObject json = request.json(65536);
                    Words$$ExternalSyntheticLambda1 words$$ExternalSyntheticLambda1 = new Words$$ExternalSyntheticLambda1(10, ok);
                    JSONArray optJSONArray = json.optJSONArray("steps");
                    if (optJSONArray == null) {
                        String optString = json.optString("id");
                        Intrinsics.checkNotNullExpressionValue(optString, "optString(...)");
                        JSONObject jSONObject3 = (JSONObject) words$$ExternalSyntheticLambda1.invoke(optString);
                        if (jSONObject3 != null) {
                            optJSONArray = jSONObject3.optJSONArray("steps");
                        } else {
                            optJSONArray = null;
                        }
                        if (optJSONArray == null) {
                            JSONObject m9m3 = Census$$ExternalSyntheticOutline0.m9m("error", "no such scene", "put(...)");
                            response2 = new HttpServer.Response();
                            response2.status = 404;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda06 = HttpServer.trusted;
                            response2.body = Census$$ExternalSyntheticOutline0.m("toString(...)", m9m3);
                        }
                    }
                    final Scenes.Target target = (Scenes.Target) managing$$ExternalSyntheticLambda22.invoke();
                    if (target == null) {
                        JSONObject m9m4 = Census$$ExternalSyntheticOutline0.m9m("error", "adb: not connected", "put(...)");
                        response2 = new HttpServer.Response();
                        response2.status = 503;
                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda07 = HttpServer.trusted;
                        response2.body = Census$$ExternalSyntheticOutline0.m("toString(...)", m9m4);
                    } else {
                        final ?? obj2 = new Object();
                        Scenes.Target target2 = new Scenes.Target(obj2) { // from class: dev.tvremote.core.scenes.Scenes$runRequest$watched$1
                            public final /* synthetic */ Scenes.Target $$delegate_0;
                            public final /* synthetic */ Ref$ObjectRef $missing;

                            {
                                this.$missing = obj2;
                                this.$$delegate_0 = Scenes.Target.this;
                            }

                            @Override // dev.tvremote.core.scenes.Scenes.Target
                            public final void app(String str9) {
                                this.$$delegate_0.app(str9);
                            }

                            @Override // dev.tvremote.core.scenes.Scenes.Target
                            public final void input(String str9) {
                                this.$$delegate_0.input(str9);
                            }

                            @Override // dev.tvremote.core.scenes.Scenes.Target
                            public final void key(int i4) {
                                this.$$delegate_0.key(i4);
                            }

                            @Override // dev.tvremote.core.scenes.Scenes.Target
                            public final void link(String str9) {
                                this.$$delegate_0.link(str9);
                            }

                            @Override // dev.tvremote.core.scenes.Scenes.Target
                            public final void notify(JSONObject jSONObject4) {
                                this.$$delegate_0.notify(jSONObject4);
                            }

                            @Override // dev.tvremote.core.scenes.Scenes.Target
                            public final void timer(int i4) {
                                try {
                                    Scenes.Target.this.timer(i4);
                                } catch (SetupNeed.Missing e) {
                                    this.$missing.element = e;
                                    throw e;
                                }
                            }

                            @Override // dev.tvremote.core.scenes.Scenes.Target
                            public final void volume(int i4) {
                                this.$$delegate_0.volume(i4);
                            }
                        };
                        JSONArray put3 = new JSONArray().put(new JSONObject().put("name", "x").put("steps", optJSONArray));
                        Intrinsics.checkNotNullExpressionValue(put3, "put(...)");
                        JSONObject optJSONObject = Scenes.clean(put3).optJSONObject(0);
                        if (optJSONObject == null || (jSONArray = optJSONObject.optJSONArray("steps")) == null) {
                            jSONArray = new JSONArray();
                        }
                        String run$default = Scenes.run$default(jSONArray, target2);
                        SetupNeed.Missing missing = (SetupNeed.Missing) obj2.element;
                        if (missing != null) {
                            JSONObject m9m5 = Census$$ExternalSyntheticOutline0.m9m("error", String.valueOf(missing.getMessage()), "put(...)");
                            response2 = new HttpServer.Response();
                            response2.status = 409;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda08 = HttpServer.trusted;
                            response2.body = Census$$ExternalSyntheticOutline0.m("toString(...)", m9m5);
                        } else {
                            JSONObject jSONObject4 = new JSONObject();
                            if (run$default == null) {
                                z = true;
                            } else {
                                z = false;
                            }
                            JSONObject put4 = jSONObject4.put("ok", z);
                            if (run$default == null) {
                                run$default = "";
                            }
                            JSONObject put5 = put4.put("failed", run$default);
                            Intrinsics.checkNotNullExpressionValue(put5, "put(...)");
                            response2 = new HttpServer.Response();
                            response2.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda09 = HttpServer.trusted;
                            response2.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put5);
                        }
                    }
                } else if (request.path.equals("/api/scene/pin") && request.method.equals("POST") && ((Setup$$ExternalSyntheticLambda4) ok.video) != null) {
                    JSONObject json2 = request.json(65536);
                    Setup$$ExternalSyntheticLambda4 setup$$ExternalSyntheticLambda42 = (Setup$$ExternalSyntheticLambda4) ok.video;
                    Intrinsics.checkNotNull(setup$$ExternalSyntheticLambda42);
                    JSONArray jSONArray3 = (JSONArray) managing$$ExternalSyntheticLambda2.invoke();
                    IntRange until = MathKt.until(0, jSONArray3.length());
                    ArrayList arrayList = new ArrayList();
                    Iterator it = until.iterator();
                    while (((IntProgressionIterator) it).hasNext) {
                        JSONObject optJSONObject2 = jSONArray3.optJSONObject(((IntProgressionIterator) it).nextInt());
                        if (optJSONObject2 != null) {
                            arrayList.add(optJSONObject2);
                        }
                    }
                    Iterator it2 = arrayList.iterator();
                    while (true) {
                        if (it2.hasNext()) {
                            obj = it2.next();
                            JSONObject jSONObject5 = (JSONObject) obj;
                            if (json2.has("steps") || !Intrinsics.areEqual(jSONObject5.optString("id"), json2.optString("id"))) {
                            }
                        } else {
                            obj = null;
                        }
                    }
                    JSONObject jSONObject6 = (JSONObject) obj;
                    HashMap hashMap5 = Scenes.KEYS;
                    JSONArray jSONArray4 = new JSONArray();
                    if (jSONObject6 != null) {
                        json2 = jSONObject6;
                    }
                    JSONArray put6 = jSONArray4.put(json2);
                    Intrinsics.checkNotNullExpressionValue(put6, "put(...)");
                    JSONObject optJSONObject3 = Scenes.clean(put6).optJSONObject(0);
                    if (optJSONObject3 == null) {
                        JSONObject m9m6 = Census$$ExternalSyntheticOutline0.m9m("error", "no scene", "put(...)");
                        response3 = new HttpServer.Response();
                        response3.status = 400;
                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda010 = HttpServer.trusted;
                        response3.body = Census$$ExternalSyntheticOutline0.m("toString(...)", m9m6);
                    } else {
                        try {
                            JSONObject jSONObject7 = (JSONObject) setup$$ExternalSyntheticLambda42.invoke(optJSONObject3);
                            if (jSONObject7.has("error")) {
                                String optString2 = jSONObject7.optString("error");
                                Intrinsics.checkNotNullExpressionValue(optString2, "optString(...)");
                                JSONObject put7 = new JSONObject().put("error", optString2);
                                Intrinsics.checkNotNullExpressionValue(put7, "put(...)");
                                response2 = new HttpServer.Response();
                                response2.status = 501;
                                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda011 = HttpServer.trusted;
                                String jSONObject8 = put7.toString();
                                Intrinsics.checkNotNullExpressionValue(jSONObject8, "toString(...)");
                                response2.body = WorkService.Companion.bytes(jSONObject8);
                            } else {
                                response2 = new HttpServer.Response();
                                response2.status = 200;
                                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda012 = HttpServer.trusted;
                                String jSONObject9 = jSONObject7.toString();
                                Intrinsics.checkNotNullExpressionValue(jSONObject9, "toString(...)");
                                response2.body = WorkService.Companion.bytes(jSONObject9);
                            }
                        } catch (SetupNeed.Missing e) {
                            JSONObject m9m7 = Census$$ExternalSyntheticOutline0.m9m("error", String.valueOf(e.getMessage()), "put(...)");
                            HttpServer.Response response7 = new HttpServer.Response();
                            response7.status = 409;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda013 = HttpServer.trusted;
                            response7.body = Census$$ExternalSyntheticOutline0.m("toString(...)", m9m7);
                            response3 = response7;
                        } catch (Exception e2) {
                            String message = e2.getMessage();
                            if (message == null) {
                                message = "no answer";
                            }
                            JSONObject m9m8 = Census$$ExternalSyntheticOutline0.m9m("error", message, "put(...)");
                            response3 = new HttpServer.Response();
                            response3.status = 503;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda014 = HttpServer.trusted;
                            response3.body = Census$$ExternalSyntheticOutline0.m("toString(...)", m9m8);
                        }
                    }
                    response2 = response3;
                } else {
                    response2 = null;
                }
                if (response2 != null) {
                    return response2;
                }
                if (request.path.equals("/api/watchers")) {
                    try {
                        adbLink = this.link;
                    } catch (Exception unused2) {
                    }
                    if (adbLink != null) {
                        Adb adb = adbLink.get();
                        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                        String shell = adb.shell(120000L, "ps -A -o ARGS 2>/dev/null");
                        if (shell != null) {
                            wireless = Fleet.parse(shell);
                            if (wireless != null) {
                                put = new JSONObject();
                            } else {
                                put = new JSONObject().put("watch", wireless.connect).put("listen", wireless.pairing);
                            }
                            Intrinsics.checkNotNull(put);
                            HttpServer.Response response8 = new HttpServer.Response();
                            response8.status = 200;
                            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda015 = HttpServer.trusted;
                            response8.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put);
                            return response8;
                        }
                    }
                    wireless = null;
                    if (wireless != null) {
                    }
                    Intrinsics.checkNotNull(put);
                    HttpServer.Response response82 = new HttpServer.Response();
                    response82.status = 200;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0152 = HttpServer.trusted;
                    response82.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put);
                    return response82;
                }
                if (request.path.equals("/api/app/icon")) {
                    String str9 = (String) request.query.get("pkg");
                    if (str9 != null) {
                        if (str9.length() <= 0) {
                            str9 = null;
                        }
                        if (str9 != null) {
                            RemoteLabels remoteLabels = this.labels;
                            if (remoteLabels != null) {
                                bArr3 = remoteLabels.icon(str9);
                            } else {
                                bArr3 = null;
                            }
                            if (bArr3 != null) {
                                HttpServer.Response response9 = new HttpServer.Response();
                                response9.type = "image/png";
                                response9.body = bArr3;
                                response9.headers.put("Cache-Control", "max-age=86400");
                                return response9;
                            }
                        }
                    }
                    JSONObject m9m9 = Census$$ExternalSyntheticOutline0.m9m("error", "no icon", "put(...)");
                    HttpServer.Response response10 = new HttpServer.Response();
                    response10.status = 404;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda016 = HttpServer.trusted;
                    response10.body = Census$$ExternalSyntheticOutline0.m("toString(...)", m9m9);
                    return response10;
                }
                Manage manage = this.manage;
                if (manage == null || (handle = manage.handle(request)) == null) {
                    JSONObject m9m10 = Census$$ExternalSyntheticOutline0.m9m("error", "not found", "put(...)");
                    HttpServer.Response response11 = new HttpServer.Response();
                    response11.status = 404;
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda017 = HttpServer.trusted;
                    response11.body = Census$$ExternalSyntheticOutline0.m("toString(...)", m9m10);
                    return response11;
                }
                return handle;
            }
            JSONObject m8m = Census$$ExternalSyntheticOutline0.m8m("core", "phone");
            String str10 = this.forHost;
            if (str10 == null) {
                str10 = "";
            }
            JSONObject put8 = m8m.put("host", str10);
            MainActivity mainActivity2 = this.a;
            String str11 = this.forHost;
            if (str11 == null) {
                str11 = "";
            }
            JSONObject put9 = put8.put("name", PickerScreenKt.name(mainActivity2, str11)).put("connected", true).put("is_on", true).put("paired", true);
            JSONObject jSONObject10 = new JSONObject();
            Manage manage2 = this.manage;
            if (manage2 != null) {
                str4 = manage2.link.state();
            } else {
                str4 = "unknown";
            }
            JSONObject put10 = put9.put("adb", jSONObject10.put("state", str4)).put("app_name", "TV Remote").put("version", UpdaterKt.version(this.a)).put("released", UpdaterKt.released(this.a));
            Intrinsics.checkNotNullExpressionValue(put10, "put(...)");
            HttpServer.Response response12 = new HttpServer.Response();
            response12.status = 200;
            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda018 = HttpServer.trusted;
            response12.body = Census$$ExternalSyntheticOutline0.m("toString(...)", put10);
            return response12;
        }
        response = null;
        if (response == null) {
        }
    }

    public final WebView makeWeb() {
        WebView webView = new WebView(this.a);
        webView.setBackgroundColor(UiKt.BG);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient() { // from class: dev.tvremote.phone.manage.Managing$makeWeb$1
            @Override // android.webkit.WebViewClient
            public final void onPageFinished(WebView webView2, String str) {
                Managing managing = Managing.this;
                String str2 = managing.pending;
                if (str2 != null) {
                    managing.pending = null;
                    managing.web.evaluateJavascript(str2, null);
                }
                managing.cover(true, managing.coverB);
            }

            @Override // android.webkit.WebViewClient
            public final boolean onRenderProcessGone(WebView webView2, RenderProcessGoneDetail renderProcessGoneDetail) {
                Managing managing = Managing.this;
                if (webView2 == managing.web) {
                    managing.a.ui.post(new Managing$$ExternalSyntheticLambda12(managing, 1));
                    return true;
                }
                return true;
            }

            @Override // android.webkit.WebViewClient
            public final boolean shouldOverrideUrlLoading(WebView webView2, WebResourceRequest webResourceRequest) {
                Uri url;
                if (webResourceRequest == null || (url = webResourceRequest.getUrl()) == null || Intrinsics.areEqual(url.getHost(), "127.0.0.1")) {
                    return false;
                }
                MainActivity mainActivity = Managing.this.a;
                String uri = url.toString();
                Intrinsics.checkNotNullExpressionValue(uri, "toString(...)");
                Fleet.web(mainActivity, uri);
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() { // from class: dev.tvremote.phone.manage.Managing$makeWeb$2
            @Override // android.webkit.WebChromeClient
            public final void onPermissionRequest(PermissionRequest req) {
                String str;
                int checkSelfPermission;
                Intrinsics.checkNotNullParameter(req, "req");
                Uri origin = req.getOrigin();
                if (origin != null) {
                    str = origin.getHost();
                } else {
                    str = null;
                }
                if (Intrinsics.areEqual(str, "127.0.0.1")) {
                    String[] resources = req.getResources();
                    Intrinsics.checkNotNullExpressionValue(resources, "getResources(...)");
                    if (ArraysKt.contains("android.webkit.resource.VIDEO_CAPTURE", resources)) {
                        if (Build.VERSION.SDK_INT >= 23) {
                            Managing managing = Managing.this;
                            checkSelfPermission = managing.a.checkSelfPermission("android.permission.CAMERA");
                            if (checkSelfPermission != 0) {
                                PermissionRequest permissionRequest = managing.camAsk;
                                if (permissionRequest != null) {
                                    permissionRequest.deny();
                                }
                                managing.camAsk = req;
                                managing.a.requestPermissions(new String[]{"android.permission.CAMERA"}, 32);
                                return;
                            }
                        }
                        req.grant(new String[]{"android.webkit.resource.VIDEO_CAPTURE"});
                        return;
                    }
                }
                req.deny();
            }

            @Override // android.webkit.WebChromeClient
            public final void onPermissionRequestCanceled(PermissionRequest permissionRequest) {
                Managing managing = Managing.this;
                if (managing.camAsk == permissionRequest) {
                    managing.camAsk = null;
                }
            }

            @Override // android.webkit.WebChromeClient
            public final boolean onShowFileChooser(WebView webView2, ValueCallback valueCallback, WebChromeClient.FileChooserParams fileChooserParams) {
                Managing managing = Managing.this;
                ValueCallback valueCallback2 = managing.picking;
                if (valueCallback2 != null) {
                    valueCallback2.onReceiveValue(null);
                }
                managing.picking = valueCallback;
                try {
                    MainActivity mainActivity = managing.a;
                    Intrinsics.checkNotNull(fileChooserParams);
                    mainActivity.startActivityForResult(fileChooserParams.createIntent(), 77);
                    return true;
                } catch (Exception unused) {
                    managing.picking = null;
                    return false;
                }
            }
        });
        webView.setDownloadListener(new DownloadListener() { // from class: dev.tvremote.phone.manage.Managing$$ExternalSyntheticLambda5
            /* JADX WARN: Type inference failed for: r10v1, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
            @Override // android.webkit.DownloadListener
            public final void onDownloadStart(String str, String str2, String str3, String str4, long j) {
                Intrinsics.checkNotNull(str);
                Managing managing = Managing.this;
                managing.getClass();
                ?? obj = new Object();
                obj.element = "file";
                try {
                    Matcher matcher = Pattern.compile("filename\\*=UTF-8''([^;]+)").matcher(String.valueOf(str3));
                    if (matcher.find()) {
                        String decode = URLDecoder.decode(matcher.group(1), "UTF-8");
                        Intrinsics.checkNotNullExpressionValue(decode, "decode(...)");
                        obj.element = decode;
                    }
                } catch (Exception unused) {
                }
                String m = ApkSigner$$ExternalSyntheticOutline0.m(System.nanoTime(), "dl");
                managing.a.ui.post(new Guard$$ExternalSyntheticLambda5(22, managing, Census$$ExternalSyntheticOutline0.m8m("id", m).put("label", obj.element).put("status", "running").put("pct", -1).put("msg", Fleet.T("managing.downloading_to_the_phone", new Pair[0]))));
                new Thread(new Vidaa$$ExternalSyntheticLambda3(str, (Object) managing, (Object) obj, m, 2)).start();
            }
        });
        return webView;
    }

    /* JADX WARN: Code restructure failed: missing block: B:46:0x00ea, code lost:
    
        r11 = r10.web;
        r2 = new java.lang.StringBuilder();
        r3 = r12.length();
        r4 = 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x00f6, code lost:
    
        if (r4 >= r3) goto L61;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x00f8, code lost:
    
        r5 = r12.charAt(r4);
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x0100, code lost:
    
        if (java.lang.Character.isLetter(r5) == false) goto L63;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x0102, code lost:
    
        r2.append(r5);
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x0105, code lost:
    
        r4 = r4 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:55:0x0107, code lost:
    
        r11.evaluateJavascript("showTab('" + r2.toString() + "')", null);
     */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0039  */
    /* JADX WARN: Removed duplicated region for block: B:14:0x003d A[Catch: Exception -> 0x002f, TryCatch #0 {Exception -> 0x002f, blocks: (B:5:0x0012, B:7:0x0017, B:19:0x002a, B:10:0x0033, B:14:0x003d, B:15:0x0046, B:16:0x0042, B:22:0x005b, B:24:0x0063, B:25:0x0066, B:27:0x006a, B:31:0x00a2, B:32:0x00a9, B:33:0x012b, B:39:0x00cc, B:41:0x00d0, B:44:0x00d5, B:46:0x00ea, B:48:0x00f8, B:50:0x0102, B:52:0x0105, B:55:0x0107, B:57:0x0126), top: B:4:0x0012 }] */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0042 A[Catch: Exception -> 0x002f, TryCatch #0 {Exception -> 0x002f, blocks: (B:5:0x0012, B:7:0x0017, B:19:0x002a, B:10:0x0033, B:14:0x003d, B:15:0x0046, B:16:0x0042, B:22:0x005b, B:24:0x0063, B:25:0x0066, B:27:0x006a, B:31:0x00a2, B:32:0x00a9, B:33:0x012b, B:39:0x00cc, B:41:0x00d0, B:44:0x00d5, B:46:0x00ea, B:48:0x00f8, B:50:0x0102, B:52:0x0105, B:55:0x0107, B:57:0x0126), top: B:4:0x0012 }] */
    /* JADX WARN: Removed duplicated region for block: B:17:0x003a  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void open(String str, String str2, String str3) {
        Adb adb;
        String str4;
        String str5;
        int start$default;
        Integer valueOf;
        int start$default2;
        if (str != null) {
            this.lastTab = str2;
            this.lastThen = str3;
            try {
                if (this.http == null) {
                    HttpServer httpServer = new HttpServer(this);
                    this.http = httpServer;
                    int i = this.a.getPrefs$android_release().getInt("managePort", 0);
                    if (i > 0) {
                        try {
                            start$default = HttpServer.start$default(httpServer, i);
                        } catch (IOException unused) {
                        }
                        valueOf = Integer.valueOf(start$default);
                        if (start$default > 0) {
                            valueOf = null;
                        }
                        if (valueOf == null) {
                            start$default2 = valueOf.intValue();
                        } else {
                            start$default2 = HttpServer.start$default(httpServer, 0);
                        }
                        this.port = start$default2;
                        this.a.getPrefs$android_release().edit().putInt("managePort", this.port).apply();
                    }
                    start$default = 0;
                    valueOf = Integer.valueOf(start$default);
                    if (start$default > 0) {
                    }
                    if (valueOf == null) {
                    }
                    this.port = start$default2;
                    this.a.getPrefs$android_release().edit().putInt("managePort", this.port).apply();
                }
                if (!str.equals(this.forHost)) {
                    bind(str);
                }
                if (!this.loaded) {
                    this.loaded = true;
                    String str6 = "http://127.0.0.1:" + this.port;
                    CookieManager.getInstance().setCookie(str6, "tvr=" + this.token);
                    this.pending = str3;
                    WebView webView = this.web;
                    ConcurrentHashMap concurrentHashMap = Words.books;
                    String str7 = Words.lang;
                    if (UiKt.LIGHT) {
                        str4 = "light";
                    } else {
                        str4 = "dark";
                    }
                    if (str2 != null) {
                        str5 = "#".concat(str2);
                    } else {
                        str5 = "";
                    }
                    webView.loadUrl(str6 + "/?embed=1&lang=" + str7 + "&theme=" + str4 + str5);
                } else {
                    AdbLink adbLink = this.link;
                    if (adbLink != null && (adb = adbLink.adb) != null) {
                        Thread thread = new Thread(new Guard$$ExternalSyntheticLambda5(4, adb, adbLink), "adb-check");
                        thread.setDaemon(true);
                        thread.start();
                    }
                    if (str3 != null) {
                        this.web.evaluateJavascript(str3, null);
                    }
                }
                this.view.setVisibility(0);
                this.web.onResume();
            } catch (Exception e) {
                PickerScreenKt.message(this.a, Fleet.T("managing.could_not_open_the", new Pair("error", e.getMessage())), true);
            }
        }
    }

    public final int progress() {
        Manage manage = this.manage;
        int i = -1;
        if (manage == null) {
            return -1;
        }
        Jobs jobs = manage.jobs;
        synchronized (jobs.all) {
            try {
                Object obj = null;
                for (Object obj2 : jobs.all.values()) {
                    if (Intrinsics.areEqual(((JSONObject) obj2).optString("status"), "running")) {
                        obj = obj2;
                    }
                }
                JSONObject jSONObject = (JSONObject) obj;
                if (jSONObject != null) {
                    i = jSONObject.optInt("pct", -1);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return i;
    }
}
