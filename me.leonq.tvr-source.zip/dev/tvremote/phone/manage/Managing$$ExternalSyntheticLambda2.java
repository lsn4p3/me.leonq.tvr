package dev.tvremote.phone.manage;

import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.ontv.Setup$$ExternalSyntheticLambda4;
import dev.tvremote.core.scenes.Scenes;
import dev.tvremote.core.web.WebPage;
import dev.tvremote.phone.MainActivity;
import java.io.InputStream;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import org.json.JSONArray;

/* loaded from: classes.dex */
public final /* synthetic */ class Managing$$ExternalSyntheticLambda2 implements Function0 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Managing f$0;

    public /* synthetic */ Managing$$ExternalSyntheticLambda2(Managing managing, int i) {
        this.$r8$classId = i;
        this.f$0 = managing;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        long j;
        InputStream open;
        switch (this.$r8$classId) {
            case 0:
                Managing managing = this.f$0;
                Managing$$ExternalSyntheticLambda4 managing$$ExternalSyntheticLambda4 = new Managing$$ExternalSyntheticLambda4(managing, 0);
                MainActivity mainActivity = managing.a;
                String version = UpdaterKt.version(mainActivity);
                try {
                    j = mainActivity.getPackageManager().getPackageInfo(mainActivity.getPackageName(), 0).lastUpdateTime / 1000;
                } catch (Exception unused) {
                    j = 0;
                }
                return new WebPage(managing$$ExternalSyntheticLambda4, version + "-" + j);
            case 1:
                MainActivity c = this.f$0.a;
                Intrinsics.checkNotNullParameter(c, "c");
                try {
                    return new JSONArray(c.getSharedPreferences("scenes", 0).getString("list", "[]"));
                } catch (Exception unused2) {
                    return new JSONArray();
                }
            case 2:
                AdbLink adbLink = this.f$0.link;
                if (adbLink != null) {
                    return new Scenes.Shell(new Setup$$ExternalSyntheticLambda4(adbLink, 4));
                }
                return null;
            case 3:
                open = this.f$0.a.getAssets().open("tvr-helper.jar");
                try {
                    Intrinsics.checkNotNull(open);
                    byte[] readBytes = MathKt.readBytes(open);
                    MathKt.closeFinally(open, null);
                    return readBytes;
                } finally {
                }
            default:
                open = this.f$0.a.getAssets().open("tvr-helper.jar");
                try {
                    Intrinsics.checkNotNull(open);
                    byte[] readBytes2 = MathKt.readBytes(open);
                    MathKt.closeFinally(open, null);
                    return readBytes2;
                } finally {
                }
        }
    }
}
