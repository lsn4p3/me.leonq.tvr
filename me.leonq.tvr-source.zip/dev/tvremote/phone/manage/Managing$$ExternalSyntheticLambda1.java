package dev.tvremote.phone.manage;

import android.webkit.ValueCallback;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.phone.MainActivity;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.StringsKt;

/* loaded from: classes.dex */
public final /* synthetic */ class Managing$$ExternalSyntheticLambda1 implements ValueCallback {
    public final /* synthetic */ Managing f$0;

    @Override // android.webkit.ValueCallback
    public final void onReceiveValue(Object obj) {
        String str;
        String str2;
        Managing managing = this.f$0;
        String str3 = (String) obj;
        if (str3 == null || (str = StringsKt.trim(str3, '\"')) == null) {
            str = "";
        }
        if (str.length() > 0) {
            managing.a.getPrefs$android_release().edit().putString("setupUndo", str).apply();
        }
        MainActivity mainActivity = managing.a;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Tv tv = mainActivity.tv;
        if (tv != null && (str2 = mainActivity.host) != null && !mainActivity.isFinishing() && tv.ready()) {
            MathKt.checkSetup(tv, mainActivity, str2);
        }
    }
}
