package dev.tvremote.phone.manage;

import android.webkit.ValueCallback;
import android.webkit.WebView;
import android.widget.LinearLayout;

/* loaded from: classes.dex */
public final /* synthetic */ class Managing$$ExternalSyntheticLambda12 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Managing f$0;

    public /* synthetic */ Managing$$ExternalSyntheticLambda12(Managing managing, int i) {
        this.$r8$classId = i;
        this.f$0 = managing;
    }

    @Override // java.lang.Runnable
    public final void run() {
        WebView webView;
        LinearLayout linearLayout;
        int indexOfChild;
        switch (this.$r8$classId) {
            case 0:
                Managing managing = this.f$0;
                LinearLayout linearLayout2 = managing.view;
                if (linearLayout2.getVisibility() == 0) {
                    linearLayout2.setVisibility(8);
                    managing.web.onPause();
                    managing.web.evaluateJavascript("(function(){ try { return localStorage.getItem('setupUndo') || '' } catch (e) { return '' } })()", new Managing$$ExternalSyntheticLambda1(managing));
                    return;
                }
                return;
            default:
                Managing managing2 = this.f$0;
                if (!managing2.destroyed && (indexOfChild = (linearLayout = managing2.view).indexOfChild((webView = managing2.web))) >= 0) {
                    linearLayout.removeViewAt(indexOfChild);
                    try {
                        webView.destroy();
                    } catch (Exception unused) {
                    }
                    WebView makeWeb = managing2.makeWeb();
                    managing2.web = makeWeb;
                    linearLayout.addView(makeWeb, indexOfChild, new LinearLayout.LayoutParams(-1, 0, 1.0f));
                    managing2.loaded = false;
                    managing2.pending = null;
                    try {
                        ValueCallback valueCallback = managing2.picking;
                        if (valueCallback != null) {
                            valueCallback.onReceiveValue(null);
                        }
                    } catch (Exception unused2) {
                    }
                    managing2.picking = null;
                    if (linearLayout.getVisibility() == 0) {
                        managing2.open(managing2.forHost, managing2.lastTab, managing2.lastThen);
                        return;
                    }
                    return;
                }
                return;
        }
    }
}
