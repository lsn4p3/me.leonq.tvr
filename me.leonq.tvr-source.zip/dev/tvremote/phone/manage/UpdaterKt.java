package dev.tvremote.phone.manage;

import android.content.Intent;
import android.os.Build;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Words;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda30;
import dev.tvremote.phone.picker.PickerScreenKt;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.phone.ui.UiKt;
import dev.tvremote.update.Release;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyList;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex$$ExternalSyntheticLambda0;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;

/* loaded from: classes.dex */
public abstract class UpdaterKt {
    public static final List PHONE_NOTES = CollectionsKt__CollectionsKt.listOf((Object[]) new String[]{"app điện thoại", "điện thoại và", "phone app", "phone and"});

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r10v6, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    /* JADX WARN: Type inference failed for: r14v2, types: [kotlin.collections.EmptyList] */
    /* JADX WARN: Type inference failed for: r14v7 */
    /* JADX WARN: Type inference failed for: r14v8, types: [java.util.ArrayList] */
    /* JADX WARN: Type inference failed for: r9v25, types: [java.util.ArrayList] */
    /* JADX WARN: Type inference failed for: r9v6, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r9v7, types: [java.lang.Iterable] */
    public static final void askUpdate(MainActivity mainActivity) {
        char c;
        int i;
        String str;
        int i2 = 0;
        Release release = mainActivity.update;
        if (release != null && !mainActivity.updating) {
            LinearLayout col = UiKt.col(mainActivity);
            float f = 24;
            col.setPadding(UiKt.dp(mainActivity, f), 0, UiKt.dp(mainActivity, f), 0);
            col.addView(UiKt.label(mainActivity, Fleet.T("updater.using", new Pair("current", version(mainActivity))), 14, UiKt.MUTED));
            ?? obj = new Object();
            UpdaterKt$$ExternalSyntheticLambda6 updaterKt$$ExternalSyntheticLambda6 = new UpdaterKt$$ExternalSyntheticLambda6(i2, mainActivity, obj);
            obj.element = UiKt.row(mainActivity, "", new Regex$$ExternalSyntheticLambda0(11, mainActivity, updaterKt$$ExternalSyntheticLambda6));
            updaterKt$$ExternalSyntheticLambda6.invoke();
            Object obj2 = obj.element;
            if (obj2 != null) {
                ((Button) obj2).setBackground(UiKt.box(mainActivity, UiKt.BTN, 14));
                Object obj3 = obj.element;
                if (obj3 != null) {
                    col.addView((Button) obj3, UiKt.gap(mainActivity, 12));
                    TextView note = UiKt.note(mainActivity, Fleet.T("updater.auto_note", new Pair[0]));
                    float f2 = 4;
                    note.setPadding(UiKt.dp(mainActivity, f2), UiKt.dp(mainActivity, 6), UiKt.dp(mainActivity, f2), 0);
                    col.addView(note);
                    List list = Release.KEYS;
                    String notes = release.notes;
                    ConcurrentHashMap concurrentHashMap = Words.books;
                    boolean areEqual = Intrinsics.areEqual(Words.lang, "vi");
                    List prefer = PHONE_NOTES;
                    ?? r14 = EmptyList.INSTANCE;
                    Intrinsics.checkNotNullParameter(notes, "notes");
                    Intrinsics.checkNotNullParameter(prefer, "prefer");
                    ?? lines = StringsKt.lines(StringsKt__StringsJVMKt.replace$default(notes, "\r", ""));
                    Pattern compile = Pattern.compile("^\\*\\*(.+)\\*\\*$");
                    Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                    Iterator it = lines.iterator();
                    int i3 = 0;
                    while (true) {
                        if (it.hasNext()) {
                            String obj4 = StringsKt.trim((String) it.next()).toString();
                            if (areEqual) {
                                str = "**Tiếng Việt**";
                            } else {
                                str = "**English**";
                            }
                            c = 1;
                            if (Intrinsics.areEqual(obj4, str)) {
                                break;
                            } else {
                                i3++;
                            }
                        } else {
                            c = 1;
                            i3 = -1;
                            break;
                        }
                    }
                    if (i3 >= 0) {
                        List drop = CollectionsKt.drop(i3 + 1, lines);
                        lines = new ArrayList();
                        for (Object obj5 : drop) {
                            String input = StringsKt.trim((String) obj5).toString();
                            Intrinsics.checkNotNullParameter(input, "input");
                            if (compile.matcher(input).matches()) {
                                break;
                            } else {
                                lines.add(obj5);
                            }
                        }
                    }
                    ArrayList arrayList = new ArrayList();
                    for (Object obj6 : lines) {
                        if (StringsKt__StringsJVMKt.startsWith((String) obj6, false, "- ")) {
                            arrayList.add(obj6);
                        }
                    }
                    ArrayList<String> arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList));
                    Iterator it2 = arrayList.iterator();
                    while (it2.hasNext()) {
                        String substring = ((String) it2.next()).substring(2);
                        Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
                        arrayList2.add(substring);
                    }
                    if (arrayList2.isEmpty()) {
                        if (i3 < 0) {
                            r14 = new ArrayList();
                            for (Object obj7 : lines) {
                                String str2 = (String) obj7;
                                if (!StringsKt.isBlank(str2)) {
                                    String input2 = StringsKt.trim(str2).toString();
                                    Intrinsics.checkNotNullParameter(input2, "input");
                                    if (!compile.matcher(input2).matches()) {
                                        r14.add(obj7);
                                    }
                                }
                            }
                        }
                        arrayList2 = r14;
                    }
                    ArrayList arrayList3 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList2));
                    for (String str3 : arrayList2) {
                        List list2 = Release.KEYS;
                        String obj8 = StringsKt.trim(StringsKt__StringsJVMKt.replace$default(StringsKt__StringsJVMKt.replace$default(str3, "**", ""), "`", "")).toString();
                        int length = obj8.length();
                        Pair pair = new Pair(". ", 24);
                        Pair pair2 = new Pair("; ", 24);
                        Pair pair3 = new Pair(": ", 44);
                        Pair[] pairArr = new Pair[3];
                        pairArr[0] = pair;
                        pairArr[c] = pair2;
                        pairArr[2] = pair3;
                        for (Pair pair4 : ArraysKt.asList(pairArr)) {
                            int indexOf$default = StringsKt.indexOf$default(obj8, (String) pair4.first, ((Number) pair4.second).intValue(), false, 4);
                            if (indexOf$default >= 0 && indexOf$default < length) {
                                length = indexOf$default;
                            }
                        }
                        String substring2 = obj8.substring(0, length);
                        Intrinsics.checkNotNullExpressionValue(substring2, "substring(...)");
                        String trimEnd = StringsKt.trimEnd(substring2, '.', ',', ':', ' ');
                        if (trimEnd.length() > 120) {
                            int lastIndexOf$default = StringsKt.lastIndexOf$default(trimEnd, ' ', 4);
                            Integer valueOf = Integer.valueOf(lastIndexOf$default);
                            if (lastIndexOf$default <= 60) {
                                valueOf = null;
                            }
                            if (valueOf != null) {
                                i = valueOf.intValue();
                            } else {
                                i = 118;
                            }
                            String substring3 = trimEnd.substring(0, i);
                            Intrinsics.checkNotNullExpressionValue(substring3, "substring(...)");
                            trimEnd = Census$$ExternalSyntheticOutline0.m(StringsKt.trimEnd(substring3, ',', ':', ' '), "…");
                        }
                        arrayList3.add(trimEnd);
                    }
                    ArrayList arrayList4 = new ArrayList();
                    Iterator it3 = arrayList3.iterator();
                    while (it3.hasNext()) {
                        Object next = it3.next();
                        if (((String) next).length() > 0) {
                            arrayList4.add(next);
                        }
                    }
                    ArrayList arrayList5 = new ArrayList();
                    ArrayList arrayList6 = new ArrayList();
                    Iterator it4 = arrayList4.iterator();
                    while (it4.hasNext()) {
                        Object next2 = it4.next();
                        String str4 = (String) next2;
                        if (!prefer.isEmpty()) {
                            Iterator it5 = prefer.iterator();
                            while (it5.hasNext()) {
                                if (StringsKt.contains(str4, (String) it5.next(), true)) {
                                    arrayList5.add(next2);
                                    break;
                                }
                            }
                        }
                        arrayList6.add(next2);
                    }
                    ArrayList plus = CollectionsKt.plus((List) arrayList5, (Iterable) arrayList6);
                    List take = CollectionsKt.take(plus, 6);
                    int max = Math.max(0, plus.size() - 6);
                    String upperCase = Fleet.T("updater.whats_new", new Pair("version", release.version)).toUpperCase(Locale.ROOT);
                    Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
                    col.addView(UiKt.head(mainActivity, upperCase), UiKt.gap(mainActivity, 18));
                    if (take.isEmpty()) {
                        col.addView(UiKt.label(mainActivity, Fleet.T("updater.download_and_install_the", new Pair[0]), 15, UiKt.TEXT), UiKt.gap(mainActivity, 8));
                    }
                    Iterator it6 = take.iterator();
                    while (it6.hasNext()) {
                        TextView label = UiKt.label(mainActivity, ApkSigner$$ExternalSyntheticOutline0.m("•  ", (String) it6.next()), 15, UiKt.TEXT);
                        label.setLineSpacing(UiKt.dp(mainActivity, 2), 1.0f);
                        col.addView(label, UiKt.gap(mainActivity, 8));
                    }
                    if (max > 0) {
                        col.addView(UiKt.label(mainActivity, Fleet.T("updater.more", new Pair("n", Integer.valueOf(max))), 14, UiKt.MUTED), UiKt.gap(mainActivity, 8));
                    }
                    TextView label2 = UiKt.label(mainActivity, Fleet.T("updater.all_notes", new Pair[0]), 15, UiKt.ACCENT_TEXT);
                    float f3 = 10;
                    label2.setPadding(0, UiKt.dp(mainActivity, f3), 0, UiKt.dp(mainActivity, f3));
                    label2.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(mainActivity, 14));
                    col.addView(label2, UiKt.gap(mainActivity, 6));
                    Popup.Builder builder = new Popup.Builder(mainActivity);
                    builder.title = Fleet.T("updater.title", new Pair[0]);
                    builder.view = col;
                    builder.setPositiveButton(Fleet.T("updater.update_to", new Pair("version", release.version)), new UpdaterKt$$ExternalSyntheticLambda0(mainActivity, release, 2));
                    builder.setNegativeButton(Fleet.T("common.later", new Pair[0]), null);
                    builder.show();
                    return;
                }
                Intrinsics.throwUninitializedPropertyAccessException("auto");
                throw null;
            }
            Intrinsics.throwUninitializedPropertyAccessException("auto");
            throw null;
        }
    }

    public static final void checkUpdate(MainActivity mainActivity, boolean z) {
        if (z) {
            TextView textView = mainActivity.updateNote;
            if (textView != null) {
                textView.setText(Fleet.T("setup.checking", new Pair[0]));
            } else {
                Intrinsics.throwUninitializedPropertyAccessException("updateNote");
                throw null;
            }
        }
        new Thread(new UpdaterKt$$ExternalSyntheticLambda3(mainActivity, z, 0)).start();
    }

    public static final void download(MainActivity mainActivity, Release release) {
        mainActivity.updating = true;
        progress(mainActivity, Fleet.T("updater.downloading_2", new Pair("version", release.version)));
        new Thread(new UpdaterKt$$ExternalSyntheticLambda1(mainActivity, release, 0)).start();
    }

    public static final void failed(MainActivity mainActivity, Release release, String str) {
        String str2;
        if (release == null) {
            PickerScreenKt.message(mainActivity, str, true);
            return;
        }
        Popup.Builder builder = new Popup.Builder(mainActivity);
        builder.title = Fleet.T("updater.failed_title", new Pair[0]);
        String T = Fleet.T("updater.failed_body", new Pair[0]);
        if (StringsKt__StringsJVMKt.equals(Build.MANUFACTURER, "samsung")) {
            str2 = ApkSigner$$ExternalSyntheticOutline0.m("\n\n", Fleet.T("updater.failed_samsung", new Pair[0]));
        } else {
            str2 = "";
        }
        builder.message = str + "\n\n" + T + str2;
        builder.setPositiveButton(Fleet.T("updater.failed_browser", new Pair[0]), new UpdaterKt$$ExternalSyntheticLambda0(mainActivity, release, 0));
        builder.setNegativeButton(Fleet.T("common.later", new Pair[0]), null);
        builder.show();
    }

    public static final boolean installResult(MainActivity mainActivity, Intent intent) {
        String T;
        if (!"dev.tvremote.phone.INSTALL_RESULT".equals(intent.getAction())) {
            return false;
        }
        int intExtra = intent.getIntExtra("android.content.pm.extra.STATUS", 1);
        if (intExtra == -1) {
            Intent intent2 = (Intent) intent.getParcelableExtra("android.intent.extra.INTENT");
            if (intent2 != null) {
                mainActivity.startActivity(intent2);
                return true;
            }
        } else if (intExtra != 0) {
            mainActivity.updating = false;
            showUpdate(mainActivity);
            if (intExtra == 3 && !StringsKt__StringsJVMKt.equals(Build.MANUFACTURER, "samsung")) {
                PickerScreenKt.message(mainActivity, Fleet.T("updater.update_cancelled", new Pair[0]), true);
                return true;
            }
            Release release = mainActivity.update;
            if (intExtra == 3) {
                T = Fleet.T("updater.update_cancelled", new Pair[0]);
            } else {
                T = Fleet.T("updater.could_not_install_the", new Pair("error", intent.getStringExtra("android.content.pm.extra.STATUS_MESSAGE")));
            }
            failed(mainActivity, release, T);
            return true;
        }
        return true;
    }

    public static final void progress(MainActivity mainActivity, String s) {
        Intrinsics.checkNotNullParameter(s, "s");
        UiKt.setLabel(mainActivity.getUpdateBtn$android_release(), s);
        TextView textView = mainActivity.updateNote;
        if (textView != null) {
            textView.setText(s);
        } else {
            Intrinsics.throwUninitializedPropertyAccessException("updateNote");
            throw null;
        }
    }

    public static final String released(MainActivity mainActivity) {
        try {
            String string = mainActivity.getString(mainActivity.getResources().getIdentifier("released", "string", mainActivity.getPackageName()));
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            List split$default = StringsKt.split$default(string, new String[]{"-"}, 0, 6);
            return split$default.get(2) + "/" + split$default.get(1) + "/" + split$default.get(0);
        } catch (Exception unused) {
            return "";
        }
    }

    public static final void showUpdate(MainActivity mainActivity) {
        int i;
        Release release = mainActivity.update;
        Button updateBtn$android_release = mainActivity.getUpdateBtn$android_release();
        if (release == null) {
            i = 8;
        } else {
            i = 0;
        }
        updateBtn$android_release.setVisibility(i);
        if (release != null && !mainActivity.updating) {
            UiKt.setLabel(mainActivity.getUpdateBtn$android_release(), "@download|" + Fleet.T("updater.new_version_tap_to", new Pair("version", release.version)));
        }
    }

    public static final void startUpdate(MainActivity mainActivity, Release r) {
        boolean canRequestPackageInstalls;
        Intrinsics.checkNotNullParameter(r, "r");
        if (Build.VERSION.SDK_INT >= 26) {
            canRequestPackageInstalls = mainActivity.getPackageManager().canRequestPackageInstalls();
            if (!canRequestPackageInstalls) {
                Popup.Builder builder = new Popup.Builder(mainActivity);
                builder.title = Fleet.T("updater.allow_title", new Pair[0]);
                builder.message = Fleet.T("updater.allow_body", new Pair[0]);
                builder.setPositiveButton(Fleet.T("updater.allow_open", new Pair[0]), new UpdaterKt$$ExternalSyntheticLambda0(mainActivity, r, 1));
                builder.setNegativeButton(Fleet.T("common.later", new Pair[0]), null);
                builder.show();
                return;
            }
        }
        download(mainActivity, r);
    }

    public static final String version(MainActivity mainActivity) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        try {
            String str = mainActivity.getPackageManager().getPackageInfo(mainActivity.getPackageName(), 0).versionName;
            if (str == null) {
                return "0";
            }
            return str;
        } catch (Exception unused) {
            return "0";
        }
    }

    public static final String versionLine(MainActivity mainActivity) {
        String concat;
        String version = version(mainActivity);
        String released = released(mainActivity);
        if (released.length() == 0) {
            concat = "";
        } else {
            concat = " · ".concat(released);
        }
        return version + ((Object) concat);
    }
}
