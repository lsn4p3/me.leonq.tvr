package dev.tvremote.phone.manage;

import android.widget.Button;
import android.widget.Toast;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.media.MediaKt$$ExternalSyntheticLambda10;
import dev.tvremote.phone.ui.Popup;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$ObjectRef;
import kotlin.text.StringsKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class InfoScreensKt$$ExternalSyntheticLambda27 implements Runnable {
    public final /* synthetic */ int $r8$classId = 0;
    public final /* synthetic */ Ref$ObjectRef f$0;
    public final /* synthetic */ JSONObject f$1;
    public final /* synthetic */ MainActivity f$2;

    public /* synthetic */ InfoScreensKt$$ExternalSyntheticLambda27(Ref$ObjectRef ref$ObjectRef, JSONObject jSONObject, MainActivity mainActivity) {
        this.f$0 = ref$ObjectRef;
        this.f$1 = jSONObject;
        this.f$2 = mainActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity mainActivity = this.f$2;
        JSONObject jSONObject = this.f$1;
        Ref$ObjectRef ref$ObjectRef = this.f$0;
        int i = 1;
        switch (this.$r8$classId) {
            case 0:
                Object obj = ref$ObjectRef.element;
                if (obj != null) {
                    ((Button) obj).setEnabled(true);
                    Fleet.buildAbout$supMark(ref$ObjectRef, jSONObject);
                    String optString = jSONObject.optString("failed");
                    if (Intrinsics.areEqual(optString, "")) {
                        if (jSONObject.optBoolean("open")) {
                            Popup.Builder builder = new Popup.Builder(mainActivity);
                            String T = Fleet.T("support.code_title", new Pair[0]);
                            String optString2 = jSONObject.optString("code");
                            Intrinsics.checkNotNullExpressionValue(optString2, "optString(...)");
                            builder.title = Census$$ExternalSyntheticOutline0.m(T, ": ", CollectionsKt.joinToString$default(StringsKt.chunked(optString2, 4), " ", null, null, null, 62));
                            builder.message = Fleet.T("support.read_out_stop", new Pair("min", Long.valueOf(jSONObject.optLong("min"))));
                            builder.setPositiveButton(Fleet.T("common.close", new Pair[0]), null);
                            builder.setNegativeButton(Fleet.T("support.stop", new Pair[0]), new MediaKt$$ExternalSyntheticLambda10(i, mainActivity, ref$ObjectRef));
                            builder.show();
                            return;
                        }
                        return;
                    }
                    if (Intrinsics.areEqual(optString, "none_left")) {
                        Toast.makeText(mainActivity, Fleet.T("support.none_left", new Pair[0]), 1).show();
                        return;
                    } else {
                        Toast.makeText(mainActivity, Fleet.T("support.no_net_here", new Pair[0]), 1).show();
                        return;
                    }
                }
                Intrinsics.throwUninitializedPropertyAccessException("sup");
                throw null;
            default:
                Fleet.buildAbout$supMark(ref$ObjectRef, jSONObject);
                Toast.makeText(mainActivity, Fleet.T("support.stopped", new Pair[0]), 0).show();
                return;
        }
    }

    public /* synthetic */ InfoScreensKt$$ExternalSyntheticLambda27(JSONObject jSONObject, MainActivity mainActivity, Ref$ObjectRef ref$ObjectRef) {
        this.f$1 = jSONObject;
        this.f$2 = mainActivity;
        this.f$0 = ref$ObjectRef;
    }
}
