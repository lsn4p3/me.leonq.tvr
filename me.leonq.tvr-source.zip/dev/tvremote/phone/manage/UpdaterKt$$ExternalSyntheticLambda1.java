package dev.tvremote.phone.manage;

import android.content.Intent;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.ontv.Axml$$ExternalSyntheticLambda2;
import dev.tvremote.core.remote.Lg$$ExternalSyntheticLambda2;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.update.Release;
import dev.tvremote.update.SelfUpdate$sam$dev_tvremote_update_Release_Progress$0;
import java.io.File;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;

/* loaded from: classes.dex */
public final /* synthetic */ class UpdaterKt$$ExternalSyntheticLambda1 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ Release f$1;

    public /* synthetic */ UpdaterKt$$ExternalSyntheticLambda1(MainActivity mainActivity, Release release, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
        this.f$1 = release;
    }

    @Override // java.lang.Runnable
    public final void run() {
        String str;
        switch (this.$r8$classId) {
            case 0:
                MainActivity mainActivity = this.f$0;
                Release r = this.f$1;
                try {
                    Intent action = new Intent(mainActivity, (Class<?>) MainActivity.class).setAction("dev.tvremote.phone.INSTALL_RESULT");
                    Intrinsics.checkNotNullExpressionValue(action, "setAction(...)");
                    Axml$$ExternalSyntheticLambda2 axml$$ExternalSyntheticLambda2 = new Axml$$ExternalSyntheticLambda2(8, mainActivity, r);
                    Intrinsics.checkNotNullParameter(r, "r");
                    File file = new File(mainActivity.getCacheDir(), "update.apk");
                    try {
                        r.download(file, new SelfUpdate$sam$dev_tvremote_update_Release_Progress$0(axml$$ExternalSyntheticLambda2));
                        MathKt.commit(mainActivity, file, action, true, false);
                        file.delete();
                        str = null;
                    } catch (Throwable th) {
                        file.delete();
                        throw th;
                    }
                } catch (Exception e) {
                    String message = e.getMessage();
                    if (message == null) {
                        str = e.getClass().getSimpleName();
                    } else {
                        str = message;
                    }
                }
                mainActivity.ui.post(new Lg$$ExternalSyntheticLambda2(str, mainActivity, r, 11));
                return;
            default:
                MainActivity mainActivity2 = this.f$0;
                if (!mainActivity2.foreground) {
                    Fleet.install(mainActivity2, this.f$1);
                    return;
                }
                return;
        }
    }
}
