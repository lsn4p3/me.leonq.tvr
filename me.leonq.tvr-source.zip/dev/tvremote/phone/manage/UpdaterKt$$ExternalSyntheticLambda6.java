package dev.tvremote.phone.manage;

import android.widget.Button;
import dev.tvremote.core.Fleet;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.ui.UiKt;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$ObjectRef;

/* loaded from: classes.dex */
public final /* synthetic */ class UpdaterKt$$ExternalSyntheticLambda6 implements Function0 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Ref$ObjectRef f$0;
    public final /* synthetic */ MainActivity f$1;

    public /* synthetic */ UpdaterKt$$ExternalSyntheticLambda6(int i, MainActivity mainActivity, Ref$ObjectRef ref$ObjectRef) {
        this.$r8$classId = i;
        this.f$0 = ref$ObjectRef;
        this.f$1 = mainActivity;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        switch (this.$r8$classId) {
            case 0:
                Object obj = this.f$0.element;
                if (obj != null) {
                    UiKt.setToggle((Button) obj, this.f$1.getPrefs$android_release().getBoolean("autoUpdate", true), Fleet.T("updater.auto", new Pair[0]));
                    return Unit.INSTANCE;
                }
                Intrinsics.throwUninitializedPropertyAccessException("auto");
                throw null;
            case 1:
                Object obj2 = this.f$0.element;
                if (obj2 != null) {
                    UiKt.setToggle((Button) obj2, this.f$1.getPrefs$android_release().getBoolean("volKeysTv", true), Fleet.T("info_screens.set_the_tv_s", new Pair[0]));
                    return Unit.INSTANCE;
                }
                Intrinsics.throwUninitializedPropertyAccessException("vol");
                throw null;
            case 2:
                Object obj3 = this.f$0.element;
                if (obj3 != null) {
                    UiKt.setToggle((Button) obj3, this.f$1.getPrefs$android_release().getBoolean("buzz", true), Fleet.T("about.vibrate", new Pair[0]));
                    return Unit.INSTANCE;
                }
                Intrinsics.throwUninitializedPropertyAccessException("buzzRow");
                throw null;
            case 3:
                Object obj4 = this.f$0.element;
                if (obj4 != null) {
                    UiKt.setToggle((Button) obj4, this.f$1.getPrefs$android_release().getBoolean("kbdAuto", true), Fleet.T("about.tv_keyboard_auto", new Pair[0]));
                    return Unit.INSTANCE;
                }
                Intrinsics.throwUninitializedPropertyAccessException("kbdRow");
                throw null;
            case 4:
                Object obj5 = this.f$0.element;
                if (obj5 != null) {
                    UiKt.setToggle((Button) obj5, this.f$1.getPrefs$android_release().getBoolean("autoUpdate", true), Fleet.T("info_screens.check_for_updates_automatically", new Pair[0]));
                    return Unit.INSTANCE;
                }
                Intrinsics.throwUninitializedPropertyAccessException("auto");
                throw null;
            default:
                Ref$ObjectRef ref$ObjectRef = this.f$0;
                Object obj6 = ref$ObjectRef.element;
                if (obj6 != null) {
                    ((Button) obj6).setEnabled(false);
                    new Thread(new InfoScreensKt$$ExternalSyntheticLambda25(0, this.f$1, ref$ObjectRef)).start();
                    return Unit.INSTANCE;
                }
                Intrinsics.throwUninitializedPropertyAccessException("sup");
                throw null;
        }
    }
}
