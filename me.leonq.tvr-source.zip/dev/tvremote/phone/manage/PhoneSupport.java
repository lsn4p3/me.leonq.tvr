package dev.tvremote.phone.manage;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.RouteInfo;
import android.os.Build;
import dev.tvremote.core.Census;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.SupportAndroid;
import dev.tvremote.core.SupportAndroid$store$1;
import dev.tvremote.core.SupportRelay;
import dev.tvremote.core.WireLog;
import dev.tvremote.core.picture.TvAndroidKt$$ExternalSyntheticLambda0;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda5;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.picker.NetKt$$ExternalSyntheticLambda1;
import dev.tvremote.phone.picker.PickerScreenKt;
import dev.tvremote.phone.remote.TypingKt;
import dev.tvremote.tvapps.ApkCert$$ExternalSyntheticLambda0;
import java.lang.ref.WeakReference;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Charsets;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class PhoneSupport {
    public static final PhoneSupport INSTANCE = new Object();
    public static final List ROUTES = CollectionsKt__CollectionsKt.listOf((Object[]) new String[]{"/api/support/log", "/api/support/logcat", "/api/support/prefs", "/api/support/net", "/api/support/tvs", "/api/diagnose?ip="});
    public static volatile WeakReference activity = new WeakReference(null);
    public static volatile SupportRelay relay;

    public static String net(Context context) {
        Network network;
        String str;
        Boolean bool;
        Boolean bool2;
        String str2;
        String str3;
        String str4;
        String str5;
        List<RouteInfo> routes;
        List<InetAddress> dnsServers;
        List<LinkAddress> linkAddresses;
        int i = 4;
        int i2 = 1;
        try {
            Object systemService = context.getSystemService("connectivity");
            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.net.ConnectivityManager");
            ConnectivityManager connectivityManager = (ConnectivityManager) systemService;
            if (Build.VERSION.SDK_INT >= 23) {
                network = connectivityManager.getActiveNetwork();
            } else {
                network = null;
            }
            StringBuilder sb = new StringBuilder();
            sb.append("[networks] way out: ");
            sb.append(network);
            sb.append(" · lan for TVs: ");
            sb.append(MathKt.lanNetwork(context));
            sb.append('\n');
            Network[] allNetworks = connectivityManager.getAllNetworks();
            int length = allNetworks.length;
            int i3 = 0;
            while (i3 < length) {
                Network network2 = allNetworks[i3];
                NetworkCapabilities networkCapabilities = connectivityManager.getNetworkCapabilities(network2);
                LinkProperties linkProperties = connectivityManager.getLinkProperties(network2);
                List asList = ArraysKt.asList(new Pair[]{new Pair(Integer.valueOf(i2), "wifi"), new Pair(0, "mobile"), new Pair(4, "vpn"), new Pair(3, "ethernet")});
                ArrayList arrayList = new ArrayList();
                for (Object obj : asList) {
                    Pair pair = (Pair) obj;
                    if (networkCapabilities != null && networkCapabilities.hasTransport(((Number) pair.first).intValue())) {
                        arrayList.add(obj);
                    }
                }
                String joinToString$default = CollectionsKt.joinToString$default(arrayList, "+", null, null, new ApkCert$$ExternalSyntheticLambda0(3), 30);
                sb.append(network2);
                if (Intrinsics.areEqual(network2, network)) {
                    str = " (way out) ";
                } else {
                    str = " ";
                }
                sb.append(str);
                sb.append(joinToString$default);
                sb.append(" internet=");
                if (networkCapabilities != null) {
                    bool = Boolean.valueOf(networkCapabilities.hasCapability(12));
                } else {
                    bool = null;
                }
                sb.append(bool);
                sb.append(" validated=");
                if (networkCapabilities != null) {
                    bool2 = Boolean.valueOf(networkCapabilities.hasCapability(16));
                } else {
                    bool2 = null;
                }
                sb.append(bool2);
                sb.append(" iface=");
                if (linkProperties != null) {
                    str2 = linkProperties.getInterfaceName();
                } else {
                    str2 = null;
                }
                sb.append(str2);
                sb.append(" addr=");
                if (linkProperties != null && (linkAddresses = linkProperties.getLinkAddresses()) != null) {
                    str3 = CollectionsKt.joinToString$default(linkAddresses, ",", null, null, null, 62);
                } else {
                    str3 = null;
                }
                sb.append(str3);
                sb.append(" dns=");
                if (linkProperties != null && (dnsServers = linkProperties.getDnsServers()) != null) {
                    str4 = CollectionsKt.joinToString$default(dnsServers, ",", null, null, new ApkCert$$ExternalSyntheticLambda0(i), 30);
                } else {
                    str4 = null;
                }
                sb.append(str4);
                sb.append(" routes=");
                if (linkProperties != null && (routes = linkProperties.getRoutes()) != null) {
                    str5 = CollectionsKt.joinToString$default(routes, ",", null, null, new ApkCert$$ExternalSyntheticLambda0(5), 30);
                } else {
                    str5 = null;
                }
                sb.append(str5);
                sb.append('\n');
                i3++;
                i2 = 1;
            }
            return sb.toString();
        } catch (Exception e) {
            return "[networks] " + e;
        }
    }

    public static JSONObject tvs() {
        String str;
        MainActivity mainActivity = (MainActivity) activity.get();
        if (mainActivity == null) {
            return Census$$ExternalSyntheticOutline0.m9m("error", "the app's screen is closed", "put(...)");
        }
        JSONArray jSONArray = new JSONArray();
        Iterator it = PickerScreenKt.savedIps(mainActivity).iterator();
        while (it.hasNext()) {
            String str2 = (String) it.next();
            jSONArray.put(Census$$ExternalSyntheticOutline0.m8m("ip", str2).put("name", PickerScreenKt.name(mainActivity, str2)).put("kind", TypingKt.kindOf(mainActivity, str2)).put("addresses", new JSONArray((Collection) PickerScreenKt.savedTv(mainActivity, str2).getAddresses())).put("route", mainActivity.route.get(str2)).put("reach", mainActivity.reach.get(str2)).put("trying", mainActivity.trying.contains(str2)));
        }
        JSONObject put = new JSONObject().put("connected_to", mainActivity.host);
        Remote remote = mainActivity.basic;
        if (remote != null) {
            str = remote.getKind();
        } else {
            str = null;
        }
        JSONObject put2 = put.put("keys_only", str).put("tvs", jSONArray);
        Intrinsics.checkNotNullExpressionValue(put2, "put(...)");
        return put2;
    }

    /* JADX WARN: Removed duplicated region for block: B:19:0x00e9  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0143  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x015b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final JSONObject act(Context context, String str) {
        String s;
        String optString;
        String str2;
        SupportRelay relay2 = relay(context);
        String str3 = null;
        if (str.equals("start")) {
            JSONObject jSONObject = new JSONObject();
            String id = Census.id();
            if (id.length() == 0) {
                id = UUID.randomUUID().toString();
                Intrinsics.checkNotNullExpressionValue(id, "toString(...)");
            }
            JSONObject put = jSONObject.put("id", id).put("app", "phone").put("v", relay2.version).put("model", Build.MODEL);
            try {
                s = (String) relay2.report.invoke();
            } catch (Exception e) {
                s = "report: " + e;
            }
            Intrinsics.checkNotNullParameter(s, "s");
            while (true) {
                String quote = JSONObject.quote(s);
                Intrinsics.checkNotNullExpressionValue(quote, "quote(...)");
                byte[] bytes = quote.getBytes(Charsets.UTF_8);
                Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                if (bytes.length <= 56000) {
                    break;
                }
                s = StringsKt.takeLast(s, (s.length() * 4) / 5);
            }
            JSONObject put2 = put.put("report", s);
            relay2.left = -1;
            String base = SupportRelay.base();
            Intrinsics.checkNotNull(put2);
            JSONObject post = SupportRelay.post(base, put2);
            if (post != null) {
                relay2.left = post.optInt("left", -1);
                optString = post.optString("code");
                if (optString.length() != 8) {
                    optString = null;
                }
                if (optString != null) {
                    relay2.store.put("code", optString);
                    SupportAndroid$store$1 supportAndroid$store$1 = relay2.store;
                    String optString2 = post.optString("key");
                    Intrinsics.checkNotNullExpressionValue(optString2, "optString(...)");
                    supportAndroid$store$1.put("key", optString2);
                    String optString3 = post.optString("key");
                    Intrinsics.checkNotNullExpressionValue(optString3, "optString(...)");
                    relay2.lastKey = optString3;
                    if (!relay2.open()) {
                        relay2.code = optString;
                    }
                    if (optString != null) {
                        String str4 = relay2.lastKey;
                        String m = Census$$ExternalSyntheticOutline0.m(SupportRelay.base(), "/live");
                        JSONObject put3 = Census$$ExternalSyntheticOutline0.m10m("code", optString, "key", str4).put("minutes", 30);
                        Intrinsics.checkNotNullExpressionValue(put3, "put(...)");
                        JSONObject post2 = SupportRelay.post(m, put3);
                        if (post2 != null) {
                            if (!post2.has("live")) {
                                post2 = null;
                            }
                            if (post2 != null) {
                                relay2.run(SupportRelay.ends(post2, System.currentTimeMillis() + 1800000), optString, str4);
                                WireLog.all.add("·", "support open " + optString + " for 30 min");
                                str3 = optString;
                            }
                        }
                    }
                    if (str3 != null) {
                        JSONObject jSONObject2 = new JSONObject();
                        if (relay2.left == 0) {
                            str2 = "none_left";
                        } else {
                            str2 = "no_net";
                        }
                        JSONObject put4 = jSONObject2.put("failed", str2);
                        Intrinsics.checkNotNullExpressionValue(put4, "put(...)");
                        return put4;
                    }
                    return relay2.state();
                }
            }
            optString = null;
            if (optString != null) {
            }
            if (str3 != null) {
            }
        } else {
            if (str.equals("stop")) {
                String str5 = relay2.code;
                String str6 = "";
                if (str5.length() == 0 && (str5 = relay2.store.get("code")) == null) {
                    str5 = "";
                }
                String str7 = relay2.liveKey;
                if (str7.length() == 0) {
                    String str8 = relay2.store.get("key");
                    if (str8 != null) {
                        str6 = str8;
                    }
                    str7 = str6;
                }
                relay2.until = 0L;
                Thread thread = relay2.thread;
                if (thread != null) {
                    thread.interrupt();
                }
                relay2.thread = null;
                relay2.store.put("live_until", "0");
                if (str5.length() > 0) {
                    Thread thread2 = new Thread(new Guard$$ExternalSyntheticLambda5(relay2, str5, str7), "support-stop");
                    thread2.setDaemon(true);
                    thread2.start();
                }
                return relay2.state();
            }
            return relay2.state();
        }
    }

    public final SupportRelay relay(Context context) {
        SupportRelay supportRelay;
        String str;
        int i = 1;
        int i2 = 0;
        SupportRelay supportRelay2 = relay;
        if (supportRelay2 == null) {
            synchronized (this) {
                try {
                    supportRelay = relay;
                    if (supportRelay == null) {
                        MainActivity mainActivity = (MainActivity) activity.get();
                        if (mainActivity == null) {
                            if (context instanceof MainActivity) {
                                mainActivity = (MainActivity) context;
                            } else {
                                mainActivity = null;
                            }
                        }
                        if (mainActivity != null) {
                            str = UpdaterKt.version(mainActivity);
                        } else {
                            str = "";
                        }
                        String MODEL = Build.MODEL;
                        Intrinsics.checkNotNullExpressionValue(MODEL, "MODEL");
                        Regex regex = SupportAndroid.SECRET;
                        supportRelay = new SupportRelay(str, new SupportAndroid$store$1(i2, context.getApplicationContext().getSharedPreferences("support", 0)), new TvAndroidKt$$ExternalSyntheticLambda0(context, i), new NetKt$$ExternalSyntheticLambda1(context, i));
                        relay = supportRelay;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
            return supportRelay;
        }
        return supportRelay2;
    }
}
