package dev.tvremote.phone.manage;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.picker.PickerScreenKt;
import dev.tvremote.update.Release;

/* loaded from: classes.dex */
public final /* synthetic */ class UpdaterKt$$ExternalSyntheticLambda0 implements DialogInterface.OnClickListener {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ Release f$1;

    public /* synthetic */ UpdaterKt$$ExternalSyntheticLambda0(MainActivity mainActivity, Release release, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
        this.f$1 = release;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i) {
        switch (this.$r8$classId) {
            case 0:
                MainActivity mainActivity = this.f$0;
                Release release = this.f$1;
                try {
                    mainActivity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(release.url)));
                    return;
                } catch (Exception unused) {
                    PickerScreenKt.message(mainActivity, release.url, true);
                    return;
                }
            case 1:
                MainActivity mainActivity2 = this.f$0;
                Release release2 = this.f$1;
                mainActivity2.updateAfterAllow = release2;
                try {
                    mainActivity2.startActivity(new Intent("android.settings.MANAGE_UNKNOWN_APP_SOURCES", Uri.parse("package:" + mainActivity2.getPackageName())));
                    return;
                } catch (Exception unused2) {
                    mainActivity2.updateAfterAllow = null;
                    UpdaterKt.download(mainActivity2, release2);
                    return;
                }
            default:
                UpdaterKt.startUpdate(this.f$0, this.f$1);
                return;
        }
    }
}
