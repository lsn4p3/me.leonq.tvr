package dev.tvremote.phone.picture;

import android.view.View;
import android.widget.FrameLayout;

/* loaded from: classes.dex */
public final class VideoFrame extends FrameLayout {
    public int vh;
    public int vw;

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int childCount = getChildCount();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            int measuredWidth = ((i3 - i) - childAt.getMeasuredWidth()) / 2;
            int measuredHeight = ((i4 - i2) - childAt.getMeasuredHeight()) / 2;
            childAt.layout(measuredWidth, measuredHeight, childAt.getMeasuredWidth() + measuredWidth, childAt.getMeasuredHeight() + measuredHeight);
        }
    }

    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i, int i2) {
        boolean z;
        int size;
        int min;
        int size2 = View.MeasureSpec.getSize(i);
        if (View.MeasureSpec.getMode(i2) == 1073741824) {
            z = true;
        } else {
            z = false;
        }
        if (z) {
            min = View.MeasureSpec.getSize(i2);
        } else {
            if (View.MeasureSpec.getMode(i2) == 0) {
                size = Integer.MAX_VALUE;
            } else {
                size = View.MeasureSpec.getSize(i2);
            }
            min = Math.min(size, getResources().getDisplayMetrics().heightPixels / 2);
        }
        int min2 = Math.min((int) ((size2 * this.vh) / this.vw), min);
        int i3 = (int) ((min2 * this.vw) / this.vh);
        int childCount = getChildCount();
        for (int i4 = 0; i4 < childCount; i4++) {
            getChildAt(i4).measure(View.MeasureSpec.makeMeasureSpec(i3, 1073741824), View.MeasureSpec.makeMeasureSpec(min2, 1073741824));
        }
        if (!z) {
            min = min2;
        }
        setMeasuredDimension(size2, min);
    }
}
