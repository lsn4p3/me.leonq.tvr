package dev.tvremote.phone.picture;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.View;
import dev.tvremote.core.Census$$ExternalSyntheticLambda4;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.picture.DrawView;
import java.util.ArrayList;
import java.util.Iterator;
import kotlin.collections.CollectionsKt__MutableCollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;

/* loaded from: classes.dex */
public final class DrawView extends View {
    public static final /* synthetic */ int $r8$clinit = 0;
    public final RectF box;
    public final Paint frame;
    public final ArrayList landed;
    public float lastD;
    public float lastX;
    public float lastY;
    public Function0 onSize;
    public final Path path;
    public final Paint pen;
    public Pic placing;
    public final Paint smooth;
    public final ArrayList strokes;

    /* loaded from: classes.dex */
    public final class Pic {
        public final Bitmap bmp;
        public final String data;
        public long upAt;
        public int x = 5000;
        public int y = 5000;
        public int w = 4000;
        public int base = 4000;

        public Pic(Bitmap bitmap, String str) {
            this.bmp = bitmap;
            this.data = str;
        }
    }

    /* loaded from: classes.dex */
    public final class Stroke {
        public final int color;
        public final ArrayList pts = new ArrayList();
        public long upAt;
        public final int width;

        public Stroke(int i, int i2) {
            this.color = i;
            this.width = i2;
        }
    }

    public DrawView(MainActivity mainActivity) {
        super(mainActivity);
        this.strokes = new ArrayList();
        this.landed = new ArrayList();
        this.onSize = new Census$$ExternalSyntheticLambda4(20);
        this.smooth = new Paint(2);
        Paint paint = new Paint();
        Paint.Style style = Paint.Style.STROKE;
        paint.setStyle(style);
        paint.setColor(-1);
        paint.setPathEffect(new DashPathEffect(new float[]{18.0f, 10.0f}, 0.0f));
        this.frame = paint;
        this.box = new RectF();
        Paint paint2 = new Paint(1);
        paint2.setStyle(style);
        paint2.setStrokeCap(Paint.Cap.ROUND);
        paint2.setStrokeJoin(Paint.Join.ROUND);
        this.pen = paint2;
        this.path = new Path();
        setClickable(false);
        setFocusable(false);
    }

    public final RectF drawPic(Canvas canvas, Pic pic, int i) {
        float width = (getWidth() * pic.w) / 10000.0f;
        Bitmap bitmap = pic.bmp;
        float height = (bitmap.getHeight() * width) / bitmap.getWidth();
        RectF rectF = this.box;
        float f = 2;
        float f2 = width / f;
        float f3 = height / f;
        rectF.set(((getWidth() * pic.x) / 10000.0f) - f2, ((getHeight() * pic.y) / 10000.0f) - f3, ((getWidth() * pic.x) / 10000.0f) + f2, ((getHeight() * pic.y) / 10000.0f) + f3);
        Paint paint = this.smooth;
        paint.setAlpha(i);
        canvas.drawBitmap(bitmap, (Rect) null, rectF, paint);
        return rectF;
    }

    public final Function0 getOnSize() {
        return this.onSize;
    }

    public final Pic getPlacing() {
        return this.placing;
    }

    @Override // android.view.View
    public final void onDraw(Canvas c) {
        int i;
        int i2;
        int i3;
        Intrinsics.checkNotNullParameter(c, "c");
        final long currentTimeMillis = System.currentTimeMillis();
        ArrayList arrayList = this.strokes;
        final int i4 = 0;
        CollectionsKt__MutableCollectionsKt.removeAll(arrayList, new Function1() { // from class: dev.tvremote.phone.picture.DrawView$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                boolean z;
                boolean z2;
                switch (i4) {
                    case 0:
                        DrawView.Stroke it = (DrawView.Stroke) obj;
                        Intrinsics.checkNotNullParameter(it, "it");
                        long j = it.upAt;
                        if (j > 0 && currentTimeMillis - j > 1600) {
                            z = true;
                        } else {
                            z = false;
                        }
                        return Boolean.valueOf(z);
                    default:
                        DrawView.Pic it2 = (DrawView.Pic) obj;
                        Intrinsics.checkNotNullParameter(it2, "it");
                        if (currentTimeMillis - it2.upAt > 1600) {
                            z2 = true;
                        } else {
                            z2 = false;
                        }
                        return Boolean.valueOf(z2);
                }
            }
        });
        ArrayList arrayList2 = this.landed;
        final int i5 = 1;
        CollectionsKt__MutableCollectionsKt.removeAll(arrayList2, new Function1() { // from class: dev.tvremote.phone.picture.DrawView$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                boolean z;
                boolean z2;
                switch (i5) {
                    case 0:
                        DrawView.Stroke it = (DrawView.Stroke) obj;
                        Intrinsics.checkNotNullParameter(it, "it");
                        long j = it.upAt;
                        if (j > 0 && currentTimeMillis - j > 1600) {
                            z = true;
                        } else {
                            z = false;
                        }
                        return Boolean.valueOf(z);
                    default:
                        DrawView.Pic it2 = (DrawView.Pic) obj;
                        Intrinsics.checkNotNullParameter(it2, "it");
                        if (currentTimeMillis - it2.upAt > 1600) {
                            z2 = true;
                        } else {
                            z2 = false;
                        }
                        return Boolean.valueOf(z2);
                }
            }
        });
        Iterator it = arrayList2.iterator();
        Intrinsics.checkNotNullExpressionValue(it, "iterator(...)");
        while (true) {
            i = 1;
            i2 = 0;
            if (!it.hasNext()) {
                break;
            }
            Object next = it.next();
            Intrinsics.checkNotNullExpressionValue(next, "next(...)");
            Pic pic = (Pic) next;
            drawPic(c, pic, MathKt.coerceIn((int) ((1 - (((float) (currentTimeMillis - pic.upAt)) / 1600.0f)) * 255), 0, 255));
        }
        float width = getWidth() / 10000.0f;
        float height = getHeight() / 10000.0f;
        Iterator it2 = arrayList.iterator();
        Intrinsics.checkNotNullExpressionValue(it2, "iterator(...)");
        while (it2.hasNext()) {
            Object next2 = it2.next();
            Intrinsics.checkNotNullExpressionValue(next2, "next(...)");
            Stroke stroke = (Stroke) next2;
            Path path = this.path;
            path.reset();
            ArrayList arrayList3 = stroke.pts;
            path.moveTo(((Number) arrayList3.get(i2)).floatValue() * width, ((Number) arrayList3.get(i)).floatValue() * height);
            if (arrayList3.size() == 2) {
                path.lineTo((((Number) arrayList3.get(i2)).floatValue() * width) + 0.1f, ((Number) arrayList3.get(1)).floatValue() * height);
            }
            int i6 = 2;
            while (true) {
                int i7 = i6 + 1;
                if (i7 >= arrayList3.size()) {
                    break;
                }
                path.lineTo(((Number) arrayList3.get(i6)).floatValue() * width, ((Number) arrayList3.get(i7)).floatValue() * height);
                i6 += 2;
            }
            Paint paint = this.pen;
            paint.setColor(stroke.color);
            long j = stroke.upAt;
            long j2 = currentTimeMillis;
            if (j > 0) {
                float f = 1 - (((float) (j2 - j)) / 1600.0f);
                i2 = 0;
                i3 = MathKt.coerceIn((int) (f * 255), 0, 255);
            } else {
                i2 = 0;
                i3 = 255;
            }
            paint.setAlpha(i3);
            paint.setStrokeWidth(Math.max(2.0f, stroke.width * width));
            c.drawPath(path, paint);
            currentTimeMillis = j2;
            i = 1;
        }
        Pic pic2 = this.placing;
        if (pic2 != null) {
            c.drawRect(drawPic(c, pic2, 255), this.frame);
        }
        if (!arrayList.isEmpty()) {
            Iterator it3 = arrayList.iterator();
            while (it3.hasNext()) {
                if (((Stroke) it3.next()).upAt > 0) {
                    break;
                }
            }
        }
        if (arrayList2.isEmpty()) {
            return;
        }
        postInvalidateOnAnimation();
    }

    public final void setOnSize(Function0 function0) {
        Intrinsics.checkNotNullParameter(function0, "<set-?>");
        this.onSize = function0;
    }

    public final void setPlacing(Pic pic) {
        this.placing = pic;
    }
}
