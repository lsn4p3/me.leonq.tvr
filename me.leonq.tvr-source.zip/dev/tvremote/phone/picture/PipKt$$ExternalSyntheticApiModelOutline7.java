package dev.tvremote.phone.picture;

/* loaded from: classes.dex */
public abstract /* synthetic */ class PipKt$$ExternalSyntheticApiModelOutline7 {
}
