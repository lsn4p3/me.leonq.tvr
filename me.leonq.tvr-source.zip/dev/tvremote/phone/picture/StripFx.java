package dev.tvremote.phone.picture;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.SystemClock;
import android.view.View;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.ui.UiKt;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class StripFx extends View {
    public final float d;
    public int dir;
    public long flashAt;
    public boolean on;
    public final Paint p;
    public float phase;
    public final boolean still;
    public final Path tri;
    public long upAt;
    public float y;

    public StripFx(MainActivity mainActivity, boolean z, float f) {
        super(mainActivity);
        this.still = z;
        this.d = f;
        this.p = new Paint(1);
        this.tri = new Path();
        setClickable(false);
        setFocusable(false);
    }

    public final void arrow(Canvas canvas, float f, float f2, boolean z, boolean z2) {
        float f3;
        int i;
        float f4 = 5 * this.d;
        if (z) {
            f3 = -f4;
        } else {
            f3 = f4;
        }
        Path path = this.tri;
        path.rewind();
        path.moveTo(f, f2 + f3);
        float f5 = f4 * 1.2f;
        float f6 = f2 - f3;
        path.lineTo(f - f5, f6);
        path.lineTo(f + f5, f6);
        path.close();
        Paint paint = this.p;
        paint.setStyle(Paint.Style.FILL);
        if (z2) {
            i = UiKt.ACCENT_TEXT;
        } else {
            i = UiKt.MUTED;
        }
        paint.setColor(i);
        canvas.drawPath(path, paint);
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        boolean z;
        boolean z2;
        boolean z3;
        boolean z4;
        Canvas c = canvas;
        Intrinsics.checkNotNullParameter(c, "c");
        long uptimeMillis = SystemClock.uptimeMillis();
        float width = getWidth();
        float height = getHeight();
        float f = this.d;
        float f2 = f * 18.0f;
        float f3 = 1.0f;
        if (!this.on) {
            f3 = Math.max(0.0f, 1.0f - (((float) (uptimeMillis - this.upAt)) / 400.0f));
        }
        boolean z5 = this.still;
        boolean z6 = true;
        if (f3 > 0.0f && !this.on && !z5) {
            z = true;
        } else {
            z = false;
        }
        Paint paint = this.p;
        paint.setStyle(Paint.Style.STROKE);
        float f4 = 2;
        paint.setStrokeWidth(f4 * f);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setColor(((((int) (110 * f3)) + 50) << 24) | (UiKt.MUTED & 16777215));
        float f5 = this.phase;
        if (f5 < 0.0f) {
            f5 += f2;
        }
        float f6 = 26 * f;
        float f7 = f6 + f5;
        float f8 = 11 * f;
        float f9 = f4;
        float f10 = width - f8;
        while (f7 < height - f6) {
            c.drawLine(f8, f7, f10, f7, paint);
            f7 += f2;
            c = canvas;
            f9 = f9;
        }
        float f11 = f9;
        if (!z5 && uptimeMillis - this.flashAt < 180) {
            z2 = true;
        } else {
            z2 = false;
        }
        float f12 = width / f11;
        float f13 = 14 * f;
        if (z2 && this.dir < 0) {
            z3 = true;
        } else {
            z3 = false;
        }
        arrow(canvas, f12, f13, true, z3);
        float f14 = height - f13;
        if (z2 && this.dir > 0) {
            z4 = true;
        } else {
            z4 = false;
        }
        arrow(canvas, f12, f14, false, z4);
        if (!z2) {
            z6 = z;
        }
        if (z6) {
            postInvalidateOnAnimation();
        }
    }
}
