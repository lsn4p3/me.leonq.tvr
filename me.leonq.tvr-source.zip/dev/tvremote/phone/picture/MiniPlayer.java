package dev.tvremote.phone.picture;

import android.content.Context;
import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import dev.tvremote.core.Fleet;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda8;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda44;
import dev.tvremote.phone.media.NowApp;
import dev.tvremote.phone.ui.IconButton;
import dev.tvremote.phone.ui.UiKt;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;

/* loaded from: classes.dex */
public final class MiniPlayer extends FrameLayout {
    public final MainActivity a;
    public final IconButton closeBtn;
    public boolean drag;
    public float dx;
    public float dy;
    public final int m;
    public final ScaleGestureDetector pinch;
    public boolean pip;
    public boolean scaling;
    public float share;
    public final int slop;

    public MiniPlayer(MainActivity mainActivity) {
        super(mainActivity);
        this.a = mainActivity;
        boolean z = UiKt.LIGHT;
        this.m = UiKt.dp(mainActivity, 12);
        this.slop = ViewConfiguration.get(mainActivity).getScaledTouchSlop();
        this.share = MathKt.coerceIn(mainActivity.getPrefs$android_release().getFloat("mini_w", 0.6f), 0.35f, 1.0f);
        this.pinch = new ScaleGestureDetector(mainActivity, new ScaleGestureDetector.SimpleOnScaleGestureListener() { // from class: dev.tvremote.phone.picture.MiniPlayer$pinch$1
            @Override // android.view.ScaleGestureDetector.SimpleOnScaleGestureListener, android.view.ScaleGestureDetector.OnScaleGestureListener
            public final boolean onScale(ScaleGestureDetector d) {
                View view;
                Intrinsics.checkNotNullParameter(d, "d");
                MiniPlayer miniPlayer = MiniPlayer.this;
                miniPlayer.share = MathKt.coerceIn(d.getScaleFactor() * miniPlayer.share, 0.35f, 1.0f);
                Object parent = miniPlayer.getParent();
                if (parent instanceof View) {
                    view = (View) parent;
                } else {
                    view = null;
                }
                if (view != null) {
                    int width = miniPlayer.getWidth();
                    int height = miniPlayer.getHeight();
                    ViewGroup.LayoutParams layoutParams = miniPlayer.getLayoutParams();
                    Intrinsics.checkNotNull(layoutParams, "null cannot be cast to non-null type android.widget.FrameLayout.LayoutParams");
                    ((FrameLayout.LayoutParams) layoutParams).width = miniPlayer.width(view);
                    miniPlayer.requestLayout();
                    miniPlayer.post(new MainActivity$$ExternalSyntheticLambda44(miniPlayer, width, height, 1));
                    return true;
                }
                return true;
            }

            @Override // android.view.ScaleGestureDetector.SimpleOnScaleGestureListener, android.view.ScaleGestureDetector.OnScaleGestureListener
            public final boolean onScaleBegin(ScaleGestureDetector d) {
                Intrinsics.checkNotNullParameter(d, "d");
                MiniPlayer miniPlayer = MiniPlayer.this;
                miniPlayer.scaling = true;
                miniPlayer.drag = false;
                return true;
            }

            @Override // android.view.ScaleGestureDetector.SimpleOnScaleGestureListener, android.view.ScaleGestureDetector.OnScaleGestureListener
            public final void onScaleEnd(ScaleGestureDetector d) {
                Intrinsics.checkNotNullParameter(d, "d");
                MiniPlayer miniPlayer = MiniPlayer.this;
                miniPlayer.a.getPrefs$android_release().edit().putFloat("mini_w", miniPlayer.share).apply();
            }
        });
        IconButton icon = UiKt.icon(mainActivity, "@close", Fleet.T("float.close_mini", new Pair[0]), -1442840576);
        this.closeBtn = icon;
        setOutlineProvider(new NowApp.AnonymousClass2(1, this));
        setClipToOutline(true);
        setElevation(UiKt.dp(mainActivity, 10));
        setBackgroundColor(-16777216);
        icon.setIcon("@close", -1);
        float f = 34;
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(UiKt.dp(mainActivity, f), UiKt.dp(mainActivity, f), 8388661);
        float f2 = 4;
        layoutParams.setMargins(UiKt.dp(mainActivity, f2), UiKt.dp(mainActivity, f2), UiKt.dp(mainActivity, f2), UiKt.dp(mainActivity, f2));
        addView(icon, layoutParams);
        setVisibility(8);
        icon.setOnClickListener(new Guard$$ExternalSyntheticLambda8(7, this));
        addOnLayoutChangeListener(new View.OnLayoutChangeListener() { // from class: dev.tvremote.phone.picture.MiniPlayer$$ExternalSyntheticLambda3
            @Override // android.view.View.OnLayoutChangeListener
            public final void onLayoutChange(View view, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
                if (i2 == i6 && i4 == i8) {
                    return;
                }
                MiniPlayer.this.report();
            }
        });
    }

    public final void keepIn(boolean z) {
        View view;
        Object parent = getParent();
        if (parent instanceof View) {
            view = (View) parent;
        } else {
            view = null;
        }
        if (view == null) {
            return;
        }
        float translationX = getTranslationX();
        int width = view.getWidth() - getWidth();
        int i = this.m * 2;
        float f = width - i;
        if (f < 0.0f) {
            f = 0.0f;
        }
        float coerceIn = MathKt.coerceIn(translationX, -f, 0.0f);
        float translationY = getTranslationY();
        float height = (view.getHeight() - getHeight()) - i;
        if (height < 0.0f) {
            height = 0.0f;
        }
        float coerceIn2 = MathKt.coerceIn(translationY, -height, 0.0f);
        if (z) {
            animate().translationX(coerceIn).translationY(coerceIn2).setDuration(160L).withEndAction(new MiniPlayer$$ExternalSyntheticLambda0(this, 1)).start();
            return;
        }
        setTranslationX(coerceIn);
        setTranslationY(coerceIn2);
        report();
    }

    public final void mode(boolean z) {
        int i;
        View view;
        this.pip = z;
        int i2 = 0;
        if (z) {
            i = 8;
        } else {
            i = 0;
        }
        this.closeBtn.setVisibility(i);
        Object parent = getParent();
        if (parent instanceof View) {
            view = (View) parent;
        } else {
            view = null;
        }
        if (z) {
            setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
            setTranslationX(0.0f);
            setTranslationY(0.0f);
            setElevation(0.0f);
            int childCount = getChildCount();
            while (i2 < childCount) {
                if (getChildAt(i2) instanceof VideoFrame) {
                    getChildAt(i2).setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
                }
                i2++;
            }
        } else {
            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(width(view), -2, 8388693);
            int i3 = this.m;
            layoutParams.setMargins(i3, i3, i3, i3);
            setLayoutParams(layoutParams);
            int childCount2 = getChildCount();
            while (i2 < childCount2) {
                if (getChildAt(i2) instanceof VideoFrame) {
                    getChildAt(i2).setLayoutParams(new FrameLayout.LayoutParams(-1, -2));
                }
                i2++;
            }
            setElevation(UiKt.dp((Context) this.a, 10));
            post(new MiniPlayer$$ExternalSyntheticLambda0(this, 0));
        }
        invalidateOutline();
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent e) {
        Intrinsics.checkNotNullParameter(e, "e");
        if (!this.pip) {
            Rect rect = new Rect();
            IconButton iconButton = this.closeBtn;
            iconButton.getHitRect(rect);
            if (iconButton.getVisibility() != 0 || !rect.contains((int) e.getX(), (int) e.getY())) {
                return true;
            }
            return false;
        }
        return false;
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent e) {
        Intrinsics.checkNotNullParameter(e, "e");
        if (this.pip) {
            return false;
        }
        this.pinch.onTouchEvent(e);
        int actionMasked = e.getActionMasked();
        if (actionMasked != 0) {
            if (actionMasked != 1) {
                if (actionMasked != 2) {
                    if (actionMasked != 3) {
                        if (actionMasked == 5) {
                            this.scaling = true;
                            this.drag = false;
                            return true;
                        }
                    } else if (this.drag || this.scaling) {
                        keepIn(true);
                        return true;
                    }
                } else if (!this.scaling) {
                    float rawX = e.getRawX() - this.dx;
                    float rawY = e.getRawY() - this.dy;
                    if (!this.drag && Math.hypot(rawX, rawY) > this.slop) {
                        this.drag = true;
                    }
                    if (this.drag) {
                        setTranslationX(getTranslationX() + rawX);
                        setTranslationY(getTranslationY() + rawY);
                        this.dx = e.getRawX();
                        this.dy = e.getRawY();
                    }
                }
                return true;
            }
            if (this.scaling) {
                keepIn(true);
                return true;
            }
            if (!this.drag) {
                PipKt.unfloat(this.a);
                return true;
            }
            keepIn(true);
            return true;
        }
        this.dx = e.getRawX();
        this.dy = e.getRawY();
        this.drag = false;
        this.scaling = false;
        System.currentTimeMillis();
        animate().cancel();
        return true;
    }

    public final void report() {
        View view;
        int i;
        Object parent = getParent();
        if (parent instanceof View) {
            view = (View) parent;
        } else {
            view = null;
        }
        if (view == null) {
            return;
        }
        float translationY = getTranslationY() + getTop();
        int visibility = getVisibility();
        MainActivity mainActivity = this.a;
        if (visibility == 0 && !this.pip && view.getHeight() != 0 && translationY >= view.getHeight() / 2.0f) {
            i = (int) ((view.getHeight() - translationY) / mainActivity.getResources().getDisplayMetrics().density);
        } else {
            i = 0;
        }
        mainActivity.getManaging$android_release().cover(false, i);
    }

    public final int width(View view) {
        int i;
        if (view != null) {
            Integer valueOf = Integer.valueOf(view.getWidth());
            if (valueOf.intValue() <= 0) {
                valueOf = null;
            }
            if (valueOf != null) {
                i = valueOf.intValue();
                return (int) ((i - (this.m * 2)) * this.share);
            }
        }
        i = this.a.getResources().getDisplayMetrics().widthPixels;
        return (int) ((i - (this.m * 2)) * this.share);
    }
}
