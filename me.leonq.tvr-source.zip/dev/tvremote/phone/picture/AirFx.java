package dev.tvremote.phone.picture;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.SystemClock;
import android.view.View;
import dev.tvremote.phone.MainActivity;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class AirFx extends View {
    public final RectF box;
    public int count;
    public final float d;
    public int head;
    public boolean held;
    public final int n;
    public boolean on;
    public final Paint p;
    public long rt;
    public float rx;
    public float ry;
    public final boolean still;
    public final long[] ts;
    public final float[] xs;
    public final float[] ys;

    public AirFx(MainActivity mainActivity, boolean z, float f) {
        super(mainActivity);
        this.still = z;
        this.d = f;
        this.n = 12;
        this.xs = new float[12];
        this.ys = new float[12];
        this.ts = new long[12];
        this.p = new Paint(1);
        this.box = new RectF();
        setClickable(false);
        setFocusable(false);
    }

    @Override // android.view.View
    public final void onDraw(Canvas c) {
        boolean z;
        boolean z2;
        int i;
        int i2;
        Intrinsics.checkNotNullParameter(c, "c");
        long uptimeMillis = SystemClock.uptimeMillis();
        boolean z3 = this.held;
        Paint paint = this.p;
        float f = this.d;
        if (z3) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Air.access$accent(34));
            float f2 = 18 * f;
            c.drawRoundRect(this.box, f2, f2, paint);
        }
        paint.setStyle(Paint.Style.FILL);
        float[] fArr = this.ys;
        float[] fArr2 = this.xs;
        boolean z4 = this.still;
        int i3 = 0;
        if (!z4) {
            int i4 = this.count;
            int i5 = 1;
            z = false;
            while (i5 < i4) {
                int i6 = this.head - i5;
                int i7 = this.n;
                int i8 = (i6 + i7) % i7;
                boolean z5 = z4;
                long j = uptimeMillis - this.ts[i8];
                if (j < 320) {
                    float f3 = 1.0f - (((float) j) / 320.0f);
                    paint.setColor(Air.access$accent((int) (80 * f3)));
                    c.drawCircle(fArr2[i8], fArr[i8], ((12 * f3) + 4) * f, paint);
                    z = true;
                }
                i5++;
                z4 = z5;
            }
        } else {
            z = false;
        }
        boolean z6 = z4;
        if (this.on) {
            if (z6) {
                i = 0;
            } else {
                i = this.head;
            }
            float f4 = fArr2[i];
            if (!z6) {
                i3 = this.head;
            }
            float f5 = fArr[i3];
            paint.setStyle(Paint.Style.FILL);
            if (this.held) {
                i2 = 120;
            } else {
                i2 = 72;
            }
            paint.setColor(Air.access$accent(i2));
            float f6 = 28 * f;
            c.drawCircle(f4, f5, f6, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2 * f);
            paint.setColor(Air.access$accent(170));
            c.drawCircle(f4, f5, f6, paint);
        }
        long j2 = uptimeMillis - this.rt;
        if (!z6 && j2 < 340) {
            float f7 = ((float) j2) / 340.0f;
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(3 * f);
            paint.setColor(Air.access$accent((int) ((1.0f - f7) * 190)));
            c.drawCircle(this.rx, this.ry, ((46 * f7) + 16) * f, paint);
            z2 = true;
        } else {
            z2 = z;
        }
        if (z2) {
            postInvalidateOnAnimation();
        }
    }

    @Override // android.view.View
    public final void onSizeChanged(int i, int i2, int i3, int i4) {
        this.box.set(0.0f, 0.0f, i, i2);
    }

    public final void touch(float f, float f2) {
        this.on = true;
        boolean z = this.still;
        float[] fArr = this.ys;
        float[] fArr2 = this.xs;
        if (!z) {
            int i = this.head + 1;
            int i2 = this.n;
            int i3 = i % i2;
            this.head = i3;
            fArr2[i3] = f;
            fArr[i3] = f2;
            this.ts[i3] = SystemClock.uptimeMillis();
            int i4 = this.count;
            if (i4 < i2) {
                this.count = i4 + 1;
            }
        } else {
            fArr2[0] = f;
            fArr[0] = f2;
        }
        invalidate();
    }
}
