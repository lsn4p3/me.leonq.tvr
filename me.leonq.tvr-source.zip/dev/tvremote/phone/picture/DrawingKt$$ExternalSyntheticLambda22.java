package dev.tvremote.phone.picture;

import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.Button;
import dev.tvremote.core.ontv.Setup$$ExternalSyntheticLambda5;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.remote.PhoneRemoteKt;
import dev.tvremote.phone.remote.TypingKt;
import dev.tvremote.phone.ui.IconButton;
import dev.tvremote.phone.ui.Popup;
import kotlin.jvm.internal.Ref$ObjectRef;

/* loaded from: classes.dex */
public final /* synthetic */ class DrawingKt$$ExternalSyntheticLambda22 implements View.OnClickListener {
    public final /* synthetic */ int $r8$classId = 2;
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ int f$1;
    public final /* synthetic */ Object f$2;
    public final /* synthetic */ Object f$3;

    public /* synthetic */ DrawingKt$$ExternalSyntheticLambda22(int i, GradientDrawable gradientDrawable, Button button, MainActivity mainActivity) {
        this.f$0 = mainActivity;
        this.f$2 = button;
        this.f$3 = gradientDrawable;
        this.f$1 = i;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        switch (this.$r8$classId) {
            case 0:
                this.f$0.drawColor = this.f$1;
                ((Setup$$ExternalSyntheticLambda5) this.f$2).invoke();
                Popup popup = (Popup) ((Ref$ObjectRef) this.f$3).element;
                if (popup != null) {
                    popup.dismiss();
                    return;
                }
                return;
            case 1:
                IconButton iconButton = (IconButton) this.f$2;
                Object tag = iconButton.getTag();
                MainActivity mainActivity = this.f$0;
                if (tag == "kind-off") {
                    PhoneRemoteKt.kindOff(mainActivity);
                    return;
                } else {
                    TypingKt.flash(mainActivity, iconButton, (GradientDrawable) this.f$3);
                    TypingKt.opens(this.f$1, mainActivity);
                    return;
                }
            default:
                MainActivity mainActivity2 = this.f$0;
                TypingKt.flash(mainActivity2, (Button) this.f$2, (GradientDrawable) this.f$3);
                TypingKt.opens(this.f$1, mainActivity2);
                return;
        }
    }

    public /* synthetic */ DrawingKt$$ExternalSyntheticLambda22(MainActivity mainActivity, int i, Setup$$ExternalSyntheticLambda5 setup$$ExternalSyntheticLambda5, Ref$ObjectRef ref$ObjectRef) {
        this.f$0 = mainActivity;
        this.f$1 = i;
        this.f$2 = setup$$ExternalSyntheticLambda5;
        this.f$3 = ref$ObjectRef;
    }

    public /* synthetic */ DrawingKt$$ExternalSyntheticLambda22(IconButton iconButton, MainActivity mainActivity, GradientDrawable gradientDrawable, int i) {
        this.f$2 = iconButton;
        this.f$0 = mainActivity;
        this.f$3 = gradientDrawable;
        this.f$1 = i;
    }
}
