package dev.tvremote.phone.picture;

/* loaded from: classes.dex */
public final /* synthetic */ class MiniPlayer$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MiniPlayer f$0;

    public /* synthetic */ MiniPlayer$$ExternalSyntheticLambda0(MiniPlayer miniPlayer, int i) {
        this.$r8$classId = i;
        this.f$0 = miniPlayer;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.$r8$classId) {
            case 0:
                this.f$0.keepIn(false);
                return;
            default:
                this.f$0.report();
                return;
        }
    }
}
