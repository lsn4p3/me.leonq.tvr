package dev.tvremote.phone.picture;

import android.app.PendingIntent;
import android.app.PictureInPictureParams;
import android.content.Intent;
import android.graphics.Rect;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.util.Rational;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import dev.tvremote.core.Fleet;
import dev.tvremote.guard.Guard$$ExternalSyntheticApiModelOutline0;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.manage.Managing;
import dev.tvremote.phone.manage.Managing$$ExternalSyntheticLambda1;
import dev.tvremote.phone.remote.TypingKt;
import dev.tvremote.phone.ui.IconButton;
import java.util.ArrayList;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public abstract class PipKt {
    public static final ArrayList hidden = new ArrayList();

    public static final boolean canPip(MainActivity mainActivity) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        if (Build.VERSION.SDK_INT >= 26 && mainActivity.floating && picLive(mainActivity) && !mainActivity.isFinishing() && mainActivity.getPackageManager().hasSystemFeature("android.software.picture_in_picture")) {
            return true;
        }
        return false;
    }

    public static final boolean picLive(MainActivity mainActivity) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        if (mainActivity.video && mainActivity.basic == null && mainActivity.host != null && mainActivity.pic != null && mainActivity.picShown) {
            return true;
        }
        return false;
    }

    public static final PendingIntent pipIntent(int i, MainActivity mainActivity) {
        PendingIntent broadcast = PendingIntent.getBroadcast(mainActivity, i, new Intent("dev.tvremote.phone.PIP").setPackage(mainActivity.getPackageName()).putExtra("a", i), 201326592);
        Intrinsics.checkNotNullExpressionValue(broadcast, "getBroadcast(...)");
        return broadcast;
    }

    public static final PictureInPictureParams pipParams(MainActivity mainActivity) {
        Rational rational;
        Icon createWithResource;
        String str;
        String str2;
        Icon createWithResource2;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        int i = Build.VERSION.SDK_INT;
        if (i < 26) {
            return null;
        }
        PictureInPictureParams.Builder m = Guard$$ExternalSyntheticApiModelOutline0.m();
        int i2 = mainActivity.vidW;
        if (i2 < 1) {
            i2 = 1;
        }
        int i3 = mainActivity.vidH;
        if (i3 < 1) {
            i3 = 1;
        }
        long j = i2;
        long j2 = i3;
        if (j * 100 > j2 * 239) {
            rational = new Rational(239, 100);
        } else if (j2 * 100 > j * 239) {
            rational = new Rational(100, 239);
        } else {
            rational = new Rational(i2, i3);
        }
        Guard$$ExternalSyntheticApiModelOutline0.m(m, rational);
        Rect rect = new Rect();
        if (mainActivity.getSurface$android_release().isShown() && mainActivity.getSurface$android_release().getGlobalVisibleRect(rect) && !rect.isEmpty()) {
            Guard$$ExternalSyntheticApiModelOutline0.m(m, rect);
        }
        ArrayList arrayList = new ArrayList();
        if (mainActivity.basic == null) {
            boolean z = mainActivity.listen;
            if (z) {
                str = "mute";
            } else {
                str = "headphones";
            }
            if (z) {
                str2 = "float.mute";
            } else {
                str2 = "float.hear";
            }
            String T = Fleet.T(str2, new Pair[0]);
            Guard$$ExternalSyntheticApiModelOutline0.m$1();
            createWithResource2 = Icon.createWithResource(mainActivity, mainActivity.getResources().getIdentifier("ic_".concat(str), "drawable", mainActivity.getPackageName()));
            arrayList.add(Guard$$ExternalSyntheticApiModelOutline0.m(createWithResource2, T, T, pipIntent(1, mainActivity)));
        }
        String T2 = Fleet.T("float.close", new Pair[0]);
        Guard$$ExternalSyntheticApiModelOutline0.m$1();
        createWithResource = Icon.createWithResource(mainActivity, mainActivity.getResources().getIdentifier("ic_close", "drawable", mainActivity.getPackageName()));
        arrayList.add(Guard$$ExternalSyntheticApiModelOutline0.m(createWithResource, T2, T2, pipIntent(2, mainActivity)));
        Guard$$ExternalSyntheticApiModelOutline0.m(m, arrayList);
        if (i >= 31) {
            m.setAutoEnterEnabled(canPip(mainActivity));
            m.setSeamlessResizeEnabled(false);
        }
        return Guard$$ExternalSyntheticApiModelOutline0.m(m);
    }

    public static final void pipUpdate(MainActivity mainActivity) {
        float f;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        if (Build.VERSION.SDK_INT >= 26 && mainActivity.mini != null) {
            IconButton pipBtn$android_release = mainActivity.getPipBtn$android_release();
            if (!picLive(mainActivity) && !mainActivity.floating) {
                f = 0.4f;
            } else {
                f = 1.0f;
            }
            pipBtn$android_release.setAlpha(f);
            try {
                PictureInPictureParams pipParams = pipParams(mainActivity);
                if (pipParams != null) {
                    Guard$$ExternalSyntheticApiModelOutline0.m(mainActivity, pipParams);
                }
            } catch (Exception unused) {
            }
        }
    }

    public static final void setFloat(int i, MainActivity mainActivity) {
        boolean z;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        if (i == mainActivity.floatMode) {
            return;
        }
        mainActivity.floatMode = i;
        ViewGroup viewGroup = null;
        if (i == 0) {
            mainActivity.floating = false;
            mainActivity.getMini$android_release().setVisibility(8);
            ViewParent parent = mainActivity.getFrame$android_release().getParent();
            if (parent instanceof ViewGroup) {
                viewGroup = (ViewGroup) parent;
            }
            if (viewGroup != null) {
                viewGroup.removeView(mainActivity.getFrame$android_release());
            }
            mainActivity.getStage$android_release().addView(mainActivity.getFrame$android_release(), 0, new FrameLayout.LayoutParams(-1, -2));
            TypingKt.layoutRemote(mainActivity);
        } else {
            if (mainActivity.getFrame$android_release().getParent() != mainActivity.getMini$android_release()) {
                ViewParent parent2 = mainActivity.getFrame$android_release().getParent();
                if (parent2 instanceof ViewGroup) {
                    viewGroup = (ViewGroup) parent2;
                }
                if (viewGroup != null) {
                    viewGroup.removeView(mainActivity.getFrame$android_release());
                }
                mainActivity.getMini$android_release().addView(mainActivity.getFrame$android_release(), 0, new FrameLayout.LayoutParams(-1, -2));
            }
            MiniPlayer mini$android_release = mainActivity.getMini$android_release();
            if (i == 2) {
                z = true;
            } else {
                z = false;
            }
            mini$android_release.mode(z);
            mainActivity.getMini$android_release().setVisibility(0);
        }
        mainActivity.getMini$android_release().report();
        pipUpdate(mainActivity);
    }

    public static final void unfloat(MainActivity mainActivity) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        mainActivity.floating = false;
        Managing managing$android_release = mainActivity.getManaging$android_release();
        LinearLayout linearLayout = managing$android_release.view;
        if (linearLayout.getVisibility() == 0) {
            linearLayout.setVisibility(8);
            managing$android_release.web.onPause();
            managing$android_release.web.evaluateJavascript("(function(){ try { return localStorage.getItem('setupUndo') || '' } catch (e) { return '' } })()", new Managing$$ExternalSyntheticLambda1(managing$android_release));
        }
        mainActivity.getSettings$android_release().setVisibility(8);
        mainActivity.getAbout$android_release().setVisibility(8);
        if (mainActivity.floatMode == 1) {
            setFloat(0, mainActivity);
        }
        TypingKt.layoutRemote(mainActivity);
    }
}
