package dev.tvremote.phone.picture;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.util.Base64;
import android.view.View;
import android.view.ViewParent;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;
import dev.tvremote.core.Caps$$ExternalSyntheticApiModelOutline6;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.adb.TvKeyboard;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.core.remote.Ssdp;
import dev.tvremote.core.scenes.Voice;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.ir.IrRemoteKt$$ExternalSyntheticLambda22;
import dev.tvremote.phone.media.TalkKt$$ExternalSyntheticLambda2;
import dev.tvremote.phone.picture.DrawView;
import dev.tvremote.phone.remote.KbdWatch;
import dev.tvremote.phone.ui.UiKt;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.List;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Regex$$ExternalSyntheticLambda0;

/* loaded from: classes.dex */
public final /* synthetic */ class DrawingKt$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;
    public final /* synthetic */ Object f$1;

    public /* synthetic */ DrawingKt$$ExternalSyntheticLambda0(int i, Object obj, Object obj2) {
        this.$r8$classId = i;
        this.f$0 = obj;
        this.f$1 = obj2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        BitmapFactory.Options options;
        int i;
        int attributeInt;
        String str;
        boolean z;
        boolean z2;
        ViewParent viewParent;
        String str2 = "";
        DrawView.Pic pic = null;
        Boolean bool = null;
        ScrollView scrollView = null;
        Object obj = this.f$0;
        Object obj2 = this.f$1;
        switch (this.$r8$classId) {
            case 0:
                MainActivity mainActivity = (MainActivity) obj;
                Uri uri = (Uri) obj2;
                try {
                    String type = mainActivity.getContentResolver().getType(uri);
                    if (type != null) {
                        str2 = type;
                    }
                    options = new BitmapFactory.Options();
                    options.inJustDecodeBounds = true;
                    InputStream openInputStream = mainActivity.getContentResolver().openInputStream(uri);
                    if (openInputStream != null) {
                        try {
                            BitmapFactory.decodeStream(openInputStream, null, options);
                            openInputStream.close();
                        } finally {
                        }
                    }
                    i = 1;
                } catch (Exception unused) {
                }
                while (true) {
                    int i2 = i * 2;
                    if (Math.max(options.outWidth, options.outHeight) / i2 >= 1280) {
                        i = i2;
                    } else {
                        InputStream openInputStream2 = mainActivity.getContentResolver().openInputStream(uri);
                        if (openInputStream2 != null) {
                            try {
                                BitmapFactory.Options options2 = new BitmapFactory.Options();
                                options2.inSampleSize = i;
                                Bitmap decodeStream = BitmapFactory.decodeStream(openInputStream2, null, options2);
                                openInputStream2.close();
                                if (decodeStream != null) {
                                    InputStream openInputStream3 = mainActivity.getContentResolver().openInputStream(uri);
                                    if (openInputStream3 != null) {
                                        try {
                                            if (Build.VERSION.SDK_INT >= 24) {
                                                try {
                                                    attributeInt = Caps$$ExternalSyntheticApiModelOutline6.m(openInputStream3).getAttributeInt("Orientation", 1);
                                                } catch (Exception unused2) {
                                                }
                                                openInputStream3.close();
                                            }
                                            attributeInt = 1;
                                            openInputStream3.close();
                                        } finally {
                                            try {
                                                throw th;
                                            } finally {
                                            }
                                        }
                                    } else {
                                        attributeInt = 1;
                                    }
                                    Bitmap apply = Fleet.apply(decodeStream, attributeInt);
                                    float max = 1280.0f / Math.max(apply.getWidth(), apply.getHeight());
                                    if (max < 1.0f) {
                                        apply = Bitmap.createScaledBitmap(apply, Math.max(1, (int) (apply.getWidth() * max)), Math.max(1, (int) (apply.getHeight() * max)), true);
                                        Intrinsics.checkNotNullExpressionValue(apply, "createScaledBitmap(...)");
                                    }
                                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                                    Pattern compile = Pattern.compile("png|webp|gif");
                                    Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                                    if (compile.matcher(str2).find()) {
                                        apply.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
                                    }
                                    if (byteArrayOutputStream.size() == 0 || byteArrayOutputStream.size() > 3000000) {
                                        byteArrayOutputStream.reset();
                                        apply.compress(Bitmap.CompressFormat.JPEG, 85, byteArrayOutputStream);
                                    }
                                    String encodeToString = Base64.encodeToString(byteArrayOutputStream.toByteArray(), 2);
                                    Intrinsics.checkNotNullExpressionValue(encodeToString, "encodeToString(...)");
                                    pic = new DrawView.Pic(apply, encodeToString);
                                    mainActivity.ui.post(new DrawingKt$$ExternalSyntheticLambda0(pic, mainActivity, 3));
                                    return;
                                }
                            } finally {
                                try {
                                    throw th;
                                } finally {
                                }
                            }
                        }
                        throw new IllegalArgumentException();
                    }
                }
                break;
            case 1:
                ((IrRemoteKt$$ExternalSyntheticLambda22) obj).invoke((String) obj2);
                return;
            case 2:
                MainActivity mainActivity2 = (MainActivity) obj;
                LinearLayout foundList$android_release = mainActivity2.getFoundList$android_release();
                Ssdp.Found found = (Ssdp.Found) obj2;
                if (found.name.length() > 0) {
                    str2 = found.name.concat("\n");
                }
                List list = Remote.Kind.ALL;
                String str3 = found.kind;
                String name = Remote.Kind.name(str3);
                if (str3.equals("vidaa")) {
                    str = "picker.beta_vidaa";
                } else {
                    str = "picker.beta";
                }
                foundList$android_release.addView(UiKt.row(mainActivity2, str2 + found.ip + " · TV " + name + Fleet.T(str, new Pair[0]), new Regex$$ExternalSyntheticLambda0(15, mainActivity2, found)));
                return;
            case 3:
                MainActivity mainActivity3 = (MainActivity) obj;
                DrawView.Pic pic2 = (DrawView.Pic) obj2;
                if (pic2 == null) {
                    Toast.makeText(mainActivity3, Fleet.T("draw.cannot_open_picture", new Pair[0]), 1).show();
                    return;
                }
                if (!mainActivity3.drawing) {
                    Air.startDrawing(mainActivity3);
                }
                mainActivity3.getDrawView$android_release().setPlacing(pic2);
                mainActivity3.getDrawView$android_release().getOnSize().invoke();
                mainActivity3.getDrawView$android_release().invalidate();
                mainActivity3.getDrawBar$android_release().findViewWithTag("pen").setVisibility(8);
                mainActivity3.getDrawBar$android_release().findViewWithTag("pic").setVisibility(0);
                return;
            case 4:
                KbdWatch kbdWatch = (KbdWatch) obj;
                try {
                    bool = Boolean.valueOf(kbdWatch.reader.ask(new TalkKt$$ExternalSyntheticLambda2((Tv) obj2, 10)));
                } catch (Exception unused3) {
                }
                kbdWatch.a.ui.post(new DrawingKt$$ExternalSyntheticLambda0(5, kbdWatch, bool));
                return;
            case 5:
                KbdWatch kbdWatch2 = (KbdWatch) obj;
                kbdWatch2.asking = false;
                Boolean bool2 = (Boolean) obj2;
                if (bool2 != null) {
                    boolean booleanValue = bool2.booleanValue();
                    TvKeyboard.Follow follow = kbdWatch2.follow;
                    if (booleanValue != follow.was) {
                        z = true;
                    } else {
                        z = false;
                    }
                    follow.was = booleanValue;
                    TvKeyboard.Do r7 = TvKeyboard.Do.NONE;
                    if (z) {
                        if (booleanValue) {
                            follow.closed = false;
                            follow.typed = false;
                            follow.opened = true;
                            r7 = TvKeyboard.Do.OPEN;
                        } else {
                            if (follow.opened && !follow.typed && !follow.closed) {
                                z2 = true;
                            } else {
                                z2 = false;
                            }
                            follow.opened = false;
                            if (z2) {
                                r7 = TvKeyboard.Do.CLOSE;
                            }
                        }
                    }
                    int ordinal = r7.ordinal();
                    if (ordinal != 0) {
                        MainActivity mainActivity4 = kbdWatch2.a;
                        if (ordinal != 1) {
                            if (ordinal == 2) {
                                mainActivity4.kbdOpen.invoke(Boolean.FALSE);
                                return;
                            }
                            throw new RuntimeException();
                        }
                        mainActivity4.kbdOpen.invoke(Boolean.TRUE);
                        return;
                    }
                    return;
                }
                return;
            case 6:
                View view = (View) obj2;
                ViewParent parent = view.getParent();
                if (parent != null) {
                    viewParent = parent.getParent();
                } else {
                    viewParent = null;
                }
                if (viewParent instanceof ScrollView) {
                    scrollView = (ScrollView) viewParent;
                }
                if (scrollView != null) {
                    scrollView.smoothScrollTo(0, view.getTop() - Math.max(0, ((scrollView.getHeight() - view.getHeight()) - UiKt.dp((Context) obj, 60)) / 2));
                    return;
                }
                return;
            case 7:
                ((Button) obj).setBackground((Drawable) obj2);
                return;
            case 8:
                ((FrameLayout) obj).setBackground((Drawable) obj2);
                return;
            default:
                MathKt.toast((MainActivity) obj, Fleet.T("auto.search_in_none", new Pair("name", ((Voice.Command.Search) ((Voice.Command) obj2)).name)));
                return;
        }
    }

    public /* synthetic */ DrawingKt$$ExternalSyntheticLambda0(Object obj, MainActivity mainActivity, int i) {
        this.$r8$classId = i;
        this.f$1 = obj;
        this.f$0 = mainActivity;
    }
}
