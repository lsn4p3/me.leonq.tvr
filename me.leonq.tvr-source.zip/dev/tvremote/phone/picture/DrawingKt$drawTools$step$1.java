package dev.tvremote.phone.picture;

import android.os.Handler;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.picture.DrawView;
import kotlin.jvm.internal.Ref$IntRef;
import kotlin.math.MathKt;

/* loaded from: classes.dex */
public final class DrawingKt$drawTools$step$1 implements Runnable {
    public final /* synthetic */ float $k;
    public final /* synthetic */ Ref$IntRef $n;
    public final /* synthetic */ MainActivity $this_drawTools;

    public DrawingKt$drawTools$step$1(MainActivity mainActivity, float f, Ref$IntRef ref$IntRef) {
        this.$this_drawTools = mainActivity;
        this.$k = f;
        this.$n = ref$IntRef;
    }

    @Override // java.lang.Runnable
    public final void run() {
        long max;
        MainActivity mainActivity = this.$this_drawTools;
        DrawView drawView$android_release = mainActivity.getDrawView$android_release();
        DrawView.Pic pic = drawView$android_release.placing;
        if (pic != null) {
            pic.w = MathKt.coerceIn((int) (pic.w * this.$k), 400, 10000);
            drawView$android_release.onSize.invoke();
            drawView$android_release.invalidate();
        }
        Handler handler = mainActivity.ui;
        Ref$IntRef ref$IntRef = this.$n;
        int i = ref$IntRef.element;
        ref$IntRef.element = i + 1;
        if (i == 0) {
            max = 350;
        } else {
            max = Math.max(30L, 120 - (r3 * 6));
        }
        handler.postDelayed(this, max);
    }
}
