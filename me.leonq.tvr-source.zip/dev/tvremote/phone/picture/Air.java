package dev.tvremote.phone.picture;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import dev.tvremote.core.Errors;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Words;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.core.remote.Vidaa$$ExternalSyntheticLambda3;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda15;
import dev.tvremote.phone.ir.IrRemoteKt$$ExternalSyntheticLambda60;
import dev.tvremote.phone.ui.IconButton;
import dev.tvremote.phone.ui.UiKt;
import dev.tvremote.tvapps.ApkCert$$ExternalSyntheticLambda0;
import java.io.File;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$BooleanRef;
import kotlin.jvm.internal.Ref$FloatRef;
import kotlin.jvm.internal.Ref$LongRef;
import kotlin.math.MathKt;
import kotlin.text.StringsKt;
import org.conscrypt.R;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public abstract class Air {
    public static int buttons = 0;
    public static long freezeUntil = 0;
    public static boolean fxLog = false;
    public static AirMouseKt$airListen$l$1 listener = null;
    public static String mode = "arrows";
    public static Tv mouseTv;
    public static boolean padHeld;
    public static long saidAt;
    public static SensorManager sensors;
    public static Thread synth;
    public static HandlerThread thread;
    public static long tickLast;
    public static boolean touching;
    public static Function1 airPick = new ApkCert$$ExternalSyntheticLambda0(16);
    public static final int[] DRAW_COLORS = {-50384, -24822, -10742, -13445301, -12531457, -16098049, -4236558, -38207, -1, -16777216};

    public static final int access$accent(int i) {
        return (i << 24) | (UiKt.ACCENT & 16777215);
    }

    public static final void airButton(MainActivity mainActivity, boolean z) {
        freezeUntil = System.currentTimeMillis() + 80;
        buttons = z ? 1 : 0;
        Tv airTv = airTv(mainActivity);
        if (airTv != null) {
            int i = buttons;
            byte[] bArr = Tv.MOUSE_DESC;
            airTv.mouseMove(0, 0, i, 0);
        } else {
            Remote remote = mainActivity.basic;
            if (remote != null) {
                remote.pointerHold(z);
            }
        }
    }

    public static final boolean airCan(MainActivity mainActivity) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Tv tv = mainActivity.tv;
        Remote remote = mainActivity.basic;
        if (tv == null || !tv.ready()) {
            if (remote != null && remote.ready()) {
                List list = Remote.Kind.ALL;
                if (Remote.Kind.caps(remote.getKind()).contains("mouse")) {
                    return true;
                }
                return false;
            }
            return false;
        }
        return true;
    }

    public static final void airHaptic(View view, int i) {
        view.performHapticFeedback(i);
        if (fxLog) {
            Log.d("airfx", "h" + i);
        }
    }

    public static final void airMove(MainActivity mainActivity, float f, float f2, float[] fArr) {
        float f3 = fArr[0] + f;
        fArr[0] = f3;
        float f4 = fArr[1] + f2;
        fArr[1] = f4;
        int i = (int) f3;
        int i2 = (int) f4;
        if (i != 0 || i2 != 0) {
            fArr[0] = f3 - i;
            fArr[1] = f4 - i2;
            Tv airTv = airTv(mainActivity);
            if (airTv != null) {
                int i3 = buttons;
                byte[] bArr = Tv.MOUSE_DESC;
                airTv.mouseMove(i, i2, i3, 0);
            } else {
                Remote remote = mainActivity.basic;
                if (remote != null) {
                    remote.pointer(i, i2);
                }
            }
        }
    }

    /* JADX WARN: Type inference failed for: r0v13, types: [kotlin.jvm.internal.Ref$BooleanRef, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r10v2, types: [kotlin.jvm.internal.Ref$BooleanRef, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r11v1, types: [java.lang.Object, kotlin.jvm.internal.Ref$FloatRef] */
    /* JADX WARN: Type inference failed for: r12v0, types: [java.lang.Object, kotlin.jvm.internal.Ref$LongRef] */
    /* JADX WARN: Type inference failed for: r12v1, types: [kotlin.jvm.internal.Ref$BooleanRef, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r13v0, types: [java.lang.Object, kotlin.jvm.internal.Ref$FloatRef] */
    /* JADX WARN: Type inference failed for: r13v1, types: [java.lang.Object, kotlin.jvm.internal.Ref$LongRef] */
    /* JADX WARN: Type inference failed for: r14v0, types: [java.lang.Object, kotlin.jvm.internal.Ref$FloatRef] */
    /* JADX WARN: Type inference failed for: r15v1, types: [java.lang.Object, kotlin.jvm.internal.Ref$FloatRef] */
    /* JADX WARN: Type inference failed for: r2v13, types: [java.lang.Object, kotlin.jvm.internal.Ref$FloatRef] */
    /* JADX WARN: Type inference failed for: r3v6, types: [java.lang.Object, kotlin.jvm.internal.Ref$LongRef] */
    /* JADX WARN: Type inference failed for: r4v5, types: [java.lang.Object, kotlin.jvm.internal.Ref$FloatRef] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Object, kotlin.jvm.internal.Ref$FloatRef] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Object, kotlin.jvm.internal.Ref$FloatRef] */
    /* JADX WARN: Type inference failed for: r8v1, types: [java.lang.Object, kotlin.jvm.internal.Ref$LongRef] */
    public static final FrameLayout airPad(final MainActivity mainActivity) {
        boolean z;
        boolean z2;
        final FrameLayout frameLayout = new FrameLayout(mainActivity);
        frameLayout.setBackground(UiKt.box(mainActivity, UiKt.CARD, 18));
        final TextView label = UiKt.label(mainActivity, Fleet.T("air.pad", new Pair[0]), 14, UiKt.MUTED);
        label.setGravity(17);
        label.setPadding(UiKt.dp(mainActivity, 16), 0, UiKt.dp(mainActivity, 68), 0);
        frameLayout.addView(label, new FrameLayout.LayoutParams(-1, -1));
        try {
            if (Settings.Global.getFloat(mainActivity.getContentResolver(), "animator_duration_scale", 1.0f) == 0.0f) {
                z2 = true;
            } else {
                z2 = false;
            }
            z = z2;
        } catch (Exception unused) {
            z = false;
        }
        float f = 1;
        final AirFx airFx = new AirFx(mainActivity, z, UiKt.dp(mainActivity, f));
        frameLayout.addView(airFx, new FrameLayout.LayoutParams(-1, -1));
        final ?? obj = new Object();
        final ?? obj2 = new Object();
        final ?? obj3 = new Object();
        final ?? obj4 = new Object();
        final ?? obj5 = new Object();
        final ?? obj6 = new Object();
        final ?? obj7 = new Object();
        final ?? obj8 = new Object();
        final ?? obj9 = new Object();
        final ?? obj10 = new Object();
        final ?? obj11 = new Object();
        boolean z3 = z;
        final ?? obj12 = new Object();
        final float[] fArr = new float[2];
        final int dp = UiKt.dp(mainActivity, 8);
        final Vidaa$$ExternalSyntheticLambda3 vidaa$$ExternalSyntheticLambda3 = new Vidaa$$ExternalSyntheticLambda3((Object) obj4, mainActivity, frameLayout, airFx, 12);
        frameLayout.setOnTouchListener(new View.OnTouchListener() { // from class: dev.tvremote.phone.picture.AirMouseKt$$ExternalSyntheticLambda4
            /* JADX WARN: Removed duplicated region for block: B:77:0x0126  */
            /* JADX WARN: Removed duplicated region for block: B:79:0x0179  */
            /* JADX WARN: Removed duplicated region for block: B:89:0x02ac  */
            /* JADX WARN: Removed duplicated region for block: B:91:0x02ae  */
            @Override // android.view.View.OnTouchListener
            /*
                Code decompiled incorrectly, please refer to instructions dump.
            */
            public final boolean onTouch(View view, MotionEvent motionEvent) {
                Vidaa$$ExternalSyntheticLambda3 vidaa$$ExternalSyntheticLambda32;
                boolean z4;
                AirFx airFx2;
                Vidaa$$ExternalSyntheticLambda3 vidaa$$ExternalSyntheticLambda33;
                int i;
                AirFx airFx3;
                Ref$FloatRef ref$FloatRef;
                int i2;
                int actionMasked = motionEvent.getActionMasked();
                MainActivity mainActivity2 = MainActivity.this;
                AirFx airFx4 = airFx;
                Ref$LongRef ref$LongRef = obj;
                Ref$FloatRef ref$FloatRef2 = obj2;
                Ref$FloatRef ref$FloatRef3 = obj3;
                Ref$FloatRef ref$FloatRef4 = obj9;
                Ref$FloatRef ref$FloatRef5 = obj10;
                Ref$LongRef ref$LongRef2 = obj11;
                Ref$BooleanRef ref$BooleanRef = obj4;
                Ref$BooleanRef ref$BooleanRef2 = obj12;
                Ref$FloatRef ref$FloatRef6 = obj5;
                Ref$BooleanRef ref$BooleanRef3 = obj8;
                Ref$LongRef ref$LongRef3 = obj7;
                Vidaa$$ExternalSyntheticLambda3 vidaa$$ExternalSyntheticLambda34 = vidaa$$ExternalSyntheticLambda3;
                if (actionMasked != 0) {
                    if (actionMasked != 1) {
                        if (actionMasked != 2) {
                            if (actionMasked != 3) {
                                if (actionMasked != 5) {
                                    if (actionMasked == 6) {
                                        if (motionEvent.getActionIndex() == 0) {
                                            i2 = 1;
                                        } else {
                                            i2 = 0;
                                        }
                                        ref$FloatRef4.element = motionEvent.getX(i2);
                                        ref$FloatRef5.element = motionEvent.getY(i2);
                                        ref$LongRef2.element = motionEvent.getEventTime();
                                        return true;
                                    }
                                } else {
                                    if (!Air.padHeld) {
                                        ref$BooleanRef.element = true;
                                        view.removeCallbacks(vidaa$$ExternalSyntheticLambda34);
                                    }
                                    ref$FloatRef6.element = (motionEvent.getY(1) + motionEvent.getY(0)) / 2;
                                    return true;
                                }
                            } else {
                                vidaa$$ExternalSyntheticLambda33 = vidaa$$ExternalSyntheticLambda34;
                                airFx2 = airFx4;
                            }
                        } else if (motionEvent.getPointerCount() >= 2) {
                            float y = (motionEvent.getY(1) + motionEvent.getY(0)) / 2;
                            Ref$FloatRef ref$FloatRef7 = obj6;
                            float f2 = ref$FloatRef7.element;
                            float f3 = y - ref$FloatRef6.element;
                            boolean z5 = UiKt.LIGHT;
                            ref$FloatRef7.element = (f3 / UiKt.dp(mainActivity2, 14)) + f2;
                            ref$FloatRef6.element = y;
                            float f4 = ref$FloatRef7.element;
                            int i3 = (int) f4;
                            if (i3 != 0) {
                                ref$FloatRef7.element = f4 - i3;
                                Tv airTv = Air.airTv(mainActivity2);
                                if (airTv != null) {
                                    airTv.mouseMove(0, 0, 0, MathKt.coerceIn(i3, -127, 127));
                                } else {
                                    Remote remote = mainActivity2.basic;
                                    if (remote != null) {
                                        remote.pointerScroll(i3);
                                    }
                                }
                                Intrinsics.checkNotNull(view);
                                Air.airTick(view);
                            }
                        } else {
                            if (!ref$BooleanRef2.element) {
                                float abs = Math.abs(motionEvent.getX() - ref$FloatRef2.element);
                                float f5 = dp;
                                if (abs > f5 || Math.abs(motionEvent.getY() - ref$FloatRef3.element) > f5) {
                                    ref$BooleanRef.element = true;
                                    ref$BooleanRef2.element = true;
                                    view.removeCallbacks(vidaa$$ExternalSyntheticLambda34);
                                    if (ref$BooleanRef3.element) {
                                        Air.airButton(mainActivity2, true);
                                        Air.airHaptic(view, 0);
                                        airFx3 = airFx4;
                                        airFx3.held = true;
                                        airFx3.invalidate();
                                        if (!ref$BooleanRef2.element) {
                                            long max = Math.max(1L, motionEvent.getEventTime() - ref$LongRef2.element);
                                            float x = motionEvent.getX() - ref$FloatRef4.element;
                                            boolean z6 = UiKt.LIGHT;
                                            float f6 = 1;
                                            float dp2 = x / UiKt.dp(mainActivity2, f6);
                                            ref$FloatRef = ref$FloatRef5;
                                            float y2 = (motionEvent.getY() - ref$FloatRef.element) / UiKt.dp(mainActivity2, f6);
                                            float min = ((Math.min(((float) Math.hypot(dp2, y2)) / ((float) max), 3.0f) * 0.9f) + 1.0f) * 1.3f;
                                            Air.airMove(mainActivity2, dp2 * min, y2 * min, fArr);
                                        } else {
                                            ref$FloatRef = ref$FloatRef5;
                                        }
                                        ref$FloatRef4.element = motionEvent.getX();
                                        ref$FloatRef.element = motionEvent.getY();
                                        ref$LongRef2.element = motionEvent.getEventTime();
                                        airFx3.touch(motionEvent.getX(), motionEvent.getY());
                                    }
                                }
                            }
                            airFx3 = airFx4;
                            if (!ref$BooleanRef2.element) {
                            }
                            ref$FloatRef4.element = motionEvent.getX();
                            ref$FloatRef.element = motionEvent.getY();
                            ref$LongRef2.element = motionEvent.getEventTime();
                            airFx3.touch(motionEvent.getX(), motionEvent.getY());
                        }
                        return true;
                    }
                    airFx2 = airFx4;
                    vidaa$$ExternalSyntheticLambda33 = vidaa$$ExternalSyntheticLambda34;
                    Air.touching = false;
                    airFx2.on = false;
                    airFx2.invalidate();
                    view.removeCallbacks(vidaa$$ExternalSyntheticLambda33);
                    if (Air.buttons != 0) {
                        Air.airButton(mainActivity2, false);
                        airFx2.held = false;
                        airFx2.invalidate();
                    }
                    boolean z7 = Air.padHeld;
                    Air.padHeld = false;
                    if (motionEvent.getActionMasked() == 1 && !ref$BooleanRef.element && !z7 && motionEvent.getEventTime() - ref$LongRef.element < 400) {
                        Air.freezeUntil = System.currentTimeMillis() + 80;
                        Tv airTv2 = Air.airTv(mainActivity2);
                        if (airTv2 != null) {
                            byte[] bArr = Tv.MOUSE_DESC;
                            airTv2.mouseMove(0, 0, 1, 0);
                            airTv2.mouseMove(0, 0, 0, 0);
                        } else {
                            Remote remote2 = mainActivity2.basic;
                            if (remote2 != null) {
                                remote2.pointerClick();
                            }
                        }
                        if (Build.VERSION.SDK_INT >= 30) {
                            i = 16;
                        } else {
                            i = 1;
                        }
                        Air.airHaptic(view, i);
                        float x2 = motionEvent.getX();
                        float y3 = motionEvent.getY();
                        if (!airFx2.still) {
                            airFx2.rx = x2;
                            airFx2.ry = y3;
                            airFx2.rt = SystemClock.uptimeMillis();
                            airFx2.invalidate();
                        }
                        ref$LongRef3.element = motionEvent.getEventTime();
                    }
                    view.performClick();
                } else {
                    view.getParent().requestDisallowInterceptTouchEvent(true);
                    if (!Air.airCan(mainActivity2)) {
                        long uptimeMillis = SystemClock.uptimeMillis();
                        if (uptimeMillis - Air.saidAt > 4000) {
                            Air.saidAt = uptimeMillis;
                            vidaa$$ExternalSyntheticLambda32 = vidaa$$ExternalSyntheticLambda34;
                            Fleet.say(mainActivity2, Fleet.T("air.needs_adb", new Pair[0]), true);
                            airFx4.touch(motionEvent.getX(), motionEvent.getY());
                            ref$LongRef.element = motionEvent.getEventTime();
                            ref$FloatRef2.element = motionEvent.getX();
                            ref$FloatRef3.element = motionEvent.getY();
                            ref$FloatRef4.element = motionEvent.getX();
                            ref$FloatRef5.element = motionEvent.getY();
                            ref$LongRef2.element = motionEvent.getEventTime();
                            ref$BooleanRef.element = false;
                            ref$BooleanRef2.element = false;
                            ref$FloatRef6.element = 0.0f;
                            Air.touching = true;
                            if (motionEvent.getEventTime() - ref$LongRef3.element >= 300) {
                                z4 = true;
                            } else {
                                z4 = false;
                            }
                            ref$BooleanRef3.element = z4;
                            view.postDelayed(vidaa$$ExternalSyntheticLambda32, 400L);
                        }
                    }
                    vidaa$$ExternalSyntheticLambda32 = vidaa$$ExternalSyntheticLambda34;
                    airFx4.touch(motionEvent.getX(), motionEvent.getY());
                    ref$LongRef.element = motionEvent.getEventTime();
                    ref$FloatRef2.element = motionEvent.getX();
                    ref$FloatRef3.element = motionEvent.getY();
                    ref$FloatRef4.element = motionEvent.getX();
                    ref$FloatRef5.element = motionEvent.getY();
                    ref$LongRef2.element = motionEvent.getEventTime();
                    ref$BooleanRef.element = false;
                    ref$BooleanRef2.element = false;
                    ref$FloatRef6.element = 0.0f;
                    Air.touching = true;
                    if (motionEvent.getEventTime() - ref$LongRef3.element >= 300) {
                    }
                    ref$BooleanRef3.element = z4;
                    view.postDelayed(vidaa$$ExternalSyntheticLambda32, 400L);
                }
                return true;
            }
        });
        final FrameLayout frameLayout2 = new FrameLayout(mainActivity);
        frameLayout2.setBackground(UiKt.box(mainActivity, UiKt.BG, 14));
        final StripFx stripFx = new StripFx(mainActivity, z3, UiKt.dp(mainActivity, f));
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -1);
        layoutParams.bottomMargin = UiKt.dp(mainActivity, 44);
        frameLayout2.addView(stripFx, layoutParams);
        final ?? obj13 = new Object();
        final ?? obj14 = new Object();
        final ?? obj15 = new Object();
        frameLayout2.setOnTouchListener(new View.OnTouchListener() { // from class: dev.tvremote.phone.picture.AirMouseKt$$ExternalSyntheticLambda5
            /* JADX WARN: Code restructure failed: missing block: B:8:0x0016, code lost:
            
                if (r0 != 3) goto L24;
             */
            @Override // android.view.View.OnTouchListener
            /*
                Code decompiled incorrectly, please refer to instructions dump.
            */
            public final boolean onTouch(View view, MotionEvent motionEvent) {
                int i;
                int actionMasked = motionEvent.getActionMasked();
                StripFx stripFx2 = StripFx.this;
                Ref$FloatRef ref$FloatRef = obj13;
                Ref$LongRef ref$LongRef = obj14;
                Ref$FloatRef ref$FloatRef2 = obj15;
                if (actionMasked != 0) {
                    if (actionMasked != 1) {
                        if (actionMasked == 2) {
                            long max = Math.max(1L, motionEvent.getEventTime() - ref$LongRef.element);
                            float y = motionEvent.getY() - ref$FloatRef.element;
                            MainActivity mainActivity2 = mainActivity;
                            boolean z4 = UiKt.LIGHT;
                            float dp2 = y / UiKt.dp(mainActivity2, 1);
                            ref$FloatRef2.element = ((Math.min(Math.abs(dp2) / ((float) max), 2.0f) + 1.0f) * (dp2 / 10.0f)) + ref$FloatRef2.element;
                            ref$FloatRef.element = motionEvent.getY();
                            ref$LongRef.element = motionEvent.getEventTime();
                            int i2 = (int) ref$FloatRef2.element;
                            float y2 = motionEvent.getY();
                            stripFx2.phase = ((y2 - stripFx2.y) + stripFx2.phase) % (stripFx2.d * 18.0f);
                            stripFx2.y = y2;
                            stripFx2.invalidate();
                            if (i2 != 0) {
                                ref$FloatRef2.element -= i2;
                                Tv airTv = Air.airTv(mainActivity2);
                                if (airTv != null) {
                                    airTv.mouseMove(0, 0, 0, MathKt.coerceIn(i2, -127, 127));
                                } else {
                                    Remote remote = mainActivity2.basic;
                                    if (remote != null) {
                                        remote.pointerScroll(i2);
                                    }
                                }
                                Intrinsics.checkNotNull(view);
                                Air.airTick(view);
                                if (i2 > 0) {
                                    i = 1;
                                } else {
                                    i = -1;
                                }
                                stripFx2.dir = i;
                                stripFx2.flashAt = SystemClock.uptimeMillis();
                            }
                        }
                        return true;
                    }
                    Air.touching = false;
                    stripFx2.on = false;
                    stripFx2.upAt = SystemClock.uptimeMillis();
                    stripFx2.invalidate();
                    view.performClick();
                    return true;
                }
                view.getParent().requestDisallowInterceptTouchEvent(true);
                float y3 = motionEvent.getY();
                stripFx2.on = true;
                stripFx2.y = y3;
                stripFx2.invalidate();
                ref$FloatRef.element = motionEvent.getY();
                ref$LongRef.element = motionEvent.getEventTime();
                ref$FloatRef2.element = 0.0f;
                Air.touching = true;
                return true;
            }
        });
        frameLayout.addView(frameLayout2, new FrameLayout.LayoutParams(UiKt.dp(mainActivity, 48), -1));
        final ImageView imageView = new ImageView(mainActivity);
        imageView.setImageResource(R.drawable.ic_close);
        imageView.setColorFilter(UiKt.TEXT);
        imageView.setAlpha(0.35f);
        float f2 = 10;
        imageView.setPadding(UiKt.dp(mainActivity, f2), UiKt.dp(mainActivity, f2), UiKt.dp(mainActivity, f2), UiKt.dp(mainActivity, f2));
        imageView.setContentDescription(Fleet.T("common.close", new Pair[0]));
        imageView.setOnClickListener(new IrRemoteKt$$ExternalSyntheticLambda60(2));
        float f3 = 40;
        frameLayout.addView(imageView, new FrameLayout.LayoutParams(UiKt.dp(mainActivity, f3), UiKt.dp(mainActivity, f3)));
        final ImageView imageView2 = new ImageView(mainActivity);
        imageView2.setImageResource(R.drawable.ic_swap);
        imageView2.setColorFilter(UiKt.TEXT);
        imageView2.setAlpha(0.5f);
        imageView2.setPadding(UiKt.dp(mainActivity, f2), UiKt.dp(mainActivity, f2), UiKt.dp(mainActivity, f2), UiKt.dp(mainActivity, f2));
        imageView2.setContentDescription(Fleet.T("air.swap", new Pair[0]));
        FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(UiKt.dp(mainActivity, f3), UiKt.dp(mainActivity, f3), 81);
        layoutParams2.bottomMargin = UiKt.dp(mainActivity, 4);
        frameLayout2.addView(imageView2, layoutParams2);
        airPad$place(frameLayout2, imageView, label, mainActivity, frameLayout, mainActivity.getPrefs$android_release().getBoolean("airLeft", false));
        imageView2.setOnClickListener(new View.OnClickListener() { // from class: dev.tvremote.phone.picture.AirMouseKt$$ExternalSyntheticLambda7
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MainActivity mainActivity2 = MainActivity.this;
                boolean z4 = !mainActivity2.getPrefs$android_release().getBoolean("airLeft", false);
                mainActivity2.getPrefs$android_release().edit().putBoolean("airLeft", z4).apply();
                Air.airPad$place(frameLayout2, imageView, label, mainActivity2, frameLayout, z4);
                Air.airTick(imageView2);
            }
        });
        return frameLayout;
    }

    public static final void airPad$place(FrameLayout frameLayout, ImageView imageView, TextView textView, MainActivity mainActivity, FrameLayout frameLayout2, boolean z) {
        int i;
        int i2;
        int dp;
        int dp2;
        int i3;
        float f;
        float f2;
        int i4 = 8388613;
        if (z) {
            i = 8388611;
        } else {
            i = 8388613;
        }
        if (!z) {
            i4 = 8388611;
        }
        ViewGroup.LayoutParams layoutParams = frameLayout.getLayoutParams();
        Intrinsics.checkNotNull(layoutParams, "null cannot be cast to non-null type android.widget.FrameLayout.LayoutParams");
        FrameLayout.LayoutParams layoutParams2 = (FrameLayout.LayoutParams) layoutParams;
        layoutParams2.gravity = i;
        if (z) {
            boolean z2 = UiKt.LIGHT;
            i2 = UiKt.dp(mainActivity, 8);
        } else {
            i2 = 0;
        }
        boolean z3 = UiKt.LIGHT;
        float f3 = 8;
        int dp3 = UiKt.dp(mainActivity, f3);
        if (z) {
            dp = 0;
        } else {
            dp = UiKt.dp(mainActivity, f3);
        }
        layoutParams2.setMargins(i2, dp3, dp, UiKt.dp(mainActivity, f3));
        ViewGroup.LayoutParams layoutParams3 = imageView.getLayoutParams();
        Intrinsics.checkNotNull(layoutParams3, "null cannot be cast to non-null type android.widget.FrameLayout.LayoutParams");
        FrameLayout.LayoutParams layoutParams4 = (FrameLayout.LayoutParams) layoutParams3;
        layoutParams4.gravity = i4 | 48;
        if (z) {
            dp2 = 0;
        } else {
            dp2 = UiKt.dp(mainActivity, 4);
        }
        float f4 = 4;
        int dp4 = UiKt.dp(mainActivity, f4);
        if (z) {
            i3 = UiKt.dp(mainActivity, f4);
        } else {
            i3 = 0;
        }
        layoutParams4.setMargins(dp2, dp4, i3, 0);
        if (z) {
            f = 68;
        } else {
            f = 16;
        }
        int dp5 = UiKt.dp(mainActivity, f);
        if (z) {
            f2 = 16;
        } else {
            f2 = 68;
        }
        textView.setPadding(dp5, 0, UiKt.dp(mainActivity, f2), 0);
        frameLayout2.requestLayout();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v1, types: [dev.tvremote.phone.picture.AirMouseKt$airListen$l$1, android.hardware.SensorEventListener] */
    /* JADX WARN: Type inference failed for: r4v0, types: [java.lang.Object, kotlin.jvm.internal.Ref$LongRef] */
    /* JADX WARN: Type inference failed for: r5v0, types: [kotlin.jvm.internal.Ref$BooleanRef, java.lang.Object] */
    public static final void airStart(final MainActivity mainActivity, String mode2) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Intrinsics.checkNotNullParameter(mode2, "mode");
        mode = mode2;
        if (mode2.equals("mouse") && listener == null) {
            boolean z = false;
            touching = false;
            buttons = 0;
            padHeld = false;
            try {
                z = new File(mainActivity.getExternalFilesDir(null), "air_fxlog").exists();
            } catch (Exception unused) {
            }
            fxLog = z;
            Object systemService = mainActivity.getSystemService("sensor");
            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.hardware.SensorManager");
            SensorManager sensorManager = (SensorManager) systemService;
            sensors = sensorManager;
            if (new File(mainActivity.getExternalFilesDir(null), "air_synth").exists()) {
                Thread thread2 = new Thread(new MainActivity$$ExternalSyntheticLambda15(mainActivity, 18));
                thread2.setDaemon(true);
                thread2.start();
                synth = thread2;
            }
            Sensor defaultSensor = sensorManager.getDefaultSensor(4);
            if (defaultSensor == null) {
                defaultSensor = sensorManager.getDefaultSensor(15);
            }
            if (defaultSensor != null) {
                final float[] fArr = new float[2];
                final ?? obj = new Object();
                final float[] fArr2 = new float[3];
                final ?? obj2 = new Object();
                ?? r2 = new SensorEventListener() { // from class: dev.tvremote.phone.picture.AirMouseKt$airListen$l$1
                    @Override // android.hardware.SensorEventListener
                    public final void onAccuracyChanged(Sensor sensor, int i) {
                    }

                    @Override // android.hardware.SensorEventListener
                    public final void onSensorChanged(SensorEvent e) {
                        Intrinsics.checkNotNullParameter(e, "e");
                        boolean z2 = Air.padHeld;
                        Ref$BooleanRef ref$BooleanRef = obj2;
                        Ref$LongRef ref$LongRef = obj;
                        if (z2 || !Air.touching) {
                            MainActivity mainActivity2 = MainActivity.this;
                            if (!mainActivity2.covered$android_release() && System.currentTimeMillis() >= Air.freezeUntil) {
                                int type = e.sensor.getType();
                                float[] fArr3 = fArr;
                                if (type == 4) {
                                    long j = ref$LongRef.element;
                                    if (j == 0) {
                                        ref$LongRef.element = e.timestamp;
                                        return;
                                    }
                                    long j2 = e.timestamp;
                                    float f = ((float) (j2 - j)) / 1.0E9f;
                                    ref$LongRef.element = j2;
                                    if (f > 0.0f && f <= 0.2f) {
                                        float[] fArr4 = e.values;
                                        float f2 = -fArr4[2];
                                        float f3 = -fArr4[0];
                                        float hypot = (float) Math.hypot(f2, f3);
                                        if (hypot >= 0.025f) {
                                            float f4 = ((hypot * 0.45f) + 1.0f) * f * 700.0f;
                                            Air.airMove(mainActivity2, f2 * f4, f3 * f4, fArr3);
                                            return;
                                        }
                                        return;
                                    }
                                    return;
                                }
                                float[] fArr5 = new float[9];
                                float[] fArr6 = new float[3];
                                SensorManager.getRotationMatrixFromVector(fArr5, e.values);
                                SensorManager.getOrientation(fArr5, fArr6);
                                boolean z3 = ref$BooleanRef.element;
                                float[] fArr7 = fArr2;
                                if (!z3) {
                                    fArr7[0] = fArr6[0];
                                    fArr7[1] = fArr6[1];
                                    ref$BooleanRef.element = true;
                                    return;
                                }
                                float f5 = fArr6[0];
                                float f6 = f5 - fArr7[0];
                                double d = f6;
                                if (d > 3.141592653589793d) {
                                    f6 -= 6.2831855f;
                                } else if (d < -3.141592653589793d) {
                                    f6 += 6.2831855f;
                                }
                                float f7 = fArr6[1];
                                float f8 = f7 - fArr7[1];
                                fArr7[0] = f5;
                                fArr7[1] = f7;
                                if (((float) Math.hypot(f6, f8)) < 8.0E-4f) {
                                    return;
                                }
                                Air.airMove(mainActivity2, f6 * 700.0f, (-f8) * 700.0f, fArr3);
                                return;
                            }
                        }
                        ref$LongRef.element = 0L;
                        ref$BooleanRef.element = false;
                    }
                };
                listener = r2;
                HandlerThread handlerThread = new HandlerThread("air-sensor");
                handlerThread.start();
                thread = handlerThread;
                sensorManager.registerListener((SensorEventListener) r2, defaultSensor, 5000, new Handler(handlerThread.getLooper()));
                return;
            }
            return;
        }
        if (!mode2.equals("mouse")) {
            airStop(mainActivity);
        }
    }

    public static final void airStop(MainActivity mainActivity) {
        SensorManager sensorManager;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        if (buttons != 0) {
            airButton(mainActivity, false);
        }
        padHeld = false;
        AirMouseKt$airListen$l$1 airMouseKt$airListen$l$1 = listener;
        if (airMouseKt$airListen$l$1 != null && (sensorManager = sensors) != null) {
            sensorManager.unregisterListener(airMouseKt$airListen$l$1);
        }
        listener = null;
        HandlerThread handlerThread = thread;
        if (handlerThread != null) {
            handlerThread.quitSafely();
        }
        thread = null;
        Thread thread2 = synth;
        if (thread2 != null) {
            thread2.interrupt();
        }
        synth = null;
        Tv tv = mouseTv;
        if (tv != null) {
            tv.mouseStats = null;
            if (tv.mouseOn) {
                tv.mouseOn = false;
                tv.mouseAt = null;
                synchronized (tv.mouseLock) {
                    tv.mouseOut.reset();
                    tv.accDx = 0;
                    tv.accDy = 0;
                    tv.accWheel = 0;
                    tv.accBtn = 0;
                    tv.mousePump = null;
                    tv.mouseLock.notifyAll();
                }
                tv.send(new byte[]{14, 0, 1});
            }
        }
        mouseTv = null;
    }

    public static final void airTick(View view) {
        long uptimeMillis = SystemClock.uptimeMillis();
        if (uptimeMillis - tickLast < 40) {
            return;
        }
        tickLast = uptimeMillis;
        airHaptic(view, 4);
    }

    public static final Tv airTv(MainActivity mainActivity) {
        Tv tv = mainActivity.tv;
        if (tv == null || !tv.ready()) {
            return null;
        }
        if (mouseTv != tv) {
            mouseTv = tv;
            if (!tv.mouseOn) {
                tv.mouseOn = true;
                tv.mouseAt = null;
                tv.mouseHere();
            }
            tv.mouseStats = new ApkCert$$ExternalSyntheticLambda0(17);
        }
        return tv;
    }

    public static final void drawFail(MainActivity mainActivity, Exception exc) {
        String T;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        if (!mainActivity.isFinishing() && !MathKt.offerSetup(mainActivity, exc)) {
            String message = exc.getMessage();
            if (message == null) {
                message = "";
            }
            if (StringsKt.contains(message, "draw:nooverlay", false)) {
                T = Fleet.T("draw.no_overlay", new Pair[0]);
            } else {
                Object obj = Errors.ANDROID;
                ConcurrentHashMap concurrentHashMap = Words.books;
                T = Fleet.T("drawing.could_not_draw_on", new Pair("error", Errors.say(Words.lang, exc)));
            }
            Toast.makeText(mainActivity, T, 1).show();
        }
    }

    public static final void drawLit(MainActivity mainActivity) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        IconButton iconButton = mainActivity.drawBtn;
        if (iconButton == null) {
            return;
        }
        UiKt.setOn$default(iconButton, mainActivity.drawing, 16, 4);
    }

    public static final void drawSend(MainActivity mainActivity, JSONObject jSONObject) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        synchronized (mainActivity.drawQ) {
            try {
                JSONObject jSONObject2 = (JSONObject) CollectionsKt.lastOrNull(mainActivity.drawQ);
                if (Intrinsics.areEqual(jSONObject.optString("o"), "a") && jSONObject2 != null && SetsKt.setOf((Object[]) new String[]{"s", "a"}).contains(jSONObject2.optString("o")) && jSONObject2.optInt("id") == jSONObject.optInt("id")) {
                    JSONArray jSONArray = jSONObject.getJSONArray("p");
                    int length = jSONArray.length();
                    for (int i = 0; i < length; i++) {
                        jSONObject2.getJSONArray("p").put(jSONArray.get(i));
                    }
                } else {
                    mainActivity.drawQ.add(jSONObject);
                }
                if (mainActivity.drawBusy) {
                    return;
                }
                mainActivity.drawBusy = true;
                mainActivity.drawIo.execute(new MainActivity$$ExternalSyntheticLambda15(mainActivity, 19));
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public static final void picEnd(MainActivity mainActivity) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        mainActivity.getDrawView$android_release().setPlacing(null);
        mainActivity.getDrawView$android_release().invalidate();
        View findViewWithTag = mainActivity.getDrawBar$android_release().findViewWithTag("pic");
        if (findViewWithTag != null) {
            findViewWithTag.setVisibility(8);
        }
        View findViewWithTag2 = mainActivity.getDrawBar$android_release().findViewWithTag("pen");
        if (findViewWithTag2 != null) {
            findViewWithTag2.setVisibility(0);
        }
    }

    public static final void startDrawing(MainActivity mainActivity) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        if (mainActivity.basic == null && mainActivity.tv != null) {
            if (!mainActivity.video) {
                mainActivity.toggleVideo$android_release();
            }
            mainActivity.drawing = true;
            mainActivity.getDrawBar$android_release().setVisibility(0);
            drawLit(mainActivity);
            mainActivity.drawIo.execute(new MainActivity$$ExternalSyntheticLambda15(mainActivity, 20));
            return;
        }
        Toast.makeText(mainActivity, Fleet.T("drawing.drawing_on_the_tv", new Pair[0]), 1).show();
    }

    public static final void stopDrawing(MainActivity mainActivity) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        mainActivity.drawing = false;
        mainActivity.getDrawBar$android_release().setVisibility(8);
        drawLit(mainActivity);
        picEnd(mainActivity);
        DrawView drawView$android_release = mainActivity.getDrawView$android_release();
        drawView$android_release.strokes.clear();
        drawView$android_release.landed.clear();
        drawView$android_release.invalidate();
        synchronized (mainActivity.drawQ) {
            mainActivity.drawQ.clear();
        }
        mainActivity.drawIo.execute(new MainActivity$$ExternalSyntheticLambda15(mainActivity, 21));
    }
}
