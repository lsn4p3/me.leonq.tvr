package dev.tvremote.phone.picture;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.FrameLayout;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.ui.UiKt;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;

/* loaded from: classes.dex */
public final /* synthetic */ class DrawingKt$$ExternalSyntheticLambda3 implements Function0 {
    public final /* synthetic */ int $r8$classId = 0;
    public final /* synthetic */ View f$0;
    public final /* synthetic */ MainActivity f$1;

    public /* synthetic */ DrawingKt$$ExternalSyntheticLambda3(View view, MainActivity mainActivity) {
        this.f$0 = view;
        this.f$1 = mainActivity;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        switch (this.$r8$classId) {
            case 0:
                GradientDrawable gradientDrawable = new GradientDrawable();
                gradientDrawable.setShape(1);
                MainActivity mainActivity = this.f$1;
                gradientDrawable.setColor(mainActivity.drawColor);
                gradientDrawable.setStroke((mainActivity.drawWidth / 30) + UiKt.dp(mainActivity, 1), UiKt.TEXT);
                this.f$0.setBackground(gradientDrawable);
                return Unit.INSTANCE;
            default:
                MainActivity mainActivity2 = this.f$1;
                int dp = UiKt.dp((Context) mainActivity2, Math.max(4, mainActivity2.drawWidth / 5));
                this.f$0.setLayoutParams(new FrameLayout.LayoutParams(dp, dp, 17));
                return Unit.INSTANCE;
        }
    }

    public /* synthetic */ DrawingKt$$ExternalSyntheticLambda3(MainActivity mainActivity, View view) {
        this.f$1 = mainActivity;
        this.f$0 = view;
    }
}
