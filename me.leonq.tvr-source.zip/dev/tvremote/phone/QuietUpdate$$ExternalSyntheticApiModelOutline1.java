package dev.tvremote.phone;

/* loaded from: classes.dex */
public abstract /* synthetic */ class QuietUpdate$$ExternalSyntheticApiModelOutline1 {
}
