package dev.tvremote.phone;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.util.Base64;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.manage.Jobs$$ExternalSyntheticLambda0;
import dev.tvremote.core.ontv.Home;
import dev.tvremote.core.remote.Vidaa$$ExternalSyntheticLambda0;
import dev.tvremote.core.scenes.Scenes$$ExternalSyntheticLambda1;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda10;
import dev.tvremote.phone.ir.IrRemoteKt$$ExternalSyntheticLambda58;
import dev.tvremote.phone.media.MediaKt$$ExternalSyntheticLambda4;
import dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda17;
import dev.tvremote.phone.picker.ManyTvsKt;
import dev.tvremote.phone.picker.ManyTvsKt$$ExternalSyntheticLambda36;
import dev.tvremote.phone.picker.ManyTvsKt$$ExternalSyntheticLambda41;
import dev.tvremote.phone.picture.Air;
import dev.tvremote.phone.picture.DrawView;
import dev.tvremote.phone.remote.PhoneRemoteKt;
import dev.tvremote.phone.remote.TypingKt;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.phone.ui.UiKt;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.collections.EmptySet;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import org.conscrypt.FileClientSessionCache;
import org.conscrypt.metrics.ConscryptStatsLog;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda10 implements Function1 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda10(MainActivity mainActivity, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
    }

    /* JADX WARN: Removed duplicated region for block: B:41:0x0199  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x019d  */
    @Override // kotlin.jvm.functions.Function1
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object invoke(Object obj) {
        boolean z;
        int i;
        String m;
        Set set;
        String T;
        int max;
        Integer num;
        String T2;
        final int i2 = 1;
        MainActivity mainActivity = this.f$0;
        final int i3 = 0;
        switch (this.$r8$classId) {
            case 0:
                String it = (String) obj;
                int i4 = MainActivity.$r8$clinit;
                Intrinsics.checkNotNullParameter(it, "it");
                InputStream open = mainActivity.getAssets().open(it);
                Intrinsics.checkNotNullExpressionValue(open, "open(...)");
                return open;
            case 1:
                Function0 f = (Function0) obj;
                Intrinsics.checkNotNullParameter(f, "f");
                mainActivity.ui.post(new IrRemoteKt$$ExternalSyntheticLambda58(mainActivity, f, i2));
                return Unit.INSTANCE;
            case 2:
                Function0 f2 = (Function0) obj;
                Intrinsics.checkNotNullParameter(f2, "f");
                mainActivity.ui.post(new IrRemoteKt$$ExternalSyntheticLambda58(mainActivity, f2, i3));
                return Unit.INSTANCE;
            case 3:
                List ips = (List) obj;
                Intrinsics.checkNotNullParameter(ips, "ips");
                ManyTvsKt.fleetRun$default(mainActivity, Fleet.T("fleet.menu_restart", new Pair[0]), ips, new Vidaa$$ExternalSyntheticLambda0(2), 12);
                return Unit.INSTANCE;
            case 4:
                List ips2 = (List) obj;
                Intrinsics.checkNotNullParameter(ips2, "ips");
                ManyTvsKt.fleetRun$default(mainActivity, Fleet.T("fleet.menu_welcome_off", new Pair[0]), ips2, new ManyTvsKt$$ExternalSyntheticLambda41(mainActivity, i3), 12);
                return Unit.INSTANCE;
            case 5:
                List it2 = (List) obj;
                Intrinsics.checkNotNullParameter(it2, "it");
                MainActivity mainActivity2 = this.f$0;
                Popup.Builder builder = new Popup.Builder(mainActivity2);
                builder.message = Fleet.T("fleet.asking_each", new Pair[0]);
                builder.cancelable = false;
                Popup show = builder.show();
                HashMap hashMap = new HashMap();
                HashMap hashMap2 = new HashMap();
                HashSet hashSet = new HashSet();
                ExecutorService newFixedThreadPool = Executors.newFixedThreadPool(3);
                Iterator it3 = it2.iterator();
                while (it3.hasNext()) {
                    newFixedThreadPool.execute(new Jobs$$ExternalSyntheticLambda0(mainActivity2, (String) it3.next(), hashMap, hashMap2, hashSet));
                }
                newFixedThreadPool.shutdown();
                new Thread(new ManyTvsKt$$ExternalSyntheticLambda36(newFixedThreadPool, mainActivity2, show, hashMap2, hashMap, hashSet, it2)).start();
                return Unit.INSTANCE;
            case 6:
                List it4 = (List) obj;
                Intrinsics.checkNotNullParameter(it4, "it");
                MainActivity mainActivity3 = this.f$0;
                Popup.Builder builder2 = new Popup.Builder(mainActivity3);
                builder2.message = Fleet.T("fleet.asking_each", new Pair[0]);
                builder2.cancelable = false;
                Popup show2 = builder2.show();
                HashMap hashMap3 = new HashMap();
                HashMap hashMap4 = new HashMap();
                HashMap hashMap5 = new HashMap();
                ArrayList arrayList = new ArrayList();
                HashSet hashSet2 = new HashSet();
                ExecutorService newFixedThreadPool2 = Executors.newFixedThreadPool(3);
                Iterator it5 = it4.iterator();
                while (it5.hasNext()) {
                    HashMap hashMap6 = hashMap4;
                    HashMap hashMap7 = hashMap5;
                    hashMap4 = hashMap6;
                    hashMap5 = hashMap7;
                    newFixedThreadPool2.execute(new ManyTvsKt$$ExternalSyntheticLambda36(mainActivity3, (String) it5.next(), hashMap3, hashMap6, hashMap7, arrayList, hashSet2));
                }
                newFixedThreadPool2.shutdown();
                new Thread(new AdbHelpKt$$ExternalSyntheticLambda17(newFixedThreadPool2, mainActivity3, show2, hashMap3, it4, hashSet2, arrayList, hashMap4, hashMap5)).start();
                return Unit.INSTANCE;
            case 7:
                String it6 = (String) obj;
                Intrinsics.checkNotNullParameter(it6, "it");
                return "• ".concat(mainActivity.title$android_release(it6));
            case 8:
                String it7 = (String) obj;
                Intrinsics.checkNotNullParameter(it7, "it");
                return mainActivity.title$android_release(it7);
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                String it8 = (String) obj;
                Intrinsics.checkNotNullParameter(it8, "it");
                return "• ".concat(mainActivity.title$android_release(it8));
            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                String ip = (String) obj;
                Intrinsics.checkNotNullParameter(ip, "ip");
                String str = (String) mainActivity.route.get(ip);
                if (str == null) {
                    str = ip;
                }
                return new Triple(str, TypingKt.kindOf(mainActivity, ip), mainActivity.getFilesDir());
            case 11:
                String it9 = (String) obj;
                Intrinsics.checkNotNullParameter(it9, "it");
                Paint paint = new Paint(1);
                paint.setTextSize(72.0f);
                paint.setTypeface(Typeface.DEFAULT_BOLD);
                paint.setTextAlign(Paint.Align.CENTER);
                ArrayList arrayList2 = new ArrayList();
                Iterator it10 = StringsKt.split$default(it9, new char[]{'\n'}).iterator();
                while (it10.hasNext()) {
                    String str2 = "";
                    for (String str3 : new Regex("\\s+").split((String) it10.next(), 0)) {
                        if (str2.length() == 0) {
                            m = str3;
                        } else {
                            m = Census$$ExternalSyntheticOutline0.m(str2, " ", str3);
                        }
                        if (str2.length() > 0 && paint.measureText(m) > 1100.0f) {
                            arrayList2.add(str2);
                            str2 = str3;
                        } else {
                            str2 = m;
                        }
                    }
                    arrayList2.add(str2);
                }
                Iterator it11 = arrayList2.iterator();
                if (it11.hasNext()) {
                    float measureText = paint.measureText((String) it11.next());
                    while (it11.hasNext()) {
                        measureText = Math.max(measureText, paint.measureText((String) it11.next()));
                    }
                    int i5 = ((int) measureText) + 81;
                    int size = (arrayList2.size() * 92) + 60;
                    Bitmap createBitmap = Bitmap.createBitmap(i5, size, Bitmap.Config.ARGB_8888);
                    Intrinsics.checkNotNullExpressionValue(createBitmap, "createBitmap(...)");
                    Canvas canvas = new Canvas(createBitmap);
                    if (mainActivity.drawColor == -16777216) {
                        z = true;
                    } else {
                        z = false;
                    }
                    float f3 = i5;
                    RectF rectF = new RectF(0.0f, 0.0f, f3, size);
                    Paint paint2 = new Paint(1);
                    if (z) {
                        i = -419430401;
                    } else {
                        i = -654311424;
                    }
                    paint2.setColor(i);
                    canvas.drawRoundRect(rectF, 32.0f, 32.0f, paint2);
                    paint.setColor(mainActivity.drawColor);
                    Iterator it12 = arrayList2.iterator();
                    int i6 = 0;
                    while (it12.hasNext()) {
                        Object next = it12.next();
                        int i7 = i6 + 1;
                        if (i6 >= 0) {
                            canvas.drawText((String) next, f3 / 2.0f, ((i6 * 92) + 40) - paint.ascent(), paint);
                            i6 = i7;
                        } else {
                            CollectionsKt__CollectionsKt.throwIndexOverflow();
                            throw null;
                        }
                    }
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    createBitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
                    if (!mainActivity.drawing) {
                        Air.startDrawing(mainActivity);
                    }
                    DrawView drawView$android_release = mainActivity.getDrawView$android_release();
                    String encodeToString = Base64.encodeToString(byteArrayOutputStream.toByteArray(), 2);
                    Intrinsics.checkNotNullExpressionValue(encodeToString, "encodeToString(...)");
                    DrawView.Pic pic = new DrawView.Pic(createBitmap, encodeToString);
                    int min = Math.min(9000, (i5 * 10000) / 1920);
                    pic.w = min;
                    pic.base = min;
                    drawView$android_release.setPlacing(pic);
                    mainActivity.getDrawView$android_release().getOnSize().invoke();
                    mainActivity.getDrawView$android_release().invalidate();
                    mainActivity.getDrawBar$android_release().findViewWithTag("pen").setVisibility(8);
                    mainActivity.getDrawBar$android_release().findViewWithTag("pic").setVisibility(0);
                    return Unit.INSTANCE;
                }
                throw new NoSuchElementException();
            case FileClientSessionCache.MAX_SIZE /* 12 */:
                String it13 = (String) obj;
                Intrinsics.checkNotNullParameter(it13, "it");
                Intrinsics.checkNotNullParameter(mainActivity, "<this>");
                Fleet.openLink(mainActivity, "https://play.google.com/store/apps/details?id=".concat(it13));
                return Unit.INSTANCE;
            case 13:
                String it14 = (String) obj;
                Intrinsics.checkNotNullParameter(it14, "it");
                Fleet.openLink(mainActivity, "market://search?c=apps&q=" + URLEncoder.encode(it14, "UTF-8"));
                return Unit.INSTANCE;
            case 14:
                String it15 = (String) obj;
                Intrinsics.checkNotNullParameter(it15, "it");
                Pattern compile = Pattern.compile("^[a-zA-Z][a-zA-Z0-9+.-]*:");
                Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                if (!compile.matcher(it15).find()) {
                    it15 = "https://".concat(it15);
                }
                String youtubeUrl = Home.youtubeUrl(it15);
                if (youtubeUrl == null) {
                    youtubeUrl = it15;
                }
                Fleet.askLink(mainActivity, youtubeUrl, new MediaKt$$ExternalSyntheticLambda4(mainActivity, it15, 11));
                return Unit.INSTANCE;
            case 15:
                String name = (String) obj;
                Intrinsics.checkNotNullParameter(name, "name");
                Drawable mutate = mainActivity.getResources().getDrawable(mainActivity.getResources().getIdentifier("ic_".concat(name), "drawable", mainActivity.getPackageName()), null).mutate();
                mutate.setTint(UiKt.TEXT);
                return mutate;
            case 16:
                JSONObject r = (JSONObject) obj;
                Intrinsics.checkNotNullParameter(r, "r");
                if (!MathKt.needsSetup(mainActivity, r)) {
                    long optLong = r.optLong("sleep_at");
                    final MainActivity$$ExternalSyntheticLambda10 mainActivity$$ExternalSyntheticLambda10 = new MainActivity$$ExternalSyntheticLambda10(mainActivity, 19);
                    if (optLong > 0) {
                        set = MathKt.setOf("timerOn");
                    } else {
                        set = EmptySet.INSTANCE;
                    }
                    ArrayList remoteMenu = PhoneRemoteKt.remoteMenu(mainActivity, "timer", set, MapsKt__MapsKt.mapOf(new Pair("lengths", new Function0(mainActivity$$ExternalSyntheticLambda10) { // from class: dev.tvremote.phone.scenes.AutomationKt$$ExternalSyntheticLambda29
                        public final /* synthetic */ MainActivity$$ExternalSyntheticLambda10 f$0;

                        {
                            this.f$0 = mainActivity$$ExternalSyntheticLambda10;
                        }

                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            switch (i3) {
                                case 0:
                                    return (List) this.f$0.invoke(new int[]{30, 60, 120});
                                default:
                                    return (List) this.f$0.invoke(new int[]{15, 45, 90});
                            }
                        }
                    }), new Pair("lengthsMore", new Function0(mainActivity$$ExternalSyntheticLambda10) { // from class: dev.tvremote.phone.scenes.AutomationKt$$ExternalSyntheticLambda29
                        public final /* synthetic */ MainActivity$$ExternalSyntheticLambda10 f$0;

                        {
                            this.f$0 = mainActivity$$ExternalSyntheticLambda10;
                        }

                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            switch (i2) {
                                case 0:
                                    return (List) this.f$0.invoke(new int[]{30, 60, 120});
                                default:
                                    return (List) this.f$0.invoke(new int[]{15, 45, 90});
                            }
                        }
                    })));
                    if (optLong > 0) {
                        T = Fleet.T("automation.the_tv_turns_off_2", new Pair("time", MathKt.hm(optLong, r.optLong("now"))));
                    } else {
                        T = Fleet.T("remote.sleep_timer", new Pair[0]);
                    }
                    if (optLong <= 0) {
                        i3 = -1;
                    }
                    UiKt.menu(mainActivity, T, i3, remoteMenu);
                }
                return Unit.INSTANCE;
            case 17:
                String it16 = (String) obj;
                Intrinsics.checkNotNullParameter(it16, "it");
                Calendar now = Calendar.getInstance();
                Intrinsics.checkNotNullParameter(now, "now");
                String lowerCase = StringsKt.trim(it16).toString().toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                if (lowerCase.length() > 0) {
                    for (int i8 = 0; i8 < lowerCase.length(); i8++) {
                        if (Character.isDigit(lowerCase.charAt(i8))) {
                        }
                    }
                    Integer intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull(lowerCase);
                    if (intOrNull != null) {
                        int intValue = intOrNull.intValue();
                        if (1 <= intValue && intValue < 1441) {
                            num = intOrNull;
                        } else {
                            num = null;
                        }
                        if (num != null) {
                            max = num.intValue();
                            if (max <= 0) {
                                MathKt.setTimer(max, mainActivity);
                            } else {
                                MathKt.toast(mainActivity, Fleet.T("auto.sleep_bad", new Pair[0]));
                            }
                            return Unit.INSTANCE;
                        }
                    }
                    max = 0;
                    if (max <= 0) {
                    }
                    return Unit.INSTANCE;
                }
                MatcherMatchResult access$findNext = MathKt.access$findNext(Census$$ExternalSyntheticOutline0.m6m("^(\\d{1,2})\\s*[:hg.]\\s*(\\d{2})?$", "compile(...)", lowerCase, "matcher(...)"), 0, lowerCase);
                if (access$findNext != null) {
                    int parseInt = Integer.parseInt((String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1));
                    CharSequence charSequence = (CharSequence) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(2);
                    if (charSequence.length() == 0) {
                        charSequence = "0";
                    }
                    int parseInt2 = Integer.parseInt((String) charSequence);
                    if (parseInt <= 23 && parseInt2 <= 59) {
                        Object clone = now.clone();
                        Intrinsics.checkNotNull(clone, "null cannot be cast to non-null type java.util.Calendar");
                        Calendar calendar = (Calendar) clone;
                        calendar.set(11, parseInt);
                        calendar.set(12, parseInt2);
                        calendar.set(13, 0);
                        calendar.set(14, 0);
                        if (!calendar.after(now)) {
                            calendar.add(5, 1);
                        }
                        max = Math.max(1, (int) Math.round((calendar.getTimeInMillis() - now.getTimeInMillis()) / 60000.0d));
                        if (max <= 0) {
                        }
                        return Unit.INSTANCE;
                    }
                }
                max = 0;
                if (max <= 0) {
                }
                return Unit.INSTANCE;
            case 18:
                JSONObject x = (JSONObject) obj;
                Intrinsics.checkNotNullParameter(x, "x");
                MathKt.toast(mainActivity, Fleet.T("automation.the_tv_turns_off", new Pair("time", MathKt.hm(x.optLong("sleep_at"), x.optLong("now")))));
                return Unit.INSTANCE;
            default:
                int[] ms = (int[]) obj;
                Intrinsics.checkNotNullParameter(ms, "ms");
                ArrayList arrayList3 = new ArrayList(ms.length);
                for (int i9 : ms) {
                    if (i9 < 60) {
                        T2 = Fleet.T("automation.off_in_min", new Pair("n", Integer.valueOf(i9)));
                    } else if (i9 % 60 > 0) {
                        T2 = Fleet.T("automation.off_in_h_30", new Pair("n", Integer.valueOf(i9 / 60)));
                    } else {
                        T2 = Fleet.T("automation.off_in_h", new Pair("n", Integer.valueOf(i9 / 60)));
                    }
                    arrayList3.add(new Triple(T2, "", new Scenes$$ExternalSyntheticLambda1(mainActivity, i9, i2)));
                }
                return arrayList3;
        }
    }
}
