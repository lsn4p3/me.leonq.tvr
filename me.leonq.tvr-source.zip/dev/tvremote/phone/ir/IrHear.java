package dev.tvremote.phone.ir;

import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.Adb$$ExternalSyntheticLambda0;
import java.io.Closeable;
import java.util.concurrent.ConcurrentHashMap;

/* loaded from: classes.dex */
public final class IrHear implements Closeable {
    public volatile boolean closed;
    public volatile long lastKey;
    public volatile long lastScan;
    public final Adb.Stream s;
    public volatile long scanValue = -1;

    public IrHear(Adb adb) {
        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
        this.s = adb.open(10000L, "shell:getevent -l");
        Thread thread = new Thread(new Adb$$ExternalSyntheticLambda0(6, this), "ir-hear");
        thread.setDaemon(true);
        thread.start();
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        this.closed = true;
        try {
            this.s.close();
        } catch (Exception unused) {
        }
    }
}
