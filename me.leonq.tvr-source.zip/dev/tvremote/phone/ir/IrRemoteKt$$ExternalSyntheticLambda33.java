package dev.tvremote.phone.ir;

import android.view.View;
import android.widget.Toast;
import dev.tvremote.core.Fleet;
import dev.tvremote.phone.MainActivity;
import java.util.ArrayList;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.internal.Ref$IntRef;
import kotlin.jvm.internal.Ref$ObjectRef;

/* loaded from: classes.dex */
public final /* synthetic */ class IrRemoteKt$$ExternalSyntheticLambda33 implements View.OnClickListener {
    public final /* synthetic */ int $r8$classId = 1;
    public final /* synthetic */ ArrayList f$0;
    public final /* synthetic */ Ref$IntRef f$1;
    public final /* synthetic */ MainActivity f$2;
    public final /* synthetic */ Ref$ObjectRef f$3;

    public /* synthetic */ IrRemoteKt$$ExternalSyntheticLambda33(MainActivity mainActivity, Ref$IntRef ref$IntRef, ArrayList arrayList, Ref$ObjectRef ref$ObjectRef) {
        this.f$2 = mainActivity;
        this.f$1 = ref$IntRef;
        this.f$0 = arrayList;
        this.f$3 = ref$ObjectRef;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        switch (this.$r8$classId) {
            case 0:
                Pair pair = (Pair) CollectionsKt.getOrNull(this.f$1.element, this.f$0);
                if (pair != null) {
                    MainActivity mainActivity = this.f$2;
                    mainActivity.buzz$android_release();
                    IrRemoteKt.irSend(mainActivity, (String) MapsKt__MapsKt.getValue(((IrProfile) pair.first).keys, this.f$3.element), false);
                    return;
                }
                return;
            default:
                MainActivity mainActivity2 = this.f$2;
                mainActivity2.buzz$android_release();
                Ref$IntRef ref$IntRef = this.f$1;
                int i = ref$IntRef.element + 1;
                ArrayList arrayList = this.f$0;
                if (i >= arrayList.size()) {
                    Toast.makeText(mainActivity2, Fleet.T("ir.end", new Pair[0]), 1).show();
                    return;
                }
                Ref$ObjectRef ref$ObjectRef = this.f$3;
                IrRemoteKt.irFind(mainActivity2, (String) ref$ObjectRef.element, ref$IntRef.element + 1);
                IrRemoteKt.irSend(mainActivity2, (String) MapsKt__MapsKt.getValue(((IrProfile) ((Pair) arrayList.get(ref$IntRef.element + 1)).first).keys, ref$ObjectRef.element), false);
                return;
        }
    }

    public /* synthetic */ IrRemoteKt$$ExternalSyntheticLambda33(ArrayList arrayList, Ref$IntRef ref$IntRef, MainActivity mainActivity, Ref$ObjectRef ref$ObjectRef) {
        this.f$0 = arrayList;
        this.f$1 = ref$IntRef;
        this.f$2 = mainActivity;
        this.f$3 = ref$ObjectRef;
    }
}
