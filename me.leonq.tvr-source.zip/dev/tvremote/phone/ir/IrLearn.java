package dev.tvremote.phone.ir;

import dev.tvremote.home.HomeQr$$ExternalSyntheticLambda0;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public abstract class IrLearn {
    public static final List KEYS = ArraysKt.asList(new String[]{"HOME", "BACK", "UP", "DOWN", "LEFT", "RIGHT", "OK", "MENU", "VOL_UP", "VOL_DOWN", "MUTE", "POWER"});
    public static final List READINGS = ArraysKt.asList(new Reading[]{new Reading("wire", new HomeQr$$ExternalSyntheticLambda0(27)), new Reading("rc32", new HomeQr$$ExternalSyntheticLambda0(28)), new Reading("nec16", new HomeQr$$ExternalSyntheticLambda0(29))});

    /* loaded from: classes.dex */
    public final class Reading {
        public final Function1 of;

        public Reading(String str, Function1 function1) {
            this.of = function1;
        }
    }

    public static LinkedHashMap build(LinkedHashMap linkedHashMap) {
        if (linkedHashMap.size() >= 4 && CollectionsKt.toSet(linkedHashMap.values()).size() == linkedHashMap.size()) {
            for (Reading reading : READINGS) {
                LinkedHashMap linkedHashMap2 = new LinkedHashMap(MapsKt__MapsKt.mapCapacity(linkedHashMap.size()));
                for (Map.Entry entry : linkedHashMap.entrySet()) {
                    linkedHashMap2.put(entry.getKey(), (Pair) reading.of.invoke(entry.getValue()));
                }
                Collection values = linkedHashMap2.values();
                if (values == null || !values.isEmpty()) {
                    Iterator it = values.iterator();
                    while (it.hasNext()) {
                        if (((Pair) it.next()) == null) {
                            break;
                        }
                    }
                }
                Collection<Pair> values2 = linkedHashMap2.values();
                ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(values2));
                for (Pair pair : values2) {
                    Intrinsics.checkNotNull(pair);
                    arrayList.add((String) pair.first);
                }
                if (CollectionsKt.toSet(arrayList).size() == 1) {
                    Collection<Pair> values3 = linkedHashMap2.values();
                    ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(values3));
                    for (Pair pair2 : values3) {
                        Intrinsics.checkNotNull(pair2);
                        arrayList2.add((String) pair2.second);
                    }
                    if (CollectionsKt.toSet(arrayList2).size() == linkedHashMap2.size()) {
                        LinkedHashMap linkedHashMap3 = new LinkedHashMap(MapsKt__MapsKt.mapCapacity(linkedHashMap2.size()));
                        for (Map.Entry entry2 : linkedHashMap2.entrySet()) {
                            Object key = entry2.getKey();
                            Object value = entry2.getValue();
                            Intrinsics.checkNotNull(value);
                            Object value2 = entry2.getValue();
                            Intrinsics.checkNotNull(value2);
                            linkedHashMap3.put(key, "NEC " + ((Pair) value).first + " " + ((Pair) value2).second);
                        }
                        if (!linkedHashMap3.isEmpty()) {
                            for (Map.Entry entry3 : linkedHashMap3.entrySet()) {
                                String str = (String) entry3.getKey();
                                HashSet scans = IrEvents.scans((String) entry3.getValue());
                                if (scans != null && scans.contains(MapsKt__MapsKt.getValue(linkedHashMap, str))) {
                                }
                            }
                        }
                        return linkedHashMap3;
                    }
                    continue;
                } else {
                    continue;
                }
            }
            return null;
        }
        return null;
    }

    public static String hex(int i) {
        String hexString = Integer.toHexString(i & 255);
        Intrinsics.checkNotNullExpressionValue(hexString, "toHexString(...)");
        String upperCase = hexString.toUpperCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
        return upperCase;
    }
}
