package dev.tvremote.phone.ir;

import android.R;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.hardware.ConsumerIrManager;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.adb.AdbLink$$ExternalSyntheticLambda1;
import dev.tvremote.core.ontv.Axml$$ExternalSyntheticLambda2;
import dev.tvremote.core.remote.Lg$$ExternalSyntheticLambda2;
import dev.tvremote.core.remote.Vidaa$$ExternalSyntheticLambda3;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda9;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda10;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda15;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda30;
import dev.tvremote.phone.media.TalkKt$$ExternalSyntheticLambda1;
import dev.tvremote.phone.picker.PickerScreenKt;
import dev.tvremote.phone.ui.IconButton;
import dev.tvremote.phone.ui.UiKt;
import dev.tvremote.phone.ui.UiKt$$ExternalSyntheticLambda1;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyList;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$IntRef;
import kotlin.jvm.internal.Ref$ObjectRef;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgressionIterator;
import kotlin.ranges.IntRange;
import kotlin.sequences.ConstrainedOnceSequence;
import kotlin.sequences.Sequence;
import kotlin.sequences.SequencesKt;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public abstract class IrRemoteKt {
    public static final Set ONCE = MathKt.setOf("POWER");

    public static final String getTitle(IrProfile irProfile) {
        Intrinsics.checkNotNullParameter(irProfile, "<this>");
        String str = irProfile.brand;
        int i = irProfile.kind;
        if (i == 0) {
            return str;
        }
        return Census$$ExternalSyntheticOutline0.m(str, " · ", Fleet.T("ir.kind", new Pair("n", Integer.valueOf(i))));
    }

    public static void irAuto$default(final MainActivity mainActivity, String str, String str2, IrProfile irProfile, int i) {
        final String str3;
        final String str4;
        final boolean z;
        if ((i & 1) != 0) {
            str3 = "";
        } else {
            str3 = str;
        }
        if ((i & 2) != 0) {
            str4 = "";
        } else {
            str4 = str2;
        }
        if ((i & 4) != 0) {
            irProfile = null;
        }
        final IrProfile irProfile2 = irProfile;
        if ((i & 8) != 0) {
            z = false;
        } else {
            z = true;
        }
        IrState.onFind = true;
        IrState.page = "auto";
        final String irTvName = irTvName(mainActivity, IrState.auto);
        irPage(mainActivity, Fleet.T("ir.find", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity, 5), new Function1() { // from class: dev.tvremote.phone.ir.IrRemoteKt$$ExternalSyntheticLambda20
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                String str5;
                String T;
                View button;
                int i2 = 6;
                int i3 = 8;
                int i4 = 1;
                LinearLayout irPage = (LinearLayout) obj;
                Intrinsics.checkNotNullParameter(irPage, "$this$irPage");
                String T2 = Fleet.T("ir.auto_hint", new Pair("name", irTvName));
                MainActivity mainActivity2 = MainActivity.this;
                irPage.addView(UiKt.note(mainActivity2, T2), UiKt.gap(mainActivity2, 10));
                LinearLayout col = UiKt.col(mainActivity2);
                col.setBackground(UiKt.box(mainActivity2, UiKt.CARD, 14));
                float f = 16;
                float f2 = 14;
                col.setPadding(UiKt.dp(mainActivity2, f), UiKt.dp(mainActivity2, f2), UiKt.dp(mainActivity2, f), UiKt.dp(mainActivity2, f2));
                IrProfile irProfile3 = irProfile2;
                String str6 = str3;
                if (irProfile3 != null) {
                    str5 = Fleet.T("ir.auto_found", new Pair("name", IrRemoteKt.getTitle(irProfile3)));
                } else if (str6.length() == 0) {
                    str5 = Fleet.T("ir.ready", new Pair[0]);
                } else {
                    str5 = str6;
                }
                TextView label = UiKt.label(mainActivity2, str5, 20, UiKt.TEXT);
                label.setTypeface(Typeface.DEFAULT_BOLD);
                col.addView(label);
                String str7 = str4;
                if (str7.length() > 0) {
                    col.addView(UiKt.label(mainActivity2, str7, 14, UiKt.MUTED), UiKt.gap(mainActivity2, 4));
                }
                boolean z2 = z;
                if (z2) {
                    ProgressBar progressBar = new ProgressBar(mainActivity2, null, R.attr.progressBarStyleHorizontal);
                    progressBar.setIndeterminate(true);
                    progressBar.setProgressTintList(ColorStateList.valueOf(UiKt.ACCENT));
                    col.addView(progressBar, UiKt.gap(mainActivity2, 8));
                }
                irPage.addView(col, UiKt.gap(mainActivity2, 14));
                if (irProfile3 != null) {
                    button = UiKt.button(mainActivity2, Fleet.T("ir.use", new Pair[0]), UiKt.ACCENT);
                    button.setOnClickListener(new Guard$$ExternalSyntheticLambda9(i4, mainActivity2, irProfile3));
                } else if (z2) {
                    button = UiKt.button(mainActivity2, Fleet.T("ir.stop", new Pair[0]), UiKt.BTN);
                    button.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(mainActivity2, 5));
                } else {
                    if (str6.length() == 0) {
                        T = Fleet.T("ir.auto_start", new Pair[0]);
                    } else {
                        T = Fleet.T("ir.retry", new Pair[0]);
                    }
                    button = UiKt.button(mainActivity2, T, UiKt.ACCENT);
                    button.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(mainActivity2, i2));
                }
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, UiKt.dp(mainActivity2, 56));
                layoutParams.topMargin = UiKt.dp(mainActivity2, 4);
                irPage.addView(button, layoutParams);
                Button button2 = UiKt.button(mainActivity2, ApkSigner$$ExternalSyntheticOutline0.m("@search|", Fleet.T("ir.by_hand", new Pair[0])), UiKt.SOFT);
                UiKt.setInk(button2, UiKt.ACCENT_TEXT);
                button2.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(mainActivity2, 7));
                float f3 = 48;
                LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, UiKt.dp(mainActivity2, f3));
                float f4 = 10;
                layoutParams2.topMargin = UiKt.dp(mainActivity2, f4);
                irPage.addView(button2, layoutParams2);
                if (!z2) {
                    Button button3 = UiKt.button(mainActivity2, ApkSigner$$ExternalSyntheticOutline0.m("@gamepad|", Fleet.T("ir.learn", new Pair[0])), UiKt.SOFT);
                    UiKt.setInk(button3, UiKt.ACCENT_TEXT);
                    button3.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(mainActivity2, i3));
                    LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, UiKt.dp(mainActivity2, f3));
                    layoutParams3.topMargin = UiKt.dp(mainActivity2, f4);
                    irPage.addView(button3, layoutParams3);
                    irPage.addView(UiKt.note(mainActivity2, Fleet.T("ir.learn_sub", new Pair[0])), UiKt.gap(mainActivity2, 6));
                }
                return Unit.INSTANCE;
            }
        });
    }

    public static final boolean irAvailable(MainActivity mainActivity) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        ConsumerIrManager consumerIrManager = null;
        try {
            Object systemService = mainActivity.getSystemService("consumer_ir");
            if (systemService instanceof ConsumerIrManager) {
                consumerIrManager = (ConsumerIrManager) systemService;
            }
        } catch (Exception unused) {
        }
        if ((consumerIrManager != null && consumerIrManager.hasIrEmitter()) || (mainActivity.getApplicationInfo().flags & 2) != 0) {
            return true;
        }
        return false;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:10:0x008e, code lost:
    
        r2 = 135;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x0043, code lost:
    
        if (r0.equals("RC5X") == false) goto L89;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0067, code lost:
    
        r2 = 114;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x0064, code lost:
    
        if (r0.equals("RC5") == false) goto L89;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0070, code lost:
    
        if (r0.equals("NEC") != false) goto L92;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x0079, code lost:
    
        if (r0.equals("Samsung32") == false) goto L89;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0082, code lost:
    
        if (r0.equals("SIRC20") == false) goto L89;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x008b, code lost:
    
        if (r0.equals("SIRC15") == false) goto L89;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x0097, code lost:
    
        if (r0.equals("NECext") == false) goto L89;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0039, code lost:
    
        if (r0.equals("SIRC") == false) goto L89;
     */
    /* JADX WARN: Removed duplicated region for block: B:36:0x009f  */
    /* JADX WARN: Type inference failed for: r5v0, types: [dev.tvremote.phone.ir.IrRemoteKt$irBind$again$1] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void irBind(final MainActivity mainActivity, Button button, IrProfile irProfile, final String str, final GradientDrawable gradientDrawable) {
        Ir$Signal encode;
        final String str2 = (String) irProfile.keys.get(str);
        if (str2 == null) {
            button.setAlpha(0.3f);
            button.setEnabled(false);
            return;
        }
        final Drawable background = button.getBackground();
        String obj = StringsKt.trim(str2).toString();
        String substringBefore = StringsKt.substringBefore(obj, ' ', obj);
        int i = 108;
        switch (substringBefore.hashCode()) {
            case -1996073675:
                break;
            case -1848821909:
                break;
            case -1848821883:
                break;
            case -1083519047:
                break;
            case 77164:
                break;
            case 80932:
                break;
            case 80933:
                if (substringBefore.equals("RC6")) {
                    i = 107;
                    break;
                }
                encode = Fleet.encode(false, str2);
                if (encode != null) {
                    i = Math.max(108, ((int) (encode.getMicros() / 1000)) + 40);
                    break;
                }
                break;
            case 80944:
                if (substringBefore.equals("RCA")) {
                    i = 80;
                    break;
                }
                encode = Fleet.encode(false, str2);
                if (encode != null) {
                }
                break;
            case 2508980:
                break;
            case 2545415:
                break;
            default:
                encode = Fleet.encode(false, str2);
                if (encode != null) {
                }
                break;
        }
        final long j = i;
        final ?? r5 = new Runnable() { // from class: dev.tvremote.phone.ir.IrRemoteKt$irBind$again$1
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity mainActivity2 = MainActivity.this;
                IrRemoteKt.irSend(mainActivity2, str2, true);
                mainActivity2.ui.postDelayed(this, j);
            }
        };
        button.setOnTouchListener(new View.OnTouchListener() { // from class: dev.tvremote.phone.ir.IrRemoteKt$$ExternalSyntheticLambda24
            @Override // android.view.View.OnTouchListener
            public final boolean onTouch(View view, MotionEvent motionEvent) {
                int actionMasked = motionEvent.getActionMasked();
                IrRemoteKt$irBind$again$1 irRemoteKt$irBind$again$1 = r5;
                MainActivity mainActivity2 = mainActivity;
                if (actionMasked != 0) {
                    if (actionMasked == 1 || actionMasked == 3) {
                        mainActivity2.ui.removeCallbacks(irRemoteKt$irBind$again$1);
                        view.setBackground(background);
                        return true;
                    }
                } else {
                    view.setBackground(gradientDrawable);
                    mainActivity2.buzz$android_release();
                    IrRemoteKt.irSend(mainActivity2, str2, false);
                    if (!IrRemoteKt.ONCE.contains(str)) {
                        mainActivity2.ui.postDelayed(irRemoteKt$irBind$again$1, j);
                    }
                }
                return true;
            }
        });
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v11 */
    /* JADX WARN: Type inference failed for: r1v9, types: [java.lang.Iterable] */
    public static final ArrayList irCatalog(MainActivity mainActivity) {
        Object obj;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        List irCustom = irCustom(mainActivity);
        Object obj2 = IrState.catalog;
        ?? r1 = obj2;
        if (obj2 == null) {
            try {
                ArrayList arrayList = IrCodes.KEYS;
                InputStream open = mainActivity.getAssets().open("ir/codes.json");
                Intrinsics.checkNotNullExpressionValue(open, "open(...)");
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(open, Charsets.UTF_8), 8192);
                try {
                    String readText = MathKt.readText(bufferedReader);
                    bufferedReader.close();
                    obj = IrCodes.merge(IrCodes.parse(readText));
                } finally {
                }
            } catch (Exception unused) {
                obj = EmptyList.INSTANCE;
            }
            Object obj3 = obj;
            IrState.catalog = obj3;
            r1 = obj3;
        }
        return CollectionsKt.plus(irCustom, (Iterable) r1);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v0, types: [java.util.List, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r3v0, types: [kotlin.collections.EmptyList] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.util.List, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r3v3, types: [java.util.ArrayList] */
    public static final List irCustom(MainActivity mainActivity) {
        ?? r3;
        ?? r2 = IrState.custom;
        if (r2 == 0) {
            try {
                String pref$android_release = mainActivity.pref$android_release("ir:custom");
                if (pref$android_release.length() == 0) {
                    pref$android_release = "[]";
                }
                JSONArray jSONArray = new JSONArray(pref$android_release);
                IntRange until = MathKt.until(0, jSONArray.length());
                r3 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until));
                Iterator it = until.iterator();
                while (((IntProgressionIterator) it).hasNext) {
                    JSONObject jSONObject = jSONArray.getJSONObject(((IntProgressionIterator) it).nextInt());
                    JSONObject jSONObject2 = jSONObject.getJSONObject("keys");
                    String string = jSONObject.getString("id");
                    Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                    String string2 = jSONObject.getString("name");
                    Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
                    String string3 = jSONObject.getString("name");
                    Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
                    Iterator<String> keys = jSONObject2.keys();
                    Intrinsics.checkNotNullExpressionValue(keys, "keys(...)");
                    Sequence asSequence = SequencesKt.asSequence(keys);
                    LinkedHashMap linkedHashMap = new LinkedHashMap();
                    Iterator it2 = ((ConstrainedOnceSequence) asSequence).iterator();
                    while (it2.hasNext()) {
                        Object next = it2.next();
                        linkedHashMap.put(next, jSONObject2.getString((String) next));
                    }
                    r3.add(new IrProfile(string, string2, string3, linkedHashMap));
                }
            } catch (Exception unused) {
                r3 = EmptyList.INSTANCE;
            }
            IrState.custom = r3;
            return r3;
        }
        return r2;
    }

    public static final IrProfile irCustomKeep(MainActivity mainActivity, String str, String str2, LinkedHashMap linkedHashMap) {
        List irCustom = irCustom(mainActivity);
        ArrayList arrayList = new ArrayList();
        for (Object obj : irCustom) {
            if (!Intrinsics.areEqual(((IrProfile) obj).id, str)) {
                arrayList.add(obj);
            }
        }
        ArrayList plus = CollectionsKt.plus(arrayList, new IrProfile(str, str2, str2, linkedHashMap));
        JSONArray jSONArray = new JSONArray();
        Iterator it = plus.iterator();
        while (it.hasNext()) {
            IrProfile irProfile = (IrProfile) it.next();
            jSONArray.put(new JSONObject().put("id", irProfile.id).put("name", irProfile.brand).put("keys", new JSONObject(irProfile.keys)));
        }
        mainActivity.getPrefs$android_release().edit().putString("ir:custom", jSONArray.toString()).apply();
        IrState.custom = plus;
        return (IrProfile) CollectionsKt.last(plus);
    }

    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    /* JADX WARN: Type inference failed for: r5v1, types: [kotlin.jvm.internal.Ref$IntRef, java.lang.Object] */
    public static final void irFind(MainActivity mainActivity, String str, int i) {
        IrState.onFind = true;
        IrState.page = "";
        ?? obj = new Object();
        obj.element = str;
        ?? obj2 = new Object();
        obj2.element = i;
        ArrayList arrayList = IrCodes.KEYS;
        irPage(mainActivity, Fleet.T("ir.find", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity, 7), new IrRemoteKt$$ExternalSyntheticLambda22(mainActivity, (Ref$IntRef) obj2, IrCodes.distinct((String) obj.element, irCatalog(mainActivity)), (Ref$ObjectRef) obj));
    }

    public static /* synthetic */ void irFind$default(MainActivity mainActivity) {
        irFind(mainActivity, "POWER", -1);
    }

    public static final void irKeep(MainActivity mainActivity, List list) {
        JSONArray jSONArray = new JSONArray();
        Iterator it = list.iterator();
        while (it.hasNext()) {
            Pair pair = (Pair) it.next();
            String str = (String) pair.first;
            jSONArray.put(new JSONObject().put("name", str).put("id", (String) pair.second));
        }
        mainActivity.getPrefs$android_release().edit().putString("ir:saved", jSONArray.toString()).apply();
    }

    public static void irLearn$default(final MainActivity mainActivity, final String str, String str2, int i, int i2) {
        final int i3;
        final boolean z;
        if ((i2 & 2) != 0) {
            str2 = "";
        }
        final String str3 = str2;
        if ((i2 & 4) != 0) {
            i3 = 0;
        } else {
            i3 = i;
        }
        if ((i2 & 8) != 0) {
            z = true;
        } else {
            z = false;
        }
        IrState.onFind = true;
        IrState.page = "auto";
        irPage(mainActivity, Fleet.T("ir.find", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity, 11), new Function1() { // from class: dev.tvremote.phone.ir.IrRemoteKt$$ExternalSyntheticLambda57
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                LinearLayout irPage = (LinearLayout) obj;
                Intrinsics.checkNotNullParameter(irPage, "$this$irPage");
                MainActivity mainActivity2 = MainActivity.this;
                LinearLayout col = UiKt.col(mainActivity2);
                col.setBackground(UiKt.box(mainActivity2, UiKt.CARD, 14));
                float f = 16;
                float f2 = 14;
                col.setPadding(UiKt.dp(mainActivity2, f), UiKt.dp(mainActivity2, f2), UiKt.dp(mainActivity2, f), UiKt.dp(mainActivity2, f2));
                TextView label = UiKt.label(mainActivity2, str, 20, UiKt.TEXT);
                label.setTypeface(Typeface.DEFAULT_BOLD);
                col.addView(label);
                String str4 = str3;
                if (str4.length() > 0) {
                    col.addView(UiKt.label(mainActivity2, str4, 14, UiKt.MUTED), UiKt.gap(mainActivity2, 4));
                }
                boolean z2 = z;
                if (z2) {
                    ProgressBar progressBar = new ProgressBar(mainActivity2, null, R.attr.progressBarStyleHorizontal);
                    progressBar.setIndeterminate(true);
                    progressBar.setProgressTintList(ColorStateList.valueOf(UiKt.ACCENT));
                    col.addView(progressBar, UiKt.gap(mainActivity2, 8));
                }
                irPage.addView(col, UiKt.gap(mainActivity2, 14));
                if (z2) {
                    View button = UiKt.button(mainActivity2, Fleet.T("ir.learn_skip", new Pair[0]), UiKt.BTN);
                    button.setOnClickListener(new IrRemoteKt$$ExternalSyntheticLambda60(0));
                    float f3 = 52;
                    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, UiKt.dp(mainActivity2, f3));
                    layoutParams.topMargin = UiKt.dp(mainActivity2, 4);
                    irPage.addView(button, layoutParams);
                    int i4 = i3;
                    if (i4 >= 4) {
                        View button2 = UiKt.button(mainActivity2, Fleet.T("ir.learn_done", new Pair("n", Integer.valueOf(i4))), UiKt.ACCENT);
                        button2.setOnClickListener(new IrRemoteKt$$ExternalSyntheticLambda60(1));
                        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, UiKt.dp(mainActivity2, f3));
                        layoutParams2.topMargin = UiKt.dp(mainActivity2, 10);
                        irPage.addView(button2, layoutParams2);
                    }
                } else {
                    View button3 = UiKt.button(mainActivity2, Fleet.T("ir.retry", new Pair[0]), UiKt.ACCENT);
                    button3.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(mainActivity2, 9));
                    LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, UiKt.dp(mainActivity2, 56));
                    layoutParams3.topMargin = UiKt.dp(mainActivity2, 4);
                    irPage.addView(button3, layoutParams3);
                }
                return Unit.INSTANCE;
            }
        });
    }

    public static final void irLearnRun(MainActivity mainActivity) {
        String str = IrState.auto;
        String irTvName = irTvName(mainActivity, str);
        IrState.stop = false;
        IrState.skip = false;
        IrState.finish = false;
        irLearn$default(mainActivity, Fleet.T("ir.auto_connecting", new Pair("name", irTvName)), null, 0, 14);
        new Thread(new Vidaa$$ExternalSyntheticLambda3(str, (Object) mainActivity, (Object) new MainActivity$$ExternalSyntheticLambda10(mainActivity, 2), irTvName, 1), "ir-learn").start();
    }

    public static final void irList(MainActivity mainActivity) {
        IrState.onFind = false;
        IrState.page = "list";
        IrState.slot = -1;
        irPage(mainActivity, Fleet.T("ir.title", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity, 6), new IrRemoteKt$$ExternalSyntheticLambda2(0, mainActivity, irSaved(mainActivity)));
    }

    public static final void irOpen(MainActivity mainActivity, String str) {
        String str2;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        SharedPreferences.Editor edit = mainActivity.getPrefs$android_release().edit();
        if (str == null) {
            str2 = "";
        } else {
            str2 = str;
        }
        edit.putString("ir:tv", str2).apply();
        Object obj = IrState.catalog;
        IrState.slot = -1;
        if (str == null) {
            irList(mainActivity);
        } else {
            irRemote(mainActivity);
        }
        mainActivity.getIrHost$android_release().setVisibility(0);
    }

    public static final void irPage(MainActivity mainActivity, String str, Function0 function0, Function1 function1) {
        LinearLayout col = UiKt.col(mainActivity);
        float f = 16;
        col.setPadding(UiKt.dp(mainActivity, f), UiKt.dp(mainActivity, 20), UiKt.dp(mainActivity, f), UiKt.dp(mainActivity, 24));
        TextView label = UiKt.label(mainActivity, str, 24, UiKt.TEXT);
        label.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout linearLayout = new LinearLayout(mainActivity);
        linearLayout.setGravity(16);
        linearLayout.addView(label, new LinearLayout.LayoutParams(0, -2, 1.0f));
        IconButton icon = UiKt.icon(mainActivity, "@check", Fleet.T("drawing.done", new Pair[0]), UiKt.ACCENT);
        icon.setOnClickListener(new UiKt$$ExternalSyntheticLambda1(function0, 1));
        linearLayout.addView(icon, new LinearLayout.LayoutParams(UiKt.dp(mainActivity, 52), UiKt.dp(mainActivity, 44)));
        col.addView(linearLayout);
        function1.invoke(col);
        ScrollView scrollView = new ScrollView(mainActivity);
        scrollView.setBackgroundColor(UiKt.BG);
        scrollView.setClickable(true);
        scrollView.addView(col);
        mainActivity.getIrHost$android_release().removeAllViews();
        mainActivity.getIrHost$android_release().addView(scrollView, new FrameLayout.LayoutParams(-1, -1));
    }

    public static final LinearLayout irPill(MainActivity mainActivity, IrProfile irProfile, String str, Triple triple, Triple triple2) {
        LinearLayout col = UiKt.col(mainActivity);
        col.setBackground(UiKt.box(mainActivity, UiKt.BTN, 26));
        IconButton icon = UiKt.icon(mainActivity, (String) triple.second, (String) triple.third, 0);
        irBind(mainActivity, icon, irProfile, (String) triple.first, UiKt.box(mainActivity, UiKt.HELD, 26));
        IconButton icon2 = UiKt.icon(mainActivity, (String) triple2.second, (String) triple2.third, 0);
        irBind(mainActivity, icon2, irProfile, (String) triple2.first, UiKt.box(mainActivity, UiKt.HELD, 26));
        TextView label = UiKt.label(mainActivity, str, 13, UiKt.MUTED);
        label.setGravity(17);
        label.setTypeface(Typeface.DEFAULT_BOLD);
        col.addView(icon, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        col.addView(label, new LinearLayout.LayoutParams(-1, -2));
        col.addView(icon2, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        return col;
    }

    /* JADX WARN: Code restructure failed: missing block: B:27:0x0045, code lost:
    
        if (r0 != null) goto L48;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final IrProfile irProfile(MainActivity mainActivity) {
        String str;
        Object obj;
        String concat;
        if (irTarget(mainActivity).length() > 0) {
            String irTarget = irTarget(mainActivity);
            if (irTarget.length() == 0) {
                concat = "ir:profile";
            } else {
                concat = "ir:profile:".concat(irTarget);
            }
            str = mainActivity.pref$android_release(concat);
            if (str.length() == 0) {
                str = mainActivity.pref$android_release("ir:profile");
            }
        } else {
            if (IrState.slot >= 0) {
                Pair pair = (Pair) CollectionsKt.getOrNull(IrState.slot, irSaved(mainActivity));
                if (pair != null) {
                    str = (String) pair.second;
                }
            }
            str = "";
        }
        Iterator it = irCatalog(mainActivity).iterator();
        while (true) {
            if (it.hasNext()) {
                obj = it.next();
                if (((IrProfile) obj).ids.contains(str)) {
                    break;
                }
            } else {
                obj = null;
                break;
            }
        }
        return (IrProfile) obj;
    }

    public static final void irRemote(MainActivity mainActivity) {
        String str;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        IrState.onFind = false;
        IrState.page = "";
        IrProfile irProfile = irProfile(mainActivity);
        Pair pair = (Pair) CollectionsKt.getOrNull(IrState.slot, irSaved(mainActivity));
        if (pair != null) {
            str = (String) pair.first;
        } else {
            str = null;
        }
        if (str == null) {
            str = Fleet.T("ir.title", new Pair[0]);
        }
        irPage(mainActivity, str, new TalkKt$$ExternalSyntheticLambda1(mainActivity, 8), new Axml$$ExternalSyntheticLambda2(7, mainActivity, irProfile));
    }

    public static final void irRename(final int i, final MainActivity mainActivity) {
        final ArrayList mutableList = CollectionsKt.toMutableList((Collection) irSaved(mainActivity));
        if (i >= 0 && i < mutableList.size()) {
            Fleet.askText(mainActivity, Fleet.T("ir.name_title", new Pair[0]), Fleet.T("ir.name_hint", new Pair[0]), Fleet.T("ir.save", new Pair[0]), (String) ((Pair) mutableList.get(i)).first, new Function1() { // from class: dev.tvremote.phone.ir.IrRemoteKt$$ExternalSyntheticLambda17
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    String n = (String) obj;
                    Intrinsics.checkNotNullParameter(n, "n");
                    ArrayList arrayList = mutableList;
                    int i2 = i;
                    arrayList.set(i2, new Pair(n, ((Pair) arrayList.get(i2)).second));
                    MainActivity mainActivity2 = mainActivity;
                    IrRemoteKt.irKeep(mainActivity2, arrayList);
                    if (IrState.page.equals("list")) {
                        IrRemoteKt.irList(mainActivity2);
                    } else if (IrState.page.equals("") && !IrState.onFind) {
                        IrRemoteKt.irRemote(mainActivity2);
                    }
                    return Unit.INSTANCE;
                }
            });
        }
    }

    public static final LinearLayout irRow(MainActivity mainActivity, IrProfile irProfile, int i, Triple... tripleArr) {
        boolean z;
        LinearLayout linearLayout = new LinearLayout(mainActivity);
        int length = tripleArr.length;
        int i2 = 0;
        int i3 = 0;
        while (i2 < length) {
            Triple triple = tripleArr[i2];
            int i4 = i3 + 1;
            String str = (String) triple.first;
            IconButton icon = UiKt.icon(mainActivity, (String) triple.second, (String) triple.third, UiKt.BTN);
            irBind(mainActivity, icon, irProfile, str, UiKt.box(mainActivity, UiKt.HELD, 16));
            if (i3 > 0) {
                z = true;
            } else {
                z = false;
            }
            linearLayout.addView(icon, UiKt.cell(i, mainActivity, z));
            i2++;
            i3 = i4;
        }
        return linearLayout;
    }

    public static final void irSave(MainActivity mainActivity, IrProfile irProfile) {
        String str;
        Object obj;
        String concat;
        if (irTarget(mainActivity).length() > 0) {
            SharedPreferences.Editor edit = mainActivity.getPrefs$android_release().edit();
            String irTarget = irTarget(mainActivity);
            if (irTarget.length() == 0) {
                concat = "ir:profile";
            } else {
                concat = "ir:profile:".concat(irTarget);
            }
            edit.putString(concat, irProfile.id).apply();
            return;
        }
        ArrayList mutableList = CollectionsKt.toMutableList((Collection) irSaved(mainActivity));
        int i = IrState.slot;
        if (i >= 0 && i < mutableList.size()) {
            Pair pair = (Pair) mutableList.get(i);
            String str2 = (String) pair.first;
            String str3 = (String) pair.second;
            Iterator it = irCatalog(mainActivity).iterator();
            while (true) {
                str = null;
                if (it.hasNext()) {
                    obj = it.next();
                    if (((IrProfile) obj).ids.contains(str3)) {
                        break;
                    }
                } else {
                    obj = null;
                    break;
                }
            }
            IrProfile irProfile2 = (IrProfile) obj;
            if (irProfile2 != null) {
                str = getTitle(irProfile2);
            }
            if (Intrinsics.areEqual(str2, str)) {
                str2 = getTitle(irProfile);
            }
            mutableList.set(i, new Pair(str2, irProfile.id));
            irKeep(mainActivity, mutableList);
            return;
        }
        mutableList.add(new Pair(getTitle(irProfile), irProfile.id));
        irKeep(mainActivity, mutableList);
        IrState.slot = mutableList.size() - 1;
        mainActivity.ui.post(new MainActivity$$ExternalSyntheticLambda15(mainActivity, 8));
    }

    public static final List irSaved(MainActivity mainActivity) {
        String pref$android_release = mainActivity.pref$android_release("ir:saved");
        int length = pref$android_release.length();
        EmptyList emptyList = EmptyList.INSTANCE;
        if (length == 0) {
            String pref$android_release2 = mainActivity.pref$android_release("ir:profile");
            Object obj = null;
            if (pref$android_release2.length() <= 0) {
                pref$android_release2 = null;
            }
            if (pref$android_release2 != null) {
                Iterator it = irCatalog(mainActivity).iterator();
                while (true) {
                    if (!it.hasNext()) {
                        break;
                    }
                    Object next = it.next();
                    if (((IrProfile) next).ids.contains(pref$android_release2)) {
                        obj = next;
                        break;
                    }
                }
                IrProfile irProfile = (IrProfile) obj;
                if (irProfile != null) {
                    List listOf = MathKt.listOf(new Pair(getTitle(irProfile), irProfile.id));
                    irKeep(mainActivity, listOf);
                    return listOf;
                }
            }
        } else {
            try {
                JSONArray jSONArray = new JSONArray(pref$android_release);
                IntRange until = MathKt.until(0, jSONArray.length());
                ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until));
                Iterator it2 = until.iterator();
                while (((IntProgressionIterator) it2).hasNext) {
                    JSONObject jSONObject = jSONArray.getJSONObject(((IntProgressionIterator) it2).nextInt());
                    arrayList.add(new Pair(jSONObject.optString("name"), jSONObject.optString("id")));
                }
                return arrayList;
            } catch (Exception unused) {
            }
        }
        return emptyList;
    }

    public static final void irSend(MainActivity mainActivity, String code, boolean z) {
        Ir$Signal encode;
        if (!z) {
            IrState.toggle = !IrState.toggle;
        }
        ConsumerIrManager consumerIrManager = null;
        if (z) {
            boolean z2 = IrState.toggle;
            Intrinsics.checkNotNullParameter(code, "code");
            String obj = StringsKt.trim(code).toString();
            String substringBefore = StringsKt.substringBefore(obj, ' ', obj);
            if (!substringBefore.equals("NEC") && !substringBefore.equals("NECext")) {
                encode = Fleet.encode(z2, code);
            } else if (Fleet.encode(false, code) == null) {
                encode = null;
            } else {
                encode = new Ir$Signal(38000, new int[]{9000, 2250, 560});
            }
        } else {
            encode = Fleet.encode(IrState.toggle, code);
        }
        if (encode == null) {
            return;
        }
        try {
            Object systemService = mainActivity.getSystemService("consumer_ir");
            if (systemService instanceof ConsumerIrManager) {
                consumerIrManager = (ConsumerIrManager) systemService;
            }
        } catch (Exception unused) {
        }
        if (consumerIrManager != null && consumerIrManager.hasIrEmitter()) {
            IrState.io.execute(new Lg$$ExternalSyntheticLambda2(consumerIrManager, encode, mainActivity, 10));
            return;
        }
        long micros = encode.getMicros();
        int[] iArr = (int[]) encode.pattern;
        StringBuilder sb = new StringBuilder();
        sb.append((CharSequence) "");
        int i = 0;
        for (int i2 : iArr) {
            i++;
            if (i > 1) {
                sb.append((CharSequence) ",");
            }
            sb.append((CharSequence) String.valueOf(i2));
        }
        sb.append((CharSequence) "");
        Log.i("TvrIr", "send " + code + " hz=" + encode.hz + " us=" + micros + " pattern=" + sb.toString());
    }

    public static final void irStop() {
        Object obj = IrState.catalog;
        IrState.stop = true;
        AdbLink adbLink = IrState.link;
        if (adbLink != null) {
            new Thread(new AdbLink$$ExternalSyntheticLambda1(adbLink, 1)).start();
        }
    }

    public static final String irTarget(MainActivity mainActivity) {
        String pref$android_release = mainActivity.pref$android_release("ir:tv");
        if (!PickerScreenKt.savedIps(mainActivity).contains(pref$android_release)) {
            pref$android_release = null;
        }
        if (pref$android_release == null) {
            return "";
        }
        return pref$android_release;
    }

    public static final String irTvName(MainActivity mainActivity, String str) {
        String pref$android_release = mainActivity.pref$android_release("name:" + str);
        if (pref$android_release.length() == 0) {
            return str;
        }
        return pref$android_release;
    }

    public static final void irUp(MainActivity mainActivity) {
        if (irTarget(mainActivity).length() == 0) {
            Object obj = IrState.catalog;
            if (!IrState.page.equals("list")) {
                irList(mainActivity);
                return;
            }
        }
        mainActivity.getIrHost$android_release().setVisibility(8);
    }

    public static final int nearest(ConsumerIrManager consumerIrManager, int i) {
        ConsumerIrManager.CarrierFrequencyRange[] carrierFrequencyRangeArr;
        int min;
        int min2;
        ConsumerIrManager.CarrierFrequencyRange carrierFrequencyRange = null;
        try {
            carrierFrequencyRangeArr = consumerIrManager.getCarrierFrequencies();
        } catch (Exception unused) {
            carrierFrequencyRangeArr = null;
        }
        if (carrierFrequencyRangeArr == null) {
            return i;
        }
        if (carrierFrequencyRangeArr.length != 0) {
            ConsumerIrManager.CarrierFrequencyRange carrierFrequencyRange2 = carrierFrequencyRangeArr[0];
            int i2 = 1;
            int length = carrierFrequencyRangeArr.length - 1;
            if (length != 0) {
                int minFrequency = carrierFrequencyRange2.getMinFrequency();
                if (i <= carrierFrequencyRange2.getMaxFrequency() && minFrequency <= i) {
                    min = 0;
                } else {
                    min = Math.min(Math.abs(i - carrierFrequencyRange2.getMinFrequency()), Math.abs(i - carrierFrequencyRange2.getMaxFrequency()));
                }
                if (1 <= length) {
                    while (true) {
                        ConsumerIrManager.CarrierFrequencyRange carrierFrequencyRange3 = carrierFrequencyRangeArr[i2];
                        int minFrequency2 = carrierFrequencyRange3.getMinFrequency();
                        if (i <= carrierFrequencyRange3.getMaxFrequency() && minFrequency2 <= i) {
                            min2 = 0;
                        } else {
                            min2 = Math.min(Math.abs(i - carrierFrequencyRange3.getMinFrequency()), Math.abs(i - carrierFrequencyRange3.getMaxFrequency()));
                        }
                        if (min > min2) {
                            carrierFrequencyRange2 = carrierFrequencyRange3;
                            min = min2;
                        }
                        if (i2 == length) {
                            break;
                        }
                        i2++;
                    }
                }
            }
            carrierFrequencyRange = carrierFrequencyRange2;
        }
        if (carrierFrequencyRange != null) {
            return MathKt.coerceIn(i, carrierFrequencyRange.getMinFrequency(), carrierFrequencyRange.getMaxFrequency());
        }
        return i;
    }
}
