package dev.tvremote.phone.ir;

import android.content.DialogInterface;
import android.view.View;
import dev.tvremote.core.Fleet;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.ui.Popup;
import java.util.ArrayList;
import java.util.List;
import kotlin.Pair;
import kotlin.collections.CollectionsKt__CollectionsKt;

/* loaded from: classes.dex */
public final /* synthetic */ class IrRemoteKt$$ExternalSyntheticLambda8 implements View.OnClickListener {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;
    public final /* synthetic */ Object f$1;
    public final /* synthetic */ int f$2;

    public /* synthetic */ IrRemoteKt$$ExternalSyntheticLambda8(Object obj, Object obj2, int i, int i2) {
        this.$r8$classId = i2;
        this.f$0 = obj;
        this.f$1 = obj2;
        this.f$2 = i;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        final int i = this.f$2;
        Object obj = this.f$1;
        Object obj2 = this.f$0;
        switch (this.$r8$classId) {
            case 0:
                final MainActivity mainActivity = (MainActivity) obj2;
                Popup.Builder builder = new Popup.Builder(mainActivity);
                builder.title = Fleet.T("ir.delete_ask", new Pair("name", (String) obj));
                builder.setPositiveButton(Fleet.T("setup.delete", new Pair[0]), new DialogInterface.OnClickListener() { // from class: dev.tvremote.phone.ir.IrRemoteKt$$ExternalSyntheticLambda18
                    @Override // android.content.DialogInterface.OnClickListener
                    public final void onClick(DialogInterface dialogInterface, int i2) {
                        MainActivity mainActivity2 = MainActivity.this;
                        List irSaved = IrRemoteKt.irSaved(mainActivity2);
                        ArrayList arrayList = new ArrayList();
                        int i3 = 0;
                        for (Object obj3 : irSaved) {
                            int i4 = i3 + 1;
                            if (i3 >= 0) {
                                if (i3 != i) {
                                    arrayList.add(obj3);
                                }
                                i3 = i4;
                            } else {
                                CollectionsKt__CollectionsKt.throwIndexOverflow();
                                throw null;
                            }
                        }
                        IrRemoteKt.irKeep(mainActivity2, arrayList);
                        IrRemoteKt.irList(mainActivity2);
                    }
                });
                builder.setNegativeButton(Fleet.T("common.cancel", new Pair[0]), null);
                builder.show();
                return;
            case 1:
                DialogInterface.OnClickListener onClickListener = (DialogInterface.OnClickListener) obj2;
                Popup popup = (Popup) obj;
                if (onClickListener != null) {
                    onClickListener.onClick(popup, i);
                }
                popup.dismiss();
                return;
            default:
                DialogInterface.OnClickListener onClickListener2 = (DialogInterface.OnClickListener) obj2;
                Popup popup2 = (Popup) obj;
                if (onClickListener2 != null) {
                    onClickListener2.onClick(popup2, i);
                }
                popup2.dismiss();
                return;
        }
    }
}
