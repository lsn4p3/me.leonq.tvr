package dev.tvremote.phone.ir;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import kotlin.collections.ArraysKt;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;

/* loaded from: classes.dex */
public abstract class IrEvents {
    public static final Regex ADD = new Regex("^add device \\d+: (/dev/input/\\S+)");
    public static final Regex NAME = new Regex("^\\s+name:\\s+\"(.*)\"");
    public static final Regex EVENT = new Regex("^(/dev/input/\\S+): (EV_KEY\\s+\\S+\\s+DOWN|EV_MSC\\s+MSC_SCAN\\s+\\S+)");
    public static final Regex SCAN = new Regex("MSC_SCAN\\s+([0-9a-fA-F]+)");

    /* loaded from: classes.dex */
    public final class Reader {
        public String adding;
        public boolean mapped;
        public final HashMap names = new HashMap();

        public final boolean key(String str) {
            MatcherMatchResult find = IrEvents.ADD.find(str, 0);
            if (find != null) {
                this.adding = (String) ((MatcherMatchResult$groupValues$1) find.getGroupValues()).get(1);
                return false;
            }
            MatcherMatchResult find2 = IrEvents.NAME.find(str, 0);
            HashMap hashMap = this.names;
            if (find2 != null) {
                String str2 = this.adding;
                if (str2 != null) {
                    hashMap.put(str2, ((MatcherMatchResult$groupValues$1) find2.getGroupValues()).get(1));
                }
                this.adding = null;
                return false;
            }
            MatcherMatchResult find3 = IrEvents.EVENT.find(str, 0);
            if (find3 == null) {
                return false;
            }
            this.mapped = StringsKt__StringsJVMKt.startsWith((String) ((MatcherMatchResult$groupValues$1) find3.getGroupValues()).get(2), false, "EV_KEY");
            String str3 = (String) hashMap.get(((MatcherMatchResult$groupValues$1) find3.getGroupValues()).get(1));
            if (str3 == null) {
                str3 = "";
            }
            return !StringsKt__StringsJVMKt.startsWith(str3, false, "virtual");
        }
    }

    public static HashSet scans(String code) {
        Long longOrNull;
        char c;
        Intrinsics.checkNotNullParameter(code, "code");
        List split = new Regex("\\s+").split(StringsKt.trim(code).toString(), 0);
        Long l = null;
        if (split.size() >= 3 && !Intrinsics.areEqual(split.get(0), "RAW") && (longOrNull = StringsKt__StringNumberConversionsKt.toLongOrNull((String) split.get(1), 16)) != null) {
            long longValue = longOrNull.longValue();
            Long longOrNull2 = StringsKt__StringNumberConversionsKt.toLongOrNull((String) split.get(2), 16);
            if (longOrNull2 != null) {
                long longValue2 = longOrNull2.longValue();
                Long[] lArr = {Long.valueOf((longValue << 8) | longValue2), Long.valueOf((longValue << 16) | longValue2)};
                HashSet hashSet = new HashSet(MapsKt__MapsKt.mapCapacity(2));
                ArraysKt.toCollection(lArr, hashSet);
                String str = (String) split.get(0);
                int hashCode = str.hashCode();
                if (hashCode != -1996073675) {
                    if (hashCode != -1083519047) {
                        if (hashCode != 77164 || !str.equals("NEC")) {
                            c = 16;
                        } else {
                            c = 16;
                            l = Long.valueOf((((~longValue) & 255) << 8) | (longValue & 255) | ((longValue2 & 255) << 16) | (((~longValue2) & 255) << 24));
                        }
                    } else {
                        c = 16;
                        if (str.equals("Samsung32")) {
                            long j = longValue & 255;
                            l = Long.valueOf(j | (j << 8) | ((longValue2 & 255) << 16) | (((~longValue2) & 255) << 24));
                        }
                    }
                } else {
                    c = 16;
                    if (str.equals("NECext")) {
                        l = Long.valueOf((longValue & 65535) | ((longValue2 & 65535) << 16));
                    }
                }
                if (l != null) {
                    long longValue3 = l.longValue() & 4294967295L;
                    hashSet.add(Long.valueOf(longValue3));
                    hashSet.add(Long.valueOf(Long.reverseBytes(longValue3) >>> 32));
                    hashSet.add(Long.valueOf(((longValue & 255) << 24) | (((~longValue) & 255) << c) | ((longValue2 & 255) << 8) | ((~longValue2) & 255)));
                    if (Intrinsics.areEqual(split.get(0), "NECext")) {
                        hashSet.add(Long.valueOf(((longValue & 65535) << c) | (longValue2 & 65535)));
                    }
                }
                return hashSet;
            }
        }
        return null;
    }
}
