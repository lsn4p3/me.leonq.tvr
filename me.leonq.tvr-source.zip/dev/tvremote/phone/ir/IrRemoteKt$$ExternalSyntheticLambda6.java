package dev.tvremote.phone.ir;

import android.view.View;
import dev.tvremote.phone.MainActivity;

/* loaded from: classes.dex */
public final /* synthetic */ class IrRemoteKt$$ExternalSyntheticLambda6 implements View.OnClickListener {
    public final /* synthetic */ int $r8$classId = 0;
    public final /* synthetic */ int f$0;
    public final /* synthetic */ MainActivity f$1;

    public /* synthetic */ IrRemoteKt$$ExternalSyntheticLambda6(int i, MainActivity mainActivity) {
        this.f$0 = i;
        this.f$1 = mainActivity;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        switch (this.$r8$classId) {
            case 0:
                IrState.slot = this.f$0;
                IrRemoteKt.irRemote(this.f$1);
                return;
            default:
                IrRemoteKt.irRename(this.f$0, this.f$1);
                return;
        }
    }

    public /* synthetic */ IrRemoteKt$$ExternalSyntheticLambda6(MainActivity mainActivity, int i) {
        this.f$1 = mainActivity;
        this.f$0 = i;
    }
}
