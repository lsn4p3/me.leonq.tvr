package dev.tvremote.phone.ir;

import android.widget.Toast;
import dev.tvremote.core.Fleet;
import dev.tvremote.phone.MainActivity;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;

/* loaded from: classes.dex */
public final /* synthetic */ class IrRemoteKt$$ExternalSyntheticLambda25 implements Function0 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ IrProfile f$1;

    public /* synthetic */ IrRemoteKt$$ExternalSyntheticLambda25(MainActivity mainActivity, IrProfile irProfile, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
        this.f$1 = irProfile;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        MainActivity mainActivity = this.f$0;
        IrProfile irProfile = this.f$1;
        switch (this.$r8$classId) {
            case 0:
                IrRemoteKt.irSave(mainActivity, irProfile);
                IrRemoteKt.irRemote(mainActivity);
                return Unit.INSTANCE;
            default:
                Toast.makeText(mainActivity, Fleet.T("ir.found", new Pair("name", IrRemoteKt.getTitle(irProfile))), 1).show();
                IrRemoteKt.irRemote(mainActivity);
                return Unit.INSTANCE;
        }
    }
}
