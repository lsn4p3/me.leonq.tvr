package dev.tvremote.phone.ir;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;

/* loaded from: classes.dex */
public final class IrProfile {
    public final String brand;
    public final String id;
    public final Set ids;
    public final LinkedHashMap keys;
    public final int kind;
    public final List models;
    public final String name;

    public IrProfile(String id, String brand, String name, LinkedHashMap linkedHashMap, int i, List list, Set set) {
        Intrinsics.checkNotNullParameter(id, "id");
        Intrinsics.checkNotNullParameter(brand, "brand");
        Intrinsics.checkNotNullParameter(name, "name");
        this.id = id;
        this.brand = brand;
        this.name = name;
        this.keys = linkedHashMap;
        this.kind = i;
        this.models = list;
        this.ids = set;
    }

    public /* synthetic */ IrProfile(String str, String str2, String str3, LinkedHashMap linkedHashMap) {
        this(str, str2, str3, linkedHashMap, 0, MathKt.listOf(str3), MathKt.setOf(str));
    }
}
