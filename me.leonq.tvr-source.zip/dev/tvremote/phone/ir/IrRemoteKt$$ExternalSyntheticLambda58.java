package dev.tvremote.phone.ir;

import dev.tvremote.phone.MainActivity;
import kotlin.jvm.functions.Function0;

/* loaded from: classes.dex */
public final /* synthetic */ class IrRemoteKt$$ExternalSyntheticLambda58 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ Function0 f$1;

    public /* synthetic */ IrRemoteKt$$ExternalSyntheticLambda58(MainActivity mainActivity, Function0 function0) {
        this.$r8$classId = 2;
        this.f$1 = function0;
        this.f$0 = mainActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.$r8$classId) {
            case 0:
                MainActivity mainActivity = this.f$0;
                if (!mainActivity.isFinishing() && IrState.page.equals("auto") && mainActivity.getIrHost$android_release().getVisibility() == 0) {
                    this.f$1.invoke();
                    return;
                }
                return;
            case 1:
                MainActivity mainActivity2 = this.f$0;
                if (!mainActivity2.isFinishing() && IrState.page.equals("auto") && mainActivity2.getIrHost$android_release().getVisibility() == 0) {
                    this.f$1.invoke();
                    return;
                }
                return;
            default:
                Function0 function0 = this.f$1;
                MainActivity mainActivity3 = this.f$0;
                try {
                    function0.invoke();
                } catch (Exception unused) {
                } catch (Throwable th) {
                    mainActivity3.tvBusy.set(false);
                    throw th;
                }
                mainActivity3.tvBusy.set(false);
                return;
        }
    }

    public /* synthetic */ IrRemoteKt$$ExternalSyntheticLambda58(MainActivity mainActivity, Function0 function0, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
        this.f$1 = function0;
    }
}
