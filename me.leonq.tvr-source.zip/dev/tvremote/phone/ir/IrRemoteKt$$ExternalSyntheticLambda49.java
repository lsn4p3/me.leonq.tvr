package dev.tvremote.phone.ir;

import dev.tvremote.core.Fleet;
import dev.tvremote.phone.MainActivity;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$ObjectRef;

/* loaded from: classes.dex */
public final /* synthetic */ class IrRemoteKt$$ExternalSyntheticLambda49 implements Function1 {
    public final /* synthetic */ int $r8$classId = 1;
    public final /* synthetic */ Ref$ObjectRef f$0;
    public final /* synthetic */ MainActivity f$1;

    public /* synthetic */ IrRemoteKt$$ExternalSyntheticLambda49(MainActivity mainActivity, Ref$ObjectRef ref$ObjectRef) {
        this.f$1 = mainActivity;
        this.f$0 = ref$ObjectRef;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        String it = (String) obj;
        switch (this.$r8$classId) {
            case 0:
                Intrinsics.checkNotNullParameter(it, "it");
                this.f$0.element = it;
                IrRemoteKt.irSend(this.f$1, it, false);
                return Unit.INSTANCE;
            default:
                Intrinsics.checkNotNullParameter(it, "it");
                Fleet.setTalkMode(this.f$1, it);
                Object obj2 = this.f$0.element;
                if (obj2 != null) {
                    ((Function0) obj2).invoke();
                    return Unit.INSTANCE;
                }
                Intrinsics.throwUninitializedPropertyAccessException("talkChips");
                throw null;
        }
    }

    public /* synthetic */ IrRemoteKt$$ExternalSyntheticLambda49(Ref$ObjectRef ref$ObjectRef, MainActivity mainActivity) {
        this.f$0 = ref$ObjectRef;
        this.f$1 = mainActivity;
    }
}
