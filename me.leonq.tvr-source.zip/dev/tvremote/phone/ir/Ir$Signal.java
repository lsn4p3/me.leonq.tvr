package dev.tvremote.phone.ir;

import dev.tvremote.core.ontv.Video;
import java.nio.ByteBuffer;

/* loaded from: classes.dex */
public final class Ir$Signal {
    public int hz;
    public final Object pattern;

    public /* synthetic */ Ir$Signal(int i, Object obj) {
        this.hz = i;
        this.pattern = obj;
    }

    public long getMicros() {
        long j = 0;
        for (int i = 0; i < ((int[]) this.pattern).length; i++) {
            j += r0[i];
        }
        return j;
    }

    public int se() {
        int ue = ue();
        if ((ue & 1) == 1) {
            return (ue + 1) / 2;
        }
        return -(ue / 2);
    }

    public int u(int i) {
        int i2 = 0;
        for (int i3 = 0; i3 < i; i3++) {
            int i4 = this.hz;
            i2 = (i2 << 1) | ((((byte[]) this.pattern)[i4 >> 3] >> (7 - (i4 & 7))) & 1);
            this.hz = i4 + 1;
        }
        return i2;
    }

    public int ue() {
        int i = 0;
        int i2 = 0;
        while (u(1) == 0) {
            i2++;
            if (i2 >= 32) {
                throw new IllegalArgumentException("Failed requirement.");
            }
        }
        int i3 = (1 << i2) - 1;
        if (i2 > 0) {
            i = u(i2);
        }
        return i3 + i;
    }

    public Ir$Signal(byte[] bArr) {
        this.pattern = bArr;
    }

    public Ir$Signal(Video.Way way) {
        ByteBuffer slice = way.getContents().slice();
        this.pattern = slice;
        slice.order(way.getContents().order());
        this.hz = slice.remaining() / 4;
    }
}
