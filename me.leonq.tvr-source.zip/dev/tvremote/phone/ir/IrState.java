package dev.tvremote.phone.ir;

import dev.tvremote.core.Diagnose$$ExternalSyntheticLambda1;
import dev.tvremote.core.adb.AdbLink;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* loaded from: classes.dex */
public abstract class IrState {
    public static String auto = "";
    public static Object catalog = null;
    public static Object custom = null;
    public static volatile boolean finish = false;
    public static final ExecutorService io = Executors.newSingleThreadExecutor(new Diagnose$$ExternalSyntheticLambda1(8));
    public static volatile AdbLink link = null;
    public static boolean onFind = false;
    public static String page = "";
    public static volatile boolean skip = false;
    public static int slot = -1;
    public static volatile boolean stop;
    public static boolean toggle;
}
