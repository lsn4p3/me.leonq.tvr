package dev.tvremote.phone.ir;

import android.view.View;
import dev.tvremote.core.remote.Lg$$ExternalSyntheticLambda14;
import dev.tvremote.phone.picture.Air;
import dev.tvremote.phone.remote.Gp;

/* loaded from: classes.dex */
public final /* synthetic */ class IrRemoteKt$$ExternalSyntheticLambda60 implements View.OnClickListener {
    public final /* synthetic */ int $r8$classId;

    public /* synthetic */ IrRemoteKt$$ExternalSyntheticLambda60(int i) {
        this.$r8$classId = i;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        switch (this.$r8$classId) {
            case 0:
                Object obj = IrState.catalog;
                IrState.skip = true;
                return;
            case 1:
                Object obj2 = IrState.catalog;
                IrState.finish = true;
                return;
            case 2:
                Air.airPick.invoke("mouse");
                return;
            default:
                new Thread(new Lg$$ExternalSyntheticLambda14(Gp.ws, 2)).start();
                return;
        }
    }
}
