package dev.tvremote.phone.ir;

import android.graphics.Typeface;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.remote.Ssdp;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda30;
import dev.tvremote.phone.picture.DrawingKt$$ExternalSyntheticLambda0;
import dev.tvremote.phone.ui.UiKt;
import java.util.Iterator;
import java.util.List;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final /* synthetic */ class IrRemoteKt$$ExternalSyntheticLambda2 implements Function1 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ List f$0;
    public final /* synthetic */ MainActivity f$1;

    public /* synthetic */ IrRemoteKt$$ExternalSyntheticLambda2(int i, MainActivity mainActivity, List list) {
        this.$r8$classId = i;
        this.f$0 = list;
        this.f$1 = mainActivity;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        float f;
        Object obj2;
        int i;
        boolean add;
        switch (this.$r8$classId) {
            case 0:
                LinearLayout irPage = (LinearLayout) obj;
                Intrinsics.checkNotNullParameter(irPage, "$this$irPage");
                List list = this.f$0;
                boolean isEmpty = list.isEmpty();
                MainActivity mainActivity = this.f$1;
                int i2 = 14;
                if (isEmpty) {
                    irPage.addView(UiKt.note(mainActivity, Fleet.T("ir.saved_none", new Pair[0])), UiKt.gap(mainActivity, 14));
                }
                int i3 = 0;
                for (Object obj3 : list) {
                    int i4 = i3 + 1;
                    if (i3 >= 0) {
                        Pair pair = (Pair) obj3;
                        String str = (String) pair.first;
                        String str2 = (String) pair.second;
                        Iterator it = IrRemoteKt.irCatalog(mainActivity).iterator();
                        while (true) {
                            if (it.hasNext()) {
                                Object next = it.next();
                                if (((IrProfile) next).ids.contains(str2)) {
                                    obj2 = next;
                                }
                            } else {
                                obj2 = null;
                            }
                        }
                        IrProfile irProfile = (IrProfile) obj2;
                        LinearLayout linearLayout = new LinearLayout(mainActivity);
                        linearLayout.setGravity(16);
                        linearLayout.setBackground(UiKt.box(mainActivity, UiKt.CARD, i2));
                        float f2 = 10;
                        linearLayout.setPadding(UiKt.dp(mainActivity, i2), UiKt.dp(mainActivity, f2), UiKt.dp(mainActivity, 6), UiKt.dp(mainActivity, f2));
                        linearLayout.setClickable(true);
                        linearLayout.setOnClickListener(new IrRemoteKt$$ExternalSyntheticLambda6(i3, mainActivity));
                        LinearLayout col = UiKt.col(mainActivity);
                        TextView label = UiKt.label(mainActivity, str, 16, UiKt.TEXT);
                        label.setTypeface(Typeface.DEFAULT_BOLD);
                        label.setMaxLines(1);
                        TextUtils.TruncateAt truncateAt = TextUtils.TruncateAt.END;
                        label.setEllipsize(truncateAt);
                        col.addView(label);
                        if (irProfile != null && !Intrinsics.areEqual(IrRemoteKt.getTitle(irProfile), str)) {
                            TextView label2 = UiKt.label(mainActivity, IrRemoteKt.getTitle(irProfile), 13, UiKt.MUTED);
                            label2.setMaxLines(1);
                            label2.setEllipsize(truncateAt);
                            col.addView(label2);
                        }
                        linearLayout.addView(col, new LinearLayout.LayoutParams(0, -2, 1.0f));
                        View icon = UiKt.icon(mainActivity, "@pen", Fleet.T("ir.rename", new Pair[0]), UiKt.CARD);
                        icon.setOnClickListener(new IrRemoteKt$$ExternalSyntheticLambda6(mainActivity, i3));
                        float f3 = 44;
                        linearLayout.addView(icon, new LinearLayout.LayoutParams(UiKt.dp(mainActivity, f3), UiKt.dp(mainActivity, f3)));
                        View icon2 = UiKt.icon(mainActivity, "@trash", Fleet.T("setup.delete", new Pair[0]), UiKt.CARD);
                        icon2.setOnClickListener(new IrRemoteKt$$ExternalSyntheticLambda8(mainActivity, str, i3, 0));
                        linearLayout.addView(icon2, new LinearLayout.LayoutParams(UiKt.dp(mainActivity, f3), UiKt.dp(mainActivity, f3)));
                        if (i3 == 0) {
                            i = 14;
                        } else {
                            i = 8;
                        }
                        irPage.addView(linearLayout, UiKt.gap(mainActivity, i));
                        i3 = i4;
                        i2 = 14;
                    } else {
                        CollectionsKt__CollectionsKt.throwIndexOverflow();
                        throw null;
                    }
                }
                View button = UiKt.button(mainActivity, ApkSigner$$ExternalSyntheticOutline0.m("@plus|", Fleet.T("ir.add", new Pair[0])), UiKt.ACCENT);
                button.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(mainActivity, 10));
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, UiKt.dp(mainActivity, 52));
                layoutParams.topMargin = UiKt.dp(mainActivity, 14);
                irPage.addView(button, layoutParams);
                LinearLayout linearLayout2 = new LinearLayout(mainActivity);
                Button button2 = UiKt.button(mainActivity, ApkSigner$$ExternalSyntheticOutline0.m("@download|", Fleet.T("ir.export", new Pair[0])), UiKt.SOFT);
                button2.setEnabled(!list.isEmpty());
                if (list.isEmpty()) {
                    f = 0.4f;
                } else {
                    f = 1.0f;
                }
                button2.setAlpha(f);
                button2.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(mainActivity, 1));
                float f4 = 48;
                linearLayout2.addView(button2, new LinearLayout.LayoutParams(0, UiKt.dp(mainActivity, f4), 1.0f));
                Button button3 = UiKt.button(mainActivity, ApkSigner$$ExternalSyntheticOutline0.m("@upload|", Fleet.T("ir.import", new Pair[0])), UiKt.SOFT);
                button3.setOnClickListener(new MainActivity$$ExternalSyntheticLambda30(mainActivity, 2));
                LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(0, UiKt.dp(mainActivity, f4), 1.0f);
                layoutParams2.leftMargin = UiKt.dp(mainActivity, 10);
                linearLayout2.addView(button3, layoutParams2);
                irPage.addView(linearLayout2, UiKt.gap(mainActivity, 10));
                return Unit.INSTANCE;
            default:
                List list2 = this.f$0;
                MainActivity mainActivity2 = this.f$1;
                Ssdp.Found f5 = (Ssdp.Found) obj;
                Intrinsics.checkNotNullParameter(f5, "f");
                Intrinsics.checkNotNull(list2);
                synchronized (list2) {
                    if (list2.contains(f5.ip)) {
                        add = false;
                    } else {
                        add = list2.add(f5.ip);
                    }
                }
                if (add) {
                    mainActivity2.ui.post(new DrawingKt$$ExternalSyntheticLambda0(2, mainActivity2, f5));
                }
                return Unit.INSTANCE;
        }
    }
}
