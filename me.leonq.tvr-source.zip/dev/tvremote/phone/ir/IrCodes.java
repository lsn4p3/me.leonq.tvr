package dev.tvremote.phone.ir;

import dev.tvremote.core.scenes.Phrases$alt$$inlined$sortedByDescending$1;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.CollectionsKt__MutableCollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$IntRef;
import kotlin.jvm.internal.TypeIntrinsics;
import kotlin.jvm.internal.markers.KMappedMarker;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgression;
import kotlin.ranges.IntProgressionIterator;
import kotlin.ranges.IntRange;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public abstract class IrCodes {
    public static final ArrayList KEYS;

    static {
        List asList = ArraysKt.asList(new String[]{"POWER", "HOME", "BACK", "UP", "DOWN", "LEFT", "RIGHT", "OK", "MENU", "SETTINGS", "VOL_UP", "VOL_DOWN", "MUTE", "CH_UP", "CH_DOWN", "INPUT", "PLAY_PAUSE", "STOP", "REWIND", "FFWD", "NEXT", "PREV", "INFO", "GUIDE", "SUBTITLE", "RED", "GREEN", "YELLOW", "BLUE", "NETFLIX", "YOUTUBE", "PRIME"});
        IntProgression intProgression = new IntProgression(0, 9, 1);
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(intProgression));
        Iterator it = intProgression.iterator();
        while (((IntProgressionIterator) it).hasNext) {
            arrayList.add(String.valueOf(((IntProgressionIterator) it).nextInt()));
        }
        KEYS = CollectionsKt.plus(asList, (Iterable) arrayList);
        CollectionsKt__CollectionsKt.listOf((Object[]) new String[]{"POWER", "HOME", "VOL_UP", "MUTE"});
    }

    public static ArrayList distinct(String key, ArrayList arrayList) {
        Intrinsics.checkNotNullParameter(key, "key");
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            IrProfile irProfile = (IrProfile) it.next();
            String str = (String) irProfile.keys.get(key);
            if (str != null) {
                Object obj = linkedHashMap.get(str);
                if (obj == null) {
                    obj = new ArrayList();
                    linkedHashMap.put(str, obj);
                }
                ((List) obj).add(irProfile);
            }
        }
        Collection<List> values = linkedHashMap.values();
        Intrinsics.checkNotNullExpressionValue(values, "<get-values>(...)");
        ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(values));
        for (List list : values) {
            Intrinsics.checkNotNull(list);
            arrayList2.add(new Pair(CollectionsKt.first(list), Integer.valueOf(list.size())));
        }
        return arrayList2;
    }

    /* JADX WARN: Type inference failed for: r0v0 */
    /* JADX WARN: Type inference failed for: r0v1, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v17 */
    public static ArrayList merge(ArrayList arrayList) {
        int i;
        Object next;
        ?? r0 = 0;
        int i2 = 1;
        ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList));
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            arrayList2.add(((IrProfile) it.next()).brand);
        }
        List<String> distinct = CollectionsKt.distinct(arrayList2);
        ArrayList arrayList3 = new ArrayList();
        for (String str : distinct) {
            ArrayList arrayList4 = new ArrayList();
            Iterator it2 = arrayList.iterator();
            while (it2.hasNext()) {
                Object next2 = it2.next();
                if (Intrinsics.areEqual(((IrProfile) next2).brand, str)) {
                    arrayList4.add(next2);
                }
            }
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            Iterator it3 = arrayList4.iterator();
            while (it3.hasNext()) {
                Object next3 = it3.next();
                String str2 = (String) ((IrProfile) next3).keys.get("POWER");
                if (str2 == null) {
                    str2 = "";
                }
                if (!StringsKt__StringsJVMKt.startsWith(str2, r0, "RAW")) {
                    char[] cArr = new char[i2];
                    cArr[r0] = ' ';
                    str2 = CollectionsKt.joinToString$default(CollectionsKt.take(StringsKt.split$default(str2, cArr), 2), " ", null, null, null, 62);
                }
                Object obj = linkedHashMap.get(str2);
                if (obj == null) {
                    obj = new ArrayList();
                    linkedHashMap.put(str2, obj);
                }
                ((List) obj).add(next3);
            }
            List sortedWith = CollectionsKt.sortedWith(linkedHashMap.values(), new Phrases$alt$$inlined$sortedByDescending$1(7));
            ArrayList arrayList5 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(sortedWith));
            int i3 = 0;
            boolean z = r0;
            for (Object obj2 : sortedWith) {
                int i4 = i3 + 1;
                if (i3 >= 0) {
                    List list = (List) obj2;
                    LinkedHashMap linkedHashMap2 = new LinkedHashMap();
                    Iterator it4 = KEYS.iterator();
                    boolean z2 = z;
                    while (it4.hasNext()) {
                        String str3 = (String) it4.next();
                        ArrayList arrayList6 = new ArrayList();
                        Iterator it5 = list.iterator();
                        while (it5.hasNext()) {
                            String str4 = (String) ((IrProfile) it5.next()).keys.get(str3);
                            if (str4 != null) {
                                arrayList6.add(str4);
                            }
                        }
                        LinkedHashMap linkedHashMap3 = new LinkedHashMap();
                        Iterator it6 = arrayList6.iterator();
                        while (it6.hasNext()) {
                            String str5 = (String) it6.next();
                            Object obj3 = linkedHashMap3.get(str5);
                            if (obj3 == null && !linkedHashMap3.containsKey(str5)) {
                                obj3 = new Object();
                            }
                            Ref$IntRef ref$IntRef = (Ref$IntRef) obj3;
                            ref$IntRef.element++;
                            linkedHashMap3.put(str5, ref$IntRef);
                        }
                        for (Map.Entry entry : linkedHashMap3.entrySet()) {
                            Intrinsics.checkNotNull(entry, "null cannot be cast to non-null type kotlin.collections.MutableMap.MutableEntry<K of kotlin.collections.GroupingKt__GroupingJVMKt.mapValuesInPlace, R of kotlin.collections.GroupingKt__GroupingJVMKt.mapValuesInPlace>");
                            if (!(entry instanceof KMappedMarker)) {
                                entry.setValue(Integer.valueOf(((Ref$IntRef) entry.getValue()).element));
                            } else {
                                TypeIntrinsics.throwCce(entry, "kotlin.collections.MutableMap.MutableEntry");
                                throw null;
                            }
                        }
                        if (!(linkedHashMap3 instanceof KMappedMarker)) {
                            Iterator it7 = linkedHashMap3.entrySet().iterator();
                            if (!it7.hasNext()) {
                                next = null;
                            } else {
                                next = it7.next();
                                if (it7.hasNext()) {
                                    int intValue = ((Number) ((Map.Entry) next).getValue()).intValue();
                                    do {
                                        Object next4 = it7.next();
                                        int intValue2 = ((Number) ((Map.Entry) next4).getValue()).intValue();
                                        if (intValue < intValue2) {
                                            next = next4;
                                            intValue = intValue2;
                                        }
                                    } while (it7.hasNext());
                                }
                            }
                            Map.Entry entry2 = (Map.Entry) next;
                            if (entry2 != null) {
                                linkedHashMap2.put(str3, entry2.getKey());
                            }
                            z2 = false;
                        } else {
                            TypeIntrinsics.throwCce(linkedHashMap3, "kotlin.collections.MutableMap");
                            throw null;
                        }
                    }
                    String str6 = ((IrProfile) list.get(z2 ? 1 : 0)).id;
                    String str7 = ((IrProfile) list.get(z2 ? 1 : 0)).name;
                    if (sortedWith.size() > 1) {
                        i = i4;
                    } else {
                        i = 0;
                    }
                    ArrayList arrayList7 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(list));
                    Iterator it8 = list.iterator();
                    while (it8.hasNext()) {
                        arrayList7.add(((IrProfile) it8.next()).name);
                    }
                    ArrayList arrayList8 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(list));
                    Iterator it9 = list.iterator();
                    while (it9.hasNext()) {
                        arrayList8.add(((IrProfile) it9.next()).id);
                    }
                    arrayList5.add(new IrProfile(str6, str, str7, linkedHashMap2, i, arrayList7, CollectionsKt.toSet(arrayList8)));
                    i3 = i4;
                    z = z2;
                } else {
                    CollectionsKt__CollectionsKt.throwIndexOverflow();
                    throw null;
                }
            }
            CollectionsKt__MutableCollectionsKt.addAll(arrayList5, arrayList3);
            i2 = 1;
            r0 = z;
        }
        return arrayList3;
    }

    public static ArrayList parse(String str) {
        JSONArray jSONArray = new JSONObject(str).getJSONArray("profiles");
        IntRange until = MathKt.until(0, jSONArray.length());
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until));
        Iterator it = until.iterator();
        while (((IntProgressionIterator) it).hasNext) {
            JSONObject jSONObject = jSONArray.getJSONObject(((IntProgressionIterator) it).nextInt());
            JSONObject jSONObject2 = jSONObject.getJSONObject("keys");
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            Iterator<String> keys = jSONObject2.keys();
            Intrinsics.checkNotNullExpressionValue(keys, "keys(...)");
            while (keys.hasNext()) {
                String next = keys.next();
                linkedHashMap.put(next, jSONObject2.getString(next));
            }
            String string = jSONObject.getString("id");
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            String string2 = jSONObject.getString("brand");
            Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
            String string3 = jSONObject.getString("name");
            Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
            arrayList.add(new IrProfile(string, string2, string3, linkedHashMap));
        }
        return arrayList;
    }
}
