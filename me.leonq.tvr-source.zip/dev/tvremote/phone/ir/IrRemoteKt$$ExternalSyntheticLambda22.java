package dev.tvremote.phone.ir;

import android.graphics.Typeface;
import android.net.Network;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.remote.Ssdp;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda7;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.manage.UpdaterKt$$ExternalSyntheticLambda10;
import dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda63;
import dev.tvremote.phone.picker.PickerScreenKt;
import dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda9;
import dev.tvremote.phone.remote.TypingKt;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.phone.ui.UiKt;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$IntRef;
import kotlin.jvm.internal.Ref$ObjectRef;
import kotlin.math.MathKt;

/* loaded from: classes.dex */
public final /* synthetic */ class IrRemoteKt$$ExternalSyntheticLambda22 implements Function1 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ Object f$1;
    public final /* synthetic */ Object f$2;
    public final /* synthetic */ Object f$3;

    public /* synthetic */ IrRemoteKt$$ExternalSyntheticLambda22(MainActivity mainActivity, Ref$IntRef ref$IntRef, ArrayList arrayList, Ref$ObjectRef ref$ObjectRef) {
        this.$r8$classId = 0;
        this.f$0 = mainActivity;
        this.f$1 = ref$IntRef;
        this.f$2 = arrayList;
        this.f$3 = ref$ObjectRef;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        String T;
        String T2;
        boolean z;
        float f;
        String str;
        boolean z2;
        int i = 4;
        int i2 = 2;
        boolean z3 = true;
        char c = 1;
        boolean z4 = false;
        switch (this.$r8$classId) {
            case 0:
                LinearLayout irPage = (LinearLayout) obj;
                Intrinsics.checkNotNullParameter(irPage, "$this$irPage");
                MainActivity mainActivity = this.f$0;
                LinearLayout linearLayout = new LinearLayout(mainActivity);
                linearLayout.setBaselineAligned(false);
                Iterator it = ArraysKt.asList(new Pair[]{new Pair("POWER", Fleet.T("remote.power", new Pair[0])), new Pair("HOME", Fleet.T("rkey.home", new Pair[0])), new Pair("VOL_UP", Fleet.T("ir.vol", new Pair[0])), new Pair("MUTE", Fleet.T("rkey.mute", new Pair[0]))}).iterator();
                int i3 = 0;
                while (true) {
                    boolean hasNext = it.hasNext();
                    Ref$ObjectRef ref$ObjectRef = (Ref$ObjectRef) this.f$3;
                    if (hasNext) {
                        Object next = it.next();
                        int i4 = i3 + 1;
                        if (i3 >= 0) {
                            Pair pair = (Pair) next;
                            String str2 = (String) pair.first;
                            Button button = UiKt.button(mainActivity, (String) pair.second, UiKt.BTN);
                            button.setTextSize(13.0f);
                            button.setMaxLines(1);
                            button.setEllipsize(TextUtils.TruncateAt.END);
                            float f2 = i;
                            button.setPadding(UiKt.dp(mainActivity, f2), 0, UiKt.dp(mainActivity, f2), 0);
                            UiKt.setOn$default(button, Intrinsics.areEqual(str2, ref$ObjectRef.element), 0, 6);
                            button.setOnClickListener(new Guard$$ExternalSyntheticLambda7(str2, ref$ObjectRef, mainActivity));
                            if (i3 > 0) {
                                z2 = true;
                            } else {
                                z2 = false;
                            }
                            linearLayout.addView(button, UiKt.cell(40, mainActivity, z2));
                            i3 = i4;
                            i = 4;
                        } else {
                            CollectionsKt__CollectionsKt.throwIndexOverflow();
                            throw null;
                        }
                    } else {
                        irPage.addView(UiKt.note(mainActivity, Fleet.T("ir.find_key", new Pair[0])), UiKt.gap(mainActivity, 10));
                        irPage.addView(linearLayout, UiKt.gap(mainActivity, 6));
                        irPage.addView(UiKt.note(mainActivity, Fleet.T("ir.find_hint", new Pair[0])), UiKt.gap(mainActivity, 8));
                        LinearLayout col = UiKt.col(mainActivity);
                        col.setBackground(UiKt.box(mainActivity, UiKt.CARD, 14));
                        float f3 = 16;
                        float f4 = 14;
                        col.setPadding(UiKt.dp(mainActivity, f3), UiKt.dp(mainActivity, f4), UiKt.dp(mainActivity, f3), UiKt.dp(mainActivity, f4));
                        Ref$IntRef ref$IntRef = (Ref$IntRef) this.f$1;
                        int i5 = ref$IntRef.element;
                        ArrayList arrayList = (ArrayList) this.f$2;
                        if (i5 < 0) {
                            T = Fleet.T("ir.ready", new Pair[0]);
                        } else {
                            T = Fleet.T("ir.step", new Pair("n", Integer.valueOf(i5 + 1)), new Pair("total", Integer.valueOf(arrayList.size())));
                        }
                        TextView label = UiKt.label(mainActivity, T, 20, UiKt.TEXT);
                        label.setTypeface(Typeface.DEFAULT_BOLD);
                        col.addView(label);
                        int i6 = ref$IntRef.element;
                        if (i6 >= 0 && i6 < arrayList.size()) {
                            Pair pair2 = (Pair) arrayList.get(ref$IntRef.element);
                            IrProfile irProfile = (IrProfile) pair2.first;
                            int intValue = ((Number) pair2.second).intValue();
                            String title = IrRemoteKt.getTitle(irProfile);
                            if (intValue > 1) {
                                str = ApkSigner$$ExternalSyntheticOutline0.m("  ", Fleet.T("ir.same", new Pair("n", Integer.valueOf(intValue - 1))));
                            } else {
                                str = "";
                            }
                            col.addView(UiKt.label(mainActivity, Census$$ExternalSyntheticOutline0.m(title, str), 14, UiKt.MUTED), UiKt.gap(mainActivity, 4));
                        }
                        irPage.addView(col, UiKt.gap(mainActivity, 14));
                        LinearLayout linearLayout2 = new LinearLayout(mainActivity);
                        Button button2 = UiKt.button(mainActivity, Fleet.T("ir.again", new Pair[0]), UiKt.BTN);
                        if (ref$IntRef.element < 0) {
                            T2 = Fleet.T("ir.send", new Pair[0]);
                        } else {
                            T2 = Fleet.T("ir.next", new Pair[0]);
                        }
                        Button button3 = UiKt.button(mainActivity, T2, UiKt.BTN);
                        int i7 = ref$IntRef.element;
                        if (i7 >= 0 && i7 < arrayList.size()) {
                            z = true;
                        } else {
                            z = false;
                        }
                        button2.setEnabled(z);
                        float f5 = 0.4f;
                        if (button2.isEnabled()) {
                            f = 1.0f;
                        } else {
                            f = 0.4f;
                        }
                        button2.setAlpha(f);
                        button2.setOnClickListener(new IrRemoteKt$$ExternalSyntheticLambda33(arrayList, ref$IntRef, mainActivity, ref$ObjectRef));
                        button3.setOnClickListener(new IrRemoteKt$$ExternalSyntheticLambda33(mainActivity, ref$IntRef, arrayList, ref$ObjectRef));
                        linearLayout2.addView(button2, UiKt.cell(52, mainActivity, false));
                        linearLayout2.addView(button3, UiKt.cell(52, mainActivity, true));
                        irPage.addView(linearLayout2, UiKt.gap(mainActivity, 14));
                        View button4 = UiKt.button(mainActivity, Fleet.T("ir.reacted", new Pair[0]), UiKt.ACCENT);
                        int i8 = ref$IntRef.element;
                        if (i8 < 0 || i8 >= arrayList.size()) {
                            z3 = false;
                        }
                        button4.setEnabled(z3);
                        if (button4.isEnabled()) {
                            f5 = 1.0f;
                        }
                        button4.setAlpha(f5);
                        button4.setOnClickListener(new Guard$$ExternalSyntheticLambda7(arrayList, ref$IntRef, mainActivity, i2));
                        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, UiKt.dp(mainActivity, 56));
                        layoutParams.topMargin = UiKt.dp(mainActivity, 10);
                        irPage.addView(button4, layoutParams);
                        return Unit.INSTANCE;
                    }
                }
                break;
            case 1:
                boolean booleanValue = ((Boolean) obj).booleanValue();
                String obj2 = ((EditText) this.f$1).getText().toString();
                int length = obj2.length();
                MainActivity mainActivity2 = this.f$0;
                if (length == 0) {
                    Fleet.say(mainActivity2, Fleet.T("playing.no_text", new Pair[0]), false);
                } else {
                    ((Popup) this.f$2).dismiss();
                    new Thread(new UpdaterKt$$ExternalSyntheticLambda10((Tv) this.f$3, obj2, booleanValue, mainActivity2)).start();
                }
                return Unit.INSTANCE;
            case 2:
                List list = (List) this.f$1;
                Network network = (Network) this.f$2;
                Set set = (Set) this.f$3;
                MainActivity mainActivity3 = this.f$0;
                String ip = (String) obj;
                Intrinsics.checkNotNullParameter(ip, "ip");
                Intrinsics.checkNotNull(list);
                synchronized (list) {
                    if (!list.contains(ip)) {
                        z4 = list.add(ip);
                    }
                }
                if (z4) {
                    boolean open = MathKt.open(ip, 5555, 900, network);
                    if (set.contains(ip) && open && mainActivity3.host == null) {
                        mainActivity3.ui.post(new AdbHelpKt$$ExternalSyntheticLambda63(mainActivity3, ip, c == true ? 1 : 0));
                    }
                    String name = PickerScreenKt.name(mainActivity3, ip);
                    if (name.length() == 0) {
                        name = Ssdp.castName$default(ip);
                    }
                    mainActivity3.ui.post(new UpdaterKt$$ExternalSyntheticLambda10(mainActivity3, ip, name, open, 4));
                }
                return Unit.INSTANCE;
            case 3:
                EditText at = (EditText) obj;
                Intrinsics.checkNotNullParameter(at, "at");
                if (((LinearLayout) this.f$1).getVisibility() != 0) {
                    TypingKt.slide(this.f$0.getControls$android_release());
                    ((RemoteScreenKt$$ExternalSyntheticLambda9) this.f$2).invoke(Boolean.TRUE);
                }
                at.requestFocus();
                return Boolean.valueOf(((InputMethodManager) this.f$3).showSoftInput(at, 0));
            default:
                boolean booleanValue2 = ((Boolean) obj).booleanValue();
                MainActivity mainActivity4 = this.f$0;
                if (booleanValue2) {
                    ((IrRemoteKt$$ExternalSyntheticLambda22) this.f$1).invoke(mainActivity4.getTextBox$android_release());
                } else if (((LinearLayout) this.f$2).getVisibility() == 0) {
                    TypingKt.slide(mainActivity4.getControls$android_release());
                    ((RemoteScreenKt$$ExternalSyntheticLambda9) this.f$3).invoke(Boolean.FALSE);
                }
                return Unit.INSTANCE;
        }
    }

    public /* synthetic */ IrRemoteKt$$ExternalSyntheticLambda22(Object obj, MainActivity mainActivity, Object obj2, Object obj3, int i) {
        this.$r8$classId = i;
        this.f$1 = obj;
        this.f$0 = mainActivity;
        this.f$2 = obj2;
        this.f$3 = obj3;
    }

    public /* synthetic */ IrRemoteKt$$ExternalSyntheticLambda22(List list, Network network, Set set, MainActivity mainActivity) {
        this.$r8$classId = 2;
        this.f$1 = list;
        this.f$2 = network;
        this.f$3 = set;
        this.f$0 = mainActivity;
    }
}
