package dev.tvremote.phone;

import android.provider.Settings;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.WireLog;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.adb.AdbTls;
import dev.tvremote.core.adb.Mdns;
import dev.tvremote.core.ontv.Channels;
import dev.tvremote.core.ontv.Games;
import dev.tvremote.core.ontv.Home;
import dev.tvremote.core.ontv.OwnApp;
import dev.tvremote.core.ontv.Rescue;
import dev.tvremote.core.ontv.SetupUpdate;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.remote.Lg$$ExternalSyntheticLambda14;
import dev.tvremote.core.remote.Lg$$ExternalSyntheticLambda2;
import dev.tvremote.core.remote.Lg$$ExternalSyntheticLambda5;
import dev.tvremote.core.remote.Vidaa;
import dev.tvremote.core.remote.Vidaa$$ExternalSyntheticLambda6;
import dev.tvremote.core.remote.WebSocket;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda5;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda8;
import dev.tvremote.phone.ir.IrRemoteKt$$ExternalSyntheticLambda22;
import dev.tvremote.phone.manage.Managing;
import dev.tvremote.phone.media.MediaKt$$ExternalSyntheticLambda15;
import dev.tvremote.phone.media.TalkKt$$ExternalSyntheticLambda2;
import dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda63;
import dev.tvremote.phone.picker.SetupNews;
import dev.tvremote.phone.remote.Gp;
import dev.tvremote.phone.remote.RescuingKt$$ExternalSyntheticLambda2;
import dev.tvremote.phone.remote.TypingKt;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.phone.ui.UiKt;
import dev.tvremote.update.Release;
import java.net.SocketTimeoutException;
import java.net.URI;
import java.security.SecureRandom;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.conscrypt.metrics.ConscryptStatsLog;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda9 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ Tv f$1;
    public final /* synthetic */ String f$2;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda9(Tv tv, MainActivity mainActivity, String str) {
        this.$r8$classId = 6;
        this.f$0 = mainActivity;
        this.f$2 = str;
        this.f$1 = tv;
    }

    /* JADX WARN: Removed duplicated region for block: B:128:0x0241 A[Catch: Exception -> 0x02e7, TRY_ENTER, TryCatch #12 {Exception -> 0x02e7, blocks: (B:119:0x0204, B:121:0x0224, B:125:0x0237, B:128:0x0241, B:130:0x024f, B:135:0x025d, B:139:0x0269, B:144:0x0273, B:147:0x028b, B:149:0x028f, B:151:0x0299, B:152:0x029d, B:154:0x02be, B:159:0x02cc, B:163:0x02d8), top: B:118:0x0204 }] */
    /* JADX WARN: Removed duplicated region for block: B:144:0x0273 A[Catch: Exception -> 0x02e7, TRY_LEAVE, TryCatch #12 {Exception -> 0x02e7, blocks: (B:119:0x0204, B:121:0x0224, B:125:0x0237, B:128:0x0241, B:130:0x024f, B:135:0x025d, B:139:0x0269, B:144:0x0273, B:147:0x028b, B:149:0x028f, B:151:0x0299, B:152:0x029d, B:154:0x02be, B:159:0x02cc, B:163:0x02d8), top: B:118:0x0204 }] */
    /* JADX WARN: Removed duplicated region for block: B:159:0x02cc A[Catch: Exception -> 0x02e7, TryCatch #12 {Exception -> 0x02e7, blocks: (B:119:0x0204, B:121:0x0224, B:125:0x0237, B:128:0x0241, B:130:0x024f, B:135:0x025d, B:139:0x0269, B:144:0x0273, B:147:0x028b, B:149:0x028f, B:151:0x0299, B:152:0x029d, B:154:0x02be, B:159:0x02cc, B:163:0x02d8), top: B:118:0x0204 }] */
    /* JADX WARN: Removed duplicated region for block: B:206:0x049f A[Catch: Exception -> 0x04bd, TRY_ENTER, TryCatch #9 {Exception -> 0x04bd, blocks: (B:201:0x0466, B:206:0x049f, B:210:0x04b0, B:211:0x04bf, B:213:0x04dd, B:216:0x04ee, B:223:0x0492), top: B:200:0x0466 }] */
    /* JADX WARN: Removed duplicated region for block: B:213:0x04dd A[Catch: Exception -> 0x04bd, TryCatch #9 {Exception -> 0x04bd, blocks: (B:201:0x0466, B:206:0x049f, B:210:0x04b0, B:211:0x04bf, B:213:0x04dd, B:216:0x04ee, B:223:0x0492), top: B:200:0x0466 }] */
    /* JADX WARN: Removed duplicated region for block: B:89:0x01d3 A[Catch: InterruptedException -> 0x01e2, TRY_ENTER, TRY_LEAVE, TryCatch #2 {InterruptedException -> 0x01e2, blocks: (B:22:0x0057, B:24:0x0075, B:26:0x0081, B:29:0x0091, B:31:0x00b8, B:34:0x00c5, B:35:0x0106, B:37:0x010a, B:40:0x010e, B:44:0x0116, B:47:0x011e, B:51:0x012b, B:76:0x0131, B:54:0x0153, B:74:0x015b, B:56:0x0167, B:72:0x016f, B:58:0x017d, B:60:0x0185, B:62:0x018e, B:65:0x0196, B:83:0x019e, B:85:0x01a2, B:89:0x01d3, B:104:0x01ae), top: B:21:0x0057 }] */
    /* JADX WARN: Removed duplicated region for block: B:96:0x01be A[SYNTHETIC] */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void run() {
        String T;
        String str;
        boolean containsMatchIn;
        String shell;
        int i;
        JSONObject jSONObject;
        SetupNews setupNews;
        MatcherMatchResult access$findNext;
        String str2;
        Release release;
        String str3;
        String str4;
        String str5;
        String optString;
        String optString2;
        String str6;
        String str7;
        String optString3;
        String optString4;
        String str8;
        List split$default;
        String read;
        int i2 = 4;
        String str9 = "";
        int i3 = 3;
        int i4 = 8;
        int i5 = 2;
        JSONObject jSONObject2 = null;
        String str10 = null;
        int i6 = 1;
        final int i7 = 0;
        switch (this.$r8$classId) {
            case 0:
                MainActivity mainActivity = this.f$0;
                Tv tv = this.f$1;
                String str11 = this.f$2;
                if (mainActivity.pic == tv && !mainActivity.picShown && !mainActivity.isFinishing()) {
                    if (str11.equals("hw")) {
                        T = Fleet.T("screen.hardware", new Pair[0]);
                    } else {
                        T = Fleet.T("screen.software", new Pair[0]);
                    }
                    Popup.Builder builder = new Popup.Builder(mainActivity);
                    String lowerCase = T.toLowerCase(Locale.ROOT);
                    Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                    builder.message = Fleet.T("phone.no_picture_after_10", new Pair("name", lowerCase));
                    builder.setPositiveButton(Fleet.T("screen.back_to_auto", new Pair[0]), new MainActivity$$ExternalSyntheticLambda14(mainActivity, 1));
                    builder.setNegativeButton(Fleet.T("phone.keep_waiting", new Pair[0]), null);
                    builder.show();
                    return;
                }
                return;
            case 1:
                int i8 = MainActivity.$r8$clinit;
                Tv tv2 = this.f$1;
                String str12 = this.f$2;
                String search = tv2.search(str12);
                MainActivity mainActivity2 = this.f$0;
                mainActivity2.ui.post(new MainActivity$$ExternalSyntheticLambda41(mainActivity2, str12, search, i7));
                return;
            case 2:
                MainActivity mainActivity3 = this.f$0;
                Tv tv3 = this.f$1;
                String tvHost = this.f$2;
                if (mainActivity3.tv == tv3 && Intrinsics.areEqual(mainActivity3.host, tvHost) && mainActivity3.foreground) {
                    Managing managing$android_release = mainActivity3.getManaging$android_release();
                    Intrinsics.checkNotNullParameter(tvHost, "tvHost");
                    try {
                        if (!tvHost.equals(managing$android_release.forHost)) {
                            managing$android_release.bind(tvHost);
                        }
                        AdbLink adbLink = managing$android_release.link;
                        if (adbLink != null) {
                            adbLink.state();
                            return;
                        }
                        return;
                    } catch (Exception unused) {
                        return;
                    }
                }
                return;
            case 3:
                Tv tv4 = this.f$1;
                String str13 = this.f$2;
                if (tv4 != null) {
                    int i9 = MainActivity.$r8$clinit;
                    str = tv4.search(str13);
                } else {
                    str = null;
                }
                MainActivity mainActivity4 = this.f$0;
                mainActivity4.ui.post(new MainActivity$$ExternalSyntheticLambda41(mainActivity4, str13, str, 1));
                return;
            case 4:
                try {
                    AdbTls.Wireless parse = Fleet.parse(this.f$1.shell("ps -A -o ARGS 2>/dev/null"));
                    if (parse != null) {
                        i7 = parse.connect;
                    }
                } catch (Exception unused2) {
                }
                MainActivity mainActivity5 = this.f$0;
                mainActivity5.ui.post(new Lg$$ExternalSyntheticLambda5(mainActivity5, this.f$2, i7, 2));
                return;
            case 5:
                String u = this.f$2;
                MainActivity mainActivity6 = this.f$0;
                try {
                    OwnApp ownApp = Channels.app;
                    Intrinsics.checkNotNullParameter(u, "u");
                    if (Channels.validStream(StringsKt.trim(u).toString())) {
                        try {
                            String path = new URI(StringsKt.trim(u).toString()).getPath();
                            if (path != null) {
                                str9 = path;
                            }
                            containsMatchIn = Channels.STREAM.containsMatchIn(str9);
                        } catch (Exception unused3) {
                        }
                        Tv tv5 = this.f$1;
                        if (containsMatchIn) {
                            OwnApp ownApp2 = Channels.app;
                            Channels.Play playResult = Channels.playResult(u, new TalkKt$$ExternalSyntheticLambda2(tv5, i2));
                            if (playResult != Channels.Play.OK) {
                                mainActivity6.ui.post(new Guard$$ExternalSyntheticLambda5(24, mainActivity6, playResult));
                            } else {
                                return;
                            }
                        }
                        ConcurrentHashMap concurrentHashMap = Adb.ASKING;
                        shell = tv5.shell("am start -a android.intent.action.VIEW -d " + Mdns.q(u));
                        if (!StringsKt.contains(shell, "Error", false)) {
                            String lowerCase2 = shell.toLowerCase(Locale.ROOT);
                            Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
                            if (!StringsKt.contains(lowerCase2, "unable to resolve", false)) {
                                return;
                            }
                        }
                        WireLog.all.add("·", "open " + u + ": " + StringsKt.take(StringsKt.trim(shell).toString(), 120));
                        mainActivity6.ui.post(new MainActivity$$ExternalSyntheticLambda15(mainActivity6, 11));
                        return;
                    }
                    containsMatchIn = false;
                    Tv tv52 = this.f$1;
                    if (containsMatchIn) {
                    }
                    ConcurrentHashMap concurrentHashMap2 = Adb.ASKING;
                    shell = tv52.shell("am start -a android.intent.action.VIEW -d " + Mdns.q(u));
                    if (!StringsKt.contains(shell, "Error", false)) {
                    }
                    WireLog.all.add("·", "open " + u + ": " + StringsKt.take(StringsKt.trim(shell).toString(), 120));
                    mainActivity6.ui.post(new MainActivity$$ExternalSyntheticLambda15(mainActivity6, 11));
                    return;
                } catch (Exception e) {
                    WireLog.all.add("·", "open " + u + ": " + e);
                    mainActivity6.ui.post(new MediaKt$$ExternalSyntheticLambda15(mainActivity6, e, i7));
                    return;
                }
            case 6:
                MainActivity mainActivity7 = this.f$0;
                if (!mainActivity7.isFinishing()) {
                    String str14 = this.f$2;
                    if (str14 == null) {
                        Fleet.say(mainActivity7, Fleet.T("now_playing.the_tv_did_not_2", new Pair[0]), true);
                        return;
                    }
                    EditText input = UiKt.input(mainActivity7, Fleet.T("playing.clip_empty", new Pair[0]));
                    input.setText(str14);
                    input.setSingleLine(false);
                    input.setMinLines(4);
                    input.setMaxLines(8);
                    input.setGravity(8388659);
                    input.setBackground(UiKt.box(mainActivity7, UiKt.BTN, 12));
                    LinearLayout col = UiKt.col(mainActivity7);
                    float f = 24;
                    float f2 = 12;
                    col.setPadding(UiKt.dp(mainActivity7, f), UiKt.dp(mainActivity7, f2), UiKt.dp(mainActivity7, f), UiKt.dp(mainActivity7, 20));
                    col.addView(input, new LinearLayout.LayoutParams(-1, -2));
                    LinearLayout linearLayout = new LinearLayout(mainActivity7);
                    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, UiKt.dp(mainActivity7, 44));
                    layoutParams.topMargin = UiKt.dp(mainActivity7, f2);
                    col.addView(linearLayout, layoutParams);
                    Popup.Builder builder2 = new Popup.Builder(mainActivity7);
                    builder2.title = Fleet.T("now_playing.the_tvs_clipboard", new Pair[0]);
                    builder2.view = col;
                    Popup create = builder2.create();
                    final IrRemoteKt$$ExternalSyntheticLambda22 irRemoteKt$$ExternalSyntheticLambda22 = new IrRemoteKt$$ExternalSyntheticLambda22(input, mainActivity7, create, this.f$1, 1);
                    final int i10 = 1;
                    int i11 = 0;
                    for (Triple triple : ArraysKt.asList(new Triple[]{new Triple(Fleet.T("now_playing.copy", new Pair[0]), Fleet.T("now_playing.copy_to_the_phone", new Pair[0]), new Vidaa$$ExternalSyntheticLambda6(mainActivity7, input, create, 5)), new Triple(Fleet.T("now_playing.send", new Pair[0]), Fleet.T("now_playing.put_on_the_tvs", new Pair[0]), new Function0() { // from class: dev.tvremote.phone.media.NowPlayingBarKt$$ExternalSyntheticLambda8
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            switch (i7) {
                                case 0:
                                    irRemoteKt$$ExternalSyntheticLambda22.invoke(Boolean.FALSE);
                                    return Unit.INSTANCE;
                                default:
                                    irRemoteKt$$ExternalSyntheticLambda22.invoke(Boolean.TRUE);
                                    return Unit.INSTANCE;
                            }
                        }
                    }), new Triple(Fleet.T("now_playing.paste", new Pair[0]), Fleet.T("now_playing.paste_where_the_tv", new Pair[0]), new Function0() { // from class: dev.tvremote.phone.media.NowPlayingBarKt$$ExternalSyntheticLambda8
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            switch (i10) {
                                case 0:
                                    irRemoteKt$$ExternalSyntheticLambda22.invoke(Boolean.FALSE);
                                    return Unit.INSTANCE;
                                default:
                                    irRemoteKt$$ExternalSyntheticLambda22.invoke(Boolean.TRUE);
                                    return Unit.INSTANCE;
                            }
                        }
                    })})) {
                        int i12 = i11 + 1;
                        String str15 = (String) triple.first;
                        if (i11 == 2) {
                            i = UiKt.ACCENT;
                        } else {
                            i = UiKt.BTN;
                        }
                        View button = UiKt.button(mainActivity7, str15, i);
                        button.setContentDescription((CharSequence) triple.second);
                        float f3 = 4;
                        button.setPadding(UiKt.dp(mainActivity7, f3), 0, UiKt.dp(mainActivity7, f3), 0);
                        button.setOnClickListener(new Guard$$ExternalSyntheticLambda8(i2, triple));
                        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(0, -1, 1.0f);
                        if (i11 > 0) {
                            layoutParams2.leftMargin = UiKt.dp(mainActivity7, 8);
                        }
                        linearLayout.addView(button, layoutParams2);
                        i11 = i12;
                    }
                    create.show();
                    return;
                }
                return;
            case 7:
                Tv tv6 = this.f$1;
                MainActivity mainActivity8 = this.f$0;
                String str16 = this.f$2;
                try {
                    jSONObject = Home.call("", new TalkKt$$ExternalSyntheticLambda2(tv6, 7), null);
                } catch (Exception unused4) {
                    jSONObject = null;
                }
                if (jSONObject == null || !jSONObject.optBoolean("installed")) {
                    jSONObject = null;
                }
                try {
                    Pattern compile = Pattern.compile("versionName=(\\S+)");
                    Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                    String shell2 = tv6.shell("dumpsys package dev.tvremote.setup 2>/dev/null | grep -m1 versionName=");
                    Matcher matcher = compile.matcher(shell2);
                    Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
                    access$findNext = MathKt.access$findNext(matcher, 0, shell2);
                } catch (Exception unused5) {
                    mainActivity8.setupChecked.remove(str16);
                    setupNews = null;
                }
                if (access$findNext != null && (str8 = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)) != null) {
                    str2 = str8;
                    if (str2.length() != 0) {
                        if (jSONObject != null && (optString4 = jSONObject.optString("version")) != null) {
                            str6 = optString4;
                            if (jSONObject != null && (optString3 = jSONObject.optString("latest")) != null) {
                                str7 = optString3;
                                setupNews = new SetupNews("", "", "", 0L, "", "", str6, str7, true);
                            }
                            str7 = "";
                            setupNews = new SetupNews("", "", "", 0L, "", "", str6, str7, true);
                        }
                        str6 = "";
                        if (jSONObject != null) {
                            str7 = optString3;
                            setupNews = new SetupNews("", "", "", 0L, "", "", str6, str7, true);
                        }
                        str7 = "";
                        setupNews = new SetupNews("", "", "", 0L, "", "", str6, str7, true);
                    } else {
                        Regex regex = SetupUpdate.VERSION;
                        JSONObject parse2 = SetupUpdate.parse(tv6.shell("cat /data/local/tmp/tvr-update/state 2>/dev/null; echo '|'; cat /data/local/tmp/tvr-update/bad 2>/dev/null"));
                        try {
                            List list = Release.KEYS;
                            release = MathKt.newer(str2, "tv", "tv-setup.apk");
                        } catch (Exception unused6) {
                            release = null;
                        }
                        if (release != null) {
                            Regex regex2 = SetupUpdate.VERSION;
                            if (!SetupUpdate.bad(release.version, parse2)) {
                                str3 = release.version;
                                String optString5 = parse2.optString("state");
                                Intrinsics.checkNotNullExpressionValue(optString5, "optString(...)");
                                long optLong = parse2.optLong("at");
                                String optString6 = parse2.optString("version");
                                Intrinsics.checkNotNullExpressionValue(optString6, "optString(...)");
                                String optString7 = parse2.optString("from");
                                Intrinsics.checkNotNullExpressionValue(optString7, "optString(...)");
                                if (jSONObject != null && (optString2 = jSONObject.optString("version")) != null) {
                                    str4 = optString2;
                                    if (jSONObject != null && (optString = jSONObject.optString("latest")) != null) {
                                        str5 = optString;
                                        setupNews = new SetupNews(str2, str3, optString5, optLong, optString6, optString7, str4, str5, false);
                                    }
                                    str5 = "";
                                    setupNews = new SetupNews(str2, str3, optString5, optLong, optString6, optString7, str4, str5, false);
                                }
                                str4 = "";
                                if (jSONObject != null) {
                                    str5 = optString;
                                    setupNews = new SetupNews(str2, str3, optString5, optLong, optString6, optString7, str4, str5, false);
                                }
                                str5 = "";
                                setupNews = new SetupNews(str2, str3, optString5, optLong, optString6, optString7, str4, str5, false);
                            }
                        }
                        str3 = "";
                        String optString52 = parse2.optString("state");
                        Intrinsics.checkNotNullExpressionValue(optString52, "optString(...)");
                        long optLong2 = parse2.optLong("at");
                        String optString62 = parse2.optString("version");
                        Intrinsics.checkNotNullExpressionValue(optString62, "optString(...)");
                        String optString72 = parse2.optString("from");
                        Intrinsics.checkNotNullExpressionValue(optString72, "optString(...)");
                        if (jSONObject != null) {
                            str4 = optString2;
                            if (jSONObject != null) {
                            }
                            str5 = "";
                            setupNews = new SetupNews(str2, str3, optString52, optLong2, optString62, optString72, str4, str5, false);
                        }
                        str4 = "";
                        if (jSONObject != null) {
                        }
                        str5 = "";
                        setupNews = new SetupNews(str2, str3, optString52, optLong2, optString62, optString72, str4, str5, false);
                    }
                    mainActivity8.ui.post(new Lg$$ExternalSyntheticLambda2(mainActivity8, setupNews, str16, 24));
                    return;
                }
                str2 = "";
                if (str2.length() != 0) {
                }
                mainActivity8.ui.post(new Lg$$ExternalSyntheticLambda2(mainActivity8, setupNews, str16, 24));
                return;
            case 8:
                MainActivity mainActivity9 = this.f$0;
                Tv tv7 = this.f$1;
                String str17 = this.f$2;
                long j = 400;
                while (Gp.alive) {
                    try {
                        try {
                            String obj = StringsKt.trim(tv7.shell("cat /sdcard/Android/data/dev.tvremote.games/files/pad.txt 2>/dev/null")).toString();
                            char[] cArr = new char[i6];
                            cArr[0] = ' ';
                            split$default = StringsKt.split$default(obj, cArr);
                        } catch (InterruptedException unused7) {
                            return;
                        }
                    } catch (Exception unused8) {
                    }
                    if (split$default.size() == i5 && StringsKt__StringNumberConversionsKt.toIntOrNull((String) split$default.get(0)) != null && ((String) split$default.get(i6)).length() >= 16) {
                        SecureRandom secureRandom = WebSocket.RANDOM;
                        WebSocket open$default = Vidaa.Companion.open$default(str17, Integer.parseInt((String) split$default.get(0)), "/ws?k=" + split$default.get(i6), false);
                        Gp.ws = open$default;
                        try {
                            String string = Settings.Secure.getString(mainActivity9.getContentResolver(), "android_id");
                            if (string == null) {
                                string = "";
                            }
                            open$default.send("hello " + ("gyro-" + StringsKt.take(string, 8)));
                            open$default.sock.setSoTimeout(500);
                            Thread thread = new Thread(new Lg$$ExternalSyntheticLambda14(open$default, i3));
                            thread.setDaemon(true);
                            thread.start();
                            while (Gp.alive && Gp.ws == open$default) {
                                try {
                                    read = open$default.read();
                                } catch (SocketTimeoutException | Exception unused9) {
                                }
                                if (read != null) {
                                    if (!StringsKt__StringsJVMKt.startsWith(read, false, "p ") && StringsKt__StringsJVMKt.startsWith(read, false, "{")) {
                                        JSONObject jSONObject3 = new JSONObject(read);
                                        if (jSONObject3.has("slot")) {
                                            TypingKt.gpStatus(mainActivity9, Fleet.T("gpad.joined", new Pair("n", Integer.valueOf(jSONObject3.getInt("slot")))));
                                        } else if (jSONObject3.optBoolean("full")) {
                                            TypingKt.gpStatus(mainActivity9, Fleet.T("gpad.full", new Pair[0]));
                                        } else if (jSONObject3.optBoolean("replaced")) {
                                            TypingKt.gpStatus(mainActivity9, Fleet.T("gpad.replaced", new Pair[0]));
                                            Gp.alive = false;
                                        } else if (!jSONObject3.optBoolean("rescan") && !jSONObject3.optBoolean("closed")) {
                                            if (jSONObject3.has("vibrate")) {
                                                mainActivity9.buzz$android_release();
                                            }
                                        }
                                    }
                                }
                            }
                            try {
                                open$default.close();
                            } catch (Exception unused10) {
                            }
                            if (Gp.alive) {
                                TypingKt.gpStatus(mainActivity9, Fleet.T("gpad.joining", new Pair[0]));
                            }
                            j = 400;
                        } catch (Exception unused11) {
                            j = 400;
                            if (Gp.alive) {
                                TypingKt.gpStatus(mainActivity9, Fleet.T("gpad.joining", new Pair[0]));
                            }
                            if (!Gp.alive) {
                            }
                            i5 = 2;
                            i6 = 1;
                        }
                        if (!Gp.alive) {
                            Thread.sleep(j);
                            j *= 2;
                            if (j > 5000) {
                                j = 5000;
                            }
                        }
                        i5 = 2;
                        i6 = 1;
                    }
                    TypingKt.gpStatus(mainActivity9, Fleet.T("gpad.off", new Pair[0]));
                    Thread.sleep(2500L);
                    i5 = 2;
                    i6 = 1;
                }
                return;
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                try {
                    str10 = Games.pad(this.f$2, new TalkKt$$ExternalSyntheticLambda2(this.f$1, i4));
                } catch (Exception unused12) {
                }
                MainActivity mainActivity10 = this.f$0;
                mainActivity10.runOnUiThread(new AdbHelpKt$$ExternalSyntheticLambda63(str10, mainActivity10, i3));
                return;
            default:
                try {
                    jSONObject2 = Rescue.run$default(new TalkKt$$ExternalSyntheticLambda2(this.f$1, 13));
                } catch (Exception unused13) {
                }
                MainActivity mainActivity11 = this.f$0;
                mainActivity11.ui.post(new RescuingKt$$ExternalSyntheticLambda2(jSONObject2, mainActivity11, this.f$2));
                return;
        }
    }

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda9(Tv tv, MainActivity mainActivity, String str, int i) {
        this.$r8$classId = i;
        this.f$1 = tv;
        this.f$0 = mainActivity;
        this.f$2 = str;
    }

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda9(Tv tv, String str, MainActivity mainActivity, int i) {
        this.$r8$classId = i;
        this.f$1 = tv;
        this.f$2 = str;
        this.f$0 = mainActivity;
    }

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda9(MainActivity mainActivity, Tv tv, String str, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
        this.f$1 = tv;
        this.f$2 = str;
    }

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda9(String str, MainActivity mainActivity, Tv tv, int i) {
        this.$r8$classId = i;
        this.f$2 = str;
        this.f$0 = mainActivity;
        this.f$1 = tv;
    }
}
