package dev.tvremote.phone;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.Toast;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class SceneActivity extends Activity {
    @Override // android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().getDecorView().setLayoutDirection(0);
        Intent intent = new Intent(this, (Class<?>) SceneService.class);
        Bundle extras = getIntent().getExtras();
        if (extras == null) {
            extras = new Bundle();
        }
        Intent putExtras = intent.putExtras(extras);
        Intrinsics.checkNotNullExpressionValue(putExtras, "putExtras(...)");
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(putExtras);
            } else {
                startService(putExtras);
            }
        } catch (Exception e) {
            Toast.makeText(this, e.getMessage(), 1).show();
        }
        finish();
    }
}
