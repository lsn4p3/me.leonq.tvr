package dev.tvremote.phone;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import dev.tvremote.core.Fleet;
import dev.tvremote.guard.Guard$$ExternalSyntheticApiModelOutline0;
import dev.tvremote.phone.ui.UiKt;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;
import org.conscrypt.R;

/* loaded from: classes.dex */
public final class SceneService extends Service {
    public static final /* synthetic */ int $r8$clinit = 0;
    public volatile boolean busy;
    public final Handler ui = new Handler(Looper.getMainLooper());

    @Override // android.app.Service
    public final IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public final int onStartCommand(Intent intent, int i, int i2) {
        Notification.Builder builder;
        String str;
        String str2;
        UiKt.loadLang(this);
        String T = Fleet.T("scene_activity.sending_to_the_tv", new Pair[0]);
        int i3 = Build.VERSION.SDK_INT;
        if (i3 >= 26) {
            Object systemService = getSystemService("notification");
            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.app.NotificationManager");
            Guard$$ExternalSyntheticApiModelOutline0.m18m();
            ((NotificationManager) systemService).createNotificationChannel(Guard$$ExternalSyntheticApiModelOutline0.m$1(Fleet.T("scene_activity.commands_to_the_tv", new Pair[0])));
            builder = Guard$$ExternalSyntheticApiModelOutline0.m(this);
        } else {
            builder = new Notification.Builder(this);
        }
        Notification build = builder.setSmallIcon(R.drawable.ic_tv).setContentTitle("TV Remote").setContentText(T).build();
        Intrinsics.checkNotNullExpressionValue(build, "build(...)");
        if (i3 >= 34) {
            startForeground(3, build, 2048);
        } else {
            startForeground(3, build);
        }
        if (this.busy) {
            return 2;
        }
        this.busy = true;
        if (intent != null) {
            str = intent.getStringExtra("scene");
        } else {
            str = null;
        }
        if (intent == null || (str2 = intent.getStringExtra("do")) == null) {
            str2 = "";
        }
        new Thread(new SceneService$$ExternalSyntheticLambda3(this, str, str2)).start();
        return 2;
    }

    @Override // android.app.Service
    public final void onTimeout(int i) {
        stopSelf();
    }
}
