package dev.tvremote.phone;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.manage.HealthApi;
import dev.tvremote.core.web.HttpServer;
import dev.tvremote.guard.Guard$$ExternalSyntheticApiModelOutline0;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda3;
import dev.tvremote.home.HomeQr$$ExternalSyntheticLambda0;
import dev.tvremote.phone.ui.UiKt;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import org.conscrypt.R;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class WorkService extends Service {
    public static final Companion Companion = new Object();
    public static boolean stopAsked;
    public static boolean up;
    public PowerManager.WakeLock wake;

    @Override // android.app.Service
    public final IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public final void onCreate() {
        super.onCreate();
        UiKt.loadLang(this);
        Companion companion = Companion;
        Notification note = Companion.note(this, "", -1);
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(5, note, 1);
        } else {
            startForeground(5, note);
        }
        synchronized (companion) {
            up = true;
            if (stopAsked) {
                stopAsked = false;
                stopSelf();
            }
        }
        MathKt.reachAroundVpn(this);
        Object systemService = getSystemService("power");
        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.os.PowerManager");
        PowerManager.WakeLock newWakeLock = ((PowerManager) systemService).newWakeLock(1, "tvremote:work");
        newWakeLock.setReferenceCounted(false);
        newWakeLock.acquire(3600000L);
        this.wake = newWakeLock;
    }

    @Override // android.app.Service
    public final void onDestroy() {
        synchronized (Companion) {
            up = false;
        }
        PowerManager.WakeLock wakeLock = this.wake;
        if (wakeLock != null) {
            wakeLock.release();
        }
        super.onDestroy();
    }

    @Override // android.app.Service
    public final int onStartCommand(Intent intent, int i, int i2) {
        String stringExtra;
        if (intent != null && (stringExtra = intent.getStringExtra("what")) != null) {
            Companion.show(this, stringExtra, -1);
            return 2;
        }
        return 2;
    }

    /* loaded from: classes.dex */
    public final class Companion {
        public static final String access$find(String str, String str2) {
            String str3 = HealthApi.HEALTH_LIVE_NOW;
            Matcher matcher = Pattern.compile(str).matcher(str2);
            if (matcher.find()) {
                return matcher.group(1);
            }
            return null;
        }

        public static final Object access$num(String str) {
            String str2 = HealthApi.HEALTH_LIVE_NOW;
            if (str != null) {
                return Long.valueOf(Long.parseLong(str));
            }
            Object NULL = JSONObject.NULL;
            Intrinsics.checkNotNullExpressionValue(NULL, "NULL");
            return NULL;
        }

        public static final HttpServer.Request access$read(InputStream inputStream) {
            String substring;
            HashMap hashMap;
            long j;
            Long longOrNull;
            String str;
            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = HttpServer.trusted;
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            long nanoTime = System.nanoTime() + 15000000000L;
            while (true) {
                int i = 0;
                while (i < 4) {
                    int read = inputStream.read();
                    if (read >= 0 && byteArrayOutputStream.size() <= 16384 && System.nanoTime() <= nanoTime) {
                        byteArrayOutputStream.write(read);
                        if ((read == 13 && (i == 0 || i == 2)) || (read == 10 && (i == 1 || i == 3))) {
                            i++;
                        } else if (read == 13) {
                            i = 1;
                        }
                    } else {
                        return null;
                    }
                }
                String byteArrayOutputStream2 = byteArrayOutputStream.toString("ISO-8859-1");
                Intrinsics.checkNotNullExpressionValue(byteArrayOutputStream2, "toString(...)");
                List split$default = StringsKt.split$default(byteArrayOutputStream2, new String[]{"\r\n"}, 0, 6);
                List split$default2 = StringsKt.split$default((CharSequence) split$default.get(0), new String[]{" "}, 0, 6);
                if (split$default2.size() >= 2) {
                    HttpServer.Request request = new HttpServer.Request();
                    String str2 = (String) split$default2.get(0);
                    Intrinsics.checkNotNullParameter(str2, "<set-?>");
                    request.method = str2;
                    String str3 = (String) split$default2.get(1);
                    int indexOf$default = StringsKt.indexOf$default(str3, '?', 6);
                    if (indexOf$default < 0) {
                        substring = str3;
                    } else {
                        substring = str3.substring(0, indexOf$default);
                        Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
                    }
                    request.path = substring;
                    if (indexOf$default >= 0) {
                        String substring2 = str3.substring(indexOf$default + 1);
                        Intrinsics.checkNotNullExpressionValue(substring2, "substring(...)");
                        Iterator it = StringsKt.split$default(substring2, new String[]{"&"}, 0, 6).iterator();
                        while (it.hasNext()) {
                            List split$default3 = StringsKt.split$default((String) it.next(), new String[]{"="}, 2, 2);
                            try {
                                HashMap hashMap2 = request.query;
                                String decode = URLDecoder.decode((String) split$default3.get(0), "UTF-8");
                                if (split$default3.size() > 1) {
                                    str = URLDecoder.decode((String) split$default3.get(1), "UTF-8");
                                } else {
                                    str = "";
                                }
                                hashMap2.put(decode, str);
                            } catch (IllegalArgumentException unused) {
                                return null;
                            }
                        }
                    }
                    Iterator it2 = CollectionsKt.drop(1, split$default).iterator();
                    while (true) {
                        boolean hasNext = it2.hasNext();
                        hashMap = request.headers;
                        if (!hasNext) {
                            break;
                        }
                        String str4 = (String) it2.next();
                        int indexOf$default2 = StringsKt.indexOf$default(str4, ':', 6);
                        if (indexOf$default2 > 0) {
                            String substring3 = str4.substring(0, indexOf$default2);
                            Intrinsics.checkNotNullExpressionValue(substring3, "substring(...)");
                            String obj = StringsKt.trim(substring3).toString();
                            Locale ROOT = Locale.ROOT;
                            Intrinsics.checkNotNullExpressionValue(ROOT, "ROOT");
                            String lowerCase = obj.toLowerCase(ROOT);
                            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                            String substring4 = str4.substring(indexOf$default2 + 1);
                            Intrinsics.checkNotNullExpressionValue(substring4, "substring(...)");
                            hashMap.put(lowerCase, StringsKt.trim(substring4).toString());
                        }
                    }
                    String str5 = (String) hashMap.get("content-length");
                    if (str5 != null && (longOrNull = StringsKt__StringNumberConversionsKt.toLongOrNull(str5)) != null) {
                        j = longOrNull.longValue();
                    } else {
                        j = 0;
                    }
                    request.length = j;
                    if (j < 0) {
                        return null;
                    }
                    request.body = new HttpServer.Left(inputStream, request.length);
                    return request;
                }
                return null;
            }
        }

        public static byte[] bytes(String str) {
            byte[] bytes = str.getBytes(Charsets.UTF_8);
            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
            return bytes;
        }

        public static Notification note(Context context, String str, int i) {
            Notification.Builder builder;
            String str2;
            int i2;
            boolean z = false;
            if (Build.VERSION.SDK_INT >= 26) {
                Object systemService = context.getSystemService("notification");
                Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.app.NotificationManager");
                Guard$$ExternalSyntheticApiModelOutline0.m18m();
                Guard$$ExternalSyntheticApiModelOutline0.m((NotificationManager) systemService, Guard$$ExternalSyntheticApiModelOutline0.m$2(Fleet.T("work_service.work_on_the_tv", new Pair[0])));
                builder = Guard$$ExternalSyntheticApiModelOutline0.m(context);
            } else {
                builder = new Notification.Builder(context);
            }
            PendingIntent activity = PendingIntent.getActivity(context, 3, new Intent(context, (Class<?>) MainActivity.class).addFlags(536870912), 201326592);
            Notification.Builder smallIcon = builder.setSmallIcon(R.drawable.ic_tv);
            String say = say(str);
            if (i >= 0) {
                str2 = ApkSigner$$ExternalSyntheticOutline0.m(" · ", i, "%");
            } else {
                str2 = "...";
            }
            Notification.Builder onlyAlertOnce = smallIcon.setContentTitle(say + str2).setContentText(Fleet.T("work_service.goes_on_while_you", new Pair[0])).setContentIntent(activity).setOngoing(true).setOnlyAlertOnce(true);
            if (i < 0) {
                i2 = 0;
            } else {
                i2 = i;
            }
            if (i < 0) {
                z = true;
            }
            Notification build = onlyAlertOnce.setProgress(100, i2, z).build();
            Intrinsics.checkNotNullExpressionValue(build, "build(...)");
            return build;
        }

        public static String say(String what) {
            Intrinsics.checkNotNullParameter(what, "what");
            switch (what.hashCode()) {
                case -838846263:
                    if (what.equals("update")) {
                        return Fleet.T("work_service.updating_tv_setup", new Pair[0]);
                    }
                    break;
                case -838595071:
                    if (what.equals("upload")) {
                        return Fleet.T("work_service.copying_a_file_to", new Pair[0]);
                    }
                    break;
                case -57604358:
                    if (what.equals("tailscale")) {
                        return Fleet.T("work_service.setting_up_tailscale_on", new Pair[0]);
                    }
                    break;
                case 1957569947:
                    if (what.equals("install")) {
                        return Fleet.T("work_service.installing_an_app_on", new Pair[0]);
                    }
                    break;
            }
            return Fleet.T("work_service.working_on_the_tv", new Pair[0]);
        }

        public static void show(String str, JSONObject jSONObject) {
            String str2;
            ListenService listenService = ListenService.current;
            if (listenService == null) {
                return;
            }
            if (jSONObject == null || (str2 = ArraysKt.asList(new Object[]{jSONObject.opt("state"), jSONObject.opt("title"), jSONObject.opt("app"), jSONObject.opt("sub"), jSONObject.opt("dur"), Long.valueOf(jSONObject.optLong("pos") / 15000)}).toString()) == null) {
                str2 = "";
            }
            String concat = str2.concat(str);
            ListenService.last = str;
            if (Intrinsics.areEqual(concat, ListenService.shown)) {
                return;
            }
            ListenService.shown = concat;
            listenService.show(str, jSONObject);
        }

        public static void stop(MainActivity c) {
            Intrinsics.checkNotNullParameter(c, "c");
            synchronized (ListenService.Companion) {
                try {
                    if (ListenService.up) {
                        c.stopService(new Intent(c, (Class<?>) ListenService.class));
                    } else {
                        ListenService.stopAsked = true;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        public static void stop$1(MainActivity mainActivity) {
            synchronized (WorkService.Companion) {
                try {
                    if (WorkService.up) {
                        mainActivity.stopService(new Intent(mainActivity, (Class<?>) WorkService.class));
                    } else {
                        WorkService.stopAsked = true;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        public static void sweep() {
            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = HttpServer.trusted;
            ((ScheduledThreadPoolExecutor) HttpServer.sweeper$delegate.getValue()).schedule(new Guard$$ExternalSyntheticLambda3(4), MathKt.coerceIn(30000 / 4, 50L, 5000L), TimeUnit.MILLISECONDS);
        }

        public static void show(Context context, String what, int i) {
            Intrinsics.checkNotNullParameter(what, "what");
            try {
                Object systemService = context.getSystemService("notification");
                Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.app.NotificationManager");
                ((NotificationManager) systemService).notify(5, note(context, what, i));
            } catch (Exception unused) {
            }
        }
    }
}
