package dev.tvremote.phone;

import android.content.DialogInterface;
import android.os.Handler;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.adb.AdbTls;
import dev.tvremote.core.remote.Lg$$ExternalSyntheticLambda5;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.picker.AdbHelpKt;
import dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda54;
import dev.tvremote.phone.picker.PickerScreenKt;
import dev.tvremote.phone.ui.Popup;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;

/* loaded from: classes.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda41 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ String f$1;
    public final /* synthetic */ String f$2;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda41(MainActivity mainActivity, String str, String str2) {
        this.$r8$classId = 2;
        this.f$1 = str;
        this.f$0 = mainActivity;
        this.f$2 = str2;
    }

    /* JADX WARN: Removed duplicated region for block: B:18:0x00e3 A[LOOP:0: B:16:0x00dd->B:18:0x00e3, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0112 A[LOOP:1: B:21:0x010c->B:23:0x0112, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:28:0x012c  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x0142 A[SYNTHETIC] */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void run() {
        final boolean z;
        final boolean open;
        final String str;
        Iterator it;
        Iterator it2;
        Iterator it3;
        Object obj;
        Pair pair;
        String str2;
        String str3 = this.f$2;
        String str4 = this.f$1;
        MainActivity mainActivity = this.f$0;
        switch (this.$r8$classId) {
            case 0:
                int i = MainActivity.$r8$clinit;
                mainActivity.searched$android_release(str4, str3);
                return;
            case 1:
                int i2 = MainActivity.$r8$clinit;
                mainActivity.searched$android_release(str4, str3);
                return;
            default:
                final String str5 = this.f$1;
                boolean open2 = MathKt.open(str5, 5555, 1500, null);
                final MainActivity mainActivity2 = this.f$0;
                if (open2) {
                    mainActivity2.adbFailed.add(str5);
                }
                if (!open2) {
                    AdbTls adbTls = AdbTls.INSTANCE;
                    if (AdbTls.available() && AdbTls.wireless$default(14, str5, null).getAny()) {
                        z = true;
                        open = MathKt.open(str5, 6466, 2500, null);
                        if (!open && !z) {
                            List list = Remote.Kind.ALL;
                            List asList = ArraysKt.asList(new Pair[]{new Pair(6466, "android"), new Pair(5555, "android"), new Pair(3000, "lg"), new Pair(3001, "lg"), new Pair(8002, "samsung"), new Pair(8001, "samsung"), new Pair(8060, "roku"), new Pair(36669, "vidaa")});
                            ConcurrentHashMap concurrentHashMap = new ConcurrentHashMap();
                            ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(asList));
                            it = asList.iterator();
                            while (it.hasNext()) {
                                Thread thread = new Thread(new Lg$$ExternalSyntheticLambda5(str5, ((Number) ((Pair) it.next()).first).intValue(), concurrentHashMap));
                                thread.setDaemon(true);
                                thread.start();
                                arrayList.add(thread);
                            }
                            it2 = arrayList.iterator();
                            while (it2.hasNext()) {
                                ((Thread) it2.next()).join(800 + 300);
                            }
                            it3 = asList.iterator();
                            while (true) {
                                if (!it3.hasNext()) {
                                    obj = it3.next();
                                    if (Intrinsics.areEqual(concurrentHashMap.get(((Pair) obj).first), Boolean.TRUE)) {
                                    }
                                } else {
                                    obj = null;
                                }
                            }
                            pair = (Pair) obj;
                            if (pair != null || (str2 = (String) pair.second) == null) {
                                str2 = null;
                            }
                            if (str2 != null && !str2.equals("android")) {
                                str = str2;
                                Handler handler = mainActivity2.ui;
                                final String str6 = this.f$2;
                                handler.post(new Runnable() { // from class: dev.tvremote.phone.remote.KeysOnlyKt$$ExternalSyntheticLambda15
                                    @Override // java.lang.Runnable
                                    public final void run() {
                                        final MainActivity mainActivity3 = MainActivity.this;
                                        String str7 = str5;
                                        boolean z2 = z;
                                        String str8 = str;
                                        boolean z3 = open;
                                        final String str9 = str6;
                                        if (!mainActivity3.isFinishing() && Intrinsics.areEqual(mainActivity3.host, str7) && mainActivity3.tv == null) {
                                            if (z2) {
                                                String str10 = mainActivity3.entry;
                                                mainActivity3.disconnect$android_release(null);
                                                AdbHelpKt.offerWireless(mainActivity3, str7, str10);
                                                return;
                                            }
                                            if (str8 != null) {
                                                mainActivity3.getPrefs$android_release().edit().putString("kind:" + str7, str8).apply();
                                                mainActivity3.disconnect$android_release(null);
                                                TypingKt.startBasic(mainActivity3, str7, false);
                                                return;
                                            }
                                            if (!z3) {
                                                mainActivity3.disconnect$android_release(str9);
                                                return;
                                            }
                                            mainActivity3.disconnect$android_release(null);
                                            if (mainActivity3.getPrefs$android_release().getBoolean("atv:" + str7, false)) {
                                                TypingKt.startBasic(mainActivity3, str7, false);
                                                return;
                                            }
                                            Popup.Builder builder = new Popup.Builder(mainActivity3);
                                            builder.title = Fleet.T("keys_only.adb_debugging_is_off", new Pair[0]);
                                            builder.message = Fleet.T("keys_only.you_can_still_press", new Pair[0]);
                                            builder.setPositiveButton(Fleet.T("keys_only.pair_with_a_code", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda54(mainActivity3, str7, 2));
                                            builder.setNegativeButton(Fleet.T("common.close", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda54(mainActivity3, str9, 3));
                                            builder.onCancel = new DialogInterface.OnCancelListener() { // from class: dev.tvremote.phone.remote.KeysOnlyKt$$ExternalSyntheticLambda22
                                                @Override // android.content.DialogInterface.OnCancelListener
                                                public final void onCancel(DialogInterface dialogInterface) {
                                                    PickerScreenKt.message(MainActivity.this, str9, true);
                                                }
                                            };
                                            builder.show();
                                        }
                                    }
                                });
                                return;
                            }
                        }
                        str = null;
                        Handler handler2 = mainActivity2.ui;
                        final String str62 = this.f$2;
                        handler2.post(new Runnable() { // from class: dev.tvremote.phone.remote.KeysOnlyKt$$ExternalSyntheticLambda15
                            @Override // java.lang.Runnable
                            public final void run() {
                                final MainActivity mainActivity3 = MainActivity.this;
                                String str7 = str5;
                                boolean z2 = z;
                                String str8 = str;
                                boolean z3 = open;
                                final String str9 = str62;
                                if (!mainActivity3.isFinishing() && Intrinsics.areEqual(mainActivity3.host, str7) && mainActivity3.tv == null) {
                                    if (z2) {
                                        String str10 = mainActivity3.entry;
                                        mainActivity3.disconnect$android_release(null);
                                        AdbHelpKt.offerWireless(mainActivity3, str7, str10);
                                        return;
                                    }
                                    if (str8 != null) {
                                        mainActivity3.getPrefs$android_release().edit().putString("kind:" + str7, str8).apply();
                                        mainActivity3.disconnect$android_release(null);
                                        TypingKt.startBasic(mainActivity3, str7, false);
                                        return;
                                    }
                                    if (!z3) {
                                        mainActivity3.disconnect$android_release(str9);
                                        return;
                                    }
                                    mainActivity3.disconnect$android_release(null);
                                    if (mainActivity3.getPrefs$android_release().getBoolean("atv:" + str7, false)) {
                                        TypingKt.startBasic(mainActivity3, str7, false);
                                        return;
                                    }
                                    Popup.Builder builder = new Popup.Builder(mainActivity3);
                                    builder.title = Fleet.T("keys_only.adb_debugging_is_off", new Pair[0]);
                                    builder.message = Fleet.T("keys_only.you_can_still_press", new Pair[0]);
                                    builder.setPositiveButton(Fleet.T("keys_only.pair_with_a_code", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda54(mainActivity3, str7, 2));
                                    builder.setNegativeButton(Fleet.T("common.close", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda54(mainActivity3, str9, 3));
                                    builder.onCancel = new DialogInterface.OnCancelListener() { // from class: dev.tvremote.phone.remote.KeysOnlyKt$$ExternalSyntheticLambda22
                                        @Override // android.content.DialogInterface.OnCancelListener
                                        public final void onCancel(DialogInterface dialogInterface) {
                                            PickerScreenKt.message(MainActivity.this, str9, true);
                                        }
                                    };
                                    builder.show();
                                }
                            }
                        });
                        return;
                    }
                }
                z = false;
                open = MathKt.open(str5, 6466, 2500, null);
                if (!open) {
                    List list2 = Remote.Kind.ALL;
                    List asList2 = ArraysKt.asList(new Pair[]{new Pair(6466, "android"), new Pair(5555, "android"), new Pair(3000, "lg"), new Pair(3001, "lg"), new Pair(8002, "samsung"), new Pair(8001, "samsung"), new Pair(8060, "roku"), new Pair(36669, "vidaa")});
                    ConcurrentHashMap concurrentHashMap2 = new ConcurrentHashMap();
                    ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(asList2));
                    it = asList2.iterator();
                    while (it.hasNext()) {
                    }
                    it2 = arrayList2.iterator();
                    while (it2.hasNext()) {
                    }
                    it3 = asList2.iterator();
                    while (true) {
                        if (!it3.hasNext()) {
                        }
                    }
                    pair = (Pair) obj;
                    if (pair != null) {
                    }
                    str2 = null;
                    if (str2 != null) {
                        str = str2;
                        Handler handler22 = mainActivity2.ui;
                        final String str622 = this.f$2;
                        handler22.post(new Runnable() { // from class: dev.tvremote.phone.remote.KeysOnlyKt$$ExternalSyntheticLambda15
                            @Override // java.lang.Runnable
                            public final void run() {
                                final MainActivity mainActivity3 = MainActivity.this;
                                String str7 = str5;
                                boolean z2 = z;
                                String str8 = str;
                                boolean z3 = open;
                                final String str9 = str622;
                                if (!mainActivity3.isFinishing() && Intrinsics.areEqual(mainActivity3.host, str7) && mainActivity3.tv == null) {
                                    if (z2) {
                                        String str10 = mainActivity3.entry;
                                        mainActivity3.disconnect$android_release(null);
                                        AdbHelpKt.offerWireless(mainActivity3, str7, str10);
                                        return;
                                    }
                                    if (str8 != null) {
                                        mainActivity3.getPrefs$android_release().edit().putString("kind:" + str7, str8).apply();
                                        mainActivity3.disconnect$android_release(null);
                                        TypingKt.startBasic(mainActivity3, str7, false);
                                        return;
                                    }
                                    if (!z3) {
                                        mainActivity3.disconnect$android_release(str9);
                                        return;
                                    }
                                    mainActivity3.disconnect$android_release(null);
                                    if (mainActivity3.getPrefs$android_release().getBoolean("atv:" + str7, false)) {
                                        TypingKt.startBasic(mainActivity3, str7, false);
                                        return;
                                    }
                                    Popup.Builder builder = new Popup.Builder(mainActivity3);
                                    builder.title = Fleet.T("keys_only.adb_debugging_is_off", new Pair[0]);
                                    builder.message = Fleet.T("keys_only.you_can_still_press", new Pair[0]);
                                    builder.setPositiveButton(Fleet.T("keys_only.pair_with_a_code", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda54(mainActivity3, str7, 2));
                                    builder.setNegativeButton(Fleet.T("common.close", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda54(mainActivity3, str9, 3));
                                    builder.onCancel = new DialogInterface.OnCancelListener() { // from class: dev.tvremote.phone.remote.KeysOnlyKt$$ExternalSyntheticLambda22
                                        @Override // android.content.DialogInterface.OnCancelListener
                                        public final void onCancel(DialogInterface dialogInterface) {
                                            PickerScreenKt.message(MainActivity.this, str9, true);
                                        }
                                    };
                                    builder.show();
                                }
                            }
                        });
                        return;
                    }
                }
                str = null;
                Handler handler222 = mainActivity2.ui;
                final String str6222 = this.f$2;
                handler222.post(new Runnable() { // from class: dev.tvremote.phone.remote.KeysOnlyKt$$ExternalSyntheticLambda15
                    @Override // java.lang.Runnable
                    public final void run() {
                        final MainActivity mainActivity3 = MainActivity.this;
                        String str7 = str5;
                        boolean z2 = z;
                        String str8 = str;
                        boolean z3 = open;
                        final String str9 = str6222;
                        if (!mainActivity3.isFinishing() && Intrinsics.areEqual(mainActivity3.host, str7) && mainActivity3.tv == null) {
                            if (z2) {
                                String str10 = mainActivity3.entry;
                                mainActivity3.disconnect$android_release(null);
                                AdbHelpKt.offerWireless(mainActivity3, str7, str10);
                                return;
                            }
                            if (str8 != null) {
                                mainActivity3.getPrefs$android_release().edit().putString("kind:" + str7, str8).apply();
                                mainActivity3.disconnect$android_release(null);
                                TypingKt.startBasic(mainActivity3, str7, false);
                                return;
                            }
                            if (!z3) {
                                mainActivity3.disconnect$android_release(str9);
                                return;
                            }
                            mainActivity3.disconnect$android_release(null);
                            if (mainActivity3.getPrefs$android_release().getBoolean("atv:" + str7, false)) {
                                TypingKt.startBasic(mainActivity3, str7, false);
                                return;
                            }
                            Popup.Builder builder = new Popup.Builder(mainActivity3);
                            builder.title = Fleet.T("keys_only.adb_debugging_is_off", new Pair[0]);
                            builder.message = Fleet.T("keys_only.you_can_still_press", new Pair[0]);
                            builder.setPositiveButton(Fleet.T("keys_only.pair_with_a_code", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda54(mainActivity3, str7, 2));
                            builder.setNegativeButton(Fleet.T("common.close", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda54(mainActivity3, str9, 3));
                            builder.onCancel = new DialogInterface.OnCancelListener() { // from class: dev.tvremote.phone.remote.KeysOnlyKt$$ExternalSyntheticLambda22
                                @Override // android.content.DialogInterface.OnCancelListener
                                public final void onCancel(DialogInterface dialogInterface) {
                                    PickerScreenKt.message(MainActivity.this, str9, true);
                                }
                            };
                            builder.show();
                        }
                    }
                });
                return;
        }
    }

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda41(MainActivity mainActivity, String str, String str2, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
        this.f$1 = str;
        this.f$2 = str2;
    }
}
