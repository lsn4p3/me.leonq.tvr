package dev.tvremote.phone.picker;

import android.net.ConnectivityManager;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.Network;
import dev.tvremote.core.Lan;
import java.net.InetAddress;
import java.util.List;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class NetKt$reachAroundVpn$2$1 {
    public final /* synthetic */ ConnectivityManager $cm;
    public final /* synthetic */ Network $n;
    public final boolean vpn;

    public NetKt$reachAroundVpn$2$1(boolean z, Network network, ConnectivityManager connectivityManager) {
        this.$n = network;
        this.$cm = connectivityManager;
        this.vpn = z;
    }

    public final boolean onLink(InetAddress inetAddress) {
        List<LinkAddress> linkAddresses;
        LinkProperties linkProperties = this.$cm.getLinkProperties(this.$n);
        if (linkProperties != null && (linkAddresses = linkProperties.getLinkAddresses()) != null && !linkAddresses.isEmpty()) {
            for (LinkAddress linkAddress : linkAddresses) {
                Function0 function0 = Lan.wifi;
                InetAddress address = linkAddress.getAddress();
                Intrinsics.checkNotNullExpressionValue(address, "getAddress(...)");
                if (Lan.inSubnet(inetAddress, address, linkAddress.getPrefixLength())) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }
}
