package dev.tvremote.phone.picker;

import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.manage.Manage;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.ui.UiKt;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class ManyTvsKt$$ExternalSyntheticLambda41 implements Function2 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ ManyTvsKt$$ExternalSyntheticLambda41(MainActivity mainActivity, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(Object obj, Object obj2) {
        int i;
        switch (this.$r8$classId) {
            case 0:
                AdbLink link = (AdbLink) obj;
                Intrinsics.checkNotNullParameter(link, "link");
                Intrinsics.checkNotNullParameter((Part) obj2, "<unused var>");
                Manage manage = new Manage(link, null, this.f$0.getCacheDir(), null);
                JSONObject put = new JSONObject().put("on", false);
                Intrinsics.checkNotNullExpressionValue(put, "put(...)");
                manage.welcomeBulk(null, 0L, "", put, null, null);
                return Fleet.T("fleet.step_welcome_off", new Pair[0]);
            default:
                AppRow r = (AppRow) obj;
                boolean booleanValue = ((Boolean) obj2).booleanValue();
                Intrinsics.checkNotNullParameter(r, "r");
                r.picked = booleanValue;
                CheckBox checkBox = r.tick;
                if (checkBox != null) {
                    checkBox.setChecked(booleanValue);
                    LinearLayout linearLayout = r.view;
                    if (linearLayout != null) {
                        linearLayout.setBackground(UiKt.onBox(12, this.f$0, booleanValue));
                        TextView title = r.getTitle();
                        if (booleanValue) {
                            i = UiKt.ACCENT_TEXT;
                        } else {
                            i = UiKt.TEXT;
                        }
                        title.setTextColor(i);
                        return Unit.INSTANCE;
                    }
                    Intrinsics.throwUninitializedPropertyAccessException("view");
                    throw null;
                }
                Intrinsics.throwUninitializedPropertyAccessException("tick");
                throw null;
        }
    }
}
