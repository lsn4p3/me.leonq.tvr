package dev.tvremote.phone.picker;

import android.view.View;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.media.MediaKt$$ExternalSyntheticLambda4;
import dev.tvremote.phone.media.TalkKt$$ExternalSyntheticLambda1;
import dev.tvremote.phone.ui.UiKt;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.jvm.functions.Function0;

/* loaded from: classes.dex */
public final /* synthetic */ class PickerScreenKt$$ExternalSyntheticLambda4 implements View.OnLongClickListener {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;

    public /* synthetic */ PickerScreenKt$$ExternalSyntheticLambda4(int i, Object obj) {
        this.$r8$classId = i;
        this.f$0 = obj;
    }

    @Override // android.view.View.OnLongClickListener
    public final boolean onLongClick(View view) {
        String str;
        String str2;
        Object obj = this.f$0;
        switch (this.$r8$classId) {
            case 0:
                ((MediaKt$$ExternalSyntheticLambda4) obj).invoke();
                return true;
            default:
                final MainActivity mainActivity = (MainActivity) obj;
                final boolean equals = mainActivity.pref$android_release("talkMode").equals("quick");
                String T = Fleet.T("remote.speak", new Pair[0]);
                if (equals) {
                    str = "talk.to_old";
                } else {
                    str = "talk.to_quick";
                }
                String m = ApkSigner$$ExternalSyntheticOutline0.m("@mic|", Fleet.T(str, new Pair[0]));
                if (equals) {
                    str2 = "talk.mode_old_sub";
                } else {
                    str2 = "talk.mode_quick_sub";
                }
                UiKt.menu(mainActivity, T, -1, ArraysKt.asList(new Triple[]{new Triple(m, Fleet.T(str2, new Pair[0]), new Function0() { // from class: dev.tvremote.phone.media.TalkKt$$ExternalSyntheticLambda7
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        String str3;
                        if (equals) {
                            str3 = "old";
                        } else {
                            str3 = "quick";
                        }
                        Fleet.setTalkMode(MainActivity.this, str3);
                        return Unit.INSTANCE;
                    }
                }), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@tv|", Fleet.T("talk.assistant", new Pair[0])), "", new TalkKt$$ExternalSyntheticLambda1(mainActivity, 23))}));
                return true;
        }
    }
}
