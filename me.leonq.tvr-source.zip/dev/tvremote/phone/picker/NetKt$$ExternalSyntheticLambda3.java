package dev.tvremote.phone.picker;

import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.widget.Button;
import android.widget.TextView;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Words$$ExternalSyntheticLambda1;
import dev.tvremote.core.ontv.Setup$$ExternalSyntheticLambda5;
import dev.tvremote.phone.ui.Popup;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$BooleanRef;
import kotlin.jvm.internal.Ref$ObjectRef;

/* loaded from: classes.dex */
public final /* synthetic */ class NetKt$$ExternalSyntheticLambda3 implements Function0 {
    public final /* synthetic */ int $r8$classId = 1;
    public final /* synthetic */ Collection f$0;
    public final /* synthetic */ Object f$1;
    public final /* synthetic */ Object f$2;
    public final /* synthetic */ Ref$ObjectRef f$3;
    public final /* synthetic */ Object f$4;

    public /* synthetic */ NetKt$$ExternalSyntheticLambda3(List list, Ref$ObjectRef ref$ObjectRef, Setup$$ExternalSyntheticLambda5 setup$$ExternalSyntheticLambda5, Button button, TextView textView) {
        this.f$0 = list;
        this.f$3 = ref$ObjectRef;
        this.f$1 = setup$$ExternalSyntheticLambda5;
        this.f$2 = button;
        this.f$4 = textView;
    }

    /* JADX WARN: Removed duplicated region for block: B:29:0x00c1  */
    @Override // kotlin.jvm.functions.Function0
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object invoke() {
        int i;
        boolean z;
        String str;
        String T;
        switch (this.$r8$classId) {
            case 0:
                NsdManager nsdManager = (NsdManager) this.f$2;
                final Ref$ObjectRef ref$ObjectRef = this.f$3;
                final Words$$ExternalSyntheticLambda1 words$$ExternalSyntheticLambda1 = (Words$$ExternalSyntheticLambda1) this.f$4;
                NsdServiceInfo nsdServiceInfo = (NsdServiceInfo) ((LinkedBlockingQueue) this.f$0).poll();
                Ref$BooleanRef ref$BooleanRef = (Ref$BooleanRef) this.f$1;
                if (nsdServiceInfo == null) {
                    ref$BooleanRef.element = false;
                } else {
                    ref$BooleanRef.element = true;
                    try {
                        nsdManager.resolveService(nsdServiceInfo, new NsdManager.ResolveListener() { // from class: dev.tvremote.phone.picker.NetKt$announced$1$1
                            @Override // android.net.nsd.NsdManager.ResolveListener
                            public final void onResolveFailed(NsdServiceInfo i2, int i3) {
                                Intrinsics.checkNotNullParameter(i2, "i");
                                Object obj = Ref$ObjectRef.this.element;
                                if (obj != null) {
                                    ((Function0) obj).invoke();
                                } else {
                                    Intrinsics.throwUninitializedPropertyAccessException("next");
                                    throw null;
                                }
                            }

                            @Override // android.net.nsd.NsdManager.ResolveListener
                            public final void onServiceResolved(NsdServiceInfo i2) {
                                Inet4Address inet4Address;
                                String hostAddress;
                                Intrinsics.checkNotNullParameter(i2, "i");
                                InetAddress host = i2.getHost();
                                if (host instanceof Inet4Address) {
                                    inet4Address = (Inet4Address) host;
                                } else {
                                    inet4Address = null;
                                }
                                if (inet4Address != null && (hostAddress = inet4Address.getHostAddress()) != null) {
                                    words$$ExternalSyntheticLambda1.invoke(hostAddress);
                                }
                                Object obj = Ref$ObjectRef.this.element;
                                if (obj != null) {
                                    ((Function0) obj).invoke();
                                } else {
                                    Intrinsics.throwUninitializedPropertyAccessException("next");
                                    throw null;
                                }
                            }
                        });
                    } catch (Exception unused) {
                        ref$BooleanRef.element = false;
                    }
                }
                return Unit.INSTANCE;
            default:
                List list = (List) this.f$0;
                int i2 = 0;
                if (list.isEmpty()) {
                    i = 0;
                } else {
                    Iterator it = list.iterator();
                    i = 0;
                    while (it.hasNext()) {
                        if (((AppRow) it.next()).picked && (i = i + 1) < 0) {
                            CollectionsKt__CollectionsKt.throwCountOverflow();
                            throw null;
                        }
                    }
                }
                Object obj = this.f$3.element;
                if (obj != null) {
                    Button button = ((Popup) obj).getButton(-1);
                    if (i > 0) {
                        z = true;
                    } else {
                        z = false;
                    }
                    button.setEnabled(z);
                    String T2 = Fleet.T("fleet.remove", new Pair[0]);
                    if (i > 0) {
                        str = ApkSigner$$ExternalSyntheticOutline0.m(" (", i, ")");
                    } else {
                        str = "";
                    }
                    button.setText(T2 + str);
                    List list2 = (List) ((Setup$$ExternalSyntheticLambda5) this.f$1).invoke();
                    boolean isEmpty = list2.isEmpty() ^ true;
                    Button button2 = (Button) this.f$2;
                    button2.setEnabled(isEmpty);
                    if (!list2.isEmpty()) {
                        if (!list2.isEmpty()) {
                            Iterator it2 = list2.iterator();
                            while (it2.hasNext()) {
                                if (!((AppRow) it2.next()).picked) {
                                }
                            }
                        }
                        T = Fleet.T("fleet.pick_none", new Pair[0]);
                        button2.setText(T);
                        if (!list2.isEmpty()) {
                            i2 = 8;
                        }
                        ((TextView) this.f$4).setVisibility(i2);
                        return Unit.INSTANCE;
                    }
                    T = Fleet.T("fleet.pick_all", new Pair[0]);
                    button2.setText(T);
                    if (!list2.isEmpty()) {
                    }
                    ((TextView) this.f$4).setVisibility(i2);
                    return Unit.INSTANCE;
                }
                Intrinsics.throwUninitializedPropertyAccessException("box");
                throw null;
        }
    }

    public /* synthetic */ NetKt$$ExternalSyntheticLambda3(LinkedBlockingQueue linkedBlockingQueue, Ref$BooleanRef ref$BooleanRef, NsdManager nsdManager, Ref$ObjectRef ref$ObjectRef, Words$$ExternalSyntheticLambda1 words$$ExternalSyntheticLambda1) {
        this.f$0 = linkedBlockingQueue;
        this.f$1 = ref$BooleanRef;
        this.f$2 = nsdManager;
        this.f$3 = ref$ObjectRef;
        this.f$4 = words$$ExternalSyntheticLambda1;
    }
}
