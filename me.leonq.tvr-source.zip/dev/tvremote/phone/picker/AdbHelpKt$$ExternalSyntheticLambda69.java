package dev.tvremote.phone.picker;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.adb.AdbLink$$ExternalSyntheticLambda2;
import dev.tvremote.core.ontv.LauncherInstall;
import dev.tvremote.core.ontv.Launchers;
import dev.tvremote.core.ontv.Setup$$ExternalSyntheticLambda5;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.SceneActivity;
import java.io.File;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$IntRef;
import kotlin.text.StringsKt;

/* loaded from: classes.dex */
public final /* synthetic */ class AdbHelpKt$$ExternalSyntheticLambda69 implements Function2 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;
    public final /* synthetic */ Object f$1;
    public final /* synthetic */ Object f$2;

    public /* synthetic */ AdbHelpKt$$ExternalSyntheticLambda69(MainActivity mainActivity, Launchers.Gallery gallery, Launchers.Entry entry) {
        this.$r8$classId = 2;
        this.f$1 = mainActivity;
        this.f$0 = gallery;
        this.f$2 = entry;
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(Object obj, Object obj2) {
        switch (this.$r8$classId) {
            case 0:
                String want = (String) obj;
                int intValue = ((Integer) obj2).intValue();
                Intrinsics.checkNotNullParameter(want, "want");
                int i = intValue * 5;
                boolean z = false;
                int i2 = 0;
                while (true) {
                    if (i2 < i && !((Boolean) ((Function0) this.f$0).invoke()).booleanValue()) {
                        Remote remote = ((MainActivity) this.f$1).basic;
                        Remote remote2 = (Remote) this.f$2;
                        if (remote == remote2) {
                            if (Intrinsics.areEqual(remote2.getApp(), want)) {
                                z = true;
                            } else {
                                Thread.sleep(200L);
                                i2++;
                            }
                        }
                    }
                }
                return Boolean.valueOf(z);
            case 1:
                int intValue2 = ((Integer) obj).intValue();
                Function1 extra = (Function1) obj2;
                Intrinsics.checkNotNullParameter(extra, "extra");
                Context context = (Context) this.f$0;
                Intent addFlags = new Intent(context, (Class<?>) SceneActivity.class).addFlags(268435456);
                Intrinsics.checkNotNullExpressionValue(addFlags, "addFlags(...)");
                Intent intent = (Intent) extra.invoke(addFlags);
                Ref$IntRef ref$IntRef = (Ref$IntRef) this.f$2;
                int i3 = ref$IntRef.element + 1;
                ref$IntRef.element = i3;
                ((RemoteViews) this.f$1).setOnClickPendingIntent(intValue2, PendingIntent.getActivity(context, i3, intent, 201326592));
                return Unit.INSTANCE;
            default:
                AdbLink link = (AdbLink) obj;
                Part p = (Part) obj2;
                Intrinsics.checkNotNullParameter(link, "link");
                Intrinsics.checkNotNullParameter(p, "p");
                Adb adb = link.get();
                File cacheDir = ((MainActivity) this.f$1).getCacheDir();
                Intrinsics.checkNotNullExpressionValue(cacheDir, "getCacheDir(...)");
                new LauncherInstall(adb, cacheDir, (Launchers.Gallery) this.f$0, "en").run((Launchers.Entry) this.f$2, 0, new AdbLink$$ExternalSyntheticLambda2(4, p), new Setup$$ExternalSyntheticLambda5(9, p));
                return StringsKt.removePrefix(Fleet.T("fleet.step_lkept", new Pair[0]), "✓ ");
        }
    }

    public /* synthetic */ AdbHelpKt$$ExternalSyntheticLambda69(Object obj, Object obj2, Object obj3, int i) {
        this.$r8$classId = i;
        this.f$0 = obj;
        this.f$1 = obj2;
        this.f$2 = obj3;
    }
}
