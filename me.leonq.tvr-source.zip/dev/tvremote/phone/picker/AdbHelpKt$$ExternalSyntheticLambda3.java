package dev.tvremote.phone.picker;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.os.Build;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.manage.Jobs$$ExternalSyntheticLambda0;
import dev.tvremote.core.ontv.Launchers;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.core.remote.Vidaa$$ExternalSyntheticLambda3;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda5;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda10;
import dev.tvremote.phone.media.MediaKt$$ExternalSyntheticLambda10;
import dev.tvremote.phone.remote.TypingKt;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.phone.ui.UiKt;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.TypeIntrinsics;
import kotlin.jvm.internal.markers.KMappedMarker;
import kotlin.jvm.internal.markers.KMutableCollection;
import kotlin.math.MathKt;
import kotlin.text.Regex$$ExternalSyntheticLambda0;
import kotlin.text.StringsKt;
import org.conscrypt.FileClientSessionCache;
import org.conscrypt.metrics.ConscryptStatsLog;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class AdbHelpKt$$ExternalSyntheticLambda3 implements Function0 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ AdbHelpKt$$ExternalSyntheticLambda3(MainActivity mainActivity, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
    }

    /* JADX WARN: Can't wrap try/catch for region: R(8:18|(4:34|35|26|27)|22|(4:30|31|26|27)|24|25|26|27) */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x010c, code lost:
    
        android.widget.Toast.makeText(r0, dev.tvremote.core.Fleet.T("drawing.this_phone_has_no", new kotlin.Pair[0]), 1).show();
     */
    /* JADX WARN: Type inference failed for: r3v5, types: [kotlin.jvm.internal.Ref$BooleanRef, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r6v8, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    @Override // kotlin.jvm.functions.Function0
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object invoke() {
        InputStream open;
        int i = 3;
        int i2 = 1;
        switch (this.$r8$classId) {
            case 0:
                MainActivity mainActivity = this.f$0;
                AdbHelpKt.wirelessPair(mainActivity, mainActivity.host);
                return Unit.INSTANCE;
            case 1:
                MainActivity mainActivity2 = this.f$0;
                Remote remote = mainActivity2.basic;
                if (remote != null) {
                    AdbHelpKt.tvJob(mainActivity2, new AdbHelpKt$$ExternalSyntheticLambda18(mainActivity2, remote, i));
                }
                return Unit.INSTANCE;
            case 2:
                MainActivity mainActivity3 = this.f$0;
                Object systemService = mainActivity3.getSystemService("clipboard");
                Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.content.ClipboardManager");
                ((ClipboardManager) systemService).setPrimaryClip(ClipData.newPlainText("tv-setup", "github.com/hoangtran0410/tv-remote/releases/latest/download/tv-setup.apk"));
                Toast.makeText(mainActivity3, Fleet.T("health.copied", new Pair[0]), 0).show();
                return Unit.INSTANCE;
            case 3:
                MainActivity mainActivity4 = this.f$0;
                String str = mainActivity4.host;
                HashSet hashSet = mainActivity4.adbFailed;
                if ((hashSet instanceof KMappedMarker) && !(hashSet instanceof KMutableCollection)) {
                    TypeIntrinsics.throwCce(hashSet, "kotlin.collections.MutableCollection");
                    throw null;
                }
                hashSet.remove(str);
                String str2 = mainActivity4.entry;
                mainActivity4.disconnect$android_release(null);
                if (str != null) {
                    mainActivity4.connect$android_release(str, str2);
                }
                return Unit.INSTANCE;
            case 4:
                Remote remote2 = this.f$0.basic;
                if (remote2 != null) {
                    remote2.launch("https://play.google.com/store/apps");
                }
                return Unit.INSTANCE;
            case 5:
                MainActivity mainActivity5 = this.f$0;
                EditText input = UiKt.input(mainActivity5, "com.example.app");
                FrameLayout inDialog = UiKt.inDialog(mainActivity5, input);
                Popup.Builder builder = new Popup.Builder(mainActivity5);
                builder.title = Fleet.T("setup.pkg_ask", new Pair[0]);
                builder.view = inDialog;
                builder.setPositiveButton(Fleet.T("apps.open", new Pair[0]), new MediaKt$$ExternalSyntheticLambda10(2, input, mainActivity5));
                builder.setNegativeButton(Fleet.T("common.cancel", new Pair[0]), null);
                builder.show();
                return Unit.INSTANCE;
            case 6:
                MainActivity mainActivity6 = this.f$0;
                Remote remote3 = mainActivity6.basic;
                if (remote3 != null && AdbHelpKt.tvFree(mainActivity6)) {
                    ?? obj = new Object();
                    Popup.Builder builder2 = new Popup.Builder(mainActivity6);
                    builder2.title = Fleet.T("setup.direct_title", new Pair[0]);
                    builder2.message = Fleet.T("setup.sending_link", new Pair[0]);
                    builder2.setPositiveButton(Fleet.T("adb_help.installed", new Pair[0]), new ManyTvsKt$$ExternalSyntheticLambda6((Object) obj, mainActivity6, remote3, i2));
                    builder2.setNeutralButton(Fleet.T("adb_help.other_ways", new Pair[0]), new MediaKt$$ExternalSyntheticLambda10(i, obj, mainActivity6));
                    builder2.setNegativeButton(Fleet.T("common.close", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda12(obj, 1));
                    builder2.onCancel = new AdbHelpKt$$ExternalSyntheticLambda13(1, obj);
                    Popup show = builder2.show();
                    show.setCanceledOnTouchOutside(false);
                    new Thread(new Vidaa$$ExternalSyntheticLambda3(remote3, (Object) obj, mainActivity6, show, 5)).start();
                    ?? obj2 = new Object();
                    Jobs$$ExternalSyntheticLambda0 jobs$$ExternalSyntheticLambda0 = new Jobs$$ExternalSyntheticLambda0(obj, show, mainActivity6, remote3, obj2, 4);
                    obj2.element = jobs$$ExternalSyntheticLambda0;
                    mainActivity6.ui.postDelayed(jobs$$ExternalSyntheticLambda0, 60000L);
                }
                return Unit.INSTANCE;
            case 7:
                MainActivity mainActivity7 = this.f$0;
                try {
                    mainActivity7.startActivityForResult(new Intent("android.intent.action.GET_CONTENT").setType("*/*").addCategory("android.intent.category.OPENABLE").putExtra("android.intent.extra.MIME_TYPES", new String[]{"application/vnd.android.package-archive", "application/octet-stream", "application/zip", "application/x-zip-compressed", "application/vnd.xapk"}), mainActivity7.PICK_FLEET);
                } catch (Exception unused) {
                    ManyTvsKt.toast(mainActivity7, Fleet.T("media.this_phone_has_no", new Pair[0]));
                }
                return Unit.INSTANCE;
            case 8:
                MainActivity mainActivity8 = this.f$0;
                try {
                    mainActivity8.startActivityForResult(new Intent("android.intent.action.GET_CONTENT").setType("*/*").addCategory("android.intent.category.OPENABLE").putExtra("android.intent.extra.MIME_TYPES", new String[]{"video/*", "image/*"}), mainActivity8.PICK_FLEET_WELCOME);
                } catch (Exception unused2) {
                    ManyTvsKt.toast(mainActivity8, Fleet.T("media.this_phone_has_no", new Pair[0]));
                }
                return Unit.INSTANCE;
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                String T = Fleet.T("fleet.ask_welcome_off", new Pair[0]);
                MainActivity mainActivity9 = this.f$0;
                ManyTvsKt.fleetPick(mainActivity9, T, new MainActivity$$ExternalSyntheticLambda10(mainActivity9, 4));
                return Unit.INSTANCE;
            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                String T2 = Fleet.T("many_tvs.remove_apps_on_which", new Pair[0]);
                MainActivity mainActivity10 = this.f$0;
                ManyTvsKt.fleetPick(mainActivity10, T2, new MainActivity$$ExternalSyntheticLambda10(mainActivity10, 6));
                return Unit.INSTANCE;
            case 11:
                MainActivity mainActivity11 = this.f$0;
                List list = Launchers.KEYS;
                Launchers.useTestFile(mainActivity11.getExternalFilesDir(null));
                Launchers.dir = new File(mainActivity11.getCacheDir(), "launchers");
                Popup.Builder builder3 = new Popup.Builder(mainActivity11);
                builder3.message = Fleet.T("launcher.loading", new Pair[0]);
                builder3.cancelable = false;
                new Thread(new Guard$$ExternalSyntheticLambda5(27, mainActivity11, builder3.show())).start();
                return Unit.INSTANCE;
            case FileClientSessionCache.MAX_SIZE /* 12 */:
                String T3 = Fleet.T("many_tvs.restart_which_tvs", new Pair[0]);
                MainActivity mainActivity12 = this.f$0;
                ManyTvsKt.fleetPick(mainActivity12, T3, new MainActivity$$ExternalSyntheticLambda10(mainActivity12, i));
                return Unit.INSTANCE;
            case 13:
                String T4 = Fleet.T("fleet.menu_checkout", new Pair[0]);
                MainActivity mainActivity13 = this.f$0;
                ManyTvsKt.fleetPick(mainActivity13, T4, new MainActivity$$ExternalSyntheticLambda10(mainActivity13, 5));
                return Unit.INSTANCE;
            case 14:
                open = this.f$0.getAssets().open("tvr-helper.jar");
                try {
                    Intrinsics.checkNotNull(open);
                    byte[] readBytes = MathKt.readBytes(open);
                    MathKt.closeFinally(open, null);
                    return readBytes;
                } finally {
                    try {
                        throw th;
                    } finally {
                    }
                }
            case 15:
                open = this.f$0.getAssets().open("tvr-helper.jar");
                try {
                    Intrinsics.checkNotNull(open);
                    byte[] readBytes2 = MathKt.readBytes(open);
                    MathKt.closeFinally(open, null);
                    return readBytes2;
                } finally {
                }
            case 16:
                MainActivity mainActivity14 = this.f$0;
                Intent type = new Intent("android.provider.action.PICK_IMAGES").setType("image/*");
                Intrinsics.checkNotNullExpressionValue(type, "setType(...)");
                int i3 = Build.VERSION.SDK_INT;
                int i4 = mainActivity14.PICK_DRAW;
                if (i3 >= 33 || type.resolveActivity(mainActivity14.getPackageManager()) != null) {
                    try {
                        mainActivity14.startActivityForResult(type, i4);
                    } catch (Exception unused3) {
                    }
                    return Unit.INSTANCE;
                }
                Intent type2 = new Intent("androidx.activity.result.contract.action.PICK_IMAGES").setType("image/*");
                Intrinsics.checkNotNullExpressionValue(type2, "setType(...)");
                if (type2.resolveActivity(mainActivity14.getPackageManager()) != null) {
                    try {
                        mainActivity14.startActivityForResult(type2, i4);
                    } catch (Exception unused4) {
                    }
                    return Unit.INSTANCE;
                }
                mainActivity14.startActivityForResult(new Intent("android.intent.action.GET_CONTENT").setType("image/*").addCategory("android.intent.category.OPENABLE"), i4);
                return Unit.INSTANCE;
            case 17:
                String T5 = Fleet.T("draw.message_for_tv", new Pair[0]);
                String T6 = Fleet.T("drawing.e_g_dinner_s", new Pair[0]);
                String T7 = Fleet.T("draw.next", new Pair[0]);
                MainActivity mainActivity15 = this.f$0;
                Fleet.askText(mainActivity15, T5, T6, T7, "", new MainActivity$$ExternalSyntheticLambda10(mainActivity15, 11));
                return Unit.INSTANCE;
            case 18:
                TypingKt.gamesPointerOpen(this.f$0);
                return Unit.INSTANCE;
            case 19:
                TypingKt.opens(178, this.f$0);
                return Unit.INSTANCE;
            case 20:
                Fleet.web(this.f$0, "https://tvremote.pages.dev/guide#tracking-other");
                return Unit.INSTANCE;
            default:
                MainActivity mainActivity16 = this.f$0;
                ArrayList list2 = MathKt.list(mainActivity16);
                ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(list2));
                Iterator it = list2.iterator();
                while (it.hasNext()) {
                    JSONObject jSONObject = (JSONObject) it.next();
                    arrayList.add(new Triple(StringsKt.trim(jSONObject.optString("icon") + "  " + jSONObject.optString("name")).toString(), "", new Regex$$ExternalSyntheticLambda0(19, mainActivity16, jSONObject)));
                }
                return arrayList;
        }
    }
}
