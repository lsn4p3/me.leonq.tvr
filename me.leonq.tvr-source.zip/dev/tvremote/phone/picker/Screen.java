package dev.tvremote.phone.picker;

import android.view.View;
import android.widget.FrameLayout;

/* loaded from: classes.dex */
public final class Screen extends FrameLayout {
    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i, int i2) {
        super.onMeasure(i, View.MeasureSpec.makeMeasureSpec((View.MeasureSpec.getSize(i) * 9) / 16, 1073741824));
    }
}
