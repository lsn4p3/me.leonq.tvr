package dev.tvremote.phone.picker;

import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class SetupNews {
    public final long at;
    public final String from;
    public final String home;
    public final String homeLatest;
    public final String installed;
    public final String latest;
    public final boolean missing;
    public final String state;
    public final String version;

    public SetupNews(String str, String latest, String str2, long j, String str3, String str4, String str5, String str6, boolean z) {
        Intrinsics.checkNotNullParameter(latest, "latest");
        this.installed = str;
        this.latest = latest;
        this.state = str2;
        this.at = j;
        this.version = str3;
        this.from = str4;
        this.home = str5;
        this.homeLatest = str6;
        this.missing = z;
    }
}
