package dev.tvremote.phone.picker;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.manage.FilesApi$$ExternalSyntheticLambda4;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.ui.UiKt;
import java.io.File;
import java.util.List;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$ObjectRef;

/* loaded from: classes.dex */
public final /* synthetic */ class ManyTvsKt$$ExternalSyntheticLambda10 implements Runnable {
    public final /* synthetic */ int $r8$classId = 1;
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ boolean f$1;
    public final /* synthetic */ Ref$ObjectRef f$2;
    public final /* synthetic */ File f$3;

    public /* synthetic */ ManyTvsKt$$ExternalSyntheticLambda10(MainActivity mainActivity, boolean z, File file, Ref$ObjectRef ref$ObjectRef) {
        this.f$0 = mainActivity;
        this.f$1 = z;
        this.f$3 = file;
        this.f$2 = ref$ObjectRef;
    }

    @Override // java.lang.Runnable
    public final void run() {
        final Ref$ObjectRef ref$ObjectRef = this.f$2;
        final File file = this.f$3;
        boolean z = this.f$1;
        final MainActivity mainActivity = this.f$0;
        final int i = 1;
        final int i2 = 0;
        switch (this.$r8$classId) {
            case 0:
                if (!mainActivity.isFinishing()) {
                    if (!z) {
                        ManyTvsKt.toast(mainActivity, Fleet.T("many_tvs.could_not_read_this", new Pair[0]));
                        return;
                    } else {
                        ManyTvsKt.fleetPick(mainActivity, Fleet.T("many_tvs.install_on_which_tvs", new Pair("name", ref$ObjectRef.element)), new Function1() { // from class: dev.tvremote.phone.picker.ManyTvsKt$$ExternalSyntheticLambda13
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj) {
                                int i3 = 1;
                                switch (i2) {
                                    case 0:
                                        List ips = (List) obj;
                                        Intrinsics.checkNotNullParameter(ips, "ips");
                                        String T = Fleet.T("many_tvs.install", new Pair("name", ref$ObjectRef.element));
                                        File file2 = file;
                                        MainActivity mainActivity2 = mainActivity;
                                        ManyTvsKt.fleetRun$default(mainActivity2, T, ips, new FilesApi$$ExternalSyntheticLambda4(i3, file2, mainActivity2), 8);
                                        return Unit.INSTANCE;
                                    default:
                                        final List ips2 = (List) obj;
                                        Intrinsics.checkNotNullParameter(ips2, "ips");
                                        String T2 = Fleet.T("welcome.when", new Pair[0]);
                                        String m = ApkSigner$$ExternalSyntheticOutline0.m("@power|", Fleet.T("welcome.every", new Pair[0]));
                                        final MainActivity mainActivity3 = mainActivity;
                                        final Ref$ObjectRef ref$ObjectRef2 = ref$ObjectRef;
                                        final File file3 = file;
                                        final int i4 = 0;
                                        Triple triple = new Triple(m, "", new Function0() { // from class: dev.tvremote.phone.picker.ManyTvsKt$$ExternalSyntheticLambda23
                                            @Override // kotlin.jvm.functions.Function0
                                            public final Object invoke() {
                                                switch (i4) {
                                                    case 0:
                                                        ManyTvsKt.fleetWelcomeRun(mainActivity3, (String) ref$ObjectRef2.element, file3, ips2, "every");
                                                        return Unit.INSTANCE;
                                                    default:
                                                        ManyTvsKt.fleetWelcomeRun(mainActivity3, (String) ref$ObjectRef2.element, file3, ips2, "boot");
                                                        return Unit.INSTANCE;
                                                }
                                            }
                                        });
                                        final int i5 = 1;
                                        UiKt.menu(mainActivity3, T2, 0, ArraysKt.asList(new Triple[]{triple, new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@refresh|", Fleet.T("welcome.boot", new Pair[0])), "", new Function0() { // from class: dev.tvremote.phone.picker.ManyTvsKt$$ExternalSyntheticLambda23
                                            @Override // kotlin.jvm.functions.Function0
                                            public final Object invoke() {
                                                switch (i5) {
                                                    case 0:
                                                        ManyTvsKt.fleetWelcomeRun(mainActivity3, (String) ref$ObjectRef2.element, file3, ips2, "every");
                                                        return Unit.INSTANCE;
                                                    default:
                                                        ManyTvsKt.fleetWelcomeRun(mainActivity3, (String) ref$ObjectRef2.element, file3, ips2, "boot");
                                                        return Unit.INSTANCE;
                                                }
                                            }
                                        })}));
                                        return Unit.INSTANCE;
                                }
                            }
                        });
                        return;
                    }
                }
                return;
            default:
                if (!mainActivity.isFinishing()) {
                    if (!z) {
                        ManyTvsKt.toast(mainActivity, Fleet.T("many_tvs.could_not_read_this", new Pair[0]));
                        return;
                    } else if (file.length() > 209715200) {
                        file.delete();
                        ManyTvsKt.toast(mainActivity, Fleet.T("core.fr_welcome_toobig", new Pair("max", "200 MB")));
                        return;
                    } else {
                        ManyTvsKt.fleetPick(mainActivity, Fleet.T("welcome.title", new Pair[0]), new Function1() { // from class: dev.tvremote.phone.picker.ManyTvsKt$$ExternalSyntheticLambda13
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj) {
                                int i3 = 1;
                                switch (i) {
                                    case 0:
                                        List ips = (List) obj;
                                        Intrinsics.checkNotNullParameter(ips, "ips");
                                        String T = Fleet.T("many_tvs.install", new Pair("name", ref$ObjectRef.element));
                                        File file2 = file;
                                        MainActivity mainActivity2 = mainActivity;
                                        ManyTvsKt.fleetRun$default(mainActivity2, T, ips, new FilesApi$$ExternalSyntheticLambda4(i3, file2, mainActivity2), 8);
                                        return Unit.INSTANCE;
                                    default:
                                        final List ips2 = (List) obj;
                                        Intrinsics.checkNotNullParameter(ips2, "ips");
                                        String T2 = Fleet.T("welcome.when", new Pair[0]);
                                        String m = ApkSigner$$ExternalSyntheticOutline0.m("@power|", Fleet.T("welcome.every", new Pair[0]));
                                        final MainActivity mainActivity3 = mainActivity;
                                        final Ref$ObjectRef ref$ObjectRef2 = ref$ObjectRef;
                                        final File file3 = file;
                                        final int i4 = 0;
                                        Triple triple = new Triple(m, "", new Function0() { // from class: dev.tvremote.phone.picker.ManyTvsKt$$ExternalSyntheticLambda23
                                            @Override // kotlin.jvm.functions.Function0
                                            public final Object invoke() {
                                                switch (i4) {
                                                    case 0:
                                                        ManyTvsKt.fleetWelcomeRun(mainActivity3, (String) ref$ObjectRef2.element, file3, ips2, "every");
                                                        return Unit.INSTANCE;
                                                    default:
                                                        ManyTvsKt.fleetWelcomeRun(mainActivity3, (String) ref$ObjectRef2.element, file3, ips2, "boot");
                                                        return Unit.INSTANCE;
                                                }
                                            }
                                        });
                                        final int i5 = 1;
                                        UiKt.menu(mainActivity3, T2, 0, ArraysKt.asList(new Triple[]{triple, new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@refresh|", Fleet.T("welcome.boot", new Pair[0])), "", new Function0() { // from class: dev.tvremote.phone.picker.ManyTvsKt$$ExternalSyntheticLambda23
                                            @Override // kotlin.jvm.functions.Function0
                                            public final Object invoke() {
                                                switch (i5) {
                                                    case 0:
                                                        ManyTvsKt.fleetWelcomeRun(mainActivity3, (String) ref$ObjectRef2.element, file3, ips2, "every");
                                                        return Unit.INSTANCE;
                                                    default:
                                                        ManyTvsKt.fleetWelcomeRun(mainActivity3, (String) ref$ObjectRef2.element, file3, ips2, "boot");
                                                        return Unit.INSTANCE;
                                                }
                                            }
                                        })}));
                                        return Unit.INSTANCE;
                                }
                            }
                        });
                        return;
                    }
                }
                return;
        }
    }

    public /* synthetic */ ManyTvsKt$$ExternalSyntheticLambda10(MainActivity mainActivity, boolean z, Ref$ObjectRef ref$ObjectRef, File file) {
        this.f$0 = mainActivity;
        this.f$1 = z;
        this.f$2 = ref$ObjectRef;
        this.f$3 = file;
    }
}
