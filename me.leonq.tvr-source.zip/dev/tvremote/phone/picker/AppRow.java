package dev.tvremote.phone.picker;

import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import java.util.List;
import java.util.Locale;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class AppRow {
    public ImageView image;
    public final String key;
    public TextView letter;
    public final String name;
    public final boolean named;
    public final List on;
    public boolean picked;
    public final String pkg;
    public CheckBox tick;
    public TextView title;
    public LinearLayout view;

    public AppRow(String pkg, String str, List on, boolean z) {
        Intrinsics.checkNotNullParameter(pkg, "pkg");
        Intrinsics.checkNotNullParameter(on, "on");
        this.pkg = pkg;
        this.name = str;
        this.on = on;
        this.named = z;
        String lowerCase = Census$$ExternalSyntheticOutline0.m(str, " ", pkg).toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        this.key = lowerCase;
    }

    public final ImageView getImage() {
        ImageView imageView = this.image;
        if (imageView != null) {
            return imageView;
        }
        Intrinsics.throwUninitializedPropertyAccessException("image");
        throw null;
    }

    public final TextView getLetter() {
        TextView textView = this.letter;
        if (textView != null) {
            return textView;
        }
        Intrinsics.throwUninitializedPropertyAccessException("letter");
        throw null;
    }

    public final TextView getTitle() {
        TextView textView = this.title;
        if (textView != null) {
            return textView;
        }
        Intrinsics.throwUninitializedPropertyAccessException("title");
        throw null;
    }
}
