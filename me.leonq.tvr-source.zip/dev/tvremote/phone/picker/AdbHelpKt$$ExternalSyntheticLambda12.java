package dev.tvremote.phone.picker;

import android.content.DialogInterface;
import kotlin.jvm.internal.Ref$BooleanRef;

/* loaded from: classes.dex */
public final /* synthetic */ class AdbHelpKt$$ExternalSyntheticLambda12 implements DialogInterface.OnClickListener {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Ref$BooleanRef f$0;

    public /* synthetic */ AdbHelpKt$$ExternalSyntheticLambda12(Ref$BooleanRef ref$BooleanRef, int i) {
        this.$r8$classId = i;
        this.f$0 = ref$BooleanRef;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i) {
        switch (this.$r8$classId) {
            case 0:
                this.f$0.element = true;
                return;
            default:
                this.f$0.element = true;
                return;
        }
    }
}
