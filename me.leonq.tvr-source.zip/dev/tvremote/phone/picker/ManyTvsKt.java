package dev.tvremote.phone.picker;

import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.manage.Manage;
import dev.tvremote.core.ontv.Checkout;
import dev.tvremote.core.ontv.Games;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda9;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.manage.UpdaterKt$$ExternalSyntheticLambda10;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.phone.ui.UiKt;
import dev.tvremote.tvapps.ApkCert$$ExternalSyntheticLambda0;
import dev.tvremote.tvui.Marks;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyMap;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.StringsKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public abstract class ManyTvsKt {
    public static Object checkoutNames = EmptyMap.INSTANCE;

    public static final String checkoutLine(Checkout.Result result) {
        String T;
        String str;
        String T2;
        ArrayList arrayList = result.failed;
        int i = result.cleared;
        String str2 = null;
        if (i <= 0 && !arrayList.isEmpty()) {
            T = null;
        } else {
            T = Fleet.T("fleet.co_cleared", new Pair("n", Integer.valueOf(i)));
        }
        if (!arrayList.isEmpty()) {
            str = Fleet.T("fleet.co_failed", new Pair("n", Integer.valueOf(arrayList.size())));
        } else {
            str = null;
        }
        String T3 = Fleet.T("fleet.co_vol", new Pair("v", Integer.valueOf(result.volume)));
        String str3 = result.web;
        int hashCode = str3.hashCode();
        if (hashCode != 3548) {
            if (hashCode != 110119) {
                if (hashCode == 1069449574 && str3.equals("missing")) {
                    T2 = Fleet.T("fleet.co_web_missing", new Pair[0]);
                }
                T2 = Fleet.T("fleet.co_web_failed", new Pair[0]);
            } else {
                if (str3.equals("old")) {
                    T2 = Fleet.T("fleet.co_web_old", new Pair[0]);
                }
                T2 = Fleet.T("fleet.co_web_failed", new Pair[0]);
            }
        } else {
            if (str3.equals("ok")) {
                int i2 = result.forgot;
                if (i2 > 0) {
                    T2 = Fleet.T("fleet.co_web_ok", new Pair("n", Integer.valueOf(i2)));
                } else {
                    T2 = Fleet.T("fleet.co_web_0", new Pair[0]);
                }
            }
            T2 = Fleet.T("fleet.co_web_failed", new Pair[0]);
        }
        if (result.home) {
            str2 = Fleet.T("fleet.co_home", new Pair[0]);
        }
        String[] strArr = {T, str, T3, T2, str2};
        ArrayList arrayList2 = new ArrayList();
        for (int i3 = 0; i3 < 5; i3++) {
            String str4 = strArr[i3];
            if (str4 != null) {
                arrayList2.add(str4);
            }
        }
        return CollectionsKt.joinToString$default(arrayList2, " · ", null, null, null, 62);
    }

    public static final ImageView checkoutReport$glyph(MainActivity mainActivity, String str, int i, int i2) {
        ImageView imageView = new ImageView(mainActivity);
        imageView.setImageResource(imageView.getResources().getIdentifier(ApkSigner$$ExternalSyntheticOutline0.m("ic_", str), "drawable", mainActivity.getPackageName()));
        imageView.setImageTintList(ColorStateList.valueOf(i));
        float f = i2;
        imageView.setLayoutParams(new LinearLayout.LayoutParams(UiKt.dp(mainActivity, f), UiKt.dp(mainActivity, f)));
        return imageView;
    }

    public static final void fleetPick(MainActivity mainActivity, String str, Function1 function1) {
        HashMap hashMap;
        String str2;
        ArrayList savedIps = PickerScreenKt.savedIps(mainActivity);
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(savedIps));
        Iterator it = savedIps.iterator();
        while (true) {
            boolean hasNext = it.hasNext();
            hashMap = mainActivity.reach;
            if (!hasNext) {
                break;
            }
            String str3 = (String) it.next();
            String title$android_release = mainActivity.title$android_release(str3);
            if (Intrinsics.areEqual(hashMap.get(str3), Boolean.FALSE)) {
                str2 = Fleet.T("many_tvs.no_answer", new Pair[0]);
            } else {
                str2 = "";
            }
            arrayList.add(title$android_release + str2);
        }
        String[] strArr = (String[]) arrayList.toArray(new String[0]);
        int size = savedIps.size();
        boolean[] zArr = new boolean[size];
        for (int i = 0; i < size; i++) {
            zArr[i] = !Intrinsics.areEqual(hashMap.get(savedIps.get(i)), Boolean.FALSE);
        }
        Popup.Builder builder = new Popup.Builder(mainActivity);
        builder.title = str;
        String[] items = strArr;
        ManyTvsKt$$ExternalSyntheticLambda25 manyTvsKt$$ExternalSyntheticLambda25 = new ManyTvsKt$$ExternalSyntheticLambda25(zArr, 0);
        Intrinsics.checkNotNullParameter(items, "items");
        builder.choices = new Triple(items, zArr, manyTvsKt$$ExternalSyntheticLambda25);
        builder.setPositiveButton(Fleet.T("draw.next", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda9(savedIps, mainActivity, function1, zArr));
        builder.setNegativeButton(Fleet.T("common.cancel", new Pair[0]), null);
        builder.show();
    }

    public static void fleetRun$default(final MainActivity mainActivity, String str, List list, Function2 function2, int i) {
        boolean z;
        final boolean z2;
        String T;
        if ((i & 4) != 0) {
            z = false;
        } else {
            z = true;
        }
        if ((i & 8) != 0) {
            z2 = false;
        } else {
            z2 = true;
        }
        final LinearLayout col = UiKt.col(mainActivity);
        float f = 20;
        float f2 = 8;
        col.setPadding(UiKt.dp(mainActivity, f), UiKt.dp(mainActivity, f2), UiKt.dp(mainActivity, f), UiKt.dp(mainActivity, f2));
        final ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(list));
        Iterator it = list.iterator();
        while (it.hasNext()) {
            String str2 = (String) it.next();
            TextView label = UiKt.label(mainActivity, mainActivity.title$android_release(str2), 16, UiKt.TEXT);
            label.setTypeface(Typeface.DEFAULT_BOLD);
            TextView label2 = UiKt.label(mainActivity, "", 14, UiKt.MUTED);
            col.addView(label, UiKt.gap(mainActivity, 10));
            col.addView(label2);
            Part part = new Part(label2, str2);
            part.setStep(Fleet.T("fleet.step_waiting", new Pair[0]));
            arrayList.add(part);
        }
        ScrollView scrollView = new ScrollView(mainActivity);
        scrollView.addView(col);
        Popup.Builder builder = new Popup.Builder(mainActivity);
        builder.title = str;
        builder.view = scrollView;
        if (z2) {
            T = Fleet.T("fleet.co_r_done", new Pair[0]);
        } else {
            T = Fleet.T("common.close", new Pair[0]);
        }
        builder.setPositiveButton(T, null);
        builder.setNeutralButton(Fleet.T("page.stop", new Pair[0]), null);
        final Popup show = builder.show();
        if (z2) {
            show.getButton(-1).setEnabled(false);
        }
        final Button button = show.getButton(-3);
        if (!z) {
            button.setVisibility(8);
        }
        button.setOnClickListener(new Guard$$ExternalSyntheticLambda9(2, arrayList, button));
        ExecutorService newFixedThreadPool = Executors.newFixedThreadPool(3);
        Iterator it2 = arrayList.iterator();
        while (it2.hasNext()) {
            newFixedThreadPool.execute(new UpdaterKt$$ExternalSyntheticLambda10((Part) it2.next(), mainActivity, function2, z2));
        }
        newFixedThreadPool.shutdown();
        mainActivity.ui.post(new Runnable() { // from class: dev.tvremote.phone.picker.ManyTvsKt$fleetRun$tick$1
            /* JADX WARN: Multi-variable type inference failed */
            /* JADX WARN: Type inference failed for: r10v33, types: [java.lang.Object, java.lang.Iterable] */
            /* JADX WARN: Type inference failed for: r3v35, types: [java.util.Collection, java.lang.Object] */
            /* JADX WARN: Type inference failed for: r6v12, types: [java.util.List] */
            /* JADX WARN: Type inference failed for: r6v16, types: [java.util.ArrayList] */
            @Override // java.lang.Runnable
            public final void run() {
                int i2;
                String T2;
                String str3;
                int i3;
                boolean z3;
                String str4;
                int i4;
                int i5;
                String T3;
                int i6;
                String str5;
                int i7;
                String str6;
                int i8;
                Checkout.Result result;
                MainActivity mainActivity2;
                ViewGroup viewGroup;
                Iterator it3;
                ArrayList arrayList2;
                String str7;
                Popup popup;
                Object listOf;
                CoRow coRow;
                int i9;
                String T4;
                int i10;
                String T5;
                int i11;
                String str8;
                int i12 = 1;
                Iterator it4 = arrayList.iterator();
                while (it4.hasNext()) {
                    Part part2 = (Part) it4.next();
                    int optInt = part2.job.optInt("pct", 0);
                    TextView textView = part2.line;
                    int i13 = part2.state;
                    if (i13 != 1) {
                        if (i13 != 2) {
                            i11 = UiKt.MUTED;
                        } else {
                            i11 = UiKt.ERR_TEXT;
                        }
                    } else {
                        i11 = UiKt.OK_TEXT;
                    }
                    textView.setTextColor(i11);
                    TextView textView2 = part2.line;
                    if (part2.state != 0) {
                        str8 = part2.step;
                    } else {
                        AdbLink adbLink = part2.link;
                        if (adbLink != null && adbLink.waiting) {
                            str8 = Fleet.T("many_tvs.the_tv_asks_allow", new Pair[0]);
                        } else if (1 <= optInt && optInt < 90) {
                            str8 = Fleet.T("many_tvs.copying_to_the_tv", new Pair("pct", Integer.valueOf(optInt)));
                        } else if (optInt >= 90) {
                            str8 = Fleet.T("many_tvs.installing", new Pair[0]);
                        } else {
                            str8 = part2.step;
                        }
                    }
                    UiKt.setMarked(textView2, str8);
                }
                ArrayList arrayList3 = arrayList;
                if (!arrayList3.isEmpty()) {
                    Iterator it5 = arrayList3.iterator();
                    while (it5.hasNext()) {
                        if (((Part) it5.next()).state == 0) {
                            if (!mainActivity.isFinishing()) {
                                mainActivity.ui.postDelayed(this, 500L);
                                return;
                            }
                        }
                    }
                }
                ArrayList arrayList4 = arrayList;
                Checkout.Result result2 = null;
                if (arrayList4.isEmpty()) {
                    i2 = 0;
                } else {
                    Iterator it6 = arrayList4.iterator();
                    i2 = 0;
                    while (it6.hasNext()) {
                        if (((Part) it6.next()).state == 2 && (i2 = i2 + 1) < 0) {
                            CollectionsKt__CollectionsKt.throwCountOverflow();
                            throw null;
                        }
                    }
                }
                button.setVisibility(8);
                Popup popup2 = show;
                ArrayList arrayList5 = arrayList;
                String str9 = "bad";
                if (!arrayList5.isEmpty()) {
                    Iterator it7 = arrayList5.iterator();
                    while (it7.hasNext()) {
                        if (((Part) it7.next()).state == 3) {
                            T2 = Fleet.T("files.stopped", new Pair[0]);
                            break;
                        }
                    }
                }
                if (z2) {
                    T2 = Fleet.T("fleet.co_title", new Pair[0]);
                } else if (i2 == 0) {
                    T2 = Fleet.T("many_tvs.done_on_all_tvs", new Pair("n", Integer.valueOf(arrayList.size())));
                } else {
                    T2 = Fleet.T("many_tvs.done_tvs_tvs", new Pair("ok", Integer.valueOf(arrayList.size() - i2)), new Pair("bad", Integer.valueOf(i2)));
                }
                popup2.setTitle(T2);
                if (z2) {
                    ArrayList arrayList6 = arrayList;
                    if (!arrayList6.isEmpty()) {
                        Iterator it8 = arrayList6.iterator();
                        while (it8.hasNext()) {
                            if (((Part) it8.next()).state == 3) {
                            }
                        }
                    }
                    MainActivity mainActivity3 = mainActivity;
                    Popup popup3 = show;
                    ViewGroup viewGroup2 = col;
                    ArrayList arrayList7 = arrayList;
                    ArrayList arrayList8 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList7));
                    Iterator it9 = arrayList7.iterator();
                    while (true) {
                        str3 = "close";
                        if (!it9.hasNext()) {
                            break;
                        }
                        Part part3 = (Part) it9.next();
                        if (part3.state == i12) {
                            result = Games.parse(part3.raw);
                        } else {
                            result = result2;
                        }
                        if (result != null) {
                            ApkCert$$ExternalSyntheticLambda0 apkCert$$ExternalSyntheticLambda0 = new ApkCert$$ExternalSyntheticLambda0(6);
                            listOf = new ArrayList();
                            boolean isEmpty = result.apps.isEmpty();
                            ArrayList arrayList9 = result.failed;
                            it3 = it9;
                            popup = popup3;
                            if (!isEmpty) {
                                viewGroup = viewGroup2;
                                str7 = str9;
                                mainActivity2 = mainActivity3;
                                arrayList2 = arrayList8;
                                listOf.add(new CoRow(0, "eraser", Fleet.T("fleet.co_r_clear", new Pair("apps", CollectionsKt.joinToString$default(result.apps, ", ", null, null, apkCert$$ExternalSyntheticLambda0, 30))), null));
                            } else {
                                mainActivity2 = mainActivity3;
                                viewGroup = viewGroup2;
                                arrayList2 = arrayList8;
                                str7 = str9;
                                int i14 = result.cleared;
                                if (i14 > 0) {
                                    String T6 = Fleet.T("fleet.co_cleared", new Pair("n", Integer.valueOf(i14)));
                                    if (T6.length() > 0) {
                                        StringBuilder sb = new StringBuilder();
                                        String valueOf = String.valueOf(T6.charAt(0));
                                        Intrinsics.checkNotNull(valueOf, "null cannot be cast to non-null type java.lang.String");
                                        String upperCase = valueOf.toUpperCase(Locale.ROOT);
                                        Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
                                        sb.append((Object) upperCase);
                                        String substring = T6.substring(1);
                                        Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
                                        sb.append(substring);
                                        T6 = sb.toString();
                                    }
                                    listOf.add(new CoRow(0, "eraser", T6, null));
                                } else if (arrayList9.isEmpty()) {
                                    listOf.add(new CoRow(0, "eraser", Fleet.T("fleet.co_r_clear_none", new Pair[0]), null));
                                }
                            }
                            if (!arrayList9.isEmpty()) {
                                if (!arrayList9.isEmpty()) {
                                    Iterator it10 = arrayList9.iterator();
                                    while (it10.hasNext()) {
                                        if (Intrinsics.areEqual((String) it10.next(), "?")) {
                                            T5 = Fleet.T("fleet.co_failed", new Pair("n", Integer.valueOf(arrayList9.size())));
                                            if (T5.length() > 0) {
                                                StringBuilder sb2 = new StringBuilder();
                                                String valueOf2 = String.valueOf(T5.charAt(0));
                                                Intrinsics.checkNotNull(valueOf2, "null cannot be cast to non-null type java.lang.String");
                                                String upperCase2 = valueOf2.toUpperCase(Locale.ROOT);
                                                Intrinsics.checkNotNullExpressionValue(upperCase2, "toUpperCase(...)");
                                                sb2.append((Object) upperCase2);
                                                String substring2 = T5.substring(1);
                                                Intrinsics.checkNotNullExpressionValue(substring2, "substring(...)");
                                                sb2.append(substring2);
                                                T5 = sb2.toString();
                                            }
                                            listOf.add(new CoRow(2, "eraser", T5, null));
                                        }
                                    }
                                }
                                T5 = Fleet.T("fleet.co_r_failed", new Pair("apps", CollectionsKt.joinToString$default(result.failed, ", ", null, null, apkCert$$ExternalSyntheticLambda0, 30)));
                                listOf.add(new CoRow(2, "eraser", T5, null));
                            }
                            listOf.add(new CoRow(0, "vol_up", Fleet.T("fleet.co_r_vol", new Pair("v", Integer.valueOf(result.volume))), null));
                            String str10 = result.web;
                            int hashCode = str10.hashCode();
                            if (hashCode != 3548) {
                                if (hashCode != 110119) {
                                    if (hashCode == 1069449574 && str10.equals("missing")) {
                                        coRow = new CoRow(1, "globe", Fleet.T("fleet.co_r_web_missing", new Pair[0]), "install");
                                    }
                                    i10 = 0;
                                    coRow = new CoRow(1, "globe", Fleet.T("fleet.co_r_web_failed", new Pair[i10]), null);
                                } else {
                                    i10 = 0;
                                    if (str10.equals("old")) {
                                        coRow = new CoRow(1, "globe", Fleet.T("fleet.co_r_web_old", new Pair[0]), "update");
                                    }
                                    coRow = new CoRow(1, "globe", Fleet.T("fleet.co_r_web_failed", new Pair[i10]), null);
                                }
                            } else {
                                if (str10.equals("ok")) {
                                    int i15 = result.forgot;
                                    if (i15 > 0) {
                                        i9 = 0;
                                        T4 = Fleet.T("fleet.co_r_web_ok", new Pair("n", Integer.valueOf(i15)));
                                    } else {
                                        i9 = 0;
                                        T4 = Fleet.T("fleet.co_r_web_0", new Pair[0]);
                                    }
                                    coRow = new CoRow(i9, "globe", T4, null);
                                }
                                i10 = 0;
                                coRow = new CoRow(1, "globe", Fleet.T("fleet.co_r_web_failed", new Pair[i10]), null);
                            }
                            listOf.add(coRow);
                            if (result.home) {
                                listOf.add(new CoRow(0, "home", Fleet.T("fleet.co_r_home", new Pair[0]), null));
                            }
                        } else {
                            mainActivity2 = mainActivity3;
                            viewGroup = viewGroup2;
                            it3 = it9;
                            arrayList2 = arrayList8;
                            str7 = str9;
                            popup = popup3;
                            listOf = MathKt.listOf(new CoRow(2, "close", StringsKt.removePrefix(part3.step, "✗ "), null));
                        }
                        ArrayList arrayList10 = arrayList2;
                        arrayList10.add(new Triple(part3, result, listOf));
                        arrayList8 = arrayList10;
                        str9 = str7;
                        it9 = it3;
                        popup3 = popup;
                        viewGroup2 = viewGroup;
                        mainActivity3 = mainActivity2;
                        i12 = 1;
                        result2 = null;
                    }
                    MainActivity mainActivity4 = mainActivity3;
                    ViewGroup viewGroup3 = viewGroup2;
                    ArrayList arrayList11 = arrayList8;
                    String str11 = str9;
                    Popup popup4 = popup3;
                    if (arrayList11.isEmpty()) {
                        i3 = 0;
                    } else {
                        Iterator it11 = arrayList11.iterator();
                        i3 = 0;
                        while (it11.hasNext()) {
                            if (((Part) ((Triple) it11.next()).first).state == 2 && (i3 = i3 + 1) < 0) {
                                CollectionsKt__CollectionsKt.throwCountOverflow();
                                throw null;
                            }
                        }
                    }
                    if (!arrayList11.isEmpty()) {
                        Iterator it12 = arrayList11.iterator();
                        loop10: while (it12.hasNext()) {
                            Iterable iterable = (Iterable) ((Triple) it12.next()).third;
                            if (!(iterable instanceof Collection) || !((Collection) iterable).isEmpty()) {
                                Iterator it13 = iterable.iterator();
                                while (it13.hasNext()) {
                                    if (((CoRow) it13.next()).state != 0) {
                                        z3 = true;
                                        break loop10;
                                    }
                                }
                            }
                        }
                    }
                    z3 = false;
                    viewGroup3.removeAllViews();
                    MainActivity mainActivity5 = mainActivity4;
                    LinearLayout linearLayout = new LinearLayout(mainActivity5);
                    linearLayout.setGravity(16);
                    FrameLayout frameLayout = new FrameLayout(mainActivity5);
                    frameLayout.setBackground(UiKt.oval(mainActivity5, UiKt.SEL));
                    String str12 = "check";
                    String str13 = "alert";
                    if (!z3) {
                        str4 = "check";
                    } else {
                        str4 = "alert";
                    }
                    if (z3) {
                        if (!z3) {
                            i4 = UiKt.ERR_TEXT;
                        } else {
                            i4 = UiKt.HELD;
                        }
                    } else {
                        i4 = UiKt.OK_TEXT;
                    }
                    float f3 = 24;
                    frameLayout.addView(ManyTvsKt.checkoutReport$glyph(mainActivity5, str4, i4, 24), new FrameLayout.LayoutParams(UiKt.dp(mainActivity5, f3), UiKt.dp(mainActivity5, f3), 17));
                    float f4 = 44;
                    linearLayout.addView(frameLayout, new LinearLayout.LayoutParams(UiKt.dp(mainActivity5, f4), UiKt.dp(mainActivity5, f4)));
                    LinearLayout col2 = UiKt.col(mainActivity5);
                    float f5 = 12;
                    col2.setPadding(UiKt.dp(mainActivity5, f5), 0, 0, 0);
                    TextView label3 = UiKt.label(mainActivity5, Fleet.T("fleet.co_r_title", new Pair("ok", Integer.valueOf(arrayList11.size() - i3)), new Pair("n", Integer.valueOf(arrayList11.size()))), 17, UiKt.TEXT);
                    label3.setTypeface(Typeface.DEFAULT_BOLD);
                    col2.addView(label3);
                    if (z3) {
                        if (arrayList11.isEmpty()) {
                            i8 = 0;
                        } else {
                            Iterator it14 = arrayList11.iterator();
                            i8 = 0;
                            while (it14.hasNext()) {
                                Iterable iterable2 = (Iterable) ((Triple) it14.next()).third;
                                if (!(iterable2 instanceof Collection) || !((Collection) iterable2).isEmpty()) {
                                    Iterator it15 = iterable2.iterator();
                                    while (it15.hasNext()) {
                                        if (((CoRow) it15.next()).state != 0) {
                                            i8++;
                                            if (i8 < 0) {
                                                CollectionsKt__CollectionsKt.throwCountOverflow();
                                                throw null;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        i5 = 0;
                        T3 = Fleet.T("fleet.co_r_sub_bad", new Pair(str11, Integer.valueOf(i8)));
                    } else {
                        i5 = 0;
                        T3 = Fleet.T("fleet.co_r_sub_ok", new Pair[0]);
                    }
                    col2.addView(UiKt.label(mainActivity5, T3, 13, UiKt.MUTED));
                    linearLayout.addView(col2, new LinearLayout.LayoutParams(i5, -2, 1.0f));
                    viewGroup3.addView(linearLayout);
                    Iterator it16 = arrayList11.iterator();
                    while (it16.hasNext()) {
                        Triple triple = (Triple) it16.next();
                        Part part4 = (Part) triple.first;
                        List list2 = (List) triple.third;
                        LinearLayout col3 = UiKt.col(mainActivity5);
                        col3.setBackground(UiKt.box(mainActivity5, UiKt.BTN, 14));
                        float f6 = 14;
                        float f7 = 10;
                        col3.setPadding(UiKt.dp(mainActivity5, f6), UiKt.dp(mainActivity5, f5), UiKt.dp(mainActivity5, f6), UiKt.dp(mainActivity5, f7));
                        TextView label4 = UiKt.label(mainActivity5, mainActivity5.title$android_release(part4.ip), 16, UiKt.TEXT);
                        label4.setTypeface(Typeface.DEFAULT_BOLD);
                        col3.addView(label4);
                        Iterator it17 = list2.iterator();
                        while (it17.hasNext()) {
                            CoRow coRow2 = (CoRow) it17.next();
                            LinearLayout linearLayout2 = new LinearLayout(mainActivity5);
                            linearLayout2.setGravity(48);
                            Iterator it18 = it17;
                            ImageView checkoutReport$glyph = ManyTvsKt.checkoutReport$glyph(mainActivity5, coRow2.icon, UiKt.MUTED, 20);
                            ViewGroup.LayoutParams layoutParams = checkoutReport$glyph.getLayoutParams();
                            Intrinsics.checkNotNull(layoutParams, "null cannot be cast to non-null type android.widget.LinearLayout.LayoutParams");
                            Iterator it19 = it16;
                            String str14 = str12;
                            float f8 = 2;
                            ((LinearLayout.LayoutParams) layoutParams).topMargin = UiKt.dp(mainActivity5, f8);
                            linearLayout2.addView(checkoutReport$glyph);
                            String str15 = coRow2.text;
                            if (coRow2.state == 2) {
                                i6 = UiKt.ERR_TEXT;
                            } else {
                                i6 = UiKt.TEXT;
                            }
                            TextView label5 = UiKt.label(mainActivity5, str15, 14, i6);
                            float f9 = f7;
                            label5.setPadding(UiKt.dp(mainActivity5, f7), 0, UiKt.dp(mainActivity5, 8), 0);
                            String str16 = str13;
                            linearLayout2.addView(label5, new LinearLayout.LayoutParams(0, -2, 1.0f));
                            int i16 = coRow2.state;
                            if (i16 != 0) {
                                if (i16 != 1) {
                                    str5 = str3;
                                } else {
                                    str5 = str16;
                                }
                            } else {
                                str5 = str14;
                            }
                            if (i16 != 0) {
                                if (i16 != 1) {
                                    i7 = UiKt.ERR_TEXT;
                                } else {
                                    i7 = UiKt.HELD;
                                }
                            } else {
                                i7 = UiKt.OK_TEXT;
                            }
                            ImageView checkoutReport$glyph2 = ManyTvsKt.checkoutReport$glyph(mainActivity5, str5, i7, 20);
                            ViewGroup.LayoutParams layoutParams2 = checkoutReport$glyph2.getLayoutParams();
                            Intrinsics.checkNotNull(layoutParams2, "null cannot be cast to non-null type android.widget.LinearLayout.LayoutParams");
                            ((LinearLayout.LayoutParams) layoutParams2).topMargin = UiKt.dp(mainActivity5, f8);
                            linearLayout2.addView(checkoutReport$glyph2);
                            col3.addView(linearLayout2, UiKt.gap(mainActivity5, 8));
                            String str17 = coRow2.fix;
                            if (str17 != null) {
                                if (str17.equals("update")) {
                                    str6 = "fleet.co_r_fix_update";
                                } else {
                                    str6 = "fleet.co_r_fix_install";
                                }
                                View button2 = UiKt.button(mainActivity5, Fleet.T(str6, new Pair[0]), UiKt.CARD);
                                MainActivity mainActivity6 = mainActivity5;
                                Part part5 = part4;
                                Popup popup5 = popup4;
                                button2.setOnClickListener(new ManyTvsKt$$ExternalSyntheticLambda40(popup5, mainActivity6, part5, coRow2, 0));
                                LinearLayout.LayoutParams gap = UiKt.gap(mainActivity6, 8);
                                gap.height = UiKt.dp(mainActivity6, 40);
                                col3.addView(button2, gap);
                                str3 = str3;
                                mainActivity5 = mainActivity6;
                                popup4 = popup5;
                                part4 = part5;
                            }
                            str12 = str14;
                            str13 = str16;
                            it17 = it18;
                            it16 = it19;
                            f7 = f9;
                        }
                        MainActivity mainActivity7 = mainActivity5;
                        viewGroup3.addView(col3, UiKt.gap(mainActivity7, 12));
                        mainActivity5 = mainActivity7;
                        str12 = str12;
                        str13 = str13;
                        it16 = it16;
                    }
                    show.getButton(-1).setEnabled(true);
                }
            }
        });
    }

    public static final void fleetWelcomeRun(final MainActivity mainActivity, final String str, final File file, List list, String str2) {
        final JSONObject put = new JSONObject().put("on", true).put("when", str2).put("seconds", 10);
        fleetRun$default(mainActivity, Fleet.T("welcome.title", new Pair[0]), list, new Function2() { // from class: dev.tvremote.phone.picker.ManyTvsKt$$ExternalSyntheticLambda27
            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(Object obj, Object obj2) {
                MainActivity mainActivity2 = mainActivity;
                String str3 = str;
                JSONObject jSONObject = put;
                AdbLink link = (AdbLink) obj;
                Part p = (Part) obj2;
                Intrinsics.checkNotNullParameter(link, "link");
                Intrinsics.checkNotNullParameter(p, "p");
                File file2 = file;
                FileInputStream fileInputStream = new FileInputStream(file2);
                try {
                    Manage manage = new Manage(link, null, mainActivity2.getCacheDir(), null);
                    long length = file2.length();
                    Intrinsics.checkNotNull(jSONObject);
                    manage.welcomeBulk(fileInputStream, length, str3, jSONObject, p.job, p.cancel);
                    fileInputStream.close();
                    return Fleet.T("fleet.step_welcome_set", new Pair[0]);
                } finally {
                }
            }
        }, 8);
    }

    public static final void toast(MainActivity mainActivity, String str) {
        Toast.makeText(mainActivity, Marks.plain(str), 0).show();
    }
}
