package dev.tvremote.phone.picker;

import android.content.DialogInterface;

/* loaded from: classes.dex */
public final /* synthetic */ class ManyTvsKt$$ExternalSyntheticLambda25 implements DialogInterface.OnMultiChoiceClickListener {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ boolean[] f$0;

    public /* synthetic */ ManyTvsKt$$ExternalSyntheticLambda25(boolean[] zArr, int i) {
        this.$r8$classId = i;
        this.f$0 = zArr;
    }

    @Override // android.content.DialogInterface.OnMultiChoiceClickListener
    public final void onClick(DialogInterface dialogInterface, int i, boolean z) {
        switch (this.$r8$classId) {
            case 0:
                this.f$0[i] = z;
                return;
            default:
                this.f$0[i] = z;
                return;
        }
    }
}
