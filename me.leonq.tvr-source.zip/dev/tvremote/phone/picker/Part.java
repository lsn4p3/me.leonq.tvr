package dev.tvremote.phone.picker;

import android.widget.TextView;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.web.Cancel;
import kotlin.jvm.internal.Intrinsics;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class Part {
    public final String ip;
    public final TextView line;
    public volatile AdbLink link;
    public volatile int state;
    public volatile String step = "";
    public volatile String raw = "";
    public final Cancel cancel = new Cancel();
    public final JSONObject job = new JSONObject();

    public Part(TextView textView, String str) {
        this.ip = str;
        this.line = textView;
    }

    public final void setStep(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.step = str;
    }
}
