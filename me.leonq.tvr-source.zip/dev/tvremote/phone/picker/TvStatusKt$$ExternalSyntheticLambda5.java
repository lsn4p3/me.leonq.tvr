package dev.tvremote.phone.picker;

import android.view.View;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.manage.Managing;
import java.util.HashMap;
import java.util.List;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;

/* loaded from: classes.dex */
public final /* synthetic */ class TvStatusKt$$ExternalSyntheticLambda5 implements View.OnClickListener {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ TvStatusKt$$ExternalSyntheticLambda5(MainActivity mainActivity, String str, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
        this.f$1 = str;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        switch (this.$r8$classId) {
            case 0:
                MainActivity mainActivity = this.f$0;
                mainActivity.getClass();
                String ip = this.f$1;
                Intrinsics.checkNotNullParameter(ip, "ip");
                String str = (String) mainActivity.route.get(ip);
                if (str == null) {
                    str = ip;
                }
                if (str.equals(ip)) {
                    ip = null;
                }
                mainActivity.connect$android_release(str, ip);
                return;
            case 1:
                PickerScreenKt.wake(this.f$0, this.f$1);
                return;
            case 2:
                MainActivity mainActivity2 = this.f$0;
                HashMap hashMap = mainActivity2.setupNews;
                String str2 = this.f$1;
                hashMap.remove(str2);
                mainActivity2.setupChecked.remove(str2);
                MathKt.showSetup(mainActivity2, str2);
                Managing.open$default(mainActivity2.getManaging$android_release(), str2, null, "installSetupApk()", 2);
                return;
            case 3:
                StringBuilder sb = new StringBuilder("tv:none@");
                String str3 = this.f$1;
                sb.append(str3);
                List listOf = MathKt.listOf(sb.toString());
                MainActivity mainActivity3 = this.f$0;
                MathKt.putOff(0, mainActivity3, listOf);
                MathKt.showSetup(mainActivity3, str3);
                return;
            case 4:
                PickerScreenKt.wake(this.f$0, this.f$1);
                return;
            default:
                PickerScreenKt.askRemove(this.f$0, this.f$1);
                return;
        }
    }
}
