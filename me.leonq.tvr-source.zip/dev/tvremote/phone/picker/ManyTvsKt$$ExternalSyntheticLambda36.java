package dev.tvremote.phone.picker;

import dev.tvremote.core.Diagnose;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Words;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.ontv.RemoteLabels;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.media.TalkKt$$ExternalSyntheticLambda4;
import dev.tvremote.phone.ui.Popup;
import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;
import kotlin.collections.EmptyMap;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;

/* loaded from: classes.dex */
public final /* synthetic */ class ManyTvsKt$$ExternalSyntheticLambda36 implements Runnable {
    public final /* synthetic */ int $r8$classId = 0;
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ Object f$1;
    public final /* synthetic */ Serializable f$2;
    public final /* synthetic */ Serializable f$3;
    public final /* synthetic */ Object f$4;
    public final /* synthetic */ Object f$5;
    public final /* synthetic */ Serializable f$6;

    public /* synthetic */ ManyTvsKt$$ExternalSyntheticLambda36(MainActivity mainActivity, String str, HashMap hashMap, HashMap hashMap2, HashMap hashMap3, ArrayList arrayList, HashSet hashSet) {
        this.f$0 = mainActivity;
        this.f$1 = str;
        this.f$2 = hashMap;
        this.f$3 = hashMap2;
        this.f$4 = hashMap3;
        this.f$5 = arrayList;
        this.f$6 = hashSet;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Map map;
        switch (this.$r8$classId) {
            case 0:
                MainActivity mainActivity = this.f$0;
                String input = (String) this.f$1;
                HashMap hashMap = (HashMap) this.f$2;
                HashMap hashMap2 = (HashMap) this.f$3;
                HashMap hashMap3 = (HashMap) this.f$4;
                ArrayList arrayList = (ArrayList) this.f$5;
                HashSet hashSet = (HashSet) this.f$6;
                File filesDir = mainActivity.getFilesDir();
                Intrinsics.checkNotNullExpressionValue(filesDir, "getFilesDir(...)");
                String str = (String) mainActivity.route.get(input);
                if (str == null) {
                    str = input;
                }
                AdbLink adbLink = new AdbLink(filesDir, str);
                try {
                    Fleet.Info info = Fleet.info(adbLink.get());
                    AdbHelpKt$$ExternalSyntheticLambda3 adbHelpKt$$ExternalSyntheticLambda3 = new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity, 15);
                    File cacheDir = mainActivity.getCacheDir();
                    Pattern compile = Pattern.compile("[^\\w.-]");
                    Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                    Intrinsics.checkNotNullParameter(input, "input");
                    String replaceAll = compile.matcher(input).replaceAll("_");
                    Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
                    RemoteLabels remoteLabels = new RemoteLabels(adbLink, adbHelpKt$$ExternalSyntheticLambda3, new File(cacheDir, "meta/".concat(replaceAll)));
                    try {
                        map = remoteLabels.names();
                    } catch (Exception unused) {
                        map = EmptyMap.INSTANCE;
                    }
                    synchronized (hashMap) {
                        try {
                            for (String str2 : info.apps) {
                                Object obj = hashMap.get(str2);
                                if (obj == null) {
                                    obj = new ArrayList();
                                    hashMap.put(str2, obj);
                                }
                                ((List) obj).add(input);
                            }
                            hashMap2.putAll(map);
                            hashMap3.put(input, remoteLabels);
                            arrayList.add(adbLink);
                            hashSet.add(input);
                        } finally {
                        }
                    }
                    return;
                } catch (Exception unused2) {
                    adbLink.close();
                    return;
                }
            case 1:
                String str3 = (String) this.f$1;
                String str4 = (String) this.f$2;
                String str5 = (String) this.f$3;
                String str6 = (String) this.f$4;
                MainActivity mainActivity2 = this.f$0;
                String str7 = (String) this.f$5;
                String str8 = (String) this.f$6;
                Diagnose.Result result = null;
                try {
                    Regex regex = Diagnose.OTHER_BRANDS;
                    Diagnose.Real real = new Diagnose.Real((AdbLink) null, 3);
                    ConcurrentHashMap concurrentHashMap = Words.books;
                    result = Diagnose.run(real, str3, str4, str5, str6, Words.lang);
                } catch (Exception unused3) {
                }
                mainActivity2.ui.post(new TalkKt$$ExternalSyntheticLambda4(mainActivity2, str7, result, str6, str3, str8, 2));
                return;
            default:
                ((ExecutorService) this.f$1).awaitTermination(3L, TimeUnit.MINUTES);
                MainActivity mainActivity3 = this.f$0;
                mainActivity3.ui.post(new TalkKt$$ExternalSyntheticLambda4((Popup) this.f$4, mainActivity3, (HashMap) this.f$2, (HashMap) this.f$3, (HashSet) this.f$6, (List) this.f$5));
                return;
        }
    }

    public /* synthetic */ ManyTvsKt$$ExternalSyntheticLambda36(String str, String str2, String str3, String str4, MainActivity mainActivity, String str5, String str6) {
        this.f$1 = str;
        this.f$2 = str2;
        this.f$3 = str3;
        this.f$4 = str4;
        this.f$0 = mainActivity;
        this.f$5 = str5;
        this.f$6 = str6;
    }

    public /* synthetic */ ManyTvsKt$$ExternalSyntheticLambda36(ExecutorService executorService, MainActivity mainActivity, Popup popup, HashMap hashMap, HashMap hashMap2, HashSet hashSet, List list) {
        this.f$1 = executorService;
        this.f$0 = mainActivity;
        this.f$4 = popup;
        this.f$2 = hashMap;
        this.f$3 = hashMap2;
        this.f$6 = hashSet;
        this.f$5 = list;
    }
}
