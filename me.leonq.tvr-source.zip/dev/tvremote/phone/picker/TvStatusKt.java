package dev.tvremote.phone.picker;

import android.graphics.Bitmap;
import android.widget.ImageView;
import android.widget.TextView;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.FleetStatus;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda15;
import dev.tvremote.phone.ui.UiKt;
import java.util.ArrayList;
import java.util.List;
import java.util.WeakHashMap;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$ObjectRef;

/* loaded from: classes.dex */
public abstract class TvStatusKt {
    public static final WeakHashMap tickFor = new WeakHashMap();
    public static final WeakHashMap shotFor = new WeakHashMap();

    public static void $r8$lambda$oPFA35vlznG0Zi1vl6HF8mLIEAg(ImageView imageView, Ref$ObjectRef ref$ObjectRef, String str) {
        imageView.setTag(null);
        Bitmap bitmap = (Bitmap) ref$ObjectRef.element;
        if (bitmap != null) {
            boolean z = TvStatus.shots;
            if (TvStatus.shots && imageView.getVisibility() == 0) {
                imageView.setImageBitmap(bitmap);
                Card card = (Card) TvStatus.cards.get(str);
                if (card != null) {
                    card.blank.setText("");
                }
            }
        }
    }

    public static final Runnable getShotTick(MainActivity mainActivity) {
        WeakHashMap weakHashMap = shotFor;
        Object obj = weakHashMap.get(mainActivity);
        if (obj == null) {
            obj = new MainActivity$$ExternalSyntheticLambda15(mainActivity, 17);
            weakHashMap.put(mainActivity, obj);
        }
        return (Runnable) obj;
    }

    public static final Runnable getStatusTick(MainActivity mainActivity) {
        WeakHashMap weakHashMap = tickFor;
        Object obj = weakHashMap.get(mainActivity);
        if (obj == null) {
            obj = new MainActivity$$ExternalSyntheticLambda15(mainActivity, 16);
            weakHashMap.put(mainActivity, obj);
        }
        return (Runnable) obj;
    }

    /* JADX WARN: Code restructure failed: missing block: B:42:0x013d, code lost:
    
        if (r12.getDrawable() == null) goto L162;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0033, code lost:
    
        if (kotlin.jvm.internal.Intrinsics.areEqual(r4, "standby") == false) goto L96;
     */
    /* JADX WARN: Removed duplicated region for block: B:10:0x0039  */
    /* JADX WARN: Removed duplicated region for block: B:13:0x0046  */
    /* JADX WARN: Removed duplicated region for block: B:19:0x0068  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x0074  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0109  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x0118  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x0123  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x012b  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0135  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x011a  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x010c  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x0081  */
    /* JADX WARN: Removed duplicated region for block: B:78:0x006b  */
    /* JADX WARN: Removed duplicated region for block: B:79:0x003c  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void showCard(MainActivity mainActivity, String ip, Card card, Boolean bool, String plain) {
        String str;
        boolean areEqual;
        int i;
        String concat;
        String T;
        CharSequence text;
        int i2;
        Boolean bool2;
        int i3;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Intrinsics.checkNotNullParameter(ip, "ip");
        Intrinsics.checkNotNullParameter(plain, "plain");
        FleetStatus.Status status = (FleetStatus.Status) TvStatus.last.get(ip);
        if (status != null && !Intrinsics.areEqual(bool, Boolean.FALSE)) {
            String str2 = status.state;
            if (!Intrinsics.areEqual(str2, "on")) {
            }
            if (status == null) {
                str = status.state;
            } else {
                str = null;
            }
            areEqual = Intrinsics.areEqual(str, "on");
            if (status != null) {
                if (areEqual) {
                    plain = ApkSigner$$ExternalSyntheticOutline0.m("● ", Fleet.T("tvstat.on", new Pair[0]));
                } else {
                    plain = ApkSigner$$ExternalSyntheticOutline0.m("● ", Fleet.T("tvstat.standby", new Pair[0]));
                }
            }
            TextView textView = card.state;
            textView.setText(plain);
            if (!areEqual) {
                i = UiKt.OK_TEXT;
            } else {
                i = UiKt.MUTED;
            }
            textView.setTextColor(i);
            String str3 = "";
            if (status != null) {
                if (PickerScreenKt.name(mainActivity, ip).length() == 0) {
                    ip = "";
                }
            } else if (areEqual && status.app.length() > 0) {
                if (status.home) {
                    T = Fleet.T("tvstat.home", new Pair[0]);
                } else {
                    T = Fleet.T("tvstat.showing", new Pair("app", status.appName));
                }
                ip = T;
            } else {
                String str4 = status.android;
                if (str4.length() == 0) {
                    concat = "";
                } else {
                    concat = "Android ".concat(str4);
                }
                List asList = ArraysKt.asList(new String[]{status.model, concat});
                ArrayList arrayList = new ArrayList();
                for (Object obj : asList) {
                    if (((String) obj).length() > 0) {
                        arrayList.add(obj);
                    }
                }
                ip = CollectionsKt.joinToString$default(arrayList, " · ", null, null, null, 62);
            }
            TextView textView2 = card.more;
            textView2.setText(ip);
            text = textView2.getText();
            Intrinsics.checkNotNullExpressionValue(text, "getText(...)");
            int i4 = 8;
            if (text.length() != 0) {
                i2 = 8;
            } else {
                i2 = 0;
            }
            textView2.setVisibility(i2);
            bool2 = Boolean.FALSE;
            if (!Intrinsics.areEqual(bool, bool2)) {
                i3 = 0;
            } else {
                i3 = 8;
            }
            card.wake.setVisibility(i3);
            if (areEqual) {
                i4 = 0;
            }
            ImageView imageView = card.pic;
            imageView.setVisibility(i4);
            if (!areEqual) {
                imageView.setImageDrawable(null);
            }
            if (!Intrinsics.areEqual(bool, bool2)) {
                if (!areEqual) {
                    if (status != null) {
                        str3 = Fleet.T("tvstat.standby", new Pair[0]);
                    } else {
                        if (Intrinsics.areEqual(bool, Boolean.TRUE)) {
                            str3 = Fleet.T("tvstat.no_picture", new Pair[0]);
                        }
                        str3 = "…";
                    }
                }
            }
            card.blank.setText(str3);
        }
        status = null;
        if (status == null) {
        }
        areEqual = Intrinsics.areEqual(str, "on");
        if (status != null) {
        }
        TextView textView3 = card.state;
        textView3.setText(plain);
        if (!areEqual) {
        }
        textView3.setTextColor(i);
        String str32 = "";
        if (status != null) {
        }
        TextView textView22 = card.more;
        textView22.setText(ip);
        text = textView22.getText();
        Intrinsics.checkNotNullExpressionValue(text, "getText(...)");
        int i42 = 8;
        if (text.length() != 0) {
        }
        textView22.setVisibility(i2);
        bool2 = Boolean.FALSE;
        if (!Intrinsics.areEqual(bool, bool2)) {
        }
        card.wake.setVisibility(i3);
        if (areEqual) {
        }
        ImageView imageView2 = card.pic;
        imageView2.setVisibility(i42);
        if (!areEqual) {
        }
        if (!Intrinsics.areEqual(bool, bool2)) {
        }
        card.blank.setText(str32);
    }

    public static final void showThumbs(MainActivity mainActivity) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        boolean z = TvStatus.shots;
        for (String str : TvStatus.cards.keySet()) {
            PickerScreenKt.showReach(mainActivity, str, (Boolean) mainActivity.reach.get(str));
        }
    }
}
