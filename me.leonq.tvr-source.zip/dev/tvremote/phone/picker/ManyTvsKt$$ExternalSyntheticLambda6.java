package dev.tvremote.phone.picker;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.widget.EditText;
import dev.tvremote.core.Census$$ExternalSyntheticLambda4;
import dev.tvremote.core.Diagnose;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.adb.Adb$$ExternalSyntheticLambda5;
import dev.tvremote.core.adb.AdbTls;
import dev.tvremote.core.manage.HomeApi$$ExternalSyntheticLambda1;
import dev.tvremote.core.ontv.Checkout;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.core.remote.Vidaa$$ExternalSyntheticLambda6;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.media.MediaKt$$ExternalSyntheticLambda9;
import dev.tvremote.phone.ui.DlApp;
import dev.tvremote.phone.ui.UiKt;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.Pair;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$BooleanRef;
import kotlin.math.MathKt;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class ManyTvsKt$$ExternalSyntheticLambda6 implements DialogInterface.OnClickListener {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;
    public final /* synthetic */ Object f$1;
    public final /* synthetic */ Object f$2;

    public /* synthetic */ ManyTvsKt$$ExternalSyntheticLambda6(Adb$$ExternalSyntheticLambda5 adb$$ExternalSyntheticLambda5, List list, boolean[] zArr) {
        this.$r8$classId = 6;
        this.f$0 = adb$$ExternalSyntheticLambda5;
        this.f$2 = list;
        this.f$1 = zArr;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i) {
        switch (this.$r8$classId) {
            case 0:
                MainActivity mainActivity = (MainActivity) this.f$0;
                SharedPreferences.Editor edit = mainActivity.getPrefs$android_release().edit();
                Checkout.Config config = (Checkout.Config) this.f$1;
                JSONObject put = new JSONObject().put("volume", config.volume);
                List list = config.apps;
                if (list != null) {
                    put.put("apps", new JSONArray((Collection) list));
                }
                Intrinsics.checkNotNullExpressionValue(put, "also(...)");
                edit.putString("checkout", put.toString()).apply();
                ManyTvsKt.fleetRun$default(mainActivity, Fleet.T("fleet.menu_checkout", new Pair[0]), (List) this.f$2, new HomeApi$$ExternalSyntheticLambda1(3, config), 4);
                return;
            case 1:
                ((Ref$BooleanRef) this.f$1).element = true;
                MainActivity mainActivity2 = (MainActivity) this.f$0;
                AdbHelpKt.tvJob(mainActivity2, new AdbHelpKt$$ExternalSyntheticLambda18(mainActivity2, (Remote) this.f$2, 1));
                return;
            case 2:
                String str = (String) this.f$2;
                MainActivity mainActivity3 = (MainActivity) this.f$0;
                Remote remote = (Remote) this.f$1;
                AdbHelpKt.tvJob(mainActivity3, new AdbHelpKt$$ExternalSyntheticLambda47(mainActivity3, remote, str, 2));
                mainActivity3.ui.postDelayed(new MediaKt$$ExternalSyntheticLambda9(mainActivity3, remote, 3), 800L);
                return;
            case 3:
                DlApp dlApp = UiKt.HOME_APP;
                DlApp dlApp2 = (DlApp) this.f$1;
                MainActivity mainActivity4 = (MainActivity) this.f$0;
                Remote remote2 = (Remote) this.f$2;
                if (dlApp2 == dlApp) {
                    AdbHelpKt.openHome(mainActivity4, remote2, new Census$$ExternalSyntheticLambda4(19));
                    return;
                } else {
                    AdbHelpKt.tvJob(mainActivity4, new Vidaa$$ExternalSyntheticLambda6(mainActivity4, remote2, dlApp2, 6));
                    return;
                }
            case 4:
                Integer intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull(StringsKt.trim(((EditText) this.f$1).getText().toString()).toString());
                if (intOrNull != null) {
                    int intValue = intOrNull.intValue();
                    String str2 = (String) this.f$2;
                    AdbTls adbTls = AdbTls.INSTANCE;
                    MainActivity mainActivity5 = (MainActivity) this.f$0;
                    File filesDir = mainActivity5.getFilesDir();
                    Intrinsics.checkNotNullExpressionValue(filesDir, "getFilesDir(...)");
                    adbTls.save(filesDir, str2, intValue);
                    mainActivity5.adbFailed.remove(str2);
                    String str3 = mainActivity5.entry;
                    mainActivity5.disconnect$android_release(null);
                    mainActivity5.connect$android_release(str2, str3);
                    return;
                }
                return;
            case 5:
                ((MainActivity) this.f$0).connect$android_release(((Diagnose.Found) this.f$1).ip, (String) this.f$2);
                return;
            case 6:
                ArrayList arrayList = new ArrayList();
                int i2 = 0;
                for (Object obj : (List) this.f$2) {
                    int i3 = i2 + 1;
                    if (i2 >= 0) {
                        if (((boolean[]) this.f$1)[i2]) {
                            arrayList.add(obj);
                        }
                        i2 = i3;
                    } else {
                        CollectionsKt__CollectionsKt.throwIndexOverflow();
                        throw null;
                    }
                }
                ((Adb$$ExternalSyntheticLambda5) this.f$0).invoke(arrayList);
                return;
            default:
                MainActivity mainActivity6 = (MainActivity) this.f$0;
                mainActivity6.getPrefs$android_release().edit().putString("setupUndo", String.valueOf(((SetupNews) this.f$1).at)).apply();
                MathKt.showSetup(mainActivity6, (String) this.f$2);
                return;
        }
    }

    public /* synthetic */ ManyTvsKt$$ExternalSyntheticLambda6(MainActivity mainActivity, Object obj, Object obj2, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
        this.f$1 = obj;
        this.f$2 = obj2;
    }

    public /* synthetic */ ManyTvsKt$$ExternalSyntheticLambda6(Object obj, MainActivity mainActivity, Object obj2, int i) {
        this.$r8$classId = i;
        this.f$1 = obj;
        this.f$0 = mainActivity;
        this.f$2 = obj2;
    }
}
