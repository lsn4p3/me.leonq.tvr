package dev.tvremote.phone.picker;

import android.view.KeyEvent;
import android.view.View;
import android.widget.LinearLayout;
import dev.tvremote.core.adb.TvKeyboard;
import dev.tvremote.core.scenes.RemoteSpec$Entry;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.ir.IrRemoteKt$$ExternalSyntheticLambda22;
import dev.tvremote.phone.manage.Managing;
import dev.tvremote.phone.remote.KbdWatch;
import dev.tvremote.phone.remote.PhoneRemoteKt;
import dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda9;
import dev.tvremote.phone.remote.TypingKt;
import dev.tvremote.phone.ui.IconButton;
import dev.tvremote.phone.ui.Popup;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final /* synthetic */ class ManyTvsKt$$ExternalSyntheticLambda40 implements View.OnClickListener {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ KeyEvent.Callback f$0;
    public final /* synthetic */ MainActivity f$1;
    public final /* synthetic */ Object f$2;
    public final /* synthetic */ Object f$3;

    public /* synthetic */ ManyTvsKt$$ExternalSyntheticLambda40(KeyEvent.Callback callback, MainActivity mainActivity, Object obj, Object obj2, int i) {
        this.$r8$classId = i;
        this.f$0 = callback;
        this.f$1 = mainActivity;
        this.f$2 = obj;
        this.f$3 = obj2;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        String str;
        switch (this.$r8$classId) {
            case 0:
                ((Popup) this.f$0).dismiss();
                Managing managing$android_release = this.f$1.getManaging$android_release();
                String str2 = ((Part) this.f$2).ip;
                if (Intrinsics.areEqual(((CoRow) this.f$3).fix, "update")) {
                    str = "updateSetup()";
                } else {
                    str = "installSetupApk()";
                }
                Managing.open$default(managing$android_release, str2, null, str, 2);
                return;
            case 1:
                Object tag = ((IconButton) this.f$0).getTag();
                MainActivity mainActivity = this.f$1;
                if (tag == "kind-off") {
                    PhoneRemoteKt.kindOff(mainActivity);
                    return;
                } else {
                    ((Function2) this.f$2).invoke(mainActivity, ((RemoteSpec$Entry) this.f$3).arg);
                    return;
                }
            default:
                int visibility = ((LinearLayout) this.f$0).getVisibility();
                MainActivity mainActivity2 = this.f$1;
                if (visibility != 0) {
                    ((IrRemoteKt$$ExternalSyntheticLambda22) this.f$2).invoke(mainActivity2.getTextBox$android_release());
                    return;
                }
                KbdWatch kbdWatch = mainActivity2.kbdWatch;
                if (kbdWatch != null) {
                    TvKeyboard.Follow follow = kbdWatch.follow;
                    follow.closed = true;
                    follow.opened = false;
                    TypingKt.slide(mainActivity2.getControls$android_release());
                    ((RemoteScreenKt$$ExternalSyntheticLambda9) this.f$3).invoke(Boolean.FALSE);
                    return;
                }
                Intrinsics.throwUninitializedPropertyAccessException("kbdWatch");
                throw null;
        }
    }

    public /* synthetic */ ManyTvsKt$$ExternalSyntheticLambda40(LinearLayout linearLayout, IrRemoteKt$$ExternalSyntheticLambda22 irRemoteKt$$ExternalSyntheticLambda22, MainActivity mainActivity, RemoteScreenKt$$ExternalSyntheticLambda9 remoteScreenKt$$ExternalSyntheticLambda9) {
        this.$r8$classId = 2;
        this.f$0 = linearLayout;
        this.f$2 = irRemoteKt$$ExternalSyntheticLambda22;
        this.f$1 = mainActivity;
        this.f$3 = remoteScreenKt$$ExternalSyntheticLambda9;
    }
}
