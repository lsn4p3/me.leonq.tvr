package dev.tvremote.phone.picker;

import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class CoRow {
    public final String fix;
    public final String icon;
    public final int state;
    public final String text;

    public CoRow(int i, String str, String text, String str2) {
        Intrinsics.checkNotNullParameter(text, "text");
        this.state = i;
        this.icon = str;
        this.text = text;
        this.fix = str2;
    }
}
