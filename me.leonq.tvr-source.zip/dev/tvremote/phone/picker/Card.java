package dev.tvremote.phone.picker;

import android.widget.ImageView;
import android.widget.TextView;
import dev.tvremote.phone.ui.IconButton;

/* loaded from: classes.dex */
public final class Card {
    public final TextView blank;
    public final TextView more;
    public final ImageView pic;
    public final TextView state;
    public final IconButton wake;

    public Card(ImageView imageView, TextView textView, IconButton iconButton, TextView textView2, TextView textView3, TextView textView4) {
        this.pic = imageView;
        this.blank = textView;
        this.wake = iconButton;
        this.state = textView3;
        this.more = textView4;
    }
}
