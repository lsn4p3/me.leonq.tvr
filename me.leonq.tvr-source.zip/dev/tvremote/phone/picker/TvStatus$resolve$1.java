package dev.tvremote.phone.picker;

import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class TvStatus$resolve$1 implements Function1 {
    public static final TvStatus$resolve$1 INSTANCE = new Object();

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        String it = (String) obj;
        Intrinsics.checkNotNullParameter(it, "it");
        return null;
    }
}
