package dev.tvremote.phone.picker;

import dev.tvremote.core.Diagnose$$ExternalSyntheticLambda1;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda3;
import dev.tvremote.update.Ed25519;
import java.io.File;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.Pair;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public abstract class TvStatus {
    public static volatile Ed25519.Pt board;
    public static volatile boolean shots;
    public static final ConcurrentHashMap last = new ConcurrentHashMap();
    public static final HashMap thumbs = new HashMap();
    public static final HashMap cards = new HashMap();
    public static final ConcurrentHashMap links = new ConcurrentHashMap();
    public static final ConcurrentHashMap used = new ConcurrentHashMap();
    public static volatile Function1 resolve = TvStatus$resolve$1.INSTANCE;
    public static final AtomicBoolean busy = new AtomicBoolean();
    public static final Semaphore gate = new Semaphore(2);
    public static final ExecutorService pool = Executors.newCachedThreadPool(new Diagnose$$ExternalSyntheticLambda1(9));

    static {
        Executors.newSingleThreadScheduledExecutor(new Diagnose$$ExternalSyntheticLambda1(10)).scheduleWithFixedDelay(new Guard$$ExternalSyntheticLambda3(7), 30L, 30L, TimeUnit.SECONDS);
    }

    public static AdbLink link(File keys, String ip, String addr) {
        AdbLink adbLink;
        Intrinsics.checkNotNullParameter(ip, "ip");
        Intrinsics.checkNotNullParameter(addr, "addr");
        Intrinsics.checkNotNullParameter(keys, "keys");
        used.put(ip, Long.valueOf(System.currentTimeMillis()));
        ConcurrentHashMap concurrentHashMap = links;
        Pair pair = (Pair) concurrentHashMap.get(ip);
        if (pair != null && Intrinsics.areEqual(pair.first, addr)) {
            return (AdbLink) pair.second;
        }
        if (pair != null && (adbLink = (AdbLink) pair.second) != null) {
            adbLink.close();
        }
        AdbLink adbLink2 = new AdbLink(keys, addr);
        concurrentHashMap.put(ip, new Pair(addr, adbLink2));
        return adbLink2;
    }
}
