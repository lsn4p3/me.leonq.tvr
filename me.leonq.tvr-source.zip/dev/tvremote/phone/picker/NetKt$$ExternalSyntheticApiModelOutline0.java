package dev.tvremote.phone.picker;

/* loaded from: classes.dex */
public abstract /* synthetic */ class NetKt$$ExternalSyntheticApiModelOutline0 {
}
