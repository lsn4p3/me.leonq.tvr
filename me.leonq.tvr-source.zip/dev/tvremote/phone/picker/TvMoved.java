package dev.tvremote.phone.picker;

/* loaded from: classes.dex */
public final class TvMoved extends Exception {
}
