package dev.tvremote.phone.picker;

import android.content.Context;
import android.net.Network;
import android.os.Build;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Diagnose;
import dev.tvremote.core.Scrub;
import dev.tvremote.core.SupportAndroid;
import dev.tvremote.core.WireLog;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.manage.PhoneSupport;
import dev.tvremote.phone.remote.TypingKt;
import java.io.File;
import java.net.DatagramSocket;
import java.net.URLDecoder;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class NetKt$$ExternalSyntheticLambda1 implements Function1 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Context f$0;

    public /* synthetic */ NetKt$$ExternalSyntheticLambda1(Context context, int i) {
        this.$r8$classId = i;
        this.f$0 = context;
    }

    /* JADX WARN: Removed duplicated region for block: B:72:0x01b8  */
    /* JADX WARN: Type inference failed for: r4v6, types: [java.lang.Object, java.util.Comparator] */
    @Override // kotlin.jvm.functions.Function1
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object invoke(Object obj) {
        Network lanNetwork;
        String str;
        Object clean;
        String str2;
        String decode;
        String str3;
        String str4;
        switch (this.$r8$classId) {
            case 0:
                Context context = this.f$0;
                DatagramSocket s = (DatagramSocket) obj;
                Intrinsics.checkNotNullParameter(s, "s");
                try {
                    if (Build.VERSION.SDK_INT >= 22 && (lanNetwork = MathKt.lanNetwork(context)) != null) {
                        lanNetwork.bindSocket(s);
                    }
                } catch (Exception unused) {
                }
                return Unit.INSTANCE;
            default:
                Context context2 = this.f$0;
                String it = (String) obj;
                Intrinsics.checkNotNullParameter(it, "it");
                PhoneSupport phoneSupport = PhoneSupport.INSTANCE;
                Context applicationContext = context2.getApplicationContext();
                Intrinsics.checkNotNullExpressionValue(applicationContext, "getApplicationContext(...)");
                String substringBefore = StringsKt.substringBefore(it, '?', it);
                switch (substringBefore.hashCode()) {
                    case -8588458:
                        if (substringBefore.equals("/api/support/logcat")) {
                            return new Pair(200, SupportAndroid.logcat());
                        }
                        break;
                    case 367344768:
                        if (substringBefore.equals("/api/support/log")) {
                            return new Pair(200, WireLog.all.report(null));
                        }
                        break;
                    case 367346393:
                        if (substringBefore.equals("/api/support/net")) {
                            return new Pair(200, PhoneSupport.net(applicationContext));
                        }
                        break;
                    case 367352685:
                        if (substringBefore.equals("/api/support/tvs")) {
                            return new Pair(200, PhoneSupport.tvs().toString(1));
                        }
                        break;
                    case 834788588:
                        if (substringBefore.equals("/api/support/prefs")) {
                            Regex regex = SupportAndroid.SECRET;
                            StringBuilder sb = new StringBuilder();
                            Object[] listFiles = new File(applicationContext.getApplicationInfo().dataDir, "shared_prefs").listFiles();
                            if (listFiles == null) {
                                listFiles = new File[0];
                            }
                            ?? obj2 = new Object();
                            if (listFiles.length != 0) {
                                listFiles = Arrays.copyOf(listFiles, listFiles.length);
                                Intrinsics.checkNotNullExpressionValue(listFiles, "copyOf(...)");
                                if (listFiles.length > 1) {
                                    Arrays.sort(listFiles, obj2);
                                }
                            }
                            Iterator it2 = ArraysKt.asList(listFiles).iterator();
                            while (it2.hasNext()) {
                                String name = ((File) it2.next()).getName();
                                Intrinsics.checkNotNullExpressionValue(name, "getName(...)");
                                String removeSuffix = StringsKt.removeSuffix(name, ".xml");
                                if (!StringsKt__StringsJVMKt.startsWith(removeSuffix, false, "WebView") && !StringsKt__StringsJVMKt.startsWith(removeSuffix, false, "Aw")) {
                                    try {
                                        Map<String, ?> all = applicationContext.getSharedPreferences(removeSuffix, 0).getAll();
                                        if (!all.isEmpty()) {
                                            sb.append("[prefs ");
                                            sb.append(removeSuffix);
                                            sb.append("]\n");
                                            for (Map.Entry entry : new TreeMap(all).entrySet()) {
                                                String str5 = (String) entry.getKey();
                                                Object value = entry.getValue();
                                                sb.append(str5);
                                                sb.append('=');
                                                Intrinsics.checkNotNull(str5);
                                                String str6 = "…";
                                                if (!SupportAndroid.SECRET.matches(str5)) {
                                                    if (value instanceof String) {
                                                        if (StringsKt__StringsJVMKt.startsWith((String) value, false, "{")) {
                                                            clean = SupportAndroid.clean(new JSONObject((String) value));
                                                        } else {
                                                            if (StringsKt__StringsJVMKt.startsWith((String) value, false, "[")) {
                                                                clean = SupportAndroid.clean(new JSONArray((String) value));
                                                            }
                                                            str = null;
                                                            if (str == null) {
                                                                str = StringsKt.take((String) value, 2000);
                                                            }
                                                        }
                                                        str = String.valueOf(clean);
                                                        if (str == null) {
                                                        }
                                                    } else if (value instanceof Set) {
                                                        str = CollectionsKt.joinToString$default((Iterable) value, ",", "{", "}", null, 56);
                                                    } else {
                                                        str = String.valueOf(value);
                                                    }
                                                    str6 = SupportAndroid.TOKEN.replace(str, "…");
                                                }
                                                sb.append(str6);
                                                sb.append('\n');
                                            }
                                        }
                                    } catch (Exception unused2) {
                                    }
                                }
                            }
                            return new Pair(200, Scrub.blank(sb.toString()));
                        }
                        break;
                    case 887415746:
                        if (substringBefore.equals("/api/diagnose")) {
                            MatcherMatchResult access$findNext = MathKt.access$findNext(Census$$ExternalSyntheticOutline0.m6m("[?&]ip=([\\w.:%-]+)", "compile(...)", it, "matcher(...)"), 0, it);
                            if (access$findNext != null && (str2 = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1)) != null && (decode = URLDecoder.decode(str2, "UTF-8")) != null) {
                                MainActivity mainActivity = (MainActivity) PhoneSupport.activity.get();
                                Regex regex2 = Diagnose.OTHER_BRANDS;
                                Diagnose.Real real = new Diagnose.Real((AdbLink) null, 3);
                                if (mainActivity != null) {
                                    str3 = TypingKt.kindOf(mainActivity, decode);
                                } else {
                                    str3 = "android";
                                }
                                String str7 = str3;
                                if (mainActivity != null) {
                                    str4 = PickerScreenKt.name(mainActivity, decode);
                                } else {
                                    str4 = "";
                                }
                                return new Pair(200, Diagnose.json(Diagnose.run(real, decode, str7, str4, "", "en"), "en").toString(1));
                            }
                            return new Pair(400, "which TV: /api/diagnose?ip=192.168.1.20");
                        }
                        break;
                }
                return new Pair(403, Census$$ExternalSyntheticOutline0.m("not allowed for support: ", substringBefore, " (the phone answers ", CollectionsKt.joinToString$default(PhoneSupport.ROUTES, ", ", null, null, null, 62), ")"));
        }
    }
}
