package dev.tvremote.phone.picker;

import android.os.Handler;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.adb.Adb$$ExternalSyntheticLambda5;
import dev.tvremote.core.ontv.Axml$$ExternalSyntheticLambda2;
import dev.tvremote.core.remote.Lg$$ExternalSyntheticLambda2;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.core.remote.Vidaa$$ExternalSyntheticLambda3;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.media.MediaKt$$ExternalSyntheticLambda1;
import dev.tvremote.phone.ui.DlApp;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.phone.ui.UiKt;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.Pair;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$BooleanRef;
import kotlin.jvm.internal.Ref$IntRef;

/* loaded from: classes.dex */
public final /* synthetic */ class AdbHelpKt$$ExternalSyntheticLambda17 implements Runnable {
    public final /* synthetic */ int $r8$classId = 0;
    public final /* synthetic */ Object f$0;
    public final /* synthetic */ MainActivity f$1;
    public final /* synthetic */ Serializable f$3;
    public final /* synthetic */ Object f$4;
    public final /* synthetic */ Object f$5;
    public final /* synthetic */ Object f$6;
    public final /* synthetic */ Serializable f$7;
    public final /* synthetic */ Object f$8;
    public final /* synthetic */ Popup f$9;

    public /* synthetic */ AdbHelpKt$$ExternalSyntheticLambda17(Remote remote, MainActivity mainActivity, Ref$BooleanRef ref$BooleanRef, Adb$$ExternalSyntheticLambda5 adb$$ExternalSyntheticLambda5, Ref$BooleanRef ref$BooleanRef2, Axml$$ExternalSyntheticLambda2 axml$$ExternalSyntheticLambda2, Ref$IntRef ref$IntRef, DlApp dlApp, Popup popup) {
        this.f$0 = remote;
        this.f$1 = mainActivity;
        this.f$3 = ref$BooleanRef;
        this.f$4 = adb$$ExternalSyntheticLambda5;
        this.f$5 = ref$BooleanRef2;
        this.f$6 = axml$$ExternalSyntheticLambda2;
        this.f$7 = ref$IntRef;
        this.f$8 = dlApp;
        this.f$9 = popup;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:51:0x00ff A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:55:0x009b A[SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r2v12, types: [dev.tvremote.phone.ui.Popup] */
    /* JADX WARN: Type inference failed for: r2v8, types: [dev.tvremote.phone.ui.Popup] */
    /* JADX WARN: Type inference failed for: r7v0, types: [dev.tvremote.phone.ui.Popup, java.lang.Object] */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void run() {
        AtomicBoolean atomicBoolean;
        int i;
        Ref$BooleanRef ref$BooleanRef;
        switch (this.$r8$classId) {
            case 0:
                final Remote remote = (Remote) this.f$0;
                final MainActivity mainActivity = this.f$1;
                final Ref$BooleanRef ref$BooleanRef2 = (Ref$BooleanRef) this.f$3;
                Axml$$ExternalSyntheticLambda2 axml$$ExternalSyntheticLambda2 = (Axml$$ExternalSyntheticLambda2) this.f$6;
                Ref$IntRef ref$IntRef = (Ref$IntRef) this.f$7;
                final DlApp dlApp = (DlApp) this.f$8;
                ?? r7 = this.f$9;
                try {
                    try {
                        try {
                        } catch (TvMoved unused) {
                            ref$IntRef = r7;
                        }
                    } catch (Throwable th) {
                        th = th;
                        mainActivity.tvBusy.set(false);
                        throw th;
                    }
                } catch (Exception unused2) {
                    atomicBoolean = mainActivity.tvBusy;
                }
                if (remote.getApp().length() == 0) {
                    mainActivity.ui.post(new Lg$$ExternalSyntheticLambda2(r7, mainActivity, dlApp, 15));
                    atomicBoolean = mainActivity.tvBusy;
                    atomicBoolean.set(false);
                    return;
                }
                final int i2 = 0;
                boolean openOnTv = AdbHelpKt.openOnTv(mainActivity, remote, "com.esaba.downloader", true, new Function0() { // from class: dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda33
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        switch (i2) {
                            case 0:
                                return Boolean.valueOf(ref$BooleanRef2.element);
                            default:
                                return Boolean.valueOf(ref$BooleanRef2.element);
                        }
                    }
                });
                Adb$$ExternalSyntheticLambda5 adb$$ExternalSyntheticLambda5 = (Adb$$ExternalSyntheticLambda5) this.f$4;
                if (!openOnTv && !ref$BooleanRef2.element && mainActivity.basic == remote) {
                    adb$$ExternalSyntheticLambda5.invoke("adb_help.the_tv_has_no");
                    while (!ref$BooleanRef2.element && mainActivity.basic == remote && !openOnTv) {
                        int i3 = 0;
                        while (true) {
                            ref$BooleanRef = (Ref$BooleanRef) this.f$5;
                            if (i3 < 600 && !ref$BooleanRef2.element && !ref$BooleanRef.element && !Intrinsics.areEqual(remote.getApp(), "com.esaba.downloader")) {
                                Thread.sleep(200L);
                                i3++;
                            }
                        }
                        if (!ref$BooleanRef2.element && mainActivity.basic == remote) {
                            axml$$ExternalSyntheticLambda2.invoke(Boolean.TRUE);
                            adb$$ExternalSyntheticLambda5.invoke("adb_help.opening_downloader_on_the_tv");
                            if (!Intrinsics.areEqual(remote.getApp(), "com.esaba.downloader")) {
                                final int i4 = 1;
                                if (!AdbHelpKt.openOnTv(mainActivity, remote, "com.esaba.downloader", true, new Function0() { // from class: dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda33
                                    @Override // kotlin.jvm.functions.Function0
                                    public final Object invoke() {
                                        switch (i4) {
                                            case 0:
                                                return Boolean.valueOf(ref$BooleanRef2.element);
                                            default:
                                                return Boolean.valueOf(ref$BooleanRef2.element);
                                        }
                                    }
                                })) {
                                    openOnTv = false;
                                    ref$BooleanRef.element = false;
                                    axml$$ExternalSyntheticLambda2.invoke(Boolean.FALSE);
                                    if (openOnTv) {
                                        adb$$ExternalSyntheticLambda5.invoke("adb_help.the_tv_still_has");
                                    }
                                }
                            }
                            openOnTv = true;
                            ref$BooleanRef.element = false;
                            axml$$ExternalSyntheticLambda2.invoke(Boolean.FALSE);
                            if (openOnTv) {
                            }
                        }
                    }
                }
                atomicBoolean = mainActivity.tvBusy;
                Handler handler = mainActivity.ui;
                try {
                    if (!openOnTv) {
                        final ?? r2 = r7;
                        final int i5 = 0;
                        handler.post(new Runnable() { // from class: dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda35
                            @Override // java.lang.Runnable
                            public final void run() {
                                switch (i5) {
                                    case 0:
                                        Popup popup = r2;
                                        if (popup.isShowing()) {
                                            popup.dismiss();
                                        }
                                        if (!ref$BooleanRef2.element) {
                                            MainActivity mainActivity2 = mainActivity;
                                            if (mainActivity2.basic == remote) {
                                                if (dlApp == UiKt.SETUP_APP) {
                                                    AdbHelpKt.installSetupByHand(mainActivity2);
                                                    return;
                                                } else {
                                                    AdbHelpKt.otherHome(mainActivity2);
                                                    return;
                                                }
                                            }
                                            return;
                                        }
                                        return;
                                    default:
                                        Popup popup2 = r2;
                                        if (popup2.isShowing()) {
                                            popup2.dismiss();
                                        }
                                        if (!ref$BooleanRef2.element) {
                                            MainActivity mainActivity3 = mainActivity;
                                            Remote remote2 = mainActivity3.basic;
                                            Remote remote3 = remote;
                                            if (remote2 == remote3 && !mainActivity3.isFinishing()) {
                                                Popup.Builder builder = new Popup.Builder(mainActivity3);
                                                builder.title = Fleet.T("allow.look_at_the_tv", new Pair[0]);
                                                DlApp dlApp2 = dlApp;
                                                builder.message = Fleet.T((String) dlApp2.look, new Pair[0]);
                                                builder.setPositiveButton(Fleet.T((String) dlApp2.open, new Pair[0]), new ManyTvsKt$$ExternalSyntheticLambda6(dlApp2, mainActivity3, remote3, 3));
                                                builder.setNeutralButton(Fleet.T("adb_help.step_by_step", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda67(mainActivity3, dlApp2, 2));
                                                builder.setNegativeButton(Fleet.T("common.close", new Pair[0]), null);
                                                builder.show();
                                                return;
                                            }
                                            return;
                                        }
                                        return;
                                }
                            }
                        });
                        ref$IntRef = r2;
                    } else {
                        ref$IntRef.element = 2;
                        adb$$ExternalSyntheticLambda5.invoke("adb_help.handing_the_download_link");
                        Thread.sleep(3000L);
                        remote.launch("downloader://" + dlApp.getCode());
                        for (int i6 = 0; i6 < 3; i6++) {
                            Thread.sleep(1500L);
                            if (Intrinsics.areEqual(remote.getApp(), "android") && !ref$BooleanRef2.element) {
                                remote.pulse(23, 110L);
                            }
                            Thread.sleep(2500L);
                            String app = remote.getApp();
                            ref$IntRef.element = 3;
                            adb$$ExternalSyntheticLambda5.invoke("adb_help.link_entered_waiting_for");
                            for (i = 0; i < 240 && !ref$BooleanRef2.element && mainActivity.basic == remote && Intrinsics.areEqual(remote.getApp(), app); i++) {
                                Thread.sleep(500L);
                            }
                            if (!ref$BooleanRef2.element && AdbHelpKt.TV_HOME.containsMatchIn(remote.getApp())) {
                                throw new Exception();
                            }
                            final ?? r22 = r7;
                            final int i7 = 1;
                            handler.post(new Runnable() { // from class: dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda35
                                @Override // java.lang.Runnable
                                public final void run() {
                                    switch (i7) {
                                        case 0:
                                            Popup popup = r22;
                                            if (popup.isShowing()) {
                                                popup.dismiss();
                                            }
                                            if (!ref$BooleanRef2.element) {
                                                MainActivity mainActivity2 = mainActivity;
                                                if (mainActivity2.basic == remote) {
                                                    if (dlApp == UiKt.SETUP_APP) {
                                                        AdbHelpKt.installSetupByHand(mainActivity2);
                                                        return;
                                                    } else {
                                                        AdbHelpKt.otherHome(mainActivity2);
                                                        return;
                                                    }
                                                }
                                                return;
                                            }
                                            return;
                                        default:
                                            Popup popup2 = r22;
                                            if (popup2.isShowing()) {
                                                popup2.dismiss();
                                            }
                                            if (!ref$BooleanRef2.element) {
                                                MainActivity mainActivity3 = mainActivity;
                                                Remote remote2 = mainActivity3.basic;
                                                Remote remote3 = remote;
                                                if (remote2 == remote3 && !mainActivity3.isFinishing()) {
                                                    Popup.Builder builder = new Popup.Builder(mainActivity3);
                                                    builder.title = Fleet.T("allow.look_at_the_tv", new Pair[0]);
                                                    DlApp dlApp2 = dlApp;
                                                    builder.message = Fleet.T((String) dlApp2.look, new Pair[0]);
                                                    builder.setPositiveButton(Fleet.T((String) dlApp2.open, new Pair[0]), new ManyTvsKt$$ExternalSyntheticLambda6(dlApp2, mainActivity3, remote3, 3));
                                                    builder.setNeutralButton(Fleet.T("adb_help.step_by_step", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda67(mainActivity3, dlApp2, 2));
                                                    builder.setNegativeButton(Fleet.T("common.close", new Pair[0]), null);
                                                    builder.show();
                                                    return;
                                                }
                                                return;
                                            }
                                            return;
                                    }
                                }
                            });
                            ref$IntRef = r22;
                        }
                        Thread.sleep(2500L);
                        String app2 = remote.getApp();
                        ref$IntRef.element = 3;
                        adb$$ExternalSyntheticLambda5.invoke("adb_help.link_entered_waiting_for");
                        while (i < 240) {
                            Thread.sleep(500L);
                        }
                        if (!ref$BooleanRef2.element) {
                            throw new Exception();
                        }
                        final Popup r222 = r7;
                        final int i72 = 1;
                        handler.post(new Runnable() { // from class: dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda35
                            @Override // java.lang.Runnable
                            public final void run() {
                                switch (i72) {
                                    case 0:
                                        Popup popup = r222;
                                        if (popup.isShowing()) {
                                            popup.dismiss();
                                        }
                                        if (!ref$BooleanRef2.element) {
                                            MainActivity mainActivity2 = mainActivity;
                                            if (mainActivity2.basic == remote) {
                                                if (dlApp == UiKt.SETUP_APP) {
                                                    AdbHelpKt.installSetupByHand(mainActivity2);
                                                    return;
                                                } else {
                                                    AdbHelpKt.otherHome(mainActivity2);
                                                    return;
                                                }
                                            }
                                            return;
                                        }
                                        return;
                                    default:
                                        Popup popup2 = r222;
                                        if (popup2.isShowing()) {
                                            popup2.dismiss();
                                        }
                                        if (!ref$BooleanRef2.element) {
                                            MainActivity mainActivity3 = mainActivity;
                                            Remote remote2 = mainActivity3.basic;
                                            Remote remote3 = remote;
                                            if (remote2 == remote3 && !mainActivity3.isFinishing()) {
                                                Popup.Builder builder = new Popup.Builder(mainActivity3);
                                                builder.title = Fleet.T("allow.look_at_the_tv", new Pair[0]);
                                                DlApp dlApp2 = dlApp;
                                                builder.message = Fleet.T((String) dlApp2.look, new Pair[0]);
                                                builder.setPositiveButton(Fleet.T((String) dlApp2.open, new Pair[0]), new ManyTvsKt$$ExternalSyntheticLambda6(dlApp2, mainActivity3, remote3, 3));
                                                builder.setNeutralButton(Fleet.T("adb_help.step_by_step", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda67(mainActivity3, dlApp2, 2));
                                                builder.setNegativeButton(Fleet.T("common.close", new Pair[0]), null);
                                                builder.show();
                                                return;
                                            }
                                            return;
                                        }
                                        return;
                                }
                            }
                        });
                        ref$IntRef = r222;
                    }
                } catch (TvMoved unused3) {
                    try {
                        mainActivity.ui.post(new Vidaa$$ExternalSyntheticLambda3(ref$IntRef, ref$BooleanRef2, mainActivity, dlApp, 6));
                        atomicBoolean = mainActivity.tvBusy;
                        atomicBoolean.set(false);
                        return;
                    } catch (Throwable th2) {
                        th = th2;
                        mainActivity = mainActivity;
                        mainActivity.tvBusy.set(false);
                        throw th;
                    }
                }
                atomicBoolean.set(false);
                return;
            default:
                ((ExecutorService) this.f$0).awaitTermination(3L, TimeUnit.MINUTES);
                MainActivity mainActivity2 = this.f$1;
                mainActivity2.ui.post(new MediaKt$$ExternalSyntheticLambda1(mainActivity2, this.f$9, (HashMap) this.f$3, (List) this.f$5, (HashSet) this.f$4, (ArrayList) this.f$6, (HashMap) this.f$7, (HashMap) this.f$8));
                return;
        }
    }

    public /* synthetic */ AdbHelpKt$$ExternalSyntheticLambda17(ExecutorService executorService, MainActivity mainActivity, Popup popup, HashMap hashMap, List list, HashSet hashSet, ArrayList arrayList, HashMap hashMap2, HashMap hashMap3) {
        this.f$0 = executorService;
        this.f$1 = mainActivity;
        this.f$9 = popup;
        this.f$3 = hashMap;
        this.f$5 = list;
        this.f$4 = hashSet;
        this.f$6 = arrayList;
        this.f$7 = hashMap2;
        this.f$8 = hashMap3;
    }
}
