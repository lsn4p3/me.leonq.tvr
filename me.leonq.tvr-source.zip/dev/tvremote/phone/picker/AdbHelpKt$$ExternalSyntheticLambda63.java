package dev.tvremote.phone.picker;

import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.widget.EditText;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.core.remote.Vidaa;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.remote.KeysOnlyKt$$ExternalSyntheticLambda2;
import dev.tvremote.phone.remote.KeysOnlyKt$$ExternalSyntheticLambda3;
import dev.tvremote.phone.remote.TypingKt;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.phone.ui.UiKt;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;

/* loaded from: classes.dex */
public final /* synthetic */ class AdbHelpKt$$ExternalSyntheticLambda63 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ AdbHelpKt$$ExternalSyntheticLambda63(MainActivity mainActivity, String str, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
        this.f$1 = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Object obj;
        final boolean z;
        final boolean z2;
        Object next;
        switch (this.$r8$classId) {
            case 0:
                String T = Fleet.T("adb_help.connect_port", new Pair[0]);
                MainActivity mainActivity = this.f$0;
                EditText input = UiKt.input(mainActivity, T);
                input.setInputType(2);
                Popup.Builder builder = new Popup.Builder(mainActivity);
                builder.title = Fleet.T("adb_help.paired_connect_port", new Pair[0]);
                builder.message = Fleet.T("adb_help.on_the_wireless_debugging", new Pair[0]);
                builder.view = UiKt.inDialog(mainActivity, input);
                builder.setPositiveButton(Fleet.T("page.connect", new Pair[0]), new ManyTvsKt$$ExternalSyntheticLambda6(input, mainActivity, this.f$1, 4));
                builder.setNegativeButton(Fleet.T("common.cancel", new Pair[0]), null);
                builder.show();
                return;
            case 1:
                MainActivity mainActivity2 = this.f$0;
                HashMap hashMap = mainActivity2.route;
                String str = this.f$1;
                hashMap.put(str, str);
                HashMap hashMap2 = mainActivity2.reach;
                Boolean bool = Boolean.TRUE;
                hashMap2.put(str, bool);
                PickerScreenKt.showReach(mainActivity2, str, bool);
                return;
            case 2:
                long currentTimeMillis = System.currentTimeMillis();
                StringBuilder sb = new StringBuilder("ts:");
                final String str2 = this.f$1;
                sb.append(str2);
                String sb2 = sb.toString();
                final MainActivity mainActivity3 = this.f$0;
                List asList = ArraysKt.asList(new String[]{str2, mainActivity3.pref$android_release(sb2), mainActivity3.pref$android_release("lan:" + str2)});
                ArrayList arrayList = new ArrayList();
                for (Object obj2 : asList) {
                    if (((String) obj2).length() > 0) {
                        arrayList.add(obj2);
                    }
                }
                Iterator it = CollectionsKt.distinct(arrayList).iterator();
                while (true) {
                    obj = null;
                    z = false;
                    if (it.hasNext()) {
                        next = it.next();
                        String str3 = (String) next;
                        String kindOf = TypingKt.kindOf(mainActivity3, str2);
                        if (!kindOf.equals("android")) {
                            List ports = Remote.Kind.ports(kindOf);
                            if (ports.isEmpty()) {
                                continue;
                            } else {
                                Iterator it2 = ports.iterator();
                                while (it2.hasNext()) {
                                    if (MathKt.open(str3, ((Number) it2.next()).intValue(), 1500, null)) {
                                    }
                                }
                            }
                        } else if (!MathKt.open(str3, 5555, 2500, null)) {
                            if (mainActivity3.getPrefs$android_release().getBoolean("atv:".concat(str2), false) && MathKt.open(str3, 6466, 1500, null)) {
                            }
                        }
                    }
                }
                obj = next;
                final String str4 = (String) obj;
                if (str4 != null) {
                    z = true;
                }
                if (!z) {
                    try {
                        long currentTimeMillis2 = 1000 - (System.currentTimeMillis() - currentTimeMillis);
                        if (currentTimeMillis2 < 0) {
                            currentTimeMillis2 = 0;
                        }
                        Thread.sleep(currentTimeMillis2);
                    } catch (InterruptedException unused) {
                    }
                }
                String pref$android_release = mainActivity3.pref$android_release("lan:" + str2);
                if (pref$android_release.length() > 0 && !MathKt.sameNetwork(pref$android_release)) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                mainActivity3.ui.post(new Runnable() { // from class: dev.tvremote.phone.picker.PickerScreenKt$$ExternalSyntheticLambda16
                    @Override // java.lang.Runnable
                    public final void run() {
                        MainActivity mainActivity4 = MainActivity.this;
                        HashSet hashSet = mainActivity4.trying;
                        String str5 = str2;
                        hashSet.remove(str5);
                        HashMap hashMap3 = mainActivity4.route;
                        String str6 = str4;
                        if (str6 != null) {
                            hashMap3.put(str5, str6);
                        } else {
                            hashMap3.remove(str5);
                        }
                        boolean z3 = z;
                        mainActivity4.reach.put(str5, Boolean.valueOf(z3));
                        mainActivity4.awayFrom.put(str5, Boolean.valueOf(z2));
                        PickerScreenKt.showReach(mainActivity4, str5, Boolean.valueOf(z3));
                    }
                });
                return;
            case 3:
                String str5 = this.f$1;
                MainActivity mainActivity4 = this.f$0;
                if (str5 == null) {
                    Fleet.say(mainActivity4, Fleet.T("gpad.off", new Pair[0]), true);
                    return;
                } else {
                    mainActivity4.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str5)));
                    return;
                }
            case 4:
                MainActivity mainActivity5 = this.f$0;
                String str6 = mainActivity5.entry;
                Handler handler = mainActivity5.ui;
                String str7 = this.f$1;
                if (str6 == null) {
                    str6 = str7;
                }
                String kindOf2 = TypingKt.kindOf(mainActivity5, str6);
                File filesDir = mainActivity5.getFilesDir();
                Intrinsics.checkNotNullExpressionValue(filesDir, "getFilesDir(...)");
                Remote of = Vidaa.Companion.of(filesDir, kindOf2, str7);
                try {
                    of.connect(new AdbHelpKt$$ExternalSyntheticLambda47(mainActivity5, of, str7, 3));
                    handler.post(new KeysOnlyKt$$ExternalSyntheticLambda2(of, mainActivity5, str7));
                    return;
                } catch (Exception e) {
                    of.close();
                    handler.post(new KeysOnlyKt$$ExternalSyntheticLambda3(mainActivity5, str7, e, 0));
                    return;
                }
            default:
                TypingKt.startBasic(this.f$0, this.f$1, true);
                return;
        }
    }

    public /* synthetic */ AdbHelpKt$$ExternalSyntheticLambda63(String str, MainActivity mainActivity, int i) {
        this.$r8$classId = i;
        this.f$1 = str;
        this.f$0 = mainActivity;
    }
}
