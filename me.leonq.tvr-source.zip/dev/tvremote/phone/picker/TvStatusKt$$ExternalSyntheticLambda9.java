package dev.tvremote.phone.picker;

import android.widget.LinearLayout;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.remote.Lg$$ExternalSyntheticLambda2;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.ui.UiKt;
import dev.tvremote.tvapps.ApkCert$$ExternalSyntheticLambda0;
import dev.tvremote.update.Ed25519;
import java.util.ArrayList;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.collections.EmptyList;

/* loaded from: classes.dex */
public final /* synthetic */ class TvStatusKt$$ExternalSyntheticLambda9 implements Runnable {
    public final /* synthetic */ int $r8$classId = 1;
    public final /* synthetic */ ArrayList f$0;
    public final /* synthetic */ MainActivity f$1;

    public /* synthetic */ TvStatusKt$$ExternalSyntheticLambda9(MainActivity mainActivity, ArrayList arrayList) {
        this.f$1 = mainActivity;
        this.f$0 = arrayList;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Object obj;
        String T;
        switch (this.$r8$classId) {
            case 0:
                ArrayList arrayList = this.f$0;
                MainActivity mainActivity = this.f$1;
                try {
                    try {
                        boolean z = TvStatus.shots;
                        Ed25519.Pt pt = TvStatus.board;
                        if (pt == null) {
                            pt = new Ed25519.Pt(new ApkCert$$ExternalSyntheticLambda0(15));
                            TvStatus.board = pt;
                        }
                        obj = pt.round(arrayList);
                    } catch (Exception unused) {
                        obj = EmptyList.INSTANCE;
                    }
                    mainActivity.ui.post(new Lg$$ExternalSyntheticLambda2(mainActivity, obj, arrayList, 26));
                    return;
                } finally {
                    TvStatus.busy.set(false);
                }
            default:
                MainActivity mainActivity2 = this.f$1;
                mainActivity2.getScanBtn$android_release().setEnabled(true);
                UiKt.setLabel(mainActivity2.getScanBtn$android_release(), "@search|" + Fleet.T("picker.scan_the_wi_fi", new Pair[0]));
                if (mainActivity2.getFoundList$android_release().getChildCount() == 0) {
                    LinearLayout foundList$android_release = mainActivity2.getFoundList$android_release();
                    ArrayList arrayList2 = this.f$0;
                    if (arrayList2.isEmpty()) {
                        T = Fleet.T("picker.the_phone_is_not", new Pair[0]);
                    } else {
                        T = Fleet.T("picker.scanned", new Pair("nets", CollectionsKt.joinToString$default(arrayList2, ", ", null, null, new ApkCert$$ExternalSyntheticLambda0(10), 30)));
                    }
                    foundList$android_release.addView(UiKt.note(mainActivity2, T));
                    return;
                }
                return;
        }
    }

    public /* synthetic */ TvStatusKt$$ExternalSyntheticLambda9(ArrayList arrayList, MainActivity mainActivity) {
        this.f$0 = arrayList;
        this.f$1 = mainActivity;
    }
}
