package dev.tvremote.phone.picker;

import dev.tvremote.core.Census$$ExternalSyntheticLambda4;
import dev.tvremote.core.Downloader;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.remote.Atv;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda14;
import dev.tvremote.phone.media.MediaKt$$ExternalSyntheticLambda10;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.phone.ui.UiKt;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final /* synthetic */ class AdbHelpKt$$ExternalSyntheticLambda18 implements Function0 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ Remote f$1;

    public /* synthetic */ AdbHelpKt$$ExternalSyntheticLambda18(MainActivity mainActivity, Remote remote, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
        this.f$1 = remote;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        Atv atv;
        int i = 2;
        int i2 = 4;
        Remote a = this.f$1;
        MainActivity mainActivity = this.f$0;
        switch (this.$r8$classId) {
            case 0:
                AdbHelpKt.openHome(mainActivity, a, new AdbHelpKt$$ExternalSyntheticLambda18(mainActivity, a, i));
                return Unit.INSTANCE;
            case 1:
                AdbHelpKt.openOnTv(mainActivity, a, "dev.tvremote.setup", true, new Census$$ExternalSyntheticLambda4(18));
                return Unit.INSTANCE;
            case 2:
                Popup.Builder builder = new Popup.Builder(mainActivity);
                builder.title = "TV Home";
                builder.message = Fleet.T("setup.home_look_own", new Pair[0]);
                builder.setPositiveButton(Fleet.T("setup.adb_steps_btn", new Pair[0]), new MainActivity$$ExternalSyntheticLambda14(mainActivity, 8));
                builder.setNeutralButton(Fleet.T("adb_help.open_again", new Pair[0]), new MediaKt$$ExternalSyntheticLambda10(i2, mainActivity, a));
                builder.setNegativeButton(Fleet.T("setup.choose_another", new Pair[0]), new MainActivity$$ExternalSyntheticLambda14(mainActivity, 9));
                builder.show();
                return Unit.INSTANCE;
            case 3:
                AdbHelpKt.openOnTv(mainActivity, a, "dev.tvremote.setup", true, new Census$$ExternalSyntheticLambda4(18));
                return Unit.INSTANCE;
            case 4:
                boolean z = UiKt.LIGHT;
                String str = (String) Downloader.codes().get("setup");
                if (str == null) {
                    str = "";
                }
                Intrinsics.checkNotNullParameter(mainActivity, "<this>");
                Intrinsics.checkNotNullParameter(a, "a");
                for (int i3 = 0; i3 < 40; i3++) {
                    a.pulse(19, 70L);
                }
                for (int i4 = 0; i4 < 4; i4++) {
                    a.pulse(22, 110L);
                }
                for (int i5 = 0; i5 < 2; i5++) {
                    a.pulse(21, 110L);
                }
                Thread.sleep(5700L);
                a.pulse(23, 110L);
                Thread.sleep(2500L);
                if (a instanceof Atv) {
                    atv = (Atv) a;
                } else {
                    atv = null;
                }
                if (atv != null) {
                    atv.keys(str);
                } else {
                    a.text(str);
                }
                Thread.sleep((str.length() * 60) + 1000);
                a.key(66, 3);
                return Unit.INSTANCE;
            default:
                AdbHelpKt.openOnTv(mainActivity, a, "com.esaba.downloader", true, new Census$$ExternalSyntheticLambda4(18));
                return Unit.INSTANCE;
        }
    }
}
