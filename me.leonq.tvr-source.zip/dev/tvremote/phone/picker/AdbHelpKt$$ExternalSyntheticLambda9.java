package dev.tvremote.phone.picker;

import android.content.DialogInterface;
import android.widget.EditText;
import android.widget.Toast;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.adb.AdbTls;
import dev.tvremote.core.manage.HomeApi$$ExternalSyntheticLambda1;
import dev.tvremote.core.remote.Vidaa$$ExternalSyntheticLambda3;
import dev.tvremote.phone.MainActivity;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.StringsKt;

/* loaded from: classes.dex */
public final /* synthetic */ class AdbHelpKt$$ExternalSyntheticLambda9 implements DialogInterface.OnClickListener {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;
    public final /* synthetic */ Object f$1;
    public final /* synthetic */ MainActivity f$2;
    public final /* synthetic */ Serializable f$3;

    public /* synthetic */ AdbHelpKt$$ExternalSyntheticLambda9(EditText editText, Object obj, MainActivity mainActivity, String str, int i) {
        this.$r8$classId = i;
        this.f$0 = editText;
        this.f$1 = obj;
        this.f$2 = mainActivity;
        this.f$3 = str;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i) {
        MainActivity mainActivity = this.f$2;
        Object obj = this.f$3;
        Object obj2 = this.f$1;
        Object obj3 = this.f$0;
        switch (this.$r8$classId) {
            case 0:
                Pattern compile = Pattern.compile("^(?:(.+):)?(\\d{2,5})$");
                Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                String input = StringsKt.trim(((EditText) obj3).getText().toString()).toString();
                Intrinsics.checkNotNullParameter(input, "input");
                Matcher matcher = compile.matcher(input);
                Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
                MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, input);
                AdbTls adbTls = AdbTls.INSTANCE;
                String cleanCode = AdbTls.cleanCode(((EditText) obj2).getText().toString());
                MainActivity mainActivity2 = this.f$2;
                if (access$findNext != null && cleanCode != null) {
                    CharSequence charSequence = (CharSequence) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1);
                    if (charSequence.length() == 0) {
                        CharSequence charSequence2 = (String) obj;
                        if (charSequence2 == null) {
                            charSequence = "";
                        } else {
                            charSequence = charSequence2;
                        }
                    }
                    Toast.makeText(mainActivity2, Fleet.T("setup.pairing", new Pair[0]), 0).show();
                    new Thread(new Vidaa$$ExternalSyntheticLambda3((Object) mainActivity2, (String) charSequence, (Object) access$findNext, cleanCode, 7)).start();
                    return;
                }
                Toast.makeText(mainActivity2, Fleet.T("setup.enter_addr_code", new Pair[0]), 1).show();
                return;
            case 1:
                ArrayList arrayList = new ArrayList();
                Iterator it = ((ArrayList) obj3).iterator();
                int i2 = 0;
                while (it.hasNext()) {
                    Object next = it.next();
                    int i3 = i2 + 1;
                    if (i2 >= 0) {
                        if (((boolean[]) obj)[i2]) {
                            arrayList.add(next);
                        }
                        i2 = i3;
                    } else {
                        CollectionsKt__CollectionsKt.throwIndexOverflow();
                        throw null;
                    }
                }
                if (arrayList.isEmpty()) {
                    ManyTvsKt.toast(mainActivity, Fleet.T("fleet.pick_one", new Pair[0]));
                    return;
                } else {
                    ((Function1) obj2).invoke(arrayList);
                    return;
                }
            case 2:
                ManyTvsKt.fleetRun$default(mainActivity, Fleet.T("many_tvs.remove", new Pair("what", (String) obj)), (List) obj3, new HomeApi$$ExternalSyntheticLambda1(2, (ArrayList) obj2), 12);
                return;
            default:
                new Thread(new Vidaa$$ExternalSyntheticLambda3(obj2, ((EditText) obj3).getText().toString(), (Object) this.f$2, (String) obj, 13)).start();
                return;
        }
    }

    public /* synthetic */ AdbHelpKt$$ExternalSyntheticLambda9(MainActivity mainActivity, String str, List list, ArrayList arrayList) {
        this.$r8$classId = 2;
        this.f$2 = mainActivity;
        this.f$3 = str;
        this.f$0 = list;
        this.f$1 = arrayList;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public /* synthetic */ AdbHelpKt$$ExternalSyntheticLambda9(ArrayList arrayList, MainActivity mainActivity, Function1 function1, boolean[] zArr) {
        this.$r8$classId = 1;
        this.f$0 = arrayList;
        this.f$2 = mainActivity;
        this.f$1 = function1;
        this.f$3 = zArr;
    }
}
