package dev.tvremote.phone.picker;

import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.RippleDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkRequest;
import android.os.Build;
import android.os.Handler;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.FleetStatus;
import dev.tvremote.core.SameTv$Tv;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda8;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda15;
import dev.tvremote.phone.media.MediaKt$$ExternalSyntheticLambda4;
import dev.tvremote.phone.remote.TypingKt;
import dev.tvremote.phone.ui.IconButton;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.phone.ui.UiKt;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.WeakHashMap;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;

/* loaded from: classes.dex */
public abstract class PickerScreenKt {
    public static final List PER_TV = ArraysKt.asList(new String[]{"name", "mac", "lan", "ts", "tvs", "kind"});
    public static final Regex MOBILE = new Regex("^(rmnet|ccmni|pdp|v4-|clat|seth|wwan|tun|ppp|ipsec)");

    public static final void askRemove(MainActivity mainActivity, String ip) {
        String concat;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Intrinsics.checkNotNullParameter(ip, "ip");
        Popup.Builder builder = new Popup.Builder(mainActivity);
        String T = Fleet.T("picker.remove_this_tv_from", new Pair[0]);
        String title$android_release = mainActivity.title$android_release(ip);
        if (name(mainActivity, ip).length() == 0) {
            concat = "";
        } else {
            concat = " · ".concat(ip);
        }
        builder.message = T + "\n" + title$android_release + concat + "\n\n" + Fleet.T("picker.nothing_changes_on_the", new Pair[0]);
        builder.setPositiveButton(Fleet.T("picker.remove", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda54(mainActivity, ip, 1));
        builder.setNegativeButton(Fleet.T("common.cancel", new Pair[0]), null);
        builder.show();
    }

    /* JADX WARN: Removed duplicated region for block: B:38:0x00c4 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:42:0x0065 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void foldSaved(MainActivity mainActivity, String str) {
        boolean z;
        boolean z2;
        boolean z3;
        Object obj;
        Object obj2;
        boolean z4;
        boolean z5;
        boolean z6;
        boolean z7;
        boolean z8;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        ArrayList savedIps = savedIps(mainActivity);
        if (str != null && savedIps.contains(str)) {
            List listOf = MathKt.listOf(str);
            ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(savedIps));
            Iterator it = savedIps.iterator();
            boolean z9 = false;
            while (it.hasNext()) {
                Object next = it.next();
                if (!z9 && Intrinsics.areEqual(next, str)) {
                    z9 = true;
                    z8 = false;
                } else {
                    z8 = true;
                }
                if (z8) {
                    arrayList.add(next);
                }
            }
            savedIps = CollectionsKt.plus(listOf, (Iterable) arrayList);
        }
        ArrayList mutableList = CollectionsKt.toMutableList((Collection) savedIps);
        ArrayList arrayList2 = new ArrayList();
        while (!mutableList.isEmpty()) {
            Object remove = mutableList.remove(0);
            ArrayList arrayList3 = new ArrayList();
            Iterator it2 = mutableList.iterator();
            while (it2.hasNext()) {
                Object next2 = it2.next();
                String it3 = (String) remove;
                Intrinsics.checkNotNullParameter(it3, "it");
                SameTv$Tv savedTv = savedTv(mainActivity, it3);
                String it4 = (String) next2;
                Intrinsics.checkNotNullParameter(it4, "it");
                SameTv$Tv savedTv2 = savedTv(mainActivity, it4);
                String str2 = savedTv.host;
                if (str2.length() != 0) {
                    String str3 = savedTv2.host;
                    if (str3.length() != 0) {
                        String str4 = savedTv.mac;
                        if (str4.length() > 0) {
                            String str5 = savedTv2.mac;
                            if (str5.length() > 0) {
                                z7 = str4.equalsIgnoreCase(str5);
                                if (z7) {
                                    arrayList3.add(next2);
                                }
                            }
                        }
                        if (savedTv2.getAddresses().contains(str2) || savedTv.getAddresses().contains(str3)) {
                            z7 = true;
                            if (z7) {
                            }
                        }
                    }
                }
                z7 = false;
                if (z7) {
                }
            }
            mutableList.removeAll(arrayList3);
            arrayList2.add(new Pair(remove, arrayList3));
        }
        if (!arrayList2.isEmpty()) {
            Iterator it5 = arrayList2.iterator();
            while (it5.hasNext()) {
                if (!((List) ((Pair) it5.next()).second).isEmpty()) {
                    z = false;
                    break;
                }
            }
        }
        z = true;
        if (z) {
            return;
        }
        SharedPreferences.Editor edit = mainActivity.getPrefs$android_release().edit();
        Iterator it6 = arrayList2.iterator();
        while (it6.hasNext()) {
            Pair pair = (Pair) it6.next();
            String str6 = (String) pair.first;
            for (String str7 : (List) pair.second) {
                for (String str8 : ArraysKt.asList(new String[]{"name", "mac", "tvs"})) {
                    if (mainActivity.pref$android_release(str8 + ":" + str6).length() == 0) {
                        z5 = true;
                    } else {
                        z5 = false;
                    }
                    if (z5) {
                        if (mainActivity.pref$android_release(str8 + ":" + str7).length() > 0) {
                            z6 = true;
                        } else {
                            z6 = false;
                        }
                        if (z6) {
                            edit.putString(Census$$ExternalSyntheticOutline0.m(str8, ":", str6), mainActivity.pref$android_release(str8 + ":" + str7));
                        }
                    }
                }
                Set addresses = savedTv(mainActivity, str7).getAddresses();
                LinkedHashSet linkedHashSet = new LinkedHashSet(MapsKt__MapsKt.mapCapacity(addresses.size()));
                boolean z10 = false;
                for (Object obj3 : addresses) {
                    if (!z10 && Intrinsics.areEqual(obj3, str6)) {
                        z10 = true;
                        z4 = false;
                    } else {
                        z4 = true;
                    }
                    if (z4) {
                        linkedHashSet.add(obj3);
                    }
                }
                if (mainActivity.pref$android_release("lan:" + str6).length() == 0) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                if (z2) {
                    Iterator it7 = linkedHashSet.iterator();
                    while (true) {
                        if (it7.hasNext()) {
                            obj2 = it7.next();
                            if (!StringsKt__StringsJVMKt.startsWith((String) obj2, false, "100.")) {
                                break;
                            }
                        } else {
                            obj2 = null;
                            break;
                        }
                    }
                    String str9 = (String) obj2;
                    if (str9 != null) {
                        edit.putString("lan:" + str6, str9);
                    }
                }
                if (mainActivity.pref$android_release("ts:" + str6).length() == 0) {
                    z3 = true;
                } else {
                    z3 = false;
                }
                if (z3) {
                    Iterator it8 = linkedHashSet.iterator();
                    while (true) {
                        if (it8.hasNext()) {
                            Object next3 = it8.next();
                            if (StringsKt__StringsJVMKt.startsWith((String) next3, false, "100.")) {
                                obj = next3;
                                break;
                            }
                        } else {
                            obj = null;
                            break;
                        }
                    }
                    String str10 = (String) obj;
                    if (str10 != null) {
                        edit.putString("ts:" + str6, str10);
                    }
                }
                if (mainActivity.getPrefs$android_release().getBoolean("atv:".concat(str7), false)) {
                    edit.putBoolean("atv:" + str6, true);
                }
                Iterator it9 = PER_TV.iterator();
                while (it9.hasNext()) {
                    edit.remove(((String) it9.next()) + ":" + str7);
                }
                edit.remove("atv:".concat(str7));
            }
        }
        ArrayList arrayList4 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList2));
        Iterator it10 = arrayList2.iterator();
        while (it10.hasNext()) {
            arrayList4.add((String) ((Pair) it10.next()).first);
        }
        edit.putString("ips", TextUtils.join(",", arrayList4)).apply();
    }

    public static final void message(MainActivity mainActivity, String str, boolean z) {
        String str2;
        int i;
        int i2;
        int i3;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        TextView pickerMsg$android_release = mainActivity.getPickerMsg$android_release();
        if (str != null) {
            str2 = str;
        } else {
            str2 = "";
        }
        pickerMsg$android_release.setText(str2);
        TextView pickerMsg$android_release2 = mainActivity.getPickerMsg$android_release();
        if (z) {
            i = UiKt.ERR_TEXT;
        } else {
            i = UiKt.TEXT;
        }
        pickerMsg$android_release2.setTextColor(i);
        TextView pickerMsg$android_release3 = mainActivity.getPickerMsg$android_release();
        if (z) {
            i2 = UiKt.ERR_BG;
        } else {
            i2 = UiKt.CARD;
        }
        pickerMsg$android_release3.setBackground(UiKt.box(mainActivity, i2, 12));
        TextView pickerMsg$android_release4 = mainActivity.getPickerMsg$android_release();
        if (str == null) {
            i3 = 8;
        } else {
            i3 = 0;
        }
        pickerMsg$android_release4.setVisibility(i3);
    }

    public static final String name(MainActivity mainActivity, String ip) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Intrinsics.checkNotNullParameter(ip, "ip");
        return mainActivity.pref$android_release("name:".concat(ip));
    }

    public static final String reachWords(MainActivity mainActivity, String ip, Boolean bool) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Intrinsics.checkNotNullParameter(ip, "ip");
        if (bool == null) {
            return Fleet.T("picker.checking", new Pair[0]);
        }
        if (bool.equals(Boolean.FALSE)) {
            if (mainActivity.trying.contains(ip)) {
                return Fleet.T("picker.trying_again", new Pair[0]);
            }
            if (Intrinsics.areEqual(mainActivity.awayFrom.get(ip), Boolean.TRUE)) {
                return Fleet.T("picker.no_answer_you_are", new Pair[0]);
            }
            return Fleet.T("picker.no_answer_tv_off", new Pair[0]);
        }
        if (bool.equals(Boolean.TRUE)) {
            String str = (String) mainActivity.route.get(ip);
            if (str != null && !str.equals(ip)) {
                if (StringsKt__StringsJVMKt.startsWith(str, false, "100.")) {
                    return Fleet.T("picker.reachable_through_tailscale", new Pair[0]);
                }
                return Fleet.T("picker.reachable_at_home", new Pair[0]);
            }
            return Fleet.T("picker.reachable", new Pair[0]);
        }
        throw new RuntimeException();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r3v21 */
    /* JADX WARN: Type inference failed for: r3v23 */
    /* JADX WARN: Type inference failed for: r3v6, types: [boolean, int] */
    public static final void refreshSaved(final MainActivity mainActivity) {
        int i;
        int i2;
        int i3 = 8;
        boolean z = true;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        foldSaved(mainActivity, null);
        mainActivity.getSavedList$android_release().removeAllViews();
        mainActivity.savedRows.clear();
        TvStatus.thumbs.clear();
        TvStatus.cards.clear();
        String str = "@close";
        int i4 = -1;
        if (!TvStatus.shots || savedIps(mainActivity).isEmpty()) {
            String str2 = "@close";
            Iterator it = savedIps(mainActivity).iterator();
            while (it.hasNext()) {
                String str3 = (String) it.next();
                Button row = UiKt.row(mainActivity, "", new MediaKt$$ExternalSyntheticLambda4(mainActivity, str3, 7));
                IconButton icon = UiKt.icon(mainActivity, "@power", Fleet.T("remote.wake", new Pair[0]), UiKt.BTN);
                icon.setOnClickListener(new TvStatusKt$$ExternalSyntheticLambda5(mainActivity, str3, 1));
                icon.setVisibility(8);
                mainActivity.savedRows.put(str3, new Pair(row, icon));
                showReach(mainActivity, str3, (Boolean) mainActivity.reach.get(str3));
                LinearLayout linearLayout = new LinearLayout(mainActivity);
                linearLayout.addView(row, new LinearLayout.LayoutParams(0, -2, 1.0f));
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(UiKt.dp(mainActivity, 60), -1);
                float f = 6;
                layoutParams.leftMargin = UiKt.dp(mainActivity, f);
                linearLayout.addView(icon, layoutParams);
                linearLayout.setLayoutParams(UiKt.gap(mainActivity, 6));
                MediaKt$$ExternalSyntheticLambda4 mediaKt$$ExternalSyntheticLambda4 = new MediaKt$$ExternalSyntheticLambda4(mainActivity, str3, 8);
                String str4 = str2;
                IconButton icon2 = UiKt.icon(mainActivity, str4, Fleet.T("picker.remove_this_tv_from_the", new Pair[0]), UiKt.BTN);
                icon2.setOnClickListener(new Guard$$ExternalSyntheticLambda8(6, mediaKt$$ExternalSyntheticLambda4));
                LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(UiKt.dp(mainActivity, 48), -1);
                layoutParams2.leftMargin = UiKt.dp(mainActivity, f);
                linearLayout.addView(icon2, layoutParams2);
                row.setOnLongClickListener(new PickerScreenKt$$ExternalSyntheticLambda4(0, mediaKt$$ExternalSyntheticLambda4));
                mainActivity.getSavedList$android_release().addView(linearLayout);
                str2 = str4;
            }
        } else {
            ArrayList savedIps = savedIps(mainActivity);
            WeakHashMap weakHashMap = TvStatusKt.tickFor;
            Iterator it2 = CollectionsKt.chunked(savedIps, 2).iterator();
            while (it2.hasNext()) {
                List list = (List) it2.next();
                LinearLayout linearLayout2 = new LinearLayout(mainActivity);
                linearLayout2.setLayoutParams(UiKt.gap(mainActivity, i3));
                Iterator it3 = list.iterator();
                int i5 = 0;
                ?? r3 = z;
                while (it3.hasNext()) {
                    int i6 = i5 + 1;
                    final String str5 = (String) it3.next();
                    LinearLayout linearLayout3 = new LinearLayout(mainActivity);
                    linearLayout3.setOrientation(r3);
                    linearLayout3.setBackground(UiKt.box(mainActivity, UiKt.CARD, 14));
                    linearLayout3.setClipToOutline(r3);
                    linearLayout3.setClickable(r3);
                    if (Build.VERSION.SDK_INT >= 23) {
                        linearLayout3.setForeground(new RippleDrawable(ColorStateList.valueOf(872415231), null, UiKt.box(mainActivity, i4, 14)));
                    }
                    linearLayout3.setOnClickListener(new TvStatusKt$$ExternalSyntheticLambda5(mainActivity, str5, 0));
                    linearLayout3.setOnLongClickListener(new View.OnLongClickListener() { // from class: dev.tvremote.phone.picker.TvStatusKt$$ExternalSyntheticLambda6
                        @Override // android.view.View.OnLongClickListener
                        public final boolean onLongClick(View view) {
                            PickerScreenKt.askRemove(MainActivity.this, str5);
                            return true;
                        }
                    });
                    FrameLayout frameLayout = new FrameLayout(mainActivity);
                    frameLayout.setBackgroundColor(-16053233);
                    ImageView imageView = new ImageView(mainActivity);
                    imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    frameLayout.addView(imageView, new FrameLayout.LayoutParams(-1, -1));
                    TextView label = UiKt.label(mainActivity, "", 12, UiKt.MUTED);
                    label.setGravity(17);
                    frameLayout.addView(label, new FrameLayout.LayoutParams(-1, -1));
                    IconButton icon3 = UiKt.icon(mainActivity, "@power", Fleet.T("remote.wake", new Pair[0]), UiKt.BTN);
                    icon3.setOnClickListener(new TvStatusKt$$ExternalSyntheticLambda5(mainActivity, str5, 4));
                    float f2 = 44;
                    Iterator it4 = it2;
                    Iterator it5 = it3;
                    frameLayout.addView(icon3, new FrameLayout.LayoutParams(UiKt.dp(mainActivity, f2), UiKt.dp(mainActivity, f2), 17));
                    IconButton icon4 = UiKt.icon(mainActivity, str, Fleet.T("picker.remove_this_tv_from_the", new Pair[0]), -1728053248);
                    icon4.setSize(16.0f);
                    icon4.setOnClickListener(new TvStatusKt$$ExternalSyntheticLambda5(mainActivity, str5, 5));
                    float f3 = 30;
                    FrameLayout.LayoutParams layoutParams3 = new FrameLayout.LayoutParams(UiKt.dp(mainActivity, f3), UiKt.dp(mainActivity, f3), 8388661);
                    float f4 = 6;
                    layoutParams3.setMargins(0, UiKt.dp(mainActivity, f4), UiKt.dp(mainActivity, f4), 0);
                    frameLayout.addView(icon4, layoutParams3);
                    linearLayout3.addView(frameLayout, new LinearLayout.LayoutParams(-1, -2));
                    LinearLayout linearLayout4 = new LinearLayout(mainActivity);
                    linearLayout4.setOrientation(1);
                    float f5 = 10;
                    float f6 = 8;
                    linearLayout4.setPadding(UiKt.dp(mainActivity, f5), UiKt.dp(mainActivity, f6), UiKt.dp(mainActivity, f5), UiKt.dp(mainActivity, f5));
                    String name = name(mainActivity, str5);
                    if (name.length() == 0) {
                        name = str5;
                    }
                    TextView label2 = UiKt.label(mainActivity, name, 15, UiKt.TEXT);
                    label2.setSingleLine(true);
                    TextUtils.TruncateAt truncateAt = TextUtils.TruncateAt.END;
                    label2.setEllipsize(truncateAt);
                    label2.setTypeface(Typeface.DEFAULT_BOLD);
                    TextView label3 = UiKt.label(mainActivity, "", 12, UiKt.MUTED);
                    label3.setSingleLine(true);
                    label3.setEllipsize(truncateAt);
                    String str6 = str;
                    TextView label4 = UiKt.label(mainActivity, "", 12, UiKt.MUTED);
                    label4.setSingleLine(true);
                    label4.setEllipsize(truncateAt);
                    linearLayout4.addView(label2);
                    linearLayout4.addView(label3);
                    linearLayout4.addView(label4);
                    linearLayout3.addView(linearLayout4);
                    Card card = new Card(imageView, label, icon3, label2, label3, label4);
                    TvStatus.cards.put(str5, card);
                    TvStatus.thumbs.put(str5, imageView);
                    HashMap hashMap = mainActivity.reach;
                    TvStatusKt.showCard(mainActivity, str5, card, (Boolean) hashMap.get(str5), reachWords(mainActivity, str5, (Boolean) hashMap.get(str5)));
                    LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(0, -2, 1.0f);
                    if (i5 == 1) {
                        layoutParams4.leftMargin = UiKt.dp(mainActivity, f6);
                    }
                    linearLayout2.addView(linearLayout3, layoutParams4);
                    i5 = i6;
                    it2 = it4;
                    it3 = it5;
                    str = str6;
                    r3 = 1;
                    i4 = -1;
                }
                Iterator it6 = it2;
                String str7 = str;
                if (list.size() == 1) {
                    View view = new View(mainActivity);
                    LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(0, 0, 1.0f);
                    layoutParams5.leftMargin = UiKt.dp(mainActivity, 8);
                    linearLayout2.addView(view, layoutParams5);
                }
                mainActivity.getSavedList$android_release().addView(linearLayout2);
                it2 = it6;
                str = str7;
                i3 = 8;
                z = true;
                i4 = -1;
            }
        }
        Button button = mainActivity.fleetBtn;
        if (button != null) {
            if (savedIps(mainActivity).size() >= 2) {
                i = 0;
            } else {
                i = 8;
            }
            button.setVisibility(i);
            Button button2 = mainActivity.screensBtn;
            if (button2 != null) {
                if (!savedIps(mainActivity).isEmpty()) {
                    i2 = 0;
                } else {
                    i2 = 8;
                }
                button2.setVisibility(i2);
                TvStatusKt.showThumbs(mainActivity);
                if (mainActivity.getSavedList$android_release().getChildCount() == 0) {
                    mainActivity.getSavedList$android_release().addView(UiKt.note(mainActivity, Fleet.T("picker.no_tvs_yet_scan", new Pair[0])));
                    return;
                }
                return;
            }
            Intrinsics.throwUninitializedPropertyAccessException("screensBtn");
            throw null;
        }
        Intrinsics.throwUninitializedPropertyAccessException("fleetBtn");
        throw null;
    }

    public static final void save(MainActivity mainActivity, String ip, String model) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Intrinsics.checkNotNullParameter(ip, "ip");
        Intrinsics.checkNotNullParameter(model, "model");
        ArrayList savedIps = savedIps(mainActivity);
        savedIps.remove(ip);
        savedIps.add(0, ip);
        SharedPreferences.Editor putString = mainActivity.getPrefs$android_release().edit().putString("ips", TextUtils.join(",", savedIps));
        if (model.length() > 0) {
            putString.putString("name:".concat(ip), model);
        }
        putString.apply();
    }

    public static final ArrayList savedIps(MainActivity mainActivity) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        List split$default = StringsKt.split$default(mainActivity.pref$android_release("ips"), new String[]{","}, 0, 6);
        ArrayList arrayList = new ArrayList();
        for (Object obj : split$default) {
            if (((String) obj).length() > 0) {
                arrayList.add(obj);
            }
        }
        return CollectionsKt.toMutableList((Collection) arrayList);
    }

    public static final SameTv$Tv savedTv(MainActivity mainActivity, String ip) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Intrinsics.checkNotNullParameter(ip, "ip");
        return new SameTv$Tv(ip, mainActivity.pref$android_release("lan:".concat(ip)), mainActivity.pref$android_release("ts:".concat(ip)), mainActivity.pref$android_release("mac:".concat(ip)));
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x0153  */
    /* JADX WARN: Removed duplicated region for block: B:19:0x015a  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x0169  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0179  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x01a4  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x01b6  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x01db  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x01fa  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x01b9  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x01aa  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x016b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void showReach(MainActivity mainActivity, String ip, Boolean bool) {
        String T;
        String joinToString$default;
        String concat;
        Pair pair;
        String m;
        int i;
        int i2;
        String str;
        int i3 = 0;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Intrinsics.checkNotNullParameter(ip, "ip");
        String reachWords = reachWords(mainActivity, ip, bool);
        Card card = (Card) TvStatus.cards.get(ip);
        if (card != null) {
            TvStatusKt.showCard(mainActivity, ip, card, bool, reachWords);
            return;
        }
        Pair pair2 = (Pair) mainActivity.savedRows.get(ip);
        if (pair2 == null) {
            return;
        }
        Button button = (Button) pair2.first;
        View view = (View) pair2.second;
        String str2 = "";
        String str3 = null;
        if (!Intrinsics.areEqual(bool, Boolean.FALSE)) {
            WeakHashMap weakHashMap = TvStatusKt.tickFor;
            FleetStatus.Status status = (FleetStatus.Status) TvStatus.last.get(ip);
            if (status != null) {
                String str4 = status.state;
                if (Intrinsics.areEqual(str4, "on") || Intrinsics.areEqual(str4, "standby")) {
                    if (Intrinsics.areEqual(str4, "standby")) {
                        joinToString$default = Fleet.T("tvstat.standby", new Pair[0]);
                    } else {
                        String T2 = Fleet.T("tvstat.on", new Pair[0]);
                        if (status.app.length() == 0) {
                            T = "";
                        } else if (status.home) {
                            T = Fleet.T("tvstat.home", new Pair[0]);
                        } else {
                            T = Fleet.T("tvstat.showing", new Pair("app", status.appName));
                        }
                        List asList = ArraysKt.asList(new String[]{T2, T});
                        ArrayList arrayList = new ArrayList();
                        for (Object obj : asList) {
                            if (((String) obj).length() > 0) {
                                arrayList.add(obj);
                            }
                        }
                        joinToString$default = CollectionsKt.joinToString$default(arrayList, " · ", null, null, null, 62);
                    }
                    String str5 = status.model;
                    if (str5.length() > 24) {
                        str5 = Census$$ExternalSyntheticOutline0.m(StringsKt.trimEnd(StringsKt.take(str5, 23)).toString(), "…");
                    }
                    String m2 = ApkSigner$$ExternalSyntheticOutline0.m("● ", joinToString$default);
                    String str6 = status.android;
                    if (str6.length() == 0) {
                        concat = "";
                    } else {
                        concat = "Android ".concat(str6);
                    }
                    List asList2 = ArraysKt.asList(new String[]{str5, concat});
                    ArrayList arrayList2 = new ArrayList();
                    for (Object obj2 : asList2) {
                        if (((String) obj2).length() > 0) {
                            arrayList2.add(obj2);
                        }
                    }
                    pair = new Pair(m2, CollectionsKt.joinToString$default(arrayList2, " · ", null, null, null, 62));
                    if (pair != null && (str = (String) pair.first) != null) {
                        reachWords = str;
                    }
                    if (pair != null) {
                        str3 = (String) pair.second;
                    }
                    if (str3 == null) {
                        str3 = "";
                    }
                    if (name(mainActivity, ip).length() != 0) {
                        m = ip;
                    } else {
                        m = Census$$ExternalSyntheticOutline0.m(name(mainActivity, ip), "\n", ip);
                    }
                    if (str3.length() > 0) {
                        str2 = "\n".concat(str3);
                    }
                    SpannableString spannableString = new SpannableString(m + "\n" + reachWords + str2);
                    int length = spannableString.length() - reachWords.length();
                    if (str3.length() <= 0) {
                        i = str3.length() + 1;
                    } else {
                        i = 0;
                    }
                    int i4 = length - i;
                    if (!Intrinsics.areEqual(bool, Boolean.TRUE)) {
                        i2 = UiKt.OK_TEXT;
                    } else {
                        i2 = UiKt.MUTED;
                    }
                    spannableString.setSpan(new ForegroundColorSpan(i2), i4, reachWords.length() + i4, 0);
                    spannableString.setSpan(new RelativeSizeSpan(0.82f), i4, spannableString.length(), 0);
                    if (str3.length() > 0) {
                        spannableString.setSpan(new ForegroundColorSpan(UiKt.MUTED), reachWords.length() + i4, spannableString.length(), 0);
                    }
                    button.setText(spannableString);
                    if (!Intrinsics.areEqual(bool, Boolean.FALSE)) {
                        i3 = 8;
                    }
                    view.setVisibility(i3);
                }
            }
        }
        pair = null;
        if (pair != null) {
            reachWords = str;
        }
        if (pair != null) {
        }
        if (str3 == null) {
        }
        if (name(mainActivity, ip).length() != 0) {
        }
        if (str3.length() > 0) {
        }
        SpannableString spannableString2 = new SpannableString(m + "\n" + reachWords + str2);
        int length2 = spannableString2.length() - reachWords.length();
        if (str3.length() <= 0) {
        }
        int i42 = length2 - i;
        if (!Intrinsics.areEqual(bool, Boolean.TRUE)) {
        }
        spannableString2.setSpan(new ForegroundColorSpan(i2), i42, reachWords.length() + i42, 0);
        spannableString2.setSpan(new RelativeSizeSpan(0.82f), i42, spannableString2.length(), 0);
        if (str3.length() > 0) {
        }
        button.setText(spannableString2);
        if (!Intrinsics.areEqual(bool, Boolean.FALSE)) {
        }
        view.setVisibility(i3);
    }

    public static final void wake(MainActivity mainActivity, String ip) {
        int intValue;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Intrinsics.checkNotNullParameter(ip, "ip");
        if (mainActivity.waking) {
            return;
        }
        mainActivity.waking = true;
        String pref$android_release = mainActivity.pref$android_release("mac:".concat(ip));
        String pref$android_release2 = mainActivity.pref$android_release("lan:".concat(ip));
        message(mainActivity, Fleet.T("picker.waking", new Pair("name", mainActivity.title$android_release(ip))), false);
        String kindOf = TypingKt.kindOf(mainActivity, ip);
        if (kindOf.equals("android")) {
            intValue = 5555;
        } else {
            intValue = ((Number) CollectionsKt.first(Remote.Kind.ports(kindOf))).intValue();
        }
        new Thread(new PickerScreenKt$$ExternalSyntheticLambda15(ip, intValue, pref$android_release, pref$android_release2, mainActivity)).start();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v4, types: [android.net.ConnectivityManager$NetworkCallback, dev.tvremote.phone.picker.PickerScreenKt$watchNetworks$cb$1] */
    public static final void watchNetworks(final MainActivity mainActivity, boolean z) {
        Object systemService = mainActivity.getSystemService("connectivity");
        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.net.ConnectivityManager");
        ConnectivityManager connectivityManager = (ConnectivityManager) systemService;
        PickerScreenKt$watchNetworks$cb$1 pickerScreenKt$watchNetworks$cb$1 = mainActivity.netWatch;
        if (pickerScreenKt$watchNetworks$cb$1 != null) {
            try {
                connectivityManager.unregisterNetworkCallback(pickerScreenKt$watchNetworks$cb$1);
            } catch (Exception unused) {
            }
        }
        mainActivity.netWatch = null;
        if (z) {
            final MainActivity$$ExternalSyntheticLambda15 mainActivity$$ExternalSyntheticLambda15 = new MainActivity$$ExternalSyntheticLambda15(mainActivity, 15);
            ?? r1 = new ConnectivityManager.NetworkCallback() { // from class: dev.tvremote.phone.picker.PickerScreenKt$watchNetworks$cb$1
                @Override // android.net.ConnectivityManager.NetworkCallback
                public final void onAvailable(Network n) {
                    Intrinsics.checkNotNullParameter(n, "n");
                    Handler handler = MainActivity.this.ui;
                    MainActivity$$ExternalSyntheticLambda15 mainActivity$$ExternalSyntheticLambda152 = mainActivity$$ExternalSyntheticLambda15;
                    handler.removeCallbacks(mainActivity$$ExternalSyntheticLambda152);
                    handler.postDelayed(mainActivity$$ExternalSyntheticLambda152, 1500L);
                }

                @Override // android.net.ConnectivityManager.NetworkCallback
                public final void onLost(Network n) {
                    Intrinsics.checkNotNullParameter(n, "n");
                    Handler handler = MainActivity.this.ui;
                    MainActivity$$ExternalSyntheticLambda15 mainActivity$$ExternalSyntheticLambda152 = mainActivity$$ExternalSyntheticLambda15;
                    handler.removeCallbacks(mainActivity$$ExternalSyntheticLambda152);
                    handler.postDelayed(mainActivity$$ExternalSyntheticLambda152, 1500L);
                }
            };
            try {
                connectivityManager.registerNetworkCallback(new NetworkRequest.Builder().build(), (ConnectivityManager.NetworkCallback) r1);
                mainActivity.netWatch = r1;
            } catch (Exception unused2) {
            }
        }
    }
}
