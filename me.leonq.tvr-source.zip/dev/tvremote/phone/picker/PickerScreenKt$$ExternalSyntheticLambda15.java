package dev.tvremote.phone.picker;

import com.android.apksig.internal.util.VerityTreeBuilder;
import dev.tvremote.core.Fleet;
import dev.tvremote.phone.MainActivity;
import java.io.Serializable;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.concurrent.Phaser;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;

/* loaded from: classes.dex */
public final /* synthetic */ class PickerScreenKt$$ExternalSyntheticLambda15 implements Runnable {
    public final /* synthetic */ int $r8$classId = 1;
    public final /* synthetic */ Object f$0;
    public final /* synthetic */ int f$1;
    public final /* synthetic */ Comparable f$2;
    public final /* synthetic */ Serializable f$3;
    public final /* synthetic */ Object f$4;

    /* JADX WARN: Multi-variable type inference failed */
    public /* synthetic */ PickerScreenKt$$ExternalSyntheticLambda15(VerityTreeBuilder verityTreeBuilder, ByteBuffer byteBuffer, int i, byte[][] bArr, Phaser phaser) {
        this.f$0 = verityTreeBuilder;
        this.f$2 = byteBuffer;
        this.f$1 = i;
        this.f$3 = bArr;
        this.f$4 = phaser;
    }

    /* JADX WARN: Code restructure failed: missing block: B:63:0x0233, code lost:
    
        r8 = true;
     */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void run() {
        boolean z;
        boolean z2;
        DatagramSocket datagramSocket;
        Throwable th;
        int i;
        MessageDigest messageDigest;
        switch (this.$r8$classId) {
            case 0:
                final String str = (String) this.f$0;
                int i2 = this.f$1;
                boolean open = MathKt.open(str, i2, 1500, null);
                final String str2 = (String) this.f$2;
                int length = str2.length();
                String str3 = (String) this.f$3;
                if (length == 0 || !MathKt.sameNetwork(str3)) {
                    z = true;
                } else {
                    z = false;
                }
                boolean z3 = open;
                int i3 = 0;
                int i4 = 0;
                while (i3 < 22 && !z3 && !z) {
                    if (i3 % 6 == 0 && str2.length() > 0) {
                        String str4 = "iterator(...)";
                        String replace$default = StringsKt__StringsJVMKt.replace$default(StringsKt__StringsJVMKt.replace$default(str2, ":", ""), "-", "");
                        if (replace$default.length() == 12) {
                            byte[] bArr = new byte[102];
                            for (int i5 = 0; i5 < 6; i5++) {
                                bArr[i5] = -1;
                            }
                            int i6 = 0;
                            while (i6 < 96) {
                                int i7 = i6 + 6;
                                int i8 = (i6 % 6) * 2;
                                int i9 = i6;
                                String substring = replace$default.substring(i8, i8 + 2);
                                Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
                                MathKt.checkRadix(16);
                                bArr[i7] = (byte) Integer.parseInt(substring, 16);
                                i6 = i9 + 1;
                            }
                            LinkedHashSet linkedHashSet = new LinkedHashSet();
                            try {
                                linkedHashSet.add(InetAddress.getByName("255.255.255.255"));
                                if (StringsKt.lastIndexOf$default(str3, '.', 6) > 0) {
                                    try {
                                        String substring2 = str3.substring(0, StringsKt.lastIndexOf$default(str3, '.', 6));
                                        Intrinsics.checkNotNullExpressionValue(substring2, "substring(...)");
                                        linkedHashSet.add(InetAddress.getByName(substring2 + ".255"));
                                    } catch (Exception unused) {
                                    }
                                }
                                Iterator it = Collections.list(NetworkInterface.getNetworkInterfaces()).iterator();
                                Intrinsics.checkNotNullExpressionValue(it, "iterator(...)");
                                while (it.hasNext()) {
                                    NetworkInterface networkInterface = (NetworkInterface) it.next();
                                    if (networkInterface.isUp() && !networkInterface.isLoopback()) {
                                        Iterator<InterfaceAddress> it2 = networkInterface.getInterfaceAddresses().iterator();
                                        while (it2.hasNext()) {
                                            InetAddress broadcast = it2.next().getBroadcast();
                                            if (broadcast != null) {
                                                linkedHashSet.add(broadcast);
                                            }
                                        }
                                    }
                                }
                            } catch (Exception unused2) {
                            }
                            try {
                                datagramSocket = new DatagramSocket();
                            } catch (Exception unused3) {
                            }
                            try {
                                datagramSocket.setBroadcast(true);
                                int i10 = 0;
                                i = 0;
                                while (i10 < 3) {
                                    try {
                                        Iterator it3 = linkedHashSet.iterator();
                                        Intrinsics.checkNotNullExpressionValue(it3, str4);
                                        while (it3.hasNext()) {
                                            Object next = it3.next();
                                            String str5 = str4;
                                            Intrinsics.checkNotNullExpressionValue(next, "next(...)");
                                            InetAddress inetAddress = (InetAddress) next;
                                            LinkedHashSet linkedHashSet2 = linkedHashSet;
                                            int[] iArr = {9, 7};
                                            int i11 = 0;
                                            while (i11 < 2) {
                                                int i12 = i11;
                                                try {
                                                    z2 = z;
                                                    try {
                                                        datagramSocket.send(new DatagramPacket(bArr, 102, inetAddress, iArr[i11]));
                                                        i++;
                                                    } catch (Exception unused4) {
                                                    } catch (Throwable th2) {
                                                        th = th2;
                                                        th = th;
                                                        try {
                                                            throw th;
                                                        } catch (Throwable th3) {
                                                            MathKt.closeFinally(datagramSocket, th);
                                                            throw th3;
                                                            break;
                                                        }
                                                    }
                                                } catch (Exception unused5) {
                                                    z2 = z;
                                                }
                                                i11 = i12 + 1;
                                                z = z2;
                                            }
                                            str4 = str5;
                                            linkedHashSet = linkedHashSet2;
                                        }
                                        i10++;
                                        z = z;
                                    } catch (Throwable th4) {
                                        th = th4;
                                        z2 = z;
                                    }
                                }
                                z2 = z;
                                try {
                                    datagramSocket.close();
                                } catch (Exception unused6) {
                                }
                                i4 += i;
                            } catch (Throwable th5) {
                                z2 = z;
                                th = th5;
                                i = 0;
                            }
                        }
                        z2 = z;
                        i = 0;
                        i4 += i;
                    } else {
                        z2 = z;
                    }
                    try {
                        Thread.sleep(1000L);
                        if (!MathKt.open(str, i2, 600, null) && (str3.length() <= 0 || str3.equals(str) || !MathKt.sameNetwork(str3) || !MathKt.open(str3, i2, 400, null))) {
                            z3 = false;
                        } else {
                            z3 = true;
                        }
                        i3++;
                        z = z2;
                    } catch (InterruptedException unused7) {
                        boolean z4 = false;
                        final boolean sameNetwork = MathKt.sameNetwork(str3);
                        final MainActivity mainActivity = (MainActivity) this.f$4;
                        final boolean z5 = z4;
                        final boolean z6 = z3;
                        mainActivity.ui.post(new Runnable() { // from class: dev.tvremote.phone.picker.PickerScreenKt$$ExternalSyntheticLambda18
                            @Override // java.lang.Runnable
                            public final void run() {
                                String T;
                                MainActivity mainActivity2 = MainActivity.this;
                                mainActivity2.waking = false;
                                if (!mainActivity2.isFinishing() && mainActivity2.host == null) {
                                    if (z6) {
                                        mainActivity2.wakeNext = true;
                                        mainActivity2.connect$android_release(str, null);
                                        return;
                                    }
                                    if (str2.length() == 0) {
                                        T = Fleet.T("picker.the_app_does_not", new Pair[0]);
                                    } else if (z5 && sameNetwork) {
                                        T = Fleet.T("picker.wake_packets_were_sent", new Pair[0]);
                                    } else {
                                        T = Fleet.T("picker.the_tv_s_network", new Pair[0]);
                                    }
                                    PickerScreenKt.message(mainActivity2, Fleet.T("picker.could_not_wake_the", new Pair("why", T)), true);
                                }
                            }
                        });
                        return;
                    }
                }
                boolean z42 = false;
                final boolean sameNetwork2 = MathKt.sameNetwork(str3);
                final MainActivity mainActivity2 = (MainActivity) this.f$4;
                final boolean z52 = z42;
                final boolean z62 = z3;
                mainActivity2.ui.post(new Runnable() { // from class: dev.tvremote.phone.picker.PickerScreenKt$$ExternalSyntheticLambda18
                    @Override // java.lang.Runnable
                    public final void run() {
                        String T;
                        MainActivity mainActivity22 = MainActivity.this;
                        mainActivity22.waking = false;
                        if (!mainActivity22.isFinishing() && mainActivity22.host == null) {
                            if (z62) {
                                mainActivity22.wakeNext = true;
                                mainActivity22.connect$android_release(str, null);
                                return;
                            }
                            if (str2.length() == 0) {
                                T = Fleet.T("picker.the_app_does_not", new Pair[0]);
                            } else if (z52 && sameNetwork2) {
                                T = Fleet.T("picker.wake_packets_were_sent", new Pair[0]);
                            } else {
                                T = Fleet.T("picker.the_tv_s_network", new Pair[0]);
                            }
                            PickerScreenKt.message(mainActivity22, Fleet.T("picker.could_not_wake_the", new Pair("why", T)), true);
                        }
                    }
                });
                return;
            default:
                VerityTreeBuilder verityTreeBuilder = (VerityTreeBuilder) this.f$0;
                verityTreeBuilder.getClass();
                try {
                    try {
                        messageDigest = (MessageDigest) verityTreeBuilder.mMd.clone();
                    } catch (NoSuchAlgorithmException e) {
                        throw new IllegalStateException("Failed to obtain an instance of a previously available message digest", e);
                    }
                } catch (CloneNotSupportedException unused8) {
                    messageDigest = MessageDigest.getInstance("SHA-256");
                }
                ByteBuffer byteBuffer = (ByteBuffer) this.f$2;
                int capacity = byteBuffer.capacity();
                int i13 = this.f$1;
                int i14 = 0;
                while (i14 < capacity) {
                    int i15 = i14 + 4096;
                    ByteBuffer slice = VerityTreeBuilder.slice(byteBuffer, i14, i15);
                    messageDigest.reset();
                    byte[] bArr2 = verityTreeBuilder.mSalt;
                    if (bArr2 != null) {
                        messageDigest.update(bArr2);
                    }
                    messageDigest.update(slice);
                    ((byte[][]) this.f$3)[i13] = messageDigest.digest();
                    i13++;
                    i14 = i15;
                }
                ((Phaser) this.f$4).arriveAndDeregister();
                return;
        }
    }

    public /* synthetic */ PickerScreenKt$$ExternalSyntheticLambda15(String str, int i, String str2, String str3, MainActivity mainActivity) {
        this.f$0 = str;
        this.f$1 = i;
        this.f$2 = str2;
        this.f$3 = str3;
        this.f$4 = mainActivity;
    }
}
