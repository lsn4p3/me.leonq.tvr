package dev.tvremote.phone.picker;

import dev.tvremote.core.Downloader;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.phone.ui.UiKt;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;

/* loaded from: classes.dex */
public final /* synthetic */ class AdbHelpKt$$ExternalSyntheticLambda40 implements Function0 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Remote f$0;

    public /* synthetic */ AdbHelpKt$$ExternalSyntheticLambda40(Remote remote, int i) {
        this.$r8$classId = i;
        this.f$0 = remote;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        Remote remote = this.f$0;
        switch (this.$r8$classId) {
            case 0:
                remote.key(176, 3);
                return Unit.INSTANCE;
            case 1:
                remote.launch("android-app://com.android.tv.settings");
                return Unit.INSTANCE;
            case 2:
                remote.launch("intent:#Intent;action=android.settings.SETTINGS;end");
                return Unit.INSTANCE;
            default:
                boolean z = UiKt.LIGHT;
                String str = (String) Downloader.codes().get("setup");
                if (str == null) {
                    str = "";
                }
                remote.launch("downloader://".concat(str));
                return Unit.INSTANCE;
        }
    }
}
