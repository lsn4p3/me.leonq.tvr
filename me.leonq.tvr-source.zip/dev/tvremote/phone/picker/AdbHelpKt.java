package dev.tvremote.phone.picker;

import android.R;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticLambda6;
import dev.tvremote.core.Diagnose;
import dev.tvremote.core.Downloader;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Words;
import dev.tvremote.core.adb.Adb$$ExternalSyntheticLambda5;
import dev.tvremote.core.ontv.Axml$$ExternalSyntheticLambda2;
import dev.tvremote.core.remote.Lg$$ExternalSyntheticLambda2;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.guard.Guard$$ExternalSyntheticLambda7;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.MainActivity$$ExternalSyntheticLambda14;
import dev.tvremote.phone.ir.IrRemoteKt$$ExternalSyntheticLambda58;
import dev.tvremote.phone.manage.Managing;
import dev.tvremote.phone.media.MediaKt$$ExternalSyntheticLambda9;
import dev.tvremote.phone.media.TalkKt$$ExternalSyntheticLambda1;
import dev.tvremote.phone.remote.TypingKt;
import dev.tvremote.phone.ui.DlApp;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.phone.ui.UiKt;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.EmptyMap;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$BooleanRef;
import kotlin.jvm.internal.Ref$IntRef;
import kotlin.math.MathKt;
import kotlin.text.Regex;
import kotlin.text.RegexOption;
import org.json.JSONObject;

/* loaded from: classes.dex */
public abstract class AdbHelpKt {
    public static final Regex TV_HOME = new Regex("launcher|\\.home\\b|tvhome", RegexOption.IGNORE_CASE);

    public static final void adbSteps(MainActivity mainActivity) {
        String str;
        String str2;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Remote remote = mainActivity.basic;
        if (remote != null) {
            str = remote.getVendor();
        } else {
            str = null;
        }
        Remote remote2 = mainActivity.basic;
        if (remote2 != null) {
            str2 = remote2.getModel();
        } else {
            str2 = null;
        }
        String[] strArr = {str, str2};
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < 2; i++) {
            String str3 = strArr[i];
            if (str3 != null) {
                arrayList.add(str3);
            }
        }
        String joinToString$default = CollectionsKt.joinToString$default(arrayList, " ", null, null, null, 62);
        Managing managing$android_release = mainActivity.getManaging$android_release();
        String str4 = mainActivity.host;
        if (str4 == null) {
            return;
        }
        Managing.open$default(managing$android_release, str4, null, ApkSigner$$ExternalSyntheticOutline0.m("fromRemote(() => showAdbGuide(", JSONObject.quote(joinToString$default), "))"), 2);
    }

    public static final void findSettings(MainActivity mainActivity) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Remote remote = mainActivity.basic;
        if (remote == null || !tvFree(mainActivity)) {
            return;
        }
        Toast.makeText(mainActivity, Fleet.T("setup.trying_settings", new Pair[0]), 0).show();
        new Thread(new MediaKt$$ExternalSyntheticLambda9(mainActivity, remote, 2)).start();
    }

    /* JADX WARN: Type inference failed for: r4v0, types: [kotlin.jvm.internal.Ref$BooleanRef, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r6v0, types: [kotlin.jvm.internal.Ref$BooleanRef, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r8v1, types: [kotlin.jvm.internal.Ref$IntRef, java.lang.Object] */
    public static final void installSetup(MainActivity mainActivity, DlApp app) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Intrinsics.checkNotNullParameter(app, "app");
        Remote remote = mainActivity.basic;
        if (remote == null || !tvFree(mainActivity)) {
            return;
        }
        ?? obj = new Object();
        ?? obj2 = new Object();
        Popup.Builder builder = new Popup.Builder(mainActivity);
        builder.title = Fleet.T((String) app.title, new Pair[0]);
        builder.message = Fleet.T("adb_help.opening_downloader_on_the", new Pair[0]);
        builder.setNeutralButton(Fleet.T("adb_help.installed", new Pair[0]), null);
        builder.setNegativeButton(Fleet.T("apps.stop", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda12(obj, 0));
        builder.onCancel = new AdbHelpKt$$ExternalSyntheticLambda13(0, obj);
        Popup show = builder.show();
        Button button = show.getButton(-3);
        ?? obj3 = new Object();
        obj3.element = 1;
        Adb$$ExternalSyntheticLambda5 adb$$ExternalSyntheticLambda5 = new Adb$$ExternalSyntheticLambda5(mainActivity, show, obj3, 4);
        adb$$ExternalSyntheticLambda5.invoke("adb_help.opening_downloader_on_the");
        show.setCanceledOnTouchOutside(false);
        TextView textView = (TextView) show.findViewById(R.id.message);
        if (textView != null) {
            textView.setMinLines(7);
        }
        Axml$$ExternalSyntheticLambda2 axml$$ExternalSyntheticLambda2 = new Axml$$ExternalSyntheticLambda2(9, mainActivity, button);
        button.setOnClickListener(new Guard$$ExternalSyntheticLambda7(obj2, axml$$ExternalSyntheticLambda2, adb$$ExternalSyntheticLambda5, 3));
        new Thread(new AdbHelpKt$$ExternalSyntheticLambda17(remote, mainActivity, (Ref$BooleanRef) obj, adb$$ExternalSyntheticLambda5, (Ref$BooleanRef) obj2, axml$$ExternalSyntheticLambda2, (Ref$IntRef) obj3, app, show)).start();
    }

    public static final void installSetupByHand(MainActivity mainActivity) {
        int i = 2;
        int i2 = 1;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        String T = Fleet.T("setup.install_setup_title", new Pair[0]);
        Triple triple = new Triple(Fleet.T("adb_help.1_open_downloader_on", new Pair[0]), Fleet.T("adb_help.not_there_install_it", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity, 26));
        String T2 = Fleet.T("adb_help.2_download_tv_setup", new Pair[0]);
        boolean z = UiKt.LIGHT;
        String str = (String) Downloader.codes().get("setup");
        String str2 = "";
        if (str == null) {
            str = "";
        }
        Triple triple2 = new Triple(T2, Fleet.T("adb_help.code", new Pair("dl_code", str)), new TalkKt$$ExternalSyntheticLambda1(mainActivity, 27));
        Triple triple3 = new Triple(Fleet.T("adb_help.2b_no_luck_type", new Pair[0]), Fleet.T("adb_help.the_app_types_the", new Pair[0]), new TalkKt$$ExternalSyntheticLambda1(mainActivity, 28));
        Triple triple4 = new Triple(Fleet.T("adb_help.3_open_tv_setup", new Pair[0]), Fleet.T("adb_help.then_turn_on_usb", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity, i2));
        String T3 = Fleet.T("adb_help.copy_the_link", new Pair[0]);
        String str3 = (String) Downloader.codes().get("setup");
        if (str3 != null) {
            str2 = str3;
        }
        UiKt.menu(mainActivity, T, -1, ArraysKt.asList(new Triple[]{triple, triple2, triple3, triple4, new Triple(T3, Fleet.T("adb_help.to_type_in_downloader", new Pair("dl_code", str2), new Pair("link", "github.com/hoangtran0410/tv-remote/releases/latest/download/tv-setup.apk")), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity, i))}));
    }

    public static final void lookOnHome(MainActivity mainActivity) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Popup.Builder builder = new Popup.Builder(mainActivity);
        builder.title = Fleet.T("setup.look_title", new Pair[0]);
        builder.message = Fleet.T("adb_help.look_on_the_tv", new Pair[0]);
        builder.setPositiveButton(Fleet.T("adb_help.found_it", new Pair[0]), new MainActivity$$ExternalSyntheticLambda14(mainActivity, 10));
        builder.setNegativeButton(Fleet.T("setup.none_other_home", new Pair[0]), new MainActivity$$ExternalSyntheticLambda14(mainActivity, 11));
        builder.show();
    }

    public static final void offerWireless(MainActivity mainActivity, String ip, String str) {
        String str2;
        String str3;
        int i = 0;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Intrinsics.checkNotNullParameter(ip, "ip");
        ConcurrentHashMap concurrentHashMap = Words.books;
        String str4 = Words.lang;
        Regex regex = Diagnose.OTHER_BRANDS;
        if (str == null) {
            str2 = ip;
        } else {
            str2 = str;
        }
        String kindOf = TypingKt.kindOf(mainActivity, str2);
        EmptyMap emptyMap = EmptyMap.INSTANCE;
        Diagnose.Net net = Diagnose.Net.NA;
        if (str == null) {
            str3 = ip;
        } else {
            str3 = str;
        }
        String name = PickerScreenKt.name(mainActivity, str3);
        Pair say = Diagnose.say(new Diagnose.Facts(kindOf, ip, emptyMap, net, false, null, false, null, false, name, 448), "wireless", str4);
        String str5 = (String) say.first;
        String str6 = (String) say.second;
        Popup.Builder builder = new Popup.Builder(mainActivity);
        builder.title = str5;
        builder.message = str6;
        builder.setPositiveButton(Fleet.T("keys_only.pair", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda54(mainActivity, ip, i));
        builder.setNegativeButton(Fleet.T("common.close", new Pair[0]), null);
        builder.show();
    }

    public static final void openHome(MainActivity mainActivity, Remote a, Function0 function0) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Intrinsics.checkNotNullParameter(a, "a");
        if (!tvFree(mainActivity)) {
            return;
        }
        Toast.makeText(mainActivity, Fleet.T("adb_help.working_on_the_tv", new Pair[0]), 0).show();
        new Thread(new Lg$$ExternalSyntheticLambda2(a, mainActivity, function0, 18)).start();
    }

    public static final boolean openOnTv(MainActivity mainActivity, Remote a, String pkg, boolean z, Function0 function0) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Intrinsics.checkNotNullParameter(a, "a");
        Intrinsics.checkNotNullParameter(pkg, "pkg");
        AdbHelpKt$$ExternalSyntheticLambda69 adbHelpKt$$ExternalSyntheticLambda69 = new AdbHelpKt$$ExternalSyntheticLambda69(function0, mainActivity, a, 0);
        if (!Intrinsics.areEqual(a.getApp(), pkg)) {
            a.launch(pkg);
            if (((Boolean) adbHelpKt$$ExternalSyntheticLambda69.invoke(pkg, 4)).booleanValue()) {
                return true;
            }
            if (z) {
                a.launch("https://play.google.com/store/apps/details?id=".concat(pkg));
                if (!((Boolean) adbHelpKt$$ExternalSyntheticLambda69.invoke("com.android.vending", 10)).booleanValue()) {
                    return false;
                }
                Thread.sleep(3000L);
                if (Intrinsics.areEqual(a.getApp(), "com.android.vending")) {
                    a.pulse(23, 110L);
                    return ((Boolean) adbHelpKt$$ExternalSyntheticLambda69.invoke(pkg, 15)).booleanValue();
                }
                throw new Exception();
            }
            return false;
        }
        return true;
    }

    public static final void otherHome(MainActivity mainActivity) {
        String T;
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        Remote remote = mainActivity.basic;
        if (remote == null) {
            return;
        }
        Triple triple = new Triple("TV Home", Fleet.T("setup.home_own_sub", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda18(mainActivity, remote, 0));
        String T2 = Fleet.T("setup.via_other_home", new Pair[0]);
        List listOf = MathKt.listOf(triple);
        Pair[] pairArr = mainActivity.HOMES;
        ArrayList arrayList = new ArrayList(pairArr.length);
        for (Pair pair : pairArr) {
            String str = (String) pair.first;
            String str2 = (String) pair.second;
            if (Intrinsics.areEqual(remote.getApp(), str2)) {
                T = Fleet.T("adb_help.open_on_the_tv", new Pair[0]);
            } else {
                T = Fleet.T("adb_help.opens_it_or_its", new Pair[0]);
            }
            arrayList.add(new Triple(str, T, new Census$$ExternalSyntheticLambda6(mainActivity, str, remote, str2)));
        }
        UiKt.menu(mainActivity, T2, -1, CollectionsKt.plus(listOf, (Iterable) arrayList));
    }

    public static final boolean tvFree(MainActivity mainActivity) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        if (mainActivity.tvBusy.compareAndSet(false, true)) {
            return true;
        }
        Toast.makeText(mainActivity, Fleet.T("adb_help.the_tv_is_still", new Pair[0]), 0).show();
        return false;
    }

    public static final void tvJob(MainActivity mainActivity, Function0 function0) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        if (!tvFree(mainActivity)) {
            return;
        }
        Toast.makeText(mainActivity, Fleet.T("adb_help.working_on_the_tv", new Pair[0]), 0).show();
        new Thread(new IrRemoteKt$$ExternalSyntheticLambda58(mainActivity, function0)).start();
    }

    public static final void wirelessPair(MainActivity mainActivity, String str) {
        Intrinsics.checkNotNullParameter(mainActivity, "<this>");
        EditText input = UiKt.input(mainActivity, Fleet.T("setup.ph_addr", new Pair[0]));
        EditText input2 = UiKt.input(mainActivity, Fleet.T("setup.ph_code6", new Pair[0]));
        input.setSingleLine(true);
        input2.setInputType(2);
        LinearLayout col = UiKt.col(mainActivity);
        col.addView(UiKt.label(mainActivity, Fleet.T("setup.wireless_steps", new Pair[0]), 14, UiKt.TEXT));
        col.addView(input, UiKt.gap(mainActivity, 8));
        col.addView(input2, UiKt.gap(mainActivity, 8));
        new Thread(new Lg$$ExternalSyntheticLambda2(mainActivity, str, input, 19)).start();
        Popup.Builder builder = new Popup.Builder(mainActivity);
        builder.title = Fleet.T("setup.wireless_title", new Pair[0]);
        builder.view = UiKt.inDialog(mainActivity, col);
        builder.setPositiveButton(Fleet.T("keys_only.pair", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda9(input, input2, mainActivity, str, 0));
        builder.setNegativeButton(Fleet.T("common.cancel", new Pair[0]), null);
        builder.show();
    }
}
