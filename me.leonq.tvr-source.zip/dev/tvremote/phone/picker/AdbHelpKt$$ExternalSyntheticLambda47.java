package dev.tvremote.phone.picker;

import dev.tvremote.core.Census$$ExternalSyntheticLambda4;
import dev.tvremote.core.remote.Remote;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.remote.KeysOnlyKt$$ExternalSyntheticLambda2;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;

/* loaded from: classes.dex */
public final /* synthetic */ class AdbHelpKt$$ExternalSyntheticLambda47 implements Function0 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ Remote f$1;
    public final /* synthetic */ String f$2;

    public /* synthetic */ AdbHelpKt$$ExternalSyntheticLambda47(MainActivity mainActivity, Remote remote, String str, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
        this.f$1 = remote;
        this.f$2 = str;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        switch (this.$r8$classId) {
            case 0:
                AdbHelpKt.openOnTv(this.f$0, this.f$1, this.f$2, true, new Census$$ExternalSyntheticLambda4(18));
                return Unit.INSTANCE;
            case 1:
                AdbHelpKt.openOnTv(this.f$0, this.f$1, this.f$2, true, new Census$$ExternalSyntheticLambda4(18));
                return Unit.INSTANCE;
            case 2:
                AdbHelpKt.openOnTv(this.f$0, this.f$1, this.f$2, true, new Census$$ExternalSyntheticLambda4(18));
                return Unit.INSTANCE;
            case 3:
                MainActivity mainActivity = this.f$0;
                mainActivity.ui.post(new KeysOnlyKt$$ExternalSyntheticLambda2(mainActivity, this.f$1, this.f$2, 3));
                return Unit.INSTANCE;
            default:
                MainActivity mainActivity2 = this.f$0;
                mainActivity2.ui.post(new KeysOnlyKt$$ExternalSyntheticLambda2(mainActivity2, this.f$1, this.f$2, 2));
                return Unit.INSTANCE;
        }
    }
}
