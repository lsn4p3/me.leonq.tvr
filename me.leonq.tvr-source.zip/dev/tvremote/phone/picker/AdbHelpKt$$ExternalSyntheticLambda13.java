package dev.tvremote.phone.picker;

import android.content.DialogInterface;
import dev.tvremote.core.remote.CodePairing;
import kotlin.jvm.internal.Ref$BooleanRef;

/* loaded from: classes.dex */
public final /* synthetic */ class AdbHelpKt$$ExternalSyntheticLambda13 implements DialogInterface.OnCancelListener {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;

    public /* synthetic */ AdbHelpKt$$ExternalSyntheticLambda13(int i, Object obj) {
        this.$r8$classId = i;
        this.f$0 = obj;
    }

    @Override // android.content.DialogInterface.OnCancelListener
    public final void onCancel(DialogInterface dialogInterface) {
        switch (this.$r8$classId) {
            case 0:
                ((Ref$BooleanRef) this.f$0).element = true;
                return;
            case 1:
                ((Ref$BooleanRef) this.f$0).element = true;
                return;
            default:
                ((CodePairing) this.f$0).close();
                return;
        }
    }
}
