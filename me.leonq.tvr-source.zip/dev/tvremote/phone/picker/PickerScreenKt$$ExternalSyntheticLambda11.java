package dev.tvremote.phone.picker;

import android.view.KeyEvent;
import android.widget.TextView;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.remote.TypingKt;
import kotlin.text.Regex$$ExternalSyntheticLambda0;

/* loaded from: classes.dex */
public final /* synthetic */ class PickerScreenKt$$ExternalSyntheticLambda11 implements TextView.OnEditorActionListener {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;

    public /* synthetic */ PickerScreenKt$$ExternalSyntheticLambda11(int i, Object obj) {
        this.$r8$classId = i;
        this.f$0 = obj;
    }

    @Override // android.widget.TextView.OnEditorActionListener
    public final boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
        switch (this.$r8$classId) {
            case 0:
                MainActivity mainActivity = (MainActivity) this.f$0;
                mainActivity.connect$android_release(mainActivity.getIpBox$android_release().getText().toString(), null);
                return true;
            case 1:
                TypingKt.sendText((MainActivity) this.f$0);
                return true;
            default:
                ((Regex$$ExternalSyntheticLambda0) this.f$0).invoke();
                return true;
        }
    }
}
