package dev.tvremote.phone.picker;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.text.TextUtils;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.remote.TypingKt;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: classes.dex */
public final /* synthetic */ class AdbHelpKt$$ExternalSyntheticLambda54 implements DialogInterface.OnClickListener {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ AdbHelpKt$$ExternalSyntheticLambda54(MainActivity mainActivity, String str, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
        this.f$1 = str;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i) {
        switch (this.$r8$classId) {
            case 0:
                AdbHelpKt.wirelessPair(this.f$0, this.f$1);
                return;
            case 1:
                MainActivity mainActivity = this.f$0;
                ArrayList savedIps = PickerScreenKt.savedIps(mainActivity);
                String str = this.f$1;
                savedIps.remove(str);
                SharedPreferences.Editor putString = mainActivity.getPrefs$android_release().edit().putString("ips", TextUtils.join(",", savedIps));
                Iterator it = PickerScreenKt.PER_TV.iterator();
                while (it.hasNext()) {
                    putString.remove(((String) it.next()) + ":" + str);
                }
                putString.remove("atv:" + str).apply();
                PickerScreenKt.refreshSaved(mainActivity);
                return;
            case 2:
                TypingKt.startBasic(this.f$0, this.f$1, false);
                return;
            default:
                PickerScreenKt.message(this.f$0, this.f$1, true);
                return;
        }
    }
}
