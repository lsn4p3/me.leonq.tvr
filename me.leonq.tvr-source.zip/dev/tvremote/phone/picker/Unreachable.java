package dev.tvremote.phone.picker;

/* loaded from: classes.dex */
public final class Unreachable extends Exception {
}
