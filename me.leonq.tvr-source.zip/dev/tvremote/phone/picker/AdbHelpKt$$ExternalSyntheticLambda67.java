package dev.tvremote.phone.picker;

import android.content.DialogInterface;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.ui.DlApp;
import dev.tvremote.phone.ui.UiKt;

/* loaded from: classes.dex */
public final /* synthetic */ class AdbHelpKt$$ExternalSyntheticLambda67 implements DialogInterface.OnClickListener {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ DlApp f$1;

    public /* synthetic */ AdbHelpKt$$ExternalSyntheticLambda67(MainActivity mainActivity, DlApp dlApp, int i) {
        this.$r8$classId = i;
        this.f$0 = mainActivity;
        this.f$1 = dlApp;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i) {
        switch (this.$r8$classId) {
            case 0:
                AdbHelpKt.installSetup(this.f$0, this.f$1);
                return;
            case 1:
                DlApp dlApp = UiKt.SETUP_APP;
                MainActivity mainActivity = this.f$0;
                if (this.f$1 == dlApp) {
                    AdbHelpKt.installSetupByHand(mainActivity);
                    return;
                } else {
                    AdbHelpKt.otherHome(mainActivity);
                    return;
                }
            default:
                DlApp dlApp2 = UiKt.SETUP_APP;
                MainActivity mainActivity2 = this.f$0;
                if (this.f$1 == dlApp2) {
                    AdbHelpKt.installSetupByHand(mainActivity2);
                    return;
                } else {
                    AdbHelpKt.otherHome(mainActivity2);
                    return;
                }
        }
    }
}
