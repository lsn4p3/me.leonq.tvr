package dev.tvremote.guard;

import android.app.AlertDialog;
import android.content.DialogInterface;
import dev.tvremote.core.ontv.Setup$$ExternalSyntheticLambda5;

/* loaded from: classes.dex */
public final /* synthetic */ class Guard$$ExternalSyntheticLambda6 implements DialogInterface.OnDismissListener {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;

    public /* synthetic */ Guard$$ExternalSyntheticLambda6(int i, Object obj) {
        this.$r8$classId = i;
        this.f$0 = obj;
    }

    @Override // android.content.DialogInterface.OnDismissListener
    public final void onDismiss(DialogInterface dialogInterface) {
        switch (this.$r8$classId) {
            case 0:
                if (Guard.dialog == ((AlertDialog) this.f$0)) {
                    Guard.dialog = null;
                    Guard.bodyView = null;
                    return;
                }
                return;
            default:
                ((Setup$$ExternalSyntheticLambda5) this.f$0).invoke();
                return;
        }
    }
}
