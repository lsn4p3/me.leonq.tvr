package dev.tvremote.guard;

import android.os.Looper;
import android.util.Log;
import dev.tvremote.core.Downloader;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.adb.AdbLink$$ExternalSyntheticLambda2;
import dev.tvremote.core.ontv.Launchers;
import dev.tvremote.core.scenes.Phrases;
import dev.tvremote.core.scenes.Voice;
import dev.tvremote.core.scenes.VoicePhrases;
import dev.tvremote.core.web.HttpServer;
import dev.tvremote.home.HomeQr$$ExternalSyntheticLambda0;
import dev.tvremote.phone.PhoneApp;
import dev.tvremote.phone.WorkService;
import dev.tvremote.phone.picker.TvStatus;
import dev.tvremote.update.SignedList;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.Pair;
import kotlin.collections.ArrayDeque;
import kotlin.collections.ArraysKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;

/* loaded from: classes.dex */
public final /* synthetic */ class Guard$$ExternalSyntheticLambda3 implements Runnable {
    public final /* synthetic */ int $r8$classId;

    public /* synthetic */ Guard$$ExternalSyntheticLambda3(int i) {
        this.$r8$classId = i;
    }

    /* JADX WARN: Removed duplicated region for block: B:138:0x023b  */
    /* JADX WARN: Removed duplicated region for block: B:149:0x02c8 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:183:0x0365 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:186:0x039f A[LOOP:2: B:97:0x0148->B:186:0x039f, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:187:0x03a5 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:208:0x026d  */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void run() {
        boolean z;
        boolean z2;
        boolean z3;
        boolean z4;
        List<StackTraceElement> take;
        boolean z5;
        boolean z6;
        boolean z7;
        boolean z8;
        boolean z9;
        String message;
        int length;
        int i;
        String message2;
        List list;
        long j;
        AdbLink adbLink;
        long j2 = 2000;
        int i2 = 0;
        int i3 = 1;
        switch (this.$r8$classId) {
            case 0:
                break;
            case 1:
                File file = Downloader.dir;
                if (file != null) {
                    try {
                        List list2 = Launchers.KEYS;
                    } catch (IOException unused) {
                        return;
                    }
                }
                return;
            case 2:
                try {
                    Thread.sleep(2000L);
                    List list3 = Launchers.KEYS;
                    String str = Launchers.testBase;
                    if (str != null) {
                        list = MathKt.listOf(str);
                    } else {
                        list = Launchers.bases;
                    }
                    return;
                } catch (Exception unused2) {
                    return;
                }
            case 3:
                VoicePhrases voicePhrases = VoicePhrases.INSTANCE;
                try {
                    ?? obj = new Object();
                    obj.element = "";
                    List list4 = SignedList.KEYS;
                    byte[] bArr = (byte[]) SignedList.fetch$default(VoicePhrases.BASES, "phrases.json", null, new AdbLink$$ExternalSyntheticLambda2(3, obj), 24);
                    Voice voice = Voice.INSTANCE;
                    Phrases phrases = Voice.phrases;
                    if (phrases != null) {
                        i2 = phrases.rev;
                    }
                    Pair choose = VoicePhrases.choose(bArr, null, null);
                    if (choose != null && ((Phrases) choose.second).rev >= i2) {
                        File file2 = VoicePhrases.kept;
                        if (file2 != null) {
                            SignedList.keep(file2, bArr, (String) obj.element);
                        }
                        VoicePhrases.bytes = (byte[]) choose.first;
                        Voice.phrases = (Phrases) choose.second;
                        return;
                    }
                    return;
                } catch (Exception unused3) {
                    return;
                }
            case 4:
                long nanoTime = System.nanoTime();
                for (HttpServer.Stall stall : HttpServer.live) {
                    if (stall.patient) {
                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = HttpServer.trusted;
                        j = 600000;
                    } else {
                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda02 = HttpServer.trusted;
                        j = 30000;
                    }
                    long j3 = j * 1000000;
                    long j4 = stall.since;
                    if (j4 != 0 && nanoTime - j4 > j3) {
                        try {
                            stall.sock.close();
                        } catch (Exception unused4) {
                        }
                    }
                }
                Set set = HttpServer.live;
                if (set.isEmpty()) {
                    AtomicBoolean atomicBoolean = HttpServer.armed;
                    atomicBoolean.set(false);
                    if (set.isEmpty() || !atomicBoolean.compareAndSet(false, true)) {
                        return;
                    }
                }
                HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda03 = HttpServer.trusted;
                WorkService.Companion.sweep();
                return;
            case 5:
                throw new IllegalStateException("guard test: main thread");
            case 6:
                throw new IllegalStateException("guard test: background thread");
            default:
                long currentTimeMillis = System.currentTimeMillis();
                ConcurrentHashMap concurrentHashMap = TvStatus.used;
                for (Map.Entry entry : concurrentHashMap.entrySet()) {
                    String str2 = (String) entry.getKey();
                    if (currentTimeMillis - ((Number) entry.getValue()).longValue() > 40000) {
                        concurrentHashMap.remove(str2);
                        Pair pair = (Pair) TvStatus.links.remove(str2);
                        if (pair != null && (adbLink = (AdbLink) pair.second) != null) {
                            adbLink.close();
                        }
                    }
                }
                return;
        }
        while (true) {
            try {
                Looper.loop();
                return;
            } catch (Throwable th) {
                PhoneApp phoneApp = Guard.app;
                long currentTimeMillis2 = System.currentTimeMillis();
                Long valueOf = Long.valueOf(currentTimeMillis2);
                ArrayDeque arrayDeque = Guard.stamps;
                arrayDeque.addLast(valueOf);
                while (true) {
                    int i4 = arrayDeque.size;
                    if (i4 > 10) {
                        arrayDeque.removeFirst();
                    } else {
                        if (i4 >= 10 && currentTimeMillis2 - ((Number) arrayDeque.first()).longValue() < j2) {
                            z = true;
                        } else {
                            z = false;
                        }
                        Regex regex = GuardLogic.LIFECYCLE;
                        if (StringsKt__StringsJVMKt.endsWith(th.getClass().getName(), false, "$BadTokenException") || ((th instanceof IllegalArgumentException) && (message2 = th.getMessage()) != null && StringsKt.contains(message2, "not attached to window manager", false) == i3)) {
                            StackTraceElement[] stackTrace = th.getStackTrace();
                            Intrinsics.checkNotNullExpressionValue(stackTrace, "getStackTrace(...)");
                            int length2 = stackTrace.length;
                            for (int i5 = 0; i5 < length2; i5 += i3) {
                                StackTraceElement stackTraceElement = stackTrace[i5];
                                if (Intrinsics.areEqual(stackTraceElement.getClassName(), "android.app.Dialog")) {
                                    if (!Intrinsics.areEqual(stackTraceElement.getMethodName(), "show")) {
                                        String methodName = stackTraceElement.getMethodName();
                                        Intrinsics.checkNotNullExpressionValue(methodName, "getMethodName(...)");
                                        if (StringsKt__StringsJVMKt.startsWith(methodName, false, "dismiss")) {
                                        }
                                    }
                                    Log.w("Guard", "a dialog of a closed screen: " + th);
                                    z2 = true;
                                    if (z2) {
                                        j2 = 2000;
                                        i3 = 1;
                                    } else {
                                        throw th;
                                    }
                                }
                            }
                        }
                        Regex regex2 = GuardLogic.LIFECYCLE;
                        StackTraceElement[] stackTrace2 = th.getStackTrace();
                        if (th instanceof IllegalStateException) {
                            Intrinsics.checkNotNull(stackTrace2);
                            int length3 = stackTrace2.length;
                            for (int i6 = 0; i6 < length3; i6 += i3) {
                                StackTraceElement stackTraceElement2 = stackTrace2[i6];
                                if (Intrinsics.areEqual(stackTraceElement2.getClassName(), "android.app.ActivityThread") && Intrinsics.areEqual(stackTraceElement2.getMethodName(), "handleRequestAssistContextExtras")) {
                                    z3 = true;
                                    if ((th instanceof IllegalArgumentException) && (message = th.getMessage()) != null && StringsKt__StringsJVMKt.startsWith(message, false, "Receiver not registered") == i3) {
                                        Intrinsics.checkNotNull(stackTrace2);
                                        length = stackTrace2.length;
                                        for (i = 0; i < length; i += i3) {
                                            StackTraceElement stackTraceElement3 = stackTrace2[i];
                                            if (Intrinsics.areEqual(stackTraceElement3.getClassName(), "android.widget.TextClock") && Intrinsics.areEqual(stackTraceElement3.getMethodName(), "onDetachedFromWindow")) {
                                                z4 = true;
                                                Intrinsics.checkNotNull(stackTrace2);
                                                take = ArraysKt.take(stackTrace2, 8);
                                                if (!take.isEmpty()) {
                                                    for (StackTraceElement stackTraceElement4 : take) {
                                                        z2 = true;
                                                        if (Intrinsics.areEqual(stackTraceElement4.getClassName(), "android.os.Parcel") && Intrinsics.areEqual(stackTraceElement4.getMethodName(), "readException")) {
                                                            for (StackTraceElement stackTraceElement5 : stackTrace2) {
                                                                String className = stackTraceElement5.getClassName();
                                                                Intrinsics.checkNotNullExpressionValue(className, "getClassName(...)");
                                                                if (StringsKt__StringsJVMKt.startsWith(className, false, "android.app.servertransaction.") && Intrinsics.areEqual(stackTraceElement5.getMethodName(), "postExecute")) {
                                                                    z5 = true;
                                                                    if (z3 && !z4 && !z5) {
                                                                        Regex regex3 = GuardLogic.LIFECYCLE;
                                                                        Throwable th2 = th;
                                                                        int i7 = 0;
                                                                        while (th2 != null) {
                                                                            int i8 = i7 + 1;
                                                                            if (i7 < 8) {
                                                                                StackTraceElement[] stackTrace3 = th2.getStackTrace();
                                                                                Intrinsics.checkNotNullExpressionValue(stackTrace3, "getStackTrace(...)");
                                                                                int length4 = stackTrace3.length;
                                                                                int i9 = 0;
                                                                                while (true) {
                                                                                    if (i9 < length4) {
                                                                                        StackTraceElement stackTraceElement6 = stackTrace3[i9];
                                                                                        String className2 = stackTraceElement6.getClassName();
                                                                                        if (className2 != null) {
                                                                                            int hashCode = className2.hashCode();
                                                                                            Regex regex4 = GuardLogic.LIFECYCLE;
                                                                                            switch (hashCode) {
                                                                                                case -1613601742:
                                                                                                    if (className2.equals("android.app.servertransaction.TransactionExecutor")) {
                                                                                                        z9 = true;
                                                                                                        break;
                                                                                                    }
                                                                                                    break;
                                                                                                case -1165789339:
                                                                                                    if (className2.equals("android.app.ActivityThread")) {
                                                                                                        String methodName2 = stackTraceElement6.getMethodName();
                                                                                                        Intrinsics.checkNotNullExpressionValue(methodName2, "getMethodName(...)");
                                                                                                        z9 = regex4.matches(methodName2);
                                                                                                        break;
                                                                                                    }
                                                                                                    break;
                                                                                                case -880360069:
                                                                                                    if (className2.equals("android.app.Activity")) {
                                                                                                        String methodName3 = stackTraceElement6.getMethodName();
                                                                                                        Intrinsics.checkNotNullExpressionValue(methodName3, "getMethodName(...)");
                                                                                                        z9 = regex4.matches(methodName3);
                                                                                                        break;
                                                                                                    }
                                                                                                    break;
                                                                                                case -423031934:
                                                                                                    if (className2.equals("android.app.Instrumentation")) {
                                                                                                        String methodName4 = stackTraceElement6.getMethodName();
                                                                                                        Intrinsics.checkNotNullExpressionValue(methodName4, "getMethodName(...)");
                                                                                                        z9 = regex4.matches(methodName4);
                                                                                                        break;
                                                                                                    }
                                                                                                    break;
                                                                                            }
                                                                                        }
                                                                                        z9 = false;
                                                                                        if (z9) {
                                                                                            z7 = true;
                                                                                        } else {
                                                                                            i9++;
                                                                                        }
                                                                                    } else {
                                                                                        z7 = false;
                                                                                    }
                                                                                }
                                                                                if (z7) {
                                                                                    z6 = true;
                                                                                    if (z6 && !z) {
                                                                                        Thread thread = Looper.getMainLooper().getThread();
                                                                                        Intrinsics.checkNotNullExpressionValue(thread, "getThread(...)");
                                                                                        Guard.report(thread, th);
                                                                                    } else {
                                                                                        Thread thread2 = Looper.getMainLooper().getThread();
                                                                                        Intrinsics.checkNotNullExpressionValue(thread2, "getThread(...)");
                                                                                        Guard.save(thread2, th, true);
                                                                                        z2 = false;
                                                                                    }
                                                                                    if (z2) {
                                                                                    }
                                                                                } else {
                                                                                    Throwable cause = th2.getCause();
                                                                                    if (cause != th2) {
                                                                                        z8 = true;
                                                                                    } else {
                                                                                        z8 = false;
                                                                                    }
                                                                                    if (z8) {
                                                                                        th2 = cause;
                                                                                    } else {
                                                                                        th2 = null;
                                                                                    }
                                                                                    i7 = i8;
                                                                                }
                                                                            } else {
                                                                                z6 = false;
                                                                                if (z6) {
                                                                                }
                                                                                Thread thread22 = Looper.getMainLooper().getThread();
                                                                                Intrinsics.checkNotNullExpressionValue(thread22, "getThread(...)");
                                                                                Guard.save(thread22, th, true);
                                                                                z2 = false;
                                                                                if (z2) {
                                                                                }
                                                                            }
                                                                        }
                                                                        z6 = false;
                                                                        if (z6) {
                                                                        }
                                                                        Thread thread222 = Looper.getMainLooper().getThread();
                                                                        Intrinsics.checkNotNullExpressionValue(thread222, "getThread(...)");
                                                                        Guard.save(thread222, th, true);
                                                                        z2 = false;
                                                                        if (z2) {
                                                                        }
                                                                    } else {
                                                                        Log.w("Guard", "Android's own error: " + th);
                                                                        z2 = true;
                                                                        if (z2) {
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                            z5 = false;
                                                            if (z3) {
                                                            }
                                                            Log.w("Guard", "Android's own error: " + th);
                                                            z2 = true;
                                                            if (z2) {
                                                            }
                                                        }
                                                    }
                                                }
                                                z2 = true;
                                                z5 = false;
                                                if (z3) {
                                                }
                                                Log.w("Guard", "Android's own error: " + th);
                                                z2 = true;
                                                if (z2) {
                                                }
                                            }
                                        }
                                    }
                                    z4 = false;
                                    Intrinsics.checkNotNull(stackTrace2);
                                    take = ArraysKt.take(stackTrace2, 8);
                                    if (!take.isEmpty()) {
                                    }
                                    z2 = true;
                                    z5 = false;
                                    if (z3) {
                                    }
                                    Log.w("Guard", "Android's own error: " + th);
                                    z2 = true;
                                    if (z2) {
                                    }
                                }
                            }
                        }
                        z3 = false;
                        if (th instanceof IllegalArgumentException) {
                            Intrinsics.checkNotNull(stackTrace2);
                            length = stackTrace2.length;
                            while (i < length) {
                            }
                        }
                        z4 = false;
                        Intrinsics.checkNotNull(stackTrace2);
                        take = ArraysKt.take(stackTrace2, 8);
                        if (!take.isEmpty()) {
                        }
                        z2 = true;
                        z5 = false;
                        if (z3) {
                        }
                        Log.w("Guard", "Android's own error: " + th);
                        z2 = true;
                        if (z2) {
                        }
                    }
                }
            }
        }
    }
}
