package dev.tvremote.guard;

import android.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.util.Log;
import android.widget.ScrollView;
import android.widget.TextView;
import dev.tvremote.core.Census$$ExternalSyntheticLambda4;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.ontv.Bloat$$ExternalSyntheticLambda0;
import dev.tvremote.home.HomeQr$$ExternalSyntheticLambda0;
import dev.tvremote.phone.PhoneApp;
import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.Thread;
import java.lang.ref.WeakReference;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import kotlin.SynchronizedLazyImpl;
import kotlin.collections.ArrayDeque;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.sequences.FilteringSequence;
import kotlin.sequences.SequencesKt;
import kotlin.text.Regex;
import kotlin.text.StringsKt;

/* loaded from: classes.dex */
public abstract class Guard {
    public static PhoneApp app;
    public static TextView bodyView;
    public static volatile Bloat$$ExternalSyntheticLambda0 crash;
    public static boolean debuggable;
    public static AlertDialog dialog;
    public static String pending;
    public static Thread.UncaughtExceptionHandler prev;
    public static int repeats;
    public static boolean share;
    public static HomeQr$$ExternalSyntheticLambda0 words;
    public static WeakReference top = new WeakReference(null);
    public static String shownKey = "";
    public static final SynchronizedLazyImpl main$delegate = new SynchronizedLazyImpl(new Census$$ExternalSyntheticLambda4(13));
    public static final ArrayDeque stamps = new ArrayDeque();

    public static void report(Thread thread, Throwable th) {
        int i = 0;
        ((Handler) main$delegate.getValue()).post(new Guard$$ExternalSyntheticLambda5(i, save(thread, th, false), th));
        String name = th.getClass().getName();
        String message = th.getMessage();
        if (message == null) {
            message = "";
        }
        Regex regex = GuardLogic.LIFECYCLE;
        StringWriter stringWriter = new StringWriter();
        th.printStackTrace(new PrintWriter(stringWriter));
        String stringWriter2 = stringWriter.toString();
        Intrinsics.checkNotNullExpressionValue(stringWriter2, "toString(...)");
        String obj = StringsKt.trim(StringsKt.substringAfter(stringWriter2, '\n', "")).toString();
        String key = GuardLogic.key(th);
        Bloat$$ExternalSyntheticLambda0 bloat$$ExternalSyntheticLambda0 = crash;
        if (bloat$$ExternalSyntheticLambda0 != null) {
            try {
                bloat$$ExternalSyntheticLambda0.invoke(name, message, obj, new Guard$$ExternalSyntheticLambda4(key, i));
            } catch (Throwable unused) {
            }
        }
    }

    public static String save(Thread thread, Throwable th, boolean z) {
        PackageInfo packageInfo;
        String str;
        PhoneApp phoneApp;
        PhoneApp phoneApp2;
        try {
            phoneApp2 = app;
        } catch (Exception unused) {
            packageInfo = null;
        }
        if (phoneApp2 != null) {
            PackageManager packageManager = phoneApp2.getPackageManager();
            PhoneApp phoneApp3 = app;
            if (phoneApp3 != null) {
                packageInfo = packageManager.getPackageInfo(phoneApp3.getPackageName(), 0);
                Regex regex = GuardLogic.LIFECYCLE;
                String format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date());
                Intrinsics.checkNotNullExpressionValue(format, "format(...)");
                PhoneApp phoneApp4 = app;
                if (phoneApp4 != null) {
                    String packageName = phoneApp4.getPackageName();
                    if (packageInfo == null || (str = packageInfo.versionName) == null) {
                        str = "?";
                    }
                    String app2 = Census$$ExternalSyntheticOutline0.m(packageName, " ", str);
                    String android = Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")";
                    String device = Census$$ExternalSyntheticOutline0.m(Build.MANUFACTURER, " ", Build.MODEL);
                    String name = thread.getName();
                    Intrinsics.checkNotNullExpressionValue(name, "getName(...)");
                    Intrinsics.checkNotNullParameter(app2, "app");
                    Intrinsics.checkNotNullParameter(android, "android");
                    Intrinsics.checkNotNullParameter(device, "device");
                    StringWriter stringWriter = new StringWriter();
                    th.printStackTrace(new PrintWriter(stringWriter));
                    String str2 = "time: " + format + "\napp: " + app2 + "\nandroid: " + android + "\ndevice: " + device + "\nthread: " + name + "\n\n" + stringWriter;
                    Log.e("TvrGuard", str2);
                    try {
                        phoneApp = app;
                    } catch (Exception unused2) {
                    }
                    if (phoneApp != null) {
                        MathKt.writeText$default(new File(phoneApp.getFilesDir(), "guard-last.txt"), str2);
                        if (z) {
                            PhoneApp phoneApp5 = app;
                            if (phoneApp5 != null) {
                                MathKt.writeText$default(new File(phoneApp5.getFilesDir(), "guard-died"), "1");
                            } else {
                                Intrinsics.throwUninitializedPropertyAccessException("app");
                                throw null;
                            }
                        }
                        return str2;
                    }
                    Intrinsics.throwUninitializedPropertyAccessException("app");
                    throw null;
                }
                Intrinsics.throwUninitializedPropertyAccessException("app");
                throw null;
            }
            Intrinsics.throwUninitializedPropertyAccessException("app");
            throw null;
        }
        Intrinsics.throwUninitializedPropertyAccessException("app");
        throw null;
    }

    public static void show(Activity activity, String str, String str2, String str3, Throwable th) {
        String joinToString$default;
        int i = 0;
        if (!activity.isFinishing()) {
            HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = words;
            if (homeQr$$ExternalSyntheticLambda0 != null) {
                GuardWords guardWords = (GuardWords) homeQr$$ExternalSyntheticLambda0.invoke(activity);
                AlertDialog alertDialog = dialog;
                if (alertDialog != null && alertDialog.isShowing()) {
                    if (Intrinsics.areEqual(str3, shownKey)) {
                        int i2 = repeats;
                        repeats = 1 + i2;
                        alertDialog.setTitle(str + "  " + guardWords.repeat.invoke(Integer.valueOf(i2 + 2)));
                        return;
                    }
                    return;
                }
                repeats = 0;
                shownKey = str3;
                if (th != null) {
                    Regex regex = GuardLogic.LIFECYCLE;
                    StringWriter stringWriter = new StringWriter();
                    th.printStackTrace(new PrintWriter(stringWriter));
                    String stringWriter2 = stringWriter.toString();
                    Intrinsics.checkNotNullExpressionValue(stringWriter2, "toString(...)");
                    joinToString$default = SequencesKt.joinToString$default(SequencesKt.take(new FilteringSequence(StringsKt.lineSequence(stringWriter2), true, new HomeQr$$ExternalSyntheticLambda0(19)), 6), "\n", null, 62);
                } else {
                    List lines = StringsKt.lines(str2);
                    ArrayList arrayList = new ArrayList();
                    boolean z = false;
                    for (Object obj : lines) {
                        if (z) {
                            arrayList.add(obj);
                        } else if (StringsKt.isBlank((String) obj)) {
                            arrayList.add(obj);
                            z = true;
                        }
                    }
                    ArrayList arrayList2 = new ArrayList();
                    Iterator it = arrayList.iterator();
                    while (it.hasNext()) {
                        Object next = it.next();
                        if (!StringsKt.isBlank((String) next)) {
                            arrayList2.add(next);
                        }
                    }
                    joinToString$default = CollectionsKt.joinToString$default(CollectionsKt.take(arrayList2, 7), "\n", null, null, null, 62);
                }
                TextView textView = new TextView(activity);
                textView.setText(joinToString$default);
                textView.setTextSize(2, 12.0f);
                textView.setTypeface(Typeface.MONOSPACE);
                int i3 = (int) (16 * textView.getResources().getDisplayMetrics().density);
                textView.setPadding(i3, i3 / 2, i3, 0);
                AlertDialog.Builder title = new AlertDialog.Builder(activity, R.style.Theme.DeviceDefault.Dialog.Alert).setTitle(str);
                ScrollView scrollView = new ScrollView(activity);
                scrollView.addView(textView);
                AlertDialog.Builder negativeButton = title.setView(scrollView).setPositiveButton(guardWords.copy, (DialogInterface.OnClickListener) null).setNegativeButton(guardWords.close, (DialogInterface.OnClickListener) null);
                if (share) {
                    negativeButton.setNeutralButton(guardWords.share, (DialogInterface.OnClickListener) null);
                }
                AlertDialog create = negativeButton.create();
                create.setOnDismissListener(new Guard$$ExternalSyntheticLambda6(i, create));
                bodyView = textView;
                create.show();
                dialog = create;
                create.getButton(-1).setOnClickListener(new Guard$$ExternalSyntheticLambda7(activity, str2, guardWords, i));
                create.getButton(-2).setOnClickListener(new Guard$$ExternalSyntheticLambda8(i, create));
                if (share) {
                    create.getButton(-3).setOnClickListener(new Guard$$ExternalSyntheticLambda9(i, activity, str2));
                }
                create.getButton(-2).requestFocus();
                return;
            }
            Intrinsics.throwUninitializedPropertyAccessException("words");
            throw null;
        }
    }
}
