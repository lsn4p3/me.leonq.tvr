package dev.tvremote.guard;

import android.app.AlertDialog;
import android.app.Dialog;
import android.view.View;
import android.widget.Button;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.remote.Lg$$ExternalSyntheticLambda8;
import dev.tvremote.core.remote.Vidaa$$ExternalSyntheticLambda6;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.manage.Managing;
import dev.tvremote.phone.manage.Managing$$ExternalSyntheticLambda1;
import dev.tvremote.phone.media.MediaKt$$ExternalSyntheticLambda4;
import dev.tvremote.phone.media.NowApp;
import dev.tvremote.phone.media.PlayingBar;
import dev.tvremote.phone.picker.AdbHelpKt$$ExternalSyntheticLambda3;
import dev.tvremote.phone.picture.MiniPlayer;
import dev.tvremote.phone.picture.PipKt;
import dev.tvremote.phone.remote.Gp;
import dev.tvremote.phone.ui.UiKt;
import java.util.ArrayList;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.collections.ArraysKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex$$ExternalSyntheticLambda0;

/* loaded from: classes.dex */
public final /* synthetic */ class Guard$$ExternalSyntheticLambda8 implements View.OnClickListener {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;

    public /* synthetic */ Guard$$ExternalSyntheticLambda8(int i, Object obj) {
        this.$r8$classId = i;
        this.f$0 = obj;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        String str;
        String str2;
        int i = 8;
        switch (this.$r8$classId) {
            case 0:
                ((AlertDialog) this.f$0).dismiss();
                return;
            case 1:
                int i2 = MainActivity.$r8$clinit;
                ((Dialog) this.f$0).dismiss();
                return;
            case 2:
                Managing managing = (Managing) this.f$0;
                managing.view.setVisibility(8);
                managing.web.onPause();
                managing.web.evaluateJavascript("(function(){ try { return localStorage.getItem('setupUndo') || '' } catch (e) { return '' } })()", new Managing$$ExternalSyntheticLambda1(managing));
                return;
            case 3:
                MainActivity mainActivity = ((NowApp) this.f$0).a;
                Tv tv = mainActivity.tv;
                if (tv != null && (str = mainActivity.host) != null) {
                    String T = Fleet.T("rkey.pad_chip", new Pair[0]);
                    String replaceAll = Census$$ExternalSyntheticOutline0.m7m("^[^\\p{L}]+", "compile(...)", T, "input", T).replaceAll("");
                    Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
                    String T2 = Fleet.T("rkey.pad_chip", new Pair[0]);
                    String replaceAll2 = Census$$ExternalSyntheticOutline0.m7m("^[^\\p{L}]+", "compile(...)", T2, "input", T2).replaceAll("");
                    Intrinsics.checkNotNullExpressionValue(replaceAll2, "replaceAll(...)");
                    UiKt.menu(mainActivity, replaceAll, -1, ArraysKt.asList(new Triple[]{new Triple("@gamepad|".concat(replaceAll2), Fleet.T("rkey.pad_page_sub", new Pair[0]), new Vidaa$$ExternalSyntheticLambda6(str, (Object) mainActivity, (Object) tv, i)), new Triple(ApkSigner$$ExternalSyntheticOutline0.m("@gamepad|", Fleet.T("rkey.gamespad", new Pair[0])), Fleet.T("rkey.gamespad_sub", new Pair[0]), new AdbHelpKt$$ExternalSyntheticLambda3(mainActivity, 18))}));
                    return;
                }
                return;
            case 4:
                ((Function0) ((Triple) this.f$0).third).invoke();
                return;
            case 5:
                PlayingBar playingBar = (PlayingBar) this.f$0;
                if (Intrinsics.areEqual(playingBar.o.optString("state"), "playing")) {
                    str2 = "pause";
                } else {
                    str2 = "play";
                }
                playingBar.send(str2, 0L, playingBar.play);
                return;
            case 6:
                ((MediaKt$$ExternalSyntheticLambda4) this.f$0).invoke();
                return;
            case 7:
                MainActivity mainActivity2 = ((MiniPlayer) this.f$0).a;
                ArrayList arrayList = PipKt.hidden;
                Intrinsics.checkNotNullParameter(mainActivity2, "<this>");
                boolean covered$android_release = mainActivity2.covered$android_release();
                mainActivity2.stopPicture$android_release();
                if (!covered$android_release && mainActivity2.video) {
                    mainActivity2.toggleVideo$android_release();
                    return;
                }
                return;
            case 8:
                Button button = (Button) this.f$0;
                Gp.ready = true ^ Gp.ready;
                UiKt.setOn$default(button, Gp.ready, 0, 6);
                new Thread(new Lg$$ExternalSyntheticLambda8(Gp.ws, Gp.ready ? 1 : 0, 2)).start();
                return;
            default:
                ((Regex$$ExternalSyntheticLambda0) this.f$0).invoke();
                return;
        }
    }
}
