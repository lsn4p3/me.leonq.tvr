package dev.tvremote.guard;

import android.app.Activity;
import android.app.AlertDialog;
import android.widget.TextView;
import dev.tvremote.home.HomeQr$$ExternalSyntheticLambda0;
import dev.tvremote.phone.remote.Gp;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

/* loaded from: classes.dex */
public final /* synthetic */ class Guard$$ExternalSyntheticLambda12 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ String f$0;

    public /* synthetic */ Guard$$ExternalSyntheticLambda12(String str, int i) {
        this.$r8$classId = i;
        this.f$0 = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        TextView textView;
        switch (this.$r8$classId) {
            case 0:
                AlertDialog alertDialog = Guard.dialog;
                if (alertDialog != null && (textView = Guard.bodyView) != null) {
                    Activity activity = (Activity) Guard.top.get();
                    String str = null;
                    if (activity != null) {
                        HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = Guard.words;
                        if (homeQr$$ExternalSyntheticLambda0 != null) {
                            str = ((GuardWords) homeQr$$ExternalSyntheticLambda0.invoke(activity)).sent;
                        } else {
                            Intrinsics.throwUninitializedPropertyAccessException("words");
                            throw null;
                        }
                    }
                    if (str == null) {
                        str = "";
                    }
                    if (alertDialog.isShowing()) {
                        if (Intrinsics.areEqual(this.f$0, Guard.shownKey) && str.length() > 0) {
                            CharSequence text = textView.getText();
                            Intrinsics.checkNotNullExpressionValue(text, "getText(...)");
                            if (!StringsKt.endsWith$default(text, str)) {
                                textView.setText(((Object) textView.getText()) + "\n" + str);
                                return;
                            }
                            return;
                        }
                        return;
                    }
                    return;
                }
                return;
            default:
                TextView textView2 = Gp.status;
                if (textView2 != null) {
                    textView2.setText(this.f$0);
                    return;
                }
                return;
        }
    }
}
