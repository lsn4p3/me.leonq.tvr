package dev.tvremote.guard;

import android.os.Handler;
import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.FleetStatus;
import dev.tvremote.core.Lan;
import dev.tvremote.core.Lan$$ExternalSyntheticLambda0;
import dev.tvremote.core.ontv.Power;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;

/* loaded from: classes.dex */
public final /* synthetic */ class Guard$$ExternalSyntheticLambda4 implements Function1 {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ String f$0;

    public /* synthetic */ Guard$$ExternalSyntheticLambda4(String str, int i) {
        this.$r8$classId = i;
        this.f$0 = str;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        String str;
        Long longOrNull;
        boolean z = true;
        int i = 0;
        String host = this.f$0;
        switch (this.$r8$classId) {
            case 0:
                if (((Boolean) obj).booleanValue()) {
                    ((Handler) Guard.main$delegate.getValue()).post(new Guard$$ExternalSyntheticLambda12(host, i));
                }
                return Unit.INSTANCE;
            case 1:
                String k = (String) obj;
                Intrinsics.checkNotNullParameter(k, "k");
                String pattern = "(?m)^\\s*" + k + "=(\\S+) \\((-?\\d+) ms ago\\)";
                Intrinsics.checkNotNullParameter(pattern, "pattern");
                Pattern compile = Pattern.compile(pattern);
                Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                Matcher matcher = compile.matcher(host);
                Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
                MatcherMatchResult access$findNext = MathKt.access$findNext(matcher, 0, host);
                if (access$findNext == null) {
                    return null;
                }
                if (Intrinsics.areEqual(((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(1), "0")) {
                    access$findNext = null;
                }
                if (access$findNext == null || (str = (String) ((MatcherMatchResult$groupValues$1) access$findNext.getGroupValues()).get(2)) == null || (longOrNull = StringsKt__StringNumberConversionsKt.toLongOrNull(str)) == null) {
                    return null;
                }
                return Long.valueOf(longOrNull.longValue() / 1000);
            case 2:
                String k2 = (String) obj;
                Intrinsics.checkNotNullParameter(k2, "k");
                List list = Power.DEEP;
                return Power.find(ApkSigner$$ExternalSyntheticOutline0.m("(?m)^\\s*", k2, "=(\\S+)"), host);
            case 3:
                String it = (String) obj;
                Intrinsics.checkNotNullParameter(it, "it");
                return "pm grant " + host + " android.permission." + it + " >/dev/null 2>&1 && echo ok:" + it;
            case 4:
                String it2 = (String) obj;
                Intrinsics.checkNotNullParameter(it2, "it");
                return "pm revoke " + host + " android.permission." + it2 + " >/dev/null 2>&1 && echo ok:" + it2;
            case 5:
                String it3 = (String) obj;
                Intrinsics.checkNotNullParameter(it3, "it");
                return Boolean.valueOf(StringsKt__StringsJVMKt.endsWith(it3, false, "/ui_service/data/".concat(host)));
            default:
                int intValue = ((Integer) obj).intValue();
                Regex regex = FleetStatus.FOCUS;
                Intrinsics.checkNotNullParameter(host, "host");
                try {
                    Lan.connect(host, intValue, 1500, new Lan$$ExternalSyntheticLambda0(0)).close();
                } catch (Exception unused) {
                    z = false;
                }
                return Boolean.valueOf(z);
        }
    }
}
