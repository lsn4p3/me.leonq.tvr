package dev.tvremote.guard;

import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;

/* loaded from: classes.dex */
public abstract class GuardLogic {
    public static final Regex LIFECYCLE = new Regex("^(perform|handle)\\w*Activity\\w*$|^(perform)(Create|Start|Resume|Restart|NewIntent)\\w*$|^callActivityOn\\w+$|^execute(Callbacks|LifecycleState)?$");

    public static String key(Throwable th) {
        StackTraceElement stackTraceElement;
        String str;
        String name = th.getClass().getName();
        StackTraceElement[] stackTrace = th.getStackTrace();
        Intrinsics.checkNotNullExpressionValue(stackTrace, "getStackTrace(...)");
        if (stackTrace.length == 0) {
            stackTraceElement = null;
        } else {
            stackTraceElement = stackTrace[0];
        }
        if (stackTraceElement == null || (str = stackTraceElement.toString()) == null) {
            str = "";
        }
        return Census$$ExternalSyntheticOutline0.m(name, "@", str);
    }
}
