package dev.tvremote.guard;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.text.Editable;
import android.util.Log;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import com.android.apksig.internal.apk.ApkSigningBlockUtils;
import com.android.apksig.internal.apk.ApkSigningBlockUtils$$ExternalSyntheticLambda0;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.Errors;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Fleet$$ExternalSyntheticLambda0;
import dev.tvremote.core.FleetStatus;
import dev.tvremote.core.SupportRelay;
import dev.tvremote.core.WireLog;
import dev.tvremote.core.Words;
import dev.tvremote.core.Words$$ExternalSyntheticLambda1;
import dev.tvremote.core.adb.Adb;
import dev.tvremote.core.adb.AdbLink;
import dev.tvremote.core.adb.Mdns;
import dev.tvremote.core.ontv.Channels;
import dev.tvremote.core.ontv.Foreground;
import dev.tvremote.core.ontv.Games;
import dev.tvremote.core.ontv.Launchers;
import dev.tvremote.core.ontv.Privacy;
import dev.tvremote.core.picture.PrivateListen;
import dev.tvremote.core.picture.Tv;
import dev.tvremote.core.remote.Atv;
import dev.tvremote.core.remote.Lg$$ExternalSyntheticLambda2;
import dev.tvremote.core.remote.MqttLite;
import dev.tvremote.core.remote.Roku;
import dev.tvremote.core.remote.Vidaa$$ExternalSyntheticLambda3;
import dev.tvremote.core.remote.WebSocket;
import dev.tvremote.core.web.HttpServer;
import dev.tvremote.home.HomeQr$$ExternalSyntheticLambda0;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.QuietUpdate$Done;
import dev.tvremote.phone.ir.IrRemoteKt$$ExternalSyntheticLambda22;
import dev.tvremote.phone.manage.Managing;
import dev.tvremote.phone.media.MediaKt$castFile$tick$1;
import dev.tvremote.phone.media.PlayingBar;
import dev.tvremote.phone.media.PlayingBar$$ExternalSyntheticLambda11;
import dev.tvremote.phone.media.TalkKt$$ExternalSyntheticLambda2;
import dev.tvremote.phone.picker.PickerScreenKt;
import dev.tvremote.phone.picker.TvStatusKt$$ExternalSyntheticLambda9;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.tvapps.ApkCert$$ExternalSyntheticLambda0;
import dev.tvremote.update.Ed25519;
import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Phaser;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import javax.net.ssl.SSLSocket;
import kotlin.Pair;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$IntRef;
import kotlin.jvm.internal.Ref$ObjectRef;
import kotlin.math.MathKt;
import kotlin.text.Charsets;
import kotlin.text.Regex;
import org.conscrypt.FileClientSessionCache;
import org.conscrypt.metrics.ConscryptStatsLog;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final /* synthetic */ class Guard$$ExternalSyntheticLambda5 implements Runnable {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;
    public final /* synthetic */ Object f$1;

    public /* synthetic */ Guard$$ExternalSyntheticLambda5(int i, Object obj, Object obj2) {
        this.$r8$classId = i;
        this.f$0 = obj;
        this.f$1 = obj2;
    }

    private final void run$dev$tvremote$core$ontv$Privacy$Job$$ExternalSyntheticLambda0() {
        String str;
        String str2;
        Privacy.Job job = (Privacy.Job) this.f$0;
        int i = ((Ref$IntRef) this.f$1).element;
        job.getClass();
        long currentTimeMillis = System.currentTimeMillis();
        Privacy.Reader reader = new Privacy.Reader();
        try {
            try {
                Adb adb = job.link.get();
                LinkedHashMap linkedHashMap = Privacy.PERM_TAG;
                Adb.Stream open = adb.open(10000L, "shell:" + Privacy.command(Privacy.known().keySet()));
                synchronized (job.lock) {
                    job.stream = open;
                }
                byte[] bArr = new byte[8192];
                StringBuilder sb = new StringBuilder();
                long j = 0;
                while (true) {
                    try {
                        int read = open.read(2000L, bArr, 0, 8192);
                        if (read >= 0) {
                            if (read == 0) {
                                j += 2000;
                                if (j > 90000) {
                                    throw new IOException("privacy:stalled");
                                }
                            } else {
                                sb.append(new String(bArr, 0, read, Charsets.UTF_8));
                                while (true) {
                                    int indexOf = sb.indexOf("\n");
                                    if (indexOf >= 0) {
                                        String substring = sb.substring(0, indexOf);
                                        Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
                                        JSONObject line = reader.line(substring);
                                        sb.delete(0, indexOf + 1);
                                        synchronized (job.lock) {
                                            if (job.id == i) {
                                                job.total = reader.total;
                                                if (line != null) {
                                                    job.rows.add(line);
                                                }
                                            }
                                        }
                                        open.close();
                                        synchronized (job.lock) {
                                            if (job.id == i) {
                                                job.stream = null;
                                            }
                                        }
                                        return;
                                    }
                                    j = 0;
                                    break;
                                }
                            }
                        } else {
                            open.close();
                            synchronized (job.lock) {
                                try {
                                    if (job.id == i) {
                                        if (job.stopped) {
                                            str2 = "stopped";
                                        } else if (reader.done) {
                                            str2 = "done";
                                        } else {
                                            str2 = "error";
                                        }
                                        job.state = str2;
                                        if (str2.equals("error")) {
                                            job.msg = "incomplete";
                                        }
                                        job.took = System.currentTimeMillis() - currentTimeMillis;
                                    }
                                } finally {
                                }
                            }
                            synchronized (job.lock) {
                                if (job.id == i) {
                                    job.stream = null;
                                }
                            }
                            return;
                        }
                    } catch (Throwable th) {
                        open.close();
                        throw th;
                    }
                }
            } catch (Exception e) {
                synchronized (job.lock) {
                    try {
                        if (job.id == i) {
                            if (job.stopped) {
                                str = "stopped";
                            } else {
                                str = "error";
                            }
                            job.state = str;
                            String message = e.getMessage();
                            if (message == null) {
                                message = e.getClass().getSimpleName();
                            }
                            job.msg = message;
                            job.took = System.currentTimeMillis() - currentTimeMillis;
                        }
                        synchronized (job.lock) {
                            if (job.id == i) {
                                job.stream = null;
                            }
                        }
                    } finally {
                    }
                }
            }
        } catch (Throwable th2) {
            synchronized (job.lock) {
                if (job.id == i) {
                    job.stream = null;
                }
                throw th2;
            }
        }
    }

    private final void run$dev$tvremote$core$picture$Tv$$ExternalSyntheticLambda13() {
        boolean z;
        String str;
        Tv tv = (Tv) this.f$0;
        Fleet$$ExternalSyntheticLambda0 fleet$$ExternalSyntheticLambda0 = (Fleet$$ExternalSyntheticLambda0) this.f$1;
        synchronized (tv.quietLock) {
            if (tv.stopped) {
                return;
            }
            try {
                PrivateListen privateListen = PrivateListen.INSTANCE;
                z = PrivateListen.engage(fleet$$ExternalSyntheticLambda0);
            } catch (Exception unused) {
                z = false;
            }
            tv.quieted = z;
            if (tv.quieted) {
                str = "tvsilent";
            } else {
                str = "tvloud";
            }
            tv.status("audio", str);
        }
    }

    private final void run$dev$tvremote$core$picture$Tv$$ExternalSyntheticLambda17() {
        Adb.Stream stream = (Adb.Stream) this.f$0;
        StringBuilder sb = (StringBuilder) this.f$1;
        try {
            byte[] bArr = new byte[1024];
            while (true) {
                int read = stream.read(0L, bArr, 0, 1024);
                if (read >= 0) {
                    synchronized (sb) {
                        sb.append(new String(bArr, 0, read, Charsets.UTF_8));
                        if (sb.length() > 800) {
                            sb.delete(0, sb.length() - 800);
                        }
                    }
                } else {
                    return;
                }
            }
        } catch (IOException unused) {
        }
    }

    private final void run$dev$tvremote$core$picture$Tv$$ExternalSyntheticLambda2() {
        Adb.Stream stream;
        Tv tv = (Tv) this.f$0;
        byte[] bArr = (byte[]) this.f$1;
        Adb.Stream stream2 = tv.control;
        if (stream2 == null) {
            synchronized (tv.restLock) {
                try {
                    long currentTimeMillis = System.currentTimeMillis() + 3000;
                    while (tv.resting && !tv.stopped) {
                        long currentTimeMillis2 = currentTimeMillis - System.currentTimeMillis();
                        if (currentTimeMillis2 <= 0) {
                            break;
                        } else {
                            tv.restLock.wait(currentTimeMillis2);
                        }
                    }
                    stream = tv.control;
                } catch (Throwable th) {
                    throw th;
                }
            }
            if (stream != null) {
                stream2 = stream;
            } else {
                return;
            }
        }
        try {
            stream2.write(bArr);
        } catch (IOException unused) {
        }
    }

    private final void run$dev$tvremote$core$picture$Tv$$ExternalSyntheticLambda7() {
        Tv tv = (Tv) this.f$0;
        JSONObject jSONObject = (JSONObject) this.f$1;
        synchronized (tv.touchLock) {
            if (tv.heldDown == jSONObject) {
                tv.heldDown = null;
                tv.postTouch(jSONObject);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:146:0x02f0 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:150:0x02e7 A[SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r10v6, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void run() {
        FleetStatus.Status status;
        Socket accept;
        InetAddress inetAddress;
        AtomicInteger atomicInteger;
        String str;
        JSONObject m8m;
        LinkProperties linkProperties;
        List<LinkAddress> linkAddresses;
        int i = 16;
        Launchers.Gallery gallery = null;
        int i2 = 0;
        int i3 = 1;
        switch (this.$r8$classId) {
            case 0:
                Activity activity = (Activity) Guard.top.get();
                if (activity != null) {
                    HomeQr$$ExternalSyntheticLambda0 homeQr$$ExternalSyntheticLambda0 = Guard.words;
                    if (homeQr$$ExternalSyntheticLambda0 != null) {
                        GuardWords guardWords = (GuardWords) homeQr$$ExternalSyntheticLambda0.invoke(activity);
                        Regex regex = GuardLogic.LIFECYCLE;
                        Throwable th = (Throwable) this.f$1;
                        Guard.show(activity, guardWords.title, (String) this.f$0, GuardLogic.key(th), th);
                        return;
                    }
                    Intrinsics.throwUninitializedPropertyAccessException("words");
                    throw null;
                }
                return;
            case 1:
                ApkSigningBlockUtils$$ExternalSyntheticLambda0 apkSigningBlockUtils$$ExternalSyntheticLambda0 = (ApkSigningBlockUtils$$ExternalSyntheticLambda0) this.f$0;
                new MediaKt$castFile$tick$1((ApkSigningBlockUtils.ChunkSupplier) apkSigningBlockUtils$$ExternalSyntheticLambda0.f$0, (ArrayList) apkSigningBlockUtils$$ExternalSyntheticLambda0.f$1).run();
                ((Phaser) this.f$1).arriveAndDeregister();
                return;
            case 2:
                Ed25519.Pt pt = (Ed25519.Pt) this.f$1;
                String str2 = (String) this.f$0;
                try {
                    ConcurrentHashMap concurrentHashMap = (ConcurrentHashMap) pt.z;
                    try {
                        status = (FleetStatus.Status) ((ApkCert$$ExternalSyntheticLambda0) pt.x).invoke(str2);
                    } catch (Exception unused) {
                        status = new FleetStatus.Status(str2, "up", System.currentTimeMillis(), 508);
                    }
                    concurrentHashMap.put(str2, status);
                    synchronized (((ConcurrentHashMap) pt.t)) {
                    }
                    return;
                } catch (Throwable th2) {
                    synchronized (((ConcurrentHashMap) pt.t)) {
                        throw th2;
                    }
                }
            case 3:
                String m = Census$$ExternalSyntheticOutline0.m(SupportRelay.base(), "/live");
                JSONObject put = new JSONObject().put("code", (String) this.f$0).put("key", (String) this.f$1).put("minutes", 0);
                Intrinsics.checkNotNullExpressionValue(put, "put(...)");
                SupportRelay.post(m, put);
                return;
            case 4:
                AdbLink adbLink = (AdbLink) this.f$1;
                if (!((Adb) this.f$0).alive(4000L)) {
                    try {
                        adbLink.get();
                        return;
                    } catch (Exception unused2) {
                        return;
                    }
                }
                return;
            case 5:
                ((Ref$ObjectRef) this.f$0).element = Mdns.find$default(2500, "_adb-tls-pairing._tcp", (Function1) this.f$1);
                return;
            case 6:
                Foreground foreground = (Foreground) this.f$0;
                TalkKt$$ExternalSyntheticLambda2 talkKt$$ExternalSyntheticLambda2 = (TalkKt$$ExternalSyntheticLambda2) this.f$1;
                try {
                    Regex regex2 = Foreground.PKG;
                    foreground.pkg = Games.m13parse((String) talkKt$$ExternalSyntheticLambda2.invoke("dumpsys activity activities | grep -m1 -E 'mResumedActivity|topResumedActivity'"));
                } catch (Exception unused3) {
                    foreground.pkg = "";
                }
                foreground.at = System.currentTimeMillis();
                foreground.busy.set(false);
                return;
            case 7:
                run$dev$tvremote$core$ontv$Privacy$Job$$ExternalSyntheticLambda0();
                return;
            case 8:
                run$dev$tvremote$core$picture$Tv$$ExternalSyntheticLambda13();
                return;
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                run$dev$tvremote$core$picture$Tv$$ExternalSyntheticLambda17();
                return;
            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                Iterator it = ((ArrayList) this.f$0).iterator();
                while (it.hasNext()) {
                    try {
                        ((Adb.Stream) it.next()).close();
                    } catch (Exception unused4) {
                    }
                }
                Thread.sleep(20000L);
                ((Tv) this.f$1).letGo();
                return;
            case 11:
                run$dev$tvremote$core$picture$Tv$$ExternalSyntheticLambda2();
                return;
            case FileClientSessionCache.MAX_SIZE /* 12 */:
                Tv tv = (Tv) this.f$0;
                Tv tv2 = (Tv) this.f$1;
                while (tv.carrier == tv2 && !tv.stopped) {
                    try {
                        long currentTimeMillis = System.currentTimeMillis() - tv.ownUse;
                        if (currentTimeMillis >= 60000) {
                            if (tv2.ready()) {
                                tv.rest();
                                return;
                            }
                            return;
                        }
                        Thread.sleep(60000 - currentTimeMillis);
                    } catch (InterruptedException unused5) {
                        return;
                    }
                }
                return;
            case 13:
                run$dev$tvremote$core$picture$Tv$$ExternalSyntheticLambda7();
                return;
            case 14:
                Tv tv3 = (Tv) this.f$0;
                HttpURLConnection httpURLConnection = (HttpURLConnection) this.f$1;
                try {
                    Thread.sleep(8000L);
                    if (!tv3.framed && tv3.feedConn == httpURLConnection && !tv3.stopped) {
                        tv3.noFrame = true;
                        httpURLConnection.disconnect();
                        return;
                    }
                    return;
                } catch (InterruptedException | Exception unused6) {
                    return;
                }
            case 15:
                Atv atv = (Atv) this.f$0;
                byte[] bArr = (byte[]) this.f$1;
                while (i2 < 30 && !atv.live && !atv.closed) {
                    try {
                        Thread.sleep(200L);
                        i2++;
                    } catch (InterruptedException | Exception unused7) {
                        return;
                    }
                }
                SSLSocket sSLSocket = atv.sock;
                if (atv.live && sSLSocket != null) {
                    try {
                        atv.send(sSLSocket, bArr);
                        return;
                    } catch (Exception unused8) {
                        sSLSocket.close();
                        return;
                    }
                }
                return;
            case 16:
                WebSocket webSocket = (WebSocket) this.f$0;
                if (webSocket != null) {
                    webSocket.close();
                }
                WebSocket webSocket2 = (WebSocket) this.f$1;
                if (webSocket2 != null) {
                    webSocket2.close();
                    return;
                }
                return;
            case 17:
                Roku roku = (Roku) this.f$0;
                Function0 function0 = (Function0) this.f$1;
                while (true) {
                    int i4 = 0;
                    while (!roku.closed) {
                        try {
                            Thread.sleep(4000L);
                            if (!roku.closed) {
                                String fetch = roku.fetch("/query/device-info");
                                if (fetch == null) {
                                    i4++;
                                    if (i4 >= 3) {
                                    }
                                } else {
                                    Object obj = Roku.KEYS;
                                    String field$shared_release = Fleet.field$shared_release(fetch, "power-mode");
                                    if (field$shared_release.length() <= 0) {
                                        field$shared_release = null;
                                    }
                                    if (field$shared_release != null) {
                                        roku.isOn = Boolean.valueOf(field$shared_release.equals("PowerOn"));
                                    }
                                    String fetch2 = roku.fetch("/query/active-app");
                                    if (fetch2 != null) {
                                        roku.app = Fleet.activeApp$shared_release(fetch2);
                                    }
                                }
                            } else {
                                return;
                            }
                        } catch (InterruptedException unused9) {
                            return;
                        }
                    }
                }
                boolean z = roku.live;
                roku.live = false;
                if (z && !roku.closed) {
                    WireLog.all.add("·", "Roku " + roku.host + " stopped answering");
                    function0.invoke();
                    return;
                }
                return;
            case 18:
                MqttLite mqttLite = (MqttLite) this.f$0;
                if (mqttLite != null) {
                    mqttLite.close();
                }
                MqttLite mqttLite2 = (MqttLite) this.f$1;
                if (mqttLite2 != null) {
                    mqttLite2.close();
                    return;
                }
                return;
            case 19:
                ServerSocket serverSocket = (ServerSocket) this.f$0;
                HttpServer httpServer = (HttpServer) this.f$1;
                while (!serverSocket.isClosed()) {
                    try {
                        accept = serverSocket.accept();
                        inetAddress = accept.getInetAddress();
                    } catch (IOException unused10) {
                        if (!serverSocket.isClosed()) {
                            Thread.sleep(100L);
                        } else {
                            return;
                        }
                    }
                    if (inetAddress != null && !((Boolean) HttpServer.trusted.invoke(inetAddress)).booleanValue()) {
                        String hostAddress = inetAddress.getHostAddress();
                        if (hostAddress == null) {
                            hostAddress = "";
                        }
                        atomicInteger = (AtomicInteger) httpServer.perPeer.get(hostAddress);
                        if (atomicInteger == null) {
                            atomicInteger = new AtomicInteger();
                            AtomicInteger atomicInteger2 = (AtomicInteger) httpServer.perPeer.putIfAbsent(hostAddress, atomicInteger);
                            if (atomicInteger2 != null) {
                                atomicInteger = atomicInteger2;
                            }
                        }
                        if (atomicInteger == null && atomicInteger.incrementAndGet() > 16) {
                            atomicInteger.decrementAndGet();
                            try {
                                accept.close();
                            } catch (IOException | InterruptedException unused11) {
                            }
                        } else if (httpServer.slots.tryAcquire()) {
                            if (atomicInteger != null) {
                                atomicInteger.decrementAndGet();
                            }
                            accept.close();
                        } else {
                            httpServer.pool.execute(new Lg$$ExternalSyntheticLambda2(httpServer, accept, atomicInteger, 8));
                        }
                    }
                    atomicInteger = null;
                    if (atomicInteger == null) {
                    }
                    if (httpServer.slots.tryAcquire()) {
                    }
                }
                return;
            case 20:
                Context context = (Context) this.f$0;
                File file = (File) this.f$1;
                try {
                    try {
                        MathKt.commit(context, file, new Intent(context, (Class<?>) QuietUpdate$Done.class), false, true);
                    } finally {
                        file.delete();
                    }
                } catch (Exception e) {
                    Log.w("QuietUpdate", "install: " + e);
                }
                return;
            case 21:
                ((Managing) this.f$1).a.working$android_release((String) this.f$0);
                return;
            case 22:
                ((Managing) this.f$0).web.evaluateJavascript("window.nativeJob && nativeJob(" + ((JSONObject) this.f$1) + ")", null);
                return;
            case 23:
                EditText editText = (EditText) this.f$0;
                editText.requestFocus();
                Object systemService = ((MainActivity) this.f$1).getSystemService("input_method");
                Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
                ((InputMethodManager) systemService).showSoftInput(editText, 0);
                return;
            case 24:
                if (((Channels.Play) this.f$1) == Channels.Play.OLD) {
                    str = "core.fr_channels_old";
                } else {
                    str = "remote.stream_needs_channels";
                }
                Fleet.say((MainActivity) this.f$0, Fleet.T(str, new Pair[0]), false);
                return;
            case 25:
                PlayingBar playingBar = (PlayingBar) this.f$0;
                Tv tv4 = (Tv) this.f$1;
                try {
                    Intrinsics.checkNotNull(tv4);
                    m8m = playingBar.player(tv4).state();
                } catch (Exception unused12) {
                    m8m = Census$$ExternalSyntheticOutline0.m8m("state", "none");
                }
                playingBar.a.ui.post(new PlayingBar$$ExternalSyntheticLambda11(playingBar, m8m, i3));
                return;
            case 26:
                EditText editText2 = (EditText) this.f$0;
                Editable text = editText2.getText();
                Intrinsics.checkNotNullExpressionValue(text, "getText(...)");
                if (text.length() == 0) {
                    Mdns.Service service = (Mdns.Service) this.f$1;
                    editText2.setText(service.ip + ":" + service.port);
                    return;
                }
                return;
            case 27:
                MainActivity mainActivity = (MainActivity) this.f$0;
                Popup popup = (Popup) this.f$1;
                ?? obj2 = new Object();
                obj2.element = "";
                try {
                    gallery = Launchers.fetch$default();
                } catch (Exception e2) {
                    Object obj3 = Errors.ANDROID;
                    ConcurrentHashMap concurrentHashMap2 = Words.books;
                    obj2.element = Errors.say(Words.lang, e2);
                }
                mainActivity.ui.post(new Vidaa$$ExternalSyntheticLambda3(popup, mainActivity, gallery, (Object) obj2, 9));
                return;
            case 28:
                ((ImageView) this.f$0).setImageBitmap((Bitmap) this.f$1);
                return;
            default:
                MainActivity mainActivity2 = (MainActivity) this.f$0;
                Set set = (Set) this.f$1;
                ArrayList arrayList = new ArrayList();
                List synchronizedList = Collections.synchronizedList(new ArrayList());
                try {
                    Words$$ExternalSyntheticLambda1 words$$ExternalSyntheticLambda1 = new Words$$ExternalSyntheticLambda1(15, arrayList);
                    try {
                        Iterator it2 = Collections.list(NetworkInterface.getNetworkInterfaces()).iterator();
                        Intrinsics.checkNotNullExpressionValue(it2, "iterator(...)");
                        while (it2.hasNext()) {
                            NetworkInterface networkInterface = (NetworkInterface) it2.next();
                            if (networkInterface.isUp() && !networkInterface.isLoopback()) {
                                Regex regex3 = PickerScreenKt.MOBILE;
                                String name = networkInterface.getName();
                                Intrinsics.checkNotNullExpressionValue(name, "getName(...)");
                                if (!regex3.containsMatchIn(name)) {
                                    Iterator it3 = Collections.list(networkInterface.getInetAddresses()).iterator();
                                    Intrinsics.checkNotNullExpressionValue(it3, "iterator(...)");
                                    while (it3.hasNext()) {
                                        words$$ExternalSyntheticLambda1.invoke((InetAddress) it3.next());
                                    }
                                }
                            }
                        }
                    } catch (Exception unused13) {
                    }
                    try {
                        Object systemService2 = mainActivity2.getSystemService("connectivity");
                        Intrinsics.checkNotNull(systemService2, "null cannot be cast to non-null type android.net.ConnectivityManager");
                        ConnectivityManager connectivityManager = (ConnectivityManager) systemService2;
                        Network[] allNetworks = connectivityManager.getAllNetworks();
                        int length = allNetworks.length;
                        while (i2 < length) {
                            Network network = allNetworks[i2];
                            NetworkCapabilities networkCapabilities = connectivityManager.getNetworkCapabilities(network);
                            if (networkCapabilities != null && ((networkCapabilities.hasTransport(1) || networkCapabilities.hasTransport(3)) && (linkProperties = connectivityManager.getLinkProperties(network)) != null && (linkAddresses = linkProperties.getLinkAddresses()) != null)) {
                                Iterator<T> it4 = linkAddresses.iterator();
                                while (it4.hasNext()) {
                                    words$$ExternalSyntheticLambda1.invoke(((LinkAddress) it4.next()).getAddress());
                                }
                            }
                            i2++;
                        }
                    } catch (Exception unused14) {
                    }
                    Network lanNetwork = MathKt.lanNetwork(mainActivity2);
                    IrRemoteKt$$ExternalSyntheticLambda22 irRemoteKt$$ExternalSyntheticLambda22 = new IrRemoteKt$$ExternalSyntheticLambda22(synchronizedList, lanNetwork, set, mainActivity2);
                    Function0 announced = MathKt.announced(mainActivity2, new Words$$ExternalSyntheticLambda1(i, irRemoteKt$$ExternalSyntheticLambda22));
                    Thread thread = new Thread(new Lg$$ExternalSyntheticLambda2(lanNetwork, synchronizedList, mainActivity2, 21));
                    thread.start();
                    ExecutorService newFixedThreadPool = Executors.newFixedThreadPool(96);
                    Iterator it5 = arrayList.iterator();
                    Intrinsics.checkNotNullExpressionValue(it5, "iterator(...)");
                    while (it5.hasNext()) {
                        String str3 = (String) it5.next();
                        for (int i5 = 1; i5 < 255; i5++) {
                            newFixedThreadPool.execute(new Lg$$ExternalSyntheticLambda2(str3 + i5, lanNetwork, irRemoteKt$$ExternalSyntheticLambda22, 22));
                        }
                    }
                    newFixedThreadPool.shutdown();
                    newFixedThreadPool.awaitTermination(25L, TimeUnit.SECONDS);
                    thread.join(5000L);
                    announced.invoke();
                } catch (Exception unused15) {
                }
                mainActivity2.ui.post(new TvStatusKt$$ExternalSyntheticLambda9(mainActivity2, arrayList));
                return;
        }
    }

    public /* synthetic */ Guard$$ExternalSyntheticLambda5(SupportRelay supportRelay, String str, String str2) {
        this.$r8$classId = 3;
        this.f$0 = str;
        this.f$1 = str2;
    }

    public /* synthetic */ Guard$$ExternalSyntheticLambda5(Object obj, String str, int i) {
        this.$r8$classId = i;
        this.f$1 = obj;
        this.f$0 = str;
    }
}
