package dev.tvremote.guard;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.PictureInPictureParams;
import android.app.RemoteAction;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Rect;
import android.graphics.drawable.Icon;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Rational;
import android.widget.Button;
import dev.tvremote.phone.ListenService;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.SceneService;
import java.util.ArrayList;

/* loaded from: classes.dex */
public abstract /* synthetic */ class Guard$$ExternalSyntheticApiModelOutline0 {
    public static /* synthetic */ Notification.Builder m(Context context) {
        return new Notification.Builder(context, "work");
    }

    public static /* synthetic */ NotificationChannel m$1(String str) {
        return new NotificationChannel("jobs", str, 1);
    }

    public static /* synthetic */ NotificationChannel m$2(String str) {
        return new NotificationChannel("work", str, 2);
    }

    public static /* synthetic */ Notification.Builder m(ListenService listenService) {
        return new Notification.Builder(listenService, "listen");
    }

    public static /* synthetic */ void m$1() {
    }

    public static /* synthetic */ Notification.Builder m(SceneService sceneService) {
        return new Notification.Builder(sceneService, "jobs");
    }

    public static /* bridge */ /* synthetic */ void m$1(MainActivity mainActivity, PictureInPictureParams pictureInPictureParams) {
        mainActivity.enterPictureInPictureMode(pictureInPictureParams);
    }

    public static /* synthetic */ NotificationChannel m(String str) {
        return new NotificationChannel("listen", str, 2);
    }

    public static /* synthetic */ PictureInPictureParams.Builder m() {
        return new PictureInPictureParams.Builder();
    }

    public static /* bridge */ /* synthetic */ PictureInPictureParams m(PictureInPictureParams.Builder builder) {
        return builder.build();
    }

    public static /* synthetic */ RemoteAction m(Icon icon, String str, String str2, PendingIntent pendingIntent) {
        return new RemoteAction(icon, str, str2, pendingIntent);
    }

    /* renamed from: m, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ VibrationEffect m16m() {
        return VibrationEffect.createOneShot(18L, -1);
    }

    /* renamed from: m, reason: collision with other method in class */
    public static /* synthetic */ void m18m() {
    }

    public static /* bridge */ /* synthetic */ void m(NotificationManager notificationManager, NotificationChannel notificationChannel) {
        notificationManager.createNotificationChannel(notificationChannel);
    }

    public static /* bridge */ /* synthetic */ void m(PictureInPictureParams.Builder builder, Rect rect) {
        builder.setSourceRectHint(rect);
    }

    public static /* bridge */ /* synthetic */ void m(PictureInPictureParams.Builder builder, Rational rational) {
        builder.setAspectRatio(rational);
    }

    public static /* bridge */ /* synthetic */ void m(PictureInPictureParams.Builder builder, ArrayList arrayList) {
        builder.setActions(arrayList);
    }

    public static /* bridge */ /* synthetic */ void m(Vibrator vibrator, VibrationEffect vibrationEffect) {
        vibrator.vibrate(vibrationEffect);
    }

    public static /* bridge */ /* synthetic */ void m(Button button, String str) {
        button.setTooltipText(str);
    }

    public static /* bridge */ /* synthetic */ void m(MainActivity mainActivity, PictureInPictureParams pictureInPictureParams) {
        mainActivity.setPictureInPictureParams(pictureInPictureParams);
    }

    public static /* bridge */ /* synthetic */ void m(MainActivity mainActivity, Intent intent) {
        mainActivity.startForegroundService(intent);
    }

    public static /* bridge */ /* synthetic */ void m(MainActivity mainActivity, Guard$install$r$1 guard$install$r$1, IntentFilter intentFilter) {
        mainActivity.registerReceiver(guard$install$r$1, intentFilter, 2);
    }

    public static /* bridge */ /* synthetic */ boolean m(PackageManager packageManager) {
        return packageManager.canRequestPackageInstalls();
    }
}
