package dev.tvremote.guard;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.adb.Adb$$ExternalSyntheticLambda0;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.PhoneApp;
import dev.tvremote.phone.media.Talk;
import java.io.File;
import java.util.List;
import kotlin.collections.CollectionsKt;
import kotlin.collections.EmptyList;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.StringsKt;

/* loaded from: classes.dex */
public final class Guard$install$r$1 extends BroadcastReceiver {
    public final /* synthetic */ Object $app;
    public final /* synthetic */ int $r8$classId;

    public /* synthetic */ Guard$install$r$1(int i, Object obj) {
        this.$r8$classId = i;
        this.$app = obj;
    }

    @Override // android.content.BroadcastReceiver
    public final void onReceive(Context c, Intent i) {
        Iterable iterable;
        int i2 = 5;
        int i3 = 6;
        Object obj = this.$app;
        int i4 = this.$r8$classId;
        Intrinsics.checkNotNullParameter(c, "c");
        Intrinsics.checkNotNullParameter(i, "i");
        switch (i4) {
            case 0:
                if (Intrinsics.areEqual(i.getStringExtra("on"), "gone")) {
                    Activity activity = (Activity) Guard.top.get();
                    if (activity != null) {
                        activity.finish();
                        ((Handler) Guard.main$delegate.getValue()).postDelayed(new Adb$$ExternalSyntheticLambda0(i2, activity), 1000L);
                        return;
                    }
                    return;
                }
                if (Intrinsics.areEqual(i.getStringExtra("on"), "resume")) {
                    MathKt.writeText$default(new File(((PhoneApp) obj).getFilesDir(), "guard-resume-throw"), "1");
                    return;
                }
                PhoneApp phoneApp = Guard.app;
                if (!Intrinsics.areEqual(i.getStringExtra("on"), "bg")) {
                    ((Handler) Guard.main$delegate.getValue()).post(new Guard$$ExternalSyntheticLambda3(i2));
                    return;
                } else {
                    new Thread(new Guard$$ExternalSyntheticLambda3(i3), "guard-test").start();
                    return;
                }
            case 1:
                String stringExtra = i.getStringExtra("text");
                if (stringExtra == null) {
                    stringExtra = "";
                }
                String stringExtra2 = i.getStringExtra("op");
                if (stringExtra2 != null) {
                    Talk talk = (Talk) obj;
                    switch (stringExtra2.hashCode()) {
                        case -1367724422:
                            if (stringExtra2.equals("cancel")) {
                                talk.let_go(true);
                                return;
                            }
                            return;
                        case -792934015:
                            if (stringExtra2.equals("partial")) {
                                List listOf = MathKt.listOf(stringExtra);
                                String stringExtra3 = i.getStringExtra("alt");
                                if (stringExtra3 != null) {
                                    iterable = StringsKt.split$default(stringExtra3, new String[]{"|"}, 0, 6);
                                } else {
                                    iterable = EmptyList.INSTANCE;
                                }
                                Talk.access$heard(talk, CollectionsKt.plus(listOf, iterable), false);
                                return;
                            }
                            return;
                        case 3739:
                            if (stringExtra2.equals("up")) {
                                talk.let_go(false);
                                return;
                            }
                            return;
                        case 101143:
                            if (stringExtra2.equals("far")) {
                                talk.cancelling = true;
                                talk.paintButton();
                                return;
                            }
                            return;
                        case 3089570:
                            if (stringExtra2.equals("down")) {
                                talk.begin(true);
                                return;
                            }
                            return;
                        case 97436022:
                            if (stringExtra2.equals("final")) {
                                Talk.access$heard(talk, MathKt.listOf(stringExtra), true);
                                return;
                            }
                            return;
                        default:
                            return;
                    }
                }
                return;
            default:
                int intExtra = i.getIntExtra("a", 0);
                MainActivity mainActivity = (MainActivity) obj;
                if (intExtra != 1) {
                    if (intExtra == 2) {
                        mainActivity.stopPicture$android_release();
                        mainActivity.moveTaskToBack(true);
                        return;
                    }
                    return;
                }
                Fleet.toggleListen(mainActivity);
                return;
        }
    }
}
