package dev.tvremote.guard;

import android.os.Looper;
import android.os.Process;
import dev.tvremote.phone.PhoneApp;
import java.lang.Thread;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final /* synthetic */ class Guard$$ExternalSyntheticLambda2 implements Thread.UncaughtExceptionHandler {
    @Override // java.lang.Thread.UncaughtExceptionHandler
    public final void uncaughtException(Thread thread, Throwable th) {
        PhoneApp phoneApp = Guard.app;
        Intrinsics.checkNotNull(thread);
        Intrinsics.checkNotNull(th);
        if (thread == Looper.getMainLooper().getThread()) {
            Guard.save(thread, th, true);
            Thread.UncaughtExceptionHandler uncaughtExceptionHandler = Guard.prev;
            if (uncaughtExceptionHandler != null) {
                uncaughtExceptionHandler.uncaughtException(thread, th);
            }
            Process.killProcess(Process.myPid());
            return;
        }
        Guard.report(thread, th);
    }
}
