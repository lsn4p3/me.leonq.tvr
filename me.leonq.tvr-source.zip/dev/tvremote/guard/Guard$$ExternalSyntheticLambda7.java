package dev.tvremote.guard;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.adb.Adb$$ExternalSyntheticLambda5;
import dev.tvremote.core.ontv.Axml$$ExternalSyntheticLambda2;
import dev.tvremote.core.ontv.Launchers;
import dev.tvremote.core.ontv.Setup$$ExternalSyntheticLambda5;
import dev.tvremote.core.remote.Vidaa$$ExternalSyntheticLambda6;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.ir.IrProfile;
import dev.tvremote.phone.ir.IrRemoteKt;
import dev.tvremote.phone.picker.AppRow;
import dev.tvremote.phone.picker.ManyTvsKt$$ExternalSyntheticLambda41;
import dev.tvremote.phone.picker.NetKt$$ExternalSyntheticLambda3;
import dev.tvremote.phone.picture.Air;
import dev.tvremote.phone.remote.RemoteScreenKt$$ExternalSyntheticLambda9;
import dev.tvremote.phone.remote.TypingKt;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.phone.ui.UiKt;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$BooleanRef;
import kotlin.jvm.internal.Ref$IntRef;
import kotlin.jvm.internal.Ref$ObjectRef;

/* loaded from: classes.dex */
public final /* synthetic */ class Guard$$ExternalSyntheticLambda7 implements View.OnClickListener {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;
    public final /* synthetic */ Object f$1;
    public final /* synthetic */ Object f$2;

    public /* synthetic */ Guard$$ExternalSyntheticLambda7(Object obj, Object obj2, Object obj3, int i) {
        this.$r8$classId = i;
        this.f$0 = obj;
        this.f$1 = obj2;
        this.f$2 = obj3;
    }

    /* JADX WARN: Removed duplicated region for block: B:36:0x00fa A[LOOP:2: B:34:0x00f4->B:36:0x00fa, LOOP_END] */
    @Override // android.view.View.OnClickListener
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onClick(View view) {
        Iterator it;
        int i = -1;
        boolean z = false;
        int i2 = 0;
        boolean z2 = false;
        Object obj = this.f$2;
        Object obj2 = this.f$0;
        Object obj3 = this.f$1;
        switch (this.$r8$classId) {
            case 0:
                Object systemService = ((Activity) obj2).getSystemService("clipboard");
                Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.content.ClipboardManager");
                ((ClipboardManager) systemService).setPrimaryClip(ClipData.newPlainText("error", (String) obj3));
                Intrinsics.checkNotNull(view, "null cannot be cast to non-null type android.widget.TextView");
                ((TextView) view).setText(((GuardWords) obj).copied);
                return;
            case 1:
                String str = (String) obj3;
                if (!Intrinsics.areEqual(str, ((Ref$ObjectRef) obj2).element)) {
                    IrRemoteKt.irFind((MainActivity) obj, str, -1);
                    return;
                }
                return;
            case 2:
                IrProfile irProfile = (IrProfile) ((Pair) ((ArrayList) obj2).get(((Ref$IntRef) obj3).element)).first;
                MainActivity mainActivity = (MainActivity) obj;
                IrRemoteKt.irSave(mainActivity, irProfile);
                Toast.makeText(mainActivity, Fleet.T("ir.found", new Pair("name", IrRemoteKt.getTitle(irProfile))), 1).show();
                IrRemoteKt.irRemote(mainActivity);
                return;
            case 3:
                Ref$BooleanRef ref$BooleanRef = (Ref$BooleanRef) obj2;
                if (!ref$BooleanRef.element) {
                    ref$BooleanRef.element = true;
                    ((Axml$$ExternalSyntheticLambda2) obj3).invoke(Boolean.TRUE);
                    ((Adb$$ExternalSyntheticLambda5) obj).invoke("adb_help.checking_on_the_tv");
                    return;
                }
                return;
            case 4:
                Object obj4 = ((Ref$ObjectRef) obj2).element;
                if (obj4 != null) {
                    ((Popup) obj4).dismiss();
                    ((Axml$$ExternalSyntheticLambda2) obj3).invoke((Launchers.Entry) obj);
                    return;
                } else {
                    Intrinsics.throwUninitializedPropertyAccessException("box");
                    throw null;
                }
            case 5:
                ((ManyTvsKt$$ExternalSyntheticLambda41) obj2).invoke((AppRow) obj3, Boolean.valueOf(!r8.picked));
                ((NetKt$$ExternalSyntheticLambda3) obj).invoke();
                return;
            case 6:
                List list = (List) ((Setup$$ExternalSyntheticLambda5) obj2).invoke();
                if (!list.isEmpty()) {
                    Iterator it2 = list.iterator();
                    while (it2.hasNext()) {
                        if (!((AppRow) it2.next()).picked) {
                            it = list.iterator();
                            while (it.hasNext()) {
                                ((ManyTvsKt$$ExternalSyntheticLambda41) obj).invoke((AppRow) it.next(), Boolean.valueOf(!z));
                            }
                            ((NetKt$$ExternalSyntheticLambda3) obj3).invoke();
                            return;
                        }
                    }
                }
                z = true;
                it = list.iterator();
                while (it.hasNext()) {
                }
                ((NetKt$$ExternalSyntheticLambda3) obj3).invoke();
                return;
            case 7:
                TypingKt.slide(((MainActivity) obj2).getControls$android_release());
                if (((LinearLayout) obj).getVisibility() != 0) {
                    z2 = true;
                }
                ((RemoteScreenKt$$ExternalSyntheticLambda9) obj3).invoke(Boolean.valueOf(z2));
                return;
            default:
                List asList = ArraysKt.asList(new String[]{Fleet.T("remote_screen.mid_arrows_sub", new Pair[0]), Fleet.T("remote_screen.mid_touch_sub", new Pair[0]), Fleet.T("remote_screen.mid_mouse_sub", new Pair[0])});
                String T = Fleet.T("remote_screen.mid_title", new Pair[0]);
                List list2 = (List) obj3;
                Iterator it3 = list2.iterator();
                int i3 = 0;
                while (true) {
                    if (it3.hasNext()) {
                        if (Intrinsics.areEqual(((Pair) it3.next()).first, Air.mode)) {
                            i = i3;
                        } else {
                            i3++;
                        }
                    }
                }
                ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(list2));
                Iterator it4 = list2.iterator();
                while (true) {
                    MainActivity mainActivity2 = (MainActivity) obj2;
                    if (it4.hasNext()) {
                        Object next = it4.next();
                        int i4 = i2 + 1;
                        if (i2 >= 0) {
                            Pair pair = (Pair) next;
                            arrayList.add(new Triple((String) pair.second, asList.get(i2), new Vidaa$$ExternalSyntheticLambda6((String) pair.first, (Object) mainActivity2, obj, 11)));
                            i2 = i4;
                        } else {
                            CollectionsKt__CollectionsKt.throwIndexOverflow();
                            throw null;
                        }
                    } else {
                        UiKt.menu(mainActivity2, T, i, arrayList);
                        return;
                    }
                }
        }
    }

    public /* synthetic */ Guard$$ExternalSyntheticLambda7(String str, Ref$ObjectRef ref$ObjectRef, MainActivity mainActivity) {
        this.$r8$classId = 1;
        this.f$1 = str;
        this.f$0 = ref$ObjectRef;
        this.f$2 = mainActivity;
    }
}
