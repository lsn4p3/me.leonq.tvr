package dev.tvremote.guard;

import dev.tvremote.core.Lan$$ExternalSyntheticLambda0;
import kotlin.jvm.internal.Intrinsics;

/* loaded from: classes.dex */
public final class GuardWords {
    public final String close;
    public final String copied;
    public final String copy;
    public final String lastTime;
    public final Lan$$ExternalSyntheticLambda0 repeat;
    public final String sent;
    public final String share;
    public final String title;

    public GuardWords(String title, String lastTime, String copy, String copied, String share, String close, String sent, Lan$$ExternalSyntheticLambda0 lan$$ExternalSyntheticLambda0) {
        Intrinsics.checkNotNullParameter(title, "title");
        Intrinsics.checkNotNullParameter(lastTime, "lastTime");
        Intrinsics.checkNotNullParameter(copy, "copy");
        Intrinsics.checkNotNullParameter(copied, "copied");
        Intrinsics.checkNotNullParameter(share, "share");
        Intrinsics.checkNotNullParameter(close, "close");
        Intrinsics.checkNotNullParameter(sent, "sent");
        this.title = title;
        this.lastTime = lastTime;
        this.copy = copy;
        this.copied = copied;
        this.share = share;
        this.close = close;
        this.sent = sent;
        this.repeat = lan$$ExternalSyntheticLambda0;
    }
}
