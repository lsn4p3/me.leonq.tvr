package dev.tvremote.guard;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Toast;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.ontv.Axml$$ExternalSyntheticLambda2;
import dev.tvremote.core.ontv.Launchers;
import dev.tvremote.core.ontv.Setup$$ExternalSyntheticLambda5;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.ir.IrProfile;
import dev.tvremote.phone.ir.IrRemoteKt;
import dev.tvremote.phone.ir.IrState;
import dev.tvremote.phone.picker.Part;
import dev.tvremote.phone.picker.PickerScreenKt;
import dev.tvremote.phone.picker.TvStatus;
import dev.tvremote.phone.picker.TvStatusKt;
import dev.tvremote.phone.picture.Air;
import dev.tvremote.phone.picture.DrawingKt$$ExternalSyntheticLambda22;
import dev.tvremote.phone.picture.DrawingKt$$ExternalSyntheticLambda3;
import dev.tvremote.phone.remote.TypingKt;
import dev.tvremote.phone.ui.Popup;
import dev.tvremote.phone.ui.UiKt;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref$ObjectRef;

/* loaded from: classes.dex */
public final /* synthetic */ class Guard$$ExternalSyntheticLambda9 implements View.OnClickListener {
    public final /* synthetic */ int $r8$classId;
    public final /* synthetic */ Object f$0;
    public final /* synthetic */ Object f$1;

    public /* synthetic */ Guard$$ExternalSyntheticLambda9(int i, Object obj, Object obj2) {
        this.$r8$classId = i;
        this.f$0 = obj;
        this.f$1 = obj2;
    }

    /* JADX WARN: Type inference failed for: r9v2, types: [java.lang.Object, kotlin.jvm.internal.Ref$ObjectRef] */
    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        int i;
        int i2;
        int i3;
        int i4 = 1;
        boolean z = true;
        switch (this.$r8$classId) {
            case 0:
                ((Activity) this.f$0).startActivity(Intent.createChooser(new Intent("android.intent.action.SEND").setType("text/plain").putExtra("android.intent.extra.TEXT", (String) this.f$1), null));
                return;
            case 1:
                MainActivity mainActivity = (MainActivity) this.f$0;
                IrProfile irProfile = (IrProfile) this.f$1;
                IrRemoteKt.irSave(mainActivity, irProfile);
                mainActivity.getPrefs$android_release().edit().putString("ir:profile:".concat(IrState.auto), irProfile.id).apply();
                Toast.makeText(mainActivity, Fleet.T("ir.found", new Pair("name", IrRemoteKt.getTitle(irProfile))), 1).show();
                IrRemoteKt.irRemote(mainActivity);
                return;
            case 2:
                Iterator it = ((ArrayList) this.f$0).iterator();
                while (it.hasNext()) {
                    ((Part) it.next()).cancel.stop();
                }
                ((Button) this.f$1).setEnabled(false);
                return;
            case 3:
                Fleet.web((MainActivity) this.f$0, ((Launchers.Entry) this.f$1).source);
                return;
            case 4:
                MainActivity mainActivity2 = (MainActivity) this.f$0;
                Button button = (Button) this.f$1;
                boolean z2 = TvStatus.shots;
                TvStatus.shots = !TvStatus.shots;
                mainActivity2.getPrefs$android_release().edit().putBoolean("tvshots", TvStatus.shots).apply();
                UiKt.setOn$default(button, TvStatus.shots, 0, 6);
                PickerScreenKt.refreshSaved(mainActivity2);
                mainActivity2.ui.removeCallbacks(TvStatusKt.getShotTick(mainActivity2));
                if (TvStatus.shots) {
                    mainActivity2.ui.post(TvStatusKt.getShotTick(mainActivity2));
                    return;
                }
                return;
            case 5:
                final Setup$$ExternalSyntheticLambda5 setup$$ExternalSyntheticLambda5 = new Setup$$ExternalSyntheticLambda5(13, (DrawingKt$$ExternalSyntheticLambda3) this.f$1);
                final MainActivity mainActivity3 = (MainActivity) this.f$0;
                LinearLayout linearLayout = new LinearLayout(mainActivity3);
                linearLayout.setOrientation(1);
                boolean z3 = UiKt.LIGHT;
                float f = 20;
                linearLayout.setPadding(UiKt.dp(mainActivity3, f), UiKt.dp(mainActivity3, 16), UiKt.dp(mainActivity3, f), UiKt.dp(mainActivity3, 4));
                ?? obj = new Object();
                int[] iArr = Air.DRAW_COLORS;
                ArrayList arrayList = new ArrayList(10);
                for (int i5 = 0; i5 < 10; i5++) {
                    arrayList.add(Integer.valueOf(iArr[i5]));
                }
                int i6 = 5;
                Iterator it2 = CollectionsKt.chunked(arrayList, 5).iterator();
                while (it2.hasNext()) {
                    List list = (List) it2.next();
                    LinearLayout linearLayout2 = new LinearLayout(mainActivity3);
                    linearLayout2.setGravity(17);
                    Iterator it3 = list.iterator();
                    while (it3.hasNext()) {
                        int intValue = ((Number) it3.next()).intValue();
                        View view2 = new View(mainActivity3);
                        GradientDrawable gradientDrawable = new GradientDrawable();
                        gradientDrawable.setShape(i4);
                        gradientDrawable.setColor(intValue);
                        if (intValue == mainActivity3.drawColor) {
                            i = 4;
                        } else {
                            i = 1;
                        }
                        int dp = UiKt.dp(mainActivity3, i);
                        if (intValue == mainActivity3.drawColor) {
                            i2 = UiKt.ACCENT;
                        } else {
                            i2 = 1728053247;
                        }
                        gradientDrawable.setStroke(dp, i2);
                        view2.setBackground(gradientDrawable);
                        view2.setContentDescription(Fleet.T("remote.colour", new Pair[0]));
                        view2.setOnClickListener(new DrawingKt$$ExternalSyntheticLambda22(mainActivity3, intValue, setup$$ExternalSyntheticLambda5, (Ref$ObjectRef) obj));
                        float f2 = 40;
                        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(UiKt.dp(mainActivity3, f2), UiKt.dp(mainActivity3, f2));
                        float f3 = i6;
                        layoutParams.setMargins(UiKt.dp(mainActivity3, f3), UiKt.dp(mainActivity3, f3), UiKt.dp(mainActivity3, f3), UiKt.dp(mainActivity3, f3));
                        linearLayout2.addView(view2, layoutParams);
                        i4 = 1;
                        i6 = 5;
                    }
                    linearLayout.addView(linearLayout2, new LinearLayout.LayoutParams(-1, -2));
                    i4 = 1;
                    i6 = 5;
                }
                View view3 = new View(mainActivity3);
                GradientDrawable gradientDrawable2 = new GradientDrawable();
                gradientDrawable2.setShape(1);
                gradientDrawable2.setColor(mainActivity3.drawColor);
                gradientDrawable2.setStroke(1, 1509949439);
                view3.setBackground(gradientDrawable2);
                FrameLayout frameLayout = new FrameLayout(mainActivity3);
                frameLayout.addView(view3);
                final DrawingKt$$ExternalSyntheticLambda3 drawingKt$$ExternalSyntheticLambda3 = new DrawingKt$$ExternalSyntheticLambda3(mainActivity3, view3);
                drawingKt$$ExternalSyntheticLambda3.invoke();
                SeekBar seekBar = new SeekBar(mainActivity3);
                seekBar.setMax(23);
                seekBar.setProgress((mainActivity3.drawWidth - 20) / 10);
                seekBar.setContentDescription(Fleet.T("remote.line_size", new Pair[0]));
                seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: dev.tvremote.phone.picture.DrawingKt$drawPen$5
                    @Override // android.widget.SeekBar.OnSeekBarChangeListener
                    public final void onProgressChanged(SeekBar b, int i7, boolean z4) {
                        Intrinsics.checkNotNullParameter(b, "b");
                        MainActivity.this.drawWidth = (i7 * 10) + 20;
                        setup$$ExternalSyntheticLambda5.invoke();
                        drawingKt$$ExternalSyntheticLambda3.invoke();
                    }

                    @Override // android.widget.SeekBar.OnSeekBarChangeListener
                    public final void onStartTrackingTouch(SeekBar b) {
                        Intrinsics.checkNotNullParameter(b, "b");
                    }

                    @Override // android.widget.SeekBar.OnSeekBarChangeListener
                    public final void onStopTrackingTouch(SeekBar b) {
                        Intrinsics.checkNotNullParameter(b, "b");
                    }
                });
                LinearLayout linearLayout3 = new LinearLayout(mainActivity3);
                linearLayout3.setGravity(16);
                linearLayout3.addView(seekBar, new LinearLayout.LayoutParams(0, UiKt.dp(mainActivity3, 48), 1.0f));
                float f4 = 56;
                linearLayout3.addView(frameLayout, new LinearLayout.LayoutParams(UiKt.dp(mainActivity3, f4), UiKt.dp(mainActivity3, f4)));
                LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
                layoutParams2.topMargin = UiKt.dp(mainActivity3, 8);
                linearLayout.addView(linearLayout3, layoutParams2);
                Popup.Builder builder = new Popup.Builder(mainActivity3);
                builder.view = linearLayout;
                obj.element = builder.show();
                return;
            case 6:
                LinearLayout linearLayout4 = (LinearLayout) this.f$0;
                if (linearLayout4.getVisibility() == 0) {
                    z = false;
                }
                MainActivity mainActivity4 = (MainActivity) this.f$1;
                TypingKt.slide(mainActivity4.getControls$android_release());
                if (z) {
                    i3 = 0;
                } else {
                    i3 = 8;
                }
                linearLayout4.setVisibility(i3);
                mainActivity4.getPrefs$android_release().edit().putBoolean("numpad", z).apply();
                return;
            case 7:
                ((SeekBar) this.f$0).setProgress(1);
                ((Axml$$ExternalSyntheticLambda2) this.f$1).invoke(Float.valueOf(1.0f));
                return;
            case 8:
                if (((Popup.Builder) this.f$0).cancelable) {
                    ((Popup) this.f$1).cancel();
                    return;
                }
                return;
            default:
                ((Function1) this.f$0).invoke((String) this.f$1);
                return;
        }
    }
}
