package dev.tvremote.home;

import com.android.apksig.ApkSigner$$ExternalSyntheticOutline0;
import dev.tvremote.core.Census$$ExternalSyntheticOutline0;
import dev.tvremote.core.ontv.Home$$ExternalSyntheticLambda6;
import dev.tvremote.home.Target;
import dev.tvremote.i18n.Langs;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.CollectionsKt__MutableCollectionsJVMKt;
import kotlin.collections.EmptyList;
import kotlin.collections.EmptyMap;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgression;
import kotlin.ranges.IntProgressionIterator;
import kotlin.ranges.IntRange;
import kotlin.sequences.GeneratorSequence;
import kotlin.sequences.Sequence;
import kotlin.sequences.SequencesKt;
import kotlin.sequences.SequencesKt___SequencesKt$flatMap$2;
import kotlin.text.Charsets;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.RegexOption;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringNumberConversionsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.conscrypt.metrics.ConscryptStatsLog;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public abstract class HomeConfig {
    public static final LinkedHashMap ACCENTS;
    public static final List ART;
    public static final List BARE;
    public static final LinkedHashSet BIG_KINDS;
    public static final List DFACES;
    public static final List EVERY;
    public static final Regex FOLDER;
    public static final List GSTYLES;
    public static final List HEAD_COLORS;
    public static final List HEAD_FLAGS;
    public static final List HEAD_SIZES;
    public static final Object HEAD_TYPE;
    public static final Regex HEX6;
    public static final List KEY_COLOURS;
    public static final List KEY_DEAD;
    public static final List KEY_NUMBERS;
    public static final ArrayList LANGS;
    public static final Regex LIVE;
    public static final List LOOKS;
    public static final List MOTIONS;
    public static final ArrayList PHOTOS;
    public static final Regex PIC_ID;
    public static final List PLAIN;
    public static final List PRAYER_METHODS;
    public static final List SHOWS;
    public static final List SIZES;
    public static final Regex THEME_ID;
    public static final List THEME_KEYS;
    public static final LinkedHashSet TONAL;
    public static final List TSTYLES;
    public static final List VFPS;
    public static final Regex VIDEO;
    public static final List VIDEO_EXT;
    public static final List VRES;
    public static final ArrayList WALLS;
    public static final List WATCH_AT;
    public static final List WDIRS;
    public static final List WFITS;
    public static final ArrayList WIDGETS;
    public static final Regex WIDGET_ID;
    public static final List WMODES;
    public static final List WPLACES;
    public static final List WSNAPS;
    public static final Regex WURL;

    /* loaded from: classes.dex */
    public final class Opt {

        /* renamed from: default, reason: not valid java name */
        public final String f0default;
        public final String id;
        public final String store;
        public final String type;
        public final List values;

        public Opt(String str, String str2, List values, String str3, String str4) {
            Intrinsics.checkNotNullParameter(values, "values");
            this.id = str;
            this.type = str2;
            this.values = values;
            this.f0default = str3;
            this.store = str4;
        }
    }

    static {
        CollectionsKt__CollectionsKt.listOf((Object[]) new String[]{"dns.adguard-dns.com", "adblock.dns.mullvad.net", "p2.freedns.controld.com"});
        PLAIN = ArraysKt.asList(new String[]{"sky", "night", "ocean", "dusk", "forest", "aurora", "black", "sunset", "ember", "plum", "midnight", "teal", "slate", "graphite", "navy", "wine", "moss"});
        ART = ArraysKt.asList(new String[]{"dawn", "peaks", "dunes", "waves", "candy", "peach", "meadow", "mist", "bokeh", "canyon"});
        WDIRS = ArraysKt.asList(new String[]{"tl_br", "tb", "lr", "bl_tr", "br_tl", "bt", "rl", "tr_bl", "radial"});
        HEX6 = new Regex("[0-9a-f]{6}");
        WMODES = ArraysKt.asList(new String[]{"live", "snap"});
        WFITS = ArraysKt.asList(new String[]{"cover", "contain"});
        WSNAPS = ArraysKt.asList(new Integer[]{1, 5, 15, 30, 60});
        WURL = new Regex("https?://[^\\s/?#]+\\S*", RegexOption.IGNORE_CASE);
        List listOf = MathKt.listOf("photo");
        IntProgression intProgression = new IntProgression(2, 10, 1);
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(intProgression));
        Iterator it = intProgression.iterator();
        while (((IntProgressionIterator) it).hasNext) {
            arrayList.add("photo" + ((IntProgressionIterator) it).nextInt());
        }
        ArrayList plus = CollectionsKt.plus(listOf, (Iterable) arrayList);
        PHOTOS = plus;
        WALLS = CollectionsKt.plus((List) CollectionsKt.plus(CollectionsKt.plus((List) CollectionsKt.plus(ArraysKt.asList(new String[]{"bing", "web"}), (Iterable) plus), (Iterable) ART), "own"), (Iterable) PLAIN);
        VIDEO = new Regex("vid:[0-9a-f]{8}");
        VIDEO_EXT = ArraysKt.asList(new String[]{"mp4", "webm", "gif"});
        VFPS = ArraysKt.asList(new String[]{"", "60", "30", "24", "15"});
        VRES = ArraysKt.asList(new String[]{"", "1080", "720", "480"});
        EVERY = ArraysKt.asList(new String[]{"off", "30m", "1h", "6h", "day", "show"});
        List asList = ArraysKt.asList(new String[]{"system", "usage", "calendar", "lunar", "timer", "weather", "air", "recent", "adblock", "clock", "market", "news", "prayer"});
        ArrayList arrayList2 = HomeQr.KEYS;
        WIDGETS = CollectionsKt.plus(asList, (Iterable) arrayList2);
        SIZES = ArraysKt.asList(new String[]{"big", "small"});
        TONAL = SetsKt.plus(SetsKt.setOf((Object[]) new String[]{"system", "weather", "lunar", "air", "calendar", "usage", "timer", "market", "news", "recent", "adblock", "prayer"}), arrayList2);
        LOOKS = ArraysKt.asList(new String[]{"glass", "tonal", "solid", "none"});
        BARE = ArraysKt.asList(new String[]{"glass", "solid", "none"});
        PRAYER_METHODS = ArraysKt.asList(new String[]{"mwl", "isna", "egypt", "ummalqura", "karachi", "jakim", "kemenag", "singapore", "turkey", "tehran", "morocco"});
        BIG_KINDS = SetsKt.plus(SetsKt.setOf((Object[]) new String[]{"system", "usage", "calendar", "weather", "air", "market", "news", "prayer"}), arrayList2);
        WPLACES = ArraysKt.asList(new String[]{"top", "left", "right"});
        KEY_COLOURS = ArraysKt.asList(new Integer[]{183, 184, 185, 186});
        KEY_NUMBERS = CollectionsKt.toList(new IntProgression(7, 16, 1));
        KEY_DEAD = ArraysKt.asList(new Integer[]{170, 178, 190, 191, 195, 192, 284, 176});
        PIC_ID = new Regex("[0-9a-f]{8}");
        DFACES = ArraysKt.asList(new String[]{"big", "modern", "digital"});
        GSTYLES = ArraysKt.asList(new String[]{"time", "name", "date", "lunar", "own"});
        CollectionsKt__CollectionsKt.listOf((Object[]) new String[]{"greet", "date", "weekday", "day", "month", "year", "lunar", "canchi"});
        HEAD_SIZES = ArraysKt.asList(new String[]{"s", "m", "l"});
        HEAD_COLORS = ArraysKt.asList(new String[]{"white", "dim", "red"});
        HEAD_TYPE = MapsKt__MapsKt.mapOf(new Pair("gsize", "s"), new Pair("gcolor", "dim"), new Pair("dsize", "m"), new Pair("dcolor", "white"));
        HEAD_FLAGS = ArraysKt.asList(new String[]{"gbold", "gitalic", "gcaps", "dbold", "ditalic", "dcaps"});
        MOTIONS = ArraysKt.asList(new String[]{"calm", "full"});
        LANGS = CollectionsKt.plus(MathKt.listOf(""), (Iterable) Langs.CODES);
        Intrinsics.checkNotNullExpressionValue(Pattern.compile("[A-Za-z][\\w]*(\\.[\\w]+)+"), "compile(...)");
        LIVE = new Regex("tile:[A-Za-z][\\w]*(\\.[\\w]+)+/[a-z][a-z0-9_]{0,15}");
        FOLDER = new Regex("folder:[a-z0-9]{1,8}");
        THEME_KEYS = ArraysKt.asList(new String[]{"wall", "walls", "wurl", "wcol", "wdir", "wmode", "wsnap", "wkeep", "wevery", "shade", "wfit", "wfade", "widgets", "wsize", "wopt", "wplace", "cols", "center", "rows", "focus", "tstyle", "accent", "motion", "anim", "clock24", "greet"});
        TSTYLES = ArraysKt.asList(new String[]{"banner", "icon", "glass"});
        ACCENTS = MapsKt__MapsKt.linkedMapOf(new Pair("blue", "#2F72F0"), new Pair("teal", "#0E9F92"), new Pair("green", "#2E9E55"), new Pair("amber", "#C57400"), new Pair("orange", "#E8590C"), new Pair("red", "#E5383B"), new Pair("pink", "#D6336C"), new Pair("violet", "#7B55EE"));
        THEME_ID = new Regex("t[0-9]{1,4}");
        WATCH_AT = ArraysKt.asList(new String[]{"bottom", "top", "under1", "tiles"});
        SHOWS = ArraysKt.asList(new String[]{"showClock", "showDate", "showNet", "showGear", "showAdd", "showSuggest", "showWatch"});
        Intrinsics.checkNotNullExpressionValue(Pattern.compile("[a-z][a-z0-9_]{0,15}"), "compile(...)");
        Intrinsics.checkNotNullExpressionValue(Pattern.compile("https://[^\\s\"'<>]{4,292}"), "compile(...)");
        WIDGET_ID = new Regex("[a-z][a-z0-9_]{0,15}");
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0069, code lost:
    
        if (r11.equals("minimal") == false) goto L36;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0091, code lost:
    
        r1 = new kotlin.Pair("face", r11);
        r11 = new kotlin.Pair("theme", "dark");
        r12 = new kotlin.Pair[r3];
        r12[r2] = r1;
        r12[1] = r11;
        r1 = kotlin.collections.MapsKt__MapsKt.mapOf(r12);
     */
    /* JADX WARN: Code restructure failed: missing block: B:62:0x008e, code lost:
    
        if (r11.equals("roman") == false) goto L36;
     */
    /* JADX WARN: Failed to find 'out' block for switch in B:18:0x005f. Please report as an issue. */
    /* JADX WARN: Removed duplicated region for block: B:25:0x00ec  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x0148  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x014b A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static JSONObject cleanWopt(JSONObject o) {
        JSONObject jSONObject;
        Map map;
        JSONObject jSONObject2;
        String str;
        List list;
        String optString;
        char c = 0;
        int i = 2;
        Intrinsics.checkNotNullParameter(o, "o");
        JSONObject jSONObject3 = new JSONObject();
        JSONObject optJSONObject = o.optJSONObject("wopt");
        JSONObject optJSONObject2 = o.optJSONObject("wstyle");
        Iterator it = WIDGETS.iterator();
        while (it.hasNext()) {
            String str2 = (String) it.next();
            if (optJSONObject != null) {
                jSONObject = optJSONObject.optJSONObject(str2);
            } else {
                jSONObject = null;
            }
            if (jSONObject == null && optJSONObject2 != null && (optString = optJSONObject2.optString(str2)) != null) {
                if (optString.length() <= 0) {
                    optString = null;
                }
                if (optString != null) {
                    if (Intrinsics.areEqual(str2, "clock")) {
                        switch (optString.hashCode()) {
                            case 102970646:
                                if (optString.equals("light")) {
                                    Pair pair = new Pair("face", "classic");
                                    Pair pair2 = new Pair("theme", "light");
                                    Pair[] pairArr = new Pair[i];
                                    pairArr[c] = pair;
                                    pairArr[1] = pair2;
                                    map = MapsKt__MapsKt.mapOf(pairArr);
                                    break;
                                }
                                map = EmptyMap.INSTANCE;
                                break;
                            case 108696061:
                                break;
                            case 853620882:
                                if (optString.equals("classic")) {
                                    Pair pair3 = new Pair("face", "classic");
                                    Pair pair4 = new Pair("theme", "dark");
                                    Pair[] pairArr2 = new Pair[i];
                                    pairArr2[c] = pair3;
                                    pairArr2[1] = pair4;
                                    map = MapsKt__MapsKt.mapOf(pairArr2);
                                    break;
                                }
                                map = EmptyMap.INSTANCE;
                                break;
                            case 1064537505:
                                break;
                            default:
                                map = EmptyMap.INSTANCE;
                                break;
                        }
                    } else {
                        map = MapsKt__MapsKt.mapOf(new Pair("look", optString));
                    }
                    jSONObject2 = new JSONObject();
                    for (Opt opt : options(str2)) {
                        if (Intrinsics.areEqual(opt.store, "wopt")) {
                            String str3 = opt.id;
                            if (jSONObject == null || (str = jSONObject.optString(str3)) == null) {
                                if (map != null) {
                                    str = (String) map.get(str3);
                                } else {
                                    str = null;
                                }
                            }
                            if (str != null) {
                                if (Intrinsics.areEqual(opt.type, "toggle")) {
                                    list = ArraysKt.asList(new String[]{"off", "on"});
                                } else {
                                    list = opt.values;
                                }
                                if (!list.contains(str) || str.equals(opt.f0default)) {
                                    str = null;
                                }
                                if (str != null) {
                                    jSONObject2.put(str3, str);
                                }
                            }
                        }
                    }
                    if (jSONObject2.length() <= 0) {
                        jSONObject3.put(str2, jSONObject2);
                    }
                    c = 0;
                    i = 2;
                }
            }
            map = null;
            jSONObject2 = new JSONObject();
            while (r12.hasNext()) {
            }
            if (jSONObject2.length() <= 0) {
            }
            c = 0;
            i = 2;
        }
        return jSONObject3;
    }

    public static List customThemes(JSONObject jSONObject) {
        JSONArray optJSONArray;
        if (jSONObject != null && (optJSONArray = jSONObject.optJSONArray("themes")) != null) {
            HashSet hashSet = new HashSet();
            ArrayList arrayList = new ArrayList();
            int length = optJSONArray.length();
            for (int i = 0; i < length; i++) {
                JSONObject optJSONObject = optJSONArray.optJSONObject(i);
                if (optJSONObject != null) {
                    String optString = optJSONObject.optString("id");
                    String optString2 = optJSONObject.optString("name");
                    Intrinsics.checkNotNullExpressionValue(optString2, "optString(...)");
                    String themeName = themeName(optString2);
                    JSONObject optJSONObject2 = optJSONObject.optJSONObject("conf");
                    Intrinsics.checkNotNull(optString);
                    if (THEME_ID.matches(optString) && themeName.length() != 0 && optJSONObject2 != null && hashSet.add(optString)) {
                        arrayList.add(Census$$ExternalSyntheticOutline0.m10m("id", optString, "name", themeName).put("conf", pickTheme(optJSONObject2)));
                        if (arrayList.size() >= 12) {
                            break;
                        }
                    }
                }
            }
            return arrayList;
        }
        return EmptyList.INSTANCE;
    }

    public static String dark(String str) {
        MatcherMatchResult matcherMatchResult;
        Pattern compile = Pattern.compile("(\\d{1,2})(?::(\\d{2}))?-(\\d{1,2})(?::(\\d{2}))?");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        String input = StringsKt.trim(str).toString();
        Intrinsics.checkNotNullParameter(input, "input");
        Matcher matcher = compile.matcher(input);
        Intrinsics.checkNotNullExpressionValue(matcher, "matcher(...)");
        if (!matcher.matches()) {
            matcherMatchResult = null;
        } else {
            matcherMatchResult = new MatcherMatchResult(matcher, input);
        }
        if (matcherMatchResult != null) {
            String str2 = (String) ((MatcherMatchResult$groupValues$1) matcherMatchResult.getGroupValues()).get(1);
            String str3 = (String) ((MatcherMatchResult$groupValues$1) matcherMatchResult.getGroupValues()).get(2);
            String str4 = (String) ((MatcherMatchResult$groupValues$1) matcherMatchResult.getGroupValues()).get(3);
            String str5 = (String) ((MatcherMatchResult$groupValues$1) matcherMatchResult.getGroupValues()).get(4);
            int parseInt = Integer.parseInt(str2);
            int parseInt2 = Integer.parseInt(str4);
            if (str3.length() == 0) {
                str3 = "0";
            }
            int parseInt3 = Integer.parseInt(str3);
            if (str5.length() == 0) {
                str5 = "0";
            }
            int parseInt4 = Integer.parseInt(str5);
            if (parseInt <= 23 && parseInt2 <= 23) {
                if (parseInt3 == 0 || parseInt3 == 30) {
                    if ((parseInt4 == 0 || parseInt4 == 30) && (parseInt * 60) + parseInt3 != (parseInt2 * 60) + parseInt4) {
                        return String.format("%02d:%02d-%02d:%02d", Arrays.copyOf(new Object[]{Integer.valueOf(parseInt), Integer.valueOf(parseInt3), Integer.valueOf(parseInt2), Integer.valueOf(parseInt4)}, 4));
                    }
                    return "";
                }
                return "";
            }
            return "";
        }
        return "";
    }

    public static JSONObject folders(JSONObject jSONObject, List list, Set set, Set set2) {
        JSONObject optJSONObject;
        JSONObject jSONObject2 = new JSONObject();
        if (jSONObject != null) {
            HashSet hashSet = new HashSet(list);
            Iterator<String> keys = jSONObject.keys();
            Intrinsics.checkNotNullExpressionValue(keys, "keys(...)");
            ArrayList mutableList = SequencesKt.toMutableList(SequencesKt.asSequence(keys));
            CollectionsKt__MutableCollectionsJVMKt.sort(mutableList);
            Iterator it = mutableList.iterator();
            while (it.hasNext()) {
                String str = (String) it.next();
                if (jSONObject2.length() >= 12) {
                    break;
                }
                Intrinsics.checkNotNull(str);
                if (isFolder("folder:".concat(str)) && set.contains(str) && (optJSONObject = jSONObject.optJSONObject(str)) != null) {
                    List pkgs = pkgs(optJSONObject.optJSONArray("apps"), 40);
                    ArrayList arrayList = new ArrayList();
                    for (Object obj : pkgs) {
                        String str2 = (String) obj;
                        Target.Kind kind = Target.kind(str2);
                        Target.Kind kind2 = Target.Kind.APP;
                        if (kind != kind2) {
                            Target.Kind kind3 = Target.kind(str2);
                            if (kind3 == kind2 || kind3 == Target.Kind.TILE || kind3 == Target.Kind.PIN) {
                                if (set2.contains(str2)) {
                                }
                            }
                        }
                        if (hashSet.add(str2)) {
                            arrayList.add(obj);
                        }
                    }
                    if (!arrayList.isEmpty()) {
                        String optString = optJSONObject.optString("name");
                        Intrinsics.checkNotNullExpressionValue(optString, "optString(...)");
                        Pattern compile = Pattern.compile("\\s+");
                        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                        String replaceAll = compile.matcher(optString).replaceAll(" ");
                        Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
                        jSONObject2.put(str, Census$$ExternalSyntheticOutline0.m8m("name", StringsKt.trim(StringsKt.take(StringsKt.trim(replaceAll).toString(), 30)).toString()).put("apps", new JSONArray((Collection) arrayList)));
                    }
                }
            }
        }
        return jSONObject2;
    }

    /* JADX WARN: Code restructure failed: missing block: B:456:0x0d43, code lost:
    
        if (dev.tvremote.home.Target.kind(r8) != null) goto L467;
     */
    /* JADX WARN: Code restructure failed: missing block: B:465:0x0d71, code lost:
    
        if (r2.length() == 0) goto L479;
     */
    /* JADX WARN: Code restructure failed: missing block: B:471:0x0de4, code lost:
    
        if (r1.length() > 0) goto L487;
     */
    /* JADX WARN: Code restructure failed: missing block: B:59:0x0194, code lost:
    
        if (r6.length() == 0) goto L53;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:11:0x043a A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:15:0x041b A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:96:0x021f  */
    /* JADX WARN: Type inference failed for: r0v63, types: [org.json.JSONObject, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v66, types: [java.util.Map, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r10v4, types: [kotlin.collections.EmptyList] */
    /* JADX WARN: Type inference failed for: r1v29, types: [java.util.Map, java.lang.Object] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static JSONObject forward(JSONObject o) {
        ArrayList arrayList;
        boolean z;
        String str;
        String str2;
        String str3;
        ArrayList arrayList2;
        List take;
        int i;
        String str4;
        JSONObject jSONObject;
        String str5;
        ArrayList arrayList3;
        JSONObject jSONObject2;
        Object obj;
        Iterator<String> it;
        String str6;
        List list;
        JSONObject optJSONObject;
        List list2;
        Set set;
        String str7;
        Iterator it2;
        JSONObject jSONObject3;
        String str8;
        String str9;
        String str10;
        String str11;
        JSONObject jSONObject4;
        String str12;
        String str13;
        String m;
        String concat;
        String str14;
        String m2;
        String str15;
        JSONObject jSONObject5;
        String str16;
        String str17;
        String str18;
        String str19;
        boolean z2;
        String m3;
        String m4;
        String m5;
        String str20;
        int i2;
        String str21 = "motion";
        String str22 = "shift";
        String str23 = "homebar";
        String str24 = "anim";
        String str25 = "watchAt";
        String str26 = "infold";
        Intrinsics.checkNotNullParameter(o, "o");
        List list3 = HomeQr.TEMPLATES;
        String str27 = "big";
        JSONObject optJSONObject2 = o.optJSONObject("qrs");
        JSONObject jSONObject6 = new JSONObject();
        String str28 = "replaceAll(...)";
        String str29 = " ";
        String str30 = "compile(...)";
        String str31 = "optString(...)";
        if (optJSONObject2 != null) {
            Iterator it3 = HomeQr.KEYS.iterator();
            while (it3.hasNext()) {
                String str32 = str21;
                String str33 = (String) it3.next();
                String str34 = str22;
                JSONObject optJSONObject3 = optJSONObject2.optJSONObject(str33);
                if (optJSONObject3 == null) {
                    String str35 = str30;
                    str16 = str28;
                    str17 = str29;
                    str18 = str35;
                    jSONObject3 = optJSONObject2;
                    str11 = str26;
                    jSONObject4 = jSONObject6;
                    str19 = str31;
                    str12 = str33;
                    str8 = str23;
                    str9 = str24;
                } else {
                    jSONObject3 = optJSONObject2;
                    str8 = str23;
                    String optString = optJSONObject3.optString("tpl");
                    str9 = str24;
                    if (!HomeQr.TEMPLATES.contains(optString)) {
                        optString = null;
                    }
                    if (optString == null) {
                        String str36 = str30;
                        str16 = str28;
                        str17 = str29;
                        str18 = str36;
                        str11 = str26;
                        jSONObject4 = jSONObject6;
                        str19 = str31;
                        str12 = str33;
                    } else {
                        JSONObject optJSONObject4 = optJSONObject3.optJSONObject("f");
                        if (optJSONObject4 == null) {
                            optJSONObject4 = new JSONObject();
                        }
                        str10 = str25;
                        JSONObject jSONObject7 = optJSONObject4;
                        str11 = str26;
                        JSONObject jSONObject8 = new JSONObject();
                        Iterator it4 = ((List) MapsKt__MapsKt.getValue(HomeQr.FIELDS, optString)).iterator();
                        while (true) {
                            Iterator it5 = it4;
                            jSONObject4 = jSONObject6;
                            if (it4.hasNext()) {
                                String str37 = str33;
                                String str38 = (String) it5.next();
                                if (Intrinsics.areEqual(str38, "hidden")) {
                                    str20 = str28;
                                    jSONObject8.put(str38, jSONObject7.optBoolean(str38, false));
                                } else {
                                    str20 = str28;
                                    if (Intrinsics.areEqual(str38, "sec")) {
                                        String optString2 = jSONObject7.optString(str38);
                                        if (!HomeQr.SECURITY.contains(optString2)) {
                                            optString2 = null;
                                        }
                                        if (optString2 == null) {
                                            optString2 = "WPA";
                                        }
                                        jSONObject8.put(str38, optString2);
                                    } else {
                                        String optString3 = jSONObject7.optString(str38, "");
                                        Intrinsics.checkNotNullExpressionValue(optString3, str31);
                                        if (optString.equals("text")) {
                                            i2 = 271;
                                        } else {
                                            i2 = 250;
                                        }
                                        jSONObject8.put(str38, StringsKt.take(optString3, i2));
                                    }
                                }
                                str28 = str20;
                                it4 = it5;
                                jSONObject6 = jSONObject4;
                                str33 = str37;
                            } else {
                                String str39 = str28;
                                str12 = str33;
                                String str40 = str29;
                                String str41 = str30;
                                String str42 = str31;
                                switch (optString.hashCode()) {
                                    case 114009:
                                        if (optString.equals("sms")) {
                                            String optString4 = jSONObject8.optString("num", "");
                                            Intrinsics.checkNotNullExpressionValue(optString4, "str(...)");
                                            String num = HomeQr.num(optString4);
                                            String optString5 = jSONObject8.optString("body", "");
                                            if (num.length() != 0) {
                                                Intrinsics.checkNotNull(optString5);
                                                if (optString5.length() == 0) {
                                                    m = "";
                                                } else {
                                                    m = ApkSigner$$ExternalSyntheticOutline0.m("?body=", HomeQr.pct(optString5));
                                                }
                                                str13 = ApkSigner$$ExternalSyntheticOutline0.m("sms:", num, m);
                                                break;
                                            }
                                        }
                                        break;
                                    case 114715:
                                        if (optString.equals("tel")) {
                                            String optString6 = jSONObject8.optString("num", "");
                                            Intrinsics.checkNotNullExpressionValue(optString6, "str(...)");
                                            String num2 = HomeQr.num(optString6);
                                            if (num2.length() != 0) {
                                                str13 = "tel:".concat(num2);
                                                break;
                                            }
                                        }
                                        break;
                                    case 3321850:
                                        if (optString.equals("link")) {
                                            String optString7 = jSONObject8.optString("url", "");
                                            Intrinsics.checkNotNullExpressionValue(optString7, "str(...)");
                                            str13 = StringsKt.trim(optString7).toString();
                                            if (str13.length() != 0) {
                                                if (!HomeQr.SCHEME.containsMatchIn(str13)) {
                                                    str13 = "https://".concat(str13);
                                                    break;
                                                }
                                            }
                                        }
                                        break;
                                    case 3343799:
                                        if (optString.equals("mail")) {
                                            String optString8 = jSONObject8.optString("to", "");
                                            Intrinsics.checkNotNullExpressionValue(optString8, "str(...)");
                                            String obj2 = StringsKt.trim(optString8).toString();
                                            List asList = ArraysKt.asList(new Pair[]{new Pair("subject", jSONObject8.optString("subject", "")), new Pair("body", jSONObject8.optString("body", ""))});
                                            ArrayList arrayList4 = new ArrayList();
                                            for (Object obj3 : asList) {
                                                Object obj4 = ((Pair) obj3).second;
                                                Intrinsics.checkNotNullExpressionValue(obj4, "<get-second>(...)");
                                                if (((CharSequence) obj4).length() > 0) {
                                                    arrayList4.add(obj3);
                                                }
                                            }
                                            String joinToString$default = CollectionsKt.joinToString$default(arrayList4, "&", null, null, new HomeQr$$ExternalSyntheticLambda0(0), 30);
                                            if (obj2.length() != 0) {
                                                if (joinToString$default.length() == 0) {
                                                    concat = "";
                                                } else {
                                                    concat = "?".concat(joinToString$default);
                                                }
                                                str13 = ApkSigner$$ExternalSyntheticOutline0.m("mailto:", obj2, concat);
                                                break;
                                            }
                                        }
                                        break;
                                    case 3556653:
                                        if (optString.equals("text")) {
                                            str13 = jSONObject8.optString("text", "");
                                            Intrinsics.checkNotNullExpressionValue(str13, "str(...)");
                                            break;
                                        }
                                        break;
                                    case 3649301:
                                        if (optString.equals("wifi")) {
                                            String optString9 = jSONObject8.optString("ssid", "");
                                            String optString10 = jSONObject8.optString("pass", "");
                                            String optString11 = jSONObject8.optString("sec", "");
                                            if (!Intrinsics.areEqual(optString11, "nopass")) {
                                                Intrinsics.checkNotNull(optString10);
                                                if (optString10.length() != 0) {
                                                    str14 = "WEP";
                                                    if (!Intrinsics.areEqual(optString11, "WEP")) {
                                                        str14 = "WPA";
                                                    }
                                                    Intrinsics.checkNotNull(optString9);
                                                    if (optString9.length() != 0) {
                                                        String esc = HomeQr.esc(optString9);
                                                        if (str14.equals("nopass")) {
                                                            m2 = "";
                                                        } else {
                                                            Intrinsics.checkNotNull(optString10);
                                                            m2 = ApkSigner$$ExternalSyntheticOutline0.m("P:", HomeQr.esc(optString10), ";");
                                                        }
                                                        if (!jSONObject8.optBoolean("hidden")) {
                                                            str15 = "";
                                                        } else {
                                                            str15 = "H:true;";
                                                        }
                                                        str13 = "WIFI:T:" + str14 + ";S:" + esc + ";" + m2 + str15 + ";";
                                                        break;
                                                    }
                                                }
                                            }
                                            str14 = "nopass";
                                            Intrinsics.checkNotNull(optString9);
                                            if (optString9.length() != 0) {
                                            }
                                        }
                                        break;
                                    case 951526432:
                                        if (optString.equals("contact")) {
                                            String optString12 = jSONObject8.optString("name", "");
                                            String optString13 = jSONObject8.optString("tel", "");
                                            String optString14 = jSONObject8.optString("email", "");
                                            Intrinsics.checkNotNull(optString12);
                                            if (optString12.length() == 0) {
                                                Intrinsics.checkNotNull(optString13);
                                                if (optString13.length() == 0) {
                                                    Intrinsics.checkNotNull(optString14);
                                                    break;
                                                }
                                            }
                                            if (optString12.length() == 0) {
                                                m3 = "";
                                            } else {
                                                m3 = ApkSigner$$ExternalSyntheticOutline0.m("N:", HomeQr.esc(optString12), ";");
                                            }
                                            Intrinsics.checkNotNull(optString13);
                                            if (optString13.length() == 0) {
                                                m4 = "";
                                            } else {
                                                m4 = ApkSigner$$ExternalSyntheticOutline0.m("TEL:", HomeQr.esc(optString13), ";");
                                            }
                                            Intrinsics.checkNotNull(optString14);
                                            if (optString14.length() == 0) {
                                                m5 = "";
                                            } else {
                                                m5 = ApkSigner$$ExternalSyntheticOutline0.m("EMAIL:", HomeQr.esc(optString14), ";");
                                            }
                                            str13 = Census$$ExternalSyntheticOutline0.m("MECARD:", m3, m4, m5, ";");
                                            break;
                                        }
                                        break;
                                }
                                str13 = "";
                                if (str13.length() != 0) {
                                    byte[] bytes = str13.getBytes(Charsets.UTF_8);
                                    Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                                    if (bytes.length <= 271) {
                                        JSONObject put = new JSONObject().put("tpl", optString).put("f", jSONObject8);
                                        String optString15 = optJSONObject3.optString("cap");
                                        str19 = str42;
                                        Intrinsics.checkNotNullExpressionValue(optString15, str19);
                                        Pattern compile = Pattern.compile("\\s+");
                                        str18 = str41;
                                        Intrinsics.checkNotNullExpressionValue(compile, str18);
                                        Matcher matcher = compile.matcher(optString15);
                                        str17 = str40;
                                        String replaceAll = matcher.replaceAll(str17);
                                        str16 = str39;
                                        Intrinsics.checkNotNullExpressionValue(replaceAll, str16);
                                        JSONObject put2 = put.put("cap", StringsKt.take(StringsKt.trim(replaceAll).toString(), 60));
                                        if (optString.equals("wifi") && optJSONObject3.optBoolean("show", false)) {
                                            z2 = true;
                                        } else {
                                            z2 = false;
                                        }
                                        jSONObject5 = put2.put("show", z2);
                                        if (jSONObject5 != null) {
                                            JSONObject jSONObject9 = jSONObject4;
                                            jSONObject9.put(str12, jSONObject5);
                                            String str43 = str18;
                                            str29 = str17;
                                            str28 = str16;
                                            str30 = str43;
                                            str31 = str19;
                                            str22 = str34;
                                            str21 = str32;
                                            str23 = str8;
                                            str24 = str9;
                                            str26 = str11;
                                            str25 = str10;
                                            jSONObject6 = jSONObject9;
                                            optJSONObject2 = jSONObject3;
                                        } else {
                                            String str44 = str18;
                                            str29 = str17;
                                            str28 = str16;
                                            str30 = str44;
                                            str31 = str19;
                                            str22 = str34;
                                            str21 = str32;
                                            optJSONObject2 = jSONObject3;
                                            str23 = str8;
                                            str24 = str9;
                                            str26 = str11;
                                            str25 = str10;
                                            jSONObject6 = jSONObject4;
                                        }
                                    }
                                }
                                jSONObject5 = null;
                                str16 = str39;
                                str17 = str40;
                                str18 = str41;
                                str19 = str42;
                                if (jSONObject5 != null) {
                                }
                            }
                        }
                    }
                }
                str10 = str25;
                jSONObject5 = null;
                if (jSONObject5 != null) {
                }
            }
        }
        String str45 = str30;
        String str46 = str28;
        String str47 = str29;
        String str48 = str26;
        JSONObject jSONObject10 = jSONObject6;
        String str49 = str31;
        String str50 = str21;
        String str51 = str22;
        String str52 = str23;
        String str53 = str24;
        String str54 = str25;
        JSONArray optJSONArray = o.optJSONArray("widgets");
        if (optJSONArray != null) {
            IntRange until = MathKt.until(0, optJSONArray.length());
            arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until));
            Iterator it6 = until.iterator();
            while (((IntProgressionIterator) it6).hasNext) {
                arrayList.add(optJSONArray.optString(((IntProgressionIterator) it6).nextInt()));
            }
        } else {
            arrayList = null;
        }
        ?? r10 = EmptyList.INSTANCE;
        if (arrayList == null) {
            arrayList = r10;
        }
        ArrayList arrayList5 = new ArrayList();
        Iterator it7 = arrayList.iterator();
        while (true) {
            boolean hasNext = it7.hasNext();
            ArrayList arrayList6 = WIDGETS;
            if (hasNext) {
                Object next = it7.next();
                String str55 = (String) next;
                if (arrayList6.contains(str55) && (!HomeQr.KEYS.contains(str55) || jSONObject10.has(str55))) {
                    arrayList5.add(next);
                }
            } else {
                List distinct = CollectionsKt.distinct(arrayList5);
                List pkgs = pkgs(o.optJSONArray("dock"), 6);
                String optString16 = o.optString("wurl");
                Intrinsics.checkNotNullExpressionValue(optString16, str49);
                String wurl = wurl(optString16);
                ArrayList arrayList7 = r10;
                ArrayList arrayList8 = arrayList6;
                String optString17 = o.optString("wall");
                Intrinsics.checkNotNull(optString17);
                ArrayList arrayList9 = WALLS;
                if (!arrayList9.contains(optString17) && !isVideo(optString17)) {
                    z = false;
                } else {
                    z = true;
                }
                if (!z || (optString17.equals("web") && wurl.length() <= 0)) {
                    optString17 = null;
                }
                if (optString17 == null) {
                    optString17 = "night";
                }
                if (optString17.equals("web")) {
                    take = MathKt.listOf("web");
                    str2 = str47;
                    str3 = str45;
                    str = str46;
                } else {
                    str = str46;
                    JSONArray optJSONArray2 = o.optJSONArray("walls");
                    str2 = str47;
                    if (optJSONArray2 != null) {
                        str3 = str45;
                        IntRange until2 = MathKt.until(0, optJSONArray2.length());
                        arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until2));
                        Iterator it8 = until2.iterator();
                        while (((IntProgressionIterator) it8).hasNext) {
                            arrayList2.add(optJSONArray2.optString(((IntProgressionIterator) it8).nextInt()));
                        }
                    } else {
                        str3 = str45;
                        arrayList2 = null;
                    }
                    if (arrayList2 != null) {
                        arrayList7 = arrayList2;
                    }
                    ArrayList arrayList10 = new ArrayList();
                    Iterator it9 = arrayList7.iterator();
                    while (it9.hasNext()) {
                        Object next2 = it9.next();
                        Iterator it10 = it9;
                        String str56 = (String) next2;
                        Intrinsics.checkNotNull(str56);
                        if ((arrayList9.contains(str56) || isVideo(str56)) && !str56.equals("web")) {
                            arrayList10.add(next2);
                        }
                        it9 = it10;
                    }
                    take = CollectionsKt.take(CollectionsKt.distinct(arrayList10), 40);
                }
                if (take.isEmpty()) {
                    take = MathKt.listOf(optString17);
                }
                String str57 = "tiles";
                List strs = strs(o.optJSONArray("tiles"));
                ArrayList arrayList11 = new ArrayList();
                Iterator it11 = strs.iterator();
                while (it11.hasNext()) {
                    Object next3 = it11.next();
                    String str58 = (String) next3;
                    Intrinsics.checkNotNull(str58);
                    if (!isLive(str58)) {
                        it2 = it11;
                        str7 = str57;
                        if (Target.kind(str58) != Target.Kind.PIN && !isFolder(str58)) {
                            it11 = it2;
                            str57 = str7;
                        }
                    } else {
                        str7 = str57;
                        it2 = it11;
                    }
                    arrayList11.add(next3);
                    it11 = it2;
                    str57 = str7;
                }
                String str59 = str57;
                List take2 = CollectionsKt.take(CollectionsKt.distinct(arrayList11), 24);
                String str60 = "folders";
                JSONObject optJSONObject5 = o.optJSONObject("folders");
                ArrayList arrayList12 = new ArrayList();
                for (Object obj5 : take2) {
                    List list4 = take2;
                    String str61 = (String) obj5;
                    Intrinsics.checkNotNull(str61);
                    if (isFolder(str61)) {
                        arrayList12.add(obj5);
                    }
                    take2 = list4;
                }
                List list5 = take2;
                ArrayList arrayList13 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList12));
                Iterator it12 = arrayList12.iterator();
                while (it12.hasNext()) {
                    Iterator it13 = it12;
                    String str62 = (String) it12.next();
                    Intrinsics.checkNotNull(str62);
                    arrayList13.add(StringsKt.removePrefix(str62, "folder:"));
                    str60 = str60;
                    it12 = it13;
                }
                String str63 = str60;
                JSONObject folders = folders(optJSONObject5, pkgs, CollectionsKt.toSet(arrayList13), CollectionsKt.toSet(list5));
                Iterator<String> keys = folders.keys();
                Intrinsics.checkNotNullExpressionValue(keys, "keys(...)");
                Set set2 = SequencesKt.toSet(new GeneratorSequence(SequencesKt.asSequence(keys), new HomeQr$$ExternalSyntheticLambda0(20), 2));
                ArrayList arrayList14 = new ArrayList();
                Iterator it14 = list5.iterator();
                while (it14.hasNext()) {
                    Object next4 = it14.next();
                    Iterator it15 = it14;
                    String str64 = (String) next4;
                    Intrinsics.checkNotNull(str64);
                    if (!isFolder(str64) || set2.contains(str64)) {
                        arrayList14.add(next4);
                    }
                    it14 = it15;
                }
                Iterator<String> keys2 = folders.keys();
                Intrinsics.checkNotNullExpressionValue(keys2, "keys(...)");
                Sequence asSequence = SequencesKt.asSequence(keys2);
                Home$$ExternalSyntheticLambda6 home$$ExternalSyntheticLambda6 = new Home$$ExternalSyntheticLambda6(folders, 4);
                SequencesKt___SequencesKt$flatMap$2 sequencesKt___SequencesKt$flatMap$2 = SequencesKt___SequencesKt$flatMap$2.INSTANCE;
                Set set3 = SequencesKt.toSet(new GeneratorSequence(asSequence, home$$ExternalSyntheticLambda6));
                JSONObject put3 = new JSONObject().put("dock", new JSONArray((Collection) pkgs));
                List pkgs2 = pkgs(o.optJSONArray("hidden"), 300);
                ArrayList arrayList15 = new ArrayList();
                Iterator it16 = pkgs2.iterator();
                while (it16.hasNext()) {
                    Iterator it17 = it16;
                    Object next5 = it17.next();
                    JSONObject jSONObject11 = folders;
                    String str65 = (String) next5;
                    if (!pkgs.contains(str65) && !set3.contains(str65)) {
                        set = set3;
                        if (Target.kind(str65) == Target.Kind.APP) {
                            arrayList15.add(next5);
                        }
                    } else {
                        set = set3;
                    }
                    it16 = it17;
                    folders = jSONObject11;
                    set3 = set;
                }
                JSONObject jSONObject12 = folders;
                JSONObject put4 = put3.put("hidden", new JSONArray((Collection) arrayList15));
                JSONArray optJSONArray3 = o.optJSONArray("order");
                LinkedHashSet linkedHashSet = new LinkedHashSet();
                if (optJSONArray3 != null) {
                    int length = optJSONArray3.length();
                    for (int i3 = 0; i3 < length; i3++) {
                        String optString18 = optJSONArray3.optString(i3);
                        Regex regex = Target.PKG;
                        Intrinsics.checkNotNull(optString18);
                        if (Target.kind(optString18) != null || isFolder(optString18)) {
                            linkedHashSet.add(optString18);
                        }
                    }
                }
                List take3 = CollectionsKt.take(linkedHashSet, 800);
                ArrayList arrayList16 = new ArrayList();
                for (Object obj6 : take3) {
                    String str66 = (String) obj6;
                    if (!isFolder(str66) || set2.contains(str66)) {
                        arrayList16.add(obj6);
                    }
                }
                JSONObject put5 = put4.put("order", new JSONArray((Collection) arrayList16));
                if (!take.contains(optString17)) {
                    optString17 = (String) take.get(0);
                }
                JSONObject put6 = put5.put("wall", optString17).put("walls", new JSONArray((Collection) take)).put("wurl", wurl);
                String optString19 = o.optString("wcol");
                Intrinsics.checkNotNullExpressionValue(optString19, str49);
                String lowerCase = optString19.toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                List split$default = StringsKt.split$default(lowerCase, new char[]{','});
                ArrayList arrayList17 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(split$default));
                Iterator it18 = split$default.iterator();
                while (it18.hasNext()) {
                    arrayList17.add(StringsKt.removePrefix(StringsKt.trim((String) it18.next()).toString(), "#"));
                }
                ArrayList arrayList18 = new ArrayList();
                Iterator it19 = arrayList17.iterator();
                while (it19.hasNext()) {
                    Object next6 = it19.next();
                    if (HEX6.matches((String) next6)) {
                        arrayList18.add(next6);
                    }
                }
                List take4 = CollectionsKt.take(arrayList18, 4);
                if (take4.isEmpty()) {
                    take4 = StringsKt.split$default("0b1d3a,14307a,7a2e12", new char[]{','});
                }
                JSONObject put7 = put6.put("wcol", CollectionsKt.joinToString$default(take4, ",", null, null, null, 62));
                String optString20 = o.optString("wdir");
                List list6 = WDIRS;
                if (!list6.contains(optString20)) {
                    optString20 = null;
                }
                if (optString20 == null) {
                    optString20 = (String) list6.get(0);
                }
                JSONObject put8 = put7.put("wdir", optString20);
                String optString21 = o.optString("wmode");
                if (!WMODES.contains(optString21)) {
                    optString21 = null;
                }
                if (optString21 == null) {
                    optString21 = "live";
                }
                JSONObject put9 = put8.put("wmode", optString21);
                int optInt = o.optInt("wsnap", 5);
                Integer valueOf = Integer.valueOf(optInt);
                if (!WSNAPS.contains(Integer.valueOf(optInt))) {
                    valueOf = null;
                }
                if (valueOf != null) {
                    i = valueOf.intValue();
                } else {
                    i = 5;
                }
                JSONObject put10 = put9.put("wsnap", i).put("wkeep", o.optBoolean("wkeep", false)).put("wfade", o.optBoolean("wfade", false));
                String optString22 = o.optString("wevery");
                if (!EVERY.contains(optString22)) {
                    optString22 = null;
                }
                if (optString22 == null) {
                    optString22 = "off";
                }
                JSONObject put11 = put10.put("wevery", optString22);
                long j = 0;
                long optLong = o.optLong("photo", 0L);
                if (optLong >= 0) {
                    j = optLong;
                }
                JSONObject put12 = put11.put("photo", j);
                String optString23 = o.optString("wfit");
                if (!WFITS.contains(optString23)) {
                    optString23 = null;
                }
                if (optString23 == null) {
                    optString23 = "cover";
                }
                JSONObject put13 = put12.put("wfit", optString23).put("shade", (MathKt.coerceIn(o.optInt("shade", 50), 0, 100) / 5) * 5);
                String optString24 = o.optString("vfps");
                if (!VFPS.contains(optString24)) {
                    optString24 = null;
                }
                if (optString24 == null) {
                    optString24 = "";
                }
                JSONObject put14 = put13.put("vfps", optString24);
                String optString25 = o.optString("vres");
                if (!VRES.contains(optString25)) {
                    optString25 = null;
                }
                if (optString25 == null) {
                    optString25 = "";
                }
                JSONObject put15 = put14.put("vres", optString25).put("clock24", o.optBoolean("clock24", true));
                String optString26 = o.optString("lang");
                if (!LANGS.contains(optString26)) {
                    optString26 = null;
                }
                if (optString26 == null) {
                    optString26 = "";
                }
                JSONObject put16 = put15.put("lang", optString26).put("greet", o.optBoolean("greet", true));
                String optString27 = o.optString("gstyle");
                List list7 = GSTYLES;
                if (!list7.contains(optString27)) {
                    optString27 = null;
                }
                if (optString27 == null) {
                    optString27 = (String) list7.get(0);
                }
                JSONObject put17 = put16.put("gstyle", optString27);
                String optString28 = o.optString("gname");
                Intrinsics.checkNotNullExpressionValue(optString28, str49);
                JSONObject put18 = put17.put("gname", line(optString28, 24));
                String optString29 = o.optString("gtext");
                Intrinsics.checkNotNullExpressionValue(optString29, str49);
                JSONObject put19 = put18.put("gtext", line(optString29, 60));
                String optString30 = o.optString("dstyle");
                if (!list7.contains(optString30) || Intrinsics.areEqual(optString30, "name")) {
                    optString30 = null;
                }
                if (optString30 == null) {
                    optString30 = "date";
                }
                JSONObject put20 = put19.put("dstyle", optString30);
                String optString31 = o.optString("dtext");
                Intrinsics.checkNotNullExpressionValue(optString31, str49);
                JSONObject put21 = put20.put("dtext", line(optString31, 60));
                for (Map.Entry entry : HEAD_TYPE.entrySet()) {
                    String str67 = (String) entry.getKey();
                    String str68 = (String) entry.getValue();
                    String optString32 = o.optString(str67);
                    if (StringsKt__StringsJVMKt.endsWith(str67, false, "size")) {
                        list2 = HEAD_SIZES;
                    } else {
                        list2 = HEAD_COLORS;
                    }
                    if (!list2.contains(optString32)) {
                        optString32 = null;
                    }
                    if (optString32 != null) {
                        str68 = optString32;
                    }
                    put21.put(str67, str68);
                }
                for (String str69 : HEAD_FLAGS) {
                    put21.put(str69, o.optBoolean(str69, false));
                }
                for (String str70 : SHOWS) {
                    put21.put(str70, o.optBoolean(str70, true));
                }
                JSONObject put22 = put21.put("showInputs", o.optBoolean("showInputs", false)).put(str48, o.optBoolean(str48, false));
                String optString33 = o.optString(str54);
                List list8 = WATCH_AT;
                if (!list8.contains(optString33)) {
                    optString33 = null;
                }
                if (optString33 == null) {
                    optString33 = (String) list8.get(0);
                }
                boolean z3 = true;
                JSONObject put23 = put22.put(str54, optString33).put(str53, o.optBoolean(str53, true)).put(str52, o.optBoolean(str52, false)).put(str51, o.optBoolean(str51, false));
                String optString34 = o.optString(str50);
                if (!MOTIONS.contains(optString34)) {
                    optString34 = null;
                }
                if (optString34 == null) {
                    optString34 = "";
                }
                JSONObject put24 = put23.put(str50, optString34);
                String optString35 = o.optString("focus");
                if (!Intrinsics.areEqual(optString35, "ring")) {
                    optString35 = null;
                }
                if (optString35 == null) {
                    optString35 = "glass";
                }
                JSONObject put25 = put24.put("focus", optString35);
                String optString36 = o.optString("tstyle");
                List list9 = TSTYLES;
                if (!list9.contains(optString36)) {
                    optString36 = null;
                }
                if (optString36 == null) {
                    optString36 = (String) list9.get(0);
                }
                JSONObject put26 = put25.put("tstyle", optString36);
                String optString37 = o.optString("accent");
                if (!ACCENTS.containsKey(optString37)) {
                    optString37 = null;
                }
                if (optString37 == null) {
                    optString37 = "";
                }
                JSONObject put27 = put26.put("accent", optString37).put("cols", MathKt.coerceIn(o.optInt("cols", 5), 4, 8));
                double d = 0.0d;
                double optDouble = o.optDouble("rows", 0.0d);
                if (!Double.isNaN(optDouble) && optDouble >= 1.0d) {
                    d = Math.round(Math.min(optDouble, 10.0d) * 10) / 10.0d;
                }
                JSONObject put28 = put27.put("rows", d).put("dream", o.optBoolean("dream", false));
                String optString38 = o.optString("dface");
                if (!DFACES.contains(optString38)) {
                    optString38 = null;
                }
                if (optString38 == null) {
                    optString38 = str27;
                }
                JSONObject put29 = put28.put("dface", optString38);
                String optString39 = o.optString("ddark");
                Intrinsics.checkNotNullExpressionValue(optString39, str49);
                JSONObject put30 = put29.put("ddark", dark(optString39)).put("center", o.optBoolean("center", false));
                String optString40 = o.optString("wplace");
                List list10 = WPLACES;
                if (!list10.contains(optString40)) {
                    optString40 = null;
                }
                if (optString40 == null) {
                    optString40 = (String) list10.get(0);
                }
                JSONObject put31 = put30.put("wplace", optString40);
                String optString41 = o.optString("note");
                Intrinsics.checkNotNullExpressionValue(optString41, str49);
                Pattern compile2 = Pattern.compile("\\s+");
                String str71 = str3;
                Intrinsics.checkNotNullExpressionValue(compile2, str71);
                Matcher matcher2 = compile2.matcher(optString41);
                String str72 = str2;
                String replaceAll2 = matcher2.replaceAll(str72);
                String str73 = str;
                Intrinsics.checkNotNullExpressionValue(replaceAll2, str73);
                JSONObject put32 = put31.put("note", StringsKt.take(StringsKt.trim(replaceAll2).toString(), ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_PSK_WITH_AES_128_CBC_SHA));
                String optString42 = o.optString("place");
                Intrinsics.checkNotNullExpressionValue(optString42, str49);
                Pattern compile3 = Pattern.compile("\\s+");
                Intrinsics.checkNotNullExpressionValue(compile3, str71);
                String replaceAll3 = compile3.matcher(optString42).replaceAll(str72);
                Intrinsics.checkNotNullExpressionValue(replaceAll3, str73);
                JSONObject put33 = put32.put("place", StringsKt.take(StringsKt.trim(replaceAll3).toString(), 60));
                List<String> strs2 = strs(o.optJSONArray("feeds"));
                ArrayList arrayList19 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(strs2));
                for (String str74 : strs2) {
                    Intrinsics.checkNotNull(str74);
                    arrayList19.add(StringsKt.trim(str74).toString());
                }
                ArrayList arrayList20 = new ArrayList();
                Iterator it20 = arrayList19.iterator();
                while (it20.hasNext()) {
                    Object next7 = it20.next();
                    String str75 = (String) next7;
                    if (str75.length() <= 300 && WURL.matches(str75)) {
                        arrayList20.add(next7);
                    }
                }
                JSONObject put34 = put33.put("feeds", new JSONArray((Collection) CollectionsKt.take(CollectionsKt.distinct(arrayList20), 5))).put("keyon", o.optBoolean("keyon", false));
                JSONObject jSONObject13 = new JSONObject();
                for (Map.Entry entry2 : new TreeMap(keyApps(o.optJSONObject("keyapps"))).entrySet()) {
                    jSONObject13.put(((Integer) entry2.getKey()).toString(), (String) entry2.getValue());
                }
                JSONObject put35 = put34.put("keyapps", jSONObject13).put("autoon", o.optBoolean("autoon", false));
                if (o.optBoolean("autoon", false)) {
                    Regex regex2 = Target.PKG;
                    str4 = o.optString("autoapp");
                    Intrinsics.checkNotNullExpressionValue(str4, str49);
                }
                str4 = "";
                JSONObject put36 = put35.put("autoapp", str4);
                if (o.optBoolean("autoon", false) && o.optBoolean("autolast", false)) {
                    Regex regex3 = Target.PKG;
                    String optString43 = o.optString("autoapp");
                    Intrinsics.checkNotNullExpressionValue(optString43, str49);
                    if (Target.kind(optString43) == null) {
                        optString43 = "";
                    }
                }
                z3 = false;
                JSONObject put37 = put36.put("autolast", z3).put("autoall", o.optBoolean("autoall", false)).put(str59, new JSONArray((Collection) arrayList14)).put(str63, jSONObject12).put("qrs", jSONObject10).put("names", names(o.optJSONObject("names"))).put("pics", pics(o.optJSONObject("pics"))).put("themes", new JSONArray((Collection) customThemes(o)));
                if (o != null && (optJSONObject = o.optJSONObject("before")) != null) {
                    jSONObject = pickTheme(optJSONObject);
                }
                jSONObject = null;
                if (jSONObject != null) {
                    put37.put("before", jSONObject);
                }
                ?? put38 = put37.put("widgets", new JSONArray((Collection) distinct)).put("wsize", sizes(o, distinct)).put("wopt", cleanWopt(o));
                Intrinsics.checkNotNullExpressionValue(put38, "put(...)");
                JSONArray optJSONArray4 = o.optJSONArray("widgets");
                Regex regex4 = WIDGET_ID;
                if (optJSONArray4 != null) {
                    IntRange until3 = MathKt.until(0, optJSONArray4.length());
                    ArrayList arrayList21 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until3));
                    Iterator it21 = until3.iterator();
                    while (((IntProgressionIterator) it21).hasNext()) {
                        arrayList21.add(optJSONArray4.optString(((IntProgressionIterator) it21).nextInt()));
                    }
                    ArrayList arrayList22 = new ArrayList();
                    Iterator it22 = arrayList21.iterator();
                    while (it22.hasNext()) {
                        Object next8 = it22.next();
                        String str76 = (String) next8;
                        Intrinsics.checkNotNull(str76);
                        if (regex4.matches(str76)) {
                            arrayList22.add(next8);
                        }
                    }
                    put38.put("widgets", new JSONArray((Collection) CollectionsKt.take(CollectionsKt.distinct(arrayList22), 16)));
                }
                JSONObject optJSONObject6 = o.optJSONObject("wsize");
                if (optJSONObject6 == null) {
                    str5 = "keys(...)";
                } else {
                    JSONObject jSONObject14 = new JSONObject();
                    Iterator<String> keys3 = optJSONObject6.keys();
                    str5 = "keys(...)";
                    Intrinsics.checkNotNullExpressionValue(keys3, str5);
                    while (keys3.hasNext()) {
                        String next9 = keys3.next();
                        Intrinsics.checkNotNull(next9);
                        if (regex4.matches(next9)) {
                            String optString44 = optJSONObject6.optString(next9);
                            String str77 = str27;
                            if (!Intrinsics.areEqual(optString44, str77) && !Intrinsics.areEqual(optString44, "small")) {
                                optString44 = null;
                            }
                            if (optString44 != null) {
                                jSONObject14.put(next9, optString44);
                            }
                            str27 = str77;
                        }
                    }
                    put38.put("wsize", jSONObject14);
                }
                JSONObject themeOp = themeOp(o.optJSONObject("theme"));
                if (themeOp != null) {
                    put38.put("theme", themeOp);
                }
                put38.remove("wopt");
                JSONObject optJSONObject7 = o.optJSONObject("wopt");
                if (optJSONObject7 != null) {
                    JSONObject jSONObject15 = new JSONObject();
                    Iterator<String> keys4 = optJSONObject7.keys();
                    Intrinsics.checkNotNullExpressionValue(keys4, str5);
                    while (keys4.hasNext()) {
                        String next10 = keys4.next();
                        JSONObject optJSONObject8 = optJSONObject7.optJSONObject(next10);
                        if (optJSONObject8 != null) {
                            JSONObject jSONObject16 = new JSONObject();
                            Iterator<String> keys5 = optJSONObject8.keys();
                            Intrinsics.checkNotNullExpressionValue(keys5, str5);
                            while (keys5.hasNext()) {
                                String next11 = keys5.next();
                                String optString45 = optJSONObject8.optString(next11);
                                Intrinsics.checkNotNull(next10);
                                Iterator it23 = options(next10).iterator();
                                while (true) {
                                    if (it23.hasNext()) {
                                        obj = it23.next();
                                        jSONObject2 = optJSONObject7;
                                        if (!Intrinsics.areEqual(((Opt) obj).id, next11)) {
                                            optJSONObject7 = jSONObject2;
                                        }
                                    } else {
                                        jSONObject2 = optJSONObject7;
                                        obj = null;
                                    }
                                }
                                Opt opt = (Opt) obj;
                                ArrayList arrayList23 = arrayList8;
                                if (arrayList23.contains(next10)) {
                                    it = keys4;
                                    if (opt != null && Intrinsics.areEqual(opt.store, "wopt")) {
                                        str6 = str5;
                                        if (Intrinsics.areEqual(opt.type, "toggle")) {
                                            list = ArraysKt.asList(new String[]{"off", "on"});
                                        } else {
                                            list = opt.values;
                                        }
                                        if (!list.contains(optString45)) {
                                        }
                                        jSONObject16.put(next11, optString45);
                                    } else {
                                        str6 = str5;
                                    }
                                    arrayList8 = arrayList23;
                                    keys4 = it;
                                    optJSONObject7 = jSONObject2;
                                    str5 = str6;
                                } else {
                                    it = keys4;
                                    str6 = str5;
                                    if (regex4.matches(next10)) {
                                        Intrinsics.checkNotNull(next11);
                                        if (regex4.matches(next11)) {
                                            Intrinsics.checkNotNull(optString45);
                                            if (!regex4.matches(optString45)) {
                                            }
                                            jSONObject16.put(next11, optString45);
                                        }
                                    }
                                    arrayList8 = arrayList23;
                                    keys4 = it;
                                    optJSONObject7 = jSONObject2;
                                    str5 = str6;
                                }
                            }
                            JSONObject jSONObject17 = optJSONObject7;
                            Iterator<String> it24 = keys4;
                            String str78 = str5;
                            ArrayList arrayList24 = arrayList8;
                            if (jSONObject16.length() > 0) {
                                jSONObject15.put(next10, jSONObject16);
                            }
                            arrayList8 = arrayList24;
                            keys4 = it24;
                            optJSONObject7 = jSONObject17;
                            str5 = str78;
                        }
                    }
                    arrayList3 = arrayList8;
                    if (jSONObject15.length() > 0) {
                        put38.put("wopt", jSONObject15);
                    }
                } else {
                    arrayList3 = arrayList8;
                }
                JSONObject optJSONObject9 = o.optJSONObject("wstyle");
                if (optJSONObject9 != null) {
                    JSONObject jSONObject18 = new JSONObject();
                    Iterator it25 = arrayList3.iterator();
                    while (it25.hasNext()) {
                        String str79 = (String) it25.next();
                        String optString46 = optJSONObject9.optString(str79);
                        Intrinsics.checkNotNull(optString46);
                        if (!regex4.matches(optString46)) {
                            optString46 = null;
                        }
                        if (optString46 != null) {
                            jSONObject18.put(str79, optString46);
                        }
                    }
                    put38.put("wstyle", jSONObject18);
                }
                return put38;
            }
        }
    }

    public static boolean isFolder(String k) {
        Intrinsics.checkNotNullParameter(k, "k");
        return FOLDER.matches(k);
    }

    public static boolean isLive(String str) {
        if (str.length() <= 100 && LIVE.matches(str)) {
            return true;
        }
        return false;
    }

    public static boolean isPhoto(String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        return PHOTOS.contains(id);
    }

    public static boolean isVideo(String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        return VIDEO.matches(id);
    }

    public static LinkedHashMap keyApps(JSONObject jSONObject) {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        if (jSONObject != null) {
            Iterator<String> keys = jSONObject.keys();
            Intrinsics.checkNotNullExpressionValue(keys, "keys(...)");
            while (keys.hasNext()) {
                String next = keys.next();
                Intrinsics.checkNotNull(next);
                Integer intOrNull = StringsKt__StringNumberConversionsKt.toIntOrNull(next);
                if (intOrNull != null) {
                    String optString = jSONObject.optString(next);
                    if (KEY_COLOURS.contains(intOrNull) || KEY_NUMBERS.contains(intOrNull) || KEY_DEAD.contains(intOrNull)) {
                        Regex regex = Target.PKG;
                        Intrinsics.checkNotNull(optString);
                        if (Target.kind(optString) != null) {
                            linkedHashMap.put(intOrNull, optString);
                        }
                    }
                }
            }
        }
        return linkedHashMap;
    }

    public static String line(String str, int i) {
        Pattern compile = Pattern.compile("\\s+");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        String replaceAll = compile.matcher(str).replaceAll(" ");
        Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
        return StringsKt.take(StringsKt.trim(replaceAll).toString(), i);
    }

    public static JSONObject names(JSONObject jSONObject) {
        JSONObject jSONObject2 = new JSONObject();
        if (jSONObject != null) {
            Iterator<String> keys = jSONObject.keys();
            Intrinsics.checkNotNullExpressionValue(keys, "keys(...)");
            ArrayList mutableList = SequencesKt.toMutableList(SequencesKt.asSequence(keys));
            CollectionsKt__MutableCollectionsJVMKt.sort(mutableList);
            Iterator it = mutableList.iterator();
            while (it.hasNext()) {
                String str = (String) it.next();
                if (jSONObject2.length() >= 100) {
                    break;
                }
                Regex regex = Target.PKG;
                Intrinsics.checkNotNull(str);
                if (Target.kind(str) != null && !isLive(str)) {
                    String optString = jSONObject.optString(str);
                    Intrinsics.checkNotNullExpressionValue(optString, "optString(...)");
                    Pattern compile = Pattern.compile("\\s+");
                    Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                    String replaceAll = compile.matcher(optString).replaceAll(" ");
                    Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
                    String obj = StringsKt.trim(StringsKt.take(StringsKt.trim(replaceAll).toString(), 30)).toString();
                    if (obj.length() > 0) {
                        jSONObject2.put(str, obj);
                    }
                }
            }
        }
        return jSONObject2;
    }

    public static List options(String k) {
        String str;
        Intrinsics.checkNotNullParameter(k, "k");
        if (BIG_KINDS.contains(k)) {
            str = "big";
        } else {
            str = "small";
        }
        Opt opt = new Opt("size", "choice", SIZES, str, "wsize");
        if (k.equals("clock")) {
            return ArraysKt.asList(new Opt[]{opt, new Opt("face", "choice", ArraysKt.asList(new String[]{"classic", "minimal", "roman", "modern", "digital"}), "classic", "wopt"), new Opt("theme", "choice", ArraysKt.asList(new String[]{"dark", "light"}), "dark", "wopt"), new Opt("look", "choice", BARE, "glass", "wopt")});
        }
        boolean equals = k.equals("market");
        EmptyList emptyList = EmptyList.INSTANCE;
        if (equals) {
            return ArraysKt.asList(new Opt[]{opt, new Opt("look", "choice", LOOKS, "glass", "wopt"), new Opt("layout", "choice", ArraysKt.asList(new String[]{"card", "ticker"}), "card", "wopt"), new Opt("show", "choice", ArraysKt.asList(new String[]{"all", "gold", "rates"}), "all", "wopt"), new Opt("btc", "toggle", emptyList, "off", "wopt"), new Opt("fuel", "toggle", emptyList, "off", "wopt")});
        }
        if (k.equals("calendar")) {
            return ArraysKt.asList(new Opt[]{opt, new Opt("look", "choice", LOOKS, "glass", "wopt"), new Opt("layout", "choice", ArraysKt.asList(new String[]{"month", "date"}), "month", "wopt")});
        }
        if (k.equals("news")) {
            return ArraysKt.asList(new Opt[]{opt, new Opt("look", "choice", LOOKS, "glass", "wopt"), new Opt("src", "choice", ArraysKt.asList(new String[]{"auto", "mine", "both"}), "auto", "wopt")});
        }
        if (k.equals("prayer")) {
            return ArraysKt.asList(new Opt[]{opt, new Opt("look", "choice", LOOKS, "glass", "wopt"), new Opt("method", "choice", CollectionsKt.plus(MathKt.listOf("auto"), (Iterable) PRAYER_METHODS), "auto", "wopt"), new Opt("asr", "choice", ArraysKt.asList(new String[]{"standard", "hanafi"}), "standard", "wopt"), new Opt("hijri", "choice", ArraysKt.asList(new String[]{"hijri_m1", "hijri_0", "hijri_p1"}), "hijri_0", "wopt")});
        }
        if (TONAL.contains(k)) {
            return ArraysKt.asList(new Opt[]{opt, new Opt("look", "choice", LOOKS, "glass", "wopt")});
        }
        if (WIDGETS.contains(k)) {
            return MathKt.listOf(opt);
        }
        return emptyList;
    }

    public static String photoPath(String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        return Census$$ExternalSyntheticOutline0.m(StringsKt.substringBeforeLast("/sdcard/Android/data/dev.tvremote.home/files/wall.jpg", '/', "/sdcard/Android/data/dev.tvremote.home/files/wall.jpg"), "/", ApkSigner$$ExternalSyntheticOutline0.m("wall", StringsKt.removePrefix(id, "photo"), ".jpg"));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r3v14, types: [org.json.JSONArray] */
    /* JADX WARN: Type inference failed for: r3v3, types: [org.json.JSONObject] */
    /* JADX WARN: Type inference failed for: r3v4, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r3v8, types: [org.json.JSONObject] */
    public static JSONObject pickTheme(JSONObject jSONObject) {
        Object cleanWopt;
        JSONObject jSONObject2 = new JSONObject();
        for (String str : THEME_KEYS) {
            if (jSONObject.has(str) || (Intrinsics.areEqual(str, "wopt") && jSONObject.has("wstyle"))) {
                int hashCode = str.hashCode();
                if (hashCode != 3655388) {
                    if (hashCode != 113429752) {
                        if (hashCode == 1340337839 && str.equals("widgets")) {
                            List strs = strs(jSONObject.optJSONArray(str));
                            ArrayList arrayList = new ArrayList();
                            for (Object obj : strs) {
                                if (!HomeQr.KEYS.contains((String) obj)) {
                                    arrayList.add(obj);
                                }
                            }
                            cleanWopt = new JSONArray((Collection) arrayList);
                            jSONObject2.put(str, cleanWopt);
                        }
                        cleanWopt = jSONObject.get(str);
                        jSONObject2.put(str, cleanWopt);
                    } else {
                        if (str.equals("wsize")) {
                            cleanWopt = new JSONObject();
                            JSONObject optJSONObject = jSONObject.optJSONObject(str);
                            if (optJSONObject != null) {
                                Iterator<String> keys = optJSONObject.keys();
                                Intrinsics.checkNotNullExpressionValue(keys, "keys(...)");
                                while (keys.hasNext()) {
                                    String next = keys.next();
                                    if (!HomeQr.KEYS.contains(next)) {
                                        cleanWopt.put(next, optJSONObject.get(next));
                                    }
                                }
                            }
                            jSONObject2.put(str, cleanWopt);
                        }
                        cleanWopt = jSONObject.get(str);
                        jSONObject2.put(str, cleanWopt);
                    }
                } else {
                    if (str.equals("wopt")) {
                        cleanWopt = cleanWopt(jSONObject);
                        jSONObject2.put(str, cleanWopt);
                    }
                    cleanWopt = jSONObject.get(str);
                    jSONObject2.put(str, cleanWopt);
                }
            }
        }
        return jSONObject2;
    }

    public static JSONObject pics(JSONObject jSONObject) {
        JSONObject jSONObject2 = new JSONObject();
        if (jSONObject != null) {
            Iterator<String> keys = jSONObject.keys();
            Intrinsics.checkNotNullExpressionValue(keys, "keys(...)");
            ArrayList mutableList = SequencesKt.toMutableList(SequencesKt.asSequence(keys));
            CollectionsKt__MutableCollectionsJVMKt.sort(mutableList);
            Iterator it = mutableList.iterator();
            while (it.hasNext()) {
                String str = (String) it.next();
                if (jSONObject2.length() >= 40) {
                    break;
                }
                Regex regex = Target.PKG;
                Intrinsics.checkNotNull(str);
                if (Target.kind(str) != null && !isLive(str) && !isFolder(str)) {
                    String optString = jSONObject.optString(str);
                    Intrinsics.checkNotNull(optString);
                    if (PIC_ID.matches(optString)) {
                        jSONObject2.put(str, optString);
                    }
                }
            }
        }
        return jSONObject2;
    }

    public static List pkgs(JSONArray jSONArray, int i) {
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        if (jSONArray != null) {
            int length = jSONArray.length();
            for (int i2 = 0; i2 < length; i2++) {
                String optString = jSONArray.optString(i2);
                Regex regex = Target.PKG;
                Intrinsics.checkNotNull(optString);
                if (Target.kind(optString) != null) {
                    linkedHashSet.add(optString);
                }
            }
        }
        return CollectionsKt.take(linkedHashSet, i);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x0060, code lost:
    
        if (r5.equals("flip") == false) goto L33;
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x0072, code lost:
    
        if (r5.equals("big") == false) goto L33;
     */
    /* JADX WARN: Removed duplicated region for block: B:28:0x0078  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static JSONObject sizes(JSONObject jSONObject, List list) {
        int i;
        Object obj;
        JSONObject jSONObject2 = new JSONObject();
        JSONObject optJSONObject = jSONObject.optJSONObject("wsize");
        if (optJSONObject != null) {
            Iterator it = WIDGETS.iterator();
            while (it.hasNext()) {
                String str = (String) it.next();
                String optString = optJSONObject.optString(str);
                if (!Intrinsics.areEqual(optString, "big") && !Intrinsics.areEqual(optString, "small")) {
                    optString = null;
                }
                if (optString != null) {
                    jSONObject2.put(str, optString);
                }
            }
        } else {
            String optString2 = jSONObject.optString("wlayout");
            int i2 = 0;
            if (optString2 != null) {
                i = 1;
                switch (optString2.hashCode()) {
                    case 97536:
                        break;
                    case 3023666:
                        if (optString2.equals("big2")) {
                            i = 2;
                            break;
                        }
                        break;
                    case 3145837:
                        break;
                    case 3481927:
                        if (optString2.equals("quad")) {
                            i = 0;
                            break;
                        }
                        break;
                }
                if (i >= 0) {
                    boolean areEqual = Intrinsics.areEqual(jSONObject.optString("wlayout"), "flip");
                    for (Object obj2 : list) {
                        int i3 = i2 + 1;
                        if (i2 >= 0) {
                            String str2 = (String) obj2;
                            if (!areEqual ? i2 >= i : i2 != 2) {
                                obj = "small";
                            } else {
                                obj = "big";
                            }
                            jSONObject2.put(str2, obj);
                            i2 = i3;
                        } else {
                            CollectionsKt__CollectionsKt.throwIndexOverflow();
                            throw null;
                        }
                    }
                }
            }
            i = -1;
            if (i >= 0) {
            }
        }
        return jSONObject2;
    }

    public static List strs(JSONArray jSONArray) {
        if (jSONArray == null) {
            return EmptyList.INSTANCE;
        }
        IntRange until = MathKt.until(0, jSONArray.length());
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(until));
        Iterator it = until.iterator();
        while (((IntProgressionIterator) it).hasNext) {
            arrayList.add(jSONArray.optString(((IntProgressionIterator) it).nextInt()));
        }
        return arrayList;
    }

    public static String themeName(String str) {
        Pattern compile = Pattern.compile("\\s+");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        String replaceAll = compile.matcher(str).replaceAll(" ");
        Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
        return StringsKt.trim(StringsKt.take(StringsKt.trim(replaceAll).toString(), 24)).toString();
    }

    public static JSONObject themeOp(JSONObject jSONObject) {
        if (jSONObject != null) {
            JSONObject jSONObject2 = new JSONObject();
            String optString = jSONObject.optString("apply");
            int length = optString.length();
            if (1 > length || length >= 13) {
                optString = null;
            }
            if (optString != null) {
                jSONObject2.put("apply", optString);
            }
            String optString2 = jSONObject.optString("save");
            Intrinsics.checkNotNull(optString2);
            String themeName = themeName(optString2);
            if (themeName.length() <= 0) {
                themeName = null;
            }
            if (themeName != null) {
                jSONObject2.put("save", themeName);
            }
            String optString3 = jSONObject.optString("del");
            int length2 = optString3.length();
            if (1 > length2 || length2 >= 13) {
                optString3 = null;
            }
            if (optString3 != null) {
                jSONObject2.put("del", optString3);
            }
            if (jSONObject2.length() != 0) {
                return jSONObject2;
            }
        }
        return null;
    }

    public static String wurl(String str) {
        String obj = StringsKt.trim(str).toString();
        if (obj.length() > 500 || !WURL.matches(obj)) {
            obj = null;
        }
        if (obj == null) {
            return "";
        }
        return obj;
    }
}
