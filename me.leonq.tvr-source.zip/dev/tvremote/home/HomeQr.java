package dev.tvremote.home;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgression;
import kotlin.ranges.IntProgressionIterator;
import kotlin.text.Charsets;
import kotlin.text.Regex;
import kotlin.text.RegexOption;

/* loaded from: classes.dex */
public abstract class HomeQr {
    public static final Object FIELDS;
    public static final ArrayList KEYS;
    public static final Regex SCHEME;
    public static final List TEMPLATES = ArraysKt.asList(new String[]{"wifi", "link", "text", "tel", "sms", "mail", "contact"});
    public static final List SECURITY = ArraysKt.asList(new String[]{"WPA", "WEP", "nopass"});

    static {
        IntProgression intProgression = new IntProgression(1, 4, 1);
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(intProgression));
        Iterator it = intProgression.iterator();
        while (((IntProgressionIterator) it).hasNext) {
            arrayList.add("qr" + ((IntProgressionIterator) it).nextInt());
        }
        KEYS = arrayList;
        FIELDS = MapsKt__MapsKt.mapOf(new Pair("wifi", ArraysKt.asList(new String[]{"ssid", "pass", "sec", "hidden"})), new Pair("link", MathKt.listOf("url")), new Pair("text", MathKt.listOf("text")), new Pair("tel", MathKt.listOf("num")), new Pair("sms", ArraysKt.asList(new String[]{"num", "body"})), new Pair("mail", ArraysKt.asList(new String[]{"to", "subject", "body"})), new Pair("contact", ArraysKt.asList(new String[]{"name", "tel", "email"})));
        SCHEME = new Regex("^(?:[A-Za-z][A-Za-z0-9+.-]*://|(?:mailto|tel|sms|smsto|geo|whatsapp|tg|viber|zalo):)", RegexOption.IGNORE_CASE);
    }

    public static String esc(String str) {
        Pattern compile = Pattern.compile("([\\\\;,:\"])");
        Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
        String replaceAll = compile.matcher(str).replaceAll("\\\\$1");
        Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
        return replaceAll;
    }

    public static String num(String str) {
        StringBuilder sb = new StringBuilder();
        int length = str.length();
        for (int i = 0; i < length; i++) {
            char charAt = str.charAt(i);
            if (('0' <= charAt && charAt < ':') || charAt == '+' || charAt == '*' || charAt == '#') {
                sb.append(charAt);
            }
        }
        return sb.toString();
    }

    public static String pct(String s) {
        Intrinsics.checkNotNullParameter(s, "s");
        StringBuilder sb = new StringBuilder();
        byte[] bytes = s.getBytes(Charsets.UTF_8);
        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        for (byte b : bytes) {
            int i = b & 255;
            if ((48 > i || i >= 58) && ((65 > i || i >= 91) && ((97 > i || i >= 123) && i != 45 && i != 95 && i != 46 && i != 126))) {
                sb.append('%');
                sb.append("0123456789ABCDEF".charAt(i >> 4));
                sb.append("0123456789ABCDEF".charAt(b & 15));
            } else {
                sb.append((char) i);
            }
        }
        return sb.toString();
    }
}
