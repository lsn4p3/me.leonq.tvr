package dev.tvremote.home;

import java.util.Locale;
import java.util.Set;
import kotlin.collections.SetsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.RegexOption;
import kotlin.text.StringsKt;

/* loaded from: classes.dex */
public abstract class LinkUrl {
    public static final Set BANNED = SetsKt.setOf((Object[]) new String[]{"intent", "file", "content", "javascript", "data", "about", "blob", "vbscript", "filesystem", "android-app", "view-source", "chrome"});
    public static final Regex BARE;
    public static final Regex SCHEME;

    static {
        RegexOption regexOption = RegexOption.IGNORE_CASE;
        SCHEME = new Regex("^([a-z][a-z0-9+.-]{1,30})://(\\S+)$", regexOption);
        BARE = new Regex("^(?:[a-z0-9-]+\\.)+[a-z]{2,}(?:[/?#]\\S*)?$", regexOption);
    }

    public static String clean(String str) {
        if (str == null) {
            str = "";
        }
        String obj = StringsKt.trim(str).toString();
        if (obj.length() != 0 && obj.length() <= 500) {
            for (int i = 0; i < obj.length(); i++) {
                char charAt = obj.charAt(i);
                if (MathKt.isWhitespace(charAt) || Character.isISOControl(charAt)) {
                    return null;
                }
            }
            Regex regex = SCHEME;
            if (!regex.matches(obj)) {
                if (BARE.matches(obj)) {
                    obj = "https://".concat(obj);
                } else {
                    return null;
                }
            }
            MatcherMatchResult find = regex.find(obj, 0);
            Intrinsics.checkNotNull(find);
            String lowerCase = ((String) ((MatcherMatchResult$groupValues$1) find.getGroupValues()).get(1)).toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
            if (!BANNED.contains(lowerCase)) {
                if (lowerCase.equals("http") || lowerCase.equals("https")) {
                    String str2 = (String) ((MatcherMatchResult$groupValues$1) find.getGroupValues()).get(2);
                    String substringBefore = StringsKt.substringBefore(str2, '/', str2);
                    String substringBefore2 = StringsKt.substringBefore(substringBefore, '?', substringBefore);
                    String substringBefore3 = StringsKt.substringBefore(substringBefore2, '#', substringBefore2);
                    if (substringBefore3.length() == 0 || StringsKt.contains$default(substringBefore3, '@')) {
                        return null;
                    }
                }
                String substring = obj.substring(lowerCase.length());
                Intrinsics.checkNotNullExpressionValue(substring, "substring(...)");
                return lowerCase.concat(substring);
            }
            return null;
        }
        return null;
    }
}
