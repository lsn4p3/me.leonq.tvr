package dev.tvremote.home;

import android.content.Context;
import android.content.Intent;
import dev.tvremote.core.Fleet;
import dev.tvremote.core.Lan$$ExternalSyntheticLambda0;
import dev.tvremote.core.scenes.Voice;
import dev.tvremote.guard.GuardWords;
import dev.tvremote.phone.MainActivity;
import dev.tvremote.phone.PhoneApp;
import dev.tvremote.phone.ir.IrLearn;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.IntProgression;
import kotlin.ranges.IntProgressionIterator;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.conscrypt.FileClientSessionCache;
import org.conscrypt.metrics.ConscryptStatsLog;

/* loaded from: classes.dex */
public final /* synthetic */ class HomeQr$$ExternalSyntheticLambda0 implements Function1 {
    public final /* synthetic */ int $r8$classId;

    public /* synthetic */ HomeQr$$ExternalSyntheticLambda0(int i) {
        this.$r8$classId = i;
    }

    @Override // kotlin.jvm.functions.Function1
    public final Object invoke(Object obj) {
        boolean z = false;
        switch (this.$r8$classId) {
            case 0:
                Pair it = (Pair) obj;
                Intrinsics.checkNotNullParameter(it, "it");
                List list = HomeQr.TEMPLATES;
                Object obj2 = it.second;
                Intrinsics.checkNotNullExpressionValue(obj2, "<get-second>(...)");
                return it.first + "=" + HomeQr.pct((String) obj2);
            case 1:
                String t = (String) obj;
                Intrinsics.checkNotNullParameter(t, "t");
                if (StringsKt__StringsJVMKt.endsWith(t, false, "/ui_service/data/authentication") || StringsKt__StringsJVMKt.endsWith(t, false, "/ui_service/data/vidaa_app_connect")) {
                    z = true;
                }
                return Boolean.valueOf(z);
            case 2:
                String t2 = (String) obj;
                Intrinsics.checkNotNullParameter(t2, "t");
                if (StringsKt__StringsJVMKt.endsWith(t2, false, "/platform_service/data/tokenissuance") || StringsKt__StringsJVMKt.endsWith(t2, false, "/platform_service/data/gettoken")) {
                    z = true;
                }
                return Boolean.valueOf(z);
            case 3:
                String it2 = (String) obj;
                Intrinsics.checkNotNullParameter(it2, "it");
                if (StringsKt__StringsJVMKt.endsWith(it2, false, "/ui_service/data/authenticationcode") || StringsKt__StringsJVMKt.endsWith(it2, false, "/ui_service/data/authenticationcodeclose")) {
                    z = true;
                }
                return Boolean.valueOf(z);
            case 4:
                String it3 = (String) obj;
                Intrinsics.checkNotNullParameter(it3, "it");
                return Boolean.valueOf(StringsKt__StringsJVMKt.endsWith(it3, false, "/ui_service/data/authentication"));
            case 5:
                String it4 = (String) obj;
                Intrinsics.checkNotNullParameter(it4, "it");
                if (StringsKt__StringsJVMKt.endsWith(it4, false, "/platform_service/data/tokenissuance") || StringsKt__StringsJVMKt.endsWith(it4, false, "/platform_service/data/gettoken")) {
                    z = true;
                }
                return Boolean.valueOf(z);
            case 6:
                String it5 = (String) obj;
                Intrinsics.checkNotNullParameter(it5, "it");
                if (StringsKt__StringsJVMKt.endsWith(it5, false, "/platform_service/data/getdeviceinfo") || StringsKt__StringsJVMKt.endsWith(it5, false, "/platform_service/data/gettvinfo")) {
                    z = true;
                }
                return Boolean.valueOf(z);
            case 7:
                Byte b = (Byte) obj;
                b.byteValue();
                return String.format("%02X", Arrays.copyOf(new Object[]{b}, 1));
            case 8:
                Byte b2 = (Byte) obj;
                b2.byteValue();
                return String.format("%02X", Arrays.copyOf(new Object[]{b2}, 1));
            case ConscryptStatsLog.CONSCRYPT_SERVICE_USED__MODE__POLY1305 /* 9 */:
                Byte b3 = (Byte) obj;
                b3.byteValue();
                return String.format("%02x", Arrays.copyOf(new Object[]{b3}, 1));
            case ConscryptStatsLog.TLS_HANDSHAKE_REPORTED__CIPHER_SUITE__TLS_RSA_WITH_3DES_EDE_CBC_SHA /* 10 */:
                String it6 = (String) obj;
                Intrinsics.checkNotNullParameter(it6, "it");
                String quote = Pattern.quote(it6);
                Intrinsics.checkNotNullExpressionValue(quote, "quote(...)");
                return quote;
            case 11:
                String out = (String) obj;
                Intrinsics.checkNotNullParameter(out, "out");
                if (StringsKt.contains(out, "Exception", false) || StringsKt.contains(out, "Error", false) || StringsKt.contains(out, "Unknown", false) || StringsKt.contains(out, "not found", false)) {
                    z = true;
                }
                return Boolean.valueOf(z);
            case FileClientSessionCache.MAX_SIZE /* 12 */:
                Voice.Command it7 = (Voice.Command) obj;
                Intrinsics.checkNotNullParameter(it7, "it");
                Voice voice = Voice.INSTANCE;
                return Integer.valueOf(Voice.names1(it7).length());
            case 13:
                Voice.Command it8 = (Voice.Command) obj;
                Intrinsics.checkNotNullParameter(it8, "it");
                Voice voice2 = Voice.INSTANCE;
                return Voice.names1(it8);
            case 14:
                Triple it9 = (Triple) obj;
                Intrinsics.checkNotNullParameter(it9, "it");
                return Integer.valueOf(((String) it9.second).length());
            case 15:
                Triple it10 = (Triple) obj;
                Intrinsics.checkNotNullParameter(it10, "it");
                return (Comparable) it10.second;
            case 16:
                Voice.Command it11 = (Voice.Command) obj;
                Intrinsics.checkNotNullParameter(it11, "it");
                Voice voice3 = Voice.INSTANCE;
                return Voice.names1(it11);
            case 17:
                InetAddress it12 = (InetAddress) obj;
                Intrinsics.checkNotNullParameter(it12, "it");
                return Boolean.valueOf(it12.isLoopbackAddress());
            case 18:
                StackTraceElement stackTraceElement = (StackTraceElement) obj;
                return stackTraceElement.getFileName() + ":" + stackTraceElement.getLineNumber();
            case 19:
                Intrinsics.checkNotNullParameter((String) obj, "it");
                return Boolean.valueOf(!StringsKt.isBlank(r0));
            case 20:
                String str = (String) obj;
                List list2 = HomeConfig.PLAIN;
                Intrinsics.checkNotNull(str);
                return "folder:".concat(str);
            case 21:
                ((Boolean) obj).getClass();
                int i = MainActivity.$r8$clinit;
                return Unit.INSTANCE;
            case 22:
                int i2 = PhoneApp.$r8$clinit;
                Intrinsics.checkNotNullParameter((Context) obj, "it");
                return new GuardWords(Fleet.T("err.title", new Pair[0]), Fleet.T("err.last_time", new Pair[0]), Fleet.T("err.copy", new Pair[0]), Fleet.T("err.copied", new Pair[0]), Fleet.T("err.share", new Pair[0]), Fleet.T("err.close", new Pair[0]), Fleet.T("err.sent", new Pair[0]), new Lan$$ExternalSyntheticLambda0(6));
            case 23:
                Intent it13 = (Intent) obj;
                Intrinsics.checkNotNullParameter(it13, "it");
                Intent putExtra = it13.putExtra("do", "power");
                Intrinsics.checkNotNullExpressionValue(putExtra, "putExtra(...)");
                return putExtra;
            case 24:
                Intent it14 = (Intent) obj;
                Intrinsics.checkNotNullParameter(it14, "it");
                Intent putExtra2 = it14.putExtra("do", "mute");
                Intrinsics.checkNotNullExpressionValue(putExtra2, "putExtra(...)");
                return putExtra2;
            case 25:
                Intent it15 = (Intent) obj;
                Intrinsics.checkNotNullParameter(it15, "it");
                Intent putExtra3 = it15.putExtra("do", "vol_down");
                Intrinsics.checkNotNullExpressionValue(putExtra3, "putExtra(...)");
                return putExtra3;
            case 26:
                Intent it16 = (Intent) obj;
                Intrinsics.checkNotNullParameter(it16, "it");
                Intent putExtra4 = it16.putExtra("do", "vol_up");
                Intrinsics.checkNotNullExpressionValue(putExtra4, "putExtra(...)");
                return putExtra4;
            case 27:
                long longValue = ((Long) obj).longValue();
                if (longValue > 4294967295L) {
                    return null;
                }
                IntProgression intProgression = new IntProgression(0, 3, 1);
                ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(intProgression));
                Iterator it17 = intProgression.iterator();
                while (((IntProgressionIterator) it17).hasNext) {
                    arrayList.add(Integer.valueOf((int) ((longValue >> (((IntProgressionIterator) it17).nextInt() * 8)) & 255)));
                }
                List list3 = IrLearn.KEYS;
                if (((((Number) arrayList.get(0)).intValue() ^ ((Number) arrayList.get(1)).intValue()) & 255) != 255 || ((((Number) arrayList.get(2)).intValue() ^ ((Number) arrayList.get(3)).intValue()) & 255) != 255) {
                    return null;
                }
                return new Pair(IrLearn.hex(((Number) arrayList.get(0)).intValue()), IrLearn.hex(((Number) arrayList.get(2)).intValue()));
            case 28:
                long longValue2 = ((Long) obj).longValue();
                if (longValue2 > 4294967295L) {
                    return null;
                }
                IntProgression intProgression2 = new IntProgression(0, 3, 1);
                ArrayList arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(intProgression2));
                Iterator it18 = intProgression2.iterator();
                while (((IntProgressionIterator) it18).hasNext) {
                    arrayList2.add(Integer.valueOf((int) ((longValue2 >> (((IntProgressionIterator) it18).nextInt() * 8)) & 255)));
                }
                List list4 = IrLearn.KEYS;
                if (((((Number) arrayList2.get(2)).intValue() ^ ((Number) arrayList2.get(3)).intValue()) & 255) != 255 || ((((Number) arrayList2.get(0)).intValue() ^ ((Number) arrayList2.get(1)).intValue()) & 255) != 255) {
                    return null;
                }
                return new Pair(IrLearn.hex(((Number) arrayList2.get(3)).intValue()), IrLearn.hex(((Number) arrayList2.get(1)).intValue()));
            default:
                long longValue3 = ((Long) obj).longValue();
                if (longValue3 > 65535) {
                    return null;
                }
                return new Pair(IrLearn.hex((int) (longValue3 >> 8)), IrLearn.hex((int) longValue3));
        }
    }
}
