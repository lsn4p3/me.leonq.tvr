package dev.tvremote.home;

import java.io.IOException;
import java.io.InputStream;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLConnection;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.regex.Pattern;
import javax.net.ssl.SSLException;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Charsets;
import kotlin.text.MatcherMatchResult;
import kotlin.text.MatcherMatchResult$groupValues$1;
import kotlin.text.Regex;
import kotlin.text.RegexOption;
import kotlin.text.StringsKt;
import kotlin.text.StringsKt__StringsJVMKt;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class WebCheck {
    public static final Regex TITLE = new Regex("<title[^>]*>([^<]{1,200})", RegexOption.IGNORE_CASE);

    /* JADX WARN: Code restructure failed: missing block: B:21:0x008d, code lost:
    
        if (r8 != null) goto L24;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x008f, code lost:
    
        r8 = "";
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x0090, code lost:
    
        r8 = kotlin.text.StringsKt.trim(kotlin.text.StringsKt.substringBefore(r8, ';', r8)).toString().toLowerCase(java.util.Locale.ROOT);
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r8, "toLowerCase(...)");
        r1 = new org.json.JSONObject().put("code", r14).put("type", r8).put("url", r1).put("ms", (java.lang.System.nanoTime() / 1000000) - r5);
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00d3, code lost:
    
        if (r14 < 400) goto L31;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x00d6, code lost:
    
        r0 = r1.put("ok", false).put("why", "status");
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, "put(...)");
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x00e6, code lost:
    
        return r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x00eb, code lost:
    
        if (r8.length() != 0) goto L34;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x00ed, code lost:
    
        r7 = r8;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x0105, code lost:
    
        r6 = true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x0106, code lost:
    
        if (r6 != false) goto L47;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x010f, code lost:
    
        if (kotlin.text.StringsKt__StringsJVMKt.startsWith(r7, false, "image/") != false) goto L47;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x0117, code lost:
    
        if (kotlin.text.StringsKt__StringsJVMKt.startsWith(r7, false, "text/") != false) goto L47;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0119, code lost:
    
        r0 = r1.put("ok", false).put("why", "type");
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, "put(...)");
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x0125, code lost:
    
        if (r6 == false) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x0127, code lost:
    
        r0 = title(r10);
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x012b, code lost:
    
        if (r0 == null) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x012d, code lost:
    
        r1.put("title", r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x0132, code lost:
    
        r0 = r1.put("ok", true);
        kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, "put(...)");
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00f0, code lost:
    
        r7 = r8;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x00f8, code lost:
    
        if (r7.equals("text/html") != false) goto L40;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x0100, code lost:
    
        if (r7.equals("application/xhtml+xml") == false) goto L39;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x0103, code lost:
    
        r6 = false;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static JSONObject check$default(String str) {
        String wurl = HomeConfig.wurl(str);
        if (wurl.length() == 0) {
            JSONObject no = no("bad");
            Intrinsics.checkNotNullExpressionValue(no, "no(...)");
            return no;
        }
        long nanoTime = System.nanoTime() / 1000000;
        boolean z = false;
        int i = 0;
        while (true) {
            String str2 = "";
            if (i < 5) {
                try {
                    URLConnection openConnection = new URL(wurl).openConnection();
                    Intrinsics.checkNotNull(openConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
                    HttpURLConnection httpURLConnection = (HttpURLConnection) openConnection;
                    httpURLConnection.setConnectTimeout(6000);
                    httpURLConnection.setReadTimeout(6000);
                    httpURLConnection.setInstanceFollowRedirects(z);
                    httpURLConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 12; TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36");
                    httpURLConnection.setRequestProperty("Accept", "text/html,*/*");
                    try {
                        int responseCode = httpURLConnection.getResponseCode();
                        String headerField = httpURLConnection.getHeaderField("Location");
                        if (300 > responseCode || responseCode >= 400 || headerField == null) {
                            break;
                        }
                        wurl = new URL(new URL(wurl), headerField).toString();
                        Intrinsics.checkNotNullExpressionValue(wurl, "toString(...)");
                        i++;
                        z = false;
                    } finally {
                        httpURLConnection.disconnect();
                    }
                } catch (ConnectException unused) {
                    JSONObject no2 = no("refused");
                    Intrinsics.checkNotNullExpressionValue(no2, "no(...)");
                    return no2;
                } catch (SocketTimeoutException unused2) {
                    JSONObject no3 = no("timeout");
                    Intrinsics.checkNotNullExpressionValue(no3, "no(...)");
                    return no3;
                } catch (UnknownHostException unused3) {
                    JSONObject no4 = no("dns");
                    Intrinsics.checkNotNullExpressionValue(no4, "no(...)");
                    return no4;
                } catch (SSLException unused4) {
                    JSONObject no5 = no("ssl");
                    Intrinsics.checkNotNullExpressionValue(no5, "no(...)");
                    return no5;
                } catch (IOException e) {
                    String message = e.getMessage();
                    if (message != null) {
                        str2 = message;
                    }
                    String str3 = "cleartext";
                    if (!StringsKt.contains(str2, "cleartext", true)) {
                        str3 = "net";
                    }
                    JSONObject no6 = no(str3);
                    Intrinsics.checkNotNullExpressionValue(no6, "no(...)");
                    return no6;
                } catch (Exception unused5) {
                    JSONObject no7 = no("bad");
                    Intrinsics.checkNotNullExpressionValue(no7, "no(...)");
                    return no7;
                }
            } else {
                JSONObject put = no("loop").put("url", wurl);
                Intrinsics.checkNotNullExpressionValue(put, "put(...)");
                return put;
            }
        }
    }

    public static JSONObject no(String str) {
        return new JSONObject().put("ok", false).put("why", str);
    }

    public static String title(HttpURLConnection httpURLConnection) {
        String str;
        String obj;
        try {
            InputStream inputStream = httpURLConnection.getInputStream();
            try {
                byte[] bArr = new byte[65536];
                int i = 0;
                while (i < 65536) {
                    int read = inputStream.read(bArr, i, 65536 - i);
                    if (read < 0) {
                        break;
                    }
                    i += read;
                }
                byte[] copyOf = Arrays.copyOf(bArr, i);
                Intrinsics.checkNotNullExpressionValue(copyOf, "copyOf(...)");
                MathKt.closeFinally(inputStream, null);
                MatcherMatchResult find = TITLE.find(new String(copyOf, Charsets.UTF_8), 0);
                if (find != null && (str = (String) ((MatcherMatchResult$groupValues$1) find.getGroupValues()).get(1)) != null && (obj = StringsKt.trim(str).toString()) != null) {
                    Pattern compile = Pattern.compile("\\s+");
                    Intrinsics.checkNotNullExpressionValue(compile, "compile(...)");
                    String replaceAll = compile.matcher(obj).replaceAll(" ");
                    Intrinsics.checkNotNullExpressionValue(replaceAll, "replaceAll(...)");
                    String replace$default = StringsKt__StringsJVMKt.replace$default(StringsKt__StringsJVMKt.replace$default(StringsKt__StringsJVMKt.replace$default(replaceAll, "&amp;", "&"), "&#39;", "'"), "&quot;", "\"");
                    if (replace$default.length() > 0) {
                        return replace$default;
                    }
                }
            } finally {
            }
        } catch (Exception unused) {
        }
        return null;
    }
}
