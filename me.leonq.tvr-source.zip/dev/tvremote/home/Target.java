package dev.tvremote.home;

import java.util.Set;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.Regex;
import kotlin.text.StringsKt__StringsJVMKt;

/* loaded from: classes.dex */
public abstract class Target {
    public static final Regex PKG = new Regex("[A-Za-z][\\w]*(\\.[\\w]+)+");
    public static final Regex PIN = new Regex("pin:([A-Za-z][\\w]*(?:\\.[\\w]+)+)/([A-Za-z0-9][\\w.\\-:@]{0,63})");
    public static final Regex LIVE = new Regex("tile:([A-Za-z][\\w]*(?:\\.[\\w]+)+)/([a-z][a-z0-9_]{0,15})");
    public static final Set ACTIONS = MathKt.setOf("do:controlcenter");

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* loaded from: classes.dex */
    public final class Kind {
        public static final /* synthetic */ Kind[] $VALUES;
        public static final Kind ACTION;
        public static final Kind APP;
        public static final Kind PIN;
        public static final Kind TILE;

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r4v0, types: [java.lang.Enum, dev.tvremote.home.Target$Kind] */
        /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Enum, dev.tvremote.home.Target$Kind] */
        /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Enum, dev.tvremote.home.Target$Kind] */
        /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Enum, dev.tvremote.home.Target$Kind] */
        static {
            ?? r4 = new Enum("APP", 0);
            APP = r4;
            ?? r5 = new Enum("PIN", 1);
            PIN = r5;
            ?? r6 = new Enum("TILE", 2);
            TILE = r6;
            ?? r7 = new Enum("ACTION", 3);
            ACTION = r7;
            $VALUES = new Kind[]{r4, r5, r6, r7};
        }

        public static Kind valueOf(String str) {
            return (Kind) Enum.valueOf(Kind.class, str);
        }

        public static Kind[] values() {
            return (Kind[]) $VALUES.clone();
        }
    }

    public static Kind kind(String t) {
        Intrinsics.checkNotNullParameter(t, "t");
        if (t.length() != 0 && t.length() <= 200) {
            if (StringsKt__StringsJVMKt.startsWith(t, false, "pin:")) {
                if (PIN.matches(t)) {
                    return Kind.PIN;
                }
                return null;
            }
            if (ACTIONS.contains(t)) {
                return Kind.ACTION;
            }
            if (StringsKt__StringsJVMKt.startsWith(t, false, "tile:")) {
                if (LIVE.matches(t)) {
                    return Kind.TILE;
                }
                return null;
            }
            if (PKG.matches(t)) {
                return Kind.APP;
            }
            return null;
        }
        return null;
    }
}
