package dev.tvremote.i18n;

import java.util.List;
import kotlin.Pair;
import kotlin.collections.ArraysKt;
import kotlin.collections.MapsKt__MapsKt;

/* loaded from: classes.dex */
public abstract class Langs {
    public static final List CODES = ArraysKt.asList(new String[]{"vi", "en", "ru", "fr", "ar"});
    public static final Object NAMES = MapsKt__MapsKt.mapOf(new Pair("vi", "Tiếng Việt"), new Pair("en", "English"), new Pair("ru", "Русский"), new Pair("fr", "Français"), new Pair("ar", "العربية"));
}
